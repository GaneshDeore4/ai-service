import { Component, inject, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SessionTimeoutService } from './service/sessionService/session-timeout.service';
import { BrandedToastComponent } from './components/dialogs/branded-toast/branded-toast.component';
import { SessionService } from './service/sessionService/session.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, BrandedToastComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'trade-app-admin';
  readonly timeoutService = inject(SessionTimeoutService);
  private sessionService = inject(SessionService);

  ngOnInit() {
    if (this.sessionService.getToken()) {
      this.timeoutService.resetTimer();
    }
  }

  isPopupVisible() {
    const status = this.timeoutService.sessionStatus();
    return status === 'warning' || status === 'expired';
  }

  handleReset() {
    this.timeoutService.resetTimer();
  }

  handleLogout() {
    // This is called when user clicks "Back to Login" on expired toast
    this.timeoutService.redirectToLogin();
  }
}
