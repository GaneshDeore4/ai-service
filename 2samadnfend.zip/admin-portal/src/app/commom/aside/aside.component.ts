import { NgClass, NgFor, NgIf, NgTemplateOutlet } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { SharedService } from '../../service/sharedService/shared.service';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { SessionService } from '../../service/sessionService/session.service';
import { SUPERADMIN, BANKSUPERADMINMAKER, BANKSUPERADMINCHECKER, BANKSETUPMAKER, BANKSETUPCHECKER, MIDOFFICE, BANKBRANCHVERIFIER, BANKVIEWONLY } from '../../constants/Constants';

interface MenuItem {
  title: string;
  link: string;
  icon?: string;
  isActive: boolean;
  subMenu: MenuItem[];
  isDropdownOpen: boolean;
  hasDropdown: boolean;
  isSubMenu: boolean;
  parent?: MenuItem;
}

@Component({
  selector: 'app-aside',
  standalone: true,
  imports: [NgFor, NgIf, NgClass, NgTemplateOutlet, RouterModule],
  templateUrl: './aside.component.html',
  styleUrl: './aside.component.css'
})
export class AsideComponent implements OnInit, OnDestroy {
  activeItem: any;
  role: string = "";
  asideFull: boolean = true;
  menuItems: MenuItem[] = [];
  private subscriptions: Subscription = new Subscription();

  constructor(
    public router: Router,
    private sharedService: SharedService,
    private sessionService: SessionService
  ) {
    this.role = this.sessionService.getRole();
  }

  ngOnInit(): void {
    this.subscriptions.add(
      this.sharedService.asideFull$.subscribe(value => this.asideFull = value as boolean)
    );

    // Build the tree with precise role-based access
    this.initializeUnifiedMenu();

    // Sync state on navigation
    this.subscriptions.add(
      this.router.events.pipe(
        filter(event => event instanceof NavigationEnd)
      ).subscribe(() => {
        this.updateActiveState(this.menuItems);
      })
    );

    this.updateActiveState(this.menuItems);
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  // private initializeUnifiedMenu(): void {
  //   // Clone shared static base menu
  //   const rawBase = JSON.parse(JSON.stringify(this.sharedService.defaultMenuItems)) as MenuItem[];

  //   // Step 1: Assign children based on role and category
  //   rawBase.forEach(item => {
  //     if (item.title === 'Notifications') {
  //       const news = this.sharedService.newsMenuItems[0];
  //       item.subMenu = JSON.parse(JSON.stringify(news.subMenu || []));
  //     } else if (item.title === 'Setup') {
  //       item.link = ''; // Disable navigation to sf-landing
  //       // ADMIN roles see combined Setup (Bank + Customer + Master Maintenance)
  //       if (this.role === SUPERADMIN || this.role === BANKSUPERADMINCHECKER || this.role === BANKSUPERADMINMAKER || this.role === BANKSETUPMAKER || this.role === BANKSETUPCHECKER ) {
  //         let master = this.sharedService.systemFeaturesMenuForSA; // Master + Bank

  //         // Filter out Master Maintenance for everyone except SUPERADMIN
  //         if (this.role != SUPERADMIN && this.role != BANKSUPERADMINCHECKER && this.role != BANKSUPERADMINMAKER) {
  //           master = master.filter(m => m.title !== 'Master Maintenance');
  //         }


  //         const customer = this.sharedService.systemFeaturesMenuWOSA; // Customer
  //         item.subMenu = JSON.parse(JSON.stringify([...master, ...customer]));
  //       } else {
  //         // Others see only Customer Setup
  //         item.subMenu = JSON.parse(JSON.stringify(this.sharedService.systemFeaturesMenuWOSA));
  //       }
  //     } else if (item.title === 'Middle Office') {
  //       item.link = 'content/mo-landing'; // Disable navigation to mo-landing
  //       item.subMenu = JSON.parse(JSON.stringify(this.sharedService.middleOfficeMenu));
  //     }
  //     item.hasDropdown = item.subMenu && item.subMenu.length > 0;
  //   });

  //   // Step 2: Global Visibility Filtering (Who sees which main category)
  //   let filteredMenu: MenuItem[] = [];

  //   if (this.role === MIDOFFICE) {
  //     // MIDOFFICE role: "Only visible middle office"
  //     filteredMenu = rawBase.filter(item => item.title === 'Middle Office');
  //   } else if (this.role === SUPERADMIN) {
  //     // SUPERADMIN: Full access
  //     filteredMenu = rawBase;
  //   } else if (this.role === BANKSUPERADMINMAKER || this.role === BANKSUPERADMINCHECKER) {
  //     // ADMIN roles: Everything EXCEPT Middle Office
  //     filteredMenu = rawBase.filter(item => item.title !== 'Middle Office');
  //   } else {
  //     // OTHERS: Notifications, Setup (restricted), Audit, etc. BUT NO Middle Office
  //     filteredMenu = rawBase.filter(item => item.title !== 'Middle Office');
  //   }

  //   // Step 3: Set parent pointers for the filtered tree
  //   const setParents = (list: MenuItem[], parent?: MenuItem) => {
  //     list.forEach(i => {
  //       i.parent = parent;
  //       if (i.subMenu) setParents(i.subMenu, i);
  //     });
  //   };
  //   setParents(filteredMenu);

  //   this.menuItems = filteredMenu;
  // }

  private initializeUnifiedMenu(): void {
    const rawBase = JSON.parse(JSON.stringify(this.sharedService.defaultMenuItems)) as MenuItem[];
    rawBase.forEach(item => {
      if (item.title === 'Notifications') {
        const news = this.sharedService.newsMenuItems[0];
        item.subMenu = JSON.parse(JSON.stringify(news.subMenu || []));
      } else if (item.title === 'Setup') {
        item.link = ''; 
        if (this.role === SUPERADMIN || this.role === BANKSUPERADMINCHECKER || this.role === BANKSUPERADMINMAKER || this.role === BANKSETUPMAKER || this.role === BANKSETUPCHECKER) {
          const master = this.sharedService.systemFeaturesMenuForSA;
          const customer = this.sharedService.systemFeaturesMenuWOSA;
          let subItems = [];
          if (this.role === BANKSUPERADMINCHECKER || this.role === BANKSUPERADMINMAKER) {
            subItems = [...master, ...customer].filter(m => m.title !== 'Customer Setup');
          } else if (this.role === SUPERADMIN) {
            subItems = [...master, ...customer];
          } else {
            subItems = [...master.filter(m => m.title !== 'Master Maintenance'), ...customer];
          }
          item.subMenu = JSON.parse(JSON.stringify(subItems));
        } else {
          item.subMenu = JSON.parse(JSON.stringify(this.sharedService.systemFeaturesMenuWOSA));
        }
      } else if (item.title === 'Middle Office') {
        item.link = 'content/mo-landing'; 
        item.subMenu = JSON.parse(JSON.stringify(this.sharedService.middleOfficeMenu));
      }
      item.hasDropdown = item.subMenu && item.subMenu.length > 0;
    });
    let filteredMenu: MenuItem[] = [];
    if (this.role === BANKBRANCHVERIFIER) {
      filteredMenu = rawBase.filter(item => item.title === 'Middle Office');
    } else if (this.role === BANKSUPERADMINMAKER || this.role === BANKSUPERADMINCHECKER) {
      filteredMenu = rawBase.filter(item => item.title !== 'Middle Office');
    } else if (this.role === BANKBRANCHVERIFIER) {
      filteredMenu = rawBase.filter(item => item.title === 'Audit Trail' || item.title === 'Middle Office');
    } else if (this.role === BANKVIEWONLY) {
      filteredMenu = rawBase.filter(item => item.title === 'Notifications' || item.title === 'Audit Trail' || item.title === 'Middle Office');
    } else {
      filteredMenu = rawBase.filter(item => item.title !== 'Middle Office');
    }
    const setParents = (list: MenuItem[], parent?: MenuItem) => {
      list.forEach(i => {
        i.parent = parent;
        if (i.subMenu) setParents(i.subMenu, i);
      });
    };
    setParents(filteredMenu);
    this.menuItems = filteredMenu;
  }

  private findItemRecursive(url: string, items: MenuItem[]): { item: MenuItem, path: MenuItem[] } | null {
    const cleanUrl = url.split('?')[0].split('#')[0];
    for (const item of items) {
      if (item.link === cleanUrl) {
        return { item, path: [item] };
      }
      if (item.subMenu && item.subMenu.length > 0) {
        const found = this.findItemRecursive(url, item.subMenu);
        if (found) {
          return { item: found.item, path: [item, ...found.path] };
        }
      }
    }
    return null;
  }

  private updateActiveState(items: MenuItem[]): void {
    const currentUrl = this.router.url;
    const result = this.findItemRecursive(currentUrl, items);

    const resetAndSync = (menu: MenuItem[]) => {
      menu.forEach(i => {
        i.isActive = false;
        if (result && result.path.includes(i)) {
          i.isActive = true;
          // Auto-expand path to active item
          if (i.hasDropdown && i !== result.item) {
            i.isDropdownOpen = true;
          }
        }
        if (i.subMenu) resetAndSync(i.subMenu);
      });
    };

    resetAndSync(items);
    if (result) this.activeItem = result.item;
  }

  onClick(event: Event, item: MenuItem): void {
    if (item.hasDropdown) {
      this.toggleDropdown(item, event);
    } else if (item.link) {
      this.router.navigate([item.link]);
    }
  }

  toggleDropdown(item: MenuItem, event: Event) {
    event.stopPropagation();
    event.preventDefault();

    const willOpen = !item.isDropdownOpen;

    if (willOpen) {
      // Accordion: close siblings
      const parentList = item.parent ? item.parent.subMenu : this.menuItems;
      parentList.forEach(sibling => {
        if (sibling !== item) sibling.isDropdownOpen = false;
      });
    }

    item.isDropdownOpen = willOpen;

    // Auto-navigate to first child if opening and NOT already active in this branch
    if (willOpen && item.subMenu && item.subMenu.length > 0) {
      if (!this.router.url.startsWith(item.link)) {
        this.router.navigate([item.subMenu[0].link]);
      }
    }
  }

  toggleAside() {
    this.sharedService.toggleNavFull();
  }
}
