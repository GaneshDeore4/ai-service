import { SharedService } from './../../service/sharedService/shared.service';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { Component, ElementRef, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { SessionService } from '../../service/sessionService/session.service';
import { AuthService } from '../../service/auth.service';
import { FORCE_LOGOUT } from '../../constants/api_endpoints';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  showProfileMenu: boolean = false;
  loginUserName: string = 'User Name';
  lastLoginTime: string | null = 'Dec 3, 2025  10:30 AM';
  loginEmail:string='';
  role: string = '';

  constructor(
    private sharedService: SharedService,
    private router: Router,
    private sessionService: SessionService,
    private authService: AuthService,
    private eRef: ElementRef
  ) {
    this.role = sessionService.getRole();
    this.loginUserName = this.sessionService.getUsername();
    this.loginEmail = this.sessionService.getEmail();
    this.lastLoginTime = this.sessionService.getLastLogin()
  }

  toggleAside() {
    this.sharedService.toggleNavFull();
  }

  goHome() {
    this.sharedService.setDefaultMenuItems();
    this.router.navigate(['content/landing']);
  }

  toggleProfileMenu(event?: Event) {
    if (event) {
      event.stopPropagation();
    }
    this.showProfileMenu = !this.showProfileMenu;
    console.log('Profile menu toggled:', this.showProfileMenu);
  }

  @HostListener('document:click', ['$event'])
  clickout(event: any) {
    if (!this.eRef.nativeElement.contains(event.target)) {
      this.showProfileMenu = false;
    }
  }

  logout() {
    const payload = {
      cifOrAbbvName: this.sessionService.getCompanyName(),
      loginId: this.sessionService.getLoginId(),
    };
    this.authService.forceLogout(FORCE_LOGOUT, payload).subscribe({
      next: (response) => {
        console.log("logout response:" + JSON.stringify(response, null, 2));
        this.authService.logout();
      },
      error: (err) => {
        console.error('Login failed', JSON.stringify(err, null, 2));
      }
    });
  }
}
