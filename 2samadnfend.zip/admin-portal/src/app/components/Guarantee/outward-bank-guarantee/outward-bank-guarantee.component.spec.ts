import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardBankGuaranteeComponent } from './outward-bank-guarantee.component';

describe('OutwardBankGuaranteeComponent', () => {
  let component: OutwardBankGuaranteeComponent;
  let fixture: ComponentFixture<OutwardBankGuaranteeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OutwardBankGuaranteeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OutwardBankGuaranteeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
