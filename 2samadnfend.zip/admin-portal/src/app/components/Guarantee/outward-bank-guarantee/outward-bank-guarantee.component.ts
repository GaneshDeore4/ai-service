import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TableComponent } from '../../table/table.component';
import { TabsComponent } from '../../tabs/tabs.component';
import { HeaderComponent } from '../../header/header.component';

type TabName =
  | 'Draft'
  | 'Actions'
  | 'Pending Approval'
  | 'Pending at Bank'
  | 'Live'
  | 'Closed'
  | 'Rejected';

interface OutwardBankGuarantee {
  channelReference: string;
  customerReference: string;
  bankReference: string;
  issueDate: string;
  events: string;
  applicationName: string;
  beneficiary: string;
  currency: string;
  amount: string;
  outstandingAmount: string;
  expiryType: string;
  expiryDate: string;
  inputUser: string;
  controlUser: string;
  tab: TabName;
}

@Component({
  selector: 'app-outward-bank-guarantee',
  standalone: true,
  imports: [TableComponent, HeaderComponent, TabsComponent],
  templateUrl: './outward-bank-guarantee.component.html',
  styleUrls: ['../../../common css/inward-letter-of-credit.component.css'],
})
export class OutwardBankGuaranteeComponent implements OnInit {
  constructor(private router: Router) {}

  activeTab: TabName = 'Draft';
  tabs: { name: TabName; count: number }[] = [];
  columns = [
    { id: 'channelReference', label: 'Channel Reference', visible: true },
    { id: 'customerReference', label: 'Customer Reference', visible: false },
    { id: 'bankReference', label: 'Bank Reference', visible: true },
    { id: 'issueDate', label: 'Issue Date', visible: true },
    { id: 'events', label: 'Events', visible: true },
    { id: 'applicationName', label: 'Application Name', visible: true },
    { id: 'beneficiary', label: 'Beneficiary', visible: true },
    { id: 'currency', label: 'Currency', visible: true },
    { id: 'amount', label: 'Amount', visible: true },
    {
      id: 'outstandingAmount',
      label: 'Outstanding Amount',
      visible: true,
    },
    { id: 'expiryType', label: 'Expiry Type', visible: false },
    { id: 'expiryDate', label: 'Expiry Date', visible: false },
    { id: 'inputUser', label: 'Input User', visible: false },
    { id: 'controlUser', label: 'Control User', visible: false },
  ];

  records: OutwardBankGuarantee[] = [
    {
      channelReference: 'BG25110000100001',
      customerReference: 'CUST-8001',
      bankReference: 'BG-BK-01',
      issueDate: '02/11/2025',
      events: 'Issuance',
      applicationName: 'ABC Infra Projects',
      beneficiary: 'Metro Development Corp',
      currency: 'INR',
      amount: '₹25,00,000',
      outstandingAmount: '₹25,00,000',
      expiryType: 'Open-ended',
      expiryDate: '-',
      inputUser: 'userBG01',
      controlUser: 'ctrlBG01',
      tab: 'Pending Approval',
    },
    {
      channelReference: 'BG25100000100002',
      customerReference: 'CUST-8002',
      bankReference: 'BG-BK-02',
      issueDate: '29/10/2025',
      events: 'Draft Created',
      applicationName: 'Harbourline Logistics',
      beneficiary: 'Port Trust Authority',
      currency: 'USD',
      amount: '$80,000.00',
      outstandingAmount: '$80,000.00',
      expiryType: 'Fixed',
      expiryDate: '29/10/2026',
      inputUser: 'userBG02',
      controlUser: 'ctrlBG02',
      tab: 'Draft',
    },
    {
      channelReference: 'BG25090000100003',
      customerReference: 'CUST-8003',
      bankReference: 'BG-BK-03',
      issueDate: '15/09/2025',
      events: 'Pending Approval',
      applicationName: 'Silverline Engineering',
      beneficiary: 'State Highway Authority',
      currency: 'INR',
      amount: '₹48,50,000',
      outstandingAmount: '₹48,50,000',
      expiryType: 'Fixed',
      expiryDate: '15/09/2026',
      inputUser: 'userBG03',
      controlUser: 'ctrlBG03',
      tab: 'Pending Approval',
    },
    {
      channelReference: 'BG25080000100004',
      customerReference: 'CUST-8004',
      bankReference: 'BG-BK-04',
      issueDate: '05/08/2025',
      events: 'Sent to Bank',
      applicationName: 'Neptune Chemicals',
      beneficiary: 'Ocean Trade Corp',
      currency: 'EUR',
      amount: '€65,000',
      outstandingAmount: '€65,000',
      expiryType: 'Fixed',
      expiryDate: '05/08/2026',
      inputUser: 'userBG04',
      controlUser: 'ctrlBG04',
      tab: 'Pending at Bank',
    },
    {
      channelReference: 'BG25070000100005',
      customerReference: 'CUST-8005',
      bankReference: 'BG-BK-05',
      issueDate: '22/07/2025',
      events: 'Live',
      applicationName: 'Galaxy Textiles',
      beneficiary: 'Global Apparel Buyers',
      currency: 'USD',
      amount: '$120,000.00',
      outstandingAmount: '$120,000.00',
      expiryType: 'Fixed',
      expiryDate: '22/07/2026',
      inputUser: 'userBG05',
      controlUser: 'ctrlBG05',
      tab: 'Live',
    },
    {
      channelReference: 'BG25060000100006',
      customerReference: 'CUST-8006',
      bankReference: 'BG-BK-06',
      issueDate: '10/06/2025',
      events: 'Draft Updated',
      applicationName: 'Prime Metals Pvt Ltd',
      beneficiary: 'Steel Authority',
      currency: 'INR',
      amount: '₹32,75,000',
      outstandingAmount: '₹32,75,000',
      expiryType: 'Fixed',
      expiryDate: '10/06/2026',
      inputUser: 'userBG06',
      controlUser: 'ctrlBG06',
      tab: 'Draft',
    },
    {
      channelReference: 'BG25050000100007',
      customerReference: 'CUST-8007',
      bankReference: 'BG-BK-07',
      issueDate: '18/05/2025',
      events: 'Bank Queried',
      applicationName: 'Rising Sun Developers',
      beneficiary: 'Municipal Corporation',
      currency: 'INR',
      amount: '₹15,00,000',
      outstandingAmount: '₹15,00,000',
      expiryType: 'Open-ended',
      expiryDate: '-',
      inputUser: 'userBG07',
      controlUser: 'ctrlBG07',
      tab: 'Actions',
    },
    {
      channelReference: 'BG25040000100008',
      customerReference: 'CUST-8008',
      bankReference: 'BG-BK-08',
      issueDate: '02/04/2025',
      events: 'Closed',
      applicationName: 'Orchid Pharmaceuticals',
      beneficiary: 'Health Procurement Board',
      currency: 'USD',
      amount: '$40,000.00',
      outstandingAmount: '$0.00',
      expiryType: 'Fixed',
      expiryDate: '02/04/2025',
      inputUser: 'userBG08',
      controlUser: 'ctrlBG08',
      tab: 'Closed',
    },
    {
      channelReference: 'BG25030000100009',
      customerReference: 'CUST-8009',
      bankReference: 'BG-BK-09',
      issueDate: '10/03/2025',
      events: 'Rejected by Bank',
      applicationName: 'Everest Auto Components',
      beneficiary: 'Global Auto Corp',
      currency: 'EUR',
      amount: '€25,000',
      outstandingAmount: '€0',
      expiryType: 'Fixed',
      expiryDate: '10/03/2026',
      inputUser: 'userBG09',
      controlUser: 'ctrlBG09',
      tab: 'Rejected',
    },
    {
      channelReference: 'BG25020000100010',
      customerReference: 'CUST-8010',
      bankReference: 'BG-BK-10',
      issueDate: '25/02/2025',
      events: 'Live',
      applicationName: 'Crystal Foods Exports',
      beneficiary: 'Overseas Buyers Group',
      currency: 'USD',
      amount: '$75,000.00',
      outstandingAmount: '$75,000.00',
      expiryType: 'Fixed',
      expiryDate: '25/02/2026',
      inputUser: 'userBG10',
      controlUser: 'ctrlBG10',
      tab: 'Live',
    },
    {
      channelReference: 'BG25010000100011',
      customerReference: 'CUST-8011',
      bankReference: 'BG-BK-11',
      issueDate: '11/01/2025',
      events: 'Pending Approval',
      applicationName: 'Skyline Construction',
      beneficiary: 'Urban Infra Board',
      currency: 'INR',
      amount: '₹19,90,000',
      outstandingAmount: '₹19,90,000',
      expiryType: 'Fixed',
      expiryDate: '11/01/2026',
      inputUser: 'userBG11',
      controlUser: 'ctrlBG11',
      tab: 'Pending Approval',
    },
    {
      channelReference: 'BG24120000100012',
      customerReference: 'CUST-8012',
      bankReference: 'BG-BK-12',
      issueDate: '21/12/2024',
      events: 'Draft Created',
      applicationName: 'Delta Marine',
      beneficiary: 'Port & Harbour Authority',
      currency: 'USD',
      amount: '$55,000.00',
      outstandingAmount: '$55,000.00',
      expiryType: 'Fixed',
      expiryDate: '21/12/2025',
      inputUser: 'userBG12',
      controlUser: 'ctrlBG12',
      tab: 'Draft',
    },
    {
      channelReference: 'BG24110000100013',
      customerReference: 'CUST-8013',
      bankReference: 'BG-BK-13',
      issueDate: '05/11/2024',
      events: 'Sent to Bank',
      applicationName: 'Omega Power Systems',
      beneficiary: 'Energy Grid Corp',
      currency: 'INR',
      amount: '₹22,00,000',
      outstandingAmount: '₹22,00,000',
      expiryType: 'Fixed',
      expiryDate: '05/11/2025',
      inputUser: 'userBG13',
      controlUser: 'ctrlBG13',
      tab: 'Pending at Bank',
    },
    {
      channelReference: 'BG24100000100014',
      customerReference: 'CUST-8014',
      bankReference: 'BG-BK-14',
      issueDate: '12/10/2024',
      events: 'Bank Queried',
      applicationName: 'Zenith Retail',
      beneficiary: 'Mall Management Co.',
      currency: 'EUR',
      amount: '€18,000',
      outstandingAmount: '€18,000',
      expiryType: 'Fixed',
      expiryDate: '12/10/2025',
      inputUser: 'userBG14',
      controlUser: 'ctrlBG14',
      tab: 'Actions',
    },
    {
      channelReference: 'BG24090000100015',
      customerReference: 'CUST-8015',
      bankReference: 'BG-BK-15',
      issueDate: '01/09/2024',
      events: 'Closed',
      applicationName: 'Nova Engineering Works',
      beneficiary: 'Industrial Buyers League',
      currency: 'INR',
      amount: '₹10,00,000',
      outstandingAmount: '₹0',
      expiryType: 'Fixed',
      expiryDate: '01/09/2024',
      inputUser: 'userBG15',
      controlUser: 'ctrlBG15',
      tab: 'Closed',
    },
  ];

  ngOnInit(): void {
    this.buildTabsFromData();
  }

  private buildTabsFromData(): void {
    const tabNames: TabName[] = [
      'Draft',
      'Actions',
      'Pending Approval',
      'Pending at Bank',
      'Live',
      'Closed',
      'Rejected',
    ];

    const counts: Record<TabName, number> = {
      Draft: 0,
      Actions: 0,
      'Pending Approval': 0,
      'Pending at Bank': 0,
      Live: 0,
      Closed: 0,
      Rejected: 0,
    };

    for (const row of this.records) {
      counts[row.tab] = (counts[row.tab] || 0) + 1;
    }

    this.tabs = tabNames.map((name) => ({
      name,
      count: counts[name],
    }));

    if (!this.tabs.find((t) => t.name === this.activeTab)) {
      this.activeTab = 'Draft';
    }
  }

  get filteredRecords(): OutwardBankGuarantee[] {
    return this.records.filter((r) => r.tab === this.activeTab);
  }

  // onRowEdited(event: any) {
  //   const { oldRow, newRow } = event;
  //   const index = this.records.indexOf(oldRow);
  //   if (index !== -1) {
  //     this.records[index] = newRow;
  //     this.buildTabsFromData();
  //   }
  // }

  onRowView(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'view',

        title: 'Record Details',

        subtitle: 'View record in read-only mode',
      },
    });
  }

  onRowEdit(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'edit',

        title: 'Edit Record',

        subtitle: 'Update the selected record',
      },
    });
  }
  onRowDeleted(row: OutwardBankGuarantee) {
    this.records = this.records.filter((r) => r !== row);
    this.buildTabsFromData();

    const currentTabCount = this.tabs.find(
      (t) => t.name === this.activeTab
    )?.count;

    if (!currentTabCount) {
      const firstNonEmpty = this.tabs.find((t) => t.count > 0);
      if (firstNonEmpty) {
        this.activeTab = firstNonEmpty.name;
      }
    }
  }

  requestBankGuarantee() {
    this.router.navigate(['/guarantee/outward-bank-guarantee/request']);
  }

  openTemplates() {
    this.router.navigate(['guarantee/outward-bank-guarantee/templates']);
  }
}
