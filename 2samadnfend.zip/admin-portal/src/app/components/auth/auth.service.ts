import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private isLoggedInFlag = false;
  private isBrowser = false;

  constructor(@Inject(PLATFORM_ID) platformId: Object) {
    this.isBrowser = isPlatformBrowser(platformId);

    if (this.isBrowser) {
      const persisted = localStorage.getItem('loggedIn');
      this.isLoggedInFlag = persisted === 'true';
    }
  }

  login(credentials: { userId: string; password: string; captcha: string }): boolean {
    if (
      credentials.userId === 'admin' &&
      credentials.password === 'admin' &&
      credentials.captcha.trim().length > 0
    ) {
      this.isLoggedInFlag = true;

      if (this.isBrowser) {
        localStorage.setItem('loggedIn', 'true');
      }

      return true;
    }

    return false;
  }

  logout() {
    this.isLoggedInFlag = false;

    if (this.isBrowser) {
      localStorage.removeItem('loggedIn');
    }
  }

  isLoggedIn(): boolean {
    if (this.isBrowser) {
      return this.isLoggedInFlag || localStorage.getItem('loggedIn') === 'true';
    }
    return false;
  }
}