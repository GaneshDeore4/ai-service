import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingEntitiesComponent } from './pending-entities.component';

describe('PendingEntitiesComponent', () => {
  let component: PendingEntitiesComponent;
  let fixture: ComponentFixture<PendingEntitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PendingEntitiesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingEntitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
