import { Component, input, output, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-branded-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div *ngIf="visible()" class="fixed inset-0 z-[9998] bg-black/40 backdrop-blur-sm"></div>

    <div *ngIf="visible()" class="fixed inset-0 z-[9999] flex items-center justify-center p-4">
      <div class="max-w-sm w-full bg-white shadow-2xl rounded-2xl border-t-8 border-[#91261e] overflow-hidden flex flex-col transform animate-scale-in">

        <div class="p-8 text-center">
          <div class="inline-flex items-center justify-center w-16 h-16 rounded-full mb-4"
               [ngClass]="status() === 'warning' ? 'bg-red-50' : 'bg-gray-100'">
            <i class="fas text-3xl"
               [ngClass]="status() === 'warning' ? 'fa-clock text-[#91261e]' : 'fa-lock text-gray-500'"></i>
          </div>

          <h3 class="text-xl font-bold text-[#91261e] uppercase tracking-wider mb-2">
            {{ status() === 'warning' ? 'Session Timeout Alert' : 'Session Expired' }}
          </h3>

          <p class="text-gray-600 text-md leading-relaxed">
            {{ status() === 'warning'
               ? 'Your session is about to expire for security reasons.'
               : 'For your security, you have been logged out due to inactivity.' }}
          </p>

          <div *ngIf="status() === 'warning'" class="mt-4 mb-2">
             <span class="text-gray-400 text-xs uppercase font-semibold tracking-tighter">Expires in</span>
             <div class="text-4xl font-mono font-bold text-[#f58220] tabular-nums mt-1 animate-pulse">
               {{ countdown() }}s
             </div>
          </div>
        </div>

        <div class="p-4 bg-gray-50 border-t border-gray-100">
          <button *ngIf="status() === 'warning'" (click)="onReset.emit()"
            class="w-full py-4 text-sm font-bold bg-[#91261e] text-white hover:bg-[#7a1f23] rounded-xl shadow-lg transition-all uppercase">
            Stay Logged In
          </button>

          <button *ngIf="status() === 'expired'" (click)="onLogout.emit()"
            class="w-full py-4 text-sm font-bold bg-gray-800 text-white hover:bg-black rounded-xl shadow-lg transition-all uppercase">
            Back to Login
          </button>
        </div>

        <div *ngIf="status() === 'warning'" class="h-1.5 bg-gray-100">
          <div class="h-full bg-[#f58220] transition-all duration-1000 ease-linear" [style.width.%]="progress()"></div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .animate-scale-in { animation: scaleIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1) forwards; }
    @keyframes scaleIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
  `]
})
export class BrandedToastComponent {
  visible = input<boolean>(false);
  status = input<string>('active');
  countdown = input<number>(30);
  totalTime = input<number>(30);

  onReset = output<void>();
  onLogout = output<void>();

  progress = computed(() => (this.countdown() / this.totalTime()) * 100);
}
