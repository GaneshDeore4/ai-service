import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FooterComponent } from '../../commom/footer/footer.component';
import { DASHBOARD_STATS, FORGOT_PASSWORD } from '../../constants/api_endpoints';
import { ApiService } from '../../service/apiService/api.service';
import { SessionService } from '../../service/sessionService/session.service';
import { FormsModule } from '@angular/forms';
import { ToastComponent } from "../../commom/toast/toast.component";

@Component({
  selector: 'app-landing',
  imports: [FooterComponent, FormsModule, NgIf, ToastComponent],
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.css',
})
export class LandingComponent {
  constructor(private router: Router, private apiService: ApiService, private sessionService: SessionService) {
    // if (sessionService.getIsFirstLoginFlag())
    //   this.changePassPopup = true;
  }
  ngOnInit() {
    this.getDashboardStats();
    for (let index = 0; index < 100; index++) {
      this.rows1.push({
        'Channel Reference': 'CH-001',
        Type: 'Email',
        Date: '2025-11-11',
        Issuer: 'ABC Corp',
        Description: 'Initial contact made.',
      });
    }
  }

  getDashboardStats() {
    this.apiService.getData(DASHBOARD_STATS, {}).subscribe({
      next: (res) => {
        if (res.status === 'SUCCESS') {
          const stats = res.payload;
          this.customerCount = stats.totalCustomers;
          this.bankUsersCount = stats.totalBankUsers;
          this.usersCount = stats.totalCustomerUsers;
        }
      },
      error: (err) => {
        console.error('Failed to fetch dashboard stats', err);
      }
    });
  }
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  isHidden = true;
  toggleBox() {
    this.isHidden = !this.isHidden;
  }

  // --------------------new data------------------
  newsList = [
    {
      img: 'images/media.png',
      title: 'New Security Module',
      desc: 'System iIntroduced an advanced security module to enhance data protection and compliance. The update includes multi-factor authentication and real-time audit tracking.',
    },
    {
      img: 'images/media.png',
      title: 'System Maintenance Scheduled for December 15',
      desc: 'A planned maintenance window will occur on December 15 from 12:00 AM to 4:00 AM IST. Users may experience temporary downtime during this period.',
    },
    {
      img: 'images/media.png',
      title: 'New Dashboard Features Rolled Out',
      desc: 'The latest update brings improved analytics and customizable widgets to the dashboard, helping users monitor tasks and approvals more efficiently.',
    },
  ];
  // --------------------new data------------------

  // -------------------ongoing tasks start---------------
  headers1 = ['Channel Reference', 'Type', 'Date', 'Issuer', 'Description'];
  columnWidths1 = [
    '20%', // Channel Reference
    '15%', // Type
    '20%', // Date
    '25%', // Issuer
    '20%', // Description
  ];
  rows1 = [
    {
      'Channel Reference': 'CH-001',
      Type: 'Email',
      Date: '2025-11-11',
      Issuer: 'ABC Corp',
      Description: 'Initial contact made.',
    },
    {
      'Channel Reference': 'CH-002',
      Type: 'Call',
      Date: '2025-11-10',
      Issuer: 'XYZ Ltd',
      Description: 'Follow-up discussion',
    },
  ];

  // -------------------ongoing tasks end---------------

  // box data
  ongoingTaskNum = 0;
  recentApplicationsNum = 15;
  companyPendingApprovalNum = 10;
  entityPendingApprovalNum = 42;
  authPendingApproval = 24;
  userPendingApproval = 18;
  userAccountPendingNum = 25;
  customerCount = 15;
  draftCount = 0;
  usersCount = 18;
  bankUsersCount = 231;

  goToList(pageName: string) {
    let route = `/content/${pageName}`;
    this.router.navigate([route], { queryParams: { status: 'dashboard' } });
  }


  //RESET PASS LOGIC
  password = '';
  confirmPassword = '';
  passwordError = false;
  passwordErrorMsg = '';
  changePassPopup = false;

  passwordValidator(): boolean {
    this.passwordError = false;
    this.passwordErrorMsg = '';
    if (this.password != this.confirmPassword) {
      this.passwordError = true;
      this.passwordErrorMsg = 'Passwords do not match';
      return false;
    }
    if (this.password.length < 8) {
      this.passwordError = true;
      this.passwordErrorMsg = 'Password length';
      return false;
    }
    return true;
  }
  resetPassword() {
    if (!this.passwordValidator())
      return;
    const data = {
      userId: this.sessionService.getUserId(),
      newPassword: this.password,
      afterLogin: true,
      bankAbbvName: this.sessionService.getCompanyId(),
    }

    this.apiService.sendData(FORGOT_PASSWORD, data).subscribe({
      next: (res) => {
        if (res.status == "SUCCESS") {
          this.showToast('success', 'Success', 'Password Changed Successfully');
          this.sessionService.setIsFirstLoginFlag(false);
        } else {
          this.showToast('error', 'Error', res.description);
        }
      },
      error: (err) => {
        this.showToast('error', 'Error', 'Something went wrong');
      },
      complete: () => {
        this.changePassPopup = false;
      }
    });
  }
}
