import { Component, OnInit } from '@angular/core';

import { TableComponent } from '../../table/table.component';

import { HeaderComponent } from '../../header/header.component';

import { TabsComponent } from '../../tabs/tabs.component';

 import { Router } from '@angular/router';

interface LetterOfCredit {
  channelRef: string;

  customerRef: string;

  bankRef: string;

  status: string;

  issueDate: string;

  applicantName: string;

  currency: string;

  amount: string;

  outstandingAmount: string;

  tab: string;
}

@Component({
  selector: 'app-inward-letter-of-credit',

  standalone: true,

  imports: [TableComponent, HeaderComponent, TabsComponent],

  templateUrl: './inward-letter-of-credit.component.html',

  styleUrls: ['../../../common css/inward-letter-of-credit.component.css'],
})
export class InwardLetterOfCreditComponent implements OnInit {
  constructor(private router: Router) {}

  activeTab = 'Live';

  columns = [
    { id: 'channelRef', label: 'Channel Reference', visible: true },

    { id: 'customerRef', label: 'Customer Reference', visible: false },

    { id: 'bankRef', label: 'Bank Reference', visible: true },

    { id: 'status', label: 'Status', visible: true },

    { id: 'issueDate', label: 'Issue Date', visible: true },

    { id: 'applicantName', label: 'Applicant Name', visible: true },

    { id: 'currency', label: 'Currency', visible: true },

    { id: 'amount', label: 'Amount', visible: true },

    { id: 'outstandingAmount', label: 'Outstanding Amount', visible: true },
  ];

  tabs: { name: string; count: number }[] = [];

  letters: LetterOfCredit[] = [
    {
      channelRef: 'EL25100000105426',

      customerRef: '-',

      bankRef: 'BB-001',

      status: 'New',

      issueDate: '30/10/2025',

      applicantName: 'Test A',

      currency: 'INR',

      amount: '₹10.00',

      outstandingAmount: '₹1',

      tab: 'Live',
    },

    {
      channelRef: 'EL25090000103489',

      customerRef: '-',

      bankRef: 'BB-002',

      status: 'New',

      issueDate: '22/09/2025',

      applicantName: 'Test B',

      currency: 'USD',

      amount: '$2,000.00',

      outstandingAmount: '$2,000.00',

      tab: 'Live',
    },

    {
      channelRef: 'EL25090000103483',

      customerRef: '-',

      bankRef: 'ILC0001250066816',

      status: 'Advice',

      issueDate: '03/06/2025',

      applicantName: 'NEHA SETH',

      currency: 'USD',

      amount: '$2,000.00',

      outstandingAmount: '$2,000.00',

      tab: 'Live',
    },

    {
      channelRef: 'EL25090000103476',

      customerRef: '-',

      bankRef: 'BB-004',

      status: 'New',

      issueDate: '22/09/2025',

      applicantName: 'Test C',

      currency: 'USD',

      amount: '$2,000.00',

      outstandingAmount: '$2,000.00',

      tab: 'Live',
    },

    {
      channelRef: 'EL25070000100753',

      customerRef: '-',

      bankRef: 'ILC0001250066756',

      status: 'Advice',

      issueDate: '28/05/2025',

      applicantName: 'KUNAL',

      currency: 'INR',

      amount: '₹500.00',

      outstandingAmount: '₹500.00',

      tab: 'Live',
    },

    {
      channelRef: 'EL25040000099962',

      customerRef: 'ILC0001230039092-DPR001',

      bankRef: 'ILC0001230039092',

      status: 'Printed',

      issueDate: '-',

      applicantName: '-',

      currency: 'USD',

      amount: '$100.00',

      outstandingAmount: '$100.00',

      tab: 'Pending at Bank',
    },

    // more rows (same data as you gave, each with tab):

    {
      channelRef: 'EL25030000090001',

      customerRef: 'CUST-101',

      bankRef: 'BB-010',

      status: 'Open',

      issueDate: '15/03/2025',

      applicantName: 'Alpha Co',

      currency: 'USD',

      amount: '$5,000.00',

      outstandingAmount: '$1,000.00',

      tab: 'Live',
    },

    {
      channelRef: 'EL25030000090002',

      customerRef: 'CUST-102',

      bankRef: 'BB-011',

      status: 'Closed',

      issueDate: '10/02/2025',

      applicantName: 'Beta Co',

      currency: 'EUR',

      amount: '€3,200.00',

      outstandingAmount: '€0.00',

      tab: 'Closed',
    },

    {
      channelRef: 'EL25030000090003',

      customerRef: 'CUST-103',

      bankRef: 'BB-012',

      status: 'Pending',

      issueDate: '01/01/2025',

      applicantName: 'Gamma Ltd',

      currency: 'INR',

      amount: '₹120,000',

      outstandingAmount: '₹50,000',

      tab: 'Pending Approval',
    },

    {
      channelRef: 'EL25030000090004',

      customerRef: 'CUST-104',

      bankRef: 'BB-013',

      status: 'Expired',

      issueDate: '12/12/2024',

      applicantName: 'Delta LLC',

      currency: 'GBP',

      amount: '£10,000',

      outstandingAmount: '£10,000',

      tab: 'Pending at Bank',
    },

    {
      channelRef: 'EL25030000090005',

      customerRef: 'CUST-105',

      bankRef: 'BB-014',

      status: 'Open',

      issueDate: '05/11/2024',

      applicantName: 'Epsilon',

      currency: 'USD',

      amount: '$7,500.00',

      outstandingAmount: '$2,500.00',

      tab: 'Live',
    },

    {
      channelRef: 'EL25030000090006',

      customerRef: 'CUST-106',

      bankRef: 'BB-015',

      status: 'Printed',

      issueDate: '21/10/2024',

      applicantName: 'Zeta Trade',

      currency: 'INR',

      amount: '₹9,500',

      outstandingAmount: '₹9,500',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090007',

      customerRef: 'CUST-107',

      bankRef: 'BB-016',

      status: 'Advice',

      issueDate: '10/09/2024',

      applicantName: 'Eta Export',

      currency: 'EUR',

      amount: '€2,400.00',

      outstandingAmount: '€2,400.00',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090008',

      customerRef: 'CUST-108',

      bankRef: 'BB-017',

      status: 'New',

      issueDate: '01/08/2024',

      applicantName: 'Theta',

      currency: 'USD',

      amount: '$11,000.00',

      outstandingAmount: '$11,000.00',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090009',

      customerRef: 'CUST-109',

      bankRef: 'BB-018',

      status: 'Pending',

      issueDate: '31/07/2024',

      applicantName: 'Iota Ind',

      currency: 'INR',

      amount: '₹45,000',

      outstandingAmount: '₹5,000',

      tab: 'Pending Approval',
    },

    {
      channelRef: 'EL25030000090010',

      customerRef: 'CUST-110',

      bankRef: 'BB-019',

      status: 'New',

      issueDate: '20/06/2024',

      applicantName: 'Kappa Mfg',

      currency: 'USD',

      amount: '$2,200.00',

      outstandingAmount: '$2,200.00',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090011',

      customerRef: 'CUST-111',

      bankRef: 'BB-020',

      status: 'Open',

      issueDate: '15/05/2024',

      applicantName: 'Lambda',

      currency: 'INR',

      amount: '₹30,000',

      outstandingAmount: '₹8,000',

      tab: 'Closed',
    },

    {
      channelRef: 'EL25030000090012',

      customerRef: 'CUST-112',

      bankRef: 'BB-021',

      status: 'Closed',

      issueDate: '12/04/2024',

      applicantName: 'Mu Traders',

      currency: 'USD',

      amount: '$900.00',

      outstandingAmount: '$0.00',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090013',

      customerRef: 'CUST-113',

      bankRef: 'BB-022',

      status: 'Printed',

      issueDate: '01/04/2024',

      applicantName: 'Nu Services',

      currency: 'GBP',

      amount: '£2,500',

      outstandingAmount: '£2,500',

      tab: 'Actions',
    },

    {
      channelRef: 'EL25030000090014',

      customerRef: 'CUST-114',

      bankRef: 'BB-023',

      status: 'Advice',

      issueDate: '22/03/2024',

      applicantName: 'Xi Logistics',

      currency: 'INR',

      amount: '₹6,000',

      outstandingAmount: '₹6,000',

      tab: 'Actions',
    },

    {
      channelRef: 'EL25030000090015',

      customerRef: 'CUST-115',

      bankRef: 'BB-024',

      status: 'Pending',

      issueDate: '10/03/2024',

      applicantName: 'Omicron',

      currency: 'USD',

      amount: '$4,400.00',

      outstandingAmount: '$1,200.00',

      tab: 'Pending Approval',
    },

    {
      channelRef: 'EL25030000090016',

      customerRef: 'CUST-116',

      bankRef: 'BB-025',

      status: 'New',

      issueDate: '28/02/2024',

      applicantName: 'Pi Ins',

      currency: 'EUR',

      amount: '€1,500',

      outstandingAmount: '€1,500',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090017',

      customerRef: 'CUST-117',

      bankRef: 'BB-026',

      status: 'Open',

      issueDate: '14/02/2024',

      applicantName: 'Rho Exports',

      currency: 'INR',

      amount: '₹80,000',

      outstandingAmount: '₹20,000',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090018',

      customerRef: 'CUST-118',

      bankRef: 'BB-027',

      status: 'Closed',

      issueDate: '01/02/2024',

      applicantName: 'Sigma Corp',

      currency: 'USD',

      amount: '$12,000.00',

      outstandingAmount: '$0.00',

      tab: 'Closed',
    },

    {
      channelRef: 'EL25030000090019',

      customerRef: 'CUST-119',

      bankRef: 'BB-028',

      status: 'Advice',

      issueDate: '20/01/2024',

      applicantName: 'Tau Ltd',

      currency: 'INR',

      amount: '₹2,300',

      outstandingAmount: '₹2,300',

      tab: 'Live',
    },

    {
      channelRef: 'EL25030000090020',

      customerRef: 'CUST-120',

      bankRef: 'BB-029',

      status: 'Printed',

      issueDate: '11/01/2024',

      applicantName: 'Upsilon',

      currency: 'USD',

      amount: '$700.00',

      outstandingAmount: '$700.00',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090021',

      customerRef: 'CUST-121',

      bankRef: 'BB-030',

      status: 'New',

      issueDate: '01/01/2024',

      applicantName: 'Phi Traders',

      currency: 'EUR',

      amount: '€8,000',

      outstandingAmount: '€3,000',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090022',

      customerRef: 'CUST-122',

      bankRef: 'BB-031',

      status: 'Open',

      issueDate: '21/12/2023',

      applicantName: 'Chi Solutions',

      currency: 'INR',

      amount: '₹14,500',

      outstandingAmount: '₹4,500',

      tab: 'Closed',
    },

    {
      channelRef: 'EL25030000090023',

      customerRef: 'CUST-123',

      bankRef: 'BB-032',

      status: 'Pending',

      issueDate: '12/12/2023',

      applicantName: 'Psi Works',

      currency: 'USD',

      amount: '$3,300.00',

      outstandingAmount: '$3,300.00',

      tab: 'Live',
    },

    {
      channelRef: 'EL25030000090024',

      customerRef: 'CUST-124',

      bankRef: 'BB-033',

      status: 'Closed',

      issueDate: '05/12/2023',

      applicantName: 'Omega Inc',

      currency: 'GBP',

      amount: '£5,000',

      outstandingAmount: '£0.00',

      tab: 'Closed',
    },

    {
      channelRef: 'EL25030000090025',

      customerRef: 'CUST-125',

      bankRef: 'BB-034',

      status: 'Advice',

      issueDate: '30/11/2023',

      applicantName: 'A1 Exports',

      currency: 'INR',

      amount: '₹25,000',

      outstandingAmount: '₹10,000',

      tab: 'Pending at Bank',
    },

    {
      channelRef: 'EL25030000090026',

      customerRef: 'CUST-126',

      bankRef: 'BB-035',

      status: 'New',

      issueDate: '18/11/2023',

      applicantName: 'B2 Imports',

      currency: 'USD',

      amount: '$9,500.00',

      outstandingAmount: '$2,500.00',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090027',

      customerRef: 'CUST-127',

      bankRef: 'BB-036',

      status: 'Printed',

      issueDate: '10/11/2023',

      applicantName: 'C3 Trade',

      currency: 'INR',

      amount: '₹7,750',

      outstandingAmount: '₹7,750',

      tab: 'Pending at Bank',
    },

    {
      channelRef: 'EL25030000090028',

      customerRef: 'CUST-128',

      bankRef: 'BB-037',

      status: 'Open',

      issueDate: '01/11/2023',

      applicantName: 'D4 Logistics',

      currency: 'EUR',

      amount: '€6,500',

      outstandingAmount: '€1,500',

      tab: 'Rejected',
    },

    {
      channelRef: 'EL25030000090029',

      customerRef: 'CUST-129',

      bankRef: 'BB-038',

      status: 'Pending',

      issueDate: '20/10/2023',

      applicantName: 'E5 Solutions',

      currency: 'USD',

      amount: '$1,200.00',

      outstandingAmount: '$1,200.00',

      tab: 'Draft',
    },

    {
      channelRef: 'EL25030000090030',

      customerRef: 'CUST-130',

      bankRef: 'BB-039',

      status: 'Expired',

      issueDate: '10/10/2023',

      applicantName: 'F6 Manufacturing',

      currency: 'INR',

      amount: '₹55,000',

      outstandingAmount: '₹55,000',

      tab: 'Closed',
    },
  ];

  ngOnInit(): void {
    this.generateTabs();
  }

  /** Build tabs (name + count) from the data itself */

  private generateTabs() {
    const counts: Record<string, number> = {};

    for (const row of this.letters) {
      if (!row.tab) continue;

      counts[row.tab] = (counts[row.tab] || 0) + 1;
    }

    const order = [
      'Live',

      'Draft',

      'Actions',

      'Pending Approval',

      'Pending at Bank',

      'Rejected',

      'Closed',
    ];

    this.tabs = order

      .filter((name) => counts[name] !== undefined)

      .map((name) => ({
        name,

        count: counts[name],
      }));

    if (!this.tabs.find((t) => t.name === this.activeTab) && this.tabs.length) {
      this.activeTab = this.tabs[0].name;
    }
  }

  // onRowEdited(event: { oldRow: LetterOfCredit; newRow: LetterOfCredit }) {
  //   const { oldRow, newRow } = event;

  //   const index = this.letters.indexOf(oldRow);

  //   if (index !== -1) {
  //     this.letters[index] = newRow;

  //     this.generateTabs();
  //   }
  // }

  onRowView(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'view',

        title: 'Record Details',

        subtitle: 'View record in read-only mode',
      },
    });
  }

  onRowEdit(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'edit',

        title: 'Edit Record',

        subtitle: 'Update the selected record',
      },
    });
  }

  onRowDeleted(row: LetterOfCredit) {
    this.letters = this.letters.filter((l) => l !== row);

    this.generateTabs();
  }

  get filteredLetters(): LetterOfCredit[] {
    if (!this.activeTab) return this.letters;

    return this.letters.filter((row) => row.tab === this.activeTab);
  }
}
