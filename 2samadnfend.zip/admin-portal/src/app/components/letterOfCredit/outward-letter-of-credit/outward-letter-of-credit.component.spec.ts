import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardLetterOfCreditComponent } from './outward-letter-of-credit.component';

describe('OutwardLetterOfCreditComponent', () => {
  let component: OutwardLetterOfCreditComponent;
  let fixture: ComponentFixture<OutwardLetterOfCreditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OutwardLetterOfCreditComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OutwardLetterOfCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
