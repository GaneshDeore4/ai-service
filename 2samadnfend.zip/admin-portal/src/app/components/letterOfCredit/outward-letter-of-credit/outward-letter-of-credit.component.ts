import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { TableComponent } from '../../table/table.component';

import { HeaderComponent } from '../../header/header.component';

import { TabsComponent } from '../../tabs/tabs.component';
import { NgClass, NgIf } from '@angular/common';

interface LetterOfCredit {
  channelRef: string;

  customerRef: string;

  bankRef: string;

  status: string;

  issueDate: string;

  applicantName: string;

  currency: string;

  amount: string;

  outstandingAmount: string;

  tab: string;
}

interface LcTab {
  name: string;

  count: number;
}

@Component({
  selector: 'app-outward-letter-of-credit',

  standalone: true,

  imports: [TableComponent, HeaderComponent, TabsComponent, NgIf, NgClass],

  templateUrl: './outward-letter-of-credit.component.html',

  styleUrls: ['../../../common css/inward-letter-of-credit.component.css'],
})
export class OutwardLetterOfCreditComponent implements OnInit {
  constructor(private router: Router) {}

  toastVisible = false;

  toastHiding = false;

  toastMessage = '';

  toastType: 'success' | 'error' = 'success';

  activeTab = 'Live';

  tabs: LcTab[] = [];

  // 🔹 NEW: columns config for the reusable table

  columns = [
    { id: 'channelRef', label: 'Channel Reference', visible: true },

    { id: 'customerRef', label: 'Customer Reference', visible: false },

    { id: 'bankRef', label: 'Bank Reference', visible: true },

    { id: 'status', label: 'Status', visible: true },

    { id: 'issueDate', label: 'Issue Date', visible: true },

    { id: 'applicantName', label: 'Applicant Name', visible: true },

    { id: 'currency', label: 'Currency', visible: true },

    { id: 'amount', label: 'Amount', visible: true },

    { id: 'outstandingAmount', label: 'Outstanding Amount', visible: true },

    { id: 'tab', label: 'Tab', visible: false }, // optional
  ];

  letters: LetterOfCredit[] = [
    {
      channelRef: 'OW25110000110001',

      customerRef: 'CUST-501',

      bankRef: 'OB-101',

      status: 'Issued',

      issueDate: '01/11/2025',

      applicantName: 'Riverton Exports',

      currency: 'USD',

      amount: '$25,000.00',

      outstandingAmount: '$10,000.00',

      tab: 'Live',
    },

    {
      channelRef: 'OW25110000110002',

      customerRef: 'CUST-502',

      bankRef: 'OB-102',

      status: 'Issued',

      issueDate: '28/10/2025',

      applicantName: 'Lakshmi Textiles',

      currency: 'INR',

      amount: '₹1,200,000',

      outstandingAmount: '₹600,000',

      tab: 'Live',
    },

    {
      channelRef: 'OW25100000110011',

      customerRef: 'CUST-511',

      bankRef: 'OB-111',

      status: 'Open',

      issueDate: '10/10/2025',

      applicantName: 'Vertex Auto Parts',

      currency: 'USD',

      amount: '$15,400.00',

      outstandingAmount: '$15,400.00',

      tab: 'Live',
    },

    {
      channelRef: 'OW25090000110012',

      customerRef: 'CUST-512',

      bankRef: 'OB-112',

      status: 'Issued',

      issueDate: '05/09/2025',

      applicantName: 'Blue Ocean Foods',

      currency: 'EUR',

      amount: '€19,250.00',

      outstandingAmount: '€9,000.00',

      tab: 'Live',
    },

    // DRAFT

    {
      channelRef: 'OWD25110000120001',

      customerRef: 'CUST-601',

      bankRef: 'OB-201',

      status: 'Draft',

      issueDate: '02/11/2025',

      applicantName: 'Metro Plastics',

      currency: 'USD',

      amount: '$9,500.00',

      outstandingAmount: '$9,500.00',

      tab: 'Draft',
    },

    {
      channelRef: 'OWD25100000120002',

      customerRef: 'CUST-602',

      bankRef: 'OB-202',

      status: 'Draft',

      issueDate: '21/10/2025',

      applicantName: 'Silverline Textiles',

      currency: 'INR',

      amount: '₹850,000',

      outstandingAmount: '₹850,000',

      tab: 'Draft',
    },

    {
      channelRef: 'OWD25090000120003',

      customerRef: 'CUST-603',

      bankRef: 'OB-203',

      status: 'Draft',

      issueDate: '18/09/2025',

      applicantName: 'Pacific Agro',

      currency: 'USD',

      amount: '$31,700.00',

      outstandingAmount: '$31,700.00',

      tab: 'Draft',
    },

    // ACTIONS

    {
      channelRef: 'OWA25090000130001',

      customerRef: 'CUST-701',

      bankRef: 'OB-301',

      status: 'Amendment Required',

      issueDate: '19/09/2025',

      applicantName: 'Karan Traders',

      currency: 'EUR',

      amount: '€12,000',

      outstandingAmount: '€12,000',

      tab: 'Actions',
    },

    // PENDING APPROVAL

    {
      channelRef: 'OWP25100000140001',

      customerRef: 'CUST-801',

      bankRef: 'OB-401',

      status: 'Pending Approval',

      issueDate: '09/10/2025',

      applicantName: 'Nova Components',

      currency: 'USD',

      amount: '$4,500.00',

      outstandingAmount: '$4,500.00',

      tab: 'Pending Approval',
    },

    {
      channelRef: 'OWP25090000140002',

      customerRef: 'CUST-802',

      bankRef: 'OB-402',

      status: 'Pending Approval',

      issueDate: '25/09/2025',

      applicantName: 'AquaMarine',

      currency: 'USD',

      amount: '$18,750.00',

      outstandingAmount: '$18,750.00',

      tab: 'Pending Approval',
    },

    // PENDING AT BANK

    {
      channelRef: 'OWB25080000150001',

      customerRef: 'CUST-901',

      bankRef: 'OB-501',

      status: 'Pending at Bank',

      issueDate: '10/08/2025',

      applicantName: 'Sunrise Furnishings',

      currency: 'GBP',

      amount: '£6,800',

      outstandingAmount: '£6,800',

      tab: 'Pending at Bank',
    },

    {
      channelRef: 'OWB25070000150002',

      customerRef: 'CUST-902',

      bankRef: 'OB-502',

      status: 'Pending at Bank',

      issueDate: '02/07/2025',

      applicantName: 'GreenField Agro',

      currency: 'INR',

      amount: '₹350,000',

      outstandingAmount: '₹350,000',

      tab: 'Pending at Bank',
    },

    {
      channelRef: 'OWB25060000150003',

      customerRef: 'CUST-903',

      bankRef: 'OB-503',

      status: 'Pending at Bank',

      issueDate: '15/06/2025',

      applicantName: 'Atlas Electronics',

      currency: 'USD',

      amount: '$52,000.00',

      outstandingAmount: '$20,000.00',

      tab: 'Pending at Bank',
    },

    // REJECTED

    {
      channelRef: 'OWR25050000160001',

      customerRef: 'CUST-1001',

      bankRef: 'OB-601',

      status: 'Rejected',

      issueDate: '23/05/2025',

      applicantName: 'Orchid Pharma',

      currency: 'INR',

      amount: '₹2,500,000',

      outstandingAmount: '₹2,500,000',

      tab: 'Rejected',
    },

    // CLOSED

    {
      channelRef: 'OWC25040000170001',

      customerRef: 'CUST-1101',

      bankRef: 'OB-701',

      status: 'Closed',

      issueDate: '05/04/2025',

      applicantName: 'Stellar Metals',

      currency: 'USD',

      amount: '$8,600.00',

      outstandingAmount: '$0.00',

      tab: 'Closed',
    },

    {
      channelRef: 'OWC25030000170002',

      customerRef: 'CUST-1102',

      bankRef: 'OB-702',

      status: 'Closed',

      issueDate: '12/03/2025',

      applicantName: 'Atlas Electronics',

      currency: 'USD',

      amount: '$12,300.00',

      outstandingAmount: '$0.00',

      tab: 'Closed',
    },
  ];

  showToast(
    message: string,
    type: 'success' | 'error' = 'success',
    duration = 2000
  ) {
    this.toastMessage = message;

    this.toastType = type;

    this.toastVisible = true;

    this.toastHiding = false;

    setTimeout(() => {
      this.toastHiding = true;

      setTimeout(() => {
        this.toastVisible = false;

        this.toastHiding = false;
      }, 220);
    }, duration);
  }

  // ngOnInit(): void {
  //   const nav = this.router.getCurrentNavigation();

  //   const lcCreated = nav?.extras?.state?.['lcCreated'];
  //   console.log(lcCreated)

  //   if (lcCreated) {
  //     this.showToast('LC created successfully', 'success');
  //   }
  //   this.generateTabs();
  // }

  ngOnInit(): void {
    let lcCreated = false;

    // 1️⃣ CASE A: Coming directly from Request LOC page
    const nav = this.router.getCurrentNavigation();
    if (
      nav &&
      nav.extras &&
      nav.extras.state &&
      nav.extras.state['lcCreated']
    ) {
      lcCreated = true;
    }

    // 2️⃣ CASE B: Angular reused the component OR page refreshed
    const state = window.history.state;
    if (!lcCreated && state && state['lcCreated']) {
      lcCreated = true;
    }

    if (lcCreated) {
      this.showToast('LC created successfully', 'success');

      // Clear the state so toast doesn't show again on refresh
      const cleaned = { ...window.history.state };
      delete cleaned['lcCreated'];
      window.history.replaceState(cleaned, '');
    }

    this.generateTabs();
  }

  generateTabs() {
    const tabNames = [
      'Live',

      'Draft',

      'Actions',

      'Pending Approval',

      'Pending at Bank',

      'Rejected',

      'Closed',
    ];

    this.tabs = tabNames.map((name) => ({
      name,

      count: this.letters.filter((l) => l.tab === name).length,
    }));

    const activeHasData = this.letters.some((l) => l.tab === this.activeTab);

    if (!activeHasData) {
      const firstWithData = this.tabs.find((t) => t.count > 0);

      if (firstWithData) {
        this.activeTab = firstWithData.name;
      }
    }
  }

  get filteredLetters(): LetterOfCredit[] {
    return this.letters.filter((l) => l.tab === this.activeTab);
  }

  onTabChange() {
    this.generateTabs();
  }

  // ✅ NEW: handle edit from table

  // onRowEdited(event: any) {
  //   const { oldRow, newRow } = event;

  //   const idx = this.letters.indexOf(oldRow);

  //   if (idx !== -1) {
  //     this.letters[idx] = newRow;

  //     this.generateTabs(); // in case "tab" or something else changes
  //   }
  // }

  onRowView(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'view',

        title: 'Record Details',

        subtitle: 'View record in read-only mode',
      },
    });
  }

  onRowEdit(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'edit',

        title: 'Edit Record',

        subtitle: 'Update the selected record',
      },
    });
  }

  // ✅ NEW: handle delete from table

  onRowDeleted(row: LetterOfCredit) {
    this.letters = this.letters.filter((l) => l !== row);

    this.generateTabs();

    // if current tab is now empty, jump to first tab with data

    const stillHasData = this.letters.some((l) => l.tab === this.activeTab);

    if (!stillHasData) {
      const firstNonEmpty = this.tabs.find((t) => t.count > 0);

      if (firstNonEmpty) {
        this.activeTab = firstNonEmpty.name;
      }
    }
  }

  openTemplates() {
    this.router.navigate(['lc/outward/templates']);
  }

  openRequest() {
    this.router.navigate(['lc/outward/request-loc']);
  }
}
