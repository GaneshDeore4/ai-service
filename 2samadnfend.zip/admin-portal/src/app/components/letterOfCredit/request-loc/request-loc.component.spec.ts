import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestLocComponent } from './request-loc.component';

describe('RequestLocComponent', () => {
  let component: RequestLocComponent;
  let fixture: ComponentFixture<RequestLocComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RequestLocComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestLocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
