import { Component, OnInit, OnDestroy } from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

import { FormsModule } from '@angular/forms';

import { Router } from '@angular/router';

import { Subscription } from 'rxjs';

import { HeaderComponent } from '../../header/header.component';

import { TasksComponent } from '../../tasks/tasks.component'; // ⬅️ use tasks component

interface Section {
  id: string;

  title: string;

  attention?: boolean;

  disabled?: boolean;
}

@Component({
  selector: 'app-request-loc',

  standalone: true,

  imports: [
    CommonModule,

    ReactiveFormsModule,

    FormsModule,

    HeaderComponent,

    TasksComponent,
  ],

  templateUrl: './request-loc.component.html',

  styleUrls: ['../../../common css/request-loc.component.css'],
})
export class RequestLOCComponent implements OnInit, OnDestroy {

  sections: Section[] = [
    { id: 'general', title: 'General' },

    { id: 'beneficiary', title: 'Beneficiary' },

    { id: 'amount', title: 'Amount' },

    { id: 'documents', title: 'Documents' },

    { id: 'shipping', title: 'Shipping' },

    { id: 'charges', title: 'Charges' },

    { id: 'confirmations', title: 'Confirmations' },

    { id: 'instructions', title: 'Instructions' },
  ];

  readonly windowSize = 5;

  visibleStart = 0;

  form: FormGroup;

  activeIndex = 0;

  // layout state (only show/hide sidebar, all task logic is inside app-lc-tasks)

  showTasks = true;

  private subs: Subscription[] = [];

  constructor(private fb: FormBuilder, private router: Router) {
    this.form = this.fb.group({
      general: this.fb.group({
        lcNumber: ['', Validators.required],

        applicant: ['', Validators.required],

        issueDate: ['', Validators.required],

        expiryDate: [''],

        applicantAddress: [''],
      }),

      beneficiary: this.fb.group({
        beneficiaryName: ['', Validators.required],

        beneficiaryBank: ['', Validators.required],

        beneficiaryCountry: [''],

        beneficiarySwift: [''],
      }),

      amount: this.fb.group({
        currency: ['', Validators.required],

        amount: ['', [Validators.required, Validators.min(1)]],

        tolerance: [''],

        partialShipmentAllowed: [''],
      }),

      documents: this.fb.group({
        requiredDocs: ['', Validators.required],

        presentationDays: [''],

        insuranceRequired: [''],
      }),

      shipping: this.fb.group({
        portOfLoading: ['', Validators.required],

        portOfDischarge: [''],

        deliveryTerms: ['', Validators.required],

        latestShipmentDate: [''],
      }),

      charges: this.fb.group({
        applicantCharges: [''],

        beneficiaryCharges: [''],

        bankCharges: [''],
      }),

      confirmations: this.fb.group({
        approver: ['', Validators.required],

        requireConfirmation: [true],

        specialInstructions: [''],
      }),

      instructions: this.fb.group({
        narrative: [''],

        internalNotes: [''],
      }),
    });
  }

  ngOnInit() {
    for (const s of this.sections) {
      const sub = this.getFormGroup(s.id).statusChanges?.subscribe(() => {
        if (this.getFormGroup(s.id).valid) {
          s.attention = false;
        }
      });

      if (sub) this.subs.push(sub);
    }

    this.ensureActiveVisible();
  }

  ngOnDestroy() {
    this.subs.forEach((s) => s.unsubscribe());
  }

  get visibleSections(): Section[] {
    return this.sections.slice(
      this.visibleStart,

      this.visibleStart + this.windowSize
    );
  }

  get hiddenLeftCount(): number {
    return this.visibleStart;
  }

  get hiddenRightCount(): number {
    return Math.max(
      0,

      this.sections.length - (this.visibleStart + this.windowSize)
    );
  }

  getFormGroup(id: string): FormGroup {
    return this.form.get(id) as FormGroup;
  }

  get progressPercent(): number {
    const done = this.sections.filter(
      (s) => this.getFormGroup(s.id).valid
    ).length;

    return Math.round((done / this.sections.length) * 100);
  }

  isCompleted(i: number): boolean {
    return this.getFormGroup(this.sections[i].id).valid;
  }

  isAttention(i: number): boolean {
    return !!this.sections[i].attention;
  }

  private ensureActiveVisible() {
    if (this.activeIndex < this.visibleStart) {
      this.visibleStart = this.activeIndex;
    } else if (this.activeIndex >= this.visibleStart + this.windowSize) {
      this.visibleStart = this.activeIndex - this.windowSize + 1;
    }

    if (this.visibleStart < 0) this.visibleStart = 0;

    const maxStart = Math.max(0, this.sections.length - this.windowSize);

    if (this.visibleStart > maxStart) {
      this.visibleStart = maxStart;
    }
  }

  selectSection(index: number) {
    if (index === this.activeIndex) return;

    this.sections.forEach((s, idx) => {
      if (idx < index && !this.getFormGroup(s.id).valid) {
        s.attention = true;
      }
    });

    this.activeIndex = index;

    this.touchAllInGroup(this.getFormGroup(this.sections[index].id), false);

    this.ensureActiveVisible();
  }

  nextSection() {
    const group = this.getFormGroup(this.sections[this.activeIndex].id);

    group.markAllAsTouched();

    if (group.valid) {
      if (this.activeIndex < this.sections.length - 1) {
        this.sections[this.activeIndex + 1].attention = false;

        this.activeIndex++;

        this.ensureActiveVisible();
      }
    } else {
      this.sections[this.activeIndex].attention = true;

      this.sections.forEach((s, idx) => {
        if (idx < this.activeIndex && !this.getFormGroup(s.id).valid) {
          s.attention = true;
        }
      });
    }
  }

  prevSection() {
    if (this.activeIndex > 0) {
      this.activeIndex--;

      this.ensureActiveVisible();
    }
  }

  touchAllInGroup(g: FormGroup, touch = true) {
    Object.keys(g.controls).forEach((name) => {
      const c = g.get(name);

      if (touch) c?.markAsTouched();
      else c?.markAsUntouched();
    });
  }

  scrollTabs(direction: 'left' | 'right') {
    const step = this.windowSize;

    const maxStart = Math.max(0, this.sections.length - this.windowSize);

    if (direction === 'left') {
      this.visibleStart = Math.max(0, this.visibleStart - step);
    } else {
      this.visibleStart = Math.min(maxStart, this.visibleStart + step);
    }
  }

  /** Called from the "Tasks" tab button when sidebar is hidden */

  toggleTasks() {
    this.showTasks = true;

    this.ensureActiveVisible();
  }

  /** Called when the TasksComponent close button is clicked */

  onTasksHidden() {
    this.showTasks = false;

    this.ensureActiveVisible();
  }

  exit() {
    this.router.navigate(['/lc/outward']);
  }

  submitAll() {

    this.form.markAllAsTouched();
    
    if (this.form.valid) {
    
    const payload = this.form.value;
    
    console.log('Submit payload', payload);
    
    // ✅ Just navigate and tell outward screen to show success toast
    
    this.router.navigate(['/lc/outward'], {
    
    state: { lcCreated: true }
    
    });
    
    } else {
    
    this.sections.forEach((s) => {
    
    s.attention = !this.getFormGroup(s.id).valid;
    
    });
    
    const idx = this.sections.findIndex(
    
    (s) => !this.getFormGroup(s.id).valid
    
    );
    
    if (idx >= 0) {
    
    this.activeIndex = idx;
    
    this.ensureActiveVisible();
    
    }
    
    }
    
    }
  onFooterPrimaryClick() {
    if (this.activeIndex === this.sections.length - 1) {
      // Last section → submit whole form

      this.submitAll();
    } else {
      // Not last section → go to next section (with validation logic)

      this.nextSection();
    }
  }
}
