import { AfterViewInit, Component, CUSTOM_ELEMENTS_SCHEMA, Inject, PLATFORM_ID, inject } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionService } from '../../service/sessionService/session.service';
import { NgClass, NgIf } from '@angular/common';
import { AuthService } from '../../service/auth.service';
import { GET_BANK_USER_BY_ID, LOGIN_URL, FORGOT_PASSWORD, FORCE_LOGOUT, SEND_OTP, VALIDATE_OTP } from '../../constants/api_endpoints';
import { SUPERADMIN } from '../../constants/Constants';
import { ApiService } from '../../service/apiService/api.service';
import { MenuService } from '../../service/menuService/menu.service';
import { SessionTimeoutService } from '../../service/sessionService/session-timeout.service'; // Import SessionTimeoutService
import { OtpComponent } from '../../commom/otp/otp.component';

@Component({
  selector: 'app-login',
  imports: [MatFormFieldModule,
    MatInputModule,
    NgIf,
    FormsModule,
    OtpComponent,
    NgClass
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class LoginComponent implements AfterViewInit {
  CustomerID = 'INDUSIND'; 
  corpID = 'INDUS';
  username = '';
  password = '';
  errorMessage: string = '';
  isLoading = false;
  showPassword = false;

  private sessionTimeoutService = inject(SessionTimeoutService); // Inject SessionTimeoutService

  constructor(private router: Router, private sessionService: SessionService, private authService: AuthService, private apiService: ApiService, private menuService: MenuService, @Inject(PLATFORM_ID) private platformId: Object) {
  }

  ngAfterViewInit() {
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  login(event?: Event) {
    if (event) {
      event.preventDefault();
    }
    this.errorMessage = '';
    const payload = {
      bankAbbvName: this.corpID,
      loginId: this.username,
      password: this.password,
      force: true
    };
    this.initiateLogin(payload);
  }

  initiateLogin(payload: any) {
    this.isLoading = true;
    this.authService.login(LOGIN_URL, payload).subscribe({
      next: (response) => {
        if (response.token) {
          this.sessionService.setToken(response.token);
          this.sessionService.setRole(response.role);
          this.sessionService.setUserId(response.userId);
          this.sessionService.setLoginId(response.loginId);
          this.sessionService.setCompanyName(this.corpID);
          this.sessionService.setLastLogin(response.lastLogin)
          // Start the session timeout timer after successful login
          this.sessionTimeoutService.resetTimer();

          // Fetch dynamic menu
          this.menuService.fetchUserAccess(response.userId).subscribe();

          this.getUserDetails(response.userId);
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error('Login failed', err);
        if (err.status === 500) {
          this.errorMessage = 'Internal Server Error. Please try again later.';
        } else if (err.status === 401 || err.status === 403) {
          this.errorMessage = 'Invalid Credentials. Please check your inputs.';
        } else if (err.name === 'AbortError' || err.status === 0) {
          this.errorMessage = 'Request Aborted or Network Error. Please check your connection.';
        } else {
          this.errorMessage = err.error?.message || 'Login failed. Please try again.';
        }
      }
    });
  }

  loginDisabled(): boolean {
    if (this.corpID == '' || this.username == '' || this.password == '')
      return true;
    return false;
  }

  getUserDetails(uesrId: number) {
    this.apiService.getData(GET_BANK_USER_BY_ID + "?id=" + uesrId, {}).subscribe({
      next: (res) => {
        console.log("BANK USER" + JSON.stringify(res, null, 2));
        if (res.status == "SUCCESS") {
          this.sessionService.setUsername(res.payload.firstName);
          this.sessionService.setEmail(res.payload.email);
          this.sessionService.setCompanyId(res.payload.bankId);
          this.sessionService.setIsFirstLoginFlag(res.payload.isFirstLoginFlag);
          this.isLoading = false;
          // this.sendOtp();
          this.router.navigate(['/content/landing']);
        } else {
          this.isLoading = false;
          this.errorMessage = 'Couldnt fetch user details';
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.log("error:" + JSON.stringify(err, null, 2));
        this.errorMessage = 'Couldnt fetch user details';
      },
      complete: () => {
      }
    });
  }

  isForgotPassword = false;
  successMessage = '';
  confirmPassword = '';

  toggleForgotPassword() {
    this.isForgotPassword = !this.isForgotPassword;
    this.errorMessage = '';
    this.successMessage = '';
    this.corpID = '';
    this.username = '';
    this.password = '';
    this.confirmPassword = '';
  }

  changePasswordDisabled(): boolean {
    return !this.corpID || !this.username || !this.password || !this.confirmPassword || (this.password !== this.confirmPassword);
  }

  changePassword() {
    if (!this.corpID || !this.username || !this.password || !this.confirmPassword) {
      this.errorMessage = 'Please fill out all fields.';
      return;
    }

    if (this.password !== this.confirmPassword) {
      this.errorMessage = 'Passwords do not match.';
      return;
    }
    const data = {
      bankAbbvName: this.corpID,
      loginId: this.username,
      newPassword: this.password,
      afterLogin: false
    }
    this.apiService.sendData(FORGOT_PASSWORD, data).subscribe({
      next: (res) => {
        if (res.status == "SUCCESS") {
          this.successMessage = 'Password was successfully Reset.'
        } else {
          this.errorMessage = 'Something went wrong. Please try again';
        }
      },
      error: (err) => {
        this.errorMessage = 'Something went wrong.';
      },
      complete: () => {
      }
    });
  }


  // OTP FUNCTIONS
  isOtpOpen = false;
  otpReference: string = '';
  tempReceivedOtp = '';
  sendOtp() {
    this.isOtpOpen = true;
    const payload = {
      loginId: this.username,
      bankAbbvName: this.corpID
    }
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  onOtpResend() {
    const payload = {
      loginId: this.username,
      bankAbbvName: this.corpID,
      otpReference: this.otpReference
    }
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status) {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  validateOtp(otp: string) {
    // const payload = {
    //   otpReference: this.otpReference,
    //   enteredOtp: this.tempReceivedOtp,  //REPLACE THIS AFTERWARD WITH otp varaible
    //   loginId: this.username,
    //   bankAbbvName: this.corpID
    // }
    // this.apiService.sendData(VALIDATE_OTP, payload).subscribe({
    //   next: (res) => {
    //     if (res.status == 'SUCCESS') {
    //       // TODO: if the otp is validate call onOtpVerify
    //       this.isOtpOpen = false;
    //       this.router.navigate(['/content/landing']);
    //     } else {
    //       console.log('OTP SEND FAILED');
    //     }
    //   },
    //   error: (err) => {
    //     console.error(err);
    //   }
    // });
  }

  closeOtpPopup(){
    this.isOtpOpen=false;
    this.otpReference='';
    this.tempReceivedOtp=''
  }
}
