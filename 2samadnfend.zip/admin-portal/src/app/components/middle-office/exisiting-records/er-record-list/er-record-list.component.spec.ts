import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ErRecordListComponent } from './er-record-list.component';

describe('ErRecordListComponent', () => {
  let component: ErRecordListComponent;
  let fixture: ComponentFixture<ErRecordListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ErRecordListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ErRecordListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
