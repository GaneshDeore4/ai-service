import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../../commom/table/table.component";
import { TabsModule } from 'primeng/tabs';

@Component({
  selector: 'app-er-record-list',
  imports: [PageTitleComponent, NgIf, NgFor, FormsModule, TableComponent, NgClass,TabsModule],
  templateUrl: './er-record-list.component.html',
  styleUrl: './er-record-list.component.css'
})
export class ErRecordListComponent {


  // main page vars
  searchChannelRef = '';
  searchCompany = '';
  searchProductList = ['Export Collection', 'Import Colloection', 'Invoice'];
  selectedProduct = '';
  searchProductTypeList = ['Standby', 'Invoice Payment'];
  selectedProductType = '';
  searchBankRef = '';

  header = ['Channel Reference', 'Bank Ref', 'Company', 'Status', 'CCY', 'Amount', 'Action'];
  data: any[] = [
    {
      "Channel Reference": "CH001",
      "Bank Ref": "456789",
      "Company": "Big4U",
      "Status": "Amended",
      "CCY": "USD",
      "Amount": "100000",
    },
    {
      "Channel Reference": "CH002",
      "Bank Ref": "4567229",
      "Company": "Test Corp",
      "Status": "New",
      "CCY": "EUR",
      "Amount": "50000",
    },
  ];
  ogData = [...this.data];
  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchChannelRef = this.searchChannelRef
        ? item['Channel Reference']?.toLowerCase().includes(this.searchChannelRef.toLowerCase())
        : true;

      const matchCompany = this.searchCompany
        ? item['Company']?.toLowerCase().includes(this.searchCompany.toLowerCase())
        : true;

      const matchProduct = this.selectedProduct
        ? item['Type'] === this.selectedProduct
        : true;

      const matchProductType = this.selectedProductType
        ? item['CCY'] === this.selectedProductType
        : true;

      const matchBankRef = this.searchBankRef
        ? item['Bank Ref'] == this.searchBankRef
        : true;

      return matchChannelRef && matchCompany && matchProduct && matchProductType && matchBankRef;
    });

    // ✅ Update reference so child detects change
    this.data = [...filtered];
  }

  showTranRecord = false;
  viewTransactionf(row: any, index: any) {
    this.showTranRecord = true;
  }


  // transaction  page vars

  // tran brief
  systemId = 'BG21120000056410';
  creationDate = '19/01/2024';
  bankReference = 'OGT0001210055103';
  issueDate = '19/01/2023';
  customerReference = 'OGT0001210055103';
  companyName = 'TATA';
  product = 'Undertaking Issued';
  formOfUndertaking = 'Standby Letter of Credit';
  transactionType = 'Reporting';
  newTranStatusList = ['Amended', 'Settled', 'Expired'];
  selectedNewTranStatus = '';

  // general details
  additionalCustomerReference = '011';
  beneficiaryReference = 'RK011';
  methodOfTransmission = 'SWIFT';
  purpose = 'Issuance of Undertaking';
  confirmationInstruction = 'Without';
  transferIndicator = false;

  // applicant details
  entity = 'TEMP';
  recipient = '30480981';
  name = 'TATA ADVANCED MATERIALS LTD';
  address = `10 JIGANI INDUSTRIAL AREA JIGANI
APC CIRCLE BANGALORE KARNATAKA
INDIA`;

  // alt applicant details
  onBehalfOf = true;
  altApplicantName = 'TATA ADVANCED MATERIALS LTD';
  altaddress = `10 JIGANI INDUSTRIAL AREA JIGANI
APC CIRCLE BANGALORE KARNATAKA
INDIA`;
  altApplicantCountry = 'IN';

  // bene details:
  beneAltApplicantName: string = 'Raghu';
  beneOnBehalfOf: boolean = true;
  beneAltApplicantCountry: string = 'IN';
  beneAltaddress: string = 'D 10, Part 2, South Extn\nSembakkam\nChennai';
  beneBeiCode: string = '';

  // bank details
  recipientBankName='IndusInd Bank Limited-2';
  issuersRef='33780891.Z1.001.0001';
  IBIssuingInstruction='Direct';
  IBSwiftCode='';
  IBBankName='INDUSIND';
  IBAddress='';
  ABSwiftCode='';
  ABBankName='JPMORGAN CHASE BANK, N.A.';
  ABAddress='New York, USA';
  ATBSwiftCode='';
  ATBBankName='';
  ATBAddress='';

  // undertaking general details
  typeOfUndertaking='OGM';
  effectiveDate='';
  expiryType='Fixed';
  expiryDate='31/12/2026';

  newTranStatusError = false;
  effectiveDateError=false;
}
