import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoLandingComponent } from './mo-landing.component';

describe('MoLandingComponent', () => {
  let component: MoLandingComponent;
  let fixture: ComponentFixture<MoLandingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MoLandingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MoLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
