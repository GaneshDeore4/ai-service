import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingAtBankComponent } from './pending-at-bank.component';

describe('PendingAtBankComponent', () => {
  let component: PendingAtBankComponent;
  let fixture: ComponentFixture<PendingAtBankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PendingAtBankComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingAtBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
