import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TranInquiryComponent } from './tran-inquiry.component';

describe('TranInquiryComponent', () => {
  let component: TranInquiryComponent;
  let fixture: ComponentFixture<TranInquiryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TranInquiryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TranInquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
