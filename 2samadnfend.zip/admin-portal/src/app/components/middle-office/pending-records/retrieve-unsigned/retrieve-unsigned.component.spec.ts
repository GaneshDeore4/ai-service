import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetrieveUnsignedComponent } from './retrieve-unsigned.component';

describe('RetrieveUnsignedComponent', () => {
  let component: RetrieveUnsignedComponent;
  let fixture: ComponentFixture<RetrieveUnsignedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RetrieveUnsignedComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RetrieveUnsignedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
