import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../../commom/table/table.component";
import { PopupComponent } from "../../../../commom/popup/popup.component";

@Component({
  selector: 'app-retrieve-unsigned',
  imports: [PageTitleComponent, NgIf, NgFor, FormsModule, TableComponent, PopupComponent],
  templateUrl: './retrieve-unsigned.component.html',
  styleUrl: './retrieve-unsigned.component.css'
})
export class RetrieveUnsignedComponent {
  // main page vars
  searchChannelRef = '';
  searchCompany = '';
  searchProductList = ['Export Collection', 'Import Colloection', 'Invoice'];
  selectedProduct = '';
  searchUsername = '';

  header = ['Channel Reference', 'Company', 'Currency', 'Action'];
  data: any[] = [
    {
      "Channel Reference": "CH001",
      "Company": "Big4U",
      "Currency": "USD",
      "Amount": "100000",
      "Username": "Abhinay",
      "Input Date": "2023-01-01",
    },
    {
      "Channel Reference": "CH002",
      "Company": "Big4UP",
      "Currency": "INR",
      "Amount": "100000",
      "Username": "Abhinay",
      "Input Date": "2023-01-02",
    },
  ];

  userHeaders = ['Full Name', 'Date and Time', 'Description'];
  userData: any[] = [
    {
      "Full Name": "Dummy User1",
      "Date and Time": "Feb 4, 2025 12:07:05 PM IST",
      "Description": "Dummy description"
    },
    {
      "Full Name": "Dummy User2",
      "Date and Time": "Feb 4, 2025 12:07:05 PM IST",
      "Description": "Dummy description2"
    }
  ];

  ogData = [...this.data];

  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchChannelRef = this.searchChannelRef
        ? item['Channel Reference']?.toLowerCase().includes(this.searchChannelRef.toLowerCase())
        : true;

      const matchCompany = this.searchCompany
        ? item['Company']?.toLowerCase().includes(this.searchCompany.toLowerCase())
        : true;

      const matchProduct = this.selectedProduct
        ? item['Product'] === this.selectedProduct
        : true;

      const matchUsername = this.searchUsername
        ? item['Username'] === this.searchUsername
        : true;


      return matchChannelRef && matchCompany && matchProduct && matchUsername;
    });

    // ✅ Update reference so child detects change
    this.data = [...filtered];
  }

  showUserPopup = false;
  closeUserPopup() {
    this.showUserPopup = false;
  }
  viewUsers(row: any) {
    this.showUserPopup = true;
  }

  showTranRecord = false;
  viewTransactionf() {
    this.showTranRecord = true;
  }

  // transaction page
  companyName = 'Test domain';
  productCode = 'Secure Email';
  channelRef = 'SE25010000095851';
  tranType = 'New';
  releaseDate = 'Thursday, January 30, 2025 2:15:29 PM IST';

  selectedTranStatus = 'Approved';
  bankRef = 'SE25010000095851';

  applicationDate = '22/12/2025';
  bankName = 'IndusInd Bank LTD';
  fileType = 'Cheque Description';

  freeFormatMsg = 'this is a test free format message';


  popupVisible = false;
  popupText = '';
  hidePopup() {
    this.popupText = '';
    this.popupVisible = false;
  }


  submit(){
    this.popupText='Transaction details Saved';
    this.popupVisible=true;
    this.showTranRecord=false;
  }
  backToList(){
    this.showTranRecord=false;
  }



  // checkbox functionalities:
  selectedIndices: number[] = [];

  onSelectedIndicesChange(indices: number[]) {
    this.selectedIndices = indices;
  }
  
}
