import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../commom/page-title/page-title.component";
import { NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../commom/table/table.component";

@Component({
  selector: 'app-task-monitoring',
  imports: [PageTitleComponent, NgFor, FormsModule, TableComponent],
  templateUrl: './task-monitoring.component.html',
  styleUrl: './task-monitoring.component.css'
})
export class TaskMonitoringComponent {


  //search vars
  itemTypeList=['Task','Commnet'];
  selectedItemType='';
  searchChannelRef='';
  taskTypeList=['Private', 'Public', 'Assigned'];
  selectedTaskType='';
  taskStatusList=['Performed','Not Performed'];
  selectedTaskStatus='';
  toDate='';
  fromDate='';

  header=['Item Type', 'Post Date', 'Channel Reference', 'Transaction Type', 'Issuer', 'Task Type', 'Description'];
  data:any[]=[];

  searchData(){}
}
