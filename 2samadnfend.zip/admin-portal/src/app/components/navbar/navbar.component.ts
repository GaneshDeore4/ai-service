import { Component, OnInit } from '@angular/core';
import { NgClass, NgFor, NgIf, NgStyle } from '@angular/common';
import { Router, NavigationEnd, RouterModule } from '@angular/router';
import { filter } from 'rxjs/operators';
import { MenuService } from '../../service/menuService/menu.service';
import { Product } from '../../model/profile.models';

interface BreadcrumbItem {
  label: string;
  url?: string; // if present → clickable
}

interface MenuItem {
  name: string;
  icon?: string;
  route?: string;
  subItems?: MenuItem[];
}

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [NgClass, NgFor, NgIf, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  selectedItem: string | null = null;
  selectedSubItem: string | null = null;
  isSidebarOpen = false;
  expandedMenus = new Set<string>(); // Store menu names that are expanded
  openDesktopIndex: number | null = null;

  // breadcrumb state
  breadcrumbs: BreadcrumbItem[] = [];
  breadcrumbMenuOpen = false;

  // Updated hierarchical menu structure
  menuItems: MenuItem[] = [
    {
      name: 'Account Services',
      icon: 'fas fa-university',
      subItems: [
        { name: 'EEFC Transfer', route: '/accounts/eefc' },
        { name: 'Account Balance', route: '/accounts/balance' }
      ],
    },
    {
      name: 'Export',
      icon: 'fas fa-file-export',
      subItems: [
        { name: 'Export Collection', route: '/export/collection' },
        { name: 'Direct Export Lodgement', route: '/export/direct' },
        { name: 'SB Regularisation', route: '/export/sb-reg' },
        { name: 'EDPMS Dashboard', route: '/export/edpms' }
      ],
    },
    {
      name: 'Import',
      icon: 'fas fa-file-import',
      subItems: [
        { name: 'Import Collection', route: '/import/collection' },
        { name: 'BoE Regularisation', route: '/import/boe-reg' },
        { name: 'IDPMS Dashboard', route: '/import/idpms' }
      ],
    },
    {
      name: 'Foreign Remittance',
      icon: 'fas fa-money-bill-wave',
      subItems: [
        { name: 'Inward Remittance Disposal', route: '/remittance/inward' },
        { name: 'Outward Remittance', route: '/remittance/outward' }
      ],
    },
    {
      name: 'Letter Of Credit',
      icon: 'fas fa-file-invoice',
      subItems: [
        { 
          name: 'Inward Letter Of Credit', 
          route: '/lc/inward',
          subItems: [
            { name: 'View List', route: '/lc/inward' },
            { name: 'New Request', route: '/lc/inward/new' }
          ]
        },
        { 
          name: 'Outward Letter Of Credit', 
          route: '/lc/outward',
          subItems: [
            { name: 'View List', route: '/lc/outward' },
            { name: 'Request LC', route: '/lc/outward/request-loc' },
            { name: 'Templates', route: '/lc/outward/templates' }
          ]
        },
      ],
    },
    {
      name: 'Guarantee',
      icon: 'fas fa-shield-alt',
      subItems: [
        { name: 'Shipping Guarantee', route: '/guarantee/shipping-guarantee' },
        { 
          name: 'Outward Bank Guarantee', 
          route: '/guarantee/outward-bank-guarantee',
          subItems: [
            { name: 'View List', route: '/guarantee/outward-bank-guarantee' },
            { name: 'Templates', route: '/guarantee/outward-bank-guarantee/templates' }
          ]
        }
      ],
    },
    { 
      name: 'Finance', 
      icon: 'fas fa-coins',
      subItems: [{ name: 'Pre-shipping Finance', route: '/finance/pre-shipping' }] 
    },
    {
      name: 'Administration',
      icon: 'fas fa-user-shield',
      subItems: [
        { name: 'Data Maintenance', route: '/admin/data' },
        { name: 'Alert Maintenance', route: '/admin/alerts' },
        { name: 'Report Designer', route: '/admin/reports' },
        { name: 'Audit Queries', route: '/admin/audit' },
        { name: 'Trade Standard Reports', route: '/admin/trade-reports' },
      ],
    },
    {
      name: 'Common Services',
      icon: 'fas fa-cogs',
      subItems: [
        { name: 'Secure Email', route: '/services/email' },
        { name: 'Processed By Bank', route: '/services/processed' },
        { name: 'Pending Transactions', route: '/services/pending' },
        { name: 'Set Entity', route: '/services/entity' },
      ],
    },
  ];

  private routeMap: Record<
    string,
    { menu?: string; sub?: string; breadcrumbs: BreadcrumbItem[] }
  > = {
    '/lc/inward': {
      menu: 'Letter Of Credit',
      sub: 'Inward Letter Of Credit',
      breadcrumbs: [
        { label: 'Letter Of Credit', url: '/lc/inward' },
        { label: 'Inward Letter Of Credit' },
      ],
    },
    '/lc/outward': {
      menu: 'Letter Of Credit',
      sub: 'Outward Letter Of Credit',
      breadcrumbs: [
        { label: 'Letter Of Credit', url: '/lc/outward' },
        { label: 'Outward Letter Of Credit' },
      ],
    },
    '/lc/outward/request-loc': {
      menu: 'Letter Of Credit',
      sub: 'Outward Letter Of Credit',
      breadcrumbs: [
        { label: 'Letter Of Credit', url: '/lc/outward' },
        { label: 'Outward Letter Of Credit', url: '/lc/outward' },
        { label: 'Request Letter Of Credit' },
      ],
    },
    '/lc/outward/templates': {
      menu: 'Letter Of Credit',
      sub: 'Outward Letter Of Credit',
      breadcrumbs: [
        { label: 'Letter Of Credit', url: '/lc/outward' },
        { label: 'Outward Letter Of Credit', url: '/lc/outward' },
        { label: 'Templates' },
      ],
    },
    '/guarantee/shipping-guarantee': {
      menu: 'Guarantee',
      sub: 'Shipping Guarantee',
      breadcrumbs: [
        { label: 'Guarantee', url: '/guarantee/shipping-guarantee' },
        { label: 'Shipping Guarantee' },
      ],
    },
    '/guarantee/outward-bank-guarantee': {
      menu: 'Guarantee',
      sub: 'Outward Bank Guarantee',
      breadcrumbs: [
        { label: 'Guarantee', url: '/guarantee/outward-bank-guarantee' },
        { label: 'Outward Bank Guarantee' },
      ],
    },
    '/guarantee/outward-bank-guarantee/templates': {
      menu: 'Guarantee',
      sub: 'Outward Bank Guarantee',
      breadcrumbs: [
        { label: 'Guarantee', url: '/guarantee/outward-bank-guarantee' },
        { label: 'Outward Bank Guarantee' , url: '/guarantee/outward-bank-guarantee' },
        { label: 'Templates' },
      ],
    },
  };

  constructor(public router: Router, private menuService: MenuService) {}

  ngOnInit(): void {
    // initial sync on hard refresh
    this.updateSelectionFromUrl(this.router.url);

    // keep navbar + breadcrumbs in sync with route
    this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((navEnd) => {
        const url = navEnd.urlAfterRedirects || navEnd.url;
        this.updateSelectionFromUrl(url);
      });

    // Handle dynamic menu
    this.menuService.accessProfile$.subscribe(profile => {
      if (profile && profile.products) {
        this.transformDynamicMenu(profile.products);
      }
    });
  }

  transformDynamicMenu(products: Product[]) {
    const dynamicItems: MenuItem[] = products.map(p => ({
      name: p.productName,
      icon: this.getIcon(p.productName),
      subItems: p.subProducts?.map(sp => ({
        name: sp.subProductName,
        subItems: sp.tabActionMapping?.map(tam => ({
          name: tam.tabName,
          route: this.getDynamicRoute(p.productName, sp.subProductName, tam.tabName)
        }))
      }))
    }));

    this.menuItems = [...this.menuItems, ...dynamicItems];
    // Remove duplicates by name
    this.menuItems = this.menuItems.filter((v, i, a) => a.findIndex(t => (t.name === v.name)) === i);
  }

  getIcon(productName: string): string {
    const iconMap: { [key: string]: string } = {
       'FD': 'fas fa-piggy-bank',
       'Account': 'fas fa-university',
       'Export': 'fas fa-file-export',
       'Import': 'fas fa-file-import',
       'Remittance': 'fas fa-money-bill-wave'
    };
    return iconMap[productName] || 'fas fa-folder';
  }

  getDynamicRoute(product: string, sub: string, tab: string): string {
    const p = product.toLowerCase();
    if (p.includes('account')) return '/accounts';
    if (p.includes('export')) return '/export';
    if (p.includes('import')) return '/import';
    return '/dashboard';
  }

  private updateSelectionFromUrl(url: string) {
    const clean = url.split('?')[0].split('#')[0];
    let matchedKey: string | undefined;

    if (this.routeMap[clean]) {
      matchedKey = clean;
    } else {
      const keys = Object.keys(this.routeMap).sort((a, b) => b.length - a.length);
      for (const k of keys) {
        if (clean.startsWith(k)) {
          matchedKey = k;
          break;
        }
      }
    }

    const cfg = matchedKey ? this.routeMap[matchedKey] : undefined;
    if (cfg) {
      const { menu, sub, breadcrumbs } = cfg;
      this.selectedItem = menu ?? null;
      this.selectedSubItem = sub ?? null;
      if (menu) {
        this.expandedMenus.clear();
        this.expandedMenus.add(menu);
      }
      this.breadcrumbs = breadcrumbs;
    } else {
      this.selectedItem = null;
      this.selectedSubItem = null;
      this.expandedMenus.clear();
      this.breadcrumbs = [];
    }
    this.breadcrumbMenuOpen = false;
  }

  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
    if (!this.isSidebarOpen) this.expandedMenus.clear();
  }

  closeSidebar() {
    this.isSidebarOpen = false;
    this.expandedMenus.clear();
  }

  selectItem(itemName: string) {
    this.selectedItem = itemName;
    this.selectedSubItem = null;
  }

  selectSubItem(sub: MenuItem) {
    this.selectedSubItem = sub.name;
    for (const item of this.menuItems) {
      if (item.subItems?.some(s => s.name === sub.name)) {
        this.selectedItem = item.name;
        break;
      }
    }
    this.closeSidebar();
  }

  goToItemFromSidebar(itemName: string) {
    this.selectItem(itemName);
    this.closeSidebar();
  }

  toggleSidebarExpand(menuName: string) {
    if (this.expandedMenus.has(menuName)) {
      this.expandedMenus.delete(menuName);
    } else {
      this.expandedMenus.clear();
      this.expandedMenus.add(menuName);
    }
  }

  isExpanded(menuName: string) {
    return this.expandedMenus.has(menuName);
  }

  isMenuActive(item: MenuItem): boolean {
    if (this.router.url === item.route) return true;
    if (item.subItems) {
      return item.subItems.some(sub => this.isMenuActive(sub));
    }
    return false;
  }

  openDesktop(i: number) {
    this.openDesktopIndex = i;
  }

  closeDesktop() {
    this.openDesktopIndex = null;
  }

  trackByIndex(i: number) {
    return i;
  }

  get hasOverflowBreadcrumbs(): boolean {
    return this.breadcrumbs.length > 4;
  }

  get hiddenBreadcrumbs(): BreadcrumbItem[] {
    if (!this.hasOverflowBreadcrumbs) return [];
    const len = this.breadcrumbs.length;
    return this.breadcrumbs.slice(0, len - 3);
  }

  get visibleBreadcrumbs(): BreadcrumbItem[] {
    if (!this.hasOverflowBreadcrumbs) return this.breadcrumbs;
    const len = this.breadcrumbs.length;
    return this.breadcrumbs.slice(len - 3);
  }

  toggleBreadcrumbMenu() {
    this.breadcrumbMenuOpen = !this.breadcrumbMenuOpen;
  }

  onBreadcrumbClick(crumb: BreadcrumbItem) {
    if (crumb.url) {
      this.router.navigateByUrl(crumb.url);
    }
    this.breadcrumbMenuOpen = false;
  }

  logout() {
    // Clear all storage — removes token, currentUser, userAccess, etc.
    sessionStorage.clear();
    localStorage.clear();
    
    // Redirect to login page
    this.router.navigate(['/login']);
  }
}
