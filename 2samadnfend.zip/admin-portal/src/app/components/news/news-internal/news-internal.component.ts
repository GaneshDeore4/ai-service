import { Component } from '@angular/core';
// import { PageTitleComponent } from '../../../commom/page-title/page-title.component';
import { TableComponent } from '../../../commom/table/table.component';
import { NgClass, NgFor, NgIf, NgStyle } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ToastComponent } from '../../../commom/toast/toast.component';
import { OnInit } from '@angular/core';
import { ApiService } from '../../../service/apiService/api.service';
import {
  ADD_NOTIFICATION,
  Delete_NOTIFICATION,
  GET_ALL_NOTIFICATIONS,
  APPROVE_NOTIFICATION,
  REJECT_NOTIFICATION,
  TOGGLE_NOTIFICATION,
  GET_NOTIFICATION_BY_ID,
} from '../../../constants/api_endpoints';
import { PAGE_SIZE } from '../../../constants/Constants';
import { TblComponent } from '../../../commom/tbl/tbl.component';
import { SessionService } from '../../../service/sessionService/session.service';
import {
  SUPERADMIN,
  BANKSUPERADMINMAKER,
  BANKSUPERADMINCHECKER,
  BANKSETUPMAKER,
  BANKSETUPCHECKER,
  COMPANY_CATERGORY_ID,
} from '../../../constants/Constants';
import { UserAuditComponent } from '../../../commom/user-audit/user-audit.component';
export type AuditStatus = 'completed' | 'current' | 'pending' | 'inprogress';

export interface AuditCard {
  label: string;
  name: string;
  datetime?: string; // optional for pending
  status: AuditStatus;
  group?: string;
}
@Component({
  selector: 'app-news-internal',
  imports: [
    TblComponent,
    NgIf,
    NgClass,
    FormsModule,
    ToastComponent,
    UserAuditComponent,
  ],
  templateUrl: './news-internal.component.html',
  styleUrl: './news-internal.component.css',
})
export class NewsInternalComponent implements OnInit {
  // Pagination state
  viewMode: boolean = false;
  selectedNotificationId: number | null = null;
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'notificationTable';
  actionList: string[] = [];
  addForm: boolean = false;
  title = '';
  layout = '';
  desc = '';
  validTill: string = '';
  selectedStatus: string = '';
  validTillError = false;
  titleError = false;
  layoutError = false;
  showAddTopicPopup = false;
  topicDetailsList = [];
  popupMsg = '';
  popupVisible = false;
  viewChannel = false;
  searchText: string = '';
  originalData: any[] = [];
  modifyChannel = false;
  role = '';
  headers: { key: string; value: string }[] = [
    { key: 'title', value: 'Title' },
    { key: 'description', value: 'Description' },
    { key: 'validTill', value: 'Valid Till' },
    { key: 'status', value: 'Status' }, // ✅ NEW
    { key: 'active', value: 'Active' },
    { key: 'Action', value: 'Action' },
    // { key: 'Audit', value: 'Audit-trail' },
  ];
  isAuditOpen = false;
  channelRef = 'CH123456';
  currentDate = new Date().toISOString().split('T')[0];
  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }
  auditCards: AuditCard[] = [
    {
      label: 'Maker',
      name: 'ABC',
      datetime: '10 Apr 2026, 10:00 AM',
      status: 'completed',
    },
    {
      label: 'Checker',
      name: 'XYZ',
      datetime: '10 Apr 2026, 11:00 AM',
      status: 'completed',
    },
  ];

  selectOptions = [
    { label: 'Enabled', value: true },
    { label: 'Disabled', value: false },
  ];
  columnWidths = ['30%', '35%', '10%'];
  data: any[] = [];
  topicHeaders = ['Logo', 'Title', 'Link'];
  topicColumnWidths = ['30%', '25%', '45%'];
  topicData: any = [
    {
      Logo: '',
      Title: 'Test News',
      Link: 'https://testNew.com',
    },
  ];

  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  ngOnInit() {
    this.getNotifications();
  }
  onActiveChange(event: any) {
    const id = event.row.id;
    const isActive = event.value;
    const url = `${TOGGLE_NOTIFICATION}?notificationId=${id}`;
    const payload = {
      isActive: isActive,
    };
    this.apiService.sendData(url, payload).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.showToast(
            'success',
            'Success',
            `Notification ${isActive ? 'Enabled' : 'Disabled'}`
          );
        } else {
          this.showToast('error', 'Error', res.description);
          // ❗ revert UI if API fails
          event.row.active = !isActive;
        }
      },
      error: () => {
        this.showToast('error', 'Error', 'Toggle failed');
        // ❗ revert UI if API fails
        event.row.active = !isActive;
      },
    });
  }
  viewNotification(row: any) {
    this.selectedNotificationId = row.id;
    this.title = row.title;
    this.desc = row.description;
    // ✅ FIX HERE
    this.validTill = this.convertToInputDate(row.validTill);
    this.selectedStatus = row.status;
    this.viewMode = true;
    this.addForm = true;
  }
  modifyChannelf(row: any) {
    this.modifyChannel = true;
    this.selectedNotificationId = row.id;
    this.title = row.title;
    this.desc = row.description;
    // ✅ FIX HERE ALSO
    this.validTill = this.convertToInputDate(row.validTill);
    this.addForm = true;
  }

  approveNotification() {
    if (!this.selectedNotificationId) return;
    const url = `${APPROVE_NOTIFICATION}?notificationId=${this.selectedNotificationId}`;
    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': 'APPROVE',
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Approved', 'Notification Approved');
            this.getNotifications();
            this.backToList();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Approval failed');
        },
      });
  }
  rejectNotification() {
    if (!this.selectedNotificationId) return;
    const url = `${REJECT_NOTIFICATION}?notificationId=${this.selectedNotificationId}`;
    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': 'REJECT',
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('error', 'Rejected', 'Notification Rejected');
            this.getNotifications();
            this.backToList();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Rejection failed');
        },
      });
  }

  constructor(
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.role = this.sessionService.getRole() || '';
    if (this.role == BANKSUPERADMINMAKER || this.role == BANKSETUPMAKER || this.role == SUPERADMIN) {
      this.actionList = ['edit','delete', 'audit'];
    }
    else if(this.role == BANKSUPERADMINCHECKER){
      this.actionList = ['view', 'audit'];
    } 
  }

  approveRejectAvailable(): boolean {
    if (
      this.role === SUPERADMIN ||
      this.role === BANKSUPERADMINCHECKER ||
      this.role === BANKSETUPCHECKER
    )
      return true;
    else return false;
  }
  addBtnAllowed(): boolean {
    if (
      this.role == SUPERADMIN ||
      this.role == BANKSUPERADMINMAKER ||
      this.role == BANKSETUPMAKER
    )
      return true;
    else return false;
  }
  convertToInputDate(dateStr: string): string {
    if (!dateStr) return '';

    // expects: dd-mm-yyyy HH:mm
    const [datePart, timePart] = dateStr.split(' ');
    const [day, month, year] = datePart.split('-');

    return `${day}-${month}-${year}`; // for <input type="date">
  }

  getNotifications() {
    this.apiService
      .getData(
        GET_ALL_NOTIFICATIONS +
        '?page=' +
        (this.pageNumber - 1) +
        '&size=' +
        this.pageSize,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res?.status === 'SUCCESS' && res?.payload?.content) {
            const content = res.payload.content;

            this.data = content.map((item: any) => ({
              id: item.notificationId,
              title: item.notificationTitle || '',
              description: item.notificationDesc || '',
              active: item.isActive,
              validTill: item.validUpto || '',

              // 👇 TEMP logic (until backend gives status)
              status: item.status || 'Pending',
            }));

            // ✅ IMPORTANT for search
            this.originalData = [...this.data];

            // ✅ Pagination
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
          } else {
            this.data = [];
            this.originalData = [];
            this.showToast('error', 'Error', res?.description || 'No data');
          }
        },
        error: () => {
          this.data = [];
          this.originalData = [];
          this.showToast('error', 'Error', 'Failed to fetch notifications');
        },
      });
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }

    if (event.tableId === 'notificationTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getNotifications(); // 🔥 reload API
    }
  }

  onSearch() {
    const term = this.searchText.trim().toLowerCase();

    if (!term) {
      this.data = [...this.originalData];
      return;
    }

    this.data = this.originalData.filter(
      (item) =>
        item.title.toLowerCase().includes(term) ||
        item.description.toLowerCase().includes(term)
    );
  }

  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }

  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  addChannel() {
    console.log('add clicked');
    this.addForm = true;
  }

  hidePopup() {
    this.popupVisible = false;
  }
  openPopup() {
    this.showAddTopicPopup = true;
  }
  closePopup() {
    this.showAddTopicPopup = false;
  }

  viewChannelf() {
    this.viewChannel = true;
    console.log('viewChannel:', this.viewChannel);
  }
  editNews() {
    this.showAddTopicPopup = true;
    this.topicTitle = this.topicData[0].Title;
    this.topicLink = this.topicData[0].Link;
    console.log('editNew:', this.showAddTopicPopup);
  }

  topicTitle = '';
  topicLink = '';
  topicTitleError = false;
  saveTopic() {
    if (this.topicTitle == '') {
      this.topicTitleError = true;
      return;
    }
    this.addTopicToList();
    this.showToast('success', 'Success', 'Topic saved successfully');
    this.closePopup();
    this.topicTitle = '';
    this.topicLink = '';
    this.topicTitleError = false;
  }
  addTopicToList() {
    this.topicData.push({
      Logo: '',
      Title: this.topicTitle,
      Link: this.topicLink,
    });
  }
  deleteNotification(row: any) {
    const url = `${Delete_NOTIFICATION}?notificationId=${row.id}`;
    this.apiService.sendData(url, {}).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.getNotifications();
          this.showToast(
            'success',
            'Success',
            'Notification Deleted Successfully'
          );
        } else {
          this.showToast('error', 'Error', res.description);
        }
      },
      error: () => {
        this.showToast('error', 'Error', 'Failed to delete notification');
      },
    });
  }
  backToList() {
    this.clearFormData();
    this.addForm = false;
    this.modifyChannel = false;
    this.viewMode = false; // 👈 IMPORTANT
    this.selectedNotificationId = null;
  }
  formatToDdMmYyyyHHmm(value: string | Date): string {
    const date = typeof value === 'string' ? new Date(value) : value;

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  saveForm() {
    this.titleError = false;
    this.validTillError = false;

    if (!this.title) this.titleError = true;
    if (!this.validTill) this.validTillError = true;
    if (!this.title || !this.validTill) return;

    const payload = {
      notificationId: this.modifyChannel ? this.selectedNotificationId : null,
      notificationTitle: this.title,
      notificationDesc: this.desc,
      isUpdate: this.modifyChannel,
      validUpto: this.formatToDdMmYyyyHHmm(this.validTill),
    };

    // ✅ decide action
    const actionRole = this.modifyChannel ? 'EDIT' : 'CREATE';

    this.apiService
      .sendData(ADD_NOTIFICATION, payload, {
        'X-ACTION-ROLE': actionRole,
      })
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.getNotifications();
            this.showToast(
              'success',
              'Success',
              this.modifyChannel
                ? 'Notification Updated Successfully'
                : 'Notification Added Successfully'
            );
            this.backToList();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Operation failed');
        },
      });
  }

  clearFormData() {
    this.title = '';
    this.layout = '';
    this.desc = '';
    this.topicLink = '';
    this.topicTitle = '';
    this.topicTitleError = false;
    this.titleError = false;
    this.layoutError = false;
  }
  createAuditCards(payload: any): AuditCard[] {
    const cards: AuditCard[] = [];
    // 🟢 Maker
    if (payload.makerName && payload.createdAt) {
      cards.push({
        label: 'Maker',
        name: payload.makerName,
        datetime: this.formatAuditDate(payload.createdAt),
        status: 'completed',
      });
    }
    // 🟡 Editor (optional)
    if (payload.editorName && payload.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: payload.editorName,
        datetime: this.formatAuditDate(payload.editedAt),
        status: 'completed',
      });
    }
    // 🔴 Rejected
    if (payload.rejectedBy && payload.rejectedAt) {
      cards.push({
        label: 'Last Rejected By',
        name: payload.rejectedBy,
        datetime: this.formatAuditDate(payload.rejectedAt),
        status: 'completed',
      });
      return cards; // 🚨 stop here if rejected
    }
    // 🟢 Approved
    if (payload.checkerName && payload.approvedAt) {
      cards.push({
        label: 'Last Approved By',
        name: payload.checkerName,
        datetime: this.formatAuditDate(payload.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  auditFnc(row: any) {
    const url = `${GET_NOTIFICATION_BY_ID}?notificationId=${row.id}`;
    this.apiService.getData(url, {}).subscribe({
      next: (res: any) => {
        console.log('Audit API Response:', res);
        if (res?.status === 'SUCCESS' && res?.payload) {
          this.auditCards = this.createAuditCards(res.payload);
        }
        this.isAuditOpen = true;
      },
      error: (err) => {
        console.error('Audit API Error:', err);
      },
    });
  }
}
