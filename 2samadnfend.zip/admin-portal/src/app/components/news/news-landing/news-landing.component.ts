import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../commom/page-title/page-title.component";

@Component({
  selector: 'app-news-landing',
  imports: [PageTitleComponent],
  templateUrl: './news-landing.component.html',
  styleUrl: './news-landing.component.css'
})
export class NewsLandingComponent {

}
