import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SessionTimeoutService } from '../../service/sessionService/session-timeout.service';

@Component({
  selector: 'app-session-expiry',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="session-modal-overlay" *ngIf="sessionService.sessionStatus() !== 'active'">
      <div class="session-modal-card" [class.expired]="sessionService.sessionStatus() === 'expired'">
        <div class="icon-container">
          <i class="fas" [class.fa-clock]="sessionService.sessionStatus() === 'warning'" 
                        [class.fa-user-slash]="sessionService.sessionStatus() === 'expired'"></i>
        </div>
        
        <div class="content" *ngIf="sessionService.sessionStatus() === 'warning'">
          <h3>Session Timing Out</h3>
          <p>Your session will expire soon due to inactivity.</p>
          <div class="timer-display">
            <span class="seconds">{{ sessionService.countdown() }}</span>
            <span class="label">seconds remaining</span>
          </div>
          <button class="btn-stay" (click)="sessionService.resetTimer()">
            <i class="fas fa-play me-2"></i> Stay Logged In
          </button>
        </div>

        <div class="content" *ngIf="sessionService.sessionStatus() === 'expired'">
          <h3>Session Expired</h3>
          <p>Your session has expired. Please login again to continue.</p>
          <button class="btn-login" (click)="sessionService.redirectToLogin()">
             <i class="fas fa-sign-in-alt me-2"></i> Go to Login
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .session-modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(8px);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 99999;
      animation: fadeIn 0.3s ease;
    }

    .session-modal-card {
      background: white;
      padding: 1.5rem;
      border-radius: 16px;
      width: 100%;
      max-width: 360px;
      text-align: center;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
      position: relative;
      border: 1px solid rgba(255,255,255,0.1);
    }

    .icon-container {
      width: 60px;
      height: 60px;
      background: #fff5f5;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 0 auto 1rem;
    }

    .icon-container i {
      font-size: 1.5rem;
      color: #e53e3e;
    }

    .session-modal-card.expired .icon-container {
      background: #f7fafc;
    }
    
    .session-modal-card.expired .icon-container i {
      color: #4a5568;
    }

    h3 {
      font-size: 1.25rem;
      font-weight: 700;
      color: #1a202c;
      margin-bottom: 0.25rem;
    }

    p {
      color: #718096;
      margin-bottom: 1.5rem;
      font-size: 0.9rem;
    }

    .timer-display {
      margin-bottom: 1.5rem;
    }

    .seconds {
      display: block;
      font-size: 2.5rem;
      font-weight: 800;
      color: #e53e3e;
      line-height: 1;
    }

    .label {
      font-size: 0.875rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #a0aec0;
      font-weight: 600;
    }

    .btn-stay {
      width: 100%;
      padding: 1rem;
      background: #e53e3e;
      color: white;
      border: none;
      border-radius: 12px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .btn-stay:hover {
      background: #c53030;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(229, 62, 62, 0.3);
    }

    .btn-login {
      width: 100%;
      padding: 1rem;
      background: #4a5568;
      color: white;
      border: none;
      border-radius: 12px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .btn-login:hover {
      background: #2d3748;
      transform: translateY(-2px);
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
  `]
})
export class SessionExpiryComponent {
  public sessionService = inject(SessionTimeoutService);
}
