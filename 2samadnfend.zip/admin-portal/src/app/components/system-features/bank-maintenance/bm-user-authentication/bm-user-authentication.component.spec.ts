import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BmUserAuthenticationComponent } from './bm-user-authentication.component';

describe('BmUserAuthenticationComponent', () => {
  let component: BmUserAuthenticationComponent;
  let fixture: ComponentFixture<BmUserAuthenticationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BmUserAuthenticationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BmUserAuthenticationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
