import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BmUserProfileComponent } from './bm-user-profile.component';

describe('BmUserProfileComponent', () => {
  let component: BmUserProfileComponent;
  let fixture: ComponentFixture<BmUserProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BmUserProfileComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BmUserProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
