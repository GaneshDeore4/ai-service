import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmAuthenticationComponent } from './cm-authentication.component';

describe('CmAuthenticationComponent', () => {
  let component: CmAuthenticationComponent;
  let fixture: ComponentFixture<CmAuthenticationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CmAuthenticationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmAuthenticationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
