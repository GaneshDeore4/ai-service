import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SelectModule } from 'primeng/select';
import { FloatLabelModule } from 'primeng/floatlabel';
import COUNTRIES_DATA from '../../../../constants/Countries';
import {
  ADD_AUTH_MATRIX,
  AUTH_MATRIX_APPROVE,
  AUTH_MATRIX_REJECT,
  GET_ALL_AUTH_MATRIX,
  GET_ALL_MASTER_PRODUCT,
  GET_ALL_SUBPRO_BY_PRO_LIST,
  GET_AUTH_MATRIX_BY_ID,
  GET_AUTH_GROUPS,
  GET_ALL_TXN_COMPANIES,
  GET_ALL_TEMP_COMPANIES,
  GET_GROUPED_AUTH_MATRIX,
  APPROVE_GROUPED_MATRIX,
  GET_PRODUCTS_BY_CATEGORY_ID,
  GET_SUBPRODUCTS_BY_PRODUCT_ID,
  GET_ALL_COMPANIES,
  GET_ACCOUNT_BY_CIF,
  VALIDATE_OTP,
  SEND_OTP,
} from '../../../../constants/api_endpoints';
import { ApiService } from '../../../../service/apiService/api.service';
import { SessionService } from '../../../../service/sessionService/session.service';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
// import { TableComponent } from '../../../../commom/table/table.component';
import { TabsModule } from 'primeng/tabs';
import {
  BANKSETUPCHECKER,
  BANKSETUPMAKER,
  BANKSUPERADMINCHECKER,
  BANKSUPERADMINMAKER,
  COMPANY_CATERGORY_ID,
  COMPANY_CATERGORY_NAME,
  PAGE_SIZE,
  SUPERADMIN,
} from '../../../../constants/Constants';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  AuditCard,
  UserAuditComponent,
} from '../../../../commom/user-audit/user-audit.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { OtpComponent } from "../../../../commom/otp/otp.component";

interface Account {
  id: string;
  accountNumber: string;
  currency: string;
  schemeDescription: string;
  schemeType: string;
}
export interface SubproductEntity {
  subProductId?: number;
  // productName?:string,
  // productId?:number,
  // categoryId?:number,
  // categoryList?:string,
  subProductName?: string;
}
interface ProductEntity {
  productId?: number;
  productName?: string;
  categoryId?: number;
  categoryName?: string;
}

@Component({
  selector: 'app-cm-authorisations',
  /* imports: [
    PageTitleComponent,
    NgIf,
    NgFor,
    NgClass,
    FormsModule,
    TblComponent,
    PopupComponent,
    SelectModule,
    FloatLabelModule,
    TableComponent,
    TabsModule,
    LoaderComponent
  ], */
  imports: [
    PageTitleComponent,
    NgIf,
    NgFor,
    NgClass,
    FormsModule,
    TblComponent,
    ToastComponent,
    SelectModule,
    FloatLabelModule,
    TabsModule,
    LoaderComponent,
    UserAuditComponent,
    MultiSelectModule,
    OtpComponent
  ],
  templateUrl: './cm-authorisations.component.html',
  styleUrl: './cm-authorisations.component.css',
})
export class CmAuthorisationsComponent implements OnInit {
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  constructor(
    private apiService: ApiService,
    private sessionService: SessionService,
    private cdr: ChangeDetectorRef
  ) {
    this.role = this.sessionService.getRole() || '';
    if (this.role == BANKSUPERADMINMAKER || this.role == BANKSETUPMAKER) {
      this.actionList = ['view', 'edit', 'audit'];
    }
    else this.actionList = ['view', 'audit'];
  }
  ngOnInit() {
    this.getCompanyList();
    this.getAuthGroups();
  }
  isLoading = false;
  actionList: string[] = [];
  productData: ProductEntity[] = [];
  subProductData: SubproductEntity[] = [];
  originalAccountIds: string[] = [];
  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'CMProfileTable';
  originalCurrency: string | null = null;
  originalProduct: number | null = null;
  originalSubProduct: number | null = null;
  originalAuthLevels: string[] = [];
  originalIsSequential = false;
  originalIsVerifier = false;
  originalIsReleaser = false;
  approveRejectAvailable(): boolean {
    if (
      (this.role == BANKSUPERADMINCHECKER ||
        this.role == BANKSETUPCHECKER ||
        this.role == SUPERADMIN) &&
      this.showButtons
    )
      return true;
    else return false;
  }
  addBtnAllowed(): boolean {
    if (
      this.role == BANKSUPERADMINMAKER ||
      this.role == BANKSETUPMAKER ||
      this.role == SUPERADMIN
    )
      return true;
    else return false;
  }
  //main page vars--------------------------
  searchAbbreviatedName = '';
  searchName = '';
  countryData = COUNTRIES_DATA;
  currentAuthMatId: number | null = null;
  showButtons: boolean | null = null;
  role = '';
  selectedAccounts: Account[] = [];
  currentCompanyId: number | null = null;
  searchData(): void {
    const filtered = this.ogData.filter((item) => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']
          ?.toLowerCase()
          .includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']
          ?.toLowerCase()
          .includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  showAuthorisation = false;

  // companyHeader = ['abbvName', 'name', 'Action'];

  companyHeader: { key: string; value: string }[] = [
    { key: 'abbvName', value: 'Customer ID' },
    { key: 'name', value: 'Name' },
    { key: 'status', value: 'Status' },
    // { key: 'createdBy', value: 'Maker' },
    { key: 'Action', value: 'Action' },
  ];

  customerData: any[] = [];
  ogData: any[] = [];
  customerColumnWidth = ['40%', '50%', '10%'];
  currentCustomer = {};
  currentCustomerName: string = '';
  currentName: string = '';
  // viewCustomerf(row: any, index: number) {
  //   this.currentCustomer = row;
  //   this.currentCustomerName = row['abbvName'] || row['Abbreviated Name'] || '';
  //   this.currentName = row['companyId'] || row['Company Name'] || '';
  //   this.currentCompanyId = row.companyId;
  //   this.showAuthorisation = true;

  //   // Ensure products are loaded before fetching matrix to have correct names
  //   this.getAllProducts(() => {
  //     this.fetchMergedAuthMatrix();
  //   });
  // }
  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentCustomerName = row['abbvName'] || row['Abbreviated Name'] || '';
    this.currentCompanyId = row.companyId;
    const cifId = row.cif || row.cifId;
    this.showAuthorisation = true;
    // ✅ ONLY HERE control loader
    this.isLoading = true;
    this.getAccountsByCif(cifId, () => {
      this.getAllProducts(() => {
        this.fetchMergedAuthMatrix(() => {
          this.isLoading = false;
        });
      });
    });
  }

  getCompanyList() {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_ALL_COMPANIES +
        '?page=' +
        (this.pageNumber - 1) +
        '&size=' +
        this.pageSize,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.customerData = res['payload']['content'];
            this.ogData = [...this.customerData];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
          }
        },
        error: (err: any) => {
          console.error('Failed to load companies', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getAuthGroups() {
    this.apiService.getData(GET_AUTH_GROUPS, {}).subscribe({
      next: (res: any) => {
        if (res && res.payload) {
          this.authGroupMap = res.payload;
          this.authLevelDropdown = res.payload.map(
            (group: any) => group.authGroup
          );
        }
      },
      error: (err: any) => console.error('ERROR fetching AuthGroups', err),
    });
  }

  //customer auth page vars----------------------------
  searchTypeList = ['New', 'Amend', 'Message'];
  selectedSearchType = '';
  selectedSearchStatus = '';
  selectedSearchProductHeader: number | null = null;
  addAuthForm = false;
  viewAuth = false;
  editAuth = false;
  editIndex = 0;
  existingAuthGroupIds: number[] = [];

  productMap: Map<number, string> = new Map();
  subProductMap: Map<number, string> = new Map();

  authHeaders = [
    // { key: 'isVerifier', value: 'Verifier' },
    // { key: 'isReleaser', value: 'Releaser' },
    { key: 'productName', value: 'Product' },
    // { key: 'subProductName', value: 'Subproduct' },
    // { key: 'eventType', value: 'Event Type' },
    { key: 'currencyType', value: 'Currency' },
    { key: 'amount', value: 'Amount' },
    { key: 'authGroupsFormatted', value: 'authGroup' },
    { key: 'status', value: 'Status' },
    // { key: 'createdBy', value: 'Maker' },
    { key: 'Action', value: 'Action' },
    // { key: 'Audit', value: 'Audit-trail' },
  ];

  isAuditOpen = false;
  channelRef = 'CH123456';

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }
  auditCards: AuditCard[] = [
    {
      label: 'Maker',
      name: 'ABC',
      datetime: '10 Apr 2026, 10:00 AM',
      status: 'completed',
    },
    {
      label: 'Checker',
      name: 'XYZ',
      datetime: '10 Apr 2026, 11:00 AM',
      status: 'completed',
    },
  ];
  // auditFnc(row: any) {
  //   let url = '';
  //   // 🔴 Handle grouped vs individual
  //   if (row.ids) {
  //     // grouped
  //     url = `${GET_GROUPED_AUTH_MATRIX}?ids=${row.ids}`;
  //   } else {
  //     // individual
  //     url = `${GET_AUTH_MATRIX_BY_ID}?id=${row.authMatId}&category=${COMPANY_CATERGORY_NAME}`;
  //   }
  //   this.apiService.getData(url, {}).subscribe({
  //     next: (res: any) => {
  //       console.log('Auth Audit Response:', res);
  //       if (res?.status === 'SUCCESS' && res?.payload) {
  //         this.auditCards = this.createAuditCards(res.payload);
  //       }
  //       this.isAuditOpen = true;
  //     },
  //     error: (err) => {
  //       console.error('Audit API Error:', err);
  //     },
  //   });
  // }
  onCurrencyChange() {
    this.selectedAccounts = [];
    console.log("selected currecy: " + this.addCurrency);
    let filteredAccountList = this.ogAccountList.filter((account: Account) => {
      return account.currency === this.addCurrency;
    });
    console.log("filtered account list: " + JSON.stringify(filteredAccountList, null, 2));
    this.accountList = [...filteredAccountList];
  }
  accountList: Account[] = [];
  ogAccountList: Account[] = [];
  getAccountsByCif(cifId: string, callback?: () => void) {
    this.isLoading = true;

    this.apiService.getData(GET_ACCOUNT_BY_CIF + '/' + cifId, {}).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.accountList = res.payload;
          this.ogAccountList = [...this.accountList];
          console.log('Accounts:', this.accountList); // debug

          if (callback) callback(); // ✅ important
        }
      },
      error: (err: any) => {
        this.isLoading = false
        this.showToast('error', 'Error', 'Failed to sync accounts');
        console.error(err);
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  auditFnc(row: any) {
    let url = '';
    // 🔴 GROUPED ROW
    if (row.ids) {
      url = `${GET_GROUPED_AUTH_MATRIX}?ids=${row.ids}`;
    }
    // 🟢 INDIVIDUAL ROW
    else {
      url = `${GET_AUTH_MATRIX_BY_ID}?id=${row.authMatId}&category=${COMPANY_CATERGORY_NAME}`;
    }
    this.apiService.getData(url, {}).subscribe({
      next: (res: any) => {
        console.log('Audit Response:', res);
        if (res?.status === 'SUCCESS' && res?.payload) {
          this.auditCards = this.createAuditCards(res.payload);
        }
        this.isAuditOpen = true;
      },
      error: (err) => {
        console.error('Audit API Error:', err);
      },
    });
  }

  createAuditCards(payload: any): AuditCard[] {
    const cards: AuditCard[] = [];
    // 🟢 Maker
    if (payload.makerName && payload.createdAt) {
      cards.push({
        label: 'Maker',
        name: payload.makerName,
        datetime: this.formatAuditDate(payload.createdAt),
        status: 'completed',
      });
    }
    // 🟡 Modified
    if (payload.editorName && payload.editedAt) {
      cards.push({
        label: 'Last Modified By',
        name: payload.editorName,
        datetime: this.formatAuditDate(payload.editedAt),
        status: 'completed',
      });
    }
    // 🔴 Rejected
    if (payload.rejectedBy && payload.rejectedAt) {
      cards.push({
        label: 'Rejected By',
        name: payload.rejectedBy,
        datetime: this.formatAuditDate(payload.rejectedAt),
        status: 'completed',
      });
      return cards; // stop flow
    }
    // 🟢 Approved
    if (payload.checkerName && payload.approvedAt) {
      cards.push({
        label: 'Last Approved By',
        name: payload.checkerName,
        datetime: this.formatAuditDate(payload.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(dateStr: string): string {
    if (!dateStr) return '';
    try {
      let date: Date;
      if (dateStr.includes('T')) {
        date = new Date(dateStr);
      } else {
        const parts = dateStr.trim().split(' ');
        const [datePart, timePart, meridian] = parts;
        const [day, month, year] = datePart.split('-').map(Number);
        let [hours, minutes, seconds] = timePart.split(':').map(Number);
        if (meridian?.toLowerCase() === 'pm' && hours < 12) hours += 12;
        if (meridian?.toLowerCase() === 'am' && hours === 12) hours = 0;
        date = new Date(year, month - 1, day, hours, minutes, seconds);
      }
      if (isNaN(date.getTime())) return dateStr;
      return date.toLocaleString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  }

  authColWidth = [
    '8%',
    '6%',
    '6%',
    '8%',
    '12%',
    '8%',
    '8%',
    '8%',
    '8%',
    '8%',
    '8%',
    '6%',
    '6%',
  ];
  authData: any[] = [];
  ogAuthData = this.authData;
  selectedProduct: number | null = null;
  selectedSubProduct: number | null = null;
  subProductDisable = false;
  onProductBlur() {
    this.selectedSubProduct = -1;
    if (this.selectedProduct == -1) {
      this.subProductDisable = true;
    } else {
      this.subProductDisable = false;
      this.getAllSubproByProList();
    }
  }
  getAllSubproByProList() {
    if (!this.selectedProduct) return;
    this.apiService
      .getData(
        GET_SUBPRODUCTS_BY_PRODUCT_ID + '?productId=' + this.selectedProduct,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.subProductData = [];
            this.subProductData = res['payload'];
          }
        },
        error: (err: any) => { },
      });
  }

  getAllProducts(callback?: () => void) {
    this.apiService
      .getData(
        GET_PRODUCTS_BY_CATEGORY_ID + '?categoryId=' + COMPANY_CATERGORY_ID,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.productData = res['payload'];
            this.productData.forEach((p) => {
              if (p.productId !== undefined && p.productName !== undefined) {
                this.productMap.set(p.productId, p.productName);
              }
            });
            this.productData.unshift({
              productId: -1,
              productName: 'ALL',
            });
            this.productMap.set(-1, 'ALL');
            if (callback) callback();
          }
        },
        error: (err: any) => {
          console.log(err);
        },
        complete: () => {
          console.log('Data was fetched');
        },
      });
    // this.productData.push({productId:1,productName:'Remittance'});
  }

  extractGroups(authGroup: any[]): string[] {
    if (!authGroup) return [];

    return authGroup.map((g: any) => {
      const key = Object.keys(g)[0];
      return key.split('-')[1];
    });
  }

  // fetchMergedAuthMatrix() {
  //   this.isLoading = true;
  //   this.authData = [];
  //   const data = { page: 0, size: 100 };

  //   // Fetch Individual
  //   // this.apiService.getData(GET_ALL_AUTH_MATRIX + '?category=' + COMPANY_CATERGORY_NAME, data).subscribe({
  //   this.apiService
  //     .getData(
  //       GET_ALL_AUTH_MATRIX +
  //         '?category=' +
  //         COMPANY_CATERGORY_NAME +
  //         '&companyId=' +
  //         this.currentCompanyId,
  //       data
  //     )
  //     .subscribe({
  //       next: (resIndi: any) => {
  //         let indiRecords = [];
  //         if (resIndi.status === 'SUCCESS') {
  //           indiRecords = (resIndi.payload?.content || []).map((item: any) =>
  //             this.mapAuthItem(item)
  //           );
  //         }

  //         // Fetch Grouped
  //         // this.apiService.getData(GET_GROUPED_AUTH_MATRIX + '?category=' + COMPANY_CATERGORY_NAME, data).subscribe({
  //         this.apiService
  //           .getData(
  //             GET_GROUPED_AUTH_MATRIX +
  //               '?category=' +
  //               COMPANY_CATERGORY_NAME +
  //               '&companyId=' +
  //               this.currentCompanyId,
  //             data
  //           )
  //           .subscribe({
  //             next: (resGroup: any) => {
  //               let groupRecords = [];
  //               if (resGroup.status === 'SUCCESS') {
  //                 groupRecords = (resGroup.payload?.content || []).map(
  //                   (item: any) => this.mapAuthItem(item)
  //                 );
  //               }

  //               this.authData = [...indiRecords, ...groupRecords];
  //               this.ogAuthData = [...this.authData];
  //               this.isLoading = false;
  //             },
  //             error: (err: any) => {
  //               console.error('Error fetching grouped auth matrix', err);
  //               this.authData = [...indiRecords];
  //               this.ogAuthData = [...this.authData];
  //               this.isLoading = false;
  //             },
  //           });
  //       },
  //       error: (err: any) => {
  //         console.error('Error fetching indi auth matrix', err);
  //         this.isLoading = false;
  //       },
  //     });
  // }
  fetchMergedAuthMatrix(callback?: () => void) {
    this.authData = [];
    const data = { page: 0, size: 100 };
    this.apiService
      .getData(
        GET_ALL_AUTH_MATRIX +
        '?category=' +
        COMPANY_CATERGORY_NAME +
        '&companyId=' +
        this.currentCompanyId,
        data
      )
      .subscribe({
        next: (resIndi: any) => {
          console.log(resIndi.payload?.content);
          let indiRecords: any[] = [];
          if (resIndi.status === 'SUCCESS') {
            indiRecords = (resIndi.payload?.content || []).map((item: any) =>
              this.mapAuthItem(item)
            );
          }
          this.apiService
            .getData(
              GET_GROUPED_AUTH_MATRIX +
              '?category=' +
              COMPANY_CATERGORY_NAME +
              '&companyId=' +
              this.currentCompanyId,
              data
            )
            .subscribe({
              next: (resGroup: any) => {
                console.log(resGroup);
                let groupRecords = [];
                if (resGroup.status === 'SUCCESS') {
                  groupRecords = (resGroup.payload?.content || []).map(
                    (item: any) => this.mapAuthItem(item)
                  );
                }
                this.authData = [...indiRecords, ...groupRecords];
                this.ogAuthData = [...this.authData];
                if (callback) callback(); // ✅ stop loader here
              },
              error: () => {
                this.authData = [...indiRecords];
                this.ogAuthData = [...this.authData];
                if (callback) callback(); // ✅ stop loader even on error
              },
            });
        },
        error: () => {
          if (callback) callback(); // ✅ stop loader
        },
      });
  }

  mapAuthItem(item: any) {
    const groups = item.authGroup
      ? item.authGroup.map((g: any) => {
        const key = Object.keys(g)[0];
        return key.split('-')[1];
      })
      : [];
    return {
      createdBy: item.createdBy,
      allProductFlag: item.allProductFlag,
      eventType: item.eventType,
      type: item.type,
      currencyType: item.currencyType,
      amount: item.amount,
      authGroup: item.authGroup,
      authGroupsFormatted: groups.join(', '),
      status: item.status || 'PENDING',
      authMatId: item.authMatId,
      productId: item.productId,
      productName: item.isAllProductFlag
        ? 'All'
        : this.productMap.get(item.productId) || item.productId,
      subProductId: item.subProductId,
      subProductName:
        this.subProductMap.get(item.subProductId) || item.subProductId,
      isVerifier: item.isVerifier,
      isReleaser: item.isReleaser,
      isSequential: item.isSequential,
      ids: item.ids,
      accounts: item.accounts
    };
  }
  getGroupedAuthMatrix() {
    this.isLoading = true;
    const data = {
      page: 0,
      size: 10,
    };
    this.apiService
      .getData(
        GET_GROUPED_AUTH_MATRIX + '?category=' + COMPANY_CATERGORY_NAME,
        data
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.authData = [];
            const data = res.payload?.content || [];
            this.authData = data.map((item: any) => {
              const groups = item.authGroup
                ? item.authGroup.map((g: any) => {
                  const key = Object.keys(g)[0]; // "1-A"
                  return key.split('-')[1]; // "A"
                })
                : [];
              return {
                createdBy: item.createdBy,
                eventType: item.eventType,
                allProductFlag: item.allProductFlag,
                type: item.type,
                currencyType: item.currencyType,
                amount: item.amount,
                authGroup: item.authGroup,
                authGroupsFormatted: groups.join(', '), // A, B
                status: item.status || 'PENDING',
                authMatId: item.authMatId,
                productId: item.productId,
                subProductId: item.subProductId,
                isVerifier: item.isVerifier,
                isReleaser: item.isReleaser,
                isSequential: item.isSequential,
                ids: item.ids,
                accounts: item.accounts
              };
            });
            this.authData = [...this.authData];
            console.log(
              'grouped auth data: ' + JSON.stringify(this.authData, null, 2)
            );
          }
        },
        error: (err: any) => {
          console.error('Error fetching auth matrix', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  getIndiAuthMatrix() {
    this.isLoading = true;
    const data = {
      page: 0,
      size: 10,
    };
    this.apiService
      .getData(
        GET_ALL_AUTH_MATRIX + '?category=' + COMPANY_CATERGORY_NAME,
        data
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.authData = [];
            const data = res.payload?.content || [];
            this.authData = data.map((item: any) => {
              const groups = item.authGroup
                ? item.authGroup.map((g: any) => {
                  const key = Object.keys(g)[0]; // "1-A"
                  return key.split('-')[1]; // "A"
                })
                : [];
              return {
                createdBy: item.createdBy,
                allProductFlag: item.allProductFlag,
                eventType: item.eventType,
                type: item.type,
                currencyType: item.currencyType,
                amount: item.amount,
                authGroupsFormatted: groups.join(', '), // A, B
                status: item.status || 'PENDING',
                authMatId: item.authMatId,
                productId: item.productId,
                subProductId: item.subProductId,
                isSequential: item.isSequential,
                isVerifier: item.isVerifier,
                isReleaser: item.isReleaser,
                accounts: item.accounts
              };
            });
            this.authData = [...this.authData];
            console.log(
              'INDI auth data: ' + JSON.stringify(this.authData, null, 2)
            );
          }
        },
        error: (err: any) => {
          console.error('Error fetching auth matrix', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getAuthMatrixById(id: number, mode: 'view' | 'edit') {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_AUTH_MATRIX_BY_ID +
        '?id=' +
        id +
        '&category=' +
        COMPANY_CATERGORY_NAME,
        {}
      )
      .subscribe({
        // next: (res: any) => {
        //   if (res.status === 'SUCCESS') {
        //     const data = res.payload;
        //     this.originalCurrency = data.currencyType;
        //     this.originalProduct = data.productId;
        //     this.originalSubProduct = data.subProductId;
        //     this.originalAuthLevels = [...this.authLevelList];
        //     this.originalIsSequential = data.isSequential;
        //     this.originalIsVerifier = data.isVerifier;
        //     this.originalIsReleaser = data.isReleaser;
        //     console.log(JSON.stringify(data, null, 2));
        //     // store id for edit
        //     this.editIndex = data.authMatId;
        //     this.selectedAccounts = (data.accounts || [])
        //       .map((acc: any) => {
        //         return this.accountList.find((a) => a.id === acc.id);
        //       })
        //       .filter(Boolean);
        //     this.originalAccountIds = this.selectedAccounts.map(
        //       (acc) => acc.id
        //     );
        //     // open form
        //     this.showAuthorisation = false;
        //     this.addAuthForm = true;

        //     this.viewAuth = mode === 'view';
        //     this.editAuth = mode === 'edit';

        //     // this.SelectedAuthType =
        //     //   data.eventType.length > 1 ? 'ALL' : data.eventType[0];
        //     // console.log('selected auth type: ' + this.SelectedAuthType);

        //     this.selectedProduct = data.productId || 0;

        //     this.addCurrency = data.currencyType || null;
        //     this.addAmount = data.amount || '';
        //     this.oldAmount = data.amount || '';

        //     this.isSequential = data.isSequential;
        //     this.isVerifier = data.isVerifier;
        //     this.isReleaser = data.isReleaser;

        //     this.existingAuthGroupIds = data.authGroup
        //       ? data.authGroup.map((g: any) => {
        //           const key = Object.keys(g)[0]; // "1-A"
        //           return Number(key.split('-')[0]); // 1
        //         })
        //       : [];
        //     this.authLevelList = data.authGroup
        //       ? data.authGroup.map((g: any) => {
        //           const key = Object.keys(g)[0]; // "1-A"
        //           return key.split('-')[1]; // "A"
        //         })
        //       : [];

        //     // load dropdowns
        //     this.getAllProducts();

        //     // load sub products AFTER product set
        //     this.getAllSubproByProList();

        //     // set sub product
        //     this.selectedSubProduct = data.subProductId || 0;
        //   }
        // },
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            const data = res.payload;
            this.editIndex = data.authMatId;
            this.selectedAccounts = (data.accounts || [])
              .map((acc: any) => {
                return this.accountList.find((a) => a.id === acc.id);
              })
              .filter(Boolean);
            this.originalAccountIds = this.selectedAccounts.map(
              (acc) => acc.id
            );
            this.showAuthorisation = false;
            this.addAuthForm = true;
            this.viewAuth = mode === 'view';
            this.editAuth = mode === 'edit';
            this.selectedProduct = data.productId || 0;
            this.addCurrency = data.currencyType || null;
            this.addAmount = data.amount || '';
            this.oldAmount = data.amount || '';
            this.isSequential = data.isSequential;
            this.isVerifier = data.isVerifier;
            this.isReleaser = data.isReleaser;
            // ✅ FIRST populate
            this.authLevelList = data.authGroup
              ? data.authGroup.map((g: any) => {
                const key = Object.keys(g)[0];
                return key.split('-')[1];
              })
              : [];
            this.selectedSubProduct = data.subProductId || 0;
            // ✅ NOW store originals (IMPORTANT ORDER)
            this.originalCurrency = this.addCurrency;
            this.originalProduct = this.selectedProduct;
            this.originalSubProduct = this.selectedSubProduct;
            this.originalAuthLevels = [...this.authLevelList];
            this.originalIsSequential = this.isSequential;
            this.originalIsVerifier = this.isVerifier;
            this.originalIsReleaser = this.isReleaser;
            // load dropdowns
            this.getAllProducts();
            this.getAllSubproByProList();
          }
        },

        error: (err: any) => {
          console.error('Error fetching auth matrix', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  hasAccountChanged(): boolean {
    const current = this.selectedAccounts.map((acc) => acc.id).sort();
    const original = [...this.originalAccountIds].sort();

    if (current.length !== original.length) return true;

    return !current.every((val, index) => val === original[index]);
  }
  compareArrays(a: string[], b: string[]): boolean {
    if (a.length !== b.length) return false;
    const sortedA = [...a].sort();
    const sortedB = [...b].sort();
    return sortedA.every((val, i) => val === sortedB[i]);
  }


  hasAnyChange(): boolean {
    return (
      this.hasAccountChanged() ||
      this.addAmount !== this.oldAmount ||
      this.addCurrency !== this.originalCurrency ||
      this.selectedProduct !== this.originalProduct ||
      this.selectedSubProduct !== this.originalSubProduct ||
      !this.compareArrays(this.authLevelList, this.originalAuthLevels) ||
      this.isSequential !== this.originalIsSequential ||
      this.isVerifier !== this.originalIsVerifier ||
      this.isReleaser !== this.originalIsReleaser
    );
  }


  searchAuth(): void {
    const filtered = this.ogAuthData.filter((item) => {
      const matchType = this.selectedSearchType
        ? item['eventType']
          ?.toString()
          .toLowerCase()
          .includes(this.selectedSearchType.toLowerCase())
        : true;

      const matchProduct = this.selectedSearchProductHeader
        ? item['productId'] === this.selectedSearchProductHeader ||
        (this.selectedSearchProductHeader === -1 && item['allProductFlag'])
        : true;

      const matchStatus = this.selectedSearchStatus
        ? item['status']
          ?.toString()
          .toLowerCase()
          .includes(this.selectedSearchStatus.toLowerCase())
        : true;

      return matchType && matchProduct && matchStatus;
    });

    this.authData = [...filtered]; // ✅ Update reference for change detection
  }
  addAuthF() {
    this.authLevelHeaders = ['Authorisation Level', 'Action'];
    this.editIndex = -1;
    this.getAllProducts();
    this.addCurrency = null;
    this.showAuthorisation = false;
    this.addAuthForm = true;
    this.selectedAccounts = [];
  }

  viewAuthF(row: any, index: number) {
    this.authLevelHeaders = ['Authorisation Level'];
    this.viewAuth = true;
    this.showButtons = row.status == 'PENDING' ? true : false;

    if (row.ids) {
      // It's a grouped row
      this.assignAddPageData(row);
    } else {
      // It's an individual row
      this.currentAuthMatId = row.authMatId;
      this.getAuthMatrixById(row.authMatId, 'view');
    }
    this.addAuthForm = true;
  }
  editAuthF(row: any, index: number) {
    this.authLevelHeaders = ['Authorisation Level', 'Action'];
    this.editIndex = index;
    if (row.ids) {
      // It's a grouped row
      this.assignAddPageData(row);
    } else {
      // It's an individual row
      this.currentAuthMatId = row.authMatId;
      this.getAuthMatrixById(row.authMatId, 'edit');
    }
    this.addAuthForm = true;
  }

  approveAuth() {
    this.isLoading = true;
    let url: string = '';
    let data: any = {};

    if (this.groupedRowIds && this.groupedRowIds.length > 0) {
      url = APPROVE_GROUPED_MATRIX;
      data['authMatrixIds'] = this.groupedRowIds;
    } else {
      url = AUTH_MATRIX_APPROVE + '?id=' + this.currentAuthMatId;
    }

    this.apiService
      .sendData(url, data, {
        'X-ACTION-ROLE': 'APPROVE',
      })
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.showToast('success', 'Success', 'Authorisation Approved');
            this.fetchMergedAuthMatrix();
            this.closeAddAuthf();
            this.checkerAction = '';
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err: any) => {
          this.showToast('error', 'Error', 'Something Went wrong');

          console.error('Approve error', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  rejectAuth() {
    this.isLoading = true;

    let url: string = '';
    let data: any = {};

    if (this.groupedRowIds && this.groupedRowIds.length > 0) {
      url = AUTH_MATRIX_REJECT; // ✅ correct API
      data['authMatrixIds'] = this.groupedRowIds;
    } else {
      url = AUTH_MATRIX_REJECT + '?id=' + this.currentAuthMatId;
    }

    this.apiService
      .sendData(url, data, {
        'X-ACTION-ROLE': 'REJECT',
      })
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.showToast('success', 'Success', 'Authorisation Rejected');
            this.fetchMergedAuthMatrix();
            this.closeAddAuthf();
            this.checkerAction = '';
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err: any) => {
          this.showToast('error', 'Error', 'Something Went wrong');
          console.error('Reject error', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  authMatId: number | null = null;
  groupedRowIds: number[] = [];
  assignAddPageData(row: any) {
    this.subProductDisable = true;
    this.productData.unshift({
      productId: -1,
      productName: 'ALL',
    }); //PRODUCTS DATA IS EMPTY AND WE NEED NO PRODUCTS HERE.
    console.log('product data: ' + JSON.stringify(this.productData, null, 2));
    this.groupedRowIds = row.ids.split(',').map((id: string) => Number(id));
    console.log(this.groupedRowIds);
    this.addAmount = row.amount;
    this.oldAmount = row.amount;
    this.authMatId = row.authMatId; //this is undefined because not recieved from api
    this.addCurrency = row.currencyType;
    // this.SelectedAuthType = row.eventType.length > 1 ? 'ALL' : row.eventType[0];
    this.isReleaser = row.isReleaser;
    this.isVerifier = row.isVerifier;
    this.isSequential = row.isSequential;
    this.selectedProduct = -1; //this will be always -1 bcoz we are coming from all products list
    this.selectedSubProduct = -1;
    this.cdr.detectChanges();
    this.selectedSubProduct = row.subProductId;
    this.existingAuthGroupIds = row.authGroup
      ? row.authGroup.map((g: any) => {
        const key = Object.keys(g)[0]; // "1-A"
        return Number(key.split('-')[0]); // 1
      })
      : [];
    this.authLevelList = row.authGroup
      ? row.authGroup.map((g: any) => {
        const key = Object.keys(g)[0]; // "1-A"
        return key.split('-')[1]; // "A"
      })
      : [];

    this.selectedAccounts = (row.accounts || [])
      .map((acc: any) => {
        return this.accountList.find((a) => a.id === (acc.id ?? acc)) || acc;
      })
      .filter(Boolean);
    this.cdr.detectChanges();
    console.log("selected row for view edit: " + JSON.stringify(row, null, 2));
    console.log("selected accounts after assigning: " + JSON.stringify(this.selectedAccounts, null, 2));
  }

  deleteAuthF(index: number): void {
    if (index >= 0 && index < this.authData.length) {
      this.authData.splice(index, 1);
      this.authData = [...this.authData]; // ✅ Update reference for change detection
    }
  }

  // addAuth form vars
  authTypeList: string[] = ['ALL', 'AMEND', 'CLOSE', 'NEW', 'PAYMENT'];
  SelectedAuthType: string = '';
  authProdList = ['Bankers Guarantee Received', 'Remittance'];
  selectedAuthProd = '';
  get authSubprodTypeList(): string[] {
    return this.showDependents()
      ? ['Demand Guarantee', 'Dependent Undertaking', 'Standby']
      : ['Inward Remittance', 'Outward Remittance'];
  }
  selectedAuthSubprodType = '';
  authProdTypeList = ['Customs', 'Judicial', 'Direct Pay'];
  selectedProdType = '';
  authTenorList = ['upto 1 year', 'upto 3 years', 'upto 5 years'];
  selectedTenor = '';
  addCurrency: string | null = null;
  addAmount = '';
  oldAmount = '';
  isSequential = false;
  isVerifier = false;
  isReleaser = false;

  typeError = false;
  productError = false;
  productTypeError = false;
  subProductTypeError = false;
  tenorError = false;
  currencyError = false;
  amountError = false;

  showDependents(): Boolean {
    //this funtion is used to show prod type and tenor based on product selection
    return this.selectedAuthProd == 'Bankers Guarantee Received' ? true : false;
  }

  authLevelHeaders: string[] = ['Authorisation Level', 'Action'];
  authLevelColumnWidths = ['50%', '50%'];
  authLevelList: string[] = [];
  authLevelDropdown: string[] = [];
  authGroupMap: any[] = [];
  selectedAuthLevelDropdown = '';
  authLevelSelectorError = false;
  openAuthLevel = false;
  editAuthLevel = false;
  authLevelIndex: number = -1;

  //functions for popup
  addAuthLevelf() {
    this.openAuthLevel = true;
  }
  editAuthLevelf(index: number) {
    this.authLevelIndex = index;
    this.editAuthLevel = true;
    this.selectedAuthLevelDropdown = this.authLevelList[index];
    this.addAuthLevelf();
  }
  deleteAuthLevelf(index: number) {
    this.authLevelList = this.authLevelList.filter((_, i) => i !== index);
  }

  saveAuthLevelf() {
    if (this.selectedAuthLevelDropdown == '') {
      this.authLevelSelectorError = true;
      return;
    }
    if (this.authLevelIndex > -1) {
      this.authLevelList.splice(
        this.authLevelIndex,
        1,
        this.selectedAuthLevelDropdown
      );
    } else {
      this.authLevelList.push(this.selectedAuthLevelDropdown);
    }
    this.closeAuthLevelPopup();
  }
  closeAuthLevelPopup() {
    this.openAuthLevel = false;
    this.editAuthLevel = false;
    this.authLevelIndex = -1;
    this.authLevelSelectorError = false;
    this.selectedAuthLevelDropdown = '';
  }

  saveAuthf() {
    if (!this.validateAuth()) return;
    if (this.editIndex !== -1 && !this.hasAnyChange()) {
      this.showToast(
        'warning',
        'Warning',
        'No changes detected. Please modify something before saving.'
      );
      return;
    }
    this.isLoading = true;
    const authGroupIds = this.authLevelList
      .map((level) => {
        const match = this.authGroupMap.find((g: any) => g.authGroup === level);
        return match ? match.id : null;
      })
      .filter((id) => id !== null);

    console.log("selected accounts: " + JSON.stringify(this.selectedAccounts, null, 2));
    const accountIds = this.selectedAccounts.map((acc) => acc.id);

    console.log("edit index: " + this.editIndex);
    const isAccListUpdated =
      this.editIndex === -1
        ? true // create always true
        : this.hasAccountChanged();

    const payload = {
      isUpdate: this.editIndex !== -1,
      allProductFlag: this.selectedProduct == -1,
      authMatId: this.editAuth ? this.editIndex : null,
      companyId: this.currentCompanyId,

      productId: this.selectedProduct == -1 ? null : this.selectedProduct,
      subProductId: this.selectedSubProduct || null,

      currencyType: this.addCurrency,
      amount: Number(this.addAmount),
      oldAmount: Number(this.oldAmount),

      authGroupIds,

      accountIds, // ✅
      isAccListUpdated, // ✅

      isSequential: this.isSequential,
      isVerifier: this.isVerifier,
      isReleaser: this.isReleaser,

      eventType: this.SelectedAuthType,
      category: COMPANY_CATERGORY_NAME,
    };
    const actionRole = this.editIndex === -1 ? 'CREATE' : 'EDIT';
    this.apiService
      .sendData(ADD_AUTH_MATRIX, payload, {
        'X-ACTION-ROLE': actionRole,
      })
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              this.editIndex == -1
                ? 'Authorisation Added'
                : 'Authorisation Updated'
            );

            this.fetchMergedAuthMatrix();
            this.closeAddAuthf();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err: any) => {
          if (err.status == 400) {
            this.showToast('error', 'Error', err.error.message);
          } else this.showToast('error', 'Error', 'Something Went Wrong...');
          console.error('ERROR', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  toBankList() {
    this.authLevelHeaders = ['Authorisation Level', 'Action'];
    this.pageNumber = 1;
    this.totalElements = 0;
    this.tableId = 'CMProfileTable';
    this.getCompanyList();
    this.showAuthorisation = false;
  }
  closeAddAuthf() {
    // this.activeTab = '0';
    this.groupedRowIds = [];
    this.productData = [];
    this.subProductData = [];
    this.currentAuthMatId = null;
    this.showButtons = false;
    this.selectedProduct = null;
    this.selectedSubProduct = null;
    this.SelectedAuthType = '';
    this.subProductDisable = false;
    this.editIndex = -1;
    this.addAuthForm = false;
    this.showAuthorisation = true;
    this.viewAuth = false;
    this.editAuth = false;
    this.authLevelList = [];
    this.addCurrency = null;
    this.addAmount = '';
    this.oldAmount = '';
    this.isSequential = false;
    this.isVerifier = false;
    this.isReleaser = false;
  }

  validateAuth(): boolean {
    let errorCount = 0;

    // Reset all error flags
    this.typeError = false;
    this.productError = false;
    this.productTypeError = false;
    this.subProductTypeError = false;
    this.tenorError = false;
    this.currencyError = false;
    this.amountError = false;

    // Validate each field
    // if (!this.SelectedAuthType || this.SelectedAuthType.trim() === '') {
    //   this.typeError = true;
    //   errorCount++;
    // }
    if (!this.selectedAccounts || this.selectedAccounts.length === 0) {
      this.typeError = true;
      errorCount++;
    }

    if (!this.selectedProduct || this.selectedProduct === 0) {
      this.productError = true;
      errorCount++;
    }

    if (
      this.selectedProduct !== -1 &&
      (!this.selectedSubProduct || this.selectedSubProduct === 0)
    ) {
      this.subProductTypeError = true;
      errorCount++;
    }

    if (!this.addCurrency || this.addCurrency.trim() === '') {
      this.currencyError = true;
      errorCount++;
    }

    if (!this.addAmount || this.addAmount === '') {
      this.amountError = true;
      errorCount++;
    }

    // if (this.showDependents()) {
    //   if (!this.selectedProdType || this.selectedProdType.trim() === '') {
    //     this.productTypeError = true;
    //     errorCount++;
    //   }
    //   if (!this.selectedTenor || this.selectedTenor.trim() === '') {
    //     this.tenorError = true;
    //     errorCount++;
    //   }
    // }
    return errorCount === 0; // true if no errors
  }

  isPopupVisible = false;
  popupText = '';
  hidePopup() {
    this.isPopupVisible = false;
    this.popupText = '';
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'CMProfileTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getCompanyList();
    } else if (event.tableId === '') {
    }
  }


  // OTP FUNCTIONS
  isOtpOpen = false;
  otpReference: string = '';
  tempReceivedOtp = '';
  checkerAction: string = '';
  sendOtp(action: string) {
    this.checkerAction = action;
    this.isOtpOpen = true;
    const payload = {
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName()
    }
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  onOtpResend() {
    const payload = {
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
      otpReference: this.otpReference
    }
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status) {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  validateOtp(otp: string) {
    const payload = {
      otpReference: this.otpReference,
      enteredOtp: this.tempReceivedOtp,  //REPLACE THIS AFTERWARD WITH otp varaible
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName()
    }
    this.apiService.sendData(VALIDATE_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          // TODO: if the otp is validate call onOtpVerify
          this.isOtpOpen = false;
          if (this.checkerAction == 'approve')
            this.approveAuth();
          else if (this.checkerAction == 'reject')
            this.rejectAuth();
        } else {
          this.isOtpOpen = false;
          if (this.checkerAction == 'approve')
            this.approveAuth();
          else if (this.checkerAction == 'reject')
            this.rejectAuth();
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        this.isOtpOpen = false;
        if (this.checkerAction == 'approve')
          this.approveAuth();
        else if (this.checkerAction == 'reject')
          this.rejectAuth();
        console.error(err);
      }
    });
  }

  closeOtpPopup() {
    this.isOtpOpen = false;
    this.otpReference = '';
    this.tempReceivedOtp = ''
  }
}
