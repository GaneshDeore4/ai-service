import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmBoRefComponent } from './cm-bo-ref.component';

describe('CmBoRefComponent', () => {
  let component: CmBoRefComponent;
  let fixture: ComponentFixture<CmBoRefComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CmBoRefComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmBoRefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
