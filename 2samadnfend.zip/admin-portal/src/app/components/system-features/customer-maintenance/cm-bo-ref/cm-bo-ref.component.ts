import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../../commom/table/table.component";
import { PopupComponent } from "../../../../commom/popup/popup.component";

@Component({
  selector: 'app-cm-bo-ref',
  imports: [PageTitleComponent, NgIf, NgFor, FormsModule, TableComponent, NgClass, PopupComponent],
  templateUrl: './cm-bo-ref.component.html',
  styleUrl: './cm-bo-ref.component.css'
})
export class CmBoRefComponent {

  //main page vars
  searchAbbreviatedName = '';
  searchName = '';
  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']?.toLowerCase().includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']?.toLowerCase().includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  showBO = false;
  customerHeader = ['Abbreviated Name', 'Company Name', 'Action'];
  customerData: any[] = [
    {
      "Abbreviated Name": "10937234",
      "Company Name": "Big4U"
    },
    {
      "Abbreviated Name": "10943234",
      "Company Name": "Test Name"
    },
  ];
  ogData = this.customerData;
  currentCustomer = {};
  currentCustomerName: string = '';
  currentName: string = '';
  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentCustomerName = row['Abbreviated Name'] || '';
    this.currentName = row['Company Name'] || '';
    this.showBO = true;
  }

  // lIST OF BO PAGE
  searchCustomerRefNo = '';
  searchTradeIdentifier = '';
  productList = ['Import Collection', 'Export Collection', 'Inward Remittance'];
  selectedSearchProduct = '';
  searchBoRef = '';
  searchBORefList = ['Yes', 'No'];
  SearchBoRefUsed = '';

  customerRefHeaders = ['Customer Ref', 'TI Mnemonic', 'Product', 'BO Ref', 'BO Ref Used', 'Action']
  customerRefData: any[] = [
    {
      "Customer Ref": "CUST-001",
      "Trade Identifier": "TRD-123",
      "TI Mnemonic": "TI-MN-1",
      "Product": "Import Collection",
      "Product Type": "Collection",
      "BO Ref": "BO-REF-456",
      "BO Ref Used": "Yes",
      "Collection": "single"
    },
    {
      "Customer Ref": "CUST-002",
      "Trade Identifier": "TRD-124",
      "TI Mnemonic": "TI-MN-2",
      "Product": "Export Collection",
      "Product Type": "Collection",
      "BO Ref": "BO-REF-457",
      "BO Ref Used": "No",
      "Collection": "range"
    }
  ];
  customerRefOgData:any[]=[...this.customerRefData];

  searchBo() {
    const filtered = this.customerRefOgData.filter(item => {
      const matchCustomerRef = this.searchCustomerRefNo
        ? item['Customer Ref']?.toLowerCase().includes(this.searchCustomerRefNo.toLowerCase())
        : true;

      const matchTradeIdentifier = this.searchTradeIdentifier
        ? item['Trade Identifier']?.toLowerCase().includes(this.searchTradeIdentifier.toLowerCase())
        : true;

      const matchProduct = this.selectedSearchProduct
        ? item['Product']?.toLowerCase().includes(this.selectedSearchProduct.toLowerCase())
        : true;

      const matchBoRef = this.searchBoRef
        ? item['BO Ref']?.toLowerCase().includes(this.searchBoRef.toLowerCase())
        : true;

      const matchBoRefUsed = this.SearchBoRefUsed
        ? item['BO Ref Used'] === this.SearchBoRefUsed
        : true;

      return matchCustomerRef && matchTradeIdentifier && matchProduct && matchBoRef && matchBoRefUsed;
    });

    this.customerRefData = [...filtered];
  }
  addBo() { 
    this.addRefPopup=true;
    this.CustomerRefList= this.customerRefData.map(item => item['Customer Ref']);
  }
  viewBOf(row: any, index: number) {
    this.viewBO=true;
    this.assignValues(row);
    this.addBo();
   }
  editBOf(row: any, index: number) { 
    this.editBo=true;
    this.editBOIndex=index;
    this.assignValues(row);
    this.addBo();
  }
  deleteBOf(index: number) { 
    if (index >= 0 && index < this.customerRefData.length) {
      this.customerRefData.splice(index, 1);
      this.customerRefData = [...this.customerRefData]; // ✅ Update reference for change detection
    }
  }
  assignValues(row:any){
    this.selectedCustomerRef = row["Customer Ref"] || "";
    this.tradeIndentifier = row["Trade Identifier"] || "";
    this.selectedProduct = row["Product"] || "";
    this.selectedProductType = row["Product Type"] || "";
    this.collectionType = row["Collection"] || "";
    this.useBO = row["BO Ref Used"] === "Yes";
  }


  // popup variables
  addRefPopup=false;
  viewBO=false;
  editBo=false;
  editBOIndex=-1;

  CustomerRefList:string[]= this.customerRefData.map(item => item['Customer Ref']);
  selectedCustomerRef = '';
  tradeIndentifier = '';
  // product list is already mentioned above
  selectedProduct = '';
  get prodTypeList(): string[] {
    return this.selectedProduct == 'Export Collection' ? ['Demand Guarantee', 'Dependent Undertaking', 'Standby'] : [];
  }
  selectedProductType = '';
  collectionType = '';
  useBO=false;

  customerRefError = false;
  selectedProductError = false;
  selectedProductTypeError = false;

  popupVisible=false;
  hidePopup(){
    this.popupVisible=false;
  }
  saveBOf(){
    if(!this.validateRef())
        return;
    const newData={
      "Customer Ref": this.selectedCustomerRef,
      "Trade Identifier": this.tradeIndentifier,
      "TI Mnemonic": this.generateTIMnemonic(),
      "Product": this.selectedProduct,
      "Product Type": this.selectedProductType,
      "BO Ref": "BO-REF-457",
      "BO Ref Used": this.useBO?'Yes':'No',
      "Collection": this.collectionType
    }
    if(this.editBOIndex!=-1){
      this.customerRefOgData.splice(this.editBOIndex, 1, newData);
    }
    else{
      this.customerRefOgData.push(newData);
    }
    this.customerRefData=[...this.customerRefOgData];
    this.closeRefPopupf();
    this.popupVisible=true;
  }
  closeRefPopupf(){
    this.addRefPopup=false;
    this.viewBO=false;
    this.editBo=false;
    this.editBOIndex=-1;

    this.customerRefError = false;
    this.selectedProductError = false;
    this.selectedProductTypeError = false;
    this.CustomerRefList=[];
    this.selectedCustomerRef = '';
    this.tradeIndentifier = '';
    this.selectedProductType = '';
    this.collectionType = '';
    this.useBO=false;
  }
  generateTIMnemonic():string{
    if(this.tradeIndentifier=='')
      return this.selectedCustomerRef;
    else
      return 'TI-MN-'+this.tradeIndentifier;
  }
  validateRef():boolean{
    let errorCount = 0;

    // Reset all error flags
    this.customerRefError = false;
    this.selectedProductError = false;
    this.selectedProductTypeError = false;

    // Validate each field
    if (!this.selectedCustomerRef || this.selectedCustomerRef.trim() === '') {
      this.customerRefError = true;
      errorCount++;
    }

    if (!this.selectedProduct || this.selectedProduct.trim() === '') {
      this.selectedProductError = true;
      errorCount++;
    }

    if (this.selectedProduct === 'Export Collection') {
      if (!this.selectedProductType || this.selectedProductType.trim() === '') {
        this.selectedProductTypeError = true;
        errorCount++;
      }
    }

    return errorCount === 0; // true if no errors
  }


}
