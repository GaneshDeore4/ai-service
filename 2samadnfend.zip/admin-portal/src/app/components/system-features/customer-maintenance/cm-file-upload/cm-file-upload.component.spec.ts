import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmFileUploadComponent } from './cm-file-upload.component';

describe('CmFileUploadComponent', () => {
  let component: CmFileUploadComponent;
  let fixture: ComponentFixture<CmFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CmFileUploadComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
