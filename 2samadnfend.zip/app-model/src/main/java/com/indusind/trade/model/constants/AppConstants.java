package com.indusind.trade.model.constants;

public class AppConstants {

    public static final String DRAFT_TNX_STATUS_CODE = "01";

    public static final String DRAFT_STATUS = "Draft";

    public static final String SUBMIT_TNX_STATUS_CODE = "02";

    public static final String SUBMIT_STATUS = "Submit";

    public static final String APPROVED_TNX_STATUS_CODE = "04";

    public static final String RETURNED_TNX_STATUS_CODE = "54";

    public static final String REJECTED_TNX_STATUS_CODE = "54";

    public static final String NEW_TNX_TYPE_CODE = "01";

    public static final String UPDATE_TNX_TYPE_CODE = "02";

    public static final String UPDATE_STATUS = "Update";

    public static final String DASHBOARD_SCREEN_TYPE = "02";

    public static final String ACTION_APPROVE = "Approve";

    public static final String ACTION_REJECT = "Reject";

    public static final String ACTION_RETURN = "Return";

    public static final String ADMIN = "ADMIN";

    public static final String SUCCESS = "SUCCESS";

    public static final String OTP_NOT_FOUND = "OTP not found";
}
