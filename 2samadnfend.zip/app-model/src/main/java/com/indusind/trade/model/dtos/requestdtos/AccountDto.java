package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.company.Account;
import com.indusind.trade.model.entities.company.AccountTemp;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountDto {

	private Long accountId;

	private String accountNo;

	private String accountType;

	private String currency;

	private String solId;

	private String solDescription;

	private String activeFlag;

	private LocalDateTime createdDate;

	private String createdBy;

	private LocalDateTime modifiedDate;

	private String modifiedBy;

	private String status;
	public static AccountDto convertToDto(Account account) {
		AccountDto accountDto = new AccountDto();
		BeanUtils.copyProperties(account, accountDto);
		return accountDto;
	}

	public static Account convertToEntity(AccountDto accountDto) {
		Account account = new Account();
		BeanUtils.copyProperties(accountDto, account);
		return account;
	}

	public static AccountTemp convertToTempEntity(AccountDto accountDto) {
		AccountTemp accountTemp = new AccountTemp();
		BeanUtils.copyProperties(accountDto, accountTemp);
		return accountTemp;
	}

	public static AccountDto convertToDtoFromTemp(AccountTemp accountTemp) {
		AccountDto accountDto = new AccountDto();
		BeanUtils.copyProperties(accountTemp, accountDto);
		return accountDto;
	}

}
