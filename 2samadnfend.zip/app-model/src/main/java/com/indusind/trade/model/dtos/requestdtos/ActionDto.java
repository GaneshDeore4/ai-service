package com.indusind.trade.model.dtos.requestdtos;

import com.indusind.trade.model.entities.master.Action;
import com.indusind.trade.model.entities.master.ActionTemp;
import com.indusind.trade.model.enums.Status;
import lombok.*;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ActionDto {

    private Long actionId;

//    private List<Long> productId;

    private String actionCode;

    private String actionNameLabel;

    private ProductMasterDto product;

    private SubProductMasterDto subProduct;

    private Boolean isUpdate;

    private Long productId;

    private Long subProductId;

    private String categoryName;

    private Status status;

    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;



    public static Action convertToEntity(ActionDto actionDto) {
        Action action = new Action();
        BeanUtils.copyProperties(actionDto, action);

        return action;
    }

    public static ActionDto convertToDto(Action action) {
        ActionDto actionDto = new ActionDto();
        BeanUtils.copyProperties(action, actionDto);
        actionDto.setCategoryName(action.getProduct().getCategory().getCategoryName());

        return actionDto;
    }

    public static ActionDto convertTempToDto(ActionTemp action) {
        ActionDto actionDto = new ActionDto();
        BeanUtils.copyProperties(action, actionDto);
        actionDto.setCategoryName(action.getProduct().getCategory().getCategoryName());

        return actionDto;
    }
}
