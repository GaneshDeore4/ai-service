package com.indusind.trade.model.dtos.requestdtos;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@RequiredArgsConstructor
public class AddUserAccountMappingGroupedRequestDto {

    private List<AddUserAccountMappingRequestDto> mappingRequest;

}
