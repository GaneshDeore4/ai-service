package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.company.Address;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressDto {

    private String streetName;

    private String townName;

    private String countrySubDiv;

    private String postCode;

    public static AddressDto convertToDto(Address address) {
        AddressDto addressDto = new AddressDto();
        BeanUtils.copyProperties(address, addressDto);
        return addressDto;
    }

}
