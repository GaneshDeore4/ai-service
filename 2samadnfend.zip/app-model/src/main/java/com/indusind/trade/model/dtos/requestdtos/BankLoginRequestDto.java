package com.indusind.trade.model.dtos.requestdtos;

import lombok.Data;

@Data
public class BankLoginRequestDto {
    private String bankAbbvName;
    private String loginId;
    private String password;
    private boolean force;
}
