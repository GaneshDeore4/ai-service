package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.company.Address;
import com.indusind.trade.model.entities.bank.BankSwiftAddress;
import com.indusind.trade.model.entities.bank.BankProfile;
import com.indusind.trade.model.entities.bank.BankProfileTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.service.ProductMasterService;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.Objects;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankProfileRequestDto extends BankProfileBaseDto {

    private Boolean isUpdate;

    private List<Long> productIdList;

    private List<Long> subProductList;

    public static BankProfileTemp convertToTempEntity(BankProfileRequestDto bankProfileRequestDto, BankProfileTemp bankProfileTemp){
        BeanUtils.copyProperties(bankProfileRequestDto, bankProfileTemp);
        if(Objects.nonNull(bankProfileRequestDto.getAddressDto())){
            Address address = new Address();
            BeanUtils.copyProperties(bankProfileRequestDto.getAddressDto(), address);
            bankProfileTemp.setAddress(address);
        }
        if(Objects.nonNull(bankProfileRequestDto.getSwiftAddress())){
            BankSwiftAddress swiftAddress = new BankSwiftAddress();
            BeanUtils.copyProperties(bankProfileRequestDto.getSwiftAddress(), swiftAddress);
            bankProfileTemp.setBankSwiftAddress(swiftAddress);
        }
        return bankProfileTemp;
    }

    public static BankProfile convertToEntity(BankProfileRequestDto bankProfileRequestDto){
        BankProfile bankProfile = new BankProfile();
        BeanUtils.copyProperties(bankProfileRequestDto, bankProfile);
        return bankProfile;
    }

}
