package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.bank.BankUserTemp;
import com.indusind.trade.model.entities.bank.OfficeAddress;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.util.Objects;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankUserRequestDto extends BankUserBaseDto{

    private Boolean isUpdate;

    public static BankUserTemp convertToTempEntity(BankUserRequestDto bankUserRequestDto, BankUserTemp bankUserTemp){
        BeanUtils.copyProperties(bankUserRequestDto, bankUserTemp);
        if(Objects.nonNull(bankUserRequestDto.getOfficeAddress())) {
            OfficeAddress officeAddress =  new OfficeAddress();
            BeanUtils.copyProperties(bankUserRequestDto.getOfficeAddress(),officeAddress);
            bankUserTemp.setOfficeAddress(officeAddress);
        }
        return bankUserTemp;
    }
}