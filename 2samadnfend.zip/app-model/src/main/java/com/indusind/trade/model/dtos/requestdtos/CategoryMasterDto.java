package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.master.CategoryMaster;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.List;

@Data
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CategoryMasterDto {

    private Long categoryId;

    private String categoryName;

    private List<ProductMasterDto> productMasterList;

    private List<UserTypeDto> userTypeDtoList;

    private LocalDateTime createdAt;

    private LocalDateTime modifiedAt;

    public static CategoryMasterDto convertToDto(CategoryMaster category) {
        CategoryMasterDto categoryDto = new CategoryMasterDto();
        BeanUtils.copyProperties(category, categoryDto);
        return categoryDto;
    }

    public static CategoryMaster convertToEntity(CategoryMasterDto categoryDto) {
        CategoryMaster category = new CategoryMaster();
        BeanUtils.copyProperties(categoryDto, category);
        return category;
    }
}
