package com.indusind.trade.model.dtos.requestdtos;

import lombok.Data;

@Data
public class ClientLoginRequestDto {
    private String cifId;
    private String loginId;
    private String password;
}
