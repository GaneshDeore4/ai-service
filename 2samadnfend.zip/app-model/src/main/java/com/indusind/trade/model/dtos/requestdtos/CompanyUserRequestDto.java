package com.indusind.trade.model.dtos.requestdtos;

public record CompanyUserRequestDto(Long userId, String tnxId, Long checkerId, String action) {}
