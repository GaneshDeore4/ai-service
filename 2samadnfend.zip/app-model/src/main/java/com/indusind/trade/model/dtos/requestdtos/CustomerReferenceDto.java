package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.company.CustomerReference;
import com.indusind.trade.model.entities.company.CustomerReferenceTemp;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerReferenceDto {

    private String customerReferenceId;

    private String tradeProZone;

    private String solId;

    private String solDescription;

    private String customerReference;

    private String customerReferenceDescription;

    private String defaultReference;

    private LocalDateTime createdDate;

    private String createdBy;

    private LocalDateTime modifiedDate;

    private String modifiedBy;

    private String status;

    public static CustomerReferenceDto convertToDto(CustomerReference customerReference) {
        CustomerReferenceDto customerReferenceDto = new CustomerReferenceDto();
        BeanUtils.copyProperties(customerReference, customerReferenceDto);
        return customerReferenceDto;
    }

    public static CustomerReference convertToEntity(CustomerReferenceDto customerReferenceDto) {
        CustomerReference customerReference = new CustomerReference();
        BeanUtils.copyProperties(customerReferenceDto, customerReference);
        return customerReference;
    }

    public static CustomerReferenceDto convertToDtoFromTemp(CustomerReferenceTemp customerReferenceTemp) {
        CustomerReferenceDto customerReferenceDto = new CustomerReferenceDto();
        BeanUtils.copyProperties(customerReferenceTemp, customerReferenceDto);
        return customerReferenceDto;
    }

    public static CustomerReferenceTemp convertToTempEntity(CustomerReferenceDto customerReferenceDto) {
        CustomerReferenceTemp customerReferenceTemp = new CustomerReferenceTemp();
        BeanUtils.copyProperties(customerReferenceDto, customerReferenceTemp);
        return customerReferenceTemp;
    }
}

