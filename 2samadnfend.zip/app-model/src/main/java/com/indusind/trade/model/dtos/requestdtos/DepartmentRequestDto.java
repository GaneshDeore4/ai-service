package com.indusind.trade.model.dtos.requestdtos;

import com.indusind.trade.model.entities.master.Department;
import com.indusind.trade.model.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class DepartmentRequestDto {

    private Long id;
    private Long categoryId;
    private String departmentName;
    private Status status;
    private String departmentNameLabel;
    private Boolean isUpdate;
    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;

//    public static DepartmentRequestDto convertToDto(Department department){
//        DepartmentRequestDto dto = new DepartmentRequestDto();
//        BeanUtils.copyProperties(department, dto);
//        dto.setCategoryId(department.getCategory().getCategoryId());
//
//    }

}
