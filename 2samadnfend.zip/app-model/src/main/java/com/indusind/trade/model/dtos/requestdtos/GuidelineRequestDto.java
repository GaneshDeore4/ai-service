package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.indusind.trade.model.entities.company.GuideLineTemp;
import com.indusind.trade.model.entities.company.Guideline;
import com.indusind.trade.model.entities.company.NotificationTemp;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.time.LocalDate;

@Data
public class GuidelineRequestDto {

    private Long guidelineId;
    private String guidelineTitle;
    private String guidelineDesc;
    private Boolean isUpdate;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate validUpto;
    private String status;
    private Boolean isActive;

    public Guideline convertToEntity(GuidelineRequestDto guidelineRequestDto, Guideline guideline){
        BeanUtils.copyProperties(guidelineRequestDto, guideline);
        return guideline;
    }

    public GuideLineTemp convertToTempEntity(GuidelineRequestDto guidelineRequestDto, GuideLineTemp guideLineTemp){
        BeanUtils.copyProperties(guidelineRequestDto, guideLineTemp);
        return guideLineTemp;
    }
}
