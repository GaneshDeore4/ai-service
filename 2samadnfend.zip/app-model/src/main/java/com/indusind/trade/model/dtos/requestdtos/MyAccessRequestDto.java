package com.indusind.trade.model.dtos.requestdtos;

import lombok.Data;

import java.util.List;

@Data
public class MyAccessRequestDto {
    private Long userType;
    private List<Long> productId;
    private List<Long> subProductId;
}
