package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.bank.OfficeAddress;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OfficeAddressDto {

    private String addressLine1;
    private String addressLine2;
    private String addressLine3;
    private String addressLine4;
    private String addressLine5;

    public static OfficeAddressDto convertToDto(OfficeAddress officeAddress){
        OfficeAddressDto officeAddressDto = new OfficeAddressDto();
        BeanUtils.copyProperties(officeAddress, officeAddressDto);
        return officeAddressDto;
    }
}
