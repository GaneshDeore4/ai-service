package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OtpDto {

    private String loginId;

    private String companyCifId;

    private String bankAbbvName;

    private String otpReference;

    private String enteredOtp;

    private boolean fromLoginScreen;

}
