package com.indusind.trade.model.dtos.requestdtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
public class ProductLimitDto {

    private Long productId;
    private Long limitAmt;
    private Boolean midOfficeFlag;

}
