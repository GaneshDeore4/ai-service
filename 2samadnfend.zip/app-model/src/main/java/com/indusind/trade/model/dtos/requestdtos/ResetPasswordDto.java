package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResetPasswordDto {

    private String loginId;

    private String bankAbbvName;

    private String comanyCifId;

    private Long userId;

    private String newPassword;

    private boolean afterLogin;

}
