package com.indusind.trade.model.dtos.requestdtos;

public record RoleRequestDto(Long roleId, String tnxId, Long checkerId, String action) {
}
