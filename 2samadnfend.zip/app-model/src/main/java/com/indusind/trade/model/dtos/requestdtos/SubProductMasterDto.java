package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.enums.Status;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;

@Data
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubProductMasterDto {

    private Long subProductId;
    private String subProductName;
    private Long categoryId;
    private String categoryName;
    private Long productId;
    private String productName;
    private String productLabel;
    private Long sequenceId;
    private String subProductLabel;
    private Status status;
    private Boolean isUpdate;
    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;

    public static SubProductMasterDto convertToDto(SubProductMaster subProductMaster){
        SubProductMasterDto subProductMasterDto = new SubProductMasterDto();
        BeanUtils.copyProperties(subProductMaster, subProductMasterDto);
        subProductMasterDto.setCategoryId(subProductMaster.getProductMaster().getCategory().getCategoryId());
        subProductMasterDto.setCategoryName(subProductMaster.getProductMaster().getCategory().getCategoryName());
        subProductMasterDto.setProductId(subProductMaster.getProductMaster().getProductId());
        subProductMasterDto.setProductName(subProductMaster.getProductMaster().getProductName());
        subProductMasterDto.setProductLabel(subProductMaster.getProductMaster().getProductNameLabel());
        return subProductMasterDto;
    }

    public static SubProductMaster convertToEntity(SubProductMasterDto subProductMasterDto){
        SubProductMaster subProductMaster = new SubProductMaster();
        BeanUtils.copyProperties(subProductMasterDto, subProductMaster);
        return subProductMaster;
    }

}
