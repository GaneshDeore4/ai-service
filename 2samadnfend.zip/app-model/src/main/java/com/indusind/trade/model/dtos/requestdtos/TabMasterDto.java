package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.indusind.trade.model.entities.master.TabMaster;
import com.indusind.trade.model.entities.master.TabMasterTemp;
import com.indusind.trade.model.enums.Status;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Set;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TabMasterDto {

    private Long tabId;

    @NotBlank(message = "Tab Name cannot be blank")
    private String tabName;

    private String tabLabel;

    private Status status;

    private Long productId;

    private  Long subProductId;

    private String productLabel;

    private String subProductLabel;

    private Map<Long, String> categoryMap;

    private LocalDate createdDate;

    private Boolean isUpdate;

    private String makerName;

    private String checkerName;

    private LocalDateTime createdAt;

    private LocalDateTime approvedAt;

    private String editorName;

    private LocalDateTime editedAt;

    private String rejectedBy;

    private LocalDateTime rejectedAt;

    private String lastModifiedBy;

    private LocalDateTime lastModifiedAt;


    public static TabMasterDto convertToDto(TabMaster tabMaster){
        TabMasterDto tabMasterDto = new TabMasterDto();
        BeanUtils.copyProperties(tabMaster, tabMasterDto);
        return tabMasterDto;
    }

    public static TabMasterDto convertToDtoFromTemp(TabMasterTemp tabMasterTemp){
        TabMasterDto tabMasterDto = new TabMasterDto();
        BeanUtils.copyProperties(tabMasterTemp, tabMasterDto);
        return tabMasterDto;
    }

    public static TabMaster convertToEntity(TabMasterDto tabMasterDto){
        TabMaster tabMaster = new TabMaster();
        BeanUtils.copyProperties(tabMasterDto, tabMaster);
        return tabMaster;
    }
}
