package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.indusind.trade.model.dtos.response.dtos.AccountDetailsDto;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMapping;
import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMappingTemp;
import com.indusind.trade.model.entities.company.UserTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import lombok.*;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
public class UserDTO {

    private Boolean isUpdate;
    private Long userId;
    private Long companyId;
    private String companyName;
    private String loginId;
    private String firstName;
    private String lastName;
    private String employeeDepartment;
    private String employeeNo;
    private String addressLine1;
    private String addressLine2;
    private String addressLine3;
    private String addressLine4;
    private String addressLine5;
    private String postalCode;
    private String status;
    private String userStatus;
    private String authMode;
    private String timeZone;
    private String corrLanguage;
    private String baseCurr;
    private String contactNo;
    private String contactNoCountryCode;
    private String email;
    private String pendingTransNotify;
    private Long authLevel;
    private String authGroup;
    private String ccy;
    private String limitAmount;
    //    private List<Long> productMasterList; //list of prod ids
//    private List<Long> subProductMasterList;//list of subprod ids
    private Map<Long, List<Long>> productSubProdRespMap;
    private Map<String, Set<String>> productSubProdMap;
    private Long userTypeId;
    private String userType;

    @JsonFormat(pattern = "dd-MM-yyyy hh:mm:ss a")
    private LocalDateTime createdAt;

    @JsonFormat(pattern = "dd-MM-yyyy hh:mm:ss a")
    private LocalDateTime modifiedAt;

    @JsonFormat(pattern = "dd-MM-yyyy hh:mm:ss a")
    private LocalDateTime deletedAt;

    private List<LegalIdDetailsDto> legalIdDetailsDtoList;

    private List<AccountDetailsDto> account;

    private String makerName;
    private String checkerName;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;

    public static UserDTO convertTempToDto(UserTemp userTemp) {
        UserDTO userDTO = new UserDTO();
        BeanUtils.copyProperties(userTemp, userDTO);
        if (Objects.nonNull(userTemp.getUserMappingTemp()) && CollectionUtils.isNotEmpty(userTemp.getUserMappingTemp())) {
            userDTO.setProductSubProdMap(convertToProductSubProductMap(userTemp.getUserMappingTemp(), UserCompanyProductSubProdMappingTemp::getProductMaster,
                    UserCompanyProductSubProdMappingTemp::getSubProductMaster));
        }
        if (Objects.nonNull(userTemp.getLegalIdDetailsTempList()) && CollectionUtils.isNotEmpty(userTemp.getLegalIdDetailsTempList())) {
            userDTO.setLegalIdDetailsDtoList(userTemp.getLegalIdDetailsTempList().stream().map(LegalIdDetailsDto::convertToDtoFromTemp).collect(Collectors.toList()));
        }
        if(Objects.nonNull(userTemp.getAuthGroup())){
            userDTO.setAuthLevel(userTemp.getAuthGroup().getId());
            userDTO.setAuthGroup(userTemp.getAuthGroup().getAuthGroup());
        }
        if(Objects.nonNull(userTemp.getUserType())){
            userDTO.setUserTypeId(userTemp.getUserType().getUserTypeId());
            userDTO.setUserType(userTemp.getUserType().getUserTypeName());
        }
        if (Objects.nonNull(userTemp.getCompany())) {
            userDTO.setCompanyId(userTemp.getCompany().getCompanyId());
            userDTO.setCompanyName(userTemp.getCompany().getName());
        }
        return userDTO;
    }

    public static UserDTO convertToDto(User user) {
        UserDTO userDTO = new UserDTO();
        BeanUtils.copyProperties(user, userDTO);
        if (Objects.nonNull(user.getMappingUser()) && CollectionUtils.isNotEmpty(user.getMappingUser())) {
            userDTO.setProductSubProdMap(convertToProductSubProductMap(user.getMappingUser(), UserCompanyProductSubProdMapping::getProductMaster,
                    UserCompanyProductSubProdMapping::getSubProductMaster));
        }
        if (Objects.nonNull(user.getLegalIdDetailsList()) && CollectionUtils.isNotEmpty(user.getLegalIdDetailsList())) {
            userDTO.setLegalIdDetailsDtoList(user.getLegalIdDetailsList().stream().map(LegalIdDetailsDto::convertToDto).collect(Collectors.toList()));
        }
        if(Objects.nonNull(user.getAuthGroup())){
            userDTO.setAuthLevel(user.getAuthGroup().getId());
            userDTO.setAuthGroup(user.getAuthGroup().getAuthGroup());
        }
        if(Objects.nonNull(user.getUserType())){
            userDTO.setUserTypeId(user.getUserType().getUserTypeId());
            userDTO.setUserType(user.getUserType().getUserTypeName());
        }

        if(Objects.nonNull(user.getAccountMapping())){
           userDTO.setAccount(user.getAccountMapping().stream()
                   .map(AccountDetailsDto :: convertToDto)
                   .toList());
        }
        if (Objects.nonNull(user.getCompany())) {
            userDTO.setCompanyId(user.getCompany().getCompanyId());
            userDTO.setCompanyName(user.getCompany().getName());
        }
        return userDTO;
    }

    public static UserTemp convertToTempEntity(UserDTO userDto, UserTemp userTemp) {
        BeanUtils.copyProperties(userDto, userTemp);
        return userTemp;
    }

    private static <T> Map<String, Set<String>> convertToProductSubProductMap(
            List<T> mappingList,
            Function<T, ProductMaster> productExtractor,
            Function<T, SubProductMaster> subProductExtractor) {

        Map<String, Set<String>> productSubProductMap = new HashMap<>();

        for (T mapping : mappingList) {

            ProductMaster product = productExtractor.apply(mapping);
            SubProductMaster subProduct = subProductExtractor.apply(mapping);

            String productKey = product.getProductId() + "-" + product.getProductName();
            String subProductValue = subProduct.getSubProductId() + "-" + subProduct.getSubProductName();

            productSubProductMap
                    .computeIfAbsent(productKey, k -> new HashSet<>())
                    .add(subProductValue);
        }

        return productSubProductMap;
    }

}
