package com.indusind.trade.model.dtos.requestdtos;

import java.util.List;

public record UserTypeTabActionMappingRequestGetDto(Long productId,
                                                    Long subProductId,
                                                    Long userTypeId,
                                                    Long categoryId,
                                                    List<Long> tabIds) {
}
