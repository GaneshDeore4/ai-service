package com.indusind.trade.model.dtos.response.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ActionAccessDto {

    private Long id;
    private String actionCode;
    private String actionLabel;

}