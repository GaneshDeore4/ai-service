package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.dtos.requestdtos.ActionDto;
import com.indusind.trade.model.dtos.requestdtos.ProductMasterDto;
import com.indusind.trade.model.dtos.requestdtos.SubProductMasterDto;
import com.indusind.trade.model.entities.master.Action;
import com.indusind.trade.model.entities.master.ActionTemp;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
public class ActionResponseDto extends ActionDto {

    Map<Long, String> products = new HashMap<>();

    public static ActionResponseDto convertToDto(Action action) {
        ActionResponseDto actionResponseDtoDtoDto = new ActionResponseDto();
        BeanUtils.copyProperties(action, actionResponseDtoDtoDto);
        actionResponseDtoDtoDto.setProduct(ProductMasterDto.convertToDto(action.getProduct()));
        if(Objects.nonNull(action.getSubProduct())) {
            actionResponseDtoDtoDto.setSubProduct(SubProductMasterDto.convertToDto(action.getSubProduct()));
        }
        actionResponseDtoDtoDto.setCategoryName(action.getProduct().getCategory().getCategoryName());
//        actionResponseDtoDtoDto.setProducts(action.getProductMaster().stream()
//                .collect(Collectors.toMap(productMaster -> productMaster.getProductId(),
//                                            productMaster -> productMaster.getProductName())));
        return actionResponseDtoDtoDto;
    }

    public static ActionResponseDto convertTempToDto(ActionTemp action) {
        ActionResponseDto actionResponseDtoDtoDto = new ActionResponseDto();
        BeanUtils.copyProperties(action, actionResponseDtoDtoDto);
        actionResponseDtoDtoDto.setProduct(ProductMasterDto.convertToDto(action.getProduct()));
        if(Objects.nonNull(action.getSubProduct())) {
            actionResponseDtoDtoDto.setSubProduct(SubProductMasterDto.convertToDto(action.getSubProduct()));
        }
        actionResponseDtoDtoDto.setCategoryName(action.getProduct().getCategory().getCategoryName());
        return actionResponseDtoDtoDto;
    }
}
