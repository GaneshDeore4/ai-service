package com.indusind.trade.model.dtos.response.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AuthMatrixGroupKeyDto {

    private Long companyId;
    private Long amount;

}
