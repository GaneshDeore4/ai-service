package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.enums.AuthType;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@Builder
public class AuthMatrixResponseDto {

    private Long authMatId;
    private Long companyId;
    private String companyName;
    private Long productId;
    private String productName;
    private Long subProductId;
    private String subProductName;
//    private List<AuthType> eventType;
    private String currencyType;
    private Long amount;
    private Boolean isSequential;
    private Boolean isVerifier;
    private Boolean isReleaser;
    private List<Map<String, Integer>> authGroup;
    private String status;
    private Boolean isAllProductFlag;
    private List<AccountDetailsDto> accounts;
    private String makerName;
    private LocalDateTime createdAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String checkerName;
    private LocalDateTime approvedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;

}
