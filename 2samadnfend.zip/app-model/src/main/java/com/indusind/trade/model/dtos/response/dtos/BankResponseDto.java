package com.indusind.trade.model.dtos.response.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.dtos.requestdtos.AddressDto;
import com.indusind.trade.model.dtos.requestdtos.BankProfileBaseDto;
import com.indusind.trade.model.dtos.requestdtos.BankSwiftAddressDto;
import com.indusind.trade.model.entities.bank.BankProfile;
import com.indusind.trade.model.entities.bank.BankProfileTemp;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankResponseDto extends BankProfileBaseDto {

    private Map<String, Set<String>> prodSubProdMapping;

    public static BankResponseDto convertTempToDto(BankProfileTemp bankProfileTemp) {
        BankResponseDto bankResponseDto = new BankResponseDto();
        BeanUtils.copyProperties(bankProfileTemp, bankResponseDto);
        if (Objects.nonNull(bankProfileTemp.getBankSwiftAddress())) {
            bankResponseDto.setSwiftAddress(BankSwiftAddressDto.convertToDto(bankProfileTemp.getBankSwiftAddress()));
        } if(Objects.nonNull(bankProfileTemp.getAddress())) {
            bankResponseDto.setAddressDto(AddressDto.convertToDto(bankProfileTemp.getAddress()));
        }
        return bankResponseDto;
    }

    public static BankResponseDto convertToDto(BankProfile bankProfile) {
        BankResponseDto bankResponseDto = new BankResponseDto();
        BeanUtils.copyProperties(bankProfile, bankResponseDto);
        return bankResponseDto;
    }

    public BankProfile convertToEntity(BankResponseDto bankResponseDto) {
        BankProfile bankProfile = new BankProfile();
        BeanUtils.copyProperties(bankResponseDto, bankProfile);
        return bankProfile;
    }

    public BankProfileTemp convertToTempEntity(BankResponseDto bankResponseDto) {
        BankProfileTemp bankProfileTemp = new BankProfileTemp();
        BeanUtils.copyProperties(bankResponseDto, bankProfileTemp);
        return bankProfileTemp;
    }

}
