package com.indusind.trade.model.dtos.response.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.dtos.requestdtos.BankUserBaseDto;
import com.indusind.trade.model.dtos.requestdtos.OfficeAddressDto;
import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.entities.bank.BankUserProductSubProductMapping;
import com.indusind.trade.model.entities.bank.BankUserProductSubProductMappingTemp;
import com.indusind.trade.model.entities.bank.BankUserTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;

import java.util.*;
import java.util.function.Function;

@Data
@SuperBuilder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankUserResponseDto extends BankUserBaseDto {

    public static BankUserResponseDto convertToDto(BankUser bankUser){
        BankUserResponseDto bankUserResponseDto = new BankUserResponseDto();
        BeanUtils.copyProperties(bankUser, bankUserResponseDto);
        if(Objects.nonNull(bankUser.getMappingUser()) && CollectionUtils.isNotEmpty(bankUser.getMappingUser())){
            bankUserResponseDto.setProductSubProdMap(convertToProductSubProductMap(bankUser.getMappingUser(), BankUserProductSubProductMapping::getProductMaster,
                    BankUserProductSubProductMapping::getSubProductMaster));
        }
        if(Objects.nonNull(bankUser.getUserType())){
            bankUserResponseDto.setUserTypeId(bankUser.getUserType().getUserTypeId());
            bankUserResponseDto.setUserType(bankUser.getUserType().getUserTypeName());
        }
        if(Objects.nonNull(bankUser.getOfficeAddress())){
            bankUserResponseDto.setOfficeAddress(OfficeAddressDto.convertToDto(bankUser.getOfficeAddress()));
        }
        if (Objects.nonNull(bankUser.getBankProfile())) {
            bankUserResponseDto.setBankId(bankUser.getBankProfile().getBankProfileId());
            bankUserResponseDto.setBankName(bankUser.getBankProfile().getName());
        }

        return bankUserResponseDto;
    }

    public static BankUserResponseDto convertTempToDto(BankUserTemp bankUserTemp){
        BankUserResponseDto bankUserResponseDto = new BankUserResponseDto();
        BeanUtils.copyProperties(bankUserTemp, bankUserResponseDto);
        if(Objects.nonNull(bankUserTemp.getBankUserMappingTemp()) && CollectionUtils.isNotEmpty(bankUserTemp.getBankUserMappingTemp())){
            bankUserResponseDto.setProductSubProdMap(convertToProductSubProductMap(bankUserTemp.getBankUserMappingTemp(), BankUserProductSubProductMappingTemp::getProductMaster,
                    BankUserProductSubProductMappingTemp::getSubProductMaster));
        }
        if(Objects.nonNull(bankUserTemp.getUserType())){
            bankUserResponseDto.setUserTypeId(bankUserTemp.getUserType().getUserTypeId());
            bankUserResponseDto.setUserType(bankUserTemp.getUserType().getUserTypeName());
        }
        if(Objects.nonNull(bankUserTemp.getOfficeAddress())){
            bankUserResponseDto.setOfficeAddress(OfficeAddressDto.convertToDto(bankUserTemp.getOfficeAddress()));
        }

        if (Objects.nonNull(bankUserTemp.getBankProfile())) {
            bankUserResponseDto.setBankId(bankUserTemp.getBankProfile().getBankProfileId());
            bankUserResponseDto.setBankName(bankUserTemp.getBankProfile().getName());
        }

        return bankUserResponseDto;
    }

    private static <T> Map<String, Set<String>> convertToProductSubProductMap(
            List<T> mappingList,
            Function<T, ProductMaster> productExtractor,
            Function<T, SubProductMaster> subProductExtractor) {

        Map<String, Set<String>> productSubProductMap = new HashMap<>();

        for(T mapping : mappingList){

            ProductMaster product = productExtractor.apply(mapping);
            SubProductMaster subProductMaster = subProductExtractor.apply(mapping);

            String productKey = product.getProductId() + "-" + product.getProductName();
            String subProductValue = subProductMaster.getSubProductId() + "-" + subProductMaster.getSubProductName();

            productSubProductMap.computeIfAbsent(productKey, k -> new HashSet<>())
                    .add(subProductValue);
        }

        return productSubProductMap;
    }

}
