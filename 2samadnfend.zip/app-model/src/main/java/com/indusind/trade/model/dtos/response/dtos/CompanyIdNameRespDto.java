package com.indusind.trade.model.dtos.response.dtos;


import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.entities.company.CompanyTemp;
import com.indusind.trade.model.enums.Status;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Getter
@Setter
@RequiredArgsConstructor
public class CompanyIdNameRespDto {


    private Long companyId;
    private String name;
    private String abbvName;
    private String cifId;
    private String status;
    private String baseCurrency;
    private String createdBy;


    public static CompanyIdNameRespDto convertToTempDto(CompanyTemp companyTemp) {
        CompanyIdNameRespDto companyIdNameRespDto = new CompanyIdNameRespDto();
        BeanUtils.copyProperties(companyTemp, companyIdNameRespDto);

        return companyIdNameRespDto;
    }

    public static CompanyIdNameRespDto convertToDto(Company company) {
        CompanyIdNameRespDto companyIdNameRespDto = new CompanyIdNameRespDto();
        BeanUtils.copyProperties(company, companyIdNameRespDto);
        companyIdNameRespDto.setStatus(Status.APPROVED.toString());
        return companyIdNameRespDto;
    }

}
