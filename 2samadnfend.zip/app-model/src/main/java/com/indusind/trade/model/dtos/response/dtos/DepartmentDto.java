package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.entities.master.Department;
import com.indusind.trade.model.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class DepartmentDto {

    private Long id;
    private String departmentName;
    private String departmentNameLabel;
    private Status status;
    private Long categoryId;
    private String categoryName;
    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;
    private List<UserTypeDto> userTypes;

    public static Department convertToEntity(DepartmentDto departmentDto) {
        Department dept = new Department();
        BeanUtils.copyProperties(departmentDto, dept);
        return dept;
    }

    public static DepartmentDto convertToDto(Department department) {
        DepartmentDto deptDto = new DepartmentDto();
        BeanUtils.copyProperties(department, deptDto);
        deptDto.setCategoryId(department.getCategory().getCategoryId());
        deptDto.setCategoryName(department.getDepartmentName());
        return deptDto;
    }

}
