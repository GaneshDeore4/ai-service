package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.entities.company.GuideLineTemp;
import com.indusind.trade.model.entities.company.Guideline;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class GuidelineResponseDto {

    private Long guidelineId;
    private String guidelineTitle;
    private String guidelineDesc;
    private LocalDateTime createdDate;
    private Boolean isActive;
    private String status;
    private LocalDate validUpto;
    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;

    public static GuidelineResponseDto convertToDto(Guideline guideline){
        GuidelineResponseDto guidelineResponseDto = new GuidelineResponseDto();
        BeanUtils.copyProperties(guideline, guidelineResponseDto);
        return guidelineResponseDto;
    }

    public static GuidelineResponseDto convertToTempDto(GuideLineTemp guidelineTemp){
        GuidelineResponseDto guidelineResponseDto = new GuidelineResponseDto();
        BeanUtils.copyProperties(guidelineTemp, guidelineResponseDto);
        return guidelineResponseDto;
    }
}
