package com.indusind.trade.model.dtos.response.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MidOfficeCountDTO {
    private String product;
    private Long pendingAtBank;
    private Long pendingAtClient;
    private Long processedByBank;
    private Long processedByClient;
}
