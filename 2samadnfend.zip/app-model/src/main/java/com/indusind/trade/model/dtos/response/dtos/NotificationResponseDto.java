package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.entities.company.Notification;
import com.indusind.trade.model.entities.company.NotificationTemp;
import lombok.Data;
import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class NotificationResponseDto {

    private Long notificationId;
    private String notificationTitle;
    private String notificationDesc;
    private LocalDateTime createdDate;
    private Boolean isActive;
    private String status;
    private LocalDate validUpto;
    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;

    public static NotificationResponseDto convertToTempDto(NotificationTemp notificationTemp){
        NotificationResponseDto notificationResponseDto = new NotificationResponseDto();
        BeanUtils.copyProperties(notificationTemp, notificationResponseDto);
        return notificationResponseDto;
    }

    public static NotificationResponseDto convertToDto(Notification notification){
        NotificationResponseDto notificationResponseDto = new NotificationResponseDto();
        BeanUtils.copyProperties(notification, notificationResponseDto);
        return notificationResponseDto;
    }



}
