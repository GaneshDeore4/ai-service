package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingRequestDto;
import lombok.Data;

import java.util.List;

@Data
public class UserTypeMappingResponseDto {
    private Long userTypeId;
    private String userTypeName;
    private String userTypeNameLabel;
    private List<UserTypeTabActionMappingDto> tabMappings;
}
