package com.indusind.trade.model.entities;

import com.indusind.trade.model.utility.HashUtils;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

import java.lang.reflect.Field;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class HashListener {

//    @PrePersist
//    @PreUpdate
//    public void applyHash(Object entity) {
//        List<Field> fieldList = new ArrayList<>();
//        Map<Field, Class<?>> map =  new HashMap<>();
//        Class<?> clazz = entity.getClass();
//        while (clazz != null) {
//            Class<?> finalClazz = clazz;
//            Arrays.stream(clazz.getDeclaredFields()).filter(field->field.isAnnotationPresent(HashField.class)).forEach(field -> map.put(field, finalClazz));
//            fieldList.addAll(Arrays.stream(clazz.getDeclaredFields()).toList());
//            clazz = clazz.getSuperclass();
//        }
//        for (Field field : fieldList) {
//            if (field.isAnnotationPresent(HashField.class)) {
//                System.out.println(field.getName());
//                field.setAccessible(true);
//                try {
//                    String value = (String) field.get(entity);
//                    Field hashField = entity.getClass()
//                            .getDeclaredField(field.getName() + "Hash");
//                    hashField.setAccessible(true);
//                    hashField.set(entity, HashUtils.HAMCMD5Hash(value));
//                } catch (Exception e) {
//                    throw new RuntimeException(e);
//                }
//            }
//        }
//    }

    @PrePersist
    @PreUpdate
    public void applyHash(Object entity) {
        Map<Field, Class<?>> fieldClassMap = new HashMap<>();

        Class<?> clazz = entity.getClass();
        while (clazz != null) {
            Class<?> finalClazz = clazz;
            Arrays.stream(clazz.getDeclaredFields())
                    .filter(field -> field.isAnnotationPresent(HashField.class))
                    .forEach(field -> fieldClassMap.put(field, finalClazz));

            clazz = clazz.getSuperclass();
        }

        for (Map.Entry<Field, Class<?>> entry : fieldClassMap.entrySet()) {
            Field field = entry.getKey();
            Class<?> declaringClass = entry.getValue();

            try {
                field.setAccessible(true);
                String value = (String) field.get(entity);

                if (value == null) {
                    continue;
                }

                Field hashField = declaringClass
                        .getDeclaredField(field.getName() + "Hash");

                hashField.setAccessible(true);
                hashField.set(entity, HashUtils.HAMCMD5Hash(value));

            } catch (NoSuchFieldException e) {
                throw new RuntimeException(
                        "Missing hash field for: " + field.getName(), e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
    }
}