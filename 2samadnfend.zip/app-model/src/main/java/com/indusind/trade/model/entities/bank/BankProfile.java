package com.indusind.trade.model.entities.bank;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "gtp_bank_profile")
@Getter
@Setter
@RequiredArgsConstructor
public class BankProfile extends BankProfileBase{

    @Id
    @Column(name = "BANK_PROFILE_ID")
    private Long bankProfileId;

    @ManyToMany
    @JoinTable(
            name =  "gtp_bank_profile_product_mapping",
            joinColumns = @JoinColumn(name = "BANK_PROFILE_ID"),
            inverseJoinColumns = @JoinColumn(name = "PRODUCT_ID")
    )
    private List<ProductMaster> products;

    @ManyToMany
    @JoinTable(
            name = "gtp_bank_profile_sub_product_mapping",
            joinColumns = @JoinColumn(name = "BANK_PROFILE_ID"),
            inverseJoinColumns = @JoinColumn(name = "SUB_PRODUCT_ID")
    )
    private List<SubProductMaster> subProducts;

    public static BankProfileTemp convertToTempEntity(BankProfile bankProfile, BankProfileTemp bankProfileTemp) {
        BeanUtils.copyProperties(bankProfile, bankProfileTemp);
        bankProfileTemp.setProducts(Objects.nonNull(bankProfile.getProducts()) ? new ArrayList<>(bankProfile.getProducts()) : new ArrayList<>());
        bankProfileTemp.setSubProducts(Objects.nonNull(bankProfile.getSubProducts()) ? new ArrayList<>(bankProfile.getSubProducts()) : new ArrayList<>());
        return bankProfileTemp;
    }


}
