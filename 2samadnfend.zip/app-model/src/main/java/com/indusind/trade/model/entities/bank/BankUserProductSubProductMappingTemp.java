package com.indusind.trade.model.entities.bank;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Getter
@Setter
@Table(name = "gtp_bank_user_product_subprod_mapping_temp",
        indexes = {
                @Index(name = "idx_bank_user_prod_subprod_bankuser_temp", columnList = "bank_user_id"),
//                @Index(name = "idx_user_company_prod_subprod_company_temp", columnList = "company_id"),
                @Index(name = "idx_bank_user_prod_subprod_prod_temp", columnList = "product_id"),
                @Index(name = "idx_bank_user_prod_subprod_subprod_temp", columnList = "subproduct_id")
        },
        uniqueConstraints = @UniqueConstraint(
                name = "uk_bank_user_permission_temp_combination",
                columnNames = {
                        "bank_user_id",
                        "product_id",
                        "subproduct_id"
                }
        )
)
public class BankUserProductSubProductMappingTemp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bankUserProdSubprodId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bank_user_id", nullable = false)
    private BankUserTemp bankUserTemp;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster productMaster;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subproduct_id", nullable = false)
    private SubProductMaster subProductMaster;

    public static BankUserProductSubProductMapping convertToMasterEntity(BankUserProductSubProductMappingTemp bankUserProductSubProductMappingTemp){
        BankUserProductSubProductMapping bankUserProductSubProductMapping = new BankUserProductSubProductMapping();
        BeanUtils.copyProperties(bankUserProductSubProductMappingTemp, bankUserProductSubProductMapping);
        return bankUserProductSubProductMapping;
    }

}
