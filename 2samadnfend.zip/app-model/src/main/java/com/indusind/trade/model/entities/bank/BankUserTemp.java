package com.indusind.trade.model.entities.bank;

import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMappingTemp;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "gtp_bank_user_temp")
@Getter
@Setter
@RequiredArgsConstructor
public class BankUserTemp extends BankUserBase{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BANK_USER_ID")
    private Long bankUserId;

    @Column(name = "STATUS")
    private String status;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "bankUserTemp", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<BankUserProductSubProductMappingTemp> bankUserMappingTemp = new ArrayList<>();

    public static BankUser convertToMaster(BankUserTemp bankUserTemp, BankUser bankUser){
        BeanUtils.copyProperties(bankUserTemp, bankUser);
        return bankUser;
    }

    public void addBankUserProdSubProd(BankUserProductSubProductMappingTemp bankUserProductSubProductMappingTemp){
        bankUserProductSubProductMappingTemp.setBankUserTemp(this);
        bankUserMappingTemp.add(bankUserProductSubProductMappingTemp);
    }

}
