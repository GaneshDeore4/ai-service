package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_account")
@RequiredArgsConstructor
@Getter
@Setter
public class Account extends AccountBase {

    @Id
    @Column(name = "ACCOUNT_ID")
    private Long accountId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID", nullable = false)
    private Company company;

    public static AccountTemp convertToTempEntity(Account account){
        AccountTemp accountTemp = new AccountTemp();
        BeanUtils.copyProperties(account, accountTemp,"accountId");
        return accountTemp;
    }

}
