package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "account_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(HashListener.class)
public class AccountDetail {

    @Id
    @GeneratedValue
    @UuidGenerator
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @Column(name = "cif_id")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String cifId;

    @Column(name = "cif_id_hash")
    private String cifIdHash;

    @Column(name = "account_number", unique = true)
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String accountNumber;

    @Column(name = "account_number_hash", unique = true)
    private String accountNumberHash;

    @Column(name = "currency")
    private String currency;

    @Column(name = "scheme_description")
    private String schemeDescription;

    @Column(name = "scheme_type")
    private String schemeType;

    @Column(name = "effective_avail_balance", precision = 19, scale = 4)
    private BigDecimal effectiveAvailBalance;

    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @UpdateTimestamp
    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "accountMapping", cascade = CascadeType.ALL)
    private List<User> user;

}
