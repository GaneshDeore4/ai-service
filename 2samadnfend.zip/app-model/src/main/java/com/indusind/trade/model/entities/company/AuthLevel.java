package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@Table(name = "gtp_auth_level")
@Getter
@Setter
@SuperBuilder
@RequiredArgsConstructor
public class AuthLevel extends AuthLevelBase {

    @Id
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auth_matrix_id")
    private AuthMatrix authMatrix;

}
