package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_auth_level_temp")
@Getter
@Setter
@SuperBuilder
@RequiredArgsConstructor
public class AuthLevelTemp extends AuthLevelBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auth_matrix_id")
    private AuthMatrixTemp authMatrixTemp;

    public static AuthLevel convertToMaster(AuthLevelTemp authLevelTemp) {
        AuthLevel authLevel = new AuthLevel();
        BeanUtils.copyProperties(authLevelTemp, authLevel);

        return authLevel;
    }

    public static AuthLevelTemp convertToTemp(AuthLevel authLevel) {
        AuthLevelTemp authLevelTemp = new AuthLevelTemp();
        BeanUtils.copyProperties(authLevel, authLevelTemp,"id");

        return authLevelTemp;
    }

}
