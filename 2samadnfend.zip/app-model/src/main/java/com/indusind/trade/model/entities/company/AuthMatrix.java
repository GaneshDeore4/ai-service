package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.entities.master.EventType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "gtp_auth_matrix")
@RequiredArgsConstructor
@Getter
@Setter
public class AuthMatrix extends AuthMatrixBase {

    @Id
    private Long id;

    @OneToMany(mappedBy = "authMatrix", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AuthLevel> authLevels = new ArrayList<>();

//    @OneToMany(mappedBy = "authMatrix", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<EventType> eventTypes = new ArrayList<>();

    @ManyToMany
    @JoinTable(
            name = "gtp_auth_mat_account_mapping",
            joinColumns = @JoinColumn(name = "ID"),
            inverseJoinColumns = @JoinColumn(name = "ACCOUNT_ID")
    )
    private List<AccountDetail> accounts = new ArrayList<>();

    public static AuthMatrixTemp convertToTemp(AuthMatrix authMatrix, AuthMatrixTemp authMatrixTemp) {
        BeanUtils.copyProperties(authMatrix, authMatrixTemp, "id", "accounts");
        authMatrixTemp.getAuthLevels().addAll((authMatrix.getAuthLevels().stream().map(
                mat -> {
                    AuthLevelTemp authLevel = AuthLevelTemp.convertToTemp(mat);
                    authLevel.setAuthMatrixTemp(authMatrixTemp);
                    return authLevel;
                }
        ).toList()));
        authMatrixTemp.getAccounts().clear();
        authMatrixTemp.getAccounts().addAll(authMatrix.getAccounts());
        return authMatrixTemp;
    }
}
