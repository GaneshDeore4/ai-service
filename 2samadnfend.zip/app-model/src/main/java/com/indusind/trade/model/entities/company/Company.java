package com.indusind.trade.model.entities.company;


import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "gtp_company")
@Getter
@Setter
@RequiredArgsConstructor
public class Company extends CompanyBase {

    @Id
    @Column(name = "COMPANY_ID")
    private Long companyId;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "company", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Account> accountList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "company", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CustomerReference> customerReferenceList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "company", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LegalIdDetails> legalIdDetailsList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "company")
    List<User> userList = new ArrayList<>();

    @ManyToMany
    @JoinTable(
            name = "gtp_company_product_mapping",
            joinColumns = @JoinColumn(name = "COMPANY_ID"),
            inverseJoinColumns = @JoinColumn(name = "PRODUCT_ID")
    )
    private List<ProductMaster> products;

    @ManyToMany
    @JoinTable(
            name = "gtp_company_sub_product_mapping",
            joinColumns = @JoinColumn(name = "COMPANY_ID"),
            inverseJoinColumns = @JoinColumn(name = "SUB_PRODUCT_ID")
    )
    private List<SubProductMaster> subProducts;


    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CompanyProductLimitMapping> companyProductLimitMapping = new ArrayList<>();

    public static CompanyTemp convertToTempEntity(Company company, CompanyTemp companyTemp) {
        BeanUtils.copyProperties(company, companyTemp);
        companyTemp.setProducts(Objects.nonNull(company.getProducts()) ? new ArrayList<>(company.getProducts()) : new ArrayList<>());
        companyTemp.setSubProducts(Objects.nonNull(company.getSubProducts()) ? new ArrayList<>(company.getSubProducts()) : new ArrayList<>());
        return companyTemp;
    }

    public void addAccount(Account account) {
        account.setCompany(this);
        accountList.add(account);

    }

    public void addCustomerReference(CustomerReference ref) {
        ref.setCompany(this);
        customerReferenceList.add(ref);
    }

    public void addLegalId(LegalIdDetails legal) {
        legal.setCompany(this);
        legalIdDetailsList.add(legal);
    }

}


