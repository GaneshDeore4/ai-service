package com.indusind.trade.model.entities.company;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "gtp_company_product_limit_mapping")
@Getter
@Setter
@RequiredArgsConstructor
public class CompanyProductLimitMapping {

    @EmbeddedId
    private CompanyProductId id;

    private Long limitAmount;

    private Boolean midOfficeFlag = false;

}
