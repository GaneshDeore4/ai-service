package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "gtp_company_temp")
@Getter
@Setter
@RequiredArgsConstructor
public class CompanyTemp extends CompanyBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "COMPANY_ID")
    private Long companyId;

    @Column(name = "STATUS", nullable = false)
    private String status;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "companyTemp", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AccountTemp> accountTempList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "companyTemp", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CustomerReferenceTemp> customerReferenceTempList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "companyTemp", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LegalIdDetailsTemp> legalIdDetailsTempList = new ArrayList<>();

    @ManyToMany
    @JoinTable(
            name = "gtp_company_temp_product_mapping",
            joinColumns = @JoinColumn(name = "COMPANY_ID"),
            inverseJoinColumns = @JoinColumn(name = "PRODUCT_ID")
    )
    private List<ProductMaster> products;

    @ManyToMany
    @JoinTable(
            name = "gtp_company_temp_sub_product_mapping",
            joinColumns = @JoinColumn(name = "COMPANY_ID"),
            inverseJoinColumns = @JoinColumn(name = "SUB_PRODUCT_ID")
    )
    private List<SubProductMaster> subProducts;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CompanyProductLimitMappingTemp> companyProductLimitMapping = new ArrayList<>();


    public static Company convertToMasterEntity(CompanyTemp companyTemp, Company company) {
        BeanUtils.copyProperties(companyTemp, company);
        company.setProducts(Objects.nonNull(companyTemp.getProducts()) ? new ArrayList<>(companyTemp.getProducts()) : new ArrayList<>());
        company.setSubProducts(Objects.nonNull(companyTemp.getSubProducts()) ? new ArrayList<>(companyTemp.getSubProducts()) : new ArrayList<>());
        return company;
    }

    public void addAccountTemp(AccountTemp account) {
        account.setCompanyTemp(this);
        accountTempList.add(account);

    }

    public void addCustomerReferenceTemp(CustomerReferenceTemp ref) {
        ref.setCompanyTemp(this);
        customerReferenceTempList.add(ref);
    }

    public void addLegalIdTemp(LegalIdDetailsTemp legal) {
        legal.setCompanyTemp(this);
        legalIdDetailsTempList.add(legal);
    }

}
