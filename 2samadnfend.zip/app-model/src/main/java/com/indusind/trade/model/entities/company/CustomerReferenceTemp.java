package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_customer_reference_temp")
@Getter
@Setter
@RequiredArgsConstructor
public class CustomerReferenceTemp extends CustomerReferenceBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CUSTOMER_REFERENCE_ID")
    private Long customerReferenceId;

    @Column(name = "STATUS")
    private String status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID", nullable = false)
    private CompanyTemp companyTemp;

    public static CustomerReference convertToMasterEntity(CustomerReferenceTemp customerReferenceTemp) {
        CustomerReference customerReference = new CustomerReference();
        BeanUtils.copyProperties(customerReferenceTemp, customerReference);
        return customerReference;
    }

}
