package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_legal_id_details",
        indexes = {
                @Index(name = "idx_legal_company", columnList = "COMPANY_ID"),
                @Index(name = "idx_legal_user", columnList = "USER_ID"),
                @Index(name = "idx_legal_type", columnList = "legal_id_type")
        },
        uniqueConstraints = {
                @UniqueConstraint(
                        columnNames = {"legal_id_type", "legal_id_no", "COMPANY_ID"}
                ),
                @UniqueConstraint(
                        columnNames = {"legal_id_type", "legal_id_no", "USER_ID"}
                )
        }
)
@org.hibernate.annotations.Check(
        constraints = "(COMPANY_ID IS NOT NULL AND USER_ID IS NULL) OR "
                + "(COMPANY_ID IS NULL AND USER_ID IS NOT NULL)"
)
@Getter
@Setter
@RequiredArgsConstructor
public class LegalIdDetails extends LegalIdDetailsBase {

    @Id
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID")
    private Company company;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID")
    private User user;

    public static LegalIdDetailsTemp convertToTempEntity(LegalIdDetails legalIdDetails) {
        LegalIdDetailsTemp legalIdDetailsTemp = new LegalIdDetailsTemp();
        BeanUtils.copyProperties(legalIdDetails, legalIdDetailsTemp, "id");
        return legalIdDetailsTemp;
    }

}
