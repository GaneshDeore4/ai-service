package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_legal_id_details_temp",
        indexes = {
                @Index(name = "idx_legal_company_temp", columnList = "COMPANY_ID"),
                @Index(name = "idx_legal_user_temp", columnList = "USER_ID"),
                @Index(name = "idx_legal_type_temp", columnList = "legal_id_type")
        },
        uniqueConstraints = {
                @UniqueConstraint(
                        columnNames = {"legal_id_type", "legal_id_no", "COMPANY_ID"}
                ),
                @UniqueConstraint(
                        columnNames = {"legal_id_type", "legal_id_no", "USER_ID"}
                )
        }
)
@org.hibernate.annotations.Check(
        constraints = "(COMPANY_ID IS NOT NULL AND USER_ID IS NULL) OR "
                + "(COMPANY_ID IS NULL AND USER_ID IS NOT NULL)"
)
@Getter
@Setter
@RequiredArgsConstructor
public class LegalIdDetailsTemp extends LegalIdDetailsBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "STATUS")
    private String status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID")
    private CompanyTemp companyTemp;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID")
    private UserTemp userTemp;

    public static LegalIdDetails convertToMasterEntity(LegalIdDetailsTemp legalIdDetailsTemp){
        LegalIdDetails legalIdDetails = new LegalIdDetails();
        BeanUtils.copyProperties(legalIdDetailsTemp, legalIdDetails);
        return legalIdDetails;
    }


}
