package com.indusind.trade.model.entities.company;


import com.indusind.audit.entity.Auditable;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SQLRestriction;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.BeanUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "gtp_notifications")
@SQLRestriction("DELETED_DATE is null")
@Getter
@Setter
public class Notification extends Auditable {

    @Id
    @Column(name = "notification_id")
    private Long notificationId;

    @Column(name = "NOTIFICATION_TITLE")
    private String notificationTitle;

    @Column(name = "NOTIFICATION_DESC")
    private String notificationDesc;

    @CreationTimestamp
    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @UpdateTimestamp
    @Column(name = "MODIFIED_DATE")
    private LocalDateTime modifiedDate;

    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

    @Column(name = "DELETED_BY")
    private String deletedBy;

    @Column(name = "DELETED_DATE")
    private LocalDateTime deletedDate;

    @Column(name = "VALID_UPTO")
    private LocalDate validUpto;

    @Column(name = "IS_ACTIVE", nullable = false)
    private Boolean isActive;

    public static NotificationTemp convertToTempEntity(Notification notification, NotificationTemp notificationTemp){
        BeanUtils.copyProperties(notification, notificationTemp);
        return notificationTemp;
    }

}

