package com.indusind.trade.model.entities.company;


import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Embeddable
@Getter
@Setter
@RequiredArgsConstructor
public class SwiftAddress {

    @Column(name = "ADDRESS_LINE_1")
    private String addressLine1;

    @Column(name = "ADDRESS_LINE_2")
    private String addressLine2;

    @Column(name = "ADDRESS_LINE_3")
    private String addressLine3;

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "CONTACT_REFERENCE")
    private String contactReference;

    private String strtName;

    private String buildingNumber;

    private String buildingName;

    private String floor;

    private String room;

    private String districtName;

    private String countrySubdivision;

    private String department;

    private String subDepartment;

    private Long postalCode;

    private String swiftTownName;

    private String country;


}
