package com.indusind.trade.model.entities.company;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import com.indusind.trade.model.entities.master.UserType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@MappedSuperclass
@Getter
@Setter
@RequiredArgsConstructor
@EntityListeners(HashListener.class)
public class UserBase extends Auditable {

    @Column(name = "LOGIN_ID", unique = true, nullable = false)
    private String loginId;

    @Column(name = "USER_PASSWORD")
    private String userPassword;

    @Column(name = "FIRST_NAME")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String firstName;

    @Column(name = "FIRST_NAME_HASH")
    private String firstNameHash;

    @Column(name = "LAST_NAME")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String lastName;

    @Column(name = "LAST_NAME_HASH")
    private String lastNameHash;

    @Column(name = "EMPLOYEE_DEPARTMENT")
    private String employeeDepartment;

    @Column(name = "EMPLOYEE_NO")
    private String employeeNo;

    @Column(name = "ADDRESS_LINE1")
    private String addressLine1;

    @Column(name = "ADDRESS_LINE_2")
    private String addressLine2;

    @Column(name = "ADDRESS_LINE3")
    private String addressLine3;

    @Column(name = "ADDRESS_LINE4")
    private String addressLine4;

    @Column(name = "ADDRESS_LINE5")
    private String addressLine5;

    @Column(name = "POSTAL_CODE")
    private String postalCode;

    @Column(name = "USER_STATUS")
    private String userStatus;

    @Column(name = "AUTH_MODE")
    private String authMode;

    @Column(name = "TIME_ZONE")
    private String timeZone;

    @Column(name = "CORR_LANGUAGE")
    private String corrLanguage;

    @Column(name = "BASE_CURR")
    private String baseCurr;

//    @Column(name = "LEGAL_ID_NO")
//    private Long legalIdNumber;
//
//    @Column(name = "ISSUING_AUTH")
//    private String issuingAuth;

    @Column(name = "CONTACT_NO")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String contactNo;

    @Column(name = "CONTACT_NO_HASH")
    private String contactNoHash;

    @Column(name = "CONTACT_NO_COUNTRY_CODE")
    private String contactNoCountryCode;

//    @Column(name = "FAX")
//    private String fax;

    @Column(name = "EMAIL")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String email;

    @Column(name = "EMAIL_HASH")
    private String emailHash;

    @Column(name = "PENDING_TRANS_NOTIFY")
    private String pendingTransNotify;

    @ManyToOne
    @JoinColumn(name = "USER_TYPE_ID")
    private UserType userType;

//    @Column(name = "AUTHORISATION_LEVEL")
//    private String authLevel;

    @Column(name = "CCY")
    private String ccy;

    @Column(name = "LIMIT_AMOUNT")
    private String limitAmount;

    @Column(name = "LAST_LOGIN")
    private LocalDateTime lastLogin;

    @Column(name = "CREATED")
    private LocalDateTime created;

    @Column(name = "MAKER")
    private String maker;

    @Column(name = "MODIFIED_AT")
    private LocalDateTime modifiedAt;

    @Column(name = "DELETED_AT")
    private LocalDateTime deletedAt;

    @ManyToOne
    @JoinColumn(name = "COMPANY_ID")
    private Company company;

    @ManyToOne
    @JoinColumn(name = "AUTH_GROUP")
    private AuthGroup authGroup;

}
