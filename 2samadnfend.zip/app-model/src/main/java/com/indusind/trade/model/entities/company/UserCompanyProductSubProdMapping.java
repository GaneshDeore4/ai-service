package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Getter
@Setter
@Table(name = "gtp_user_company_product_subprod_mapping", uniqueConstraints = @UniqueConstraint(name="uk_user_company_permission_combination",
columnNames = {
        "user_id",
        "product_id",
        "subproduct_id"
}))
@RequiredArgsConstructor
public class UserCompanyProductSubProdMapping {

    @Id
    private Long usercompanysubproductid;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster productMaster;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subproduct_id")
    private SubProductMaster subProductMaster;

    public static UserCompanyProductSubProdMappingTemp convertToTempEntity(UserCompanyProductSubProdMapping userMap) {
        UserCompanyProductSubProdMappingTemp userCompanyProductSubProdMappingTemp = new UserCompanyProductSubProdMappingTemp();
        BeanUtils.copyProperties(userMap,userCompanyProductSubProdMappingTemp, "usercompanysubproductid");
        return userCompanyProductSubProdMappingTemp;
    }
}
