package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="GTP_USER_TEMP")
@Getter
@Setter
@RequiredArgsConstructor
public class UserTemp extends UserBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "STATUS", nullable = false)
    private String status;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "userTemp", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LegalIdDetailsTemp> legalIdDetailsTempList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "userTemp", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserCompanyProductSubProdMappingTemp> userMappingTemp = new ArrayList<>();


    public static User convertToMaster(UserTemp userTemp, User user){
        //User user = new User();
        BeanUtils.copyProperties(userTemp, user);
        //userTemp.setAuthGroup(Objects.nonNull(user.getAuthGroup()) ? new ArrayList<>(user.getAuthGroup()) : new ArrayList<>());
        //user.setLegalIdDetailsList(userTemp.getLegalIdDetailsTempList().stream().map(LegalIdDetailsTemp::convertToMasterEntity).collect(Collectors.toList()));
        return user;
    }

//    public static Company convertToMasterEntity(CompanyTemp companyTemp, Company company) {
//        BeanUtils.copyProperties(companyTemp, company);
////        if(Objects.nonNull(companyTemp.getProducts())){
////            companyTemp.getProducts().forEach(prod->{
////                company.getProducts().add(prod);
////            });
////        }
////        if(Objects.nonNull(companyTemp.getSubProducts())){
////            companyTemp.getSubProducts().forEach(subProd->{
////                company.getSubProducts().add(subProd);
////            });
////        }
//        company.setProducts(Objects.nonNull(companyTemp.getProducts()) ? new ArrayList<>(companyTemp.getProducts()) : new ArrayList<>());
//        company.setSubProducts(Objects.nonNull(companyTemp.getSubProducts()) ? new ArrayList<>(companyTemp.getSubProducts()) : new ArrayList<>());
//        return company;
//    }

    public void addLegalIdTemp(LegalIdDetailsTemp legal) {
        legal.setUserTemp(this);
        legalIdDetailsTempList.add(legal);
    }

    public void addUserCompanyProdSubProd(UserCompanyProductSubProdMappingTemp userCompanyProductSubProdMappingTemp) {
        userCompanyProductSubProdMappingTemp.setUserTemp(this);
        userMappingTemp.add(userCompanyProductSubProdMappingTemp);
    }
}
