package com.indusind.trade.model.entities.master;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;

/**
 * Centralized, immutable audit log — covers all 5 Ws.
 * APPEND-ONLY: never update or delete records.
 * DB constraint enforced by not exposing update/delete in repository.
 */
@Entity
@Table(name = "AUDIT_LOG", indexes = {
        @Index(name = "idx_audit_loginid", columnList = "PERFORMED_BY"),
        @Index(name = "idx_audit_action", columnList = "ACTION"),
        @Index(name = "idx_audit_resource", columnList = "RESOURCE_TYPE,RESOURCE_ID"),
        @Index(name = "idx_audit_sessionid", columnList = "SESSION_ID"),
        @Index(name = "idx_audit_timestamp", columnList = "TIMESTAMP")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "audit_seq")
    @SequenceGenerator(name = "audit_seq", sequenceName = "AUDIT_LOG_SEQ", allocationSize = 1)
    @Column(name = "AUDIT_ID")
    private Long auditId;

    // ── WHO ──────────────────────────────────────
    @Column(name = "PERFORMED_BY", length = 100)
    private String performedBy; // loginId

    @Column(name = "ROLE_NAME", length = 50)
    private String roleName;

    @Column(name = "USER_TYPE", length = 20)
    private String userType; // USER / SERVICE

    @Column(name = "COMPANY_ID")
    private Long companyId;

    // ── WHAT ─────────────────────────────────────
    @Column(name = "ACTION", nullable = false, length = 50)
    private String action; // CREATE, UPDATE, DELETE, LOGIN, LOGOUT, APPROVE, REJECT

    @Column(name = "RESOURCE_TYPE", length = 50)
    private String resourceType; // User, Company, Role, Remittance

    @Column(name = "RESOURCE_ID", length = 100)
    private String resourceId; // ID of the affected record

    @Column(name = "MODULE", length = 50)
    private String module; // AUTH, USER, COMPANY, REMITTANCE

    // ── WHEN ─────────────────────────────────────
    @Column(name = "TIMESTAMP", nullable = false, updatable = false)
    private LocalDateTime timestamp; // UTC

    // ── WHERE ────────────────────────────────────
    @Column(name = "IP_ADDRESS", length = 64)
    private String ipAddress;

    @Column(name = "SERVICE_NAME", length = 50)
    private String serviceName; // auth-service, admin-service, inward-remittance

    @Column(name = "HOSTNAME", length = 100)
    private String hostname;

    // ── WHY / OUTCOME ────────────────────────────
    @Column(name = "OUTCOME", length = 20)
    private String outcome; // SUCCESS / FAILURE / WARNING

    @Column(name = "REASON", length = 500)
    private String reason; // Justification for critical actions

    @Column(name = "ERROR_MESSAGE", length = 500)
    private String errorMessage; // On failure

    // ── CHANGE DATA ──────────────────────────────
    @Lob
    @Column(name = "OLD_VALUE")
    private String oldValue; // JSON snapshot before

    @Lob
    @Column(name = "NEW_VALUE")
    private String newValue; // JSON snapshot after

    // ── CORRELATION ──────────────────────────────
    @Column(name = "SESSION_ID", length = 36)
    private String sessionId; // From JWT claim

    @Column(name = "CORRELATION_ID", length = 36)
    private String correlationId; // X-Correlation-ID header
}
