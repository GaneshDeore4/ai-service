package com.indusind.trade.model.entities.master;


import com.indusind.audit.entity.Auditable;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
@Table(
        name = "gtp_department",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_department_name_label_with_category",
                        columnNames = {"DEPARTMENT_LABEL", "CATEGORY_ID"}
                )
        }
)
@RequiredArgsConstructor
public class Department extends Auditable {

    @Id
    private Long id;

    @Column(name = "DEPARTMENT_NAME", nullable = false)
    private String departmentName;

    @Column(name = "DEPARTMENT_LABEL", nullable = false)
    private String departmentNameLabel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CATEGORY_ID", referencedColumnName = "CATEGORY_ID", nullable = false)
    private CategoryMaster category;

    @ManyToMany
    @JoinTable(
            name = "gtp_department_user_type_mapping",
            joinColumns = @JoinColumn(name = "ID"),
            inverseJoinColumns = @JoinColumn(name = "USER_TYPE_ID")
    )
    private List<UserType> userTypes;

}
