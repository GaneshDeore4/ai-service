package com.indusind.trade.model.entities.master;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.Department;
import com.indusind.trade.model.enums.Status;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "gtp_department_temp",
        uniqueConstraints = {
        @UniqueConstraint(name = "uk_department_name_label_with_category_temp",
        columnNames = {"DEPARTMENT_LABEL", "CATEGORY_ID"})
        }
)
@RequiredArgsConstructor
public class DepartmentTemp extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "DEPARTMENT_NAME", nullable = false)
    private String departmentName;

    @Column(name = "DEPARTMENT_LABEL", nullable = false)
    private String departmentNameLabel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CATEGORY_ID", referencedColumnName = "CATEGORY_ID", nullable = false)
    private CategoryMaster category;

    @Column(name="STATUS", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

    public static Department convertToMaster(DepartmentTemp departmentTemp, Department department){
        BeanUtils.copyProperties(departmentTemp, department);
        department.setCategory(departmentTemp.getCategory());
        return department;
    }


}
