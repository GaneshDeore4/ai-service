package com.indusind.trade.model.entities.master;

import com.indusind.audit.entity.Auditable;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(
        name = "gtp_product_master",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_product_with_category",
                        columnNames = {"PRODUCT_NAME_LABEL", "CATEGORY_ID"}
                )
        },
        indexes = {
                @Index(name = "idx_product_category", columnList = "CATEGORY_ID"),
                @Index(name = "idx_product_product_label", columnList = "PRODUCT_NAME_LABEL")
        }
)
@Getter
@Setter
@RequiredArgsConstructor
public class ProductMaster extends Auditable {

    @Id
    @Column(name = "PRODUCT_ID")
    private Long productId;

    @Column(name="PRODUCT_NAME", nullable = false)
    private String productName;

    @Column(name="PRODUCT_NAME_LABEL", nullable = false)
    private String productNameLabel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CATEGORY_ID", referencedColumnName = "CATEGORY_ID", nullable = false)
    private CategoryMaster category;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "productMaster")
    private List<SubProductMaster> subProductMasterList = new ArrayList<>();

    //bidirectional mapping for fetching
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "product")
    private List<TabMaster> tabs = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY,mappedBy = "product")
    private List<TabMasterTemp> tabsTemp = new ArrayList<>();

    //bidirectional mapping for fetching
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "product")
    private List<Action> actions = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "product")
    private List<ActionTemp> actionsTemp = new ArrayList<>();

    private Boolean midOfficeFlag = false;

    private Long sequenceId;


}
