package com.indusind.trade.model.entities.master;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.enums.Status;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(
        name = "gtp_product_master_temp",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_product_with_category_temp",
                        columnNames = {"PRODUCT_NAME_LABEL", "CATEGORY_ID"}
                )
        },
        indexes = {
                @Index(name = "idx_product_category_temp", columnList = "CATEGORY_ID"),
                @Index(name = "idx_product_product_label_temp", columnList = "PRODUCT_NAME_LABEL")

        }
)
@Getter
@Setter
@RequiredArgsConstructor
public class ProductMasterTemp extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PRODUCT_ID")
    private Long productId;

    @Column(name="PRODUCT_NAME", nullable = false)
    private String productName;

    @Column(name="PRODUCT_NAME_LABEL", nullable = false)
    private String productNameLabel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CATEGORY_ID", referencedColumnName = "CATEGORY_ID", nullable = false)
    private CategoryMaster category;

    @Column(name="STATUS", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

//    @OneToMany(fetch = FetchType.LAZY, mappedBy = "productMasterTemp")
//    private List<SubProductMasterTemp> subProductMasterTempList = new ArrayList<>();

    //bidirectional mapping for fetching
//    @ManyToMany(fetch = FetchType.LAZY,mappedBy = "productsTemp")
//    private List<TabMasterTemp> tabsTemp = new ArrayList<>();

    //bidirectional mapping for fetching
//    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "productMasterTemp")
//    private List<ActionTemp> actionsTemp = new ArrayList<>();

    private Boolean midOfficeFlag = false;

    private Long sequenceId;


}
