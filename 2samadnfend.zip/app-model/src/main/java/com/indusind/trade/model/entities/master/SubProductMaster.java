package com.indusind.trade.model.entities.master;

import com.indusind.audit.entity.Auditable;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(
        name = "gtp_sub_product_master",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_sub_product_with_category",
                        columnNames = {"PRODUCT_ID", "SUB_PRODUCT_LABEL"}
                )
        },
        indexes = @Index(name = "idx_subproduct_product", columnList = "product_id")
)
@Getter
@Setter
@RequiredArgsConstructor
public class SubProductMaster extends Auditable {

    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long subProductId;

    @Column(name = "SUB_PRODUCT_NAME", nullable = false)
    private String subProductName;

    @Column(name = "SUB_PRODUCT_LABEL")
    private String subProductLabel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID", referencedColumnName = "PRODUCT_ID", nullable = false)
    private ProductMaster productMaster;

    //bidirectional mapping for fetching
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "subProduct")
    private List<TabMaster> tabs = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY,mappedBy = "subProduct")
    private List<TabMasterTemp> tabsTemp = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "subProduct")
    private List<Action> actions = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "subProduct")
    private List<ActionTemp> actionsTemp = new ArrayList<>();

    private Long sequenceId;
}
