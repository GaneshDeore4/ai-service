package com.indusind.trade.model.entities.master;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.TabMaster;
import com.indusind.trade.model.enums.Status;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(
        name = "gtp_sub_product_master_temp",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_sub_product_with_category_temp",
                        columnNames = {"PRODUCT_ID", "SUB_PRODUCT_LABEL"}
                )
        },
        indexes = {
                @Index(name = "idx_subproduct_product_temp", columnList = "product_id"),
                @Index(name = "idx_subproduct_product_label_temp", columnList = "sub_product_label")
        }

)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubProductMasterTemp extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long subProductId;

    @Column(name = "SUB_PRODUCT_NAME", nullable = false)
    private String subProductName;

    @Column(name = "SUB_PRODUCT_LABEL")
    private String subProductLabel;

    @Enumerated(EnumType.STRING)
    private Status status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID", referencedColumnName = "PRODUCT_ID", nullable = false)
    private ProductMaster productMaster;

    //bidirectional mapping for fetching
//    @ManyToMany(mappedBy = "subProductsTemp")
//    private List<TabMasterTemp> tabsTemp = new ArrayList<>();

//    @CreationTimestamp
//    @Column(name = "CREATED_AT")
//    private LocalDate createdAt;

    private Long sequenceId;
}
