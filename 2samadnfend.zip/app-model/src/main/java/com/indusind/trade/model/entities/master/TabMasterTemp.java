package com.indusind.trade.model.entities.master;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.enums.Status;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(
        name = "gtp_tab_master_temp",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_tab_temp_with_prod_subprod",
                        columnNames = {"TAB_LABEL", "PRODUCT_ID", "SUB_PRODUCT_ID"}
                )
        },
        indexes = {
                @Index(name = "idx_tab_temp_product", columnList = "PRODUCT_ID"),
                @Index(name = "idx_tab_temp_sub_product", columnList = "SUB_PRODUCT_ID"),
                @Index(name = "idx_tab_temp_tab_label", columnList = "TAB_LABEL")
        }
)
@Getter
@Setter
@RequiredArgsConstructor
public class TabMasterTemp extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TAB_ID", nullable = false)
    private Long tabId;

    @Column(name = "TAB_NAME", nullable = false)
    private String tabName;

    @Column(name = "TAB_LABEL", nullable = false)
    private String tabLabel;

    @Column(name="STATUS")
    @Enumerated(EnumType.STRING)
    private Status status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private ProductMaster product;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SUB_PRODUCT_ID")
    private SubProductMaster subProduct;

}
