package com.indusind.trade.model.entities.master;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.master.CategoryMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
@Table(
        name = "gtp_user_type",
        uniqueConstraints = {
            @UniqueConstraint(
                    name = "uk_user_type_with_category",
                    columnNames = {"USER_TYPE_NAME_LABEL","USER_TYPE_NAME", "CATEGORY_ID"}
            )
        },
        indexes = {
                @Index(name = "idx_user_type_category", columnList = "CATEGORY_ID"),
                @Index(name = "idx_user_type_name_label", columnList = "USER_TYPE_NAME_LABEL"),
        }
)
@RequiredArgsConstructor
public class UserType extends Auditable {

    @Id
    private Long userTypeId;

    @Column(name = "USER_TYPE_NAME", nullable = false)
    private String userTypeName;

    @Column(name = "USER_TYPE_NAME_LABEL", nullable = false)
    private String userTypeNameLabel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CATEGORY_ID", referencedColumnName = "CATEGORY_ID", nullable = false)
    private CategoryMaster category;

    @Column(name = "STATUS")
    private String status;

    @ManyToMany(fetch = FetchType.LAZY,mappedBy = "userTypes")
    private List<Department> departments;

    @CreationTimestamp
    private LocalDateTime createdAt;

}
