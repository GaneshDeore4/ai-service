package com.indusind.trade.model.entities.master;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(
        name = "gtp_usertype_tab_action_mapping",
        indexes = {
                @Index(name = "idx_usertype_tab_action_user_type", columnList = "user_type_id"),
                @Index(name = "idx_usertype_tab_action_product", columnList = "product_id"),
                @Index(name = "idx_usertype_tab_action_subproduct", columnList = "subproduct_id"),
                @Index(name = "idx_usertype_tab_action_tab", columnList = "tab_id"),
                @Index(name = "idx_usertype_tab_action_action", columnList = "action_id")
        },
        uniqueConstraints = @UniqueConstraint(
                name = "uk_user_permission_combination",
                columnNames = {
                        "user_type_id",
                        "product_id",
                        "subproduct_id",
                        "tab_id",
                        "action_id"
                }
        )
)
@RequiredArgsConstructor
public class UserTypeTabActionMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tabActionMapId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_type_id", nullable = false)
    private UserType userType;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster product;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subproduct_id")
    private SubProductMaster subProduct; // nullable if product has no subproduct

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "tab_id", nullable = false)
    private TabMaster tab;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "action_id", nullable = false)
    private Action action;

}
