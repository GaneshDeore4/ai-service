package com.indusind.trade.model.entities.master;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.enums.Status;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(
        name = "gtp_user_type_temp",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_user_type_temp_with_category",
                        columnNames = {"USER_TYPE_NAME_LABEL","USER_TYPE_NAME", "CATEGORY_ID"}
                )
        },
        indexes = {
                @Index(name = "idx_user_type_temp_category", columnList = "CATEGORY_ID"),
                @Index(name = "idx_user_type_name_temp_label", columnList = "USER_TYPE_NAME_LABEL")
        }
)
@RequiredArgsConstructor
public class UserTypeTemp extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userTypeId;

    @Column(name = "USER_TYPE_NAME", nullable = false)
    private String userTypeName;

    @Column(name = "USER_TYPE_NAME_LABEL", nullable = false)
    private String userTypeNameLabel;

//    @CreationTimestamp
//    private LocalDateTime createdAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CATEGORY_ID", referencedColumnName = "CATEGORY_ID", nullable = false)
    private CategoryMaster category;

    @Column(name="STATUS", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

    public static UserType convertToMaster(UserTypeTemp userTypeTemp, UserType userType){
        BeanUtils.copyProperties(userTypeTemp, userType);
        userType.setCategory(userTypeTemp.getCategory());
        return userType;
    }

}
