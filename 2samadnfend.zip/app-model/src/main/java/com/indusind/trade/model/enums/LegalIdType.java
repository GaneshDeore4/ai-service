package com.indusind.trade.model.enums;

public enum LegalIdType {
    PAN,
    GSTIN,
    CIN,
    PASSPORT,
    AADHAAR,
    TAX_ID,
    OTHER
}
