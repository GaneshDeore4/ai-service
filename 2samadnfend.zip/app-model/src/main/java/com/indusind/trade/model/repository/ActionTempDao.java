package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.ActionTemp;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ActionTempDao extends JpaRepository<ActionTemp, Long> {

    Optional<ActionTemp> findByActionCode(String actionName);

    List<ActionTemp> findAllByOrderByActionCodeAsc();
}
