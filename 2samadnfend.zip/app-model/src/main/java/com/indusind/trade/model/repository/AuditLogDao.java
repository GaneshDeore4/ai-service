package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository for persisting Auth-Service audit events.
 */
@Repository
public interface AuditLogDao extends JpaRepository<AuditLog, Long> {
}
