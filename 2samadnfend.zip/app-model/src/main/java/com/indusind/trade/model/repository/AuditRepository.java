package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

/**
 * AuditRepository — READ-ONLY queries + save (no delete/update exposed).
 * Append-only enforced by not exposing delete methods.
 */
@Repository
public interface AuditRepository extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findByPerformedByOrderByTimestampDesc(String performedBy);

    List<AuditLog> findByActionOrderByTimestampDesc(String action);

    List<AuditLog> findByResourceTypeAndResourceIdOrderByTimestampDesc(
            String resourceType, String resourceId);

    List<AuditLog> findBySessionIdOrderByTimestampDesc(String sessionId);

    List<AuditLog> findByTimestampBetweenOrderByTimestampDesc(Instant from, Instant to);

    List<AuditLog> findByModuleOrderByTimestampDesc(String module);
}
