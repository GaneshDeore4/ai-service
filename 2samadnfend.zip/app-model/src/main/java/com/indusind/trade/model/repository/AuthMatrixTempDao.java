package com.indusind.trade.model.repository;

import com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupKeyDto;
import com.indusind.trade.model.entities.company.AuthMatrixTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AuthMatrixTempDao extends JpaRepository<AuthMatrixTemp, Long> {
    Long deleteByCompanyCompanyIdAndProductProductId(Long companyId, Long productId);

    boolean existsByCompanyCompanyIdAndProductProductIdAndSubProductSubProductIdAndAmountAndCurrencyType(Long companyId, Long productId, Long subProductId, Long amount, String currencyType);

    boolean existsByCompanyCompanyIdAndProductProductIdAndSubProductSubProductIdAndAmountAndIsAllProductFlagAndCurrencyType(Long companyId, Long productId, Long subProductId, Long amount, boolean isAllProductFlag, String currencyType);

    AuthMatrixTemp findByCompanyCompanyIdAndProductProductIdAndSubProductSubProductIdAndAmountAndIsAllProductFlagAndCurrencyType(Long companyId, Long productId, Long subProductId, Long amount, boolean isAllProductFlag, String currencyType);

    List<AuthMatrixTemp> findByCompanyCompanyIdAndAmountAndIsAllProductFlagAndCurrencyType(Long companyId, Long amount, boolean isAllProductFlag, String currencyType);

    boolean existsByCompanyCompanyIdAndAmountAndIsAllProductFlagAndCurrencyType(Long companyId, Long amount, boolean isAllProdFlag, String currencyType);

    @Query("""
        SELECT new com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupKeyDto(
            a.company.id,
            a.amount
        )
        FROM AuthMatrixTemp a
        WHERE a.isAllProductFlag = true
        GROUP BY a.company.id, a.amount
    """)
    Page<AuthMatrixGroupKeyDto> findGroupedKeys(Pageable pageable);


//    @Query("""
//        SELECT DISTINCT a
//        FROM AuthMatrixTemp a
//        LEFT JOIN FETCH a.authLevels al
//        LEFT JOIN FETCH a.eventTypes et
//        WHERE a.isAllProductFlag = true
//        AND a.company.id = :companyId
//        AND a.amount = :amount
//    """)
//    List<AuthMatrixTemp> findGroupedRecords(Long companyId, Long amount);

    @Query("""
        SELECT a
        FROM AuthMatrixTemp a
        WHERE a.isAllProductFlag = true
        AND a.category = :category 
        AND (:companyId IS NULL OR a.company.companyId = :companyId)
    """)
    Page<AuthMatrixTemp> findPagedAuthMatrix(@org.springframework.data.repository.query.Param("category") String category,
                                             @org.springframework.data.repository.query.Param("companyId") Long companyId,
                                             Pageable pageable);

    Page<AuthMatrixTemp> findByIsAllProductFlag(boolean productFlag, Pageable page);

    Optional<AuthMatrixTemp> findByIdAndCategory(Long id, String category);

    Page<AuthMatrixTemp> findByIsAllProductFlagAndCategory(boolean productFlag, String category, Pageable page);

    Page<AuthMatrixTemp> findByIsAllProductFlagAndCategoryAndCompanyCompanyId(boolean productFlag, String category, Long companyId, Pageable page);



    //    @Query("""
//            select
//                a.company.companyId,
//                NULL as product,
//                NULL as subProduct,
//                a.amount,
//                a.isAllProductFlag,
//                a.status,
//                a.isVerifier,
//                a.isReleaser,
//                a.isSequential,
//                concat(a.id, '_', a.company.companyId, '_', a.amount) as id
//            from AuthMatrixTemp a
//                where a.isAllProductFlag = true
//            group by
//                a.company.companyId,
//                 a.amount,
//                 a.isAllProductFlag,
//                 a.status,
//                 a.isVerifier,
//                 a.isReleaser,
//                 a.isSequential,
//                 a.id
//            """)
//    @Query(
//            value = """
//                SELECT
//                    amt.company_id                                             AS companyId,
//                    amt.amount                                                 AS amount,
//                    -- If these fields are guaranteed same within group you can use MIN or MAX instead of bool_or
//                    bool_or(amt.is_verifier)                                   AS isVerifier,
//                    bool_or(amt.is_releaser)                                   AS isReleaser,
//                    bool_or(amt.is_sequential)                                 AS isSequential,
//                    TRUE                                                       AS isAllProductFlag,
//                    amt.currency_type                                          AS currencyType,
//                    amt.status                                                 AS status,
//                    string_agg(amt.id::text, ',')                              AS ids,
//                    -- distinct event types across the group
//                    array_to_string(array_agg(DISTINCT et.event_type), ',')    AS eventType,
//                    -- Aggregate authGroup + seqNo per group as JSON array
//                    COALESCE(
//                      jsonb_agg(DISTINCT jsonb_build_object('group', ag.name, 'seqNo', al.seq_no))
//                      FILTER (WHERE ag.name IS NOT NULL AND al.seq_no IS NOT NULL),
//                    '[]'::jsonb)                                               AS authGroup
//                FROM gtp_auth_matrix_temp amt
//                LEFT JOIN gtp_event_type_temp et ON et.auth_matrix_id = amt.id
//                LEFT JOIN gtp_auth_level_temp al ON al.auth_matrix_id = amt.id
//                LEFT JOIN auth_group ag ON ag.id = al.auth_group_id
//                WHERE amt.is_all_product_flag = TRUE
//                GROUP BY amt.company_id, amt.amount, amt.currency_type, amt.status
//                ORDER BY amt.company_id, amt.amount
//                """,
//            countQuery = """
//                SELECT COUNT(*) FROM (
//                  SELECT 1
//                  FROM gtp_auth_matrix_temp amt
//                  WHERE amt.is_all_product_flag = TRUE
//                  GROUP BY amt.company_id, amt.amount, amt.currency_type, amt.status
//                ) t
//                """,
//            nativeQuery = true
//    )
//    Page<AuthMatrixGroupedProjection> findAllByIsProductFlag(Pageable pageable);
}
