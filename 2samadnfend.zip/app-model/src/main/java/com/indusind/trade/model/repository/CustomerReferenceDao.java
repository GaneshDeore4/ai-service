package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.CustomerReference;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerReferenceDao extends JpaRepository<CustomerReference, Long> {
}
