package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DepartmentDao extends JpaRepository<Department, Long> {

    @Query("SELECT d FROM Department d WHERE d.category.categoryId = :categoryId")
    List<Department> findByCategoryId(@Param("categoryId") Long categoryId);
}
