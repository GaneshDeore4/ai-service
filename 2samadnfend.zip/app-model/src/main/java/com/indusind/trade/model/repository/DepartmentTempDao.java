package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.DepartmentTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentTempDao extends JpaRepository<DepartmentTemp, Long> {
}
