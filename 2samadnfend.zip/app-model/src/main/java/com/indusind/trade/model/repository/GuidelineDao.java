package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.Guideline;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface GuidelineDao extends JpaRepository<Guideline, Long> {

    @Query("""
            SELECT g from Guideline g
            WHERE g.isActive = true
            AND g.validUpto >= :currentDate
            """)
    List<Guideline> fetchAllGuidelineClient(LocalDate currentDate);
}
