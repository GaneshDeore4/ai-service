package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.GuideLineTemp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GuidelineTempDao extends JpaRepository<GuideLineTemp, Long> {
}
