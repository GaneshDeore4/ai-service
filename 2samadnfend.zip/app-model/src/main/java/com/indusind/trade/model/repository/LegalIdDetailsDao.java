package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.LegalIdDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LegalIdDetailsDao extends JpaRepository<LegalIdDetails, Long> {
}
