package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.NotificationTemp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationTempDao extends JpaRepository<NotificationTemp, Long> {
}
