package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.ProductMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductMasterDao extends JpaRepository<ProductMaster, Long> {

    List<ProductMaster> findByProductIdIn(List<Long> productsIds);

    List<ProductMaster> findAllByOrderByProductNameAsc();

    List<ProductMaster> findByCategoryCategoryId(Long categoryId);

    Page<ProductMaster> findByCategoryCategoryId(Long categoryId, Pageable pageable);

    Optional<ProductMaster> findByProductName(String name);

    @Query("""
            SELECT COALESCE(MAX(p.sequenceId), 0)
            FROM ProductMaster p
           """)
    Long findMaxSequenceId();
}
