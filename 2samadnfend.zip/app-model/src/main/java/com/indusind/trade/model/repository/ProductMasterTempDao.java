package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.ProductMasterTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProductMasterTempDao extends JpaRepository<ProductMasterTemp, Long> {

    Optional<ProductMasterTemp> findByProductName(String name);

    @Query("""
            SELECT COALESCE(MAX(p.sequenceId), 0)
            FROM ProductMasterTemp p
           """)
    Long findMaxSequenceId();


}
