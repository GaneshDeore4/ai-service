package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.SubProductMasterTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SubProductMasterTempDao extends JpaRepository<SubProductMasterTemp, Long> {
    Optional<SubProductMasterTemp> findBySubProductNameAndProductMaster(String name, ProductMaster product);

    Long findAllByOrderBySubProductNameAsc();

    @Query("""
                SELECT COALESCE(MAX(sp.sequenceId), 0)
                FROM SubProductMaster sp where
                sp.productMaster.productId = :productId
           """)
    Long findMaxSequenceIdByProductId(Long productId);
}
