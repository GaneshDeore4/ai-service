package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.TabMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TabMasterDao extends JpaRepository<TabMaster, Long> {
    List<TabMaster> findByTabIdIn(List<Long> roleIds);

    Optional<TabMaster> findByTabName(String tab);

    List<TabMaster> findByProductProductIdAndSubProductSubProductId(Long productId, Long subProductId);
}
