package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.TabMasterTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TabMasterTempDao extends JpaRepository<TabMasterTemp, Long> {
}
