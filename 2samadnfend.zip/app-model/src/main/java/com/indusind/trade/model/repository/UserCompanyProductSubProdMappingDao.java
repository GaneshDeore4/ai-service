package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserCompanyProductSubProdMappingDao extends JpaRepository<UserCompanyProductSubProdMapping, Long> {

    List<UserCompanyProductSubProdMapping> findByUserUserId(Long userId);
}
