package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.UserTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserTempDao extends JpaRepository<UserTemp, Long> {
    Page<UserTemp> findByCompanyCompanyId(Long companyId, Pageable pageable);
}
