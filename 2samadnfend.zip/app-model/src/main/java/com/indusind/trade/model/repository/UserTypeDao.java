package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.UserType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserTypeDao extends JpaRepository<UserType, Long> {
    UserType findByUserTypeName(String userTypeName);

    List<UserType> findByCategoryCategoryId(Long categoryId);

    @Query("SELECT u FROM UserType u WHERE u.category.categoryId = :categoryId")
    Page<UserType> findUserTypeByCategory(Pageable pageable, Long categoryId);
}
