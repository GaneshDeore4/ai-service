package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.UserTypeTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserTypeTempDao extends JpaRepository<UserTypeTemp, Long> {
}
