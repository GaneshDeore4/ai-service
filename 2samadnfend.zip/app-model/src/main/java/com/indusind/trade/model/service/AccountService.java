package com.indusind.trade.model.service;

public interface AccountService {

//    AccountTemp saveGTPAccountTnx(AccountTemp gtpAccountTemp);
//
//    GTPAccountTnxDto getAccountTnx(Long accountId, String tnxId);
//
//    AccountDto getAccount(Long accountId);
}
