package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.Action;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ActionService {

    Action saveAction(Action action);

    Page<Action> getAllActions(Pageable pageable);

    List<Action> getAllActions();

    Action getActionById(Long actionId);

    Boolean existsById(Long id);

    List<Action> getByProductId(Long productId);

    List<Action> getByProductIdSubProductId(Long productId, Long subProductId);
}
