package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.ActionTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ActionServiceTemp {

    ActionTemp getActionById(Long id);

    ActionTemp saveActionTemp(ActionTemp action);

    Page<ActionTemp> getAllActions(Pageable pageable);

    List<ActionTemp> getAllActions();
}
