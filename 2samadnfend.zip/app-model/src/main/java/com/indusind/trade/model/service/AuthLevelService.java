package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.company.AuthLevel;

public interface AuthLevelService {

    AuthLevel saveAuthLevel(AuthLevel authLevel);

}
