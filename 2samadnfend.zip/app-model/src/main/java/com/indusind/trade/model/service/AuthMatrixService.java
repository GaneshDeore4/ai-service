package com.indusind.trade.model.service;

import com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupedDto;
import com.indusind.trade.model.entities.company.AuthMatrix;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface AuthMatrixService {

    AuthMatrix saveAuthMatrix(AuthMatrix authMatrix);

    AuthMatrix getAuthMatrixById(Long id, String category);

    AuthMatrix getAuthMatrixById(Long id);

    Page<AuthMatrix> getAllAuthMatrix(Pageable page, String category,Long companyId );

    void deleteAuthMatrixById(Long authMatId);

    void flush();

    Boolean existsAuthMatrix(Long id);

    Page<AuthMatrixGroupedDto> getAllAuthMatrixAllMapping(Pageable pageable, String category, Long companyId);
}
