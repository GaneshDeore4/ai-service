package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.entities.bank.BankUserTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public interface BankUserService {

    public BankUserTemp saveBankUserTemp(BankUserTemp bankUserTemp);
    public BankUser saveBankUser(BankUser bankUser);
    public BankUserTemp getBankUserTempById(Long bankUserId);
    public BankUser getBankUSerById(Long bankUserId);
    Page<BankUserTemp> getAllTempBankUsers(Pageable pageable);
    Page<BankUser> getAllBankUsers(Pageable pageable);
    public Boolean existsBankUser(Long bankUserId);
    public Boolean existsBankUserTemp(Long bankUserId);

    Page<BankUserTemp> getTempBankUsersByBankId(Long bankId, Pageable pageable);
    Page<BankUser> getBankUsersByBankId(Long bankId, Pageable pageable);

    public void flushBankUser();

    public void flushBankUserTemp();

    void lockUnlockUser(String userId, boolean lockFlag, String bankAbbvName);


    @Transactional(rollbackFor = Exception.class)
    void resetBankUserPasswordByUserId(Long userId, String password);

    @Transactional(rollbackFor = Exception.class)
    void resetBankUserPasswordByLoginIdAndBankAbbvName(String loginId, String password, String bankAbbvName);

    Optional<BankUser> getBankUserByLoginIdAndAbbvName(String loginId, String abbvName);

    void updatePrivacyPolicy(String loginId, boolean accepted, String bankAbbvName);
}

