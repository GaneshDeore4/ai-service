package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.UserType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface CategoryMasterService {

    CategoryMaster saveCategory(CategoryMaster categoryMaster);

    Page<CategoryMaster> getAllCategories(Pageable pageable);

    List<CategoryMaster> getAllCategories();

    CategoryMaster getCategoryById(Long categoryId);

    List<ProductMaster> getProductsByCategoryId(Long categoryId);

    List<UserType> getUserTypesByCategoryId(Long categoryId);

    List<UserType> getUserTypesByCategoryName(String category);

    CategoryMaster getCategoryByName(String categoryName);
}
