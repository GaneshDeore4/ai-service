package com.indusind.trade.model.service;

import com.indusind.trade.model.dtos.response.dtos.CompanyProfileResponseDto;
import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.entities.company.CompanyTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface CompanyService {
    CompanyTemp saveComapnyTemp(CompanyTemp companyTemp);

    void flushCompany();

    void flushCompanyTemp();

    Page<CompanyTemp> getAllTempCompanies(Pageable pageable);

    Page<Company> getAllCompanies(Pageable pageable);

    CompanyTemp getCompanyTempById(Long companyId);

    Company getCompanyById(Long companyId);

    Company saveCompany(Company company);

    Boolean existsCompany(Long companyId);

    Boolean existsCompanyTemp(Long companyId);


//    Page<CompanyTemp> getAllTempCompaniesByCategory(Pageable pageable, Long categoryId);
//
//    Page<Company> getAllCompaniesByCategory(Pageable pageable, Long categoryId);

//    CompanyTemp saveCompany(CompanyTemp gtpCompany);
//
//    CompanyTemp authoriseCompany(Long companyId, String tnxId, Long checkerId, String action);
//
//    Page<CompanyDtoTnx> getAllTnxCompanies(Pageable pageable);
//
//    Page<CompanyResponseDto> getAllCompanies(Pageable pageable);
//
//    CompanyResponseDto getCompanyById(Long companyId);
//
//    CompanyDtoTnx getCompanyTnxById(Long companyId, String tnxId);
}
