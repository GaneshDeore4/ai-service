package com.indusind.trade.model.service;

import com.indusind.trade.model.dtos.requestdtos.DepartmentRequestDto;
import com.indusind.trade.model.entities.master.Department;

import java.util.List;

public interface DepartmentService {

    Department getDepartmentById(Long deptId);

    List<Department> getAllDepartments();

    List<Department> saveAll(List<Department> departments);

    Boolean existsById(Long departmentId);

    Department addDepartment(Department department);

    List<Department> getDepartmentByCategory(Long departmentId);
}
