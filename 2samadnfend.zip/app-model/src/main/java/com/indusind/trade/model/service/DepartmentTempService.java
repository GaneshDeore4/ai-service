package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.DepartmentTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface DepartmentTempService {

    DepartmentTemp saveDepartmentTemp(DepartmentTemp departmentTemp);

    Page<DepartmentTemp> getAllDepartmentTemp(Pageable pageable);

    DepartmentTemp getDepartmentTempById(Long departmentId);

}
