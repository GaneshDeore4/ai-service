package com.indusind.trade.model.service;

import com.indusind.trade.model.dtos.response.dtos.MyAccessResponseDto;

public interface MyAccessService {

    MyAccessResponseDto getMyAccess(Long userId);

}

