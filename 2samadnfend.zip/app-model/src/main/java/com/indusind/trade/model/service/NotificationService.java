package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.company.Notification;
import com.indusind.trade.model.entities.company.NotificationTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface NotificationService {

    NotificationTemp saveNotificationTemp(NotificationTemp notificationTemp);

    Notification saveNotification(Notification notification);
    Page<NotificationTemp> getAllTempNotifications(Pageable pageable);

//    Page<Notification> getAllNotifications(Pageable pageable);
    NotificationTemp getNotificationTempById(Long notificationId);

    Notification getNotificationById(Long notificationId);

    List<Notification> getAllNotificationClients();

    public void flushNotification();

    public void flushNotificationTemp();

    public Boolean existsNotification(Long notificationId);
    public Boolean existsNotificationTemp(Long notificationId);

}
