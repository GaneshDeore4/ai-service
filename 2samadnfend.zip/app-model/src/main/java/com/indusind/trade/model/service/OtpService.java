package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.Otp;

import java.util.Optional;

public interface OtpService {


    Optional<Otp> findActiveBankOtpForUpdate(String loginId, String otpReference, String bankAbbvName , Boolean isVerified);

    Optional<Otp> findActiveClientOtpForUpdate(String loginId, String otpReference, String cifId, Boolean isVerified);

    Otp saveOtp(Otp otp);
}
