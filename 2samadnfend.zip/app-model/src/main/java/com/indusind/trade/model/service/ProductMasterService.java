package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ProductMasterService {
    
    ProductMaster saveProduct(ProductMaster productMaster);

    Page<ProductMaster> getAllProducts(Pageable pageable);

    Page<ProductMaster> getAllProductsByCategoryId(Pageable pageable, Long categoryId);

    List<ProductMaster> getAllProductsByCategoryId(Long categoryId);

    List<ProductMaster> getProductsByCategoryId(Long categoryId);

    ProductMaster getProductById(Long productId);

    List<SubProductMaster> getSubProductsByProductId(Long productId);

    List<ProductMaster> getProductsByIds(List<Long> productIds);

    List<ProductMaster> getAllProducts();

    Long findMaxSequenceId();

    Boolean existProductMaster(Long productId);

}
