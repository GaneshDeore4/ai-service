package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.ProductMasterTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ProductMasterTempService {

    ProductMasterTemp getProductMasterTempById(Long id);

    ProductMasterTemp saveProductMasterTemp(ProductMasterTemp productMasterTemp);

    Page<ProductMasterTemp> getAllProductsTemp(Pageable pageable);

    List<ProductMasterTemp> getAllProductsTemp();

    Long findMaxSequenceId();
}
