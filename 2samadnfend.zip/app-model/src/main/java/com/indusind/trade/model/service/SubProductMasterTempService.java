package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.SubProductMasterTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface SubProductMasterTempService {

    SubProductMasterTemp saveSubProductTemp(SubProductMasterTemp subProductMasterTemp);

    SubProductMasterTemp getSubProductMasterTempById(Long id);

    boolean existsById(Long id);

    Page<SubProductMasterTemp> getAllSubProducts(Pageable pageable);

    List<SubProductMasterTemp> getAllSubProducts();

    Long findMaxSequenceIdByProductId(Long productId);
}
