package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.TabMaster;
import com.indusind.trade.model.entities.master.TabMasterTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface TabMasterTempService {

    TabMasterTemp getTabById(Long tabId);

    TabMasterTemp saveTabMasterTemp(TabMasterTemp tabMasterTemp);

    boolean existById(Long tabId);

    Page<TabMasterTemp> getAllTabMasterTemp(Pageable pageable);

    List<TabMasterTemp> getAllTabMasterTemp();
}
