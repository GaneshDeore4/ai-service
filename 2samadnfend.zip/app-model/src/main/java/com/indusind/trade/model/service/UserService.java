package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMappingTemp;
import com.indusind.trade.model.entities.company.UserTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface UserService {
//    GTPCompanyUserTnx saveCompanyUser(GTPCompanyUserTnx gtpCompanyUserTnx);
//
//    GTPCompanyUserTnx authoriseCompanyUser(Long userId, String tnxId, Long checkerId, String action);

    UserTemp saveUserTemp(UserTemp userTemp);

    User saveUser(User user);

    UserTemp getTempUserById(Long userId);

    User getUserById(Long userId);

    List<UserCompanyProductSubProdMappingTemp> findByUserTempUserId(Long userId);

    Page<UserTemp> getTempUsersByCompanyId(Long companyId, Pageable pageable);

    Page<User> getUsersByCompanyId(Long companyId, Pageable pageable);

    Page<User> getAllUsers(Pageable pageable);

    Page<UserTemp> getAllTempUsers(Pageable pageable);

    void flushUser();
    void flushUserTemp();

    Boolean existsUser(Long userId);

    Boolean existsUserTemp(Long userId);

    void lockUnlockUser(String loginId, boolean lockFlag, String cifId);

    void resetUserPasswordByUserId(Long userId, String password);

    void resetUserPasswordByLoginIdAndCifId(String loginId, String password, String cifId);

    Optional<User> getUserByLoginIdAndCifId(String loginId, String cifId);

    void updatePrivacyPolicy(String loginId, boolean accepted, String cifId);

    boolean existsUserByCifId(String cifId);

    boolean existsUserByLoginId(String loginId);
}
