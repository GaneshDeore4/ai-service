package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.UserTypeTabActionMapping;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UserTypeTabActionMappingService {

    List<UserTypeTabActionMapping> saveMappingList(List<UserTypeTabActionMapping> userTypeTabActionMappingList);

    List<UserTypeTabActionMapping> findByUserTypeId(Long userTypeId);

    Long deleteUserTabActionMappingByUserTypeProdSubProd(Long userTypeId, Long productId, Long subProductId);

    @Transactional(rollbackFor = Exception.class)
    void flush();

    List<UserTypeTabActionMapping> findByUserTypeProductSubProductTabIds(Long aLong, Long aLong1, Long aLong2, List<Long> longs);
}
