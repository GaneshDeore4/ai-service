package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.UserTypeTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserTypeTempService {

    UserTypeTemp saveUserTypeTemp(UserTypeTemp userTypeTemp);

    Page<UserTypeTemp> getAllTempUserType(Pageable pageable);

    UserTypeTemp getUserTypeTempById(Long userTypeId);

    Boolean existsById(Long userTypeId);


}
