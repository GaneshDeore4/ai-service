package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.repository.AccountDao;
import com.indusind.trade.model.repository.AccountTempDao;
import com.indusind.trade.model.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

//    private final AccountTempDao accountTempDao;
//    private final AccountDao accountDao;

//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public AccountTemp saveGTPAccountTnx(AccountTemp gtpAccountTemp) {
//        return accountTempDao.save(gtpAccountTemp);
//    }
//
//    @Override
//    public GTPAccountTnxDto getAccountTnx(Long accountId, String tnxId) {
//        GTPAccountTnxId accountTnxId = new GTPAccountTnxId(accountId, tnxId);
//        AccountTemp account = accountTempDao.findById(accountTnxId).orElseThrow();
//        return GTPAccountTnxDto.convertToDto(account);
//    }
//
//    @Override
//    public AccountDto getAccount(Long accountId) {
//        Account account = accountDao.findById(accountId).orElseThrow();
//        return AccountDto.convertToDto(account);
//    }
}
