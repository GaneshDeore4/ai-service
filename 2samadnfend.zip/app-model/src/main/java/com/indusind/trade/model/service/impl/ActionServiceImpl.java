package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.master.Action;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.ActionDao;
import com.indusind.trade.model.service.ActionService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ActionServiceImpl implements ActionService {

    private final ActionDao actionDao;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public Action saveAction(Action action) {
        return actionDao.save(action);
    }

    @Override
    public Page<Action> getAllActions(Pageable pageable) {
        Page<Action> page = actionDao.findAll(pageable);
        return page;
    }

    @Override
    public List<Action> getAllActions() {
        return actionDao.findAllByOrderByActionCodeAsc();
    }

    @Override
    public Action getActionById(Long actionId) {
        return actionDao.findById(actionId).orElseThrow(() -> new GTPAppException("Action with id: " + actionId + " not found", null));
    }

    @Override
    public Boolean existsById(Long id) {
        return actionDao.existsById(id);
    }

    @Override
    public List<Action> getByProductId(Long productId) {
        return actionDao.findByProductProductId(productId);
    }

    @Override
    public List<Action> getByProductIdSubProductId(Long productId, Long subProductId) {
        return actionDao.findByProductProductIdAndSubProductSubProductId(productId, subProductId);
    }
}
