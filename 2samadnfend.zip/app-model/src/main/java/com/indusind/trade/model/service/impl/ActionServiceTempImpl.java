package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.master.ActionTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.ActionTempDao;
import com.indusind.trade.model.service.ActionServiceTemp;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ActionServiceTempImpl implements ActionServiceTemp {

    private final ActionTempDao actionTempDao;

    @Override
    public ActionTemp getActionById(Long id) {
        return actionTempDao.findById(id).orElseThrow(() -> new GTPAppException("Action with id: " + id + " does not exists", null));
    }

    @Override
    public ActionTemp saveActionTemp(ActionTemp action) {
        return actionTempDao.save(action);
    }

    @Override
    public Page<ActionTemp> getAllActions(Pageable pageable) {
        return actionTempDao.findAll(pageable);
    }

    @Override
    public List<ActionTemp> getAllActions() {
        return actionTempDao.findAllByOrderByActionCodeAsc();
    }
}
