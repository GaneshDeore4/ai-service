package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.company.AuthGroup;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.AuthGroupDao;
import com.indusind.trade.model.service.AuthGroupService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthGroupServiceImpl implements AuthGroupService {

    private final AuthGroupDao authGroupDao;

    @Override
    public AuthGroup getAuthGroupById(Long id) {
        return authGroupDao.findById(id).orElseThrow(()-> new GTPAppException("AuthGroup with id: " + id + " does not exists", null));
    }

    @Override
    public AuthGroup getAuthGroup(Long id) {
        return authGroupDao.findById(id).orElse(null);
    }

    @Override
    public List<AuthGroup> getAllAuthGroups() {
        return authGroupDao.findAll();
    }
}
