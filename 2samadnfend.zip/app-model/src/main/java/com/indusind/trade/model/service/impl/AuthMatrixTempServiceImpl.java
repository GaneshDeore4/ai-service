package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.dtos.response.dtos.AccountDetailsDto;
import com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupedDto;
import com.indusind.trade.model.entities.company.AuthMatrixTemp;
import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.entities.master.EventTypeTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.AuthMatrixTempDao;
import com.indusind.trade.model.service.AuthMatrixTempService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AuthMatrixTempServiceImpl implements AuthMatrixTempService {

    private final AuthMatrixTempDao authMatrixTempDao;

    @Override
    public AuthMatrixTemp saveAuthMatrix(AuthMatrixTemp authMatrixTemp) {
        return authMatrixTempDao.save(authMatrixTemp);
    }

    @Override
    public List<AuthMatrixTemp> saveAllAuthMatrix(List<AuthMatrixTemp> authMatrixTemp) {
        return authMatrixTempDao.saveAll(authMatrixTemp);
    }

    @Override
    public AuthMatrixTemp getAuthMatrixTempById(Long id, String category) {
        return authMatrixTempDao.findByIdAndCategory(id, category).orElseThrow(()-> new GTPAppException("Auth Matrix with id: " + id + " does not exists.", null));
    }

    @Override
    public AuthMatrixTemp getAuthMatrixTempById(Long id) {
        return authMatrixTempDao.findById(id).orElseThrow(()-> new GTPAppException("Auth Matrix with id: " + id + " does not exists.", null));
    }

    @Override
    public Page<AuthMatrixTemp> getAllAuthMatrix(Pageable page) {
        return authMatrixTempDao.findByIsAllProductFlag(false, page);
    }

    @Override
    public Page<AuthMatrixTemp> getAllAuthMatrix(Pageable page, String category, Long companyId) {
        if(companyId != null) {
            return authMatrixTempDao.findByIsAllProductFlagAndCategoryAndCompanyCompanyId(
                    false, category, companyId, page);
        }
        return authMatrixTempDao.findByIsAllProductFlagAndCategory(false, category, page);

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteAuthMatrixById(Long authMatId) {
        authMatrixTempDao.deleteById(authMatId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void flush() {
        authMatrixTempDao.flush();
    }

    @Override
    public boolean existsAuthMatrixTemp(Long id) {
        return authMatrixTempDao.existsById(id);
    }

    @Override
    public boolean existsByCompanyProductSubProductAmt(Company company, ProductMaster product, SubProductMaster subProduct, Long amount, String currencyType) {
        return authMatrixTempDao.existsByCompanyCompanyIdAndProductProductIdAndSubProductSubProductIdAndAmountAndCurrencyType(company.getCompanyId(), product.getProductId(), subProduct.getSubProductId(), amount, currencyType);
    }

    @Override
    public boolean existsByCompanyProductSubProductAmtIsAllProductFlag(Company company, ProductMaster product, SubProductMaster subProduct, Long amount, boolean isAllProductFlag, String currencyType) {
        return authMatrixTempDao.existsByCompanyCompanyIdAndProductProductIdAndSubProductSubProductIdAndAmountAndIsAllProductFlagAndCurrencyType(company.getCompanyId(), product.getProductId(), subProduct.getSubProductId(), amount, isAllProductFlag, currencyType);
    }

    @Override
    public AuthMatrixTemp findByCompanyProductSubProductAmtIsAllProductFlag(Long companyId, Long productId, Long subProductId, Long amount, boolean isAllProductFlag, String currencyType) {
        return authMatrixTempDao.findByCompanyCompanyIdAndProductProductIdAndSubProductSubProductIdAndAmountAndIsAllProductFlagAndCurrencyType(companyId, productId, subProductId, amount, isAllProductFlag, currencyType);
    }

    @Override
    public List<AuthMatrixTemp> getByCompanyAmountIsAllProductFlag(Long companyId, Long amount, boolean isAllProductFlag, String currencyType) {
        return authMatrixTempDao.findByCompanyCompanyIdAndAmountAndIsAllProductFlagAndCurrencyType(companyId, amount, isAllProductFlag, currencyType);
    }

    @Override
    public boolean existsByCompanyIdAmountIsAllFlag(Long companyId, Long amount, boolean isAllProdFlag, String currencyType) {
        return authMatrixTempDao.existsByCompanyCompanyIdAndAmountAndIsAllProductFlagAndCurrencyType(companyId, amount, isAllProdFlag, currencyType);
    }

//    @Override
//    public Page<AuthMatrixGroupedProjection> getAllAuthMatrixAllMapping(Pageable pageable) {
//
//    }

    @Override
    public Page<AuthMatrixGroupedDto> getAllAuthMatrixAllMapping(Pageable pageable, String category, Long companyId ) {

//        Page<AuthMatrixGroupKeyDto> keyPage = authMatrixTempDao.findGroupedKeys(pageable);

        Page<AuthMatrixTemp> page = authMatrixTempDao.findPagedAuthMatrix(category,companyId, pageable);

        Map<String, List<AuthMatrixTemp>> grouped =
                page.getContent().stream()
                        .collect(Collectors.groupingBy(
                                a -> a.getCompany().getCompanyId() + "_" + a.getAmount()
                        ));

        List<AuthMatrixGroupedDto> result =
                grouped.values().stream()
                        .map(this::convertToGroupedDto)
                        .toList();

        return new PageImpl<>(result, pageable, page.getTotalElements());
    }

    private AuthMatrixGroupedDto convertToGroupedDto(List<AuthMatrixTemp> records) {

        AuthMatrixTemp first = records.get(0);

        AuthMatrixGroupedDto dto = new AuthMatrixGroupedDto();

        dto.setCompanyId(first.getCompany().getCompanyId());
        dto.setAmount(first.getAmount());
        dto.setCurrencyType(first.getCurrencyType());
        dto.setIsSequential(first.getIsSequential());
        dto.setIsVerifier(first.getIsVerifier());
        dto.setIsReleaser(first.getIsReleaser());
        dto.setIsAllProductFlag(first.getIsAllProductFlag());
        dto.setStatus(first.getStatus());

        dto.setIds(records.stream()
                .map(r -> r.getId().toString())
                .collect(Collectors.joining(",")));

//        dto.setEventType(records.stream()
//                .flatMap(r -> r.getEventTypes().stream())
//                .map(EventTypeTemp::getEventType)
//                .distinct()
//                .toList());

        dto.setAuthGroup(records.stream()
                .flatMap(r -> r.getAuthLevels().stream())
                .map(level -> Map.of(
                        level.getAuthGroup().getId() + "-" +level.getAuthGroup().getAuthGroup(),
                        level.getSeqNo()))
                .collect(Collectors.toSet()));

        dto.setAccounts(first.getAccounts().stream().map(
                AccountDetailsDto:: convertToDto
        ).toList());

        dto.setMakerName(first.getMakerName());
        dto.setCreatedAt(first.getCreatedAt());
        dto.setCheckerName(first.getCheckerName());
        dto.setApprovedAt(first.getApprovedAt());
        dto.setLastModifiedAt(first.getLastModifiedAt());
        dto.setLastModifiedBy(first.getLastModifiedBy());
        dto.setRejectedAt(first.getRejectedAt());
        dto.setRejectedBy(first.getRejectedBy());

        return dto;
    }

//    private AuthMatrixGroupedDto buildGroupedDto(AuthMatrixGroupKeyDto key) {
//
//        List<AuthMatrixTemp> records =
//                authMatrixTempDao.findGroupedRecords(key.getCompanyId(), key.getAmount());
//
//        AuthMatrixTemp first = records.get(0);
//
//        AuthMatrixGroupedDto dto = new AuthMatrixGroupedDto();
//
//        dto.setCompanyId(key.getCompanyId());
//        dto.setAmount(key.getAmount());
//        dto.setCurrencyType(first.getCurrencyType());
//        dto.setIsVerifier(first.getIsVerifier());
//        dto.setIsReleaser(first.getIsReleaser());
//        dto.setIsSequential(first.getIsSequential());
//        dto.setIsAllProductFlag(first.getIsAllProductFlag());
//        dto.setStatus(first.getStatus());
//
//        dto.setIds(
//                records.stream()
//                        .map(r -> r.getId().toString())
//                        .collect(Collectors.joining(","))
//        );
//
//        dto.setEventType(
//                records.stream()
//                        .flatMap(r -> r.getEventTypes().stream())
//                        .map(EventTypeTemp::getEventType)
//                        .distinct()
//                        .toList()
//        );
//
//        dto.setAuthGroup(
//                records.stream()
//                        .flatMap(r -> r.getAuthLevels().stream())
//                        .map(level -> Map.of(
//                                level.getAuthGroup().getId() + "_" + level.getAuthGroup().getAuthGroup(),
//                                level.getSeqNo()
//                        ))
//                        .toList()
//        );
//
//        return dto;
//    }
}
