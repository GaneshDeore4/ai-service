package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.bank.BankProfile;
import com.indusind.trade.model.entities.bank.BankProfileTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.BankProfileDao;
import com.indusind.trade.model.repository.BankProfileTempDao;
import com.indusind.trade.model.service.BankProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BankProfileServiceImpl implements BankProfileService {

    private final BankProfileDao bankProfileDao;
    private final BankProfileTempDao bankProfileTempDao;

    @Override
    public BankProfileTemp saveBankProfileTemp(BankProfileTemp bankProfileTemp) {
        return bankProfileTempDao.save(bankProfileTemp);
    }

    @Override
    public BankProfile saveBankProfile(BankProfile bankProfile) {
        return bankProfileDao.save(bankProfile);
    }

    @Override
    public BankProfileTemp getBankProfileTempById(Long bankProfileId) {
        return bankProfileTempDao.findById(bankProfileId).orElseThrow(() -> new GTPAppException("BankProfileTemp with id "+bankProfileId+ " does not exists.", null));
    }

    @Override
    public BankProfile getBankProfileById(Long bankProfileId) {
        return bankProfileDao.findById(bankProfileId).orElseThrow(() -> new GTPAppException("BankProfile with id "+bankProfileId+ " does not exists.", null));
    }

    @Override
    public Page<BankProfileTemp> getAllTempBanks(Pageable pageable) {
        return bankProfileTempDao.findAll(pageable);
    }

    @Override
    public Page<BankProfile> getAllBanks(Pageable pageable) {
        return bankProfileDao.findAll(pageable);
    }

    @Override
    public Boolean existsBank(Long bankProfileId) {
        return bankProfileDao.existsById(bankProfileId);
    }

    @Override
    public Boolean existsBankTemp(Long bankProfileId) {
        return bankProfileTempDao.existsById(bankProfileId);
    }

    @Override
    public void flushBankProfile() {
        bankProfileDao.flush();
    }

    @Override
    public void flushBankProfileTemp() {
        bankProfileTempDao.flush();
    }


}
