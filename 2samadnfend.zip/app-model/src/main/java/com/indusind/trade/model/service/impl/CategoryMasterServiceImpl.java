package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.CategoryMasterDao;
import com.indusind.trade.model.service.CategoryMasterService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class CategoryMasterServiceImpl implements CategoryMasterService {

    private final CategoryMasterDao categoryMasterDao;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public CategoryMaster saveCategory(CategoryMaster categoryMaster) {
        return categoryMasterDao.save(categoryMaster);
    }

    @Override
    public Page<CategoryMaster> getAllCategories(Pageable pageable) {
        return categoryMasterDao.findAll(pageable);
    }

    @Override
    public List<CategoryMaster> getAllCategories() {
        return categoryMasterDao.findAllByOrderByCategoryNameAsc();
    }

    @Override
    public CategoryMaster getCategoryById(Long categoryId) {
        return categoryMasterDao.findById(categoryId).orElseThrow(() -> new GTPAppException("Category with id " + categoryId + " does not exists.", null));
    }

    @Override
    public List<ProductMaster> getProductsByCategoryId(Long categoryId) {
        CategoryMaster category = categoryMasterDao.findById(categoryId).orElseThrow();
        return category.getProductMasterList();
    }

    @Override
    public List<UserType> getUserTypesByCategoryId(Long categoryId) {
        CategoryMaster category = categoryMasterDao.findById(categoryId).orElseThrow(() -> new GTPAppException("Not found", null));
        return  category.getUserTypeList();
    }

    @Override
    public List<UserType> getUserTypesByCategoryName(String category) {
        CategoryMaster categoryMaster = categoryMasterDao.findByCategoryNameIgnoreCase(category);
        return Objects.isNull(categoryMaster) ? new ArrayList<>() : categoryMaster.getUserTypeList();
    }

    @Override
    public CategoryMaster getCategoryByName(String categoryName) {
        CategoryMaster categoryMaster = categoryMasterDao.findByCategoryNameIgnoreCase(categoryName);
        if (Objects.isNull(categoryMaster)) {
            throw new GTPAppException("Not found", null);
        }
        return categoryMasterDao.findByCategoryNameIgnoreCase(categoryName);
    }
}
