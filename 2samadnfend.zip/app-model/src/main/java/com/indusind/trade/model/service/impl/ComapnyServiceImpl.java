package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.dtos.response.dtos.CompanyProfileResponseDto;
import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.entities.company.CompanyTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.CompanyDao;
import com.indusind.trade.model.repository.CompanyTempDao;
import com.indusind.trade.model.service.CompanyService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ComapnyServiceImpl implements CompanyService {

    private final CompanyTempDao companyTempDao;

    private final CompanyDao companyDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CompanyTemp saveComapnyTemp(CompanyTemp companyTemp) {
        return companyTempDao.save(companyTemp);
    }

    @Override
    public Company saveCompany(Company company) {
        return companyDao.save(company);
    }

    @Override
    public void flushCompany() {
        companyDao.flush();
    }

    @Override
    public void flushCompanyTemp() {
        companyTempDao.flush();
    }

    @Override
    public Page<CompanyTemp> getAllTempCompanies(Pageable pageable) {
        return companyTempDao.findAll(pageable);
    }

    @Override
    public Page<Company> getAllCompanies(Pageable pageable) {
        return companyDao.findAll(pageable);
    }

    @Override
    public CompanyTemp getCompanyTempById(Long companyId) {
        return companyTempDao.findById(companyId).orElseThrow(()-> new GTPAppException("CompanyTemp with id: " + companyId + " does not exists.", null));
    }

    @Override
    public Company getCompanyById(Long companyId) {
        return companyDao.findById(companyId).orElseThrow(()-> new GTPAppException("Company with id: " + companyId + " does not exists.", null));
    }

    @Override
    public Boolean existsCompany(Long companyId) {
        return companyDao.existsById(companyId);
    }

    @Override
    public Boolean existsCompanyTemp(Long companyId) {
        return companyTempDao.existsById(companyId);
    }

//    @Override
//    public Page<CompanyTemp> getAllTempCompaniesByCategory(Pageable pageable, Long categoryId) {
//        return companyTempDao.findByCategoryMasterCategoryId(pageable, categoryId);
//    }
//
//    @Override
//    public Page<Company> getAllCompaniesByCategory(Pageable pageable, Long categoryId) {
//        return companyDao.findByCategoryMasterCategoryId(pageable, categoryId);
//    }
}
