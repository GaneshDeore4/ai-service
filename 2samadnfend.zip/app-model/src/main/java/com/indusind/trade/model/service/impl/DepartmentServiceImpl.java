package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.dtos.requestdtos.DepartmentRequestDto;
import com.indusind.trade.model.entities.master.Department;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.DepartmentDao;
import com.indusind.trade.model.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentDao deptRepo;

    @Override
    public Department getDepartmentById(Long deptId) {
        return deptRepo.findById(deptId).orElseThrow(() -> new GTPAppException("Department with id: " + deptId + " does not exist.", null));
    }

    @Override
    public List<Department> getAllDepartments() {
        return deptRepo.findAll();
    }

    @Override
    @Transactional
    public List<Department> saveAll(List<Department> departments) {
        return deptRepo.saveAll(departments);
    }

    @Override
    public Boolean existsById(Long departmentId) {
        return deptRepo.existsById(departmentId);
    }

    @Override
    @Transactional
    public Department addDepartment(Department department) {
//        Department department = new Department();
//        if(Objects.nonNull(request.getId())) {
//            department.setId(department.getId());
//        }
//        department.setDepartmentName(request.getDepartmentName());

        return deptRepo.save(department);

    }

    @Override
    public List<Department> getDepartmentByCategory(Long departmentId) {
        return deptRepo.findByCategoryId(departmentId);
    }


}
