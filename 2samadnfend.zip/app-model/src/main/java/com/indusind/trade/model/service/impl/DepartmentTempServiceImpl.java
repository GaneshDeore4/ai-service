package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.master.DepartmentTemp;
import com.indusind.trade.model.repository.DepartmentTempDao;
import com.indusind.trade.model.service.DepartmentTempService;
import com.indusind.trade.model.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DepartmentTempServiceImpl implements DepartmentTempService {

    private final DepartmentTempDao departmentTempDao;

    @Override
    public DepartmentTemp saveDepartmentTemp(DepartmentTemp departmentTemp) {
        return departmentTempDao.save(departmentTemp);
    }

    @Override
    public Page<DepartmentTemp> getAllDepartmentTemp(Pageable pageable) {
        return departmentTempDao.findAll(pageable);
    }

    @Override
    public DepartmentTemp getDepartmentTempById(Long departmentId) {
        return departmentTempDao.findById(departmentId).orElseThrow(() -> new GTPAppException("dept with id "+departmentId+" does not exist", null));
    }
}
