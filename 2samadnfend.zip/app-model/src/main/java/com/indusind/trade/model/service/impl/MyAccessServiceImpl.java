package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.dtos.response.dtos.*;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMapping;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.entities.master.UserTypeTabActionMapping;
import com.indusind.trade.model.repository.UserDao;
import com.indusind.trade.model.repository.UserTypeTabActionMappingDao;
import com.indusind.trade.model.service.MyAccessService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class MyAccessServiceImpl implements MyAccessService {

    private final UserDao userRepository;
    private final UserTypeTabActionMappingDao tabActionRepo;

    @Override
    public MyAccessResponseDto getMyAccess(Long userId) {

        User user = userRepository.findWithMappingsByUserId(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        MyAccessResponseDto response = new MyAccessResponseDto();
        response.setUserId(user.getUserId());
        response.setUsername(user.getLoginId());
        response.setUserType(user.getUserType().getUserTypeName());

        List<UserCompanyProductSubProdMapping> mappings =
                user.getMappingUser();

        if (mappings == null || mappings.isEmpty()) {
            return response;
        }

        Map<ProductSubProductKey, List<TabActionMappingAccessDto>> tabActionMap =
                preloadTabActions(user.getUserType().getUserTypeId());

        Map<Long, ProductAccessDto> productMap = new LinkedHashMap<>();

        for (UserCompanyProductSubProdMapping mapping : mappings) {

            ProductMaster product = mapping.getProductMaster();
            SubProductMaster subProduct = mapping.getSubProductMaster();

            if (product == null)
                continue;

            ProductAccessDto productDto =
                    productMap.computeIfAbsent(
                            product.getProductId(),
                            id -> {

                                ProductAccessDto dto =
                                        new ProductAccessDto();
                                dto.setSequenceId(product.getSequenceId());
                                dto.setProductId(product.getProductId());
                                dto.setProductName(product.getProductName());
                                dto.setIsMidOffice(product.getMidOfficeFlag());

                                return dto;
                            });

            if (subProduct != null) {
                System.out.println("subprod:"+subProduct.getSequenceId());
                SubProductAccessDto subDto =
                        productDto.getSubProducts()
                                .stream()
                                .filter(s -> s.getSubProductId()
                                        .equals(subProduct.getSubProductId()))
                                .findFirst()
                                .orElseGet(() -> {

                                    SubProductAccessDto newSub =
                                            new SubProductAccessDto();

                                    newSub.setSubProductId(
                                            subProduct.getSubProductId());

                                    newSub.setSubProductName(
                                            subProduct.getSubProductName());
                                    newSub.setSequenceId(
                                            subProduct.getSequenceId()
                                    );

                                    productDto.getSubProducts().add(newSub);

                                    return newSub;
                                });

                ProductSubProductKey key =
                        new ProductSubProductKey(
                                product.getProductId(),
                                subProduct.getSubProductId());

                subDto.setTabActionMapping(
                        tabActionMap.getOrDefault(
                                key,
                                Collections.emptyList()));

            } else {

                ProductSubProductKey key =
                        new ProductSubProductKey(
                                product.getProductId(),
                                null);

                productDto.setTabActionMapping(
                        tabActionMap.getOrDefault(
                                key,
                                Collections.emptyList()));
            }
        }
        List<ProductAccessDto> productAccessDtos = new ArrayList<>(productMap.values());

        productAccessDtos.sort(Comparator.comparing(
                ProductAccessDto::getSequenceId,
                Comparator.nullsLast(Long::compareTo)
        ));

        for (ProductAccessDto productDto : productAccessDtos) {
            if (productDto.getSubProducts() != null) {
                productDto.getSubProducts().sort(
                        Comparator.comparing(
                                SubProductAccessDto::getSequenceId,
                                Comparator.nullsLast(Long::compareTo)
                        )
                );
            }
        }

        response.setProducts(productAccessDtos);

        return response;
    }

    private Map<ProductSubProductKey, List<TabActionMappingAccessDto>>
    preloadTabActions(Long userTypeId) {

        List<UserTypeTabActionMapping> mappings =
                tabActionRepo.findAllByUserType(userTypeId);

        Map<ProductSubProductKey, Map<Long, TabActionMappingAccessDto>> temp =
                new HashMap<>();

        for (UserTypeTabActionMapping m : mappings) {

            Long productId = m.getProduct().getProductId();

            Long subProductId =
                    m.getSubProduct() != null
                            ? m.getSubProduct().getSubProductId()
                            : null;

            ProductSubProductKey key =
                    new ProductSubProductKey(productId, subProductId);

            temp.putIfAbsent(key, new LinkedHashMap<>());

            Map<Long, TabActionMappingAccessDto> tabMap = temp.get(key);

            Long tabId = m.getTab().getTabId();

            TabActionMappingAccessDto tabDto =
                    tabMap.computeIfAbsent(tabId, id -> {

                        TabActionMappingAccessDto dto =
                                new TabActionMappingAccessDto();

                        dto.setTabId(tabId);
                        dto.setTabName(m.getTab().getTabLabel());

                        return dto;
                    });

            tabDto.getActions().add(
                    new ActionAccessDto(
                            m.getAction().getActionId(),
                            m.getAction().getActionCode(),
                            m.getAction().getActionNameLabel()));
        }

        Map<ProductSubProductKey, List<TabActionMappingAccessDto>> result =
                new HashMap<>();

        temp.forEach((k, v) ->
                result.put(k, new ArrayList<>(v.values()))
        );

        return result;
    }
}
