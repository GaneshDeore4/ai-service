package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.master.ProductMasterTemp;
import com.indusind.trade.model.repository.ProductMasterTempDao;
import com.indusind.trade.model.service.ProductMasterTempService;
import com.indusind.trade.model.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductMasterTempServiceImpl implements ProductMasterTempService {

    private final ProductMasterTempDao productMasterTempDao;

    @Override
    public ProductMasterTemp getProductMasterTempById(Long id) {
        return productMasterTempDao.findById(id).orElseThrow(() -> new GTPAppException("Product with id: " + id + " does not exists", null));
    }

    @Override
    public ProductMasterTemp saveProductMasterTemp(ProductMasterTemp productMasterTemp) {
        return productMasterTempDao.save(productMasterTemp);
    }

    @Override
    public Page<ProductMasterTemp> getAllProductsTemp(Pageable pageable) {
        return productMasterTempDao.findAll(pageable);
    }

    @Override
    public List<ProductMasterTemp> getAllProductsTemp() {
        return productMasterTempDao.findAll();
    }

    @Override
    public Long findMaxSequenceId() {
        return productMasterTempDao.findMaxSequenceId();
    }
}
