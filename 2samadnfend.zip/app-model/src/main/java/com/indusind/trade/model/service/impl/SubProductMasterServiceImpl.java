package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.SubProductMasterDao;
import com.indusind.trade.model.service.SubProductMasterService;
import jakarta.transaction.Transactional;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class SubProductMasterServiceImpl implements SubProductMasterService {

    SubProductMasterDao subProductMasterDao;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public SubProductMaster saveSubProduct(SubProductMaster subProductMaster) {
        return subProductMasterDao.save(subProductMaster);
    }

    @Override
    public Page<SubProductMaster> getAllSubProducts(Pageable pageable) {
        Page<SubProductMaster> page = subProductMasterDao.findAll(pageable);
        return page;
    }

    @Override
    public SubProductMaster getSubProductById(Long subProductId) {
        return subProductMasterDao.findById(subProductId).orElseThrow(() -> new GTPAppException("SubProduct with id: " + subProductId + " not found", null));
    }

    @Override
    public List<SubProductMaster> getSubProductMasterList(List<Long> subProductIds) {
        return subProductMasterDao.findBySubProductIdIn(subProductIds);
    }

    @Override
    public Long findMaxSequenceIdByProductId(Long productId) {
        return subProductMasterDao.findMaxSequenceIdByProductId(productId);
    }

    @Override
    public boolean existsById(Long id) {
        return subProductMasterDao.existsById(id);
    }


    @Override
    public List<SubProductMaster> getAllSubProducts() {
        return subProductMasterDao.findAllByOrderBySubProductNameAsc();
    }


}
