package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.master.SubProductMasterTemp;
import com.indusind.trade.model.repository.SubProductMasterTempDao;
import com.indusind.trade.model.service.SubProductMasterTempService;
import com.indusind.trade.model.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SubProductMasterTempServiceImpl implements SubProductMasterTempService {

    private final SubProductMasterTempDao subProductMasterTempDao;

    @Override
    public SubProductMasterTemp saveSubProductTemp(SubProductMasterTemp subProductMasterTemp) {
        return subProductMasterTempDao.save(subProductMasterTemp);
    }

    @Override
    public SubProductMasterTemp getSubProductMasterTempById(Long id) {
        return subProductMasterTempDao.findById(id).orElseThrow(() -> new GTPAppException("Sub Product with id: " + id + " does not exists", null));
    }

    @Override
    public boolean existsById(Long id) {
        return subProductMasterTempDao.existsById(id);
    }

    @Override
    public Page<SubProductMasterTemp> getAllSubProducts(Pageable pageable) {
        Page<SubProductMasterTemp> page = subProductMasterTempDao.findAll(pageable);
        return page;
    }

    @Override
    public List<SubProductMasterTemp> getAllSubProducts() {
        return subProductMasterTempDao.findAll();
    }

    @Override
    public Long findMaxSequenceIdByProductId(Long productId) {
        return subProductMasterTempDao.findMaxSequenceIdByProductId(productId);
    }
}
