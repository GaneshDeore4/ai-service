package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.master.TabMasterTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.TabMasterTempDao;
import com.indusind.trade.model.service.TabMasterTempService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TabMasterTempServiceImpl implements TabMasterTempService {

    private final TabMasterTempDao tabMasterTempDao;

    @Override
    public TabMasterTemp getTabById(Long tabId) {
        return tabMasterTempDao.findById(tabId).orElseThrow(() -> new GTPAppException("No Tab found for tab id", null));
    }

    @Override
    @Transactional
    public TabMasterTemp saveTabMasterTemp(TabMasterTemp tabMasterTemp) {
        return tabMasterTempDao.save(tabMasterTemp);
    }

    @Override
    public boolean existById(Long tabId) {
        return tabMasterTempDao.existsById(tabId);
    }

    @Override
    public Page<TabMasterTemp> getAllTabMasterTemp(Pageable pageable) {
        return tabMasterTempDao.findAll(pageable);
    }

    @Override
    public List<TabMasterTemp> getAllTabMasterTemp() {
        return tabMasterTempDao.findAll();
    }

}
