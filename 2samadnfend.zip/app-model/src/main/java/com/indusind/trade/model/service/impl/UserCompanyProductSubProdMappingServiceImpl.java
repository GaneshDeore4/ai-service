package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMapping;
import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMappingTemp;
import com.indusind.trade.model.entities.company.UserTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.repository.*;
import com.indusind.trade.model.service.UserCompanyProductSubProdMappingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class UserCompanyProductSubProdMappingServiceImpl implements UserCompanyProductSubProdMappingService {

    UserTempDao userTempDao;
    ProductMasterDao productMasterDao;
    SubProductMasterDao subProductMasterDao;
    CompanyDao companyDao;
    UserCompanyProductSubProdMappingTempDao userMappingTempDao;
    UserCompanyProductSubProdMappingDao userMappingDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addMappingTemp(Long userId, Map<Long, List<Long>> prodSubProdMap) {
        UserTemp userTemp = userTempDao.findById(userId).orElseThrow();

        //need to delete all users from mappingTemp
        userMappingTempDao.deleteByUserTempUserId(userId);

        userMappingTempDao.flush();

        //need to optimize db call here

        //Company company = companyDao.getReferenceById(companyId);
        //List<ProductMaster> selectProducts = company.getProducts().stream().filter(p -> prodSubProdMap.containsKey(p.getProductId())).collect(Collectors.toList());

        for(Map.Entry<Long, List<Long>> entry: prodSubProdMap.entrySet()){
            //entry-fetch product by productId first, then subprod for every subprod id
            Long productId = entry.getKey();
            List<Long> subProductsIdList = entry.getValue();

            ProductMaster productMaster = productMasterDao.getReferenceById(productId);

            if(subProductsIdList == null || subProductsIdList.isEmpty()){
                UserCompanyProductSubProdMappingTemp tempMapping = new UserCompanyProductSubProdMappingTemp();
//                tempMapping.setCompany(company);
                tempMapping.setUserTemp(userTemp);
                tempMapping.setProductMaster(productMaster);
                tempMapping.setSubProductMaster(null);
                userMappingTempDao.save(tempMapping);
            }
            else{
                for(Long subProdId : subProductsIdList){
                    SubProductMaster subProductMaster = subProductMasterDao.getReferenceById(subProdId);
                    UserCompanyProductSubProdMappingTemp tempMapping = new UserCompanyProductSubProdMappingTemp();
//                    tempMapping.setCompany(company);
                    tempMapping.setUserTemp(userTemp);
                    tempMapping.setProductMaster(productMaster);
                    tempMapping.setSubProductMaster(subProductMaster);
                    userMappingTempDao.save(tempMapping);
                }
            }
        }
    }


    @Override
    public List<UserCompanyProductSubProdMappingTemp> getMappingTempById(Long userId) {
        return userMappingTempDao.findByUserTempUserId(userId);
    }

    @Override
    public List<UserCompanyProductSubProdMapping> getMappingById(Long userId) {
        return userMappingDao.findByUserUserId(userId);
    }

    @Override
    public void addMapping(List<UserCompanyProductSubProdMapping> userMapping){
        userMappingDao.saveAll(userMapping);
    }

    @Override
    public void deleteByUserTempUserId(Long userId) {
        userMappingTempDao.deleteByUserTempUserId(userId);
    }

    @Override
    public void flush() {
        userMappingTempDao.flush();
    }

}
