package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMappingTemp;
import com.indusind.trade.model.entities.company.UserTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.UserCompanyProductSubProdMappingTempDao;
import com.indusind.trade.model.repository.UserDao;
import com.indusind.trade.model.repository.UserTempDao;
import com.indusind.trade.model.service.UserService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserTempDao userTempDao;
    private final UserDao userDao;
    private final UserCompanyProductSubProdMappingTempDao userMappingDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public UserTemp saveUserTemp(UserTemp userTemp) {
        return userTempDao.save(userTemp);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public User saveUser(User user) {
        return userDao.save(user);
    }

    @Override
    public UserTemp getTempUserById(Long userId) {
        return userTempDao.findById(userId).orElseThrow(()-> new GTPAppException("UserTemp with id: " + userId + " does not exists.", null));
    }

    @Override
    public User getUserById(Long userId) {
        return userDao.findById(userId).orElseThrow(()->new GTPAppException("User with id: " + userId + " does not exists.", null));
    }

    @Override
    public List<UserCompanyProductSubProdMappingTemp> findByUserTempUserId(Long userId) {
        return userMappingDao.findByUserTempUserId(userId);
    }

    @Override
    public Page<UserTemp> getTempUsersByCompanyId(Long companyId, Pageable pageable) {
        return userTempDao.findByCompanyCompanyId(companyId, pageable);
    }

    @Override
    public Page<User> getUsersByCompanyId(Long companyId, Pageable pageable) {
        return userDao.findByCompanyCompanyId(companyId, pageable);
    }

    @Override
    public Page<User> getAllUsers(Pageable pageable) {
        return userDao.findAll(pageable);
    }

    @Override
    public Page<UserTemp> getAllTempUsers(Pageable pageable) {
        return userTempDao.findAll(pageable);
    }

    @Override
    public void flushUser() {
        userDao.flush();
    }

    @Override
    public void flushUserTemp() {
        userTempDao.flush();
    }

    @Override
    public Boolean existsUser(Long userId) {
        return userDao.existsById(userId);
    }

    @Override
    public Boolean existsUserTemp(Long userId) {
        return userTempDao.existsById(userId);
    }



    @Override
    public void lockUnlockUser(String loginId, boolean lockFlag, String cifId) {
        User user = getUserByLoginIdAndCifId(loginId, cifId).orElseThrow(()-> new GTPAppException("User not found", null));
        if (lockFlag) {
            user.setIsUserLocked(true);
            user.setLockedDate(LocalDateTime.now());
        } else {
            user.setIsUserLocked(false);
            user.setLoginFailedCount(0L);
            user.setOtpFailedCount(0L);
            user.setLockedDate(null);
        }
        saveUser(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void resetUserPasswordByUserId(Long userId, String password) {
        User user = getUserById(userId);
        user.setUserPassword(password);
        user.setChangePasswordDate(LocalDateTime.now());
        saveUser(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void resetUserPasswordByLoginIdAndCifId(String loginId, String password, String cifId) {
        User user = getUserByLoginIdAndCifId(loginId, cifId).orElseThrow(()-> new GTPAppException("User not found", null));
        user.setUserPassword(password);
        user.setChangePasswordDate(LocalDateTime.now());
        saveUser(user);
    }


    @Override
    public Optional<User> getUserByLoginIdAndCifId(String loginId, String cifId) {
        return userDao.findByLoginIdAndCompanyCifId(loginId, cifId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updatePrivacyPolicy(String loginId, boolean accepted, String cifId) {
        User user = getUserByLoginIdAndCifId(loginId, cifId).orElseThrow(() -> new GTPAppException("User not found", null));
        user.setTermPrivacyAccepted(true);
        this.saveUser(user);
    }

    @Override
    public boolean existsUserByCifId(String cifId) {
        return userDao.existsByCompanyCifId(cifId);
    }

    @Override
    public boolean existsUserByLoginId(String loginId) {
        return userDao.existsByLoginId(loginId);
    }

}
