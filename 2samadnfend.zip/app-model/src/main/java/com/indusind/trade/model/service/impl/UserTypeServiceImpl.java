package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.CategoryMasterDao;
import com.indusind.trade.model.repository.UserTypeDao;
import com.indusind.trade.model.service.UserTypeService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserTypeServiceImpl implements UserTypeService {

    private final UserTypeDao userTypeDao;
    private final CategoryMasterDao categoryMasterDao;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public UserType saveUserType(UserType userType) {
        return userTypeDao.save(userType);
    }

    @Override
    public Page<UserType> getAllUserTypes(Pageable pageable) {
        Page<UserType> page = userTypeDao.findAll(pageable);
        return page;
    }

    @Override
    public UserType getUserTypeById(Long userTypeId) {
        UserType userType = userTypeDao.findById(userTypeId).orElseThrow(() -> new GTPAppException("userType with id "+userTypeId+" not present", null));
        return userType;
    }

    @Override
    public UserType getUserTypeByType(String userTypeName) {
        return userTypeDao.findByUserTypeName(userTypeName);

    }

    @Override
    public List<UserType> getUserTypeByIdIn(List<Long> userTypeIds) {
        return userTypeDao.findAllById(userTypeIds);
    }

    @Override
    public List<UserType> getUserTypeByCategoryId(Long categoryId) {
        return userTypeDao.findByCategoryCategoryId(categoryId);
    }

    @Override
    public Page<UserType> getUserTypePageByCategory(Pageable pageable, Long categoryId) {
        return userTypeDao.findUserTypeByCategory(pageable, categoryId);
    }

    @Override
    public Boolean existsById(Long userTypeId) {
        return userTypeDao.existsById(userTypeId);
    }


}
