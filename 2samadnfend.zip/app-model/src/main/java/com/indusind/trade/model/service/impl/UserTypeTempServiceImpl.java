package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.master.UserTypeTemp;
import com.indusind.trade.model.repository.UserTypeTempDao;
import com.indusind.trade.model.service.UserTypeTempService;
import com.indusind.trade.model.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserTypeTempServiceImpl implements UserTypeTempService{

    private final UserTypeTempDao userTypeTempDao;

    @Override
    public UserTypeTemp saveUserTypeTemp(UserTypeTemp userTypeTemp) {
        return userTypeTempDao.save(userTypeTemp);
    }

    @Override
    public Page<UserTypeTemp> getAllTempUserType(Pageable pageable) {
        Page<UserTypeTemp> page = userTypeTempDao.findAll(pageable);
        return page;
    }

    @Override
    public UserTypeTemp getUserTypeTempById(Long userTypeId) {
        return userTypeTempDao.findById(userTypeId).orElseThrow(() -> new GTPAppException("userType with id "+userTypeId+" not present", null));
    }

    @Override
    public Boolean existsById(Long userTypeId) {
        return userTypeTempDao.existsById(userTypeId);
    }
}
