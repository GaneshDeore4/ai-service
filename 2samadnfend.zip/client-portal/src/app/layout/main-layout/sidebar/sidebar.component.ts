import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { AccessService } from '../../../core/services/access.service';
import { UserAccessProfile, Product } from '../../../core/models/access.models';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule]
})
export class SidebarComponent implements OnInit {
  accessProfile: UserAccessProfile | null = null;
  openGroups: Set<number> = new Set<number>();

  constructor(
    private authService: AuthService,
    private accessService: AccessService,
    private router: Router
  ) {}

  ngOnInit() {
    this.accessService.accessProfile$.subscribe(profile => {
      this.accessProfile = profile;
    });
  }

  toggleGroup(productId: number) {
    if (this.openGroups.has(productId)) {
      this.openGroups.delete(productId);
    } else {
      this.openGroups.add(productId);
    }
  }

  isGroupOpen(productId: number): boolean {
    return this.openGroups.has(productId);
  }

  shouldShowSubmenu(product: Product): boolean {
    const subs = product.subProducts || [];
    if (subs.length === 0) return false;
    if (subs.length === 1 && subs[0].subProductName === product.productName) return false;
    return true;
  }

  getIcon(productName: string): string {
    const iconMap: { [key: string]: string } = {
      'FD': 'fas fa-piggy-bank',
      'Account': 'fas fa-university',
      'Dashboard': 'fas fa-th-large',
      'Deal Booking': 'fas fa-handshake',
      'Remittances': 'fas fa-file-invoice-dollar',
      'Bills Payments': 'fas fa-money-bill-wave',
      'Service Requests': 'fas fa-concierge-bell',
      'User Management': 'fas fa-users-cog'
    };
    return iconMap[productName] || 'fas fa-folder';
  }

  getRoute(productName: string, subProductName?: string): string {
    // Basic mapping for routes based on your existing structure
    if (productName.toLocaleLowerCase() === 'account' || productName.toLocaleLowerCase() === 'accounts') {
      if (subProductName?.toLocaleLowerCase() === 'balance') return '/accounts/balance';
      if (subProductName?.toLocaleLowerCase() === 'statements') return '/accounts/statements';
      return '/accounts';
    }
    if (productName === 'FD' || productName === 'Deposits') return '/deposits';
    if (productName === 'Deal Booking' || productName === 'Deal Booking') return '/deal-booking';
    
    if (productName.toLocaleLowerCase() === 'remittances' || productName.toLocaleLowerCase() === 'remittances') {
      if (subProductName?.toLocaleLowerCase() === 'inward remittances') return '/remittance/inwardlist';
      if (subProductName?.toLocaleLowerCase() === 'outward remittances') return '/remittance/outwardlist';
      if (subProductName?.toLocaleLowerCase() === 'beneficiary maintenance') return '/remittance/beneficiarylist';
      return '/remittance';
    }
    if (productName.toLocaleLowerCase() === 'user management' || productName.toLocaleLowerCase() === 'user management') {
      if (subProductName?.toLocaleLowerCase() === 'create user') return '/user-management/user-list';
      if (subProductName?.toLocaleLowerCase() === 'approvals') return '/user-management/approval-list';
      if (subProductName?.toLocaleLowerCase() === 'user setup') return '/user-management/cm-user-profile';
      if (subProductName?.toLocaleLowerCase() === 'customer profile') return '/user-management/cm-profile';
      if (subProductName?.toLocaleLowerCase() === 'authorisation matrix') return '/user-management/cm-authorisation';
    }

    return '/dashboard'; // Fallback
  }

  logout() {
    // Clear all storage — removes token, user, access profile
    sessionStorage.clear();
    localStorage.clear();
    // Reset service state
    this.authService.logout();
    // Redirect to login page
    this.router.navigate(['/login']);
  }
}
