import { GTPCustomerReferenceTnxDto } from '../../../model/CustomerReference';
import { LegalInfoDto } from '../../../model/LegalInfoDto';
// import { SessionService } from './../../../core/services/sessionService/session.service';
import { SessionService } from '../../../core/services/sessionService/session.service';
import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { PageTitleComponent } from '../../../shared/components/page-title/page-title.component';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { map, Observable, startWith } from 'rxjs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { EntityService } from '../../../core/services/entityService/entity.service';
import { ActivatedRoute } from '@angular/router';
import { TabsModule, TabPanel, TabList } from 'primeng/tabs';
import { ApiService } from '../../../core/services/api.service';
import {
  APPROVE_COMPANY,
  AUTHORIZE_COMPANY,
  CREATE_COMPANY,
  GET_ALL_MASTER_ROLE,
  GET_ALL_MASTER_SUBPRODUCT,
  GET_ALL_ROLE,
  GET_ALL_TEMP_COMPANIES,
  GET_ALL_TEMP_COMPANY_BY_ID,
  GET_ALL_TXN_COMPANIES,
  GET_CATEGORY_BY_CATEGORY_NAME,
  GET_CATEGORY_BY_ID,
  GET_PRO_SUBPRO_MAP_BY_CATEGORY_ID,
  PRE_EXISTING_COMPANY_DETAILS_BY_CIF,
  REJECT_COMPANY,
  SEND_OTP,
  VALIDATE_OTP,
} from '../../../core/constants/api-endpoints';
import { GTPCompanyTnxDto } from '../../../model/CompanyProfile';
import { GTPAccountTnxDto } from '../../../model/Account';
import { TblComponent } from '../../../shared/components/tbl/tbl.component';
import { GTPRoleDto } from '../../../model/Role';
import { FloatLabel, FloatLabelModule } from 'primeng/floatlabel';
import { MultiSelectModule } from 'primeng/multiselect';
import COUNTRIES_DATA from '../../../core/constants/Countries';
import { SelectModule } from 'primeng/select';
import {
  SUPERADMIN,
  COMPANY_CATERGORY_ID,
  PAGE_SIZE,
  BANKSUPERADMINMAKER,
  BANKSUPERADMINCHECKER,
  BANKSETUPMAKER,
  BANKSETUPCHECKER,
  CLIENTRELEASER,
  CLIENTVERIFIER,
} from '../../../core/constants/Constants';
import { LoaderComponent } from '../../../shared/components/loader/loader.component';
import { ToastComponent } from '../../../shared/components/toast/toast.component';
import {
  AuditCard,
  UserAuditComponent,
} from '../../../shared/components/user-audit/user-audit.component';
import { OtpComponent } from '../../../shared/components/otp/otp.component';
import {
  CLIENTCHECKER,
  CLIENTMAKER,
  CLIENTMC,
} from '../../../core/constants/roles';

export interface RoleMasterEntity {
  roleId?: number;
  roleName?: string;
}
interface SubProduct {
  subProductId: number;
  name: string;
  selected: boolean;
}

interface SubproductApiItem {
  subProductId: number;
  subProductName: string;
  categoryId: number;
  categoryName: string;
  productId: number;
  productName: string;
  productNameLabel: string;
  subProductLabel: string;
}

interface Product {
  productId: number;
  name: string;
  selected: boolean;
  subProducts: SubProduct[];
  midOfficeFlag: Boolean;
  limitAmt: string;
}
interface Zone {
  key: string;
  value: string;
}

interface PreExistingCompanyValues {
  cifid: String;
  lastName: string;
  emailId: string;
  segment: string;
  address: PreExisitingPostalAddress[];
}
interface PreExisitingPostalAddress {
  address1: string;
  address2: string;
  address3: string;
  city: string;
  state: String;
  country: string;
  pincode: string;
  category: string;
}

@Component({
  selector: 'app-cm-profiles',
  imports: [
    PageTitleComponent,
    NgIf,
    NgFor,
    FormsModule,
    NgClass,
    CommonModule,
    MultiSelectModule,
    FloatLabelModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    SelectModule,
    TabPanel,
    TabList,
    TabsModule,
    TblComponent,
    LoaderComponent,
    ToastComponent,
    UserAuditComponent,
    OtpComponent,
  ],
  templateUrl: './cm-profiles.component.html',
  styleUrls: ['./cm-profiles.component.css','../styles_copy.css'],
})
export class CmProfilesComponent implements OnInit {
  isLoading = false;
  categoryId: number | null = null;
  queryParam = '';
  role = '';
  loginUsername = '';
  loginUserId: string = '';
  countryData = COUNTRIES_DATA;
  company: GTPCompanyTnxDto = new GTPCompanyTnxDto();
  customerReferenceEntity: GTPCustomerReferenceTnxDto =
    new GTPCustomerReferenceTnxDto();
  legalInfoEntity: LegalInfoDto = new LegalInfoDto();
  accountEntity: GTPAccountTnxDto = new GTPAccountTnxDto();
  actionList: string[] = [];
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'CompanyTable';
  isAuditOpen = false;
  channelRef = 'CH123456';

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }
  auditCards: AuditCard[] = [
    {
      label: 'Maker',
      name: 'ABC',
      datetime: '10 Apr 2026, 10:00 AM',
      status: 'completed',
    },
    {
      label: 'Checker',
      name: 'XYZ',
      datetime: '10 Apr 2026, 11:00 AM',
      status: 'completed',
    },
  ];
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  private sessionService = inject(SessionService);
  constructor(
    private entityService: EntityService,
    private cdr: ChangeDetectorRef,
    private activatedRoute: ActivatedRoute,
    private apiService: ApiService
  ) {
    const storedUser = sessionStorage.getItem('currentUser');
    if (storedUser) {
      const currentUser = JSON.parse(storedUser);
      this.role = currentUser.role;
      this.loginUsername = currentUser.userFirstName;
      this.loginUserId = currentUser.loginId
    }
  }

  ngOnInit() {
    if (this.role == CLIENTMAKER || this.role == CLIENTMC) {
      this.actionList = ['view', 'edit', 'audit'];

      // } else if (this.role == SUPERADMIN) {
      //   this.actionList = ['view', 'edit', 'replicate'];
    } else if (this.role == CLIENTCHECKER) {
      this.actionList = ['view'];
    } else this.actionList = ['view'];
    this.getCategory();
    this.getTableData();
    this.filteredCountries = this.countryControl.valueChanges.pipe(
      startWith(''),
      map((value) => this._filter(value || ''))
    );

    // this.getTableData();

    this.activatedRoute.queryParamMap.subscribe((params) => {
      this.queryParam = params.get('status') || '';
      if (this.queryParam == 'dashboard') {
        this.selectedStatus = 'Awaiting for Approval(N)';
        // console.log('queryParam :', this.queryParam);
        this.searchData();
      }
    });
  }
  approveRejectAvailable(): boolean {
    if (
      this.role == SUPERADMIN ||
      this.role == CLIENTCHECKER ||
      this.role == CLIENTRELEASER || 
      this.role == CLIENTVERIFIER
    )
      return true;
    else return false;
  }
  addBtnAllowed(): boolean {
    if (
      this.role == SUPERADMIN ||
      this.role == CLIENTMAKER ||
      this.role == CLIENTMC
    )
      return true;
    else return false;
  }

  //search vars
  searchAbbreviatedName = '';
  searchName = '';
  statusList: string[] = ['ALL', 'PENDING', 'APPROVED', 'REJECTED', 'RETURNED'];
  selectedStatus = '';

  searchData(): void {
    const filtered = this.ogData.filter((item) => {
      const searchStr = this.searchName ? this.searchName.toLowerCase() : '';

      const matchText = searchStr
        ? item['cifId']?.toLowerCase().includes(searchStr) ||
          item['name']?.toLowerCase().includes(searchStr)
        : true;

      // const matchStatus = this.selectedStatus && this.selectedStatus !== 'ALL'
      //   ? item['status'] === this.selectedStatus
      //   : true;

      return matchText;
    });

    // ✅ Update reference so child detects change
    this.data = [...filtered];
    this.cdr.detectChanges();
  }

  countryControl = new FormControl('');
  filteredCountries!: Observable<{ iso: string; name: string }[]>;
  selectedISO = '';

  private _filter(value: string): { iso: string; name: string }[] {
    const filterValue = value.toLowerCase();
    return this.countryList.filter((country) =>
      country.name.toLowerCase().includes(filterValue)
    );
  }

  selectCountry(country: { iso: string; name: string }) {
    this.selectedISO = country.iso;
  }

  displayCountry(country: { iso: string; name: string } | null): string {
    return country ? country.iso : '';
  }

  // main details
  countryList = [
    { iso: 'IN', name: 'India' },
    { iso: 'US', name: 'United States' },
    { iso: 'GB', name: 'United Kingdom' },
    { iso: 'CA', name: 'Canada' },
    { iso: 'AU', name: 'Australia' },
    { iso: 'FR', name: 'France' },
    { iso: 'DE', name: 'Germany' },
    { iso: 'JP', name: 'Japan' },
    { iso: 'CN', name: 'China' },
    { iso: 'BR', name: 'Brazil' },
  ];
  AIstatusList = ['Active', 'Inactive'];
  retentionPeriodList = ['6', '9', '12'];
  languageList: string[] = ['English(UK)', 'English(USA)', 'French', 'Arabic'];
  internalContentProviderList = ['Downtime Notification', 'Downtime'];
  CIF = '';

  // table config and data
  header: { key: string; value: string }[] = [
    { key: 'abbvName', value: 'Customer ID' },
    { key: 'name', value: 'Name' },
    { key: 'status', value: 'Status' },
    { key: 'createdBy', value: 'Maker' },
    { key: 'Action', value: 'Action' },
    // { key: 'Audit', value: 'Audit-trail' },
  ];

  columnWidths = ['25%', '30%', '10%', '25%', '10%'];

  data: any[] = [];
  ogData: any[] = [];

  getCategory() {
    this.apiService
      .getData(GET_CATEGORY_BY_ID + '?categoryId=' + COMPANY_CATERGORY_ID, {})
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.categoryId = res['payload']['categoryId'];
            this.company.categoryId = this.categoryId;
            this.getAllSubproducts();
          } else {
            console.log(res.description);
          }
        },
        error: (err) => {
          console.log('Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getTableData() {
    this.isLoading = true;

    this.apiService
      .getData(
        GET_ALL_TEMP_COMPANIES +
          '?page=' +
          (this.pageNumber - 1) +
          '&size=' +
          this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.data = res['payload']['content'];
            this.ogData = [...this.data];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  // table operations:
  editProfile = false;
  editProfileIndex = -1;
  popupVisible = false;
  popupText = '';
  addProfile = false;
  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }
  addProfilef() {
    this.showAccRefFields = true;
    this.showLegalInfoFields = true;
    this.showCustRefFields = true;
    this.getAllSubproducts();
    this.company = new GTPCompanyTnxDto();
    this.addProfile = true;
    this.company.isInitialAdminCreateFlag = false;
  }

  validateProfileForm(): boolean {
    this.clearMainFormError();
    let errorCount = 0;

    if (!this.company.abbvName) {
      this.abbreviatedNameErrorMsg = 'Customer ID cannot be empty.';
      this.abbreviatedNameError = true;
      errorCount++;
    }
    // cifId
    if (!this.company.name) {
      this.nameErrorMsg = 'Name cannot be empty.';
      this.nameError = true;
      errorCount++;
    }

    // if (!this.company.isoCode) {
    //   this.countryCodeErrorMsg = 'Please select a country code';
    //   this.countryCodeError = true;
    //   errorCount++;
    // }

    // if (!this.company.swiftTownName) {
    //   this.swiftTownNameErrorMsg = 'Town Name Cannot be Empty';
    //   this.swiftTownNameError = true;
    //   errorCount++;
    // }

    // this flag is pre selected
    if (!this.company.actvFlag) {
      this.statusError = true;
      errorCount++;
    }

    if (!this.company.baseCurCode) {
      this.currencyErrorMsg = 'Please select a currency code';
      this.currencyError = true;
      errorCount++;
    }

    if (!this.company.email) {
      this.emailErrorMsg = 'Email cannot be empty';
      this.emailError = true;
      errorCount++;
    }

    return errorCount === 0;
  }

  clearMainFormError() {
    this.abbreviatedNameErrorMsg = '';
    this.nameErrorMsg = '';
    this.countryCodeErrorMsg = '';
    this.swiftTownNameErrorMsg = '';
    this.statusErrorMsg = '';
    this.languageErrorMsg = '';
    this.currencyErrorMsg = '';
    this.emailErrorMsg = '';
    this.ieCodeErrorMsg = '';
    this.abbreviatedNameError = false;
    this.nameError = false;
    this.countryCodeError = false;
    this.swiftTownNameError = false;
    this.statusError = false;
    this.languageError = false;
    this.currencyError = false;
    this.emailError = false;
    this.ieCodeError = false;
  }

  saveForm(action: 'submit' | 'save') {
    if (!this.validateProfileForm()) {
      console.warn('Form validation failed');
      return;
    }
    this.isLoading = true;
    const payload = {
      // categoryId: this.categoryId,
      isUpdate: this.editProfileIndex != -1 ? true : false,
      companyId: this.company?.companyId ?? null,
      cifId: this.company?.abbvName?.trim(),
      abbvName: this.company?.abbvName?.trim(),
      name: this.company?.name?.trim(),
      addressDto: {
        streetName: this.company?.streetName ?? '',
        townName: this.company?.townName ?? '',
        countrySubDiv: this.company?.countrySubDiv ?? '',
        postCode: this.company?.postCode ?? '',
      },
      swiftAddress: {
        addressLine1: this.company?.addressLine1 ?? '',
        addressLine2: this.company?.addressLine2 ?? '',
        addressLine3: this.company?.addressLine3 ?? '',
        countryCode: this.company?.isoCode ?? '', //not used further
        country: this.company?.isoCode ?? '',
        contactReference: this.company?.reference ?? '',
        strtName: this.company?.strtName ?? '',
        buildingNumber: this.company?.buildingNumber ?? '',
        buildingName: this.company?.buildingName ?? '',
        floor: this.company?.floor ?? '',
        room: this.company?.room ?? '',
        districtName: this.company?.districtName ?? '',
        countrySubdivision: this.company?.countrySubdivision ?? '',
        department: this.company?.department ?? '',
        subDepartment: this.company?.subDepartment ?? '',
        postalCode: this.company?.postalCode ?? '',
        swiftTownName: this.company?.swiftTownName ?? '',
      },
      dualControl: this.company?.dualControl === 'enabled' ? 'Y' : 'N',
      controlStatus:
        this.company?.actvFlag === 'Active' ? 'ACTIVE' : 'INACTIVE',
      authOwnTransaction: this.company?.authorizeOwnTransaction ? 'Y' : 'N',
      initialAdmin: this.company?.isInitialAdminCreateFlag ? 'Y' : 'N',
      baseCurrency: this.company?.baseCurCode ?? '',
      clientSegment: this.company?.clientSegment ?? '',
      email: this.company?.email ?? '',
      // status: this.company?.actvFlag === 'Active' ? 'ACTIVE' : 'INACTIVE',
      createdBy: this.loginUserId?.toString() ?? '',
      accountDtoList: (this.company?.gtpAccountTnxDto ?? [])
        .filter((acc): acc is any => acc != null)
        .map((acc) => ({
          accountId: null,
          accountNo: acc.accountNo,
          accountType: acc.accountType,
          currency: acc.curCode,
          solId: acc.bankId,
          solDescription: acc.description,
          activeFlag: acc.actvFlag,
        })),
      customerReferenceDtoList: (this.company?.gtpCustomerReferenceTnxDto ?? [])
        .filter((ref): ref is GTPCustomerReferenceTnxDto => ref != null)
        .map((ref) => ({
          customerReferenceId: null,
          tradeProZone: ref.zone,
          solId: ref.solid,
          solDescription: ref.solDesc,
          customerReference: ref.customerReference,
          customerReferenceDescription: ref.customerDesc,
          defaultReference: 'Y',
        })),
      legalIdDetailsDtoList: (this.company?.legalInfoDto ?? [])
        .filter((l): l is LegalInfoDto => l != null)
        .map((l) => ({
          id: null,
          legalIdType: l.legalIdType,
          legalIdNo: l.legalIdNo,
          legalIdIssuingAuthority: l.legalIdIssuingAuthority,
        })),
      productIdList: (this.products ?? [])
        .filter((p) => p.selected)
        .map((p) => p.productId),
      subProductList: (this.products ?? [])
        .flatMap((p) => p.subProducts ?? [])
        .filter((sp) => sp.selected)
        .map((sp) => sp.subProductId),
      productLimit: (this.products ?? [])
        .filter((p) => p.selected)
        .map((p) => ({
          productId: p.productId,
          limitAmt: Number(p.limitAmt),
          midOfficeFlag: p.midOfficeFlag,
        })),
    };
    // console.log('REQUEST PAYLOAD:', payload);
    const actionRole = this.editProfileIndex === -1 ? 'CREATE' : 'EDIT';

    this.apiService
      .sendData(CREATE_COMPANY, payload, {
        'X-ACTION-ROLE': actionRole,
      })
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              this.editProfileIndex == -1
                ? 'Company created successfully'
                : 'Company updated successfully'
            );

            this.getTableData();
            this.backToList();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err: any) => {
          console.error('API ERROR:', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  approveRejectForm(action: string) {
    this.isLoading = true;
    const url = action === 'approve' ? APPROVE_COMPANY : REJECT_COMPANY;
    const actionRole = action === 'approve' ? 'APPROVE' : 'REJECT';
    this.apiService
      .sendData(
        url + '?companyId=' + this.company.companyId,
        {},
        {
          'X-ACTION-ROLE': actionRole,
        }
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              action === 'approve'
                ? 'Company Profile Approved'
                : 'Company Profile Rejected'
            );
            this.getTableData();
            this.backToList();
            this.checkerAction = '';
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  backToList() {
    this.company = new GTPCompanyTnxDto();
    this.editAccountIndex = -1;
    this.editCustRefIndex = -1;
    this.editProfileIndex = -1;
    this.addProfile = false;
    this.editProfile = false;
    this.viewProfile = false;
    this.cleanCustRefData();
    this.cleanLegalInfoData();
    this.clearAccountDataError();
    this.clearMainFormError();
  }
  viewProfile = false;
  viewProfilef(row: any, index: number) {
    this.addProfile = true;
    this.assignEditViewValues(row);
    // this.getAllSubproducts();
    this.viewProfile = true;
    this.cdr.detectChanges();
  }

  editProfilef(row: any, index: number) {
    this.addProfile = true;
    this.editProfile = true;
    this.editProfileIndex = index;
    this.assignEditViewValues(row);
  }

  deleteProfilef(row: any, index: number) {
    if (index >= 0 && index < this.data.length) {
      this.data.splice(index, 1);
      this.data = [...this.data];
      this.cdr.detectChanges();
    }
  }

  getCompanyById(id: number) {
    this.isLoading = true;
    this.apiService
      .getData(GET_ALL_TEMP_COMPANY_BY_ID + '?companyId=' + id, {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.company = GTPCompanyTnxDto.jsonToObject(res['payload']);
            if (res['payload']?.customerReferenceDtoList) {
              this.company.gtpCustomerReferenceTnxDto = res[
                'payload'
              ].customerReferenceDtoList.map((ref: any) => {
                const newRef = new GTPCustomerReferenceTnxDto();
                newRef.zone = ref.tradeProZone;
                newRef.solid = ref.solId;
                newRef.solDesc = ref.solDescription;
                newRef.customerReference = ref.customerReference;
                newRef.customerDesc = ref.customerReferenceDescription;
                return newRef;
              });
            }
            this.CIF = this.company.cifId?.toString() ?? '';
            // Now that company data is available, get the subproducts
            this.getAllSubproducts();
            this.cdr.detectChanges();
            console.log(
              'Company data is now available:',
              JSON.stringify(this.company, null, 2)
            );
            if (this.editProfile == true) {
              if (
                !this.company.gtpAccountTnxDto ||
                this.company.gtpAccountTnxDto.length == 0
              )
                this.showAccRefFields = true;
              else this.showAccRefFields = false;
              if (
                !this.company.gtpCustomerReferenceTnxDto ||
                this.company.gtpCustomerReferenceTnxDto.length == 0
              )
                this.showCustRefFields = true;
              else this.showCustRefFields = false;
              if (
                !this.company.legalInfoDto ||
                this.company.legalInfoDto.length == 0
              )
                this.showLegalInfoFields = true;
              else this.showLegalInfoFields = false;
            }
          } else {
            this.showToast('error', 'Error', res.description);
            this.isLoading = false;
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');

          this.isLoading = false;
        },
        complete: () => {},
      });
  }
  assignEditViewValues(row: GTPCompanyTnxDto) {
    this.abbreviatedNameError = false;
    this.nameError = false;
    this.countryCodeError = false;
    this.swiftTownNameError = false;
    this.statusError = false;
    this.languageError = false;
    this.currencyError = false;
    this.emailError = false;
    this.ieCodeError = false;
    this.abbreviatedNameErrorMsg = '';
    this.nameErrorMsg = '';
    this.countryCodeErrorMsg = '';
    this.swiftTownNameErrorMsg = '';
    this.statusErrorMsg = '';
    this.languageErrorMsg = '';
    this.currencyErrorMsg = '';
    this.emailErrorMsg = '';
    this.ieCodeErrorMsg = '';
    if (row.companyId) this.getCompanyById(row.companyId);
  }

  // field validations
  abbreviatedNameError = false;
  nameError = false;
  countryCodeError = false;
  swiftTownNameError = false;
  statusError = false;
  languageError = false;
  currencyError = false;
  emailError = false;
  ieCodeError = false;
  abbreviatedNameErrorMsg = '';
  nameErrorMsg = '';
  countryCodeErrorMsg = '';
  swiftTownNameErrorMsg = '';
  statusErrorMsg = '';
  languageErrorMsg = '';
  currencyErrorMsg = '';
  emailErrorMsg = '';
  ieCodeErrorMsg = '';
  valid() {}

  // LEGAL INFO POPUP START--------------------------------------------------------
  showLegalInfoFields = true;
  toggleLegalInfoFields() {
    this.legalInfoEntity = new LegalInfoDto();
    this.cleanLegalInfoData();
    this.showLegalInfoFields = !this.showLegalInfoFields;
  }
  showLegalInfoPopup = false;
  legalIdTypeList = [
    'PAN',
    'PASSPORT',
    'AADHAAR',
    'IE CODE',
    'UDYAM No.',
    'OTHER',
  ];

  legalIdTypeError = false;
  legalIdNoError = false;
  legalcountryCodeError = false;
  legalInfoheader = ['Legal Id Type', 'Legal Id No', 'Country Code', 'Action'];
  legalInfoHeaderMap: { [key: string]: string } = {
    'Legal Id Type': 'legalIdType',
    'Legal Id No': 'legalIdNo',
    'Country Code': 'legalIdIssuingAuthority',
  };
  legalInfoColumnWidth = ['25%', '25%', '25%', '25%'];
  deleteLegalInfoDataRow(rowIndex: number) {
    if (this.company.legalInfoDto) {
      const updatedData = [...this.company.legalInfoDto];
      updatedData.splice(rowIndex, 1);
      this.company.legalInfoDto = updatedData;
    }
  }
  editLegalInfoIndex = -1;
  editLegalInfoDataRow(rowIndex: number) {
    if (this.company.legalInfoDto) {
      this.openLegalInfoPopup();
      const selectedRow = this.company.legalInfoDto[rowIndex];
      if (selectedRow) {
        this.legalInfoEntity = new LegalInfoDto(selectedRow);
      }
      // Optionally store index for update later
      this.editLegalInfoIndex = rowIndex;
    }
  }
  saveLegalInfo() {
    let isValid = this.validateLegalInfoForm();
    if (!isValid) return;

    const newRef = new LegalInfoDto(this.legalInfoEntity);
    const currentRefs = this.company.legalInfoDto ?? [];

    if (this.editLegalInfoIndex === -1) {
      this.company.legalInfoDto = [...currentRefs, newRef];
    } else {
      const updatedRefs = [...currentRefs];
      updatedRefs[this.editLegalInfoIndex] = newRef;
      this.company.legalInfoDto = updatedRefs;
      this.editLegalInfoIndex = -1;
    }
    this.showLegalInfoFields = false;
    this.closeLegalInfoPopup();
  }
  openLegalInfoPopup() {
    this.legalInfoEntity = new LegalInfoDto();
    this.showLegalInfoPopup = true;
  }
  closeLegalInfoPopup() {
    this.showLegalInfoPopup = false;
    this.cleanLegalInfoData();
  }
  cleanLegalInfoData() {
    this.legalIdNoError = false;
    this.legalIdTypeError = false;
    this.legalcountryCodeError = false;
  }
  validateLegalInfoForm(): Boolean {
    this.cleanLegalInfoData();
    let errorCount = 0;
    if (!this.legalInfoEntity.legalIdType) {
      this.legalIdTypeError = true;
      errorCount++;
    }
    if (!this.legalInfoEntity.legalIdNo) {
      this.legalIdNoError = true;
      errorCount++;
    }
    if (!this.legalInfoEntity.legalIdIssuingAuthority) {
      this.legalcountryCodeError = true;
      errorCount++;
    }
    if (errorCount > 0) return false;
    return true;
  }

  // CUST REF POPUP START-----------------------------------------------------------
  showCustRefFields = true;
  toggleFields() {
    this.customerReferenceEntity = new GTPCustomerReferenceTnxDto();
    this.cleanCustRefData();
    this.showCustRefFields = !this.showCustRefFields;
  }
  zoneList: Zone[] = [
    {
      key: 'Z1',
      value: 'Z1.001',
    },
    {
      key: 'Z3',
      value: 'Z3.001',
    },
  ];
  custRefHeader = ['Customer Reference', 'Description', 'Action'];
  custRefHeaderMap: { [key: string]: string } = {
    'Customer Reference': 'customerReference',
    Description: 'customerDesc',
  };
  custRefColumnWidth = ['40%', '50%', '10%'];
  deleteCustRefDataRow(rowIndex: number) {
    if (this.company.gtpCustomerReferenceTnxDto) {
      const updatedData = [...this.company.gtpCustomerReferenceTnxDto];
      updatedData.splice(rowIndex, 1);
      this.company.gtpCustomerReferenceTnxDto = updatedData;
    }
  }

  editCustRefIndex = -1;
  editCustRefDataRow(rowIndex: number) {
    if (this.company.gtpCustomerReferenceTnxDto) {
      this.openCustRefPopup();
      const selectedRow = this.company.gtpCustomerReferenceTnxDto[rowIndex];
      if (selectedRow) {
        this.customerReferenceEntity = new GTPCustomerReferenceTnxDto(
          selectedRow
        );
      }
      // Optionally store index for update later
      this.editCustRefIndex = rowIndex;
    }
  }

  showCustRefPopup = false;
  custRefError = false;
  custRefDescError = false;
  custRefZoneError = false;

  saveCustomerRefs() {
    let isValid = this.validateCustRefForm();
    if (!isValid) return;

    console.log(
      'customer ref: ' +
        this.company.cifId +
        '.' +
        this.customerReferenceEntity.zone +
        '.' +
        this.customerReferenceEntity.solDesc
    );
    this.customerReferenceEntity.customerDesc =
      this.customerReferenceEntity.solDesc;
    this.customerReferenceEntity.customerReference =
      this.company.cifId +
      '.' +
      this.customerReferenceEntity.zone +
      '.' +
      this.customerReferenceEntity.solDesc;
    console.log(
      'cust ref after: ' + this.customerReferenceEntity.customerReference
    );
    const newRef = new GTPCustomerReferenceTnxDto(this.customerReferenceEntity);
    const currentRefs = this.company.gtpCustomerReferenceTnxDto ?? [];

    if (this.editCustRefIndex === -1) {
      this.company.gtpCustomerReferenceTnxDto = [...currentRefs, newRef];
    } else {
      const updatedRefs = [...currentRefs];
      updatedRefs[this.editCustRefIndex] = newRef;
      this.company.gtpCustomerReferenceTnxDto = updatedRefs;
      this.editCustRefIndex = -1;
    }
    this.showCustRefFields = false;
    this.customerReferenceEntity = new GTPCustomerReferenceTnxDto();
    this.closeCusRefPopup();
  }
  openCustRefPopup() {
    this.customerReferenceEntity = new GTPCustomerReferenceTnxDto();
    this.showCustRefPopup = true;
  }
  closeCusRefPopup() {
    this.showCustRefPopup = false;
    this.cleanCustRefData();
  }
  cleanCustRefData() {
    this.custRefError = false;
    this.custRefDescError = false;
    this.custRefZoneError = false;
  }
  validateCustRefForm(): Boolean {
    this.cleanCustRefData();
    let errorCount = 0;
    if (!this.customerReferenceEntity.solid) {
      this.custRefError = true;
      errorCount++;
    }
    if (!this.customerReferenceEntity.solDesc) {
      this.custRefDescError = true;
      errorCount++;
    }
    if (!this.customerReferenceEntity.zone) {
      this.custRefZoneError = true;
      errorCount++;
    }
    if (errorCount > 0) return false;
    return true;
  }
  // CUST REF POPUPLOGIC END---------------------------------------------------

  // ACCOUNT POPUP START--------------------------------------------------------
  showAccRefFields = true;
  toggleAccFields() {
    this.accountEntity = new GTPAccountTnxDto();
    this.clearAccountDataError();
    this.showAccRefFields = !this.showAccRefFields;
  }
  accountHeaders = ['Account Number', 'Account Type', 'Action'];
  accountHeaderMap: { [key: string]: string } = {
    'Account Number': 'accountNo',
    'Account Type': 'accountType',
  };
  accountColumnWidth = ['45%', '40%', '10%'];

  // Helper method to get property value from row object
  getPropertyValue(
    row: any,
    header: string,
    headerMap: { [key: string]: string }
  ): any {
    let propertyName = headerMap[header];
    return propertyName ? row?.[propertyName] : '';
  }

  editAccountIndex = -1;
  editAccountRow(index: number) {
    if (this.company.gtpAccountTnxDto) {
      this.showAccountAddPopupF();
      const selectedRow = this.company.gtpAccountTnxDto[index];
      if (selectedRow) {
        this.accountEntity = new GTPAccountTnxDto(selectedRow);
      }
      // Switch to edit mode
      this.editAccountIndex = index;
    }
  }

  deleteAccountRow(index: number) {
    if (this.company.gtpAccountTnxDto) {
      const updatedData = [...this.company.gtpAccountTnxDto];
      updatedData.splice(index, 1);
      this.company.gtpAccountTnxDto = updatedData;
    }
  }

  showAddAccountPopup = false;
  // Dropdown lists
  accountTypeList = ['Savings', 'Current', 'Fixed Deposit'];
  accountProductTypeList = ['Retail', 'Corporate', 'Investment'];
  accountOwnerTypeList = ['Individual', 'Joint', 'Corporate'];
  currencyList = ['INR', 'USD', 'EUR'];
  customerAccountTypeList = ['Primary', 'Secondary'];
  activeList = ['Active', 'Inactive'];

  // Error flags
  accountNumberError = false;
  accountTypeError = false;
  accountProductTypeError = false;
  accountOwnerTypeError = false;
  customerAccountTypeError = false;
  descriptionError = false;
  bankIdError = false;
  customerReferenceError = false;
  activeError = false;
  showAccountAddPopupF() {
    this.showAddAccountPopup = true;
  }
  saveAccount() {
    let isValid = this.validateAccountForm();
    if (!isValid) return;

    const newAccount = new GTPAccountTnxDto(this.accountEntity);
    const currentAccounts = this.company.gtpAccountTnxDto ?? [];

    if (this.editAccountIndex === -1) {
      this.company.gtpAccountTnxDto = [...currentAccounts, newAccount]; // ADD
    } else {
      const updatedAccounts = [...currentAccounts];
      updatedAccounts[this.editAccountIndex] = newAccount; // EDIT
      this.company.gtpAccountTnxDto = updatedAccounts;
      this.editAccountIndex = -1;
    }
    this.showAccRefFields = false;
    this.closeAccountPopup();
  }
  closeAccountPopup() {
    this.showAddAccountPopup = false;
    this.accountEntity = new GTPAccountTnxDto();
    this.clearAccountDataError();
  }
  clearAccountDataError() {
    this.accountNumberError = false;
    this.accountTypeError = false;
    this.accountProductTypeError = false;
    this.accountOwnerTypeError = false;
    this.customerAccountTypeError = false;
    this.descriptionError = false;
    this.bankIdError = false;
    this.customerReferenceError = false;
    this.activeError = false;
  }

  validateAccountForm(): boolean {
    let errorCount = 0;
    this.clearAccountDataError();
    // Validate required fields
    if (!this.accountEntity.accountNo) {
      this.accountNumberError = true;
      errorCount++;
    }
    if (!this.accountEntity.accountType) {
      this.accountTypeError = true;
      errorCount++;
    }

    if (!this.accountEntity.bankId) {
      this.bankIdError = true;
      errorCount++;
    }
    if (!this.accountEntity.description) {
      this.descriptionError = true;
      errorCount++;
    }
    if (!this.accountEntity.actvFlag) {
      this.activeError = true;
      errorCount++;
    }

    // Return false if any errors exist
    return errorCount === 0;
  }
  // ACCOUNT POPUP CODE END-----------------------------------------

  // PRODUCT SUBPRODUCT SELECTION---------------------------------------------

  getAllSubproducts() {
    this.apiService
      .getData(
        GET_PRO_SUBPRO_MAP_BY_CATEGORY_ID + '?categoryId=' + this.categoryId,
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.products = this.mapApiToProducts(res.payload);
            if (this.viewProfile || this.editProfileIndex != -1) {
              this.applySelectionsFromRelationMapMutating(
                this.products,
                this.company.prodSubProdMapping ?? {}
              );
              this.mapFlagAndAmount();
              this.products = [...this.products];
            }
            this.cdr.detectChanges();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  products: Product[] = [];
  mapFlagAndAmount() {
    this.company.prodLimits.forEach((limit) => {
      const prodId = limit.productId;
      const product = this.products.find((p) => p.productId === prodId);
      if (product) {
        product.limitAmt = limit.limitAmt.toString();
        product.midOfficeFlag = limit.midOfficeFlag;
      }
    });
  }
  mapApiToProducts(
    payload: Record<string, string[]>,
    options?: {
      sort?: boolean;
      onWarn?: (msg: string) => void;
    }
  ): Product[] {
    const warn = options?.onWarn ?? (() => {});
    const shouldSort = options?.sort ?? true;

    if (!payload || typeof payload !== 'object') return [];

    const products: Product[] = [];

    for (const [productKey, rawSubList] of Object.entries(payload)) {
      const parsedProduct = this.parseIdName(productKey);
      if (!parsedProduct) {
        warn(`Skipping product with invalid format: "${productKey}"`);
        continue;
      }

      const subProducts: SubProduct[] = [];

      (rawSubList ?? []).forEach((raw, idx) => {
        const parsedSub = this.parseIdName(raw);
        if (!parsedSub) {
          warn(
            `Skipping subProduct[${idx}] for "${productKey}" due to invalid format: "${raw}"`
          );
          return;
        }
        subProducts.push({
          subProductId: parsedSub.id,
          name: parsedSub.name,
          selected: false,
        });
      });

      products.push({
        productId: parsedProduct.id,
        name: parsedProduct.name,
        selected: false,
        subProducts,
        midOfficeFlag: false,
        limitAmt: '',
      });
    }

    if (shouldSort) {
      products.sort((a, b) => a.name.localeCompare(b.name));
      products.forEach((p) =>
        p.subProducts.sort((a, b) => a.name.localeCompare(b.name))
      );
    }

    return products;
  }
  parseIdName(input: string): { id: number; name: string } | null {
    if (typeof input !== 'string') return null;

    const dash = input.indexOf('-');
    if (dash <= 0 || dash === input.length - 1) return null;

    const idPart = input.slice(0, dash).trim();
    const namePart = input.slice(dash + 1).trim();

    const id = Number(idPart);
    if (!Number.isFinite(id) || namePart.length === 0) return null;

    return { id, name: namePart };
  }

  parseKey(key: string): { id?: number; name?: string } {
    // Splits "1-p1" or "2-p1s2" → { id: 1, name: "p1" / "p1s2" }
    const idx = key.indexOf('-');
    if (idx === -1) {
      const maybeId = Number(key);
      return Number.isFinite(maybeId) ? { id: maybeId } : { name: key.trim() };
    }
    const idPart = key.slice(0, idx).trim();
    const namePart = key.slice(idx + 1).trim();
    const idNum = Number(idPart);
    const id = Number.isFinite(idNum) ? idNum : undefined;
    const name = namePart || undefined;
    return { id, name };
  }

  eqCI(a?: string, b?: string): boolean {
    return !!a && !!b && a.trim().toLowerCase() === b.trim().toLowerCase();
  }

  applySelectionsFromRelationMapMutating(
    products: Product[],
    relationMap: Record<string, string[]>
  ): void {
    const productById = new Map<number, Product>();
    const productByName = new Map<string, Product>();
    products.forEach((p) => {
      productById.set(p.productId, p);
      productByName.set(p.name.trim().toLowerCase(), p);
    });

    for (const [productKey, subProductKeys] of Object.entries(
      relationMap ?? {}
    )) {
      const { id: pId, name: pName } = this.parseKey(productKey);

      let product: Product | undefined;
      if (pId !== undefined) product = productById.get(pId);
      if (!product && pName)
        product = productByName.get(pName.trim().toLowerCase());
      if (!product) continue;

      product.selected = true;

      const spById = new Map<number, SubProduct>();
      const spByName = new Map<string, SubProduct>();
      product.subProducts.forEach((sp) => {
        spById.set(sp.subProductId, sp);
        spByName.set(sp.name.trim().toLowerCase(), sp);
      });

      for (const spKey of subProductKeys ?? []) {
        const { id: spId, name: spName } = this.parseKey(spKey);

        let sp: SubProduct | undefined;
        if (spId !== undefined) sp = spById.get(spId);
        if (!sp && spName) sp = spByName.get(spName.trim().toLowerCase());
        if (!sp) continue;

        sp.selected = true;
      }
    }
  }

  // When parent checkbox changes

  onProductChange(product: Product): void {
    product.subProducts.forEach((sub) => {
      sub.selected = product.selected;
    });
  }

  // When sub product checkbox changes
  onSubProductChange(product: Product): void {
    product.selected = false;
    const allSelected = product.subProducts.every((sub) => sub.selected);
    product.subProducts.forEach((p) => {
      if (p.selected) {
        product.selected = true;
        return;
      }
    });
    this.cdr.detectChanges();
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'CompanyTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    }
  }
  auditFnc(row: any) {
    const url = `${GET_ALL_TEMP_COMPANY_BY_ID}?companyId=${row.companyId}`;

    this.apiService.getData(url, {}).subscribe({
      next: (res: any) => {
        console.log('Company Audit Response:', res);

        if (res?.status === 'SUCCESS' && res?.payload) {
          this.auditCards = this.createAuditCards(res.payload);
        }

        this.isAuditOpen = true;
      },
      error: (err) => {
        console.error('Audit API Error:', err);
      },
    });
  }

  createAuditCards(payload: any): AuditCard[] {
    const cards: AuditCard[] = [];

    // 🟢 Maker
    if (payload.makerName && payload.createdAt) {
      cards.push({
        label: 'Maker',
        name: payload.makerName,
        datetime: this.formatAuditDate(payload.createdAt),
        status: 'completed',
      });
    }

    // 🟡 Editor
    if (payload.editorName && payload.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: payload.editorName,
        datetime: this.formatAuditDate(payload.editedAt),
        status: 'completed',
      });
    }

    // 🔴 Rejected
    if (payload.rejectedBy && payload.rejectedAt) {
      cards.push({
        label: 'Last Rejected By',
        name: payload.rejectedBy,
        datetime: this.formatAuditDate(payload.rejectedAt),
        status: 'completed',
      });

      return cards; // 🚨 stop if rejected
    }

    // 🟢 Approved
    if (payload.checkerName && payload.approvedAt) {
      cards.push({
        label: 'Last Approved By',
        name: payload.checkerName,
        datetime: this.formatAuditDate(payload.approvedAt),
        status: 'completed',
      });
    }

    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);

    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  // OTP FUNCTIONS
  isOtpOpen = false;
  otpReference: string = '';
  tempReceivedOtp = '';
  checkerAction: string = '';
  sendOtp(action: string) {
    this.checkerAction = action;
    this.isOtpOpen = true;
    const payload = {
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
    };
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      },
    });
  }

  onOtpResend() {
    const payload = {
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
      otpReference: this.otpReference,
    };
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status) {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      },
    });
  }

  validateOtp(otp: string) {
    const payload = {
      otpReference: this.otpReference,
      enteredOtp: this.tempReceivedOtp, //REPLACE THIS AFTERWARD WITH otp varaible
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
    };
    this.apiService.sendData(VALIDATE_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          // TODO: if the otp is validate call onOtpVerify
          this.isOtpOpen = false;
          this.approveRejectForm(this.checkerAction);
        } else {
          this.isOtpOpen = false;
          this.approveRejectForm(this.checkerAction);
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        this.isOtpOpen = false;
        this.approveRejectForm(this.checkerAction);
        console.error(err);
      },
    });
  }

  closeOtpPopup() {
    this.isOtpOpen = false;
    this.otpReference = '';
    this.tempReceivedOtp = '';
  }

  // FETCH PREEXISITNG COMPANY DEATAIS USING CIF
  fetchPreExistingDetailsByCif() {
    this.isLoading = true;
    this.apiService
      .getData(
        PRE_EXISTING_COMPANY_DETAILS_BY_CIF + '?cifId=' + this.company.abbvName,
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            let responseData: PreExistingCompanyValues = res.payload;
            let addressData: PreExisitingPostalAddress =
              responseData.address[0];
            console.log('address: ' + JSON.stringify(addressData, null, 2));
            this.company.email = responseData.emailId;
            this.company.name = responseData.lastName;
            this.company.clientSegment = responseData.segment;
            this.company.streetName =
              addressData.address1 +
              ', ' +
              addressData.address2 +
              ', ' +
              addressData.address3;
            this.company.country = addressData.country;
            this.company.townName = addressData.city;
            this.company.postCode = addressData.pincode;
            console.log('company: ' + JSON.stringify(this.company, null, 2));
          } else {
            // this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          // this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
}
