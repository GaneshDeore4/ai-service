package com.indusind.trade.auth.audit;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.indusind.trade.model.entities.master.AuditLog;
import com.indusind.trade.model.repository.AuditLogDao;

import java.time.LocalDateTime;

/**
 * Centralized audit writer for Auth Service.
 * Writes events: AUTH_LOGIN_SUCCESS, AUTH_LOGIN_FAILURE, AUTH_LOGOUT,
 * DEVICE_UNRECOGNIZED, DEVICE_BLOCKED_ATTEMPT, SESSION_REVOKED
 *
 * Uses a NEW transaction (REQUIRES_NEW) so audits always persist
 * even if the calling transaction rolls back.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AuthAuditService {

    private final AuditLogDao auditLogDao;

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logEvent(String action, String loginId, String roleName,
            String ipAddress, String outcome,
            String reason, String sessionId) {
        try {
            AuditLog auditLog = new AuditLog();
            auditLog.setAction(action);
            auditLog.setModule("AUTH");
            auditLog.setPerformedBy(loginId);
            auditLog.setRoleName(roleName);
            auditLog.setIpAddress(ipAddress);
            auditLog.setTimestamp(LocalDateTime.now());
            // Store outcome + reason as newValue JSON (append-only pattern)
            auditLog.setNewValue(buildOutcomeJson(outcome, reason, sessionId));
            auditLogDao.save(auditLog);
        } catch (Exception e) {
            // Never let audit failure break the business flow
            log.error("Failed to write audit log for action={} user={}: {}", action, loginId, e.getMessage());
        }
    }

    private String buildOutcomeJson(String outcome, String reason, String sessionId) {
        return String.format("{\"outcome\":\"%s\",\"reason\":\"%s\",\"sessionId\":\"%s\"}",
                nullSafe(outcome), nullSafe(reason), nullSafe(sessionId));
    }

    private String nullSafe(String s) {
        return s != null ? s : "";
    }
}
