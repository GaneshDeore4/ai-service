package com.indusind.trade.auth.config;

import com.indusind.trade.auth.security.CustomUserDetailsService;
import com.indusind.trade.auth.util.LdapRelidAuthenticationProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@EnableSpringDataWebSupport(pageSerializationMode = EnableSpringDataWebSupport.PageSerializationMode.VIA_DTO)
public class AuthenticationProviderConfig {

//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }

    @Bean(name = "clientAuthenticationProvider")
    public AuthenticationProvider clientAuthenticationProvider(
            CustomUserDetailsService customUserDetailsService,
            PasswordEncoder passwordEncoder) {

        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(customUserDetailsService);
        provider.setPasswordEncoder(passwordEncoder);

        return provider;
    }

//    @Bean(name = "bankAuthenticationProvider")
//    public AuthenticationProvider bankAuthenticationProvider(
//            BankUserDetailsService bankUserDetailsService,
//            PasswordEncoder passwordEncoder) {
//
//        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
//        provider.setUserDetailsService(bankUserDetailsService);
//        provider.setPasswordEncoder(passwordEncoder);
//
//        return provider;
//    }

    @Bean(name = "bankAuthenticationProvider")
    public AuthenticationProvider bankAuthenticationProvider(
            LdapRelidAuthenticationProvider ldapRelidAuthenticationProvider) {

        return ldapRelidAuthenticationProvider;
    }

/* 
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        // If we are using gateway then not required below code.
        CorsConfiguration cors = new CorsConfiguration();
        // Use your actual frontend URL(s)
        cors.setAllowedOrigins(List.of(
                "http://localhost:4200",
                "https://13.233.151.65",
                "http://13.233.151.65"));
        cors.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        cors.setAllowedHeaders(List.of("*"));
        cors.setExposedHeaders(List.of("Authorization", "Content-Type"));
        cors.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", cors);
        return source;
    }
*/

    @Bean
    public AuthenticationManager authenticationManager(
            @Qualifier("clientAuthenticationProvider") AuthenticationProvider clientProvider,
            @Qualifier("bankAuthenticationProvider") AuthenticationProvider bankProvider) {

        return new ProviderManager(List.of(clientProvider, bankProvider));
    }

//    @Bean
//    public AuthenticationManager authenticationManager(
//            AuthenticationConfiguration authenticationConfiguration) throws Exception {
//
//        return authenticationConfiguration.getAuthenticationManager();
//    }

}
