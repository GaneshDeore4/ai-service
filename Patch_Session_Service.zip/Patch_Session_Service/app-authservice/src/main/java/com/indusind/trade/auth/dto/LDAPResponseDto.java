package com.indusind.trade.auth.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class LDAPResponseDto {

    private Boolean success;
    private String objectName;
    private String requestUUID;
    private LocalDateTime timestamp;

}
