package com.indusind.trade.auth.dto;

import org.springframework.stereotype.Component;

@Component
public class RelRvnStatusResponse {
    private String response_code;

    private String user_id;

    private String action_response;

    private String status;

    private String msg_id;

    private String delivery_status;

    private String verification_mode;

    private String notification_uuid;

    private String is_ds_verified;

    private String error_code;

    private String error_message;

    private String push_fallback_status;

    private String original_veriification_mode;

    private String create_ts;

    private String update_ts;

    private String expiry_timestamp;

    private String client_ip_address;

    public String getResponse_code() {
        return this.response_code;
    }

    public void setResponse_code(String response_code) {
        this.response_code = response_code;
    }

    public String getUser_id() {
        return this.user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getAction_response() {
        return this.action_response;
    }

    public void setAction_response(String action_response) {
        this.action_response = action_response;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMsg_id() {
        return this.msg_id;
    }

    public void setMsg_id(String msg_id) {
        this.msg_id = msg_id;
    }

    public String getDelivery_status() {
        return this.delivery_status;
    }

    public void setDelivery_status(String delivery_status) {
        this.delivery_status = delivery_status;
    }

    public String getVerification_mode() {
        return this.verification_mode;
    }

    public void setVerification_mode(String verification_mode) {
        this.verification_mode = verification_mode;
    }

    public String getNotification_uuid() {
        return this.notification_uuid;
    }

    public void setNotification_uuid(String notification_uuid) {
        this.notification_uuid = notification_uuid;
    }

    public String getIs_ds_verified() {
        return this.is_ds_verified;
    }

    public void setIs_ds_verified(String is_ds_verified) {
        this.is_ds_verified = is_ds_verified;
    }

    public String getError_code() {
        return this.error_code;
    }

    public void setError_code(String error_code) {
        this.error_code = error_code;
    }

    public String getError_message() {
        return this.error_message;
    }

    public void setError_message(String error_message) {
        this.error_message = error_message;
    }

    public String getPush_fallback_status() {
        return this.push_fallback_status;
    }

    public void setPush_fallback_status(String push_fallback_status) {
        this.push_fallback_status = push_fallback_status;
    }

    public String getOriginal_veriification_mode() {
        return this.original_veriification_mode;
    }

    public void setOriginal_veriification_mode(String original_veriification_mode) {
        this.original_veriification_mode = original_veriification_mode;
    }

    public String getCreate_ts() {
        return this.create_ts;
    }

    public void setCreate_ts(String create_ts) {
        this.create_ts = create_ts;
    }

    public String getUpdate_ts() {
        return this.update_ts;
    }

    public void setUpdate_ts(String update_ts) {
        this.update_ts = update_ts;
    }

    public String getExpiry_timestamp() {
        return this.expiry_timestamp;
    }

    public void setExpiry_timestamp(String expiry_timestamp) {
        this.expiry_timestamp = expiry_timestamp;
    }

    public String getClient_ip_address() {
        return this.client_ip_address;
    }

    public void setClient_ip_address(String client_ip_address) {
        this.client_ip_address = client_ip_address;
    }
}

