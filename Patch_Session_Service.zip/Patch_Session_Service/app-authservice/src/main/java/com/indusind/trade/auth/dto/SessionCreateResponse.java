package com.indusind.trade.auth.dto;

import com.indusind.trade.auth.enums.SessionStatus;
import lombok.Builder;
import lombok.Value;

import java.time.Instant;

@Value
@Builder
public class SessionCreateResponse {
    String sessionId;
    Long userId;
    SessionStatus sessionStatus;
    Instant loginTime;
    Instant expiryTime;
    String token;
}
