package com.indusind.trade.auth.security;

import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.repository.BankUserDao;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BankUserDetailsService implements UserDetailsService {

    private final BankUserDao bankUserDao;

    @Override
    public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {
        // Find user by Login ID
        String userName = loginId.split("-")[0];
        String bankAbbvName = loginId.split("-")[1];
        BankUser bankUser = bankUserDao.findByLoginIdAndBankProfileAbbvName(userName, bankAbbvName)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with loginId: " + loginId));

        // Return AppUserDetails with role info
        return new AppUserDetails(bankUser);
    }
}
