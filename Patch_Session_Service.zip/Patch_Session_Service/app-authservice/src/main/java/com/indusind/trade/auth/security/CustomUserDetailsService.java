package com.indusind.trade.auth.security;

import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.repository.UserDao;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final UserDao userDao;

    @Override
    public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {
        String userName = loginId.split("-")[0];
        String cifId = loginId.split("-")[1];
        // Find user by Login ID
        User user = userDao.findByLoginIdAndCompanyCifId(userName, cifId)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with loginId: " + loginId));

        // Return AppUserDetails with role info
        return new AppUserDetails(user);
    }
}
