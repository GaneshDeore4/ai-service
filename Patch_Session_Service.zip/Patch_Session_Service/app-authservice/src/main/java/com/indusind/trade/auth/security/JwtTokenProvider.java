package com.indusind.trade.auth.security;

import com.indusind.trade.model.common.security.SecurityUtils;
import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.stream.Collectors;

@Component
@Slf4j
public class JwtTokenProvider {

    @Value("${jwt.secret}")
    private String jwtSecret;

    @Value("${jwt.expiration}")
    private long jwtExpirationDate;

    /**
     * Generate JWT with enriched claims:
     * loginId, role, userType (USER/SERVICE), companyId, sessionId, deviceId,
     * device_fingerprint
     */
    public String generateToken(Authentication authentication,
            jakarta.servlet.http.HttpServletRequest request,
            String userType,
            String cifIdOrAbbvName, String sessionId, String deviceId) {
        String username = authentication.getName();
        Date currentDate = new Date();
        Date expireDate = new Date(currentDate.getTime() + jwtExpirationDate);

        String deviceFingerprint = SecurityUtils.generateDeviceFingerprint(request);

        // Extract roles from Authentication
        String roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));

        return Jwts.builder()
                .subject(username+"-"+cifIdOrAbbvName)
                .claim("loginId", username)
                .claim("userType", userType != null ? userType : "USER")
                .claim("cifIdOrAbbvName", cifIdOrAbbvName)
                .claim("roles", roles)
                .claim("sessionId", sessionId)
                .claim("deviceId", deviceId)
                .claim("device_fingerprint", deviceFingerprint)
                .issuedAt(currentDate)
                .expiration(expireDate)
                .signWith(key(), Jwts.SIG.HS256)
                .compact();
    }

    /**
     * Backward-compatible overload (no extra claims) — used by existing callers.
     */
    public String generateToken(Authentication authentication,
            jakarta.servlet.http.HttpServletRequest request) {
        return generateToken(authentication, request, "USER", null, null, null);
    }

    private SecretKey key() {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
    }

    public String getUsername(String token) {
        return getClaims(token).getSubject();
    }

    public Claims getClaims(String token) {
        return Jwts.parser()
                .verifyWith(key())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public String getClaimAsString(String token, String claimName) {
        try {
            Object val = getClaims(token).get(claimName);
            return val != null ? val.toString() : null;
        } catch (Exception e) {
            return null;
        }
    }

    public boolean validateToken(String token, jakarta.servlet.http.HttpServletRequest request) {
        try {
            Jws<Claims> claimsJws = Jwts.parser()
                    .verifyWith(key())
                    .build()
                    .parseSignedClaims(token);

            // Device Binding Check — only if fingerprint was embedded
            String tokenFingerprint = claimsJws.getPayload().get("device_fingerprint", String.class);
            if (tokenFingerprint != null) {
                String currentFingerprint = SecurityUtils
                        .generateDeviceFingerprint(request);
                if (!tokenFingerprint.equals(currentFingerprint)) {
                    log.error("Device Fingerprint Mismatch — possible token theft. IP: {}",
                            request.getRemoteAddr());
                    return false;
                }
            }
            return true;
        } catch (io.jsonwebtoken.security.SignatureException ex) {
            log.error("Invalid JWT signature");
        } catch (MalformedJwtException ex) {
            log.error("Invalid JWT token");
        } catch (ExpiredJwtException ex) {
            log.error("Expired JWT token");
        } catch (UnsupportedJwtException ex) {
            log.error("Unsupported JWT token");
        } catch (IllegalArgumentException ex) {
            log.error("JWT claims string is empty");
        }
        return false;
    }
}

