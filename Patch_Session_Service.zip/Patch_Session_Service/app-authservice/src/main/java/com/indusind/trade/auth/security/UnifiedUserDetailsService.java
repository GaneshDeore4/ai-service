package com.indusind.trade.auth.security;

import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.repository.BankUserDao;
import com.indusind.trade.model.repository.UserDao;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UnifiedUserDetailsService implements UserDetailsService {

    private final UserDao clientRepo;
    private final BankUserDao bankRepo;

    public UnifiedUserDetailsService(UserDao clientRepo,
                                     BankUserDao bankRepo) {
        this.clientRepo = clientRepo;
        this.bankRepo = bankRepo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) {
        String userName = username.split("-")[0];
        String cifIdOrAbbvName = username.split("-")[1];

        Optional<User> client = clientRepo.findByLoginIdAndCompanyCifId(userName, cifIdOrAbbvName);
        if (client.isPresent()) {
            return new AppUserDetails(client.get());
        }

        Optional<BankUser> bank = bankRepo.findByLoginIdAndBankProfileAbbvName(userName, cifIdOrAbbvName);
        if (bank.isPresent()) {
            return new AppUserDetails(bank.get());
        }

        throw new UsernameNotFoundException("User not found");
    }
}
