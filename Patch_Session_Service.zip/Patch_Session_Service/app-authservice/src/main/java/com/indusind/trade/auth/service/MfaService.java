package com.indusind.trade.auth.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * MFA Service — in-memory OTP store (Redis-free).
 *
 * TODO: When Redis is installed:
 *  1. Re-add Redis dependencies in pom.xml
 *  2. Replace the in-memory map with StringRedisTemplate
 *  3. Use redisTemplate.opsForValue().set(key, otp, Duration.ofMinutes(5))
 */
@Service
@Slf4j
public class MfaService {

    @Value("${mfa.otp.expiry.minutes:5}")
    private int otpExpiryMinutes;

    @Value("${mfa.enabled:false}")
    private boolean mfaEnabled;

    // Fallback: in-memory OTP store (NOT suitable for multi-instance / production)
    private final Map<String, OtpEntry> otpStore = new ConcurrentHashMap<>();

    private static final String OTP_PREFIX = "mfa:otp:";

    public void generateAndSendOtp(String loginId, String type) {
        if (!mfaEnabled) {
            log.info("MFA is disabled. Skipping OTP generation for user {}", loginId);
            return;
        }
        String otp = String.format("%06d", new Random().nextInt(999999));
        Instant expiry = Instant.now().plusSeconds(otpExpiryMinutes * 60L);
        otpStore.put(OTP_PREFIX + loginId, new OtpEntry(otp, expiry));

        log.info("MFA OTP generated for user {}: {}", loginId, otp);

        // Call the existing sms-email-service when MFA is enabled
        try {
            String url = "http://sms-email-service/api/communication/send"
                    + (type.equals("client") ? "User" : "BankUser") + "Otp";
            log.info("Calling {} to deliver OTP", url);
            // restTemplate.postForEntity(url, Map.of("loginId", loginId, "otp", otp), String.class);
        } catch (Exception e) {
            log.error("Failed to send OTP via sms-email-service: {}", e.getMessage());
        }
    }

    public boolean verifyOtp(String loginId, String otp) {
        if (!mfaEnabled) {
            log.info("MFA is disabled. Auto-passing OTP verification for user {}", loginId);
            return true;
        }
        OtpEntry entry = otpStore.get(OTP_PREFIX + loginId);
        if (entry != null && !entry.isExpired() && entry.otp().equals(otp)) {
            otpStore.remove(OTP_PREFIX + loginId);
            return true;
        }
        return false;
    }

    // Simple in-memory OTP record
    private record OtpEntry(String otp, Instant expiry) {
        boolean isExpired() {
            return Instant.now().isAfter(expiry);
        }
    }
}
