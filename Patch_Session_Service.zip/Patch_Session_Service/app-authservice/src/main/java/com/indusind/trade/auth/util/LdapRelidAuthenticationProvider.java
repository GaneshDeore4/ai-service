package com.indusind.trade.auth.util;

import com.indusind.trade.auth.security.BankUserDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class LdapRelidAuthenticationProvider implements AuthenticationProvider {

    private final LoginLDAP loginLDAP;
    private final RELID_2FA_Auth relid2FAAuth;
    private final BankUserDetailsService bankUserDetailsService;

    private final PasswordEncoder passwordEncoder;

    @Override
    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {

        String combinedLogin = authentication.getName(); // loginId-bank
        String password = (String) authentication.getCredentials();

        // ------------------------------------
        // 1. Split loginId-bank
        // ------------------------------------
        String userName = combinedLogin.split("-")[0];
        String bankAbbvName = combinedLogin.split("-")[1];

        // ------------------------------------
        // 2. LDAP authentication
        // ------------------------------------
        String ldapResult = loginLDAP.validateLDAPDtls(userName, password);
//        String ldapResult = "success";
        if (!"success".equalsIgnoreCase(ldapResult)) {
            throw new BadCredentialsException("LDAP authentication failed");
        }

        // ------------------------------------
        // 3. RELID 2FA
        // ------------------------------------
//        String relidResult = relid2FAAuth.validate2FA(userName);
        String relidResult = "success";
        if (!"success".equalsIgnoreCase(relidResult)) {
            throw new BadCredentialsException("RELID authentication failed");
        }

        // ------------------------------------
        // 4. Load application user (roles only)
        // ------------------------------------
        UserDetails userDetails =
                bankUserDetailsService.loadUserByUsername(userName + "-" + bankAbbvName);

//        needs to be removed once LDAP is integrated
        if (!passwordEncoder.matches(password, userDetails.getPassword())) {
            throw new BadCredentialsException("Incorrect Password");
        }

        return new LdapRelidAuthenticationToken(
                userDetails,
                userDetails.getAuthorities()
        );
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return LdapRelidAuthenticationToken.class.isAssignableFrom(authentication);
    }
}

