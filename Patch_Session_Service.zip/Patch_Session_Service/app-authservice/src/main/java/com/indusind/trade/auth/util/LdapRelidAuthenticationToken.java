package com.indusind.trade.auth.util;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;

public class LdapRelidAuthenticationToken extends AbstractAuthenticationToken {

    private final Object principal;
    private Object credentials;

    public LdapRelidAuthenticationToken(String username, String password) {
        super(null);
        this.principal = username;
        this.credentials = password;
        setAuthenticated(false);
    }

    public LdapRelidAuthenticationToken(UserDetails user, Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.principal = user;
        this.credentials = null;
        setAuthenticated(true);
    }

    @Override
    public Object getCredentials() { return credentials; }

    @Override
    public Object getPrincipal() { return principal; }
}