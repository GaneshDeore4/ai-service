package com.indusind.trade.auth.util;

import java.time.LocalDateTime;
import java.util.Hashtable;
import java.util.UUID;

import javax.naming.AuthenticationException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import com.indusind.trade.auth.client.LDAPClient;
import com.indusind.trade.auth.dto.LDAPRequestDto;
import com.indusind.trade.auth.dto.LDAPResponseDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
//import org.springframework.remoting.RemoteAccessException;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
@Slf4j
@RequiredArgsConstructor
public class LoginLDAP {

    private final LDAPClient ldapClient;

    @Value("${ibl.client.id}")
    private String iblClientId;

    @Value("${ibl.client.secret}")
    private String iblClientSecret;

    @Value("${LDAP_PROVIDER_URL}")
    private String LDAP_PROVIDER_URL;

    @Value("${LDAP_PROVIDER_URL_SEC}")
    private String LDAP_PROVIDER_URL_SEC;

    @Value("${LDAP_PROVIDER_PRINCIPAL}")
    private String LDAP_PROVIDER_PRINCIPAL;

    public static final String LDAP_SECURITY_AUTHENTICATION = "simple";

    // public String validateLDAPDtls(String username, String password) {
    // DirContext dirContext;
    // log.info("LoginLDAP : validateLDAPDtls : Start");
    //
    // Hashtable<String, String> env = new Hashtable<String, String>();
    // try {
    // this.log.info("Primary url used: " + LDAP_PROVIDER_URL);
    // env.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
    // env.put("java.naming.provider.url", LDAP_PROVIDER_URL);
    // env.put("java.naming.security.authentication", "simple");
    // env.put("java.naming.security.principal", LDAP_PROVIDER_PRINCIPAL +
    // username);
    // env.put("java.naming.security.credentials", password);
    // dirContext = new InitialDirContext(env);
    // }
    // catch(RemoteAccessException re) {
    // log.info("LoginLDAP : Remote exception validateLDAPDtls : Failed with url: ",
    // re);
    // re.printStackTrace();
    // return "failure";
    // }
    // /*
    // * catch(RemoteAccessException re) {
    // * log.info("LoginLDAP : validateLDAPDtls : Failed with primary url");
    // * log.info("LoginLDAP : validateLDAPDtls : validating with secondary url");
    // try
    // * { env.put(Context.PROVIDER_URL, LDAP_PROVIDER_URL_SEC); dirContext = new
    // * InitialDirContext(env); } catch (AuthenticationException ex) {
    // * log.info("LoginLDAP : validateLDAPDtls : End"); return "authfail"; } catch
    // * (Exception ed) { log.info("LoginLDAP : validateLDAPDtls : End"); return
    // * "failure"; } }
    // */
    // catch (AuthenticationException ex) {
    // log.info("LoginLDAP : Auth Failed validateLDAPDtls : End : " , ex);
    // ex.printStackTrace();
    // return "authfail";
    // }
    // catch (Exception ed) {
    // log.info("LoginLDAP : validateLDAPDtls : End : ", ed);
    // ed.printStackTrace();
    // return "failure";
    // }
    // if (dirContext != null) {
    // log.info("LoginLDAP : dirContext is not null : validateLDAPDtls successfull :
    // End");
    // return "success";
    // }
    // log.info("LoginLDAP : validateLDAPDtls : End");
    // return "authfail";
    // }

    public String validateLDAPDtls(String username, String password) {
        LDAPRequestDto request = LDAPRequestDto.builder()
                .requestUUID(UUID.randomUUID().toString())
                .userid(username)
                .password(password)
                .timestamp(LocalDateTime.now())
                .build();

        try {
            // uncomment while deployment
            // LDAPResponseDto response = ldapClient.callLDAP(
            // iblClientId,
            // iblClientSecret,
            // request);

            LDAPResponseDto response = getDummyLDAPResponse();

            if (response.getSuccess()) {
                return "success";
            } else {
                return "authfail";
            }

        } catch (Exception e) {
            log.error("Something went wrong while calling LDAP: " + e.getMessage());
        }

        return "authfail";
    }

    private LDAPResponseDto getDummyLDAPResponse() {
        return LDAPResponseDto.builder()
                .success(true)
                .objectName("CN=Virendra Jain Ritvik,OU=Users,OU=IBL House Office,OU=Mumbai-HUB,DC=IBL,DC=COM")
                .requestUUID(UUID.randomUUID().toString())
                .timestamp(LocalDateTime.now())
                .build();
    }
}
