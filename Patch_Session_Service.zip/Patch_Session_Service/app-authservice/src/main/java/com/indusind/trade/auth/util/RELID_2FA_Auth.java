package com.indusind.trade.auth.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

import com.indusind.trade.auth.dto.RelRvnResponse;
import com.indusind.trade.auth.dto.RelRvnStatusResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class RELID_2FA_Auth {
    @Autowired
    private RelRvnResponse relRvnResponse;

    @Autowired
    private RelRvnStatusResponse relRvnStatusResponse;

    static final String USER_AGENT = "Mozilla/5.0";

//  static final String enterpriseId = "asbauat";
//
//  static final Integer EXPIRES_IN = Integer.valueOf(60);
//
//  static final String authToken = "eyJraWQiOiIwMGRkZDcxNi01YTA4LTQ1OWItYWM1Zi0xOTVmMjUwYzdmODIiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJabUZpTVdOaU5qQXROV05qTXkwMFkyTTBMV0l4WTJJdE5qQTFZMk16WTJOak5EZ3giLCJhdWQiOlsicmVsaWQtdmVyaWZ5LXNlcnZlciIsImdtLWFwaS1zZXJ2ZXIiLCJ1c2VyLWFwaS1zZXJ2ZXIiXSwibmJmIjoxNzI1NTM2NDQwLCJ1c2VyX25hbWUiOiJabUZpTVdOaU5qQXROV05qTXkwMFkyTTBMV0l4WTJJdE5qQTFZMk16WTJOak5EZ3giLCJzY29wZSI6ImFsbCIsImlzcyI6Imh0dHBzOlwvXC9hdXRoLnJlbGlkLmNvbSIsImV4cCI6MTc1NzA3MjQ0MCwiaWF0IjoxNzI1NTM2NDQwLCJqdGkiOiI0N2Q5OTIzMy04NzA4LTRkMzQtYTdkMi0zMjE0NjdhMTViM2EiLCJjbGllbnRfaWQiOiJabUZpTVdOaU5qQXROV05qTXkwMFkyTTBMV0l4WTJJdE5qQTFZMk16WTJOak5EZ3gifQ.jQJfFqG5qxnQeXjif4yGnju8R0TPksbu3FiRISgiNe_5rLICBe9mdBHpNmaW2-3gC9hsrT0oVNAikqcvj8BkFiDU_lExg2LKTtIaUMg--vRgFD9_pPWEhOQTtr4CrLagEYWefhBtYicYAkgBRSwAc4jkNrToypVmKH9h4CKGQEomqLHZdsAu88cCnFGjAyErXFJoq2vTa-F-ZFThZUtyVfeFyOjv4L4hCCmhlcy7jDK-mW6lzKwlLHWrzTF7gSXCkgnVx0va6RsXTFkpns5HirqLO3FF4Lt6FqllxT30aX1V32YWxJ9XXzzMMIbD_U3jfda0Y1_XcWgiSUBW_22V1A";
//
//  static final String CLIENT_ID = "ZmFiMWNiNjAtNWNjMy00Y2M0LWIxY2ItNjA1Y2MzY2NjNDgx";
//
//  static final String CLIENT_SECRET = "ff39d29502ee927a65fd7a227d96b4845733c0351a3a657e96697a5f9f655391";
//
//static final String RVN_GENERATE_URL = "https://10.24.115.23:8007/generateRVN.htm";
//
//static final String RVN_STATUS_URL = "https://10.24.115.23:8007/getRVNStatus.htm";

    static final String ENTERPRISE_ID = "egovuat";

    static final Integer EXPIRES_IN = Integer.valueOf(60);

    static final String AUTH_TOKEN = "eyJraWQiOiIwMGRkZDcxNi01YTA4LTQ1OWItYWM1Zi0xOTVmMjUwYzdmODIiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJaV00wTm1NNFl6UXRNakk0TlMwME1qZzJMVGcyWXpndFl6UXlNamcxWmpJNE5qVTIiLCJhdWQiOlsiZ20tYXBpLXNlcnZlciIsInJlbGlkLXZlcmlmeS1zZXJ2ZXIiLCJ1c2VyLWFwaS1zZXJ2ZXIiXSwibmJmIjoxNzQyODk5ODA5LCJzY29wZSI6ImFsbCIsImlzcyI6Imh0dHBzOi8vYXV0aC5yZWxpZC5jb20iLCJleHAiOjE3NzQ0MzU4MDksImlhdCI6MTc0Mjg5OTgwOSwianRpIjoiNGVhYTE2NjMtMDQwYi00ZTEzLWI4YzAtMThlODg4NjJjMmE1IiwiY2xpZW50X2lkIjoiWldNME5tTTRZelF0TWpJNE5TMDBNamcyTFRnMll6Z3RZelF5TWpnMVpqSTROalUyIiwidXNlcm5hbWUiOiJaV00wTm1NNFl6UXRNakk0TlMwME1qZzJMVGcyWXpndFl6UXlNamcxWmpJNE5qVTIifQ.EwsmjoAfYz9XqSejzMlalpuHtZQqR6mvvm5PcG711lxJoLcVJqbYq8R6yeGJ4hNYouslDYhQi2YK7yqf4pAmL9cSlvjp4rD2wAiioLOBzIxKA9YJh5S-hbOuswZuZjg_cGmFM9VFAdq8UFiQA8dXMovDmnZLbl4KO6pILBvdAUIHQ1ngXwpJlcb6CJO6ZStldB-BjhylxkGC3RWQYan_8WKbsK8BlJnZz0IXU9U8v71f67NAXKklaA178pxwHdMSNhx1SPB20sqf26ZktAzYFudtR0XbWTzNDmjvaDrpzCQxETzAg8utcI_LRZOtyjrS_KWAzs1Kdd1pqPB0GPqW-Q";

    static final String CLIENT_ID = "ZWM0NmM4YzQtMjI4NS00Mjg2LTg2YzgtYzQyMjg1ZjI4NjU2";

    static final String CLIENT_SECRET = "84e5ebba87db4d821c650961f27e558908583c51b9ef5b2ab5ea6eddc8ff637a";

    static final String RVN_GENERATE_URL = "https://10.24.115.23:8007/generateRVN.htm";

    //static final String RVN_GENERATE_URL = "https://indus2fa.indusind.com:8007/generateRVN.htm";

    //static final String RVN_STATUS_URL = "https://indus2fa.indusind.com:8007/getRVNStatus.htm";

    static final String RVN_STATUS_URL = "https://10.24.115.23:8007/getRVNStatus.htm";

    @Value("${relid.enterprise.id}")
    private String enterpriseId;

    @Value("${relid.auth.token}")
    private String authToken;

    @Value("${relid.client.id}")
    private String clientId;

    @Value("${relid.client.secret}")
    private String clientSecret;

    @Value("${relid.rvn.generate}")
    private String rvnGenerateUrl;

    @Value("${relid.rvn.status}")
    private String rvnStatusUrl;


    private static final Logger log = LoggerFactory.getLogger(RELID_2FA_Auth.class);

    public String validate2FA(String userId) {
        String tmpToken = UUID.randomUUID().toString();
        Integer rvnResponseCode = Integer.valueOf(1);
        String errorCode = "";
        String errorMsg = "";
        String test = "0";
        if ("0".equals(test)) {
            log.info("RELID_2FA_Auth: Two factor authentication : start");
            log.info("RELID_2FA_Auth: Token received is " + tmpToken);
            try {
                String jsonInput = "{ msg_id:'" + tmpToken + "', enterprise_id:'" + enterpriseId + "', user_id:'" + userId.toUpperCase() +
                        "', expires_in:" + EXPIRES_IN + ", notification_msg:{ message:'You have a REL-IDverify notification', subject:'REL-IDverify notification' }, msg:[ { lng:'English', subject:'Login Attempt', message:'You are attempting to login to EGOV', label:{ 'Accept':'Approve', 'Reject':'Disapprove' } } ], actions:[ { label:'Accept', action:'Approved' },  { label:'Reject', action:'Disapproved' }]}";
                log.info("RELID_2FA_Auth : JSON for TwoFA -->" + jsonInput);
                URL rvnGenerateURL = new URL(rvnGenerateUrl);
                HttpURLConnection con = (HttpURLConnection)rvnGenerateURL.openConnection();
                log.info("RELID_2FA_Auth : con-->" + con);
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/json");
                con.setRequestProperty("Authorization", "Bearer "+authToken);
                OutputStream os = con.getOutputStream();
                os.write(jsonInput.getBytes());
                os.flush();
                int httpResponseCode = con.getResponseCode();
                log.info("RELID_2FA_Auth : Sending 'POST' request to URL : "+ rvnGenerateUrl);
                log.info("RELID_2FA_Auth : Connection Response : " + httpResponseCode);
                if (httpResponseCode != 200)
                    throw new RuntimeException("RELID_2FA_Auth : Failed : HTTP error code : " + httpResponseCode);
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuffer rvnResponse = new StringBuffer();
                String inputLine;
                while ((inputLine = in.readLine()) != null)
                    rvnResponse.append(inputLine);
                in.close();
                log.info("RELID_2FA_Auth : rvnResponse :" + rvnResponse.toString());
                ObjectMapper mapper = new ObjectMapper();
                JsonNode jnode = mapper.readTree(rvnResponse.toString());
                rvnResponseCode = Integer.valueOf(jnode.get("response_code").asInt());
                con.disconnect();
                log.info("RELID_2FA_Auth : RelRvnResponse Response Code : " + rvnResponseCode);
                if (rvnResponseCode.intValue() == 1) {
                    errorCode = jnode.get("error_code").asText();
                    errorMsg = jnode.get("error_message").asText();
                } else {
                    this.relRvnResponse = (RelRvnResponse)mapper.readValue(rvnResponse.toString(), RelRvnResponse.class);
                    log.info("RELID_2FA_Auth : mapped RelRvnResponse : " + this.relRvnResponse.toString());
                    log.info("RELID_2FA_Auth : RelRvnResponse notification uuid : " + this.relRvnResponse.getNotification_uuid());
                    log.info("RELID_2FA_Auth : User status : " + this.relRvnResponse.getUser_status());
                    if (this.relRvnResponse.getUser_status().equals("ACTIVE")) {
                        URL rvnStatusURL = new URL(rvnStatusUrl + "/" + this.relRvnResponse.getNotification_uuid());
                        int i = 0;
                        while (i < 13) {
                            log.info("RELID_2FA_Auth : Getting Notification Status : " + i);
                            HttpURLConnection conn = null;
                            conn = (HttpURLConnection)rvnStatusURL.openConnection();
                            conn.setRequestMethod("GET");
                            conn.setRequestProperty("Authorization", "Bearer "+authToken);
                            conn.setRequestProperty("Accept", "application/json");
                            conn.setConnectTimeout(5000);
                            i++;
                            log.info("RELID_2FA_Auth : RVN Status Connection Response : " + conn.getResponseCode());
                            if (conn.getResponseCode() != 200)
                                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
                            BufferedReader br = null;
                            br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            StringBuffer rvnStatusRes = null;
                            rvnStatusRes = new StringBuffer();
                            while ((inputLine = br.readLine()) != null)
                                rvnStatusRes.append(inputLine);
                            br.close();
                            conn.disconnect();
                            log.info("RELID_2FA_Auth :RelRvnStatusResponse Response :" + rvnStatusRes.toString());
                            JsonNode jStatusnode = mapper.readTree(rvnStatusRes.toString());
                            rvnResponseCode = Integer.valueOf(jStatusnode.get("response_code").asInt());
                            log.info("RELID_2FA_Auth : RelRvnStatusResponse Response code: " + rvnResponseCode);
                            if (rvnResponseCode.intValue() == 1) {
                                errorCode = jnode.get("error_code").asText();
                                errorMsg = jnode.get("error_message").asText();
                            } else {
                                this.relRvnStatusResponse = (RelRvnStatusResponse)mapper.readValue(rvnStatusRes.toString(), RelRvnStatusResponse.class);
                                log.info("RELID_2FA_Auth : RelRvnStatusResponse Notification Status: " + this.relRvnStatusResponse.getStatus());
                                if (this.relRvnStatusResponse.getStatus().equals("EXPIRED")) {
                                    rvnResponseCode = Integer.valueOf(1);
                                    errorCode = "IBL002";
                                    errorMsg = "Notification Expired";
                                    break;
                                }
                                if (this.relRvnStatusResponse.getAction_response().equals("Disapproved")) {
                                    rvnResponseCode = Integer.valueOf(1);
                                    errorCode = "IBL003";
                                    errorMsg = "User rejected Request";
                                    break;
                                }
                                if (this.relRvnStatusResponse.getAction_response().equals("Approved")) {
                                    rvnResponseCode = Integer.valueOf(0);
                                    return "success";
                                }
                            }
                            Thread.sleep(5000L);
                        }
                    } else {
                        rvnResponseCode = Integer.valueOf(1);
                        errorCode = "IBL004";
                        errorMsg = "User not Active";
                    }
                }
            } catch (Exception e) {
                log.info("Error while performing 2FA : " + e.getMessage());
                log.error("Exception stacktrace: ",e);
            } finally {
                log.info("RELID_2FA_Auth : errorCode : " + errorCode);
                log.info("RELID_2FA_Auth : errorMsg : " + errorMsg);
            }
        }
        return "fail";
    }
}

