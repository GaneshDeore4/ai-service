-- Table: public.login_session

-- DROP TABLE IF EXISTS public.login_session;

CREATE TABLE IF NOT EXISTS public.login_session
(
    session_id character varying(255) COLLATE pg_catalog."default" NOT NULL,
    cif_id_abbv_name character varying(50) COLLATE pg_catalog."default",
    created_at timestamp(6) with time zone NOT NULL,
    device_info character varying(512) COLLATE pg_catalog."default",
    expiry_time timestamp(6) with time zone NOT NULL,
    ip_address character varying(45) COLLATE pg_catalog."default",
    last_activity_time timestamp(6) with time zone NOT NULL,
    login_id character varying(50) COLLATE pg_catalog."default",
    login_time timestamp(6) with time zone NOT NULL,
    session_status character varying(20) COLLATE pg_catalog."default" NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    user_id character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT login_session_pkey PRIMARY KEY (session_id),
    CONSTRAINT login_session_session_status_check CHECK (session_status::text = ANY (ARRAY['ACTIVE'::character varying, 'EXPIRED'::character varying, 'TERMINATED'::character varying]::text[]))
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.login_session
    OWNER to postgres;
-- Index: idx_login_session_status

-- DROP INDEX IF EXISTS public.idx_login_session_status;

CREATE INDEX IF NOT EXISTS idx_login_session_status
    ON public.login_session USING btree
    (session_status COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;
-- Index: idx_login_session_user_id

-- DROP INDEX IF EXISTS public.idx_login_session_user_id;

CREATE INDEX IF NOT EXISTS idx_login_session_user_id
    ON public.login_session USING btree
    (user_id COLLATE pg_catalog."default" ASC NULLS LAST)
    TABLESPACE pg_default;