package com.indusind.trade.session.audit;
 
import com.indusind.trade.session.entity.AuditLogEntity;
import com.indusind.trade.session.repository.AuditLogRepository;
import com.indusind.trade.session.config.SessionProperties;
//import com.indusind.trade.model.common.security.EncryptionUtil;
import org.springframework.stereotype.Service;
 
import java.time.Instant;
 
@Service
public class AuditLogService {
 
    private final AuditLogRepository auditLogRepository;
    private final SessionProperties sessionProperties;

 
//    public AuditLogService(AuditLogRepository auditLogRepository) {
//        this.auditLogRepository = auditLogRepository;
//    }
    public AuditLogService(AuditLogRepository auditLogRepository, SessionProperties sessionProperties) {
        this.auditLogRepository = auditLogRepository;
        this.sessionProperties = sessionProperties;
    }
 
//    public void record(UUID sessionId, Long userId, String apiName, String action, String status, String entityId) {
//        record(sessionId, userId, apiName, action, status, entityId, null, null);
//    }
    public void record(String sessionId, String userId, String apiName, String action, String status, String entityId) {
        record(sessionId, userId, apiName, action, status, entityId, null, null, null, null);
    }

//    public void record(UUID sessionId, Long userId, String apiName, String action, String status, String entityId, UUID makerSessionId, UUID checkerSessionId) {
//        Instant now = Instant.now();
//        AuditLogEntity log = AuditLogEntity.builder()
//                .sessionId(sessionId)
//                .userId(userId)
//                .apiName(apiName)
//                .serviceName("session-service")
//                .action(action)
//                .entityId(entityId)
//                .status(status)
//                .makerSessionId(makerSessionId)
//                .checkerSessionId(checkerSessionId)
//                .requestTime(now)
//                .responseTime(now)
//                .build();
//        auditLogRepository.save(log);
//    }
    public void record(String sessionId, String userId, String apiName, String action, String status, String entityId,
                       String makerSessionId, String checkerSessionId, String payload, String remarks) {
        Instant now = Instant.now();
        
        String encryptedPayload = null;
       /* if (payload != null && !payload.isEmpty()) {
            encryptedPayload = EncryptionUtil.encrypt(payload, sessionProperties.getAuditEncryptionSecret());
        }*/

        AuditLogEntity log = AuditLogEntity.builder()
                .sessionId(sessionId)
                .userId(userId)
                .apiName(apiName)
                .serviceName("session-service")
                .action(action)
                .entityId(entityId)
                .status(status)
                .makerSessionId(makerSessionId)
                .checkerSessionId(checkerSessionId)
                .payload(encryptedPayload)
                .remarks(remarks)
                .requestTime(now)
                .responseTime(now)
                .build();
        auditLogRepository.save(log);
    }
}
