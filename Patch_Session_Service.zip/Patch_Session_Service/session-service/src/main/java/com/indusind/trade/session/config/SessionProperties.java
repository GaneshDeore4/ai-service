package com.indusind.trade.session.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "session")
public class SessionProperties {
    private boolean terminatePreviousActiveSession = true;
    private int maxActiveSessions = 1;
    private long idleTimeoutMinutes = 5;
    private long absoluteTimeoutHours = 8;
    private long continueGraceMinutes = 2;
//    private Jwt jwt = new Jwt();
    private Jwt jwt = new Jwt();
    private String auditEncryptionSecret = "IndusIndTradeSecretKey_32ByteKey"; // 32 characters


    @Data
    public static class Jwt {
        private String secret;
        private long expiryMinutes = 30;
    }
}
