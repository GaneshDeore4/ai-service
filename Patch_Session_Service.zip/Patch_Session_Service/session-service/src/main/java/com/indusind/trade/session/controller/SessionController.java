package com.indusind.trade.session.controller;

import com.indusind.trade.session.dto.*;
import com.indusind.trade.session.service.SessionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/session")
@RequiredArgsConstructor
public class SessionController {

    private final SessionService sessionService;

    @PostMapping("/create")
    public ResponseEntity<SessionCreateResponse> create(@Valid @RequestBody SessionCreateRequest request) {
        return ResponseEntity.ok(sessionService.createSession(request));
    }

    @GetMapping("/validate")
    public ResponseEntity<SessionValidateResponse> validate(@RequestParam("session_id") String sessionId) {
        return ResponseEntity.ok(sessionService.validateSession(sessionId));
    }

    @PostMapping("/logout")
    public ResponseEntity<SessionActionResponse> logout(@Valid @RequestBody SessionLogoutRequest request) {
        return ResponseEntity.ok(sessionService.logout(request));
    }

    @PostMapping("/refresh")
    public ResponseEntity<SessionActionResponse> refresh(@Valid @RequestBody SessionRefreshRequest request) {
        return ResponseEntity.ok(sessionService.refresh(request));
    }

    @PostMapping("/force-logout")
    public ResponseEntity<SessionActionResponse> forceLogout(@Valid @RequestBody SessionForceLogoutRequest request) {
        return ResponseEntity.ok(sessionService.forceLogout(request));
    }


    @GetMapping("/history")
    public List<SessionHistoryResponse>
    getSessionHistory(@RequestParam("userId") String userId) {

        return sessionService.getSessionHistory(userId);
    }


    @GetMapping("/has-active")
    public boolean hasActiveSession(@RequestParam("userId") String userId) {
        return sessionService.hasActiveSession(userId);
    }


}
