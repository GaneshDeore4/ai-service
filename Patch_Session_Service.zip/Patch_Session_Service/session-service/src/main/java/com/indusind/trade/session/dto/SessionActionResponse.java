package com.indusind.trade.session.dto;

import lombok.Builder;
import lombok.Value;


@Value
@Builder
public class SessionActionResponse {
    String sessionId;
    String message;
    String token;
}
