package com.indusind.trade.session.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SessionCreateRequest {
    @NotNull
    private String userId;
    private String ipAddress;
    private String deviceInfo;
    private String loginId;
}
