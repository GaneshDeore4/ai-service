package com.indusind.trade.session.dto;

import com.indusind.trade.session.enums.SessionStatus;
import lombok.Builder;
import lombok.Value;

import java.time.Instant;

@Value
@Builder
public class SessionCreateResponse {
    String sessionId;
    String userId;
    SessionStatus sessionStatus;
    Instant loginTime;
    Instant expiryTime;
    String token;
}
