package com.indusind.trade.session.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;


@Data
public class SessionForceLogoutRequest {
    private String sessionId;
    private String userId;
    @NotNull
    private Long adminUserId;
    private String reason;
}
