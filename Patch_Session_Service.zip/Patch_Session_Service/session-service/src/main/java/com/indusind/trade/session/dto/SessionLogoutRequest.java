package com.indusind.trade.session.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SessionLogoutRequest {
    @NotNull
    private String sessionId;
    private String reason;
}
