package com.indusind.trade.session.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
public class SessionRefreshRequest {
    @NotNull
    private String sessionId;
}
