package com.indusind.trade.session.dto;

import com.indusind.trade.session.enums.SessionStatus;
import lombok.Builder;
import lombok.Value;

import java.time.Instant;

@Value
@Builder
public class SessionValidateResponse {
    boolean valid;
    String message;
    String sessionId;
    String userId;
    SessionStatus sessionStatus;
    Instant expiryTime;
    String token;
}
