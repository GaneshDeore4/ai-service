package com.indusind.trade.session.entity;

/**
 * DEPRECATED: Use com.indusind.trade.model.entities.session.AuditLogEntity instead.
 */
@Deprecated
public class AuditLog {}
