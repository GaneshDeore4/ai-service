package com.indusind.trade.session.entity;
 
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
 
import java.time.Instant;
 
@Entity
@Table(name = "session_audit_log", indexes = {
        @Index(name = "idx_audit_log_user_id", columnList = "user_id"),
        @Index(name = "idx_audit_log_session_id", columnList = "session_id")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLogEntity {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "audit_id")
    private Long id;
 
    @Column(name = "session_id")
    private String sessionId;
 
    @Column(name = "user_id")
    private String userId;
 
    @Column(name = "maker_session_id")
    private String makerSessionId;
 
    @Column(name = "checker_session_id")
    private String checkerSessionId;
 
    @Column(name = "api_name", length = 100)
    private String apiName;
 
    @Column(name = "service_name", length = 50)
    private String serviceName;
 
    @Column(name = "action", length = 50)
    private String action;
 
    @Column(name = "entity_id", length = 100)
    private String entityId;
 
    @Column(name = "status", length = 20)
    private String status;
 
    @Column(name = "request_time")
    private Instant requestTime;
 
    @Column(name = "response_time")
    private Instant responseTime;

    @Lob
    @Column(name = "payload")
    private String payload;

    @Column(name = "remarks", length = 500)
    private String remarks;

    @Column(name = "client_ip", length = 45)
    private String clientIp;

    @Column(name = "device_info", length = 512)
    private String deviceInfo;
}
