package com.indusind.trade.session.entity;

/**
 * DEPRECATED: Use com.indusind.trade.model.enums.SessionStatus instead.
 */
@Deprecated
public enum SessionStatus {
    ACTIVE, EXPIRED, TERMINATED
}
