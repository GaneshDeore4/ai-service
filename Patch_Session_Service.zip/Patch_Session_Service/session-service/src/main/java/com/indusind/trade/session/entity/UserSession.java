package com.indusind.trade.session.entity;
 
import com.indusind.trade.session.enums.SessionStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
 
import java.time.Instant;
 
@Entity
@Table(name = "login_session", indexes = {
        @Index(name = "idx_login_session_user_id", columnList = "user_id"),
        @Index(name = "idx_login_session_status", columnList = "session_status")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserSession {
 
    @Id
    @Column(name = "session_id", nullable = false, updatable = false)
    private String sessionId;
 
    @Column(name = "user_id", nullable = false)
    private String userId;
 
    @Column(name = "login_time", nullable = false, updatable = false)
    private Instant loginTime;
 
    @Column(name = "last_activity_time", nullable = false)
    private Instant lastActivityTime;
 
    @Column(name = "expiry_time", nullable = false)
    private Instant expiryTime;
 
    @Enumerated(EnumType.STRING)
    @Column(name = "session_status", nullable = false, length = 20)
    private SessionStatus sessionStatus;
 
    @Column(name = "ip_address", length = 45)
    private String ipAddress;
 
    @Column(name = "device_info", length = 512)
    private String deviceInfo;
 
    @Column(name = "login_id", length = 50)
    private String loginId;
 
    @Column(name = "cif_id_abbv_name", length = 50)
    private String cifIdAbbvName;
 
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
 
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;
 
    @PrePersist
    private void onCreate() {
        Instant now = Instant.now();
        if (createdAt == null) {
            createdAt = now;
        }
        if (updatedAt == null) {
            updatedAt = now;
        }
    }
 
    @PreUpdate
    private void onUpdate() {
        updatedAt = Instant.now();
    }
}
