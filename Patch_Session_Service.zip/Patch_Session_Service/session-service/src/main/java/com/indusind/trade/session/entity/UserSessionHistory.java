package com.indusind.trade.session.entity;

/**
 * DEPRECATED: Use com.indusind.trade.model.entities.session.UserSessionHistoryEntity instead.
 */
@Deprecated
public class UserSessionHistory {}
