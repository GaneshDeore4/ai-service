package com.indusind.trade.session.entity;
 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
 
import java.time.Instant;
 
@Entity
@Table(name = "login_session_history", indexes = {
        @Index(name = "idx_session_history_user_id", columnList = "user_id"),
        @Index(name = "idx_session_history_session_id", columnList = "session_id")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserSessionHistoryEntity {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
 
    @Column(name = "session_id", nullable = false)
    private String sessionId;
 
    @Column(name = "user_id", nullable = false)
    private String userId;
 
    @Column(name = "login_time")
    private Instant loginTime;
 
    @Column(name = "logout_time")
    private Instant logoutTime;
 
    @Column(name = "logout_reason", length = 100)
    private String logoutReason;
 
    @Column(name = "ip_address", length = 45)
    private String ipAddress;
 
    @Column(name = "device_info", length = 512)
    private String deviceInfo;
}
