package com.indusind.trade.session.enums;

public enum SessionStatus {
    ACTIVE,
    EXPIRED,
    TERMINATED
}
