package com.indusind.trade.session.repository;
 
import com.indusind.trade.session.entity.UserSession;
import com.indusind.trade.session.enums.SessionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import java.util.List;
import java.util.Optional;
 
@Repository
public interface MasterUserSessionRepository extends JpaRepository<UserSession, String> {
    
    List<UserSession> findByUserIdOrderByLoginTimeDesc(String userId);
    
    List<UserSession> findByLoginIdAndCifIdAbbvNameAndSessionStatus(String loginId, String cifIdAbbvName, SessionStatus sessionStatus);
    
    List<UserSession> findByLoginIdAndCifIdAbbvNameOrderByLoginTimeDesc(String loginId, String cifIdAbbvName);
    
    Optional<UserSession> findFirstByUserIdAndSessionStatusOrderByLoginTimeDesc(String userId, SessionStatus status);
    
    List<UserSession> findByUserIdAndSessionStatusOrderByLoginTimeAsc(String userId, SessionStatus status);
}
