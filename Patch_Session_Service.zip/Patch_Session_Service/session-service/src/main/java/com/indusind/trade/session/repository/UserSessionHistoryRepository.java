package com.indusind.trade.session.repository;
 
import com.indusind.trade.session.entity.UserSessionHistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;
 
@Repository
public interface UserSessionHistoryRepository extends JpaRepository<UserSessionHistoryEntity, Long> {


    List<UserSessionHistoryEntity>
    findByUserIdOrderByLoginTimeDesc(String userId);


}
