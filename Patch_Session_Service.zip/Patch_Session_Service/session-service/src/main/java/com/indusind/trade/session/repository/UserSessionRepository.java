package com.indusind.trade.session.repository;
 
/**
 * DELETED: This local repository is no longer used. session-service now uses MasterUserSessionRepository from app-model.
 */
public interface UserSessionRepository {
}
