package com.indusind.trade.session.security;

import com.indusind.trade.session.config.SessionProperties;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.UUID;

@Service
public class JwtService {

    private final SessionProperties sessionProperties;

    public JwtService(SessionProperties sessionProperties) {
        this.sessionProperties = sessionProperties;
    }

    public String generateSessionToken(String sessionId, String userId, String loginId) {
        Instant now = Instant.now();
        Instant expiry = now.plus(sessionProperties.getJwt().getExpiryMinutes(), ChronoUnit.MINUTES);
        SecretKey key = Keys.hmacShaKeyFor(sessionProperties.getJwt().getSecret().getBytes(StandardCharsets.UTF_8));

        return Jwts.builder()
                .setSubject(String.valueOf(userId))
                .claim("userId", userId)
                .claim("session_id", sessionId)
                .claim("login_id", loginId)
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(expiry))
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }
}
