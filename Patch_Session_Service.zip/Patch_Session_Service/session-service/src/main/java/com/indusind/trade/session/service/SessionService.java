package com.indusind.trade.session.service;

import com.indusind.trade.session.dto.*;

import java.util.List;


public interface SessionService {
    SessionCreateResponse createSession(SessionCreateRequest request);
    SessionValidateResponse validateSession(String sessionId);
    SessionActionResponse logout(SessionLogoutRequest request);
    SessionActionResponse refresh(SessionRefreshRequest request);
    SessionActionResponse forceLogout(SessionForceLogoutRequest request);
    List<SessionHistoryResponse> getSessionHistory(String userId);
    boolean hasActiveSession(String userId);
}
