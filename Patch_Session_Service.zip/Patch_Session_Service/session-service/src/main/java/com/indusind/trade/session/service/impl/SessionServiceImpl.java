package com.indusind.trade.session.service.impl;

import com.indusind.trade.session.audit.AuditLogService;
import com.indusind.trade.session.config.SessionProperties;
import com.indusind.trade.session.dto.*;
import com.indusind.trade.session.entity.UserSession;
import com.indusind.trade.session.entity.UserSessionHistoryEntity;
import com.indusind.trade.session.enums.SessionStatus;
import com.indusind.trade.session.repository.MasterUserSessionRepository;
import com.indusind.trade.session.repository.UserSessionHistoryRepository;
import com.indusind.trade.session.exception.SessionConflictException;
import com.indusind.trade.session.exception.SessionNotFoundException;
import com.indusind.trade.session.security.JwtService;
import com.indusind.trade.session.service.SessionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SessionServiceImpl implements SessionService {

    private final MasterUserSessionRepository userSessionRepository;
    private final UserSessionHistoryRepository userSessionHistoryRepository;
    private final AuditLogService auditLogService;
    private final JwtService jwtService;
    private final SessionProperties sessionProperties;

    @Override
    @Transactional
    public SessionCreateResponse createSession(SessionCreateRequest request) {
        enforceConcurrentSessionPolicy(request.getUserId());

        Instant now = Instant.now();
        UserSession session = UserSession.builder()
                .sessionId(java.util.UUID.randomUUID().toString())
                .userId(request.getUserId())
                .loginTime(now)
                .lastActivityTime(now)
                .expiryTime(now.plus(sessionProperties.getIdleTimeoutMinutes(), ChronoUnit.MINUTES))
                .sessionStatus(SessionStatus.ACTIVE)
                .ipAddress(request.getIpAddress())
                .deviceInfo(request.getDeviceInfo())
                .loginId(request.getLoginId())
                .build();
        UserSession saved = userSessionRepository.save(session);

        userSessionHistoryRepository.save(UserSessionHistoryEntity.builder()
                .sessionId(saved.getSessionId())
                .userId(saved.getUserId())
                .loginTime(saved.getLoginTime())
                .ipAddress(saved.getIpAddress())
                .deviceInfo(saved.getDeviceInfo())
                .build());

        String token = jwtService.generateSessionToken(saved.getSessionId(), saved.getUserId(), saved.getLoginId());
        auditLogService.record(saved.getSessionId(), saved.getUserId(), "/session/create", "CREATE", "SUCCESS", saved.getSessionId());

        return SessionCreateResponse.builder()
                .sessionId(saved.getSessionId())
                .userId(saved.getUserId())
                .sessionStatus(saved.getSessionStatus())
                .loginTime(saved.getLoginTime())
                .expiryTime(saved.getExpiryTime())
                .token(token)
                .build();
    }

    @Override
    @Transactional
    public SessionValidateResponse validateSession(String sessionId) {
        UserSession session = fetchOrThrow(sessionId);
        Instant now = Instant.now();
        Instant absoluteExpiry = session.getLoginTime().plus(sessionProperties.getAbsoluteTimeoutHours(), ChronoUnit.HOURS);
        Instant idleExpiry = session.getExpiryTime();

        if (now.isAfter(absoluteExpiry)) {
            expireSession(session, now, "SESSION_EXPIRED_ABSOLUTE");
            auditLogService.record(session.getSessionId(), session.getUserId(), "/session/validate", "VALIDATE", "SESSION_EXPIRED", session.getSessionId());
            return invalidResponse(session, "SESSION_EXPIRED");
        }

        if (now.isAfter(idleExpiry)) {
            Instant graceCutoff = idleExpiry.plus(sessionProperties.getContinueGraceMinutes(), ChronoUnit.MINUTES);
            if (!now.isAfter(graceCutoff)) {
                session.setSessionStatus(SessionStatus.ACTIVE);
                session.setLastActivityTime(now);
                session.setExpiryTime(now.plus(sessionProperties.getIdleTimeoutMinutes(), ChronoUnit.MINUTES));
                userSessionRepository.save(session);
//                String token = jwtService.generateSessionToken(session.getSessionId(), session.getUserId());
                String token = jwtService.generateSessionToken(session.getSessionId(), session.getUserId(), session.getLoginId());
                auditLogService.record(session.getSessionId(), session.getUserId(), "/session/validate", "VALIDATE", "SESSION_CONTINUED", session.getSessionId());
                return SessionValidateResponse.builder()
                        .valid(true)
                        .message("SESSION_CONTINUED")
                        .sessionId(session.getSessionId())
                        .userId(session.getUserId())
                        .sessionStatus(session.getSessionStatus())
                        .expiryTime(session.getExpiryTime())
                        .token(token)
                        .build();
            }

            expireSession(session, now, "SESSION_EXPIRED");
            auditLogService.record(session.getSessionId(), session.getUserId(), "/session/validate", "VALIDATE", "SESSION_EXPIRED", session.getSessionId());
            return invalidResponse(session, "SESSION_EXPIRED");
        }

        if (session.getSessionStatus() != SessionStatus.ACTIVE) {
            return invalidResponse(session, "SESSION_INVALID");
        }
        session.setLastActivityTime(now);
        session.setExpiryTime(now.plus(sessionProperties.getIdleTimeoutMinutes(), ChronoUnit.MINUTES));
        userSessionRepository.save(session);
        auditLogService.record(session.getSessionId(), session.getUserId(), "/session/validate", "VALIDATE", "VALID", session.getSessionId());
        return SessionValidateResponse.builder()
                .valid(true)
                .message("VALID")
                .sessionId(session.getSessionId())
                .userId(session.getUserId())
                .sessionStatus(session.getSessionStatus())
                .expiryTime(session.getExpiryTime())
                .build();
    }

    @Override
    @Transactional
    public SessionActionResponse logout(SessionLogoutRequest request) {
        UserSession session = fetchOrThrow(request.getSessionId());
        session.setSessionStatus(SessionStatus.TERMINATED);
        userSessionRepository.save(session);

        userSessionHistoryRepository.save(UserSessionHistoryEntity.builder()
                .sessionId(session.getSessionId())
                .userId(session.getUserId())
                .loginTime(session.getLoginTime())
                .logoutTime(Instant.now())
                .logoutReason(request.getReason() == null ? "USER_LOGOUT" : request.getReason())
                .ipAddress(session.getIpAddress())
                .deviceInfo(session.getDeviceInfo())
                .build());
        auditLogService.record(session.getSessionId(), session.getUserId(), "/session/logout", "LOGOUT", "SUCCESS", session.getSessionId());

        return SessionActionResponse.builder()
                .sessionId(session.getSessionId())
                .message("Session logged out successfully")
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public SessionActionResponse refresh(SessionRefreshRequest request) {
        UserSession session = fetchOrThrow(request.getSessionId());
        if (session.getSessionStatus() != SessionStatus.ACTIVE || session.getExpiryTime().isBefore(Instant.now())) {
            throw new SessionConflictException("Session is not active for refresh");
        }
//        String token = jwtService.generateSessionToken(session.getSessionId(), session.getUserId());
        String token = jwtService.generateSessionToken(session.getSessionId(), session.getUserId(), session.getLoginId());
        return SessionActionResponse.builder()
                .sessionId(session.getSessionId())
                .message("Token refreshed")
                .token(token)
                .build();
    }

    @Override
    @Transactional
    public SessionActionResponse forceLogout(SessionForceLogoutRequest request) {
        if (request.getSessionId() == null && request.getUserId() == null) {
            throw new SessionConflictException("Either sessionId or userId is required");
        }

        Instant now = Instant.now();
        String reason = request.getReason() == null
                ? "FORCE_LOGOUT_BY_ADMIN_" + request.getAdminUserId()
                : request.getReason();

        if (request.getSessionId() != null) {
            UserSession session = fetchOrThrow(request.getSessionId());
            terminateSessionWithHistory(session, reason, now);
            auditLogService.record(session.getSessionId(), session.getUserId(), "/session/force-logout", "FORCE_LOGOUT", "SUCCESS", session.getSessionId());
            return SessionActionResponse.builder()
                    .sessionId(session.getSessionId())
                    .message("Session force-logged out")
                    .build();
        }

        List<UserSession> activeSessions = userSessionRepository
                .findByUserIdAndSessionStatusOrderByLoginTimeAsc(request.getUserId(), SessionStatus.ACTIVE);
        for (UserSession session : activeSessions) {
            terminateSessionWithHistory(session, reason, now);
            auditLogService.record(session.getSessionId(), session.getUserId(), "/session/force-logout", "FORCE_LOGOUT", "SUCCESS", session.getSessionId());
        }
        return SessionActionResponse.builder()
                .sessionId(activeSessions.isEmpty() ? null : activeSessions.get(0).getSessionId())
                .message("Force-logout completed for user")
                .build();
    }

    private UserSession fetchOrThrow(String sessionId) {
        return userSessionRepository.findById(sessionId)
                .orElseThrow(() -> new SessionNotFoundException(sessionId));
    }

    private void enforceConcurrentSessionPolicy(String userId) {
        List<UserSession> activeSessions = userSessionRepository
                .findByUserIdAndSessionStatusOrderByLoginTimeAsc(userId, SessionStatus.ACTIVE);

        int maxActiveSessions = Math.max(1, sessionProperties.getMaxActiveSessions());
        if (activeSessions.size() < maxActiveSessions) {
            return;
        }

        if (!sessionProperties.isTerminatePreviousActiveSession()) {
            throw new SessionConflictException("Active session limit reached for user: " + userId);
        }

        int sessionsToTerminate = (activeSessions.size() - maxActiveSessions) + 1;
        Instant now = Instant.now();
        for (int i = 0; i < sessionsToTerminate; i++) {
            UserSession active = activeSessions.get(i);
            terminateSessionWithHistory(active, "NEW_LOGIN", now);
            auditLogService.record(active.getSessionId(), active.getUserId(), "/session/create", "TERMINATE_EXISTING", "SUCCESS", active.getSessionId());
        }
    }

    private void terminateSessionWithHistory(UserSession session, String reason, Instant logoutTime) {
        session.setSessionStatus(SessionStatus.TERMINATED);
        userSessionRepository.save(session);
        userSessionHistoryRepository.save(UserSessionHistoryEntity.builder()
                .sessionId(session.getSessionId())
                .userId(session.getUserId())
                .loginTime(session.getLoginTime())
                .logoutTime(logoutTime)
                .logoutReason(reason)
                .ipAddress(session.getIpAddress())
                .deviceInfo(session.getDeviceInfo())
                .build());
    }

    private SessionValidateResponse invalidResponse(UserSession session, String message) {
        return SessionValidateResponse.builder()
                .valid(false)
                .message(message)
                .sessionId(session.getSessionId())
                .userId(session.getUserId())
                .sessionStatus(session.getSessionStatus())
                .expiryTime(session.getExpiryTime())
                .build();
    }

    private void expireSession(UserSession session, Instant logoutTime, String reason) {
        session.setSessionStatus(SessionStatus.EXPIRED);
        userSessionRepository.save(session);
        userSessionHistoryRepository.save(UserSessionHistoryEntity.builder()
                .sessionId(session.getSessionId())
                .userId(session.getUserId())
                .loginTime(session.getLoginTime())
                .logoutTime(logoutTime)
                .logoutReason(reason)
                .ipAddress(session.getIpAddress())
                .deviceInfo(session.getDeviceInfo())
                .build());
    }


    @Transactional(readOnly = true)
    public List<SessionHistoryResponse> getSessionHistory(String userId) {

        return userSessionHistoryRepository
                .findByUserIdOrderByLoginTimeDesc(userId)
                .stream()
                .map(h -> SessionHistoryResponse.builder()
                        .sessionId(h.getSessionId())
                        .userId(h.getUserId())
                        .loginTime(h.getLoginTime())
                        .logoutTime(h.getLogoutTime())
                        .logoutReason(h.getLogoutReason())
                        .sessionStatus(
                                h.getLogoutTime() == null ? "ACTIVE" : "TERMINATED"
                        )
                        .ipAddress(h.getIpAddress())
                        .deviceInfo(h.getDeviceInfo())
                        .build())
                .toList();
    }


    @Transactional(readOnly = true)
    public boolean hasActiveSession(String userId) {

        return !userSessionRepository
                .findByUserIdAndSessionStatusOrderByLoginTimeAsc(
                        userId,
                        SessionStatus.ACTIVE
                )
                .isEmpty();
    }


}
