-- Session Service PostgreSQL schema
-- No request/response body payloads are stored.

CREATE TABLE IF NOT EXISTS login_session (
    session_id UUID PRIMARY KEY,
    user_id BIGINT NOT NULL,
    login_time TIMESTAMPTZ NOT NULL,
    last_activity_time TIMESTAMPTZ NOT NULL,
    expiry_time TIMESTAMPTZ NOT NULL,
    session_status VARCHAR(20) NOT NULL CHECK (session_status IN ('ACTIVE','EXPIRED','TERMINATED')),
    ip_address VARCHAR(45),
    device_info VARCHAR(512),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_login_session_user_id ON login_session (user_id);
CREATE INDEX IF NOT EXISTS idx_login_session_session_id ON login_session (session_id);
CREATE INDEX IF NOT EXISTS idx_login_session_user_status ON login_session (user_id, session_status);

CREATE TABLE IF NOT EXISTS login_session_history (
    id BIGSERIAL PRIMARY KEY,
    session_id UUID NOT NULL,
    user_id BIGINT NOT NULL,
    login_time TIMESTAMPTZ NOT NULL,
    logout_time TIMESTAMPTZ,
    logout_reason VARCHAR(128),
    ip_address VARCHAR(45),
    device_info VARCHAR(512)
);

CREATE INDEX IF NOT EXISTS idx_login_session_history_session_id ON login_session_history (session_id);
CREATE INDEX IF NOT EXISTS idx_login_session_history_user_id ON login_session_history (user_id);

CREATE OR REPLACE FUNCTION deny_login_session_history_update_delete()
RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'login_session_history is append-only';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_login_session_history_no_update ON login_session;
CREATE TRIGGER trg_login_session_history_no_update
BEFORE UPDATE ON login_session_history
FOR EACH ROW
EXECUTE FUNCTION deny_login_session_history_update_delete();

DROP TRIGGER IF EXISTS trg_login_session_history_no_delete ON login_session_history;
CREATE TRIGGER trg_user_session_history_no_delete
BEFORE DELETE ON login_session_history
FOR EACH ROW
EXECUTE FUNCTION deny_user_session_history_update_delete();

CREATE TABLE IF NOT EXISTS session_audit_log (
    audit_id BIGSERIAL PRIMARY KEY,
    session_id UUID NOT NULL,
    user_id BIGINT NOT NULL,
    api_name VARCHAR(100),
    service_name VARCHAR(100),
    action VARCHAR(64),
    entity_id VARCHAR(100),
    status VARCHAR(32),
    request_time TIMESTAMPTZ,
    response_time TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_session_audit_log_session_id ON session_audit_log (session_id);
CREATE INDEX IF NOT EXISTS idx_session_audit_log_user_id ON session_audit_log (user_id);
