import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionMappingMasterComponent } from './action-mapping-master.component';

describe('ActionMappingMasterComponent', () => {
  let component: ActionMappingMasterComponent;
  let fixture: ComponentFixture<ActionMappingMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ActionMappingMasterComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActionMappingMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
