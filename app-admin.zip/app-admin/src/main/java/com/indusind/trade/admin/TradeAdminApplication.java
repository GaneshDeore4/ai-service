package com.indusind.trade.admin;

import com.indusind.trade.admin.config.BankSeedProperties;
import com.indusind.trade.admin.config.BaseWidgetSeedProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"com.indusind.trade.*","com.indusind.trade.admin", "com.indusind.trade.model", "com.indusind.trade.model.common"})
@EnableConfigurationProperties({BaseWidgetSeedProperties.class, BankSeedProperties.class})
@EnableJpaRepositories({"com.indusind.trade.model.repository"})
@EntityScan({"com.indusind.trade.model.entities"})
@EnableDiscoveryClient
@EnableFeignClients
@EnableJpaAuditing
public class TradeAdminApplication {

    public static void main(String[] args) {
        SpringApplication.run(TradeAdminApplication.class, args);
    }

}
