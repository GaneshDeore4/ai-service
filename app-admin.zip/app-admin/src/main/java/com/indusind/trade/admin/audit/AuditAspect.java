package com.indusind.trade.admin.audit;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Method;
import java.net.InetAddress;

/**
 * AOP Aspect that intercepts methods annotated with {@link Auditable}.
 * Captures WHO/WHAT/WHEN/WHERE/WHY and delegates to {@link AuditService}.
 */
@Aspect
@Component
@RequiredArgsConstructor
@Slf4j
public class AuditAspect {

    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    @Around("@annotation(com.indusind.trade.admin.audit.Auditable)")
    public Object auditMethod(ProceedingJoinPoint joinPoint) throws Throwable {

        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        Auditable auditable = method.getAnnotation(Auditable.class);

        // ── WHO ────────────────────────────────────────
        String loginId = null;
        String roleName = null;
        String userType = "USER";
        Long companyId = null;
        String sessionId = null;

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated()) {
            loginId = auth.getName();
        }

        // Pull enriched claims stored by JwtValidationFilter as request attributes
        HttpServletRequest httpRequest = currentRequest();
        String ipAddress = null;
        String correlationId = null;
        String hostname = resolveHostname();

        if (httpRequest != null) {
            roleName = (String) httpRequest.getAttribute("currentRole");
            sessionId = (String) httpRequest.getAttribute("currentSessionId");
            Object cid = httpRequest.getAttribute("currentCompanyId");
            companyId = cid != null ? ((Number) cid).longValue() : null;
            ipAddress = httpRequest.getRemoteAddr();
            correlationId = httpRequest.getHeader("X-Correlation-ID");
        }

        // ── CAPTURE OLD VALUE (best-effort, from method args) ──
        String oldValue = null;
        // For updates that have a single object or ID arg, try to serialize first arg
        if (joinPoint.getArgs().length > 0 && joinPoint.getArgs()[0] != null) {
            try {
                oldValue = objectMapper.writeValueAsString(joinPoint.getArgs()[0]);
            } catch (Exception ignored) {
                /* non-serializable arg */ }
        }

        Object result = null;
        String outcome = "SUCCESS";
        String errorMsg = null;

        try {
            result = joinPoint.proceed();
        } catch (Throwable ex) {
            outcome = "FAILURE";
            errorMsg = ex.getMessage();
            throw ex;
        } finally {
            // ── CAPTURE NEW VALUE (from return value) ──
            String newValue = null;
            if (result != null) {
                try {
                    newValue = objectMapper.writeValueAsString(result);
                } catch (Exception ignored) {
                    /* non-serializable return */ }
            }

            // ── RESOURCE ID (try to extract from return) ──
            String resourceId = extractId(result);

            AuditEvent event = AuditEvent.builder()
                    .action(auditable.action())
                    .resourceType(auditable.resourceType())
                    .resourceId(resourceId)
                    .module(auditable.module())
                    .performedBy(loginId)
                    .roleName(roleName)
                    .userType(userType)
                    .companyId(companyId)
                    .ipAddress(ipAddress)
                    .serviceName("admin-service")
                    .hostname(hostname)
                    .outcome(outcome)
                    .errorMessage(errorMsg)
                    .oldValue(oldValue)
                    .newValue(newValue)
                    .sessionId(sessionId)
                    .correlationId(correlationId)
                    .build();

            auditService.log(event);
        }
        return result;
    }

    private HttpServletRequest currentRequest() {
        try {
            ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            return attrs.getRequest();
        } catch (Exception e) {
            return null;
        }
    }

    private String resolveHostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "unknown";
        }
    }

    private String extractId(Object result) {
        if (result == null)
            return null;
        try {
            // Reflectively try getId() on the returned object
            java.lang.reflect.Method getId = result.getClass().getMethod("getId");
            Object id = getId.invoke(result);
            return id != null ? id.toString() : null;
        } catch (Exception ignored) {
            return null;
        }
    }
}
