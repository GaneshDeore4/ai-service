package com.indusind.trade.admin.audit;

import com.indusind.trade.model.entities.master.AuditLog;
import com.indusind.trade.model.repository.AuditRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

/**
 * AuditController — READ-ONLY audit trail APIs.
 * All endpoints require a valid JWT (enforced by JwtValidationFilter +
 * SecurityConfig).
 * Write operations on audit are NOT exposed here — records are append-only via
 * AuditService.
 */
@RestController
@RequestMapping("/api/audit")
@RequiredArgsConstructor
public class AuditController {

    private final AuditRepository auditRepository;

    /** Full log for a specific user */
    @GetMapping("/user/{loginId}")
    public ResponseEntity<List<AuditLog>> getByUser(@PathVariable String loginId) {
        return ResponseEntity.ok(auditRepository.findByPerformedByOrderByTimestampDesc(loginId));
    }

    /** All events for a specific action code (e.g., LOGIN, DELETE) */
    @GetMapping("/action/{action}")
    public ResponseEntity<List<AuditLog>> getByAction(@PathVariable String action) {
        return ResponseEntity.ok(auditRepository.findByActionOrderByTimestampDesc(action));
    }

    /**
     * Full history for a specific resource (e.g., resourceType=User,
     * resourceId=USR001)
     */
    @GetMapping("/resource/{resourceType}/{resourceId}")
    public ResponseEntity<List<AuditLog>> getByResource(
            @PathVariable String resourceType,
            @PathVariable String resourceId) {
        return ResponseEntity.ok(
                auditRepository.findByResourceTypeAndResourceIdOrderByTimestampDesc(resourceType, resourceId));
    }

    /** All events for a specific session */
    @GetMapping("/session/{sessionId}")
    public ResponseEntity<List<AuditLog>> getBySession(@PathVariable String sessionId) {
        return ResponseEntity.ok(auditRepository.findBySessionIdOrderByTimestampDesc(sessionId));
    }

    /** Time-range query — ISO-8601 instants */
    @GetMapping("/range")
    public ResponseEntity<List<AuditLog>> getByTimeRange(
            @RequestParam String from,
            @RequestParam String to) {
        Instant fromInstant = Instant.parse(from);
        Instant toInstant = Instant.parse(to);
        return ResponseEntity.ok(auditRepository.findByTimestampBetweenOrderByTimestampDesc(fromInstant, toInstant));
    }

    /** All events for a business module (e.g., USER, COMPANY, RBAC) */
    @GetMapping("/module/{module}")
    public ResponseEntity<List<AuditLog>> getByModule(@PathVariable String module) {
        return ResponseEntity.ok(auditRepository.findByModuleOrderByTimestampDesc(module));
    }
}
