package com.indusind.trade.admin.audit;

import com.indusind.trade.model.entities.master.AuditLog;
import com.indusind.trade.model.repository.AuditRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * Centralized Audit Service — APPEND-ONLY.
 * Persists AuditLog records asynchronously in a separate transaction
 * so audit writes never block or roll back with business transactions.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AuditService {

    private final AuditRepository auditRepository;

    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(AuditEvent event) {
        try {
            AuditLog entry = AuditLog.builder()
                    // WHO
                    .performedBy(event.getPerformedBy())
                    .roleName(event.getRoleName())
                    .userType(event.getUserType())
                    .companyId(event.getCompanyId())
                    // WHAT
                    .action(event.getAction())
                    .resourceType(event.getResourceType())
                    .resourceId(event.getResourceId())
                    .module(event.getModule())
                    // WHEN
                    .timestamp(LocalDateTime.now())
                    // WHERE
                    .ipAddress(event.getIpAddress())
                    .serviceName(event.getServiceName())
                    .hostname(event.getHostname())
                    // WHY
                    .outcome(event.getOutcome())
                    .reason(event.getReason())
                    .errorMessage(event.getErrorMessage())
                    // CHANGE DATA
                    .oldValue(event.getOldValue())
                    .newValue(event.getNewValue())
                    // CORRELATION
                    .sessionId(event.getSessionId())
                    .correlationId(event.getCorrelationId())
                    .build();

            auditRepository.save(entry);

        } catch (Exception e) {
            // Audit failure must NEVER break business flow
            log.error("CRITICAL: Failed to persist audit log for action={} user={}: {}",
                    event.getAction(), event.getPerformedBy(), e.getMessage());
        }
    }
}
