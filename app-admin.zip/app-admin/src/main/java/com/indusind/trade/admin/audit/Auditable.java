package com.indusind.trade.admin.audit;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Decorate any service method with @Auditable to automatically capture
 * a before/after audit trail via {@link AuditAspect}.
 *
 * Example:
 * 
 * <pre>
 *   {@literal @}Auditable(action = "CREATE", resourceType = "User", module = "USER")
 *   public UserDTO createUser(CreateUserRequest req) { ... }
 * </pre>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Auditable {

    /** Action code: CREATE, UPDATE, DELETE, APPROVE, REJECT, etc. */
    String action();

    /** Resource type: User, Company, Role, RemittanceTxn, etc. */
    String resourceType() default "";

    /** Business module: USER, COMPANY, RBAC, REMITTANCE, etc. */
    String module() default "";
}
