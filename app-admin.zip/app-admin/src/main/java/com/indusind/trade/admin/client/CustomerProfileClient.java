package com.indusind.trade.admin.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.indusind.trade.model.dtos.requestdtos.CustomerProfileRequestDto;
import com.indusind.trade.model.dtos.response.dtos.CompanyProfileResponseDto;

@FeignClient(name = "CustomerProfileClient", url = "${app.feign.customer.profile.info-url}")
public interface CustomerProfileClient {

    @PostMapping("/customerenquiry/cifid/V1")
    CompanyProfileResponseDto fetchCustomerProfile(
            @RequestHeader("IBL-Client-ID") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody CustomerProfileRequestDto request
    );
}
