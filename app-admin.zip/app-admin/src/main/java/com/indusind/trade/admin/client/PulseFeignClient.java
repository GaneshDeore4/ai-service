package com.indusind.trade.admin.client;

import com.indusind.trade.model.dtos.response.dtos.PulseDetailsResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "pulseFeignClient", url = "${pulse.service.url}")
public interface PulseFeignClient {

    @PostMapping
    public PulseDetailsResponseDto getPulseDeatilsByPulseId(@RequestHeader("IBL-Client-ID") String clientId,
                                                            @RequestHeader("IBL-Client-Secret") String clientSecret, @RequestBody String pulseId);
}
