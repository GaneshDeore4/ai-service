package com.indusind.trade.admin.config;

import com.indusind.audit.filters.AuditHeaderFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

@Configuration
public class AuditFilterConfig {

    @Bean
    public FilterRegistrationBean<AuditHeaderFilter> auditFilter() {
        FilterRegistrationBean<AuditHeaderFilter> bean =
                new FilterRegistrationBean<>();

        bean.setFilter(new AuditHeaderFilter());
        bean.addUrlPatterns("/*");
        bean.setOrder(Ordered.HIGHEST_PRECEDENCE);

        return bean;
    }
}