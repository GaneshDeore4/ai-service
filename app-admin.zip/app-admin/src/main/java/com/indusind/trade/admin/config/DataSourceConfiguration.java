package com.indusind.trade.admin.config;

import com.indusind.trade.model.utility.CryptoUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfiguration {

    @Value("${datasource.url}")
    private String dbUrl;

    @Value("${datasource.username}")
    private String encryptedUsername;

    @Value("${datasource.password}")
    private String encryptedPassword;

    @Value("${datasource.driver-class-name}")
    private String driverClassName;

    @Bean
    public DataSource dataSource() throws Exception {
        return DataSourceBuilder.create()
                .url(dbUrl)
                .username(encryptedUsername)
                .password(encryptedPassword)
                // .username(CryptoUtils.decrypt(encryptedUsername))
                // .password(CryptoUtils.decrypt(encryptedPassword))
                .driverClassName(driverClassName)
                .build();
    }

}
