package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.ActionFacde;
import com.indusind.trade.model.dtos.requestdtos.ActionDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/action")
@RequiredArgsConstructor
public class ActionController {

    private final ActionFacde actionFacde;

    @PostMapping("/saveAction")
    public ResponseEntity<ApplicationResponse> saveAction(@RequestBody ActionDto actionDto) {
        ApplicationResponse response = actionFacde.saveAction(actionDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/updateAction")
    public ResponseEntity<ApplicationResponse> updateAction(@RequestBody ActionDto actionDto) {
        ApplicationResponse response = actionFacde.saveAction(actionDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllActions")
    public ResponseEntity<ApplicationResponse> getAllActions(@PageableDefault(page = 0, size = 10, sort = "actionName") Pageable pageable) {
        ApplicationResponse response = actionFacde.getAllActions(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllActions/all")
    public ResponseEntity<ApplicationResponse> getAllActions() {
        ApplicationResponse response = actionFacde.getAllActions(null);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getActionById")
    public ResponseEntity<ApplicationResponse> getActionById(@RequestParam Long actionId) {
        ApplicationResponse response = actionFacde.getActionById(actionId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
