package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.BankProfileFacade;
import com.indusind.trade.model.dtos.requestdtos.BankProfileRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bankprofile")
@RequiredArgsConstructor
public class BankProfileController {

    private final BankProfileFacade bankProfileFacade;

    @PostMapping("/saveBankProfile")
    public ResponseEntity<ApplicationResponse> saveBankProfile(@RequestBody BankProfileRequestDto bankProfileRequestDto){
        ApplicationResponse response = bankProfileFacade.saveBankProfile(bankProfileRequestDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveBankProfile")
    public ResponseEntity<ApplicationResponse> approveBankProfile(@RequestParam Long bankProfileId){
        ApplicationResponse response = bankProfileFacade.approveBankProfile(bankProfileId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectBankProfile")
    public ResponseEntity<ApplicationResponse> rejectCompanyTemp(@RequestParam Long bankProfileId) {
        ApplicationResponse response = bankProfileFacade.rejectBankTemp(bankProfileId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTempBanks")
    public ResponseEntity<ApplicationResponse> getAllTempBanks(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = bankProfileFacade.getAllTempBanks(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllBanks")
    public ResponseEntity<ApplicationResponse> getAllBanks(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = bankProfileFacade.getAllBanks(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getBankTempById")
    public ResponseEntity<ApplicationResponse> getBankTempById(@RequestParam Long bankProfileId) {
        ApplicationResponse response = bankProfileFacade.getBankTempById(bankProfileId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getBankById")
    public ResponseEntity<ApplicationResponse> getBankById(@RequestParam Long bankProfileId) {
        ApplicationResponse response = bankProfileFacade.getBankById(bankProfileId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

}
