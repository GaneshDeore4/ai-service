package com.indusind.trade.admin.controller;


import com.indusind.trade.admin.facade.BankUserFacade;
import com.indusind.trade.model.dtos.requestdtos.BankUserRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bankuser")
@RequiredArgsConstructor
public class BankUserController {

    private final BankUserFacade bankUserFacade;

    @PostMapping("/saveBankUser")
    public ResponseEntity<ApplicationResponse> saveBankUser(@RequestBody BankUserRequestDto bankUserRequestDto){
        ApplicationResponse response = bankUserFacade.saveBankUserTemp(bankUserRequestDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveBankUser")
    public ResponseEntity<ApplicationResponse> approveBankUser(@RequestParam Long bankUserId){
        ApplicationResponse response = bankUserFacade.approveBankUser(bankUserId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectBankUser")
    public ResponseEntity<ApplicationResponse> rejectCompanyTemp(@RequestParam Long bankUserId) {
        ApplicationResponse response = bankUserFacade.rejectBankUser(bankUserId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTempBankUsers")
    public ResponseEntity<ApplicationResponse> getAllTempBankUsers(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = bankUserFacade.getAllTempBankUsers(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllBankUsers")
    public ResponseEntity<ApplicationResponse> getAllBankUsers(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = bankUserFacade.getAllBankUsers(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getBankUserTempById")
    public ResponseEntity<ApplicationResponse> getBankUserTempById(@RequestParam Long id) {
        ApplicationResponse response = bankUserFacade.getBankUserTempById(id);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getBankUserById")
    public ResponseEntity<ApplicationResponse> getBankUserById(@RequestParam Long id) {
        ApplicationResponse response = bankUserFacade.getBankUserById(id);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTempBankUsersByBankProfileId")
    public ResponseEntity<ApplicationResponse> getTempBankUsersByBankId(@RequestParam Long bankProfileId, @PageableDefault(page = 0, size = 10) Pageable pageable){
        ApplicationResponse response = bankUserFacade.getTempBankUsersByBankId(bankProfileId, pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getBankUsersByBankProfileId")
    public ResponseEntity<ApplicationResponse> getBankUsersByBankId(@RequestParam Long bankProfileId, @PageableDefault(page = 0, size = 10) Pageable pageable){
        ApplicationResponse response = bankUserFacade.getBankUsersByBankId(bankProfileId, pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }



}
