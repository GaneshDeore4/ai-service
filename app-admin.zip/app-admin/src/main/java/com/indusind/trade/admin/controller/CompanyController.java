package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.CompanyFacade;
import com.indusind.trade.model.dtos.requestdtos.CompanyRequestDto;
import com.indusind.trade.model.dtos.requestdtos.CustomerProfileRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/company")
@RequiredArgsConstructor
public class CompanyController {


    private final CompanyFacade companyFacade;

    @PostMapping("/saveCompanyDetails")
    public ResponseEntity<ApplicationResponse> saveCompany(@RequestBody CompanyRequestDto companyDto) {
        ApplicationResponse response = companyFacade.saveCompanyTemp(companyDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveCompany")
    public ResponseEntity<ApplicationResponse> approveCompanyTemp(@RequestParam Long companyId) {
        ApplicationResponse response = companyFacade.approveCompanyTemp(companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectCompany")
    public ResponseEntity<ApplicationResponse> rejectCompanyTemp(@RequestParam Long companyId) {
        ApplicationResponse response = companyFacade.rejectCompanyTemp(companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTempCompanies")
    public ResponseEntity<ApplicationResponse> getAllTempCompanies(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = companyFacade.getAllTempCompanies(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

//    @GetMapping("/getAllTempCompaniesByCategory")
//    public ResponseEntity<ApplicationResponse> getAllTempCompaniesByCategory(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable, @RequestParam Long categoryId) {
//        ApplicationResponse response = companyFacade.getAllTempCompaniesByCategory(pageable, categoryId);
//        return ResponseEntity.status(HttpStatus.OK).body(response);
//    }
//
//    @GetMapping("/getAllCompaniesByCategory")
//    public ResponseEntity<ApplicationResponse> getAllCompaniesByCategory(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable, @RequestParam Long categoryId) {
//        ApplicationResponse response = companyFacade.getAllCompaniesByCategory(pageable, categoryId);
//        return ResponseEntity.status(HttpStatus.OK).body(response);
//    }

    //
    @GetMapping("/getAllCompanies")
    public ResponseEntity<ApplicationResponse> getAllCompanies(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = companyFacade.getAllCompanies(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getCompanyTempById")
    public ResponseEntity<ApplicationResponse> getCompanyTemp(@RequestParam Long companyId) {
        ApplicationResponse response = companyFacade.getCompanyTempById(companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getCompanyById")
    public ResponseEntity<ApplicationResponse> getCompany(@RequestParam Long companyId) {
        ApplicationResponse response = companyFacade.getCompanyById(companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProdSubProdMapByCompanyTemp")
    public ResponseEntity<ApplicationResponse> getProdSubProdMapByCompanyTemp(@RequestParam Long companyId) {
        ApplicationResponse response = companyFacade.getProdSubProdMapByCompanyTemp(companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProdSubProdMapByCompany")
    public ResponseEntity<ApplicationResponse> getProdSubProdMapByCompany(@RequestParam Long companyId) {
        ApplicationResponse response = companyFacade.getProdSubProdMapByCompany(companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/fetchCompanyByCif")
    public ResponseEntity<ApplicationResponse> getCustomerProfileByCif(@RequestParam Long cifId){
        ApplicationResponse response = companyFacade.fetchCustomerProfileByCifId(cifId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }


}


