package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.DepartmentFacade;
import com.indusind.trade.model.dtos.requestdtos.DepartmentRequestDto;
import com.indusind.trade.model.dtos.requestdtos.DepartmentToUserTypeMappingRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/department")
@RequiredArgsConstructor
public class DepartmentController {

    private final DepartmentFacade departmentFacade;

    @GetMapping("/getAllDepartments")
    public ResponseEntity<ApplicationResponse> getAllDepartments() {
        ApplicationResponse response = departmentFacade.getAllDepartments();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/createDepartment")
    public ResponseEntity<ApplicationResponse> createDepartment(@RequestBody DepartmentRequestDto request) {
        ApplicationResponse response = departmentFacade.createDepartment(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/mapUserType")
    public ResponseEntity<ApplicationResponse> mapuserTypes(@RequestBody DepartmentToUserTypeMappingRequestDto request) {
        ApplicationResponse response = departmentFacade.mapUserTypesWithDepartment(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

}
