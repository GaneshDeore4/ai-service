package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.GuidelineFacade;
import com.indusind.trade.model.dtos.requestdtos.GuidelineRequestDto;
import com.indusind.trade.model.dtos.requestdtos.NotificationRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/guideline")
@RequiredArgsConstructor
public class GuidelineController {

    private final GuidelineFacade guidelineFacade;

    @PostMapping("/addGuideline")
    public ResponseEntity<ApplicationResponse> saveGuideline(@RequestBody GuidelineRequestDto guidelineRequestDto){
        ApplicationResponse response = guidelineFacade.saveGuideline(guidelineRequestDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllGuidelines")
    public ResponseEntity<ApplicationResponse> getAllGuidelines(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable){
        ApplicationResponse response = guidelineFacade.getAllGuidelines(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getClientGuidelineById")
    public ResponseEntity<ApplicationResponse> getGuidelineById(@RequestParam Long guidelineId){
        ApplicationResponse response = guidelineFacade.getGuidelineById(guidelineId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getGuidelineById")
    public ResponseEntity<ApplicationResponse> getTempGuidelineById(@RequestParam Long guidelineId){
        ApplicationResponse response = guidelineFacade.getGuidelineTempById(guidelineId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/deleteGuidelineById")
    public ResponseEntity<ApplicationResponse> deleteNotificationById(@RequestParam Long guidelineId){
        ApplicationResponse response = guidelineFacade.deleteGuidelineById(guidelineId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllClientGuidelines")
    public ResponseEntity<ApplicationResponse> getAllClientGuideline(@PageableDefault(page = 0, size = 10, sort = "createdDate", direction = Sort.Direction.DESC) Pageable pageable){
        ApplicationResponse response = guidelineFacade.getAllGuidelinesClient(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveGuideline")
    public ResponseEntity<ApplicationResponse> approveGuideline(@RequestParam Long guidelineId){
        ApplicationResponse response = guidelineFacade.approveGuideline(guidelineId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectGuideline")
    public ResponseEntity<ApplicationResponse> rejectGuideline(@RequestParam Long guidelineId){
        ApplicationResponse response = guidelineFacade.rejectGuideline(guidelineId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/toggleGuideline")
    public ResponseEntity<ApplicationResponse> toggleGuideline(@RequestParam Long guidelineId, @RequestBody GuidelineRequestDto guidelineRequestDto){
        ApplicationResponse response = guidelineFacade.toggleGuideline(guidelineRequestDto, guidelineId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
