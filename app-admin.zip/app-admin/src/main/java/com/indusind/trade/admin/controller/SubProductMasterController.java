package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.SubProductMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.SubProductMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/subproduct")
@RequiredArgsConstructor
public class SubProductMasterController {

    private final SubProductMasterFacade subProductMasterFacade;

    @PostMapping("/saveSubProduct")
    public ResponseEntity<ApplicationResponse> saveSubProduct(@RequestBody SubProductMasterDto subProductMasterDto) {
        ApplicationResponse response = subProductMasterFacade.saveSubProduct(subProductMasterDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/updateSubProduct")
    public ResponseEntity<ApplicationResponse> updateSubProduct(@RequestBody SubProductMasterDto subProductMasterDto) {
        ApplicationResponse response = subProductMasterFacade.saveSubProduct(subProductMasterDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllSubProducts")
    public ResponseEntity<ApplicationResponse> getAllSubProducts(
            @PageableDefault(page = 0, size = 10, sort = "subProductName") Pageable pageable) {
        ApplicationResponse response = subProductMasterFacade.getAllSubProducts(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllSubProducts/all")
    public ResponseEntity<ApplicationResponse> getAllSubProducts() {
        ApplicationResponse response = subProductMasterFacade.getAllSubProducts(null);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getSubProduct")
    public ResponseEntity<ApplicationResponse> getSubProduct(@RequestParam Long subProductId) {
        ApplicationResponse response = subProductMasterFacade.getSubProductById(subProductId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTabsBySubProductId")
    public ResponseEntity<ApplicationResponse> getTabsBySubProductId(@RequestParam Long subProductId) {
        ApplicationResponse response = subProductMasterFacade.getTabsBySubProduct(subProductId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

}
