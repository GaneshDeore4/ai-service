package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.TabMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.TabMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/master")
public class TabMasterController {

    private final TabMasterFacade tabMasterFacade;

    @PostMapping("/addTab")
    public ResponseEntity<ApplicationResponse> addTabMaster(@Valid @RequestBody TabMasterDto tabMasterDto) {
        ApplicationResponse response = tabMasterFacade.addTabMaster(tabMasterDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTabs")
    public ResponseEntity<ApplicationResponse> getAllTabMaster(@PageableDefault(page = 0, size = 10) Pageable pageable) {
        ApplicationResponse response = tabMasterFacade.getAllTabMaster(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTab")
    public ResponseEntity<ApplicationResponse> getTabById(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.getTabById(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/updateTab")
    public ResponseEntity<ApplicationResponse> updateTab(@RequestParam Long tabId, @Valid @RequestBody TabMasterDto tabMasterDto) {
        ApplicationResponse response = tabMasterFacade.updateTabMaster(tabId, tabMasterDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/deleteTab")
    public ResponseEntity<ApplicationResponse> deleteTabMaster(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.deleteTabMaster(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProdSubProdMappingForTab")
    public ResponseEntity<ApplicationResponse> getProdSubProdMappingForTab(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.getProdSubProdMappingForTab(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

}
