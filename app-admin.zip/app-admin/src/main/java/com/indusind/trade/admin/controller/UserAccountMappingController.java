package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.UserAccountMappingFacade;
import com.indusind.trade.model.dtos.requestdtos.AddUserAccountMappingGroupedRequestDto;
import com.indusind.trade.model.dtos.requestdtos.AddUserAccountMappingRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/account_mapping")
@RequiredArgsConstructor
public class UserAccountMappingController {

    private final UserAccountMappingFacade userAccountMappingFacade;

    @GetMapping("/account-details-cif")
    public ResponseEntity<ApplicationResponse> getAccountDetailsByCifId(@RequestParam String cifId) {
        ApplicationResponse response = userAccountMappingFacade.getAccountsByCifId(cifId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/user-account-mapping")
    public ResponseEntity<ApplicationResponse> addUserAccountMapping(
            @RequestBody AddUserAccountMappingRequestDto request
    ) {
        ApplicationResponse response = userAccountMappingFacade.addUserAccountMapping(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/user-account-mapping-grouped")
    public ResponseEntity<ApplicationResponse> addUserAccountMappingGrouped(
            @RequestBody AddUserAccountMappingGroupedRequestDto request
    ) {
        ApplicationResponse response = userAccountMappingFacade.addBulkUserAccountMapping(request.getMappingRequest());
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/account-details-userId")
    public ResponseEntity<ApplicationResponse> getAccountDetailsByUserId(@RequestParam Long userId) {
        ApplicationResponse response = userAccountMappingFacade.getAccountsByUserId(userId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
