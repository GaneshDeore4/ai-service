package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.MyAccessFacade;
import com.indusind.trade.admin.facade.UserFacade;
import com.indusind.trade.model.dtos.requestdtos.UserDTO;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class UserController {

    private final UserFacade userFacade;

    private final MyAccessFacade myAccessFacade;

    @PostMapping("/submitUser")
    public ResponseEntity<ApplicationResponse> submitUser(@RequestBody UserDTO userDTO) {
        ApplicationResponse response = userFacade.saveUserTemp(userDTO);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveUser")
    public ResponseEntity<ApplicationResponse> authoriseUser(@RequestParam Long userId) {
        ApplicationResponse response = userFacade.approveUser(userId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTempUsersByCompanyId")
    public ResponseEntity<ApplicationResponse> getTempUsersByCompanyId(@RequestParam Long companyId, @PageableDefault(page = 0, size = 10) Pageable pageable){
        ApplicationResponse response = userFacade.getTempUsersByCompanyId(companyId, pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getUsersByCompanyId")
    public ResponseEntity<ApplicationResponse> getUsersByCompanyId(@RequestParam Long companyId, @PageableDefault(page = 0, size = 10) Pageable pageable){
        ApplicationResponse response = userFacade.getUsersByCompanyId(companyId, pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllUsers")
    public ResponseEntity<ApplicationResponse> getAllUsers(@PageableDefault(page = 0, size = 10, sort = "created", direction = Sort.Direction.DESC) Pageable pageable){
        ApplicationResponse response = userFacade.getAllUsers(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTempUsers")
    public ResponseEntity<ApplicationResponse> getAllTempUsers(@PageableDefault(page = 0, size = 10, sort = "created", direction = Sort.Direction.DESC) Pageable pageable){
        ApplicationResponse response = userFacade.getAllTempUsers(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @RequestMapping("/rejectUser")
    public ResponseEntity<ApplicationResponse> rejectUser(@RequestParam Long userId){
        ApplicationResponse response = userFacade.rejectUserTemp(userId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getUserById")
    public ResponseEntity<ApplicationResponse> getUserById(@RequestParam Long userId){
        ApplicationResponse response = userFacade.getUserById(userId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTempUserById")
    public ResponseEntity<ApplicationResponse> getTempUserById(@RequestParam Long userId){
        ApplicationResponse response = userFacade.getUserTempById(userId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping(value = "/myaccess")
    public ResponseEntity<ApplicationResponse> getMyAccess(@RequestParam Long userId) {
        ApplicationResponse response = myAccessFacade.getMyAccess(userId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getPulseDetailsByPulseId")
    public ResponseEntity<ApplicationResponse> getPulseDetailsByPulseId(@RequestParam String pulseId){
        ApplicationResponse response = userFacade.getPulseDetailsByPulseId(pulseId);
        return ResponseEntity.status(HttpStatus.OK).body(response);

    }

}
