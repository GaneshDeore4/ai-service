package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.UserTypeTabActionMappingFacade;
import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingRequestDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingRequestGetDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/usertype-tab-action")
@RequiredArgsConstructor
public class UserTypeTabActionMappingController {

    private final UserTypeTabActionMappingFacade userTypeTabActionMappingFacade;

    @PostMapping("/addMapping")
    public ResponseEntity<ApplicationResponse> addMapping(
            @RequestBody UserTypeTabActionMappingRequestDto userTypeTabActionMappingDto) {
        ApplicationResponse response = userTypeTabActionMappingFacade.addMapping(userTypeTabActionMappingDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/getMappingByTabIds")
    public ResponseEntity<ApplicationResponse> getMappingByTabIds(@RequestBody UserTypeTabActionMappingRequestGetDto dto) {
        ApplicationResponse response = userTypeTabActionMappingFacade.getMapping(dto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/getAllUserTypeMapping")
    public ResponseEntity<ApplicationResponse> getMappingAllUserTypes(@RequestBody UserTypeTabActionMappingRequestGetDto dto){
        ApplicationResponse response = userTypeTabActionMappingFacade.getInitialMapping(dto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }



}
