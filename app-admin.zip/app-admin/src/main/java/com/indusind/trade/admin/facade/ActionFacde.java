package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.ActionDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface ActionFacde {
    ApplicationResponse saveAction(ActionDto actionDto);

    ApplicationResponse getAllActions(Pageable pageable);

    ApplicationResponse getActionById(Long actionId);
}
