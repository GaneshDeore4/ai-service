package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.BankProfileRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface BankProfileFacade {

    public ApplicationResponse saveBankProfile(BankProfileRequestDto bankProfileRequestDto);

    public ApplicationResponse approveBankProfile(Long bankProfileId);

    public ApplicationResponse getBankTempById(Long bankProfileId);

    public ApplicationResponse getBankById(Long bankProfileId);

    ApplicationResponse getAllTempBanks(Pageable pageable);

    ApplicationResponse getAllBanks(Pageable pageable);

    ApplicationResponse rejectBankTemp(Long bankProfileId);

}
