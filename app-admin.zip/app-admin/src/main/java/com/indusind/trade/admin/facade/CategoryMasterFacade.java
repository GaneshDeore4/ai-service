package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.CategoryMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface CategoryMasterFacade {

    ApplicationResponse saveCategory(CategoryMasterDto categoryMasterDto);

    ApplicationResponse getAllCategories(Pageable pageable);

    ApplicationResponse getCategoryById(Long categoryId);

    ApplicationResponse getProductsByCategoryId(Long categoryId);

    ApplicationResponse getUserTypesByCategoryId(Long categoryId);

    ApplicationResponse getAllUserTypesByCategory(String category);

    ApplicationResponse getCategoryByName(String categoryName);
}
