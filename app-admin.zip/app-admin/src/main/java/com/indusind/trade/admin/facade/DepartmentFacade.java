package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.DepartmentRequestDto;
import com.indusind.trade.model.dtos.requestdtos.DepartmentToUserTypeMappingRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;


public interface DepartmentFacade {

    ApplicationResponse getAllDepartments();

    ApplicationResponse mapUserTypesWithDepartment(DepartmentToUserTypeMappingRequestDto request);

    ApplicationResponse createDepartment(DepartmentRequestDto request);
}
