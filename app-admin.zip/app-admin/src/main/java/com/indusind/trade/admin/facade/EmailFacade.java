package com.indusind.trade.admin.facade;

import java.util.Map;

public interface EmailFacade {
    Map<String, Object> sendEmail(String toAddress, String subject, String emailContent);
}
