package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.NotificationRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface NotificationFacade {

    ApplicationResponse saveNotification(NotificationRequestDto notificationRequestDto);
    ApplicationResponse getAllNotifications(Pageable pageable);
    ApplicationResponse getNotificationById(Long id);

    ApplicationResponse getNotificationTempById(Long id);

    ApplicationResponse approveNotification(Long id);

    ApplicationResponse rejectNotification(Long id);

    ApplicationResponse toggleNotification(NotificationRequestDto notificationRequestDto, Long id);

    ApplicationResponse getAllNotificationsClient();

    ApplicationResponse deleteNotificationById(Long id);
}
