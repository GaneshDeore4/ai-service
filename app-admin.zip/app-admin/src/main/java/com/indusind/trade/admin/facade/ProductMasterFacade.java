package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.ProductMasterDto;
import com.indusind.trade.model.dtos.requestdtos.ProductMidOfficeMappingRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ProductMasterFacade{

    ApplicationResponse saveProduct(ProductMasterDto productMasterDto);

    ApplicationResponse getAllProducts(Pageable pageable);

    ApplicationResponse getAllProductsByCategoryId(Pageable pageable, Long categoryId);

    ApplicationResponse getProductById(Long productId);

    ApplicationResponse getSubProductsByProductId(Long productId);

    ApplicationResponse getSubProductsByProductList(List<Long> productIds);

    ApplicationResponse getTabsByProduct(Long productId);

    ApplicationResponse getActionsByProduct(Long productId);

    ApplicationResponse getProdSubProdMapByCategoryId(Long categoryId);

    ApplicationResponse mapProductToMidOffice(ProductMidOfficeMappingRequestDto request);
}
