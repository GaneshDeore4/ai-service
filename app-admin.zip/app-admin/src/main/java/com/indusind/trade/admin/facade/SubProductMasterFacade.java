package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.SubProductMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;
public interface SubProductMasterFacade {

    ApplicationResponse saveSubProduct(SubProductMasterDto subProductMasterDto);
    ApplicationResponse getAllSubProducts(Pageable pageable);
    ApplicationResponse getSubProductById(Long SubProductId);

    ApplicationResponse getTabsBySubProduct(Long subProductId);
}
