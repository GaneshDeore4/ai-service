package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.TabMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface TabMasterFacade {

    ApplicationResponse addTabMaster(TabMasterDto tabMasterDto);
    ApplicationResponse getAllTabMaster(Pageable pageable);
    ApplicationResponse getTabById(Long roleId);
    ApplicationResponse updateTabMaster(Long roleId, TabMasterDto tabMasterDto);
    ApplicationResponse deleteTabMaster(Long roleId);

    ApplicationResponse getProdSubProdMappingForTab(Long roleId);
}
