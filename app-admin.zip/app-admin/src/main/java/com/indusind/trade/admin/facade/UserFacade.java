package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.UserDTO;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

public interface UserFacade {

    ApplicationResponse saveUserTemp(UserDTO userDTO);

    ApplicationResponse approveUser(Long userId);

    @Transactional(rollbackFor = Exception.class)
    ApplicationResponse rejectUserTemp(Long userId);

    ApplicationResponse getUserTempById(Long userId);

    ApplicationResponse getUserById(Long userId);

    ApplicationResponse getTempUsersByCompanyId(Long companyId, Pageable pageable);

    ApplicationResponse getUsersByCompanyId(Long companyId, Pageable pageable);

    ApplicationResponse getAllUsers(Pageable pageable);

    ApplicationResponse getAllTempUsers(Pageable pageable);

    ApplicationResponse getPulseDetailsByPulseId(String pulseId);

    //ApplicationResponse rejectTempUser(Long userId);

}
