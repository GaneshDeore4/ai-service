package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface UserTypeFacade {

    ApplicationResponse saveUserType(UserTypeDto userTypeDto);

    ApplicationResponse updateUserType(UserTypeDto userTypeDto);

    ApplicationResponse getAllUserTypes(Pageable pageable);

    ApplicationResponse getUserTypeById(Long userTypeId);

}
