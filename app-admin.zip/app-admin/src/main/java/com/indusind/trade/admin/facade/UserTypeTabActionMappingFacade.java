package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.MyAccessRequestDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingRequestDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingRequestGetDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;

public interface UserTypeTabActionMappingFacade {
    ApplicationResponse addMapping(UserTypeTabActionMappingRequestDto userTypeTabActionMappingDto);

    ApplicationResponse getMapping(UserTypeTabActionMappingRequestGetDto userTypeTabActionMappingRequestGetDto);

    ApplicationResponse getMyAccess(MyAccessRequestDto request);
    ApplicationResponse getInitialMapping(UserTypeTabActionMappingRequestGetDto dto);
}
