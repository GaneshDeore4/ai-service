package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.AccountFacade;
import com.indusind.trade.model.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AccountFacadeImpl implements AccountFacade {

    private final AccountService accountService;

//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public List<AccountTemp> saveOrSubmit(List<GTPAccountTnxDto> gtpAccountDtoList, String ops) {
//        List<AccountTemp> accountTempList = new ArrayList<AccountTemp>();
//        gtpAccountDtoList.forEach(dto -> {
//            dto.setTnxId(gtpTranIdSequenceService.generateTranId(LocalDate.now()));
//            //Set bank details set
//            dto.setCheckerId(0L);
//            dto.setMakerDttm(LocalDate.now());
//            dto.setTnxTypeCode(AppConstants.NEW_TNX_TYPE_CODE);
//            dto.setTnxStatCode(StringUtils.equalsIgnoreCase(AppConstants.DRAFT_STATUS, ops) ?
//                    AppConstants.DRAFT_TNX_STATUS_CODE : AppConstants.SUBMIT_TNX_STATUS_CODE);
//            dto.setAcctName(new StringJoiner(" ")
//                    .add(dto.getCurCode())
//                    .add(dto.getAccountNo())
//                    .add(dto.getDescription())
//                    .toString());
//            accountTempList.add(accountService.saveGTPAccountTnx(GTPAccountTnxDto.convertToEntity(dto)));
//            // GTPCustomerAccount mapping
//        });
//        return accountTempList;
//    }
//
//    @Override
//    public ApplicationResponse getAccountTnx(Long accountId, String tnxId) {
//        GTPAccountTnxDto accountDto = accountService.getAccountTnx(accountId, tnxId);
//        return new ApplicationResponse("SUCCESS", accountDto, "Account fetched successfully");
//    }
//
//    @Override
//    public ApplicationResponse getAccount(Long accountId) {
//        AccountDto accountDto = accountService.getAccount(accountId);
//        return new ApplicationResponse("SUCCESS", accountDto, "Account details fetched successfully");
//    }
}
