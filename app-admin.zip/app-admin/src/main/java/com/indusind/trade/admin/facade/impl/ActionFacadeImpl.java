package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.ActionFacde;
import com.indusind.trade.model.dtos.requestdtos.ActionDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.ActionResponseDto;
import com.indusind.trade.model.entities.master.Action;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.service.ActionService;
import com.indusind.trade.model.service.ProductMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ActionFacadeImpl implements ActionFacde {

    private final ActionService actionService;

    private final ProductMasterService productMasterService;

    @Override
    public ApplicationResponse saveAction(ActionDto actionDto) {
        List<ProductMaster> productList = productMasterService.getProductsByIds(actionDto.getProductId());
        Action action = ActionDto.convertToEntity(actionDto);
        action.setProductMaster(productList);
        Action savedAction = actionService.saveAction(action);
        return new ApplicationResponse("SUCCESS",ActionDto.convertToDto(savedAction), "Action saved successfully.");
    }

    @Override
    public ApplicationResponse getAllActions(Pageable pageable) {
        if (Objects.nonNull(pageable)) {
            Page<Action> page = actionService.getAllActions(pageable);
            return new ApplicationResponse("SUCCESS", page.map(ActionResponseDto::convertToDto), "Actions fetched successfully.");
        } else {
            List<Action> actionList = actionService.getAllActions();
            List<ActionResponseDto> actionDtos = actionList.stream()
                    .map(ActionResponseDto::convertToDto)
                    .collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", actionDtos, "All Actions fetched successfully.");
        }
    }

    @Override
    public ApplicationResponse getActionById(Long actionId) {
        Action action = actionService.getActionById(actionId);
        return new ApplicationResponse("SUCCESS", ActionResponseDto.convertToDto(action), "Action fetched with id");

    }
}
