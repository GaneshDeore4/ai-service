package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.AuthGroupFacade;
import com.indusind.trade.model.dtos.requestdtos.AuthGroupDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.company.AuthGroup;
import com.indusind.trade.model.service.AuthGroupService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class AuthGroupFacadeImpl implements AuthGroupFacade {

    private final AuthGroupService authGroupService;

    @Override
    public ApplicationResponse getAuthGroups() {
        List<AuthGroup> authGroups = authGroupService.getAllAuthGroups();
        List<AuthGroupDto> authGroupDtos = authGroups.stream().map(
                AuthGroupDto::convertToDto
        ).toList();
        return new ApplicationResponse("SUCCESS", authGroupDtos, "Auth groups fetched successfully");
    }
}
