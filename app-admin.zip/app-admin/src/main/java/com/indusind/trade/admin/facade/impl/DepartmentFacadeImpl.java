package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.DepartmentFacade;
import com.indusind.trade.model.dtos.requestdtos.DepartmentRequestDto;
import com.indusind.trade.model.dtos.requestdtos.DepartmentToUserTypeMappingRequestDto;
import com.indusind.trade.model.dtos.requestdtos.DeptIdUserTypeIdDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.DepartmentDto;
import com.indusind.trade.model.entities.master.Department;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.service.DepartmentService;
import com.indusind.trade.model.service.UserTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DepartmentFacadeImpl implements DepartmentFacade {

    private final DepartmentService departmentService;
    private final UserTypeService userTypeService;

    @Override
    public ApplicationResponse getAllDepartments() {
        List<Department> depts = departmentService.getAllDepartments();

        List<DepartmentDto> deptDtos = depts.stream()
                .map(d -> {
                    DepartmentDto dto = DepartmentDto.convertToDto(d);
                    List<UserType> userTypes = d.getUserTypes();
                    List<UserTypeDto> userTypeDto = userTypes.stream()
                            .map(UserTypeDto :: convertToDto)
                            .toList();
                    dto.setUserTypes(userTypeDto);
                    return dto;
                })
                .toList();

        return new ApplicationResponse("SUCCESS", deptDtos, "departments fetched successfully");
    }

    @Override
    @Transactional
    public ApplicationResponse mapUserTypesWithDepartment(DepartmentToUserTypeMappingRequestDto request) {

        List<DeptIdUserTypeIdDto> list = request.getMapping();

        List<Department> mappingList = new ArrayList<>();

        for(DeptIdUserTypeIdDto d : list) {
            Department department = departmentService.getDepartmentById(d.getDeptId());

            List<UserType> userTypes = userTypeService.getUserTypeByIdIn(d.getUserTypeIds());

            department.setUserTypes(userTypes);

            mappingList.add(department);
        }

        departmentService.saveAll(mappingList);

        return new ApplicationResponse("SUCCESS", null, "Mapping saved successfully.");
    }

    @Override
    public ApplicationResponse createDepartment(DepartmentRequestDto request) {
        departmentService.addDepartment(request);
        return new ApplicationResponse("SUCCESS", null, "Department added successfully");
    }
}
