package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.GuidelineFacade;
import com.indusind.trade.model.dtos.requestdtos.GuidelineRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.GuidelineResponseDto;
import com.indusind.trade.model.entities.company.GuideLineTemp;
import com.indusind.trade.model.entities.company.Guideline;
import com.indusind.trade.model.entities.company.Notification;
import com.indusind.trade.model.entities.company.NotificationTemp;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.service.GuidelineService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Limit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@RequiredArgsConstructor
public class GuidelineFacadeImpl implements GuidelineFacade {

    private final GuidelineService guidelineService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse saveGuideline(GuidelineRequestDto guidelineRequestDto) {
        GuideLineTemp guideLineTemp;

        if(Objects.nonNull(guidelineRequestDto.getIsUpdate()) && guidelineRequestDto.getIsUpdate()){
            guideLineTemp = guidelineService.getGuidelineTempById(guidelineRequestDto.getGuidelineId());
            guideLineTemp = guidelineRequestDto.convertToTempEntity(guidelineRequestDto, guideLineTemp);

            //notificationService.saveNotification(notification);
        }else{
            guideLineTemp = guidelineRequestDto.convertToTempEntity(guidelineRequestDto, new GuideLineTemp());
            //notificationService.saveNotification(notification);
        }
        guideLineTemp.setStatus(Status.PENDING.toString());

        guideLineTemp.setIsActive(false);
        guidelineService.flushGuidelineTemp();
        GuideLineTemp savedGuidelineTemp = guidelineService.saveGuidelineTemp(guideLineTemp);

        return new ApplicationResponse("SUCCESS", Map.of(savedGuidelineTemp.getGuidelineId(), savedGuidelineTemp.getGuidelineTitle()), "Guideline saved successfully");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getAllGuidelines(Pageable pageable) {
        Page<GuideLineTemp> guidelinePage = guidelineService.getAllTempGuidelines(pageable);
        Page<GuidelineResponseDto> guidelineResponseDtoPage = guidelinePage.map(GuidelineResponseDto :: convertToTempDto);
        return new ApplicationResponse("SUCCESS", guidelineResponseDtoPage, "Guidelines fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getGuidelineById(Long id) {
        Guideline guideline = guidelineService.getGuidelineById(id);
        GuidelineResponseDto guidelineResponseDto = GuidelineResponseDto.convertToDto(guideline);
        return new ApplicationResponse("SUCCESS", guidelineResponseDto, "Guideline fetched.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getGuidelineTempById(Long id) {
        GuideLineTemp guideLineTemp = guidelineService.getGuidelineTempById(id);
        GuidelineResponseDto guidelineResponseDto = GuidelineResponseDto.convertToTempDto(guideLineTemp);
        return new ApplicationResponse("SUCCESS", guidelineResponseDto, "Guideline fetched.");
    }

    @Override
    public ApplicationResponse approveGuideline(Long id) {
        Guideline guideline = null;
        GuideLineTemp guideLineTemp = guidelineService.getGuidelineTempById(id);
        guideLineTemp.setStatus(Status.APPROVED.toString());
        guideLineTemp = guidelineService.saveGuidelineTemp(guideLineTemp);

        Boolean existsFlag = guidelineService.existsGuideline(id);

        if (existsFlag) {
            guideline = guidelineService.getGuidelineById(id);
            guidelineService.flushGuideline();
            guideline = GuideLineTemp.convertToMasterEntity(guideLineTemp, guideline);
        } else {
            guideline = GuideLineTemp.convertToMasterEntity(guideLineTemp, new Guideline());
        }
        Guideline guidelineSaved = guidelineService.saveGuideline(guideline);
        return new ApplicationResponse("SUCCESS", Map.of(guideLineTemp.getGuidelineId(), guideLineTemp.getGuidelineTitle()), "Notification approved");
    }

    @Override
    public ApplicationResponse rejectGuideline(Long id) {
        GuideLineTemp guidelineTempSaved = null;
        GuideLineTemp guideLineTemp = guidelineService.getGuidelineTempById(id);
        if(guidelineService.existsGuideline(id)){
            Guideline guideline = guidelineService.getGuidelineById(id);
            guideLineTemp = Guideline.convertToTempEntity(guideline, guideLineTemp);
            guideLineTemp.setStatus(Status.UPDATE_REJECTED.toString());
            guidelineTempSaved = guidelineService.saveGuidelineTemp(guideLineTemp);
        }else{
            guideLineTemp.setStatus(Status.REJECTED.toString());
            guidelineTempSaved = guidelineService.saveGuidelineTemp(guideLineTemp);
        }
        return new ApplicationResponse("SUCCESS", Map.of(guidelineTempSaved.getGuidelineId(), guidelineTempSaved.getGuidelineTitle()), "Guideline rejected");
    }

    @Override
    public ApplicationResponse toggleGuideline(GuidelineRequestDto guidelineRequestDto, Long id) {
        GuideLineTemp guideLineTemp = guidelineService.getGuidelineTempById(id);
        Boolean isActive = guidelineRequestDto.getIsActive();
        guideLineTemp.setIsActive(isActive);
        GuideLineTemp savedGuidelineTemp = guidelineService.saveGuidelineTemp(guideLineTemp);
        if(guidelineService.existsGuideline(id)){
            Guideline guideline = guidelineService.getGuidelineById(id);
            guidelineService.flushGuideline();
            guideline.setIsActive(isActive);
            guidelineService.saveGuideline(guideline);
        }
        return new ApplicationResponse("SUCCESS", Map.of(savedGuidelineTemp.getGuidelineId(), savedGuidelineTemp.getIsActive()), "Guideline toggled");
    }

    @Override
    public ApplicationResponse getAllGuidelinesClient(Pageable pageable) {
        List<Guideline> guidelinePage = guidelineService.getAllGuidelineClient();
        List<GuidelineResponseDto> guidelineResponseDtoPage = guidelinePage.stream().map(GuidelineResponseDto :: convertToDto).toList();
        return new ApplicationResponse("SUCCESS", guidelineResponseDtoPage, "Client notification fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse deleteGuidelineById(Long id) {
        GuideLineTemp guideLineTemp = guidelineService.getGuidelineTempById(id);
        guideLineTemp.setDeletedDate(LocalDateTime.now());
        if(guidelineService.existsGuideline(id)){
            Guideline guideline = guidelineService.getGuidelineById(id);
            guidelineService.flushGuideline();
            guideline.setDeletedDate(LocalDateTime.now());
            guidelineService.saveGuideline(guideline);
        }
        GuideLineTemp savedGuidelineTemp = guidelineService.saveGuidelineTemp(guideLineTemp);
        return new ApplicationResponse("SUCCESS", Map.of(savedGuidelineTemp.getGuidelineId(), savedGuidelineTemp.getGuidelineId()), "Guideline deleted successfully.");
    }
}
