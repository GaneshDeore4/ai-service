package com.indusind.trade.admin.facade.impl;


import com.indusind.trade.admin.facade.MyAccessFacade;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.MyAccessResponseDto;
import com.indusind.trade.model.service.MyAccessService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class MyAccessFacadeImpl implements MyAccessFacade {

    private final MyAccessService myAccessService;


    @Override
    public ApplicationResponse getMyAccess(Long userId) {
        MyAccessResponseDto response = myAccessService.getMyAccess(userId);
        return new ApplicationResponse("SUCCESS", response, "User access fetched successfully");
    }

}
