package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.NotificationFacade;
import com.indusind.trade.model.dtos.requestdtos.NotificationRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.NotificationResponseDto;
import com.indusind.trade.model.entities.bank.BankProfile;
import com.indusind.trade.model.entities.bank.BankProfileTemp;
import com.indusind.trade.model.entities.company.Notification;
import com.indusind.trade.model.entities.company.NotificationTemp;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@RequiredArgsConstructor
public class NotificationFacadeImpl implements NotificationFacade {

    private final NotificationService notificationService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse saveNotification(NotificationRequestDto notificationRequestDto) {

        NotificationTemp notificationTemp;

        if(Objects.nonNull(notificationRequestDto.getIsUpdate()) && notificationRequestDto.getIsUpdate()){
            notificationTemp = notificationService.getNotificationTempById(notificationRequestDto.getNotificationId());
            notificationTemp = notificationRequestDto.convertToTempEntity(notificationRequestDto, notificationTemp);

            //notificationService.saveNotification(notification);
        }else{
            notificationTemp = notificationRequestDto.convertToTempEntity(notificationRequestDto, new NotificationTemp());
            //notificationService.saveNotification(notification);
        }
        notificationTemp.setStatus(Status.PENDING.toString());

        notificationTemp.setIsActive(false);
        notificationService.flushNotificationTemp();
        NotificationTemp savedNotificationTemp = notificationService.saveNotificationTemp(notificationTemp);

        return new ApplicationResponse("SUCCESS", Map.of(savedNotificationTemp.getNotificationId(), savedNotificationTemp.getNotificationTitle()), "Notification saved successfully.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getAllNotifications(Pageable pageable) {
        Page<NotificationTemp> notificationPage = notificationService.getAllTempNotifications(pageable);
        Page<NotificationResponseDto> notificationResponseDtoPage = notificationPage.map(NotificationResponseDto :: convertToTempDto);
        return new ApplicationResponse("SUCCESS", notificationResponseDtoPage, "Notifications fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getNotificationTempById(Long id) {
        NotificationTemp notificationTemp = notificationService.getNotificationTempById(id);
        NotificationResponseDto notificationResponseDto = NotificationResponseDto.convertToTempDto(notificationTemp);
        return new ApplicationResponse("SUCCESS", notificationResponseDto, "Notification fetched.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getNotificationById(Long id) {
        Notification notification = notificationService.getNotificationById(id);
        NotificationResponseDto notificationResponseDto = NotificationResponseDto.convertToDto(notification);
        return new ApplicationResponse("SUCCESS", notificationResponseDto, "Notification fetched.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse approveNotification(Long id) {
        Notification notification = null;
        NotificationTemp notificationTemp = notificationService.getNotificationTempById(id);
        notificationTemp.setStatus(Status.APPROVED.toString());
        notificationTemp = notificationService.saveNotificationTemp(notificationTemp);

        Boolean existsFlag = notificationService.existsNotification(id);

        if (existsFlag) {
            notification = notificationService.getNotificationById(id);
            notificationService.flushNotification();
            notification = NotificationTemp.convertToMasterEntity(notificationTemp, notification);
        } else {
            notification = NotificationTemp.convertToMasterEntity(notificationTemp, new Notification());
        }
        Notification notificationSaved = notificationService.saveNotification(notification);
        return new ApplicationResponse("SUCCESS", Map.of(notificationTemp.getNotificationId(), notificationTemp.getNotificationTitle()), "Notification approved");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse rejectNotification(Long id) {
        NotificationTemp notificationTempSaved = null;
        NotificationTemp notificationTemp = notificationService.getNotificationTempById(id);
        if(notificationService.existsNotification(id)){
            Notification notification = notificationService.getNotificationById(id);
            notificationTemp = Notification.convertToTempEntity(notification, notificationTemp);
            notificationTemp.setStatus(Status.UPDATE_REJECTED.toString());
            notificationTempSaved = notificationService.saveNotificationTemp(notificationTemp);
        }else{
            notificationTemp.setStatus(Status.REJECTED.toString());
            notificationTempSaved = notificationService.saveNotificationTemp(notificationTemp);
        }

        return new ApplicationResponse("SUCCESS", Map.of(notificationTempSaved.getNotificationId(), notificationTempSaved.getNotificationTitle()), "Notification Rejected");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse toggleNotification(NotificationRequestDto notificationRequestDto, Long id) {
        NotificationTemp notificationTemp = notificationService.getNotificationTempById(id);
        Boolean isActive = notificationRequestDto.getIsActive();
        notificationTemp.setIsActive(isActive);
        NotificationTemp savedNotificationTemp = notificationService.saveNotificationTemp(notificationTemp);
        if(notificationService.existsNotification(id)){
            Notification notification = notificationService.getNotificationById(id);
            notificationService.flushNotification();
            notification.setIsActive(isActive);
            notificationService.saveNotification(notification);
        }
        return new ApplicationResponse("SUCCESS", Map.of(savedNotificationTemp.getNotificationId(), savedNotificationTemp.getIsActive()), "Notification toggled");
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getAllNotificationsClient() {
        List<Notification> notificationList = notificationService.getAllNotificationClients();
        List<NotificationResponseDto> notificationResponseDtoList = notificationList.stream().map(NotificationResponseDto :: convertToDto).toList();
        return new ApplicationResponse("SUCCESS", notificationResponseDtoList, "Client notification fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse deleteNotificationById(Long id) {
        NotificationTemp notificationTemp = notificationService.getNotificationTempById(id);
        notificationTemp.setDeletedDate(LocalDateTime.now());
        if(notificationService.existsNotification(id)){
            Notification notification = notificationService.getNotificationById(id);
            notificationService.flushNotification();
            notification.setDeletedDate(LocalDateTime.now());
            notificationService.saveNotification(notification);
        }
        NotificationTemp savedNotificationTemp = notificationService.saveNotificationTemp(notificationTemp);
        return new ApplicationResponse("SUCCESS", Map.of(savedNotificationTemp.getNotificationId(), savedNotificationTemp.getNotificationTitle()), "Notification deleted successfully.");
    }
}
