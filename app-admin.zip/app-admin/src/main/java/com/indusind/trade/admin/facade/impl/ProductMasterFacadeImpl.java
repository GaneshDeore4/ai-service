package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.ProductMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.*;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.master.*;
import com.indusind.trade.model.service.CategoryMasterService;
import com.indusind.trade.model.service.ProductMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ProductMasterFacadeImpl implements ProductMasterFacade {

    private final ProductMasterService productMasterService;
    private final CategoryMasterService categoryMasterService;

    @Override
    @Transactional
    public ApplicationResponse saveProduct(ProductMasterDto productMasterDto) {
        CategoryMaster category = categoryMasterService.getCategoryById(productMasterDto.getCategoryId());
        Long currSeq = productMasterService.findMaxSequenceId();
        long nextSeq = currSeq+1;
        ProductMaster product = ProductMasterDto.convertToEntity(productMasterDto);
        product.setSequenceId(nextSeq);
        product.setCategory(category);
        ProductMaster savedProduct = productMasterService.saveProduct(product);

        return new ApplicationResponse("SUCCESS", ProductMasterDto.convertToDto(savedProduct), "Product saved successfully.");
    }

    @Override
    public ApplicationResponse getAllProducts(Pageable pageable) {
        if (Objects.nonNull(pageable)) {
            Page<ProductMaster> page = productMasterService.getAllProducts(pageable);
            Page<ProductMasterDto> dtoPage = page.map(ProductMasterDto::convertToDto);
            return new ApplicationResponse("SUCCESS", dtoPage, "Products fetched successfully.");
        } else {
            List<ProductMaster> productMasterList = productMasterService.getAllProducts();
            List<ProductMasterDto> productMasterDtos = productMasterList.stream()
                    .map(ProductMasterDto::convertToDto)
                    .collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", productMasterDtos, "All Products fetched successfully.");
        }

    }

    @Override
    public ApplicationResponse getAllProductsByCategoryId(Pageable pageable, Long categoryId) {
        if (Objects.nonNull(pageable)) {
            Page<ProductMaster> page = productMasterService.getAllProductsByCategoryId(pageable, categoryId);
            Page<ProductMasterDto> dtoPage = page.map(ProductMasterDto::convertToDto);
            return new ApplicationResponse("SUCCESS", dtoPage, "Products fetched successfully.");
        } else {
            List<ProductMaster> productMasterList = productMasterService.getAllProductsByCategoryId(categoryId);
            List<ProductMasterDto> productMasterDtos = productMasterList.stream()
                    .map(ProductMasterDto::convertToDto)
                    .collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", productMasterDtos, "All Products fetched successfully.");
        }
    }

    @Override
    public ApplicationResponse getProductById(Long productId) {
        ProductMasterDto productMasterDto = ProductMasterDto.convertToDto(productMasterService.getProductById(productId));
        return new ApplicationResponse("SUCCESS", productMasterDto, "product fetched");
    }


    @Override
    public ApplicationResponse getSubProductsByProductId(Long productId) {
        List<SubProductMaster> productMasterList = productMasterService.getSubProductsByProductId(productId);

        List<SubProductMasterDto> dtoList = productMasterList.stream()
                .map(SubProductMasterDto::convertToDto)
                .collect(Collectors.toList());
        return new ApplicationResponse("SUCCESS", dtoList, "SubProducts for products fetched successfully.");
    }

    @Override
    public ApplicationResponse getSubProductsByProductList(List<Long> productIds) {
        List<ProductMaster> productMasterList = productMasterService.getProductsByIds(productIds);
        List<ProductMasterDto> dtoList = productMasterList.stream().map(product -> {
            ProductMasterDto dto = ProductMasterDto.convertToDto(product);
            dto.setSubProductMasterDtoList(product.getSubProductMasterList().stream().map(SubProductMasterDto::convertToDto).collect(Collectors.toSet()));
            return dto;
        }).collect(Collectors.toList());
        return new ApplicationResponse("SUCCESS", dtoList, "SubProducts for products fetched successfully.");
    }

    @Override
    public ApplicationResponse getTabsByProduct(Long productId) {
        ProductMaster product = productMasterService.getProductById(productId);
        List<TabMaster> tabs = product.getTabs();
        List<TabMasterDto> tabsDto = tabs.stream()
                .map(TabMasterDto::convertToDto)
                .toList();
        return new ApplicationResponse("SUCCESS", tabsDto, "Tabs for product fetched successfully.");
    }

    @Override
    public ApplicationResponse getActionsByProduct(Long productId) {
        ProductMaster product = productMasterService.getProductById(productId);
        List<Action> actions = product.getActions();
        List<ActionDto> actionDtoList = actions.stream().map(ActionDto::convertToDto).collect(Collectors.toList());
        return new ApplicationResponse("SUCCESS", actionDtoList, "Actions for product fetched successfully.");
    }

    @Override
    public ApplicationResponse getProdSubProdMapByCategoryId(Long categoryId) {
        List<ProductMaster> productMasterList = productMasterService.getProductsByCategoryId(categoryId);
        Map<String, Set<String>> productSubProductMap = productMasterList.stream()
                .collect(Collectors.toMap(
                        product -> product.getProductId() + "-" + product.getProductName(),
                        product -> Optional.ofNullable(product.getSubProductMasterList())
                                .orElse(Collections.emptyList())
                                .stream()
                                .map(sub -> sub.getSubProductId() + "-" + sub.getSubProductName())
                                .collect(Collectors.toSet())
                ));
        return new ApplicationResponse("SUCCESS", productSubProductMap, "Product subproduct fetched successfully.");
    }

    @Override
    @Transactional
    public ApplicationResponse mapProductToMidOffice(ProductMidOfficeMappingRequestDto request) {
        List<ProductMidOfficeMappingDto> list = request.getMapping();

        for(ProductMidOfficeMappingDto d : list) {
            ProductMaster productMaster = productMasterService.getProductById(d.getProductId());
            productMaster.setMidOfficeFlag(d.getMidOfficeFlag());
            productMasterService.saveProduct(productMaster);
        }

        return new ApplicationResponse("SUCCESS", null, "Product mapped with mid office.");
    }
}
