package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.SmsFacade;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SmsFacadeImpl implements SmsFacade {

    private final WebClient webClient;

    @Override
    public HashMap<String, String> sendSms(long contactNo) {
        Logger logger = LoggerFactory.getLogger(SmsFacadeImpl.class);
        HashMap<String, String> smsResponse = new HashMap<>();

        String otp = generateOtp();
        String smsUrl = "https://enterprise.smsgupshup.com/GatewayAPI/rest?method=SendMessage&send_to="+contactNo+"&msg="+otp+"%20is%20your%20OTP.%20Please%20do%20not%20share%20with%20anyone.-Indusind%20Bank&msg_type=TEXT&userid=2000237193&auth_scheme=plain&password=CcbhZT5P&v=1.1&format=text";

        try{
            String res = webClient.get()
                    .uri(smsUrl)
                    .retrieve()
                    .onStatus(
                            status -> !status.is2xxSuccessful(), //replace responseCode check
                            clientResponse -> {
                                logger.info("request failed");
                                return Mono.error(new RuntimeException("Request failed"));
                            }
                    )
                    .bodyToMono(String.class) //replace BufferedReader
                    .block(); // keeps  existing sync behavior

            smsResponse.put("status", res.split("\\|")[0].trim());
            smsResponse.put("phone", res.split("\\|")[1].trim());
            smsResponse.put("msgId", res.split("\\|")[2].trim());
            smsResponse.put("otp", otp);
            logger.info("sendSMSReq: Response- " + res);
        } catch (Exception e) {
            logger.info("Exception occurred: {}", e.getMessage());
            // your existing fallback
            smsResponse.put("status", "success");
            smsResponse.put("phone", String.valueOf(contactNo));
            smsResponse.put("msgId", UUID.randomUUID().toString());
            smsResponse.put("otp", otp);
        }
        logger.info("smsResponse: " + smsResponse);
        logger.info("sendSMSReq: end");
        return smsResponse;
    }
    public static String generateOtp(){
        SecureRandom random = new SecureRandom();
        int otp = random.nextInt(90000)+10000;
        return String.valueOf(otp);
    }
}



