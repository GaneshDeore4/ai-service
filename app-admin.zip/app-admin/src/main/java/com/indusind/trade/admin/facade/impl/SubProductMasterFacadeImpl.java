package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.SubProductMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.SubProductMasterDto;
import com.indusind.trade.model.dtos.requestdtos.TabMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.entities.master.TabMaster;
import com.indusind.trade.model.service.ProductMasterService;
import com.indusind.trade.model.service.SubProductMasterService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class SubProductMasterFacadeImpl implements SubProductMasterFacade {

    private final SubProductMasterService subProductMasterService;

    private final ProductMasterService productMasterService;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public ApplicationResponse saveSubProduct(SubProductMasterDto subProductMasterDto) {
        ProductMaster pm = productMasterService.getProductById(subProductMasterDto.getProductId());
        Long currSeq = subProductMasterService.findMaxSequenceIdByProductId(subProductMasterDto.getProductId());
        long nextSeq = currSeq+1;
        SubProductMaster subProductMaster = SubProductMasterDto.convertToEntity(subProductMasterDto);
        subProductMaster.setSequenceId(nextSeq);
        subProductMaster.setProductMaster(pm);
        SubProductMaster savedSubProduct = subProductMasterService.saveSubProduct(subProductMaster);
        return new ApplicationResponse("SUCCESS", SubProductMasterDto.convertToDto(savedSubProduct), "Sub Product saved.");
    }

    @Override
    public ApplicationResponse getAllSubProducts(Pageable pageable) {
//        Pageable sortedPageable = pageable;
//        if(pageable.getSort().isUnsorted()){
//            sortedPageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
//                    Sort.by(Sort.Order.desc("createdAt")));
//        }
        if (Objects.nonNull(pageable)) {
            Page<SubProductMaster> page = subProductMasterService.getAllSubProducts(pageable);
            return new ApplicationResponse("SUCCESS", page.map(SubProductMasterDto::convertToDto), "Sub Products fetched");
        } else {
            List<SubProductMaster> subProductMasters = subProductMasterService.getAllSubProducts();
            List<SubProductMasterDto> subProductMasterDtolist = subProductMasters.stream().map(SubProductMasterDto::convertToDto).collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", subProductMasterDtolist, "All Sub Products fetched");

        }
    }

    @Override
    public ApplicationResponse getSubProductById(Long subProductId) {
        SubProductMaster subProductMaster = subProductMasterService.getSubProductById(subProductId);
        return new ApplicationResponse("SUCCESS", SubProductMasterDto.convertToDto(subProductMaster), "Sub Product Fetched with id");
    }

    @Override
    public ApplicationResponse getTabsBySubProduct(Long subProductId) {
        SubProductMaster subProductMaster = subProductMasterService.getSubProductById(subProductId);
        List<TabMaster> tabs = subProductMaster.getTabs();
        List<TabMasterDto> tabsDto = tabs.stream()
                .map(TabMasterDto :: convertToDto)
                .toList();
        return new ApplicationResponse("SUCCESS", tabsDto, "Sub Product Fetched with id");
    }
}
