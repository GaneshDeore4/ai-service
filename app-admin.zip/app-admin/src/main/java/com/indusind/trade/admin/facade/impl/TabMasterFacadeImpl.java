package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.TabMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.TabMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.entities.master.TabMaster;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.service.ProductMasterService;
import com.indusind.trade.model.service.SubProductMasterService;
import com.indusind.trade.model.service.TabMasterService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class TabMasterFacadeImpl implements TabMasterFacade {

    private final TabMasterService tabMasterService;
    private final ProductMasterService productMasterService;
    private final SubProductMasterService subProductMasterService;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public ApplicationResponse addTabMaster(TabMasterDto tabMasterDto) {
        try {
            TabMaster tabMaster = TabMasterDto.convertToEntity(tabMasterDto);
            List<ProductMaster> productMasterList = productMasterService.getProductsByIds(tabMasterDto.getProductIds());

            if (CollectionUtils.isNotEmpty(tabMasterDto.getSubProductIds())) {
                List<SubProductMaster> subProductList = subProductMasterService.getSubProductMasterList(tabMasterDto.getSubProductIds());
                tabMaster.setSubProducts(subProductList);
            }

            tabMaster.setProducts(productMasterList);

            TabMaster savedTabMaster = tabMasterService.addTabMaster(tabMaster);
            return new ApplicationResponse("SUCCESS", TabMasterDto.convertToDto(savedTabMaster), "Tab Master saved");
        } catch (Exception e) {
            throw new GTPAppException("Exception occurred while saving tab master", e);
        }
    }

    @Override
    public ApplicationResponse getAllTabMaster(Pageable pageable) {
        try {
            Page<TabMaster> tabMasterPage = tabMasterService.getAllTabMaster(pageable);
            Page<TabMasterDto> tabMasterDtos = tabMasterPage.map(tab -> {
                TabMasterDto tabDto = TabMasterDto.convertToDto(tab);
                this.getProductSubProductMap(tab, tabDto);
                return tabDto;
            });

            return new ApplicationResponse("SUCCESS", tabMasterDtos, "Tab master fetched");
        } catch (Exception e) {
            throw new GTPAppException("Exception occurred while fetching tab master", e);
        }
    }

    private void getProductSubProductMap(TabMaster tab, TabMasterDto tabMasterDto) {
        Map<String, Set<String>> prodSubProdMapping = new HashMap<>();
        tab.getProducts().stream().forEach(prod -> {
            if(Objects.isNull(tabMasterDto.getCategoryMap()) || tabMasterDto.getCategoryMap().isEmpty()){
                Map<Long, String> categoryMap = Map.of(prod.getCategory().getCategoryId(),prod.getCategory().getCategoryName());
                tabMasterDto.setCategoryMap(categoryMap);
            }
            prodSubProdMapping.putIfAbsent(prod.getProductId() + "-" + prod.getProductName(), new HashSet<>());
        });
//        tab.getSubProducts().stream().forEach(subProd -> {
//            prodSubProdMapping.computeIfPresent(subProd.getProductMaster().getProductId() + "-" + subProd.getProductMaster().getProductName(), (k, v) -> v + subProd.getSubProductId() + "-" + subProd.getSubProductName() + "|");
//        });
        tab.getSubProducts().forEach(subProd -> {
            String productKey = subProd.getProductMaster().getProductId()
                    + "-" + subProd.getProductMaster().getProductName();

            String subKey = subProd.getSubProductId()
                    + "-" + subProd.getSubProductName();

            prodSubProdMapping.computeIfPresent(productKey, (k, v) -> {
                v.add(subKey);
                return v;
            });
        });
        tabMasterDto.setProdSubProdMapping(prodSubProdMapping);
    }

    @Override
    public ApplicationResponse getTabById(Long tabId) {
        TabMaster tabMaster = tabMasterService.getTabById(tabId);
        TabMasterDto tabDto = TabMasterDto.convertToDto(tabMaster);
        this.getProductSubProductMap(tabMaster, tabDto);
        return new ApplicationResponse("SUCCESS", tabDto, "Tab Master fetched");
    }

    @Override
    public ApplicationResponse updateTabMaster(Long tabId, TabMasterDto tabMasterDto) {
        TabMaster updatedTab = tabMasterService.updateTabMaster(tabId, tabMasterDto.getTabName());

        return new ApplicationResponse("SUCCESS", TabMasterDto.convertToDto(updatedTab), "UserRole updated.");
    }

    @Override
    public ApplicationResponse deleteTabMaster(Long tabId) {
        tabMasterService.deleteTabMaster(tabId);
        return new ApplicationResponse("SUCCESS", "", "Tab option deleted");
    }

    @Override
    public ApplicationResponse getProdSubProdMappingForTab(Long tabId) {
        TabMaster tabMaster = tabMasterService.getUserRoleEntityById(tabId);
        TabMasterDto dto = TabMasterDto.convertToDto(tabMaster);
        this.getProductSubProductMap(tabMaster, dto);
        return new ApplicationResponse("SUCCESS", dto, "UserRole Prod SubProduct Mapping fetched");
    }
}
