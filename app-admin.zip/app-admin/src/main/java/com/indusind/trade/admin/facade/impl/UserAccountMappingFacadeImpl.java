package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.UserAccountMappingFacade;
import com.indusind.trade.model.dtos.requestdtos.AddUserAccountMappingRequestDto;
import com.indusind.trade.model.dtos.response.dtos.AccountDetailsDto;
import com.indusind.trade.model.dtos.response.dtos.AddUserAccountMappingResponseDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.company.AccountDetail;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.service.UserAccountMappingService;
import com.indusind.trade.model.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
@RequiredArgsConstructor
public class UserAccountMappingFacadeImpl implements UserAccountMappingFacade {

    private final UserAccountMappingService userAccountMappingService;
    private final UserService userService;

    @Override
    public ApplicationResponse getAccountsByCifId(String cifId) {
        List<AccountDetail> accounts = userAccountMappingService.getAccountDetailsByCifId(cifId);

        List<AccountDetailsDto> accountsDto = accounts.stream().map(
                AccountDetailsDto :: convertToDto
        ).toList();
        return new ApplicationResponse("SUCCESS", accountsDto, "Account List fetched by cifId: " + cifId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse addUserAccountMapping(AddUserAccountMappingRequestDto request) {

//        AccountDetail account = userAccountMappingService.getAccountById(request.getAccountId());
        List<AccountDetail> accountList = userAccountMappingService.getAccountsById(request.getAccountId());

        User user = userService.getUserById(request.getUserId());

        user.setAccountMapping(accountList);

        user = userService.saveUser(user);

        AddUserAccountMappingResponseDto response = AddUserAccountMappingResponseDto.builder()
                .userId(user.getUserId())
                .accountDetails(user.getAccountMapping().stream()
                        .map(AccountDetailsDto :: convertToDto)
                        .toList()
                )
                .build();

        return new ApplicationResponse("SUCCESS", response, "User Account Mapping added successfully.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse addBulkUserAccountMapping(List<AddUserAccountMappingRequestDto> request) {
        List<AddUserAccountMappingResponseDto> response = new ArrayList<>();
        for(AddUserAccountMappingRequestDto req : request) {
            response.add((AddUserAccountMappingResponseDto) addUserAccountMapping(req).getPayload());
        }
        return new ApplicationResponse("SUCCESS", response, "User Account Mapping added successfully.");
    }

    @Override
    public ApplicationResponse getAccountsByUserId(Long userId) {

        User user = userService.getUserById(userId);

        List<AccountDetail> accountDetail = user.getAccountMapping();

        if(Objects.isNull(accountDetail)) {
            throw new GTPAppException("Account mapping for user with id: " + userId + " does not exist.", null);
        }

        List<AccountDetailsDto> accountDto = accountDetail.stream()
                .map(AccountDetailsDto :: convertToDto)
                .toList();

        return new ApplicationResponse("SUCCESS", accountDto, "Account Details for userId " + userId +" fetched successfully.");
    }
}
