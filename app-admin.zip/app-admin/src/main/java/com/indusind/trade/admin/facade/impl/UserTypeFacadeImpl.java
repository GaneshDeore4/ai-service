package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.UserTypeFacade;
import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.entities.master.UserTypeTabActionMapping;
import com.indusind.trade.model.service.CategoryMasterService;
import com.indusind.trade.model.service.UserTypeService;
import com.indusind.trade.model.service.UserTypeTabActionMappingService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class UserTypeFacadeImpl implements UserTypeFacade {

    private final UserTypeService userTypeService;

    private final CategoryMasterService categoryMasterService;

    private final UserTypeTabActionMappingService userTypeTabActionMappingService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse saveUserType(UserTypeDto userTypeDto) {
        CategoryMaster categoryMaster = categoryMasterService.getCategoryById(userTypeDto.getCategoryId());
        UserType userType = UserTypeDto.convertToEntity(userTypeDto);
        userType.setCategory(categoryMaster);
        UserType savedUserType = userTypeService.saveUserType(userType);
        return new ApplicationResponse("SUCCESS", UserTypeDto.convertToDto(savedUserType), "User Type Saved");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse updateUserType(UserTypeDto userTypeDto) {
        UserType userType = UserTypeDto.convertToEntity(userTypeDto);
        UserType updatedUserType = userTypeService.saveUserType(userType);
        return new ApplicationResponse("SUCCESS", UserTypeDto.convertToDto(updatedUserType), "User Type Updated");
    }

    @Override
    public ApplicationResponse getAllUserTypes(Pageable pageable) {
        Page<UserType> page = userTypeService.getAllUserTypes(pageable);
        return new ApplicationResponse("SUCCESS", page.map(UserTypeDto::convertToDto),
                "User Types fetched successfully");
    }

    @Override
    public ApplicationResponse getUserTypeById(Long userTypeId) {
        UserType userType = userTypeService.getUserTypeById(userTypeId);
        UserTypeDto userTypeDto = UserTypeDto.convertToDto(userType);

        List<UserTypeTabActionMapping> mappingList = userTypeTabActionMappingService.findByUserTypeId(userTypeId);
        List<UserTypeTabActionMappingDto> userTypeTabActionMappingResp = new ArrayList<>();
        Map<String, List<String>> tabActionMap = mappingList.stream()
                .collect(Collectors.groupingBy(map -> map.getTab().getTabId() + "-" + map.getTab().getTabName(),
                        Collectors.mapping(map -> map.getAction().getActionId() + "-" + map.getAction().getActionName(),
                                Collectors.toList())));
//        tabActionMap.forEach((k, v) -> {
//            UserTypeTabActionMappingDto dto = new UserTypeTabActionMappingDto();
//            dto.setTabId(k.split("-")[0]);
//            dto.setTabName(k.split("-")[1]);
//
//            List<Map<String, String>> result = v.stream()
//                    .map(s -> {
//                        String[] parts = s.split("-", 2);
//                        String id = parts[0].trim();
//                        String name = parts[1].trim();
//                        Map<String, String> m = new HashMap<>();
//                        m.put("id", id);
//                        m.put("name", name);
//                        return m;
//                    })
//                    .collect(Collectors.toList());
//
//            dto.setActions(result);
//            userTypeTabActionMappingResp.add(dto);
//        });
        userTypeDto.setTabActionMapping(userTypeTabActionMappingResp);

        return new ApplicationResponse("SUCCESS", userTypeDto, "User Type Fetched");
    }
}
