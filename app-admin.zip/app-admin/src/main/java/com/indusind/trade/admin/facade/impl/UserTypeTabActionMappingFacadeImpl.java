package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.UserTypeTabActionMappingFacade;
import com.indusind.trade.model.dtos.requestdtos.*;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.UserTypeMappingResponseDto;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.entities.master.*;
import com.indusind.trade.model.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class UserTypeTabActionMappingFacadeImpl implements UserTypeTabActionMappingFacade {

    private final UserTypeTabActionMappingService userTypeTabActionMappingService;

    private final ProductMasterService productMasterService;

    private final SubProductMasterService subProductMasterService;

    private final TabMasterService tabMasterService;

    private final ActionService actionService;

    private final UserTypeService userTypeService;

//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public ApplicationResponse addMapping(UserTypeTabActionMappingRequestDto userTypeTabActionMappingDto) {
//        List<UserTypeTabActionMapping> userTypeTabActionMappingList = new ArrayList<>();
//        Map<Long, TabMaster> mapTabs = new HashMap<>();
//        SubProductMaster subProductMaster = null;
//        List<Long> tabIdRequestList = userTypeTabActionMappingDto.tabActionMappingReqDtoList().stream()
//                .map(TabActionMappingReqDto::getTabId).collect(Collectors.toList());
//        ProductMaster productMaster = productMasterService.getProductById(userTypeTabActionMappingDto.productId());
//        List<Action> actionList = productMaster.getActions();
//        Map<Long, Action> mapAction = actionList.stream()
//                .collect(Collectors.toMap(action -> action.getActionId(), Function.identity()));
//        if (Objects.nonNull(userTypeTabActionMappingDto.subProductId())) {
//            subProductMaster = subProductMasterService.getSubProductById(userTypeTabActionMappingDto.subProductId());
//            List<TabMaster> tabList = subProductMaster.getTabs();
//            mapTabs = tabList.stream().filter(tab -> tabIdRequestList.contains(tab.getTabId()))
//                    .collect(Collectors.toMap(tab -> tab.getTabId(), Function.identity()));
//        } else {
//            // Product which don't have subproduct
//            mapTabs = productMaster.getTabs().stream().filter(tab -> tabIdRequestList.contains(tab.getTabId()))
//                    .collect(Collectors.toMap(tab -> tab.getTabId(), Function.identity()));
//        }
//        UserType userType = userTypeService.getUserTypeById(userTypeTabActionMappingDto.userTypeId());
//
//        // FIX: Delete existing mappings for this UserType + Product + SubProduct
//        // combination before inserting new ones
//        if (subProductMaster != null) {
//            userTypeTabActionMappingService.deleteUserTabActionMappingByUserTypeProdSubProd(
//                    userType.getUserTypeId(), productMaster.getProductId(), subProductMaster.getSubProductId());
//        } else {
//            // If subProduct is null, we need a way to clear just the product level.
//            // The DAO currently demands subProductId. We can pass null if the DB allows it,
//            // or we might need a new DAO method. Let's assume passing null works for the
//            // query if SubProduct is null.
//            userTypeTabActionMappingService.deleteUserTabActionMappingByUserTypeProdSubProd(
//                    userType.getUserTypeId(), productMaster.getProductId(), null);
//        }
//
//        // Force Hibernate to execute the DELETEs immediately, overriding its default
//        // behavior
//        // which puts INSERTs before DELETEs in the ActionQueue.
//        userTypeTabActionMappingService.flush();
//
//        Set<String> processedDuplicates = new HashSet<>();
//
//        for (TabActionMappingReqDto tabActionMapping : userTypeTabActionMappingDto.tabActionMappingReqDtoList()) {
//            TabMaster tab = mapTabs.get(tabActionMapping.getTabId());
//            if (tab == null) {
//                tab = tabMasterService.getTabById(tabActionMapping.getTabId());
//            }
//            for (Long actionId : tabActionMapping.getActionIdList()) {
//                // Prevent duplicate combinations from the UI payload
//                String uniqueKey = tabActionMapping.getTabId() + "-" + actionId;
//                if (!processedDuplicates.add(uniqueKey)) {
//                    continue;
//                }
//
//                UserTypeTabActionMapping userTypeTabActionMapping = new UserTypeTabActionMapping();
//                userTypeTabActionMapping.setUserType(userType);
//                userTypeTabActionMapping.setProduct(productMaster);
//                userTypeTabActionMapping.setSubProduct(subProductMaster);
//                Action action = mapAction.get(actionId);
//                if (action == null) {
//                    action = actionService.getActionById(actionId);
//                }
//                userTypeTabActionMapping.setAction(action);
//                userTypeTabActionMapping.setTab(tab);
//                userTypeTabActionMappingList.add(userTypeTabActionMapping);
//            }
//        }
//        userTypeTabActionMappingService.saveMappingList(userTypeTabActionMappingList);
//        return new ApplicationResponse("SUCCESS", null, "User Type is mapped with Tabs and actions successfully");
//    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse addMapping(UserTypeTabActionMappingRequestDto userTypeTabActionMappingDto) {
        List<UserTypeTabActionMapping> userTypeTabActionMappingList = new ArrayList<>();

        ProductMaster productMaster = productMasterService.getProductById(userTypeTabActionMappingDto.productId());
        SubProductMaster subProductMaster = null;

        if(userTypeTabActionMappingDto.subProductId() != null){
            subProductMaster = subProductMasterService.getSubProductById(userTypeTabActionMappingDto.subProductId());
        }

        Map<Long, Action> mapAction = productMaster.getActions().stream().collect(Collectors.toMap(Action::getActionId, Function.identity()));

        for( UserTypeTabActionMappingReqDto mappingDto : userTypeTabActionMappingDto.userTypeTabActionMappingReqDtos() ){
            UserType userType = userTypeService.getUserTypeById(mappingDto.getUserTypeId());

            userTypeTabActionMappingService.deleteUserTabActionMappingByUserTypeProdSubProd(userType.getUserTypeId(), productMaster.getProductId(), subProductMaster != null ? subProductMaster.getSubProductId() : null);

            Set<String> processedDuplicates = new HashSet<>();

            // Prepare tab map for this request
            List<Long> tabIds = mappingDto.getTabActionMappingReqDtoList()
                    .stream()
                    .map(TabActionMappingReqDto::getTabId)
                    .toList();

            Map<Long, TabMaster> mapTabs =
                    (subProductMaster != null ?
                            subProductMaster.getTabs() :
                            productMaster.getTabs())
                            .stream()
                            .filter(t -> tabIds.contains(t.getTabId()))
                            .collect(Collectors.toMap(TabMaster::getTabId, Function.identity()));

            for (TabActionMappingReqDto tabReq : mappingDto.getTabActionMappingReqDtoList()) {

                TabMaster tab = mapTabs.get(tabReq.getTabId());

                if (tab == null) {
                    tab = tabMasterService.getTabById(tabReq.getTabId());
                }

                for (Long actionId : tabReq.getActionIdList()) {

                    String key = mappingDto.getUserTypeId() + "-" + tabReq.getTabId() + "-" + actionId;

                    if (!processedDuplicates.add(key)) continue;

                    UserTypeTabActionMapping entity = new UserTypeTabActionMapping();

                    entity.setUserType(userType);
                    entity.setProduct(productMaster);
                    entity.setSubProduct(subProductMaster);
                    entity.setTab(tab);

                    Action action = mapAction.get(actionId);
                    if (action == null) {
                        action = actionService.getActionById(actionId);
                    }

                    entity.setAction(action);

                    userTypeTabActionMappingList.add(entity);
                }
            }
        }
        userTypeTabActionMappingService.flush();
        userTypeTabActionMappingService.saveMappingList(userTypeTabActionMappingList);

        return new ApplicationResponse("SUCCESS", null, "Bulk mapping saved");
    }

    @Override
    public ApplicationResponse getMapping(UserTypeTabActionMappingRequestGetDto dto) {
        List<UserTypeTabActionMapping> userTypeTabActionMappingList = userTypeTabActionMappingService
                .findByUserTypeProductSubProductTabIds(dto.userTypeId(),dto.productId(),dto.subProductId(),dto.tabIds());

        String userTypeName;
        if(!userTypeTabActionMappingList.isEmpty()){
            userTypeName = userTypeTabActionMappingList
                    .get(0)
                    .getUserType()
                    .getUserTypeName();
        } else {
            userTypeName = null;
        }

        List<UserTypeTabActionMappingDto> result = userTypeTabActionMappingList.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.groupingBy(
                                m -> new AbstractMap.SimpleEntry<>(
                                        m.getTab().getTabId(),
                                        m.getTab().getTabName()
                                ),
                                Collectors.mapping(
                                        m -> new AbstractMap.SimpleEntry<>(m.getAction().getActionId(), m.getAction().getActionName()),
                                        Collectors.toList()
                                )
                        ),
                        grouped -> grouped.entrySet().stream()
                                .map(e -> {
                                    UserTypeTabActionMappingDto userTypeTabActionMappingDto = new UserTypeTabActionMappingDto();
                                    userTypeTabActionMappingDto.setTabId(e.getKey().getKey());
                                    userTypeTabActionMappingDto.setTabName(e.getKey().getValue());
                                    userTypeTabActionMappingDto.setProductId(dto.productId());
                                    userTypeTabActionMappingDto.setSubProductId(dto.subProductId());
                                    userTypeTabActionMappingDto.setUserTypeId(dto.userTypeId());
                                    userTypeTabActionMappingDto.setUserTypeName(userTypeName);
                                    List<Map<String, Object>> actions = e.getValue().stream()
                                            .map(a -> {
                                                Map<String, Object> map = new HashMap<>();
                                                map.put("id", a.getKey());
                                                map.put("name", a.getValue());
                                                return map;
                                            })
                                            .collect(Collectors.toList());

                                    userTypeTabActionMappingDto.setActions(actions);
                                    return userTypeTabActionMappingDto;
                                })
                                .collect(Collectors.toList())
                ));
        return new ApplicationResponse("SUCCESS", result, "Tab action mapping fetched Saved");
    }

    @Override
    public ApplicationResponse getMyAccess(MyAccessRequestDto request) {
        if (request.getUserType() == null) {
            return new ApplicationResponse("FAILURE", null, "userType is required");
        }

        List<UserTypeTabActionMapping> userTypeTabActionMappingList = userTypeTabActionMappingService
                .findByUserTypeId(request.getUserType());

        // Filter by Product and SubProduct
//        userTypeTabActionMappingList = userTypeTabActionMappingList.stream()
//                .filter(m -> request.getProductId() == null || request.getProductId().isEmpty()
//                        || request.getProductId().contains(m.getProduct().getProductId()))
//                .filter(m -> m.getSubProduct() == null
//                        || request.getSubProductId() == null || request.getSubProductId().isEmpty()
//                        || request.getSubProductId().contains(m.getSubProduct().getSubProductId()))
//                .collect(Collectors.toList());
//
//        List<UserTypeTabActionMappingDto> userTypeTabActionMappingResp = new ArrayList<>();
//        Map<String, List<String>> tabActionMap = userTypeTabActionMappingList.stream()
//                .collect(Collectors.groupingBy(map -> map.getTab().getTabId() + "-" + map.getTab().getTabName(),
//                        Collectors.mapping(map -> map.getAction().getActionId() + "-" + map.getAction().getActionName(),
//                                Collectors.toList())));
//        tabActionMap.forEach((k, v) -> {
//            UserTypeTabActionMappingDto dto = new UserTypeTabActionMappingDto();
//            dto.setTabId(k.split("-")[0]);
//            dto.setTabName(k.split("-")[1]);
//
//            List<Map<String, String>> result = v.stream()
//                    .distinct() // remove potential duplicates
//                    .map(s -> {
//                        String[] parts = s.split("-", 2);
//                        String id = parts[0].trim();
//                        String name = parts[1].trim();
//                        Map<String, String> m = new HashMap<>();
//                        m.put("id", id);
//                        m.put("name", name);
//                        return m;
//                    })
//                    .collect(Collectors.toList());
//
//            dto.setActions(result);
//            userTypeTabActionMappingResp.add(dto);
//        });
        return new ApplicationResponse("SUCCESS", null, "Users fetched");
    }

    @Override
    public ApplicationResponse getInitialMapping(UserTypeTabActionMappingRequestGetDto dto) {
        List<UserTypeMappingResponseDto> result = new ArrayList<>();
        List<UserType> userTypes = userTypeService.getUserTypeByCategoryId(dto.categoryId());

        for(UserType userType : userTypes){
            List<UserTypeTabActionMapping> userTypeTabActionMappingList = userTypeTabActionMappingService
                    .findByUserTypeProductSubProductTabIds(userType.getUserTypeId(),dto.productId(),dto.subProductId(),dto.tabIds());
            List<UserTypeTabActionMappingDto> tabResult = userTypeTabActionMappingList.stream()
                    .collect(Collectors.collectingAndThen(
                            Collectors.groupingBy(
                                    m -> new AbstractMap.SimpleEntry<>(
                                            m.getTab().getTabId(),
                                            m.getTab().getTabName()
                                    ),
                                    Collectors.mapping(
                                            m -> new AbstractMap.SimpleEntry<>(m.getAction().getActionId(), m.getAction().getActionName()),
                                            Collectors.toList()
                                    )
                            ),
                            grouped -> grouped.entrySet().stream()
                                    .map(e -> {
                                        UserTypeTabActionMappingDto userTypeTabActionMappingDto = new UserTypeTabActionMappingDto();
                                        userTypeTabActionMappingDto.setTabId(e.getKey().getKey());
                                        userTypeTabActionMappingDto.setTabName(e.getKey().getValue());
                                        userTypeTabActionMappingDto.setProductId(dto.productId());
                                        userTypeTabActionMappingDto.setSubProductId(dto.subProductId());
                                        userTypeTabActionMappingDto.setUserTypeId(userType.getUserTypeId());
                                        userTypeTabActionMappingDto.setUserTypeName(userType.getUserTypeName());
                                        List<Map<String, Object>> actions = e.getValue().stream()
                                                .map(a -> {
                                                    Map<String, Object> map = new HashMap<>();
                                                    map.put("id", a.getKey());
                                                    map.put("name", a.getValue());
                                                    return map;
                                                })
                                                .collect(Collectors.toList());

                                        userTypeTabActionMappingDto.setActions(actions);
                                        return userTypeTabActionMappingDto;
                                    })
                                    .collect(Collectors.toList())
                    ));

            UserTypeMappingResponseDto userMappingDto = new UserTypeMappingResponseDto();
            userMappingDto.setUserTypeId(userType.getUserTypeId());
            userMappingDto.setUserTypeName(userType.getUserTypeName());
            userMappingDto.setTabMappings(tabResult);

            result.add(userMappingDto);
        }
        return new ApplicationResponse("SUCCESS", result, "Tab action mapping fetched Saved");
    }


}
