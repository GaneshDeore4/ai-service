package com.indusind.trade.admin.utility;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;

import java.util.*;

public class MappingUtil {


    public static Map<String, Set<String>> getProductSubProductMapping(List<ProductMaster> prodList, List<SubProductMaster> subProductMasterList) {
        Map<String, Set<String>> prodSubProdMapping = new HashMap<>();
        prodList.stream().forEach(prod -> {
            prodSubProdMapping.putIfAbsent(prod.getProductId() + "-" + prod.getProductName(), new HashSet<>());
        });
//        companyTemp.getSubProducts().stream().forEach(subProd -> {
//            prodSubProdMapping.computeIfPresent(subProd.getProductMaster().getProductId() + "-" + subProd.getProductMaster().getProductName(), (k, v) -> v + subProd.getSubProductId() + "-" + subProd.getSubProductName() + "|");
//        });

        subProductMasterList.forEach(subProd -> {
            String productKey = subProd.getProductMaster().getProductId()
                    + "-" + subProd.getProductMaster().getProductName();

            String subKey = subProd.getSubProductId()
                    + "-" + subProd.getSubProductName();

            prodSubProdMapping.computeIfPresent(productKey, (k, v) -> {
                v.add(subKey);
                return v;
            });
        });
        return prodSubProdMapping;
    }
}
