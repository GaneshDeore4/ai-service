--Postgres script
INSERT INTO gtp_auth_group (id, auth_group) VALUES (1, 'A') ON CONFLICT (id) DO NOTHING;

INSERT INTO gtp_auth_group (id, auth_group) VALUES (2, 'B') ON CONFLICT (id) DO NOTHING;

INSERT INTO gtp_auth_group (id, auth_group) VALUES (3, 'C') ON CONFLICT (id) DO NOTHING;

INSERT INTO gtp_auth_group (id, auth_group) VALUES (4, 'D') ON CONFLICT (id) DO NOTHING;



-- Adjust sequence to avoid primary key collisions if dynamic inserts happen later

SELECT setval(pg_get_serial_sequence('gtp_auth_group', 'id'), coalesce(max(id),0) + 1, false) FROM gtp_auth_group;

INSERT INTO gtp_category_master (category_name) VALUES ('Client')
ON CONFLICT (category_name) DO NOTHING;

INSERT INTO gtp_category_master (category_name) VALUES ('Bank')
ON CONFLICT (category_name) DO NOTHING;

--INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (1, 'Super Admin', 2) ON CONFLICT (user_type_id) DO NOTHING;
--
--INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (2, 'Admin Maker', 2) ON CONFLICT (user_type_id) DO NOTHING;
--
--INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (3, 'Admin Checker', 2) ON CONFLICT (user_type_id) DO NOTHING;
--
--INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (4, 'Admin (M=C)', 2) ON CONFLICT (user_type_id) DO NOTHING;
--
--INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (5, 'Maker', 1) ON CONFLICT (user_type_id) DO NOTHING;
--
--INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (6, 'Checker', 1) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (21, 'Bank Super Admin Maker', 2) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (22, 'Bank Super Admin Checker', 2) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (23, 'Bank Setup Maker', 2) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (24, 'Bank Setup Checker', 2) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (25, 'Bank View Only', 2) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (26, 'Bank Branch Verifier', 2) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (27, 'Client (M=C)', 1) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (28, 'Client Maker', 1) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (29, 'Client Checker', 1) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (30, 'Client Verifier', 1) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (31, 'Client Releaser', 1) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (32, 'Client View', 1) ON CONFLICT (user_type_id) DO NOTHING;

INSERT INTO gtp_user_type(user_type_id, user_type_name, category_id) VALUES (20, 'Super Admin', 2) ON CONFLICT (user_type_id) DO NOTHING;

-- Re-align the sequence for CATEGORY_ID to max(id)+1
SELECT setval(
 pg_get_serial_sequence('gtp_category_master', 'category_id'),
 COALESCE((SELECT MAX(category_id) FROM gtp_category_master), 0) + 1,
 false
);


--H2 script
--INSERT INTO gtp_auth_group (id, auth_group)
--SELECT 1, 'A'
--WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE auth_group = 'A');
--
--INSERT INTO gtp_auth_group (id, auth_group)
--SELECT 2, 'B'
--WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE auth_group = 'B');
--
--INSERT INTO gtp_auth_group (id, auth_group)
--SELECT 3, 'C'
--WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE auth_group = 'C');
--
--INSERT INTO gtp_auth_group (id, auth_group)
--SELECT 4, 'D'
--WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE auth_group = 'D');
--
--commit;

-- =========================
-- H2: category_master preload
-- =========================

-- Use NOT EXISTS pattern (aligned to your reference)
--INSERT INTO gtp_category_master (CATEGORY_ID, CATEGORY_NAME)
--SELECT NULL, 'Client'
--WHERE NOT EXISTS (
--  SELECT 1 FROM gtp_category_master WHERE CATEGORY_NAME = 'Client'
--);
--
--INSERT INTO gtp_category_master (CATEGORY_ID, CATEGORY_NAME)
--SELECT NULL, 'Bank'
--WHERE NOT EXISTS (
--  SELECT 1 FROM gtp_category_master WHERE CATEGORY_NAME = 'Bank'
--);

-- commit;



-- --Orcale script
-- INSERT INTO gtp_auth_group (id, auth_group)
-- SELECT 1, 'A'
-- FROM dual
-- WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE auth_group = 'A');

-- INSERT INTO gtp_auth_group (id, auth_group)
-- SELECT 2, 'B'
-- FROM dual
-- WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE auth_group = 'B');

-- INSERT INTO gtp_auth_group (id, auth_group)
-- SELECT 3, 'C'
-- FROM dual
-- WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE auth_group = 'C');

-- INSERT INTO gtp_auth_group (id, auth_group)
-- SELECT 4, 'D'
-- FROM dual
-- WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE auth_group = 'D');


-- =========================
-- Oracle: category_master preload
-- =========================
--
-- Requires an existing sequence for CATEGORY_ID; adjust the sequence name if different
-- Example (run once separately, if not present):

-- INSERT INTO gtp_category_master (CATEGORY_ID, CATEGORY_NAME)
-- SELECT 1, 'Client'
-- FROM dual
-- WHERE NOT EXISTS (
--   SELECT 1 FROM gtp_category_master WHERE CATEGORY_NAME = 'Client'
-- );

-- INSERT INTO gtp_category_master (CATEGORY_ID, CATEGORY_NAME)
-- SELECT 2, 'Bank'
-- FROM dual
-- WHERE NOT EXISTS (
--   SELECT 1 FROM gtp_category_master WHERE CATEGORY_NAME = 'Bank'
-- );

--MERGE INTO gtp_user_type t
--USING (
--    SELECT 1,  'Bank Super Admin Maker',    2 FROM dual UNION ALL
--    SELECT 2,  'Bank Super Admin Checker',  2 FROM dual UNION ALL
--    SELECT 3,  'Bank Setup Maker',          2 FROM dual UNION ALL
--    SELECT 4,  'Bank Setup Checker',        2 FROM dual UNION ALL
--    SELECT 5,  'Bank View Only',            2 FROM dual UNION ALL
--    SELECT 6,  'Bank Branch Verifier',      2 FROM dual UNION ALL
--    SELECT 7,  'Client (M=C)',              1 FROM dual UNION ALL
--    SELECT 8,  'Client Maker',              1 FROM dual UNION ALL
--    SELECT 9,  'Client Checker',            1 FROM dual UNION ALL
--    SELECT 10, 'Client Verifier',           1 FROM dual UNION ALL
--    SELECT 11, 'Client Releaser',           1 FROM dual UNION ALL
--    SELECT 12, 'Client View',               1 FROM dual
--) s (user_type_id, user_type_name, category_id)
--ON (t.user_type_id = s.user_type_id)
--WHEN NOT MATCHED THEN
--INSERT (user_type_id, user_type_name, category_id)
--VALUES (s.user_type_id, s.user_type_name, s.category_id);
--
commit;
