-- Schema for Admin Service
-- This ensures tables exist before data.sql runs

CREATE TABLE IF NOT EXISTS gtp_auth_group (
    id BIGINT PRIMARY KEY,
    auth_group VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS gtp_category_master (
    category_id SERIAL PRIMARY KEY,
    category_name VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP,
    modified_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gtp_user_type (
    user_type_id BIGINT PRIMARY KEY,
    user_type_name VARCHAR(255) NOT NULL,
    category_id BIGINT NOT NULL,
    created_at TIMESTAMP,
    CONSTRAINT uk_user_type_with_category UNIQUE (user_type_name, category_id),
    CONSTRAINT fk_user_type_category FOREIGN KEY (category_id) REFERENCES gtp_category_master(category_id)
);
