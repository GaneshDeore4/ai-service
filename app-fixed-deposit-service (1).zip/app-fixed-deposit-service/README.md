# Fixed Deposit Service Documentation

## Overview
The `FixedDepositService` is a dedicated microservice (Port 8084) designed to handle the end-to-end lifecycle of Fixed Deposits. It supports a dual-adapter architecture, allowing it to communicate with external banking systems via either **JSON** or **SOAP** protocols.

---

## Configuration & Adapter Switching

### 1. Toggle Adapter Type
You can switch between JSON and SOAP implementations by changing a single property in `src/main/resources/application.properties`:

- **For JSON-based APIs**: `app.fd.adapter.type=json`
- **For SOAP-based APIs**: `app.fd.adapter.type=soap`

### 2. URL Configuration
Update these properties to point the service to the correct banking gateways:

- `app.bank.api.json.gateway-url`: Base gateway URL for JSON APIs.
- `app.bank.api.json.us-mgmt-url`: Management URL for OTP and User MGMT.
- `app.bank.api.soap.url`: Core banking SOAP WSDL/Service URL.

---

## API Documentation

All endpoints follow the base path: `http://localhost:8084/api/fd`

### 1. Fetch Account Details
**Endpoint**: `POST /account-details`  
**Description**: Fetches list of accounts linked to a CIF ID.

**Request Body**:
```json
{
  "appType": "ID", "appVersion": "99.99.99", "authProduct": "NA",
  "com_ImeiNo": "fb155f5bc9e4b189", "customerId": "10103750",
  "deviceId": "fb155f5bc9e4b189", "isUsrLoggedIn": "Y",
  "platform": "android", "userCode": "ARVIND", "userId": "13031",
  "acid": "123456789"
}
```

### 2. Calculate FD Rates
**Endpoint**: `POST /calculate`  
**Description**: Fetches interest rates based on amount and tenure.

**Request Body**:
```json
{
  "appType": "ID", "customerId": "10103750", "userId": "13031",
  "amountValue": "100000",
  "currencyCode": "INR",
  "months": "12",
  "days": "0"
}
```

### 3. Generate OTP
**Endpoint**: `POST /otp/generate`  
**Description**: Sends an OTP to the user's mobile for deposit registration.

**Request Body**:
```json
{
  "appType": "ID", "customerId": "10103750", "userId": "13031",
  "msg": "<#>Dear Customer, your OTP is {#111111#}. Do not share."
}
```

### 4. Verify OTP
**Endpoint**: `POST /otp/verify`  
**Description**: Validates the OTP against the server state.

**Request Body**:
```json
{
  "appType": "ID", "customerId": "10103750", "userId": "13031",
  "otp.user.otp": "123456",
  "otp.user.otp-hint": "1189",
  "action": "STATE_ID_FROM_GENERATE_OTP"
}
```

### 5. Create Fixed Deposit
**Endpoint**: `POST /create`  
**Description**: Final submission to create the FD in the core system.

**Request Body**:
```json
{
  "appType": "ID", "customerId": "10103750", "userId": "13031",
  "accountNumber": "1234567890",
  "amount": "100000",
  "currency": "INR",
  "action": "STATE_ID_FROM_GENERATE_OTP"
}
```

---

## Auditing & Persistence (Optional)
This service includes built-in database storage in the `tradedb` PostgreSQL database.
- **`fixed_deposits` table**: Tracks status (`OTP_SENT`, `COMPLETED`).
- **`fixed_deposit_audits` table**: Logs user actions.

> [!TIP]
> **To disable DB storage**: Open `FixedDepositServiceImpl.java` and comment out the lines marked with `/* AUDIT LOG: ... */` or `/* PERSISTENCE: ... */`.
