package com.indusind.trade.fd.adapter;

import com.indusind.trade.fd.dto.*;

import java.util.Map;

public interface FixedDepositJsonAdapter {
    AccountDetailsResponse fetchAccountDetails(String acid, CommonRequest common);

    FDInterestRatesRespDto calculateFdModel(FDInterestRatesReqDto request);

    Object createFd(Map<String, Object> request);

    FdSummaryResponse fetchFdSummary(FdSummaryRequest request);
}
