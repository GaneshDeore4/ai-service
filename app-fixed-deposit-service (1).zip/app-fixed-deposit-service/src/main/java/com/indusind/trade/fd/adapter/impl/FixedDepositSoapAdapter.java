package com.indusind.trade.fd.adapter.impl;

import com.indusind.trade.fd.adapter.FixedDepositAdapter;
import com.indusind.trade.fd.client.FixedDepositSoapFeignClient;
import com.indusind.trade.fd.dto.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.fd.adapter.type", havingValue = "soap")
@RequiredArgsConstructor
public class FixedDepositSoapAdapter implements FixedDepositAdapter {

    private final FixedDepositSoapFeignClient soapFeignClient;

    @Override
    public AccountDetailsResponse fetchAccountDetails(String acid, CommonRequest common) {
    	
        log.info("Fetching account details via SOAP for ACID: {}", acid);
        
        String reqId = UUID.randomUUID().toString().substring(0, 8);
        
        String soapRequest = buildAccountDetailsSoapRequest(acid, reqId, common);
        
        try {
//             String responseXml = soapFeignClient.executeSoapRequest(soapRequest);
            return getDummyAccountDetailsSoap(acid);
        } catch (Exception e) {
            log.error("SOAP Account Details Error: {}", e.getMessage());
            return getDummyAccountDetailsSoap(acid);
        }
    }

    @Override
    public FdModelResponse calculateFdModel(FdModelRequest request) {
        log.info("Calculating FD via SOAP for amount: {}", request.getAmountValue());
        
        String reqId = UUID.randomUUID().toString().substring(0, 8);
        String soapRequest = buildModelDepositSoapRequest(request, reqId);
        
        try {
            com.indusind.trade.fd.utils.SslTrustUtils.trustAllSSL();
            String responseXml = soapFeignClient.executeSoapRequest(soapRequest);
            return parseFdModelResponse(responseXml);
        } catch (Exception e) {
            log.error("SOAP FD Model Error: {}", e.getMessage());
            return getDummyFdModelSoap();
        }
    }

    public Object createFd(java.util.Map<String, Object> request) {
        log.info("Creating FD via SOAP (td-add-account)");
        String reqId = "IDTFD_" + UUID.randomUUID().toString().substring(0, 8);
        String soapRequest = buildTDAcctAddSoapRequest(request, reqId);
        
        try {
            com.indusind.trade.fd.utils.SslTrustUtils.trustAllSSL();
            String responseXml = soapFeignClient.executeSoapRequest(soapRequest);
            return parseCreateFdResponse(responseXml);
        } catch (Exception e) {
            log.error("SOAP Create FD Error: {}", e.getMessage());
            java.util.Map<String, String> errResponse = new java.util.HashMap<>();
            errResponse.put("responseCode", "99");
            errResponse.put("responseDesc", "System Error");
            return errResponse;
        }
    }

    private String buildAccountDetailsSoapRequest(String acid, String reqId, CommonRequest common) {
        // pattern from AccountService SoapAdapter
        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">\n" +
                " <soapenv:Header/>\n" +
                " <soapenv:Body>\n" +
                "  <web:executeService>\n" +
                "   <arg_0_0><![CDATA[\n" +
                "   <?xml version=\"1.0\"?><FIXML ...><Header><RequestHeader><MessageKey><RequestUUID>" + reqId + "</RequestUUID><ServiceRequestId>executeFinacleScript</ServiceRequestId></MessageKey></RequestHeader></Header>\n" +
                "   <Body><executeFinacleScriptRequest><executeFinacleScriptInputVO><requestId>IBL0210JOINTHmn001.scr</requestId><customData><acid>" + acid + "</acid></customData></executeFinacleScriptInputVO></executeFinacleScriptRequest></Body></FIXML>\n" +
                "   ]]>\n" +
                "   </arg_0_0>\n" +
                "  </web:executeService>\n" +
                " </soapenv:Body>\n" +
                "</soapenv:Envelope>";
    }

    private String buildModelDepositSoapRequest(FdModelRequest request, String reqId) {
        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">\n" +
                " <soapenv:Header/>\n" +
                " <soapenv:Body>\n" +
                "  <web:executeService>\n" +
                "   <arg_0_0><![CDATA[\n" +
                "   <FIXML xmlns=\"http://www.finacle.com/fixml\"><Header><RequestHeader><MessageKey><RequestUUID>" + reqId + "</RequestUUID><ServiceRequestId>modelDeposit</ServiceRequestId><ChannelId>COR</ChannelId></MessageKey></RequestHeader></Header>\n" +
                "   <Body><modelDepositRequest><amount>" + request.getAmountValue() + "</amount><currency>" + request.getCurrencyCode() + "</currency></modelDepositRequest></Body></FIXML>\n" +
                "   ]]>\n" +
                "   </arg_0_0>\n" +
                "  </web:executeService>\n" +
                " </soapenv:Body>\n" +
                "</soapenv:Envelope>";
    }

    private String buildFetchFDSoapRequest(FdSummaryRequest request, String reqId) {
        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">\n" +
                " <soapenv:Header/>\n" +
                " <soapenv:Body>\n" +
                "  <web:executeService>\n" +
                "   <arg_0_0><![CDATA[\n" +
                "   <FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml executeFinacleScript.xsd\" xmlns=\"http://www.finacle.com/fixml\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                "<Header>\n" +
                "<RequestHeader>\n" +
                "<MessageKey>\n" +
                "<RequestUUID>" + reqId + "</RequestUUID>\n" +
                "<ServiceRequestId>executeFinacleScript</ServiceRequestId>\n" +
                "<ServiceRequestVersion>10.2</ServiceRequestVersion>\n" +
                "<ChannelId>COR</ChannelId>\n" +
                "<LanguageId></LanguageId>\n" +
                "</MessageKey>\n" +
                "<RequestMessageInfo>\n" +
                "<BankId></BankId>\n" +
                "<TimeZone></TimeZone>\n" +
                "<EntityId></EntityId>\n" +
                "<EntityType></EntityType>\n" +
                "<ArmCorrelationId></ArmCorrelationId>\n" +
                "<MessageDateTime>2025-07-010T10:42:00.420</MessageDateTime>\n" +
                "</RequestMessageInfo>\n" +
                "<Security>\n" +
                "<Token>\n" +
                "<PasswordToken>\n" +
                "<UserId></UserId>\n" +
                "<Password></Password>\n" +
                "</PasswordToken>\n" +
                "</Token>\n" +
                "<FICertToken></FICertToken>\n" +
                "<RealUserLoginSessionId></RealUserLoginSessionId>\n" +
                "<RealUser></RealUser>\n" +
                "<RealUserPwd></RealUserPwd>\n" +
                "<SSOTransferToken></SSOTransferToken>\n" +
                "</Security>\n" +
                "</RequestHeader>\n" +
                "</Header>\n" +
                "<Body>\n" +
                "<executeFinacleScriptRequest>\n" +
                "<ExecuteFinacleScriptInputVO>\n" +
                "<requestId>IBL0210FDSMmn001.scr</requestId>\n" +
                "</ExecuteFinacleScriptInputVO>\n" +
                "<executeFinacleScript_CustomData>\n" +
                "<CIF_ID>" + request.getCifId() + "</CIF_ID>\n" +
                "<AcctId>" + (request.getAccountNumber() != null ? request.getAccountNumber() : "") + "</AcctId>\n" +
                "</executeFinacleScript_CustomData>\n" +
                "</executeFinacleScriptRequest>\n" +
                "</Body>\n" +
                "</FIXML>]]>\n" +
                "   </arg_0_0>\n" +
                "  </web:executeService>\n" +
                " </soapenv:Body>\n" +
                "</soapenv:Envelope>";
    }

    public FdSummaryResponse fetchFdSummary(FdSummaryRequest request) {
        log.info("Fetching FD summary via SOAP (IBL0210FDSMmn001.scr) for CIF: {}", request.getCifId());
        String reqId = "IDTFD_" + UUID.randomUUID().toString().substring(0, 8);
        String soapRequest = buildFetchFDSoapRequest(request, reqId);

        try {
            com.indusind.trade.fd.utils.SslTrustUtils.trustAllSSL();
            String responseXml = soapFeignClient.executeSoapRequest(soapRequest);
            return parseFdSummaryResponse(responseXml);
        } catch (Exception e) {
            log.error("SOAP FD Summary Error: {}", e.getMessage());
            return FdSummaryResponse.builder()
                    .responseCode("99")
                    .responseDesc("FD Summary Fetch Error: " + e.getMessage())
                    .fdDetails(new ArrayList<>())
                    .build();
        }
    }

    private FdSummaryResponse parseFdSummaryResponse(String xmlResponse) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new InputSource(new StringReader(xmlResponse)));

        FdSummaryResponse response = new FdSummaryResponse();
        response.setFdDetails(new ArrayList<>());

        NodeList errList = doc.getElementsByTagName("ErrorCode");
        if (errList.getLength() > 0) {
            response.setResponseCode(errList.item(0).getTextContent());
            NodeList descList = doc.getElementsByTagName("ErrorDesc");
            if (descList.getLength() > 0) response.setResponseDesc(descList.item(0).getTextContent());
            return response;
        }

        response.setResponseCode("00");
        response.setResponseDesc("Success");

        NodeList records = doc.getElementsByTagName("executeFinacleScript_CustomData"); 
        if (records.getLength() == 0) records = doc.getElementsByTagName("ResultSet");

        for (int i = 0; i < records.getLength(); i++) {
            Map<String, Object> details = new HashMap<>();
            Element el = (Element) records.item(i);
            NodeList children = el.getChildNodes();
            for (int j = 0; j < children.getLength(); j++) {
                if (children.item(j).getNodeType() == Document.ELEMENT_NODE) {
                    details.put(children.item(j).getNodeName(), children.item(j).getTextContent());
                }
            }
            if (!details.isEmpty()) response.getFdDetails().add(details);
        }

        return response;
    }

    private String buildTDAcctAddSoapRequest(Map<String, Object> request, String reqId) {

        return
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                        "xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">" +
                        "<soapenv:Header/>" +
                        "<soapenv:Body>" +
                        "<web:executeService>" +
                        "<arg_0_0><![CDATA[<FIXML xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\n" +
                        "       xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                        "       xmlns=\"http://www.finacle.com/fixml\">\n" +
                        "\n" +
                        "  <Header>\n" +
                        "    <RequestHeader>\n" +
                        "\n" +
                        "      <MessageKey>\n" +
                        "        <RequestUUID>"+reqId+"</RequestUUID>\n" +
                        "        <ServiceRequestId>TDAcctAdd</ServiceRequestId>\n" +
                        "        <ServiceRequestVersion>10.2</ServiceRequestVersion>\n" +
                        "        <ChannelId>IDC</ChannelId>\n" +
                        "        <LanguageId/>\n" +
                        "      </MessageKey>\n" +
                        "\n" +
                        "      <RequestMessageInfo>\n" +
                        "        <BankId/>\n" +
                        "        <TimeZone/>\n" +
                        "        <EntityId/>\n" +
                        "        <EntityType/>\n" +
                        "        <ArmCorrelationId/>\n" +
                        "        <MessageDateTime>2020-02-11T18:35:50.063</MessageDateTime>\n" +
                        "      </RequestMessageInfo>\n" +
                        "\n" +
                        "      <Security>\n" +
                        "        <Token>\n" +
                        "          <PasswordToken>\n" +
                        "            <UserId/>\n" +
                        "            <Password/>\n" +
                        "          </PasswordToken>\n" +
                        "        </Token>\n" +
                        "        <FICertToken/>\n" +
                        "        <RealUserLoginSessionId/>\n" +
                        "        <RealUser/>\n" +
                        "        <RealUserPwd/>\n" +
                        "        <SSOTransferToken/>\n" +
                        "      </Security>\n" +
                        "\n" +
                        "    </RequestHeader>\n" +
                        "  </Header>\n" +
                        "\n" +
                        "  <Body>\n" +
                        "\n" +
                        "    <TDAcctAddRequest>\n" +
                        "      <TDAcctAddRq>\n" +
                        "        <CustId>\n" +
                        "          <CustId>"+ request.get("cif") +"</CustId>\n" +
                        "        </CustId>\n" +
                        "\n" +
                        "        <!-- TD Account Identification -->\n" +
                        "        <TDAcctId>\n" +
                        "          <AcctType>\n" +
                        "            <AcctId>"+request.get("account")+"</AcctId>\n" +
                        "            <SchmCode>TRGEN</SchmCode>\n" +
                        "          </AcctType>\n" +
                        "          <AcctCurr>"+request.get("currency")+"</AcctCurr>\n" +
                        "        </TDAcctId>\n" +
                        "\n" +
                        "        <!-- General Account Info -->\n" +
                        "        <TDAcctGenInfo>\n" +
                        "          <GenLedgerSubHead>\n" +
                        "            <GenLedgerSubHeadCode/>\n" +
                        "            <CurCode>"+request.get("currency")+"</CurCode>\n" +
                        "          </GenLedgerSubHead>\n" +
                        "          <ModeOfOper>13</ModeOfOper>\n" +
                        "          <AcctName>NITIN TIWARI</AcctName>\n" +
                        "          <AcctShortName>NITIN TIWA</AcctShortName>\n" +
                        "          <AcctStmtMode>N</AcctStmtMode>\n" +
                        "          <DespatchMode>N</DespatchMode>\n" +
                        "        </TDAcctGenInfo>\n" +
                        "\n" +
                        "        <!-- Initial Deposit -->\n" +
                        "        <InitialDeposit>\n" +
                        "          <amountValue>"+request.get("amount")+"</amountValue>\n" +
                        "          <currencyCode>"+request.get("currency")+"</currencyCode>\n" +
                        "        </InitialDeposit>\n" +
                        "\n" +
                        "        <!-- Deposit Tenure -->\n" +
                        "        <DepositTerm>\n" +
                        "          <Days>"+((Map)request.get("tenure")).get("days") +"</Days>\n" +
                        "          <Months>"+
        (Integer.parseInt(((Map)request.get("tenure")).get("years").toString()) * 12 +
                Integer.parseInt(((Map)request.get("tenure")).get("months").toString())) +"</Months>\n" +
                        "        </DepositTerm>\n" +
                        "\n" +
                        "        <!-- Repayment Account -->\n" +
                        "        <RepayAcctId>\n" +
                        "          <AcctId>"+request.get("account")+"</AcctId>\n" +
                        "          <AcctCurr/>\n" +
                        "        </RepayAcctId>\n" +
                        "\n" +
                        "        <!-- Transaction Details -->\n" +
                        "        <TrnDtls>\n" +
                        "          <TrnType>T</TrnType>\n" +
                        "          <TrnSubType>CI</TrnSubType>\n" +
                        "\n" +
                        "          <DebitAcctId>\n" +
                        "            <AcctId>"+ request.get("account")+"</AcctId>\n" +
                        "            <AcctType>\n" +
                        "              <SchmCode>TRGEN</SchmCode>\n" +
                        "              <SchmType>TDA</SchmType>\n" +
                        "            </AcctType>\n" +
                        "            <AcctCurr>"+ request.get("currency") +"</AcctCurr>\n" +
                        "            <BankInfo>\n" +
                        "              <BankId>01</BankId>\n" +
                        "            </BankInfo>\n" +
                        "          </DebitAcctId>\n" +
                        "        </TrnDtls>\n" +
                        "\n" +
                        "        <!-- Custom Bank Fields -->\n" +
                        "        <TDAcctAdd_CustomData>\n" +
                        "          <SOLID>0022</SOLID>\n" +
                        "          <XFERINDCODE>O</XFERINDCODE>\n" +
                        "          <TRANCREMODE>O</TRANCREMODE>\n" +
                        "          <FREETEXT15/>\n" +
                        "          <MODEOFOPER>13</MODEOFOPER>\n" +
                        "          <OUTFLOWMULTAMT>0</OUTFLOWMULTAMT>\n" +
                        "          <INTTBLCD>TBGEN</INTTBLCD>\n" +
                        "          <FREECODE8/>\n" +
                        "          <MISCFLG>1</MISCFLG>\n" +
                        "        </TDAcctAdd_CustomData>\n" +
                        "\n" +
                        "        <!-- Renewal Instructions -->\n" +
                        "        <RenewalDtls>\n" +
                        "          <IntTblCode>TBGEN</IntTblCode>\n" +
                        "          <AutoCloseOnMaturityFlg>Y</AutoCloseOnMaturityFlg>\n" +
                        "          <AutoRenewalflg>N</AutoRenewalflg>\n" +
                        "        </RenewalDtls>\n" +
                        "\n" +
                        "      </TDAcctAddRq>\n" +
                        "    </TDAcctAddRequest>\n" +
                        "\n" +
                        "  </Body>\n" +
                        "\n" +
                        "</FIXML>\n" +
                        "]]></arg_0_0>" +
                        "</web:executeService>" +
                        "</soapenv:Body>" +
                        "</soapenv:Envelope>";
    }

    private FdModelResponse parseFdModelResponse(String xmlResponse) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new InputSource(new StringReader(xmlResponse)));

        NodeList errList = doc.getElementsByTagName("ErrorCode");
        if (errList.getLength() > 0) {
           String code = errList.item(0).getTextContent();
           String desc = "";
           NodeList descList = doc.getElementsByTagName("ErrorDesc");
           if (descList.getLength() > 0) desc = descList.item(0).getTextContent();
           throw new RuntimeException("ErrorCode: " + code + ", ErrorDesc: " + desc);
        }

        FdModelResponse resp = new FdModelResponse();
        resp.setStatus("SUCCESS");

        NodeList interestAmtNode = doc.getElementsByTagName("interestAmount");
        if (interestAmtNode.getLength() > 0) {
             NodeList amtValNode = ((Element)interestAmtNode.item(0)).getElementsByTagName("amountValue");
             if (amtValNode.getLength() > 0) {
                  resp.setInterestRates(amtValNode.item(0).getTextContent()); // Dummy map to interestAmount for now
             }
        }
        NodeList intRateNode = doc.getElementsByTagName("interestRate");
        if (intRateNode.getLength() > 0) {
             resp.setInterestRates(intRateNode.item(0).getTextContent());
        }

        return resp;
    }

    private Object parseCreateFdResponse(String xmlResponse) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new InputSource(new StringReader(xmlResponse)));

        java.util.Map<String, String> response = new java.util.HashMap<>();

        NodeList errList = doc.getElementsByTagName("ErrorCode");
        if (errList.getLength() > 0) {
           String code = errList.item(0).getTextContent();
           String desc = "";
           NodeList descList = doc.getElementsByTagName("ErrorDesc");
           if (descList.getLength() > 0) desc = descList.item(0).getTextContent();
           response.put("responseCode", code);
           response.put("responseDesc", desc);
           return response;
        }

        NodeList acctIdNode = doc.getElementsByTagName("AcctId");
        if (acctIdNode.getLength() > 0) {
             response.put("responseCode", "00");
             response.put("responseDesc", "Fixed Deposit Created Successfully");
             response.put("fdAccountNumber", acctIdNode.item(0).getTextContent());
             return response;
        }

        response.put("responseCode", "99");
        response.put("responseDesc", "Unknown response format");
        return response;
    }

    private AccountDetailsResponse getDummyAccountDetailsSoap(String acid) {
        AccountDetailsResponse resp = new AccountDetailsResponse();
        resp.setResponseCode("R000");
        resp.setResponseDesc("Success (SOAP MOCK)");
        resp.setListAcno(new ArrayList<>());
        AccountDetailsResponse.MappedAccount acc = new AccountDetailsResponse.MappedAccount();
        acc.setAcctName("ABC CORP - SOAP MOCK");
        acc.setAcno(acid);
        acc.setIsMapped("1");
        resp.getListAcno().add(acc);
        return resp;
    }

    private FdModelResponse getDummyFdModelSoap() {
        FdModelResponse resp = new FdModelResponse();
        resp.setStatus("SUCCESS");
        resp.setInterestRates("7.10"); // Different rate for SOAP mock
        return resp;
    }

    private OtpResponse getDummyOtpResponseSoap() {
        OtpResponse resp = new OtpResponse();
        resp.setErrorCode("00");
        resp.setOtpHint("9999");
        resp.setAction("SOAP_STATE_MOCK_123");
        return resp;
    }

    private OtpVerifyResponse getDummyOtpVerifyResponseSoap() {
        OtpVerifyResponse resp = new OtpVerifyResponse();
        resp.setResponseCode("00");
        resp.setResponseDesc("Verified via SOAP Mock");
        return resp;
    }
}
