package com.indusind.trade.fd.client;

import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import com.indusind.trade.fd.dto.AccountDetailsResponse;
import com.indusind.trade.fd.dto.OtpResponse;
import com.indusind.trade.fd.dto.OtpVerifyResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "fetch-fd-account-json-client", url = "${app.bank.api.json.gateway-url}")
public interface FetchFDAccountFeignClient {

    @PostMapping(value = "/indie/getcustomeraccounts/cifid/V1",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    IBLGatewayResponse fetchAccountsByCifId(
            @RequestHeader("IBL-Client-Id") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody String encryptedEnvelope);


}
