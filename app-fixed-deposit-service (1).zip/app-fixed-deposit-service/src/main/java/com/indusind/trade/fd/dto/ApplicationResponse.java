package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationResponse {

    private String status;
    private Object payload;
    private String description;

    @Override
    public String toString() {
        return "ApplicationResponse [status=" + status + ", payload=" + payload + ", description=" + description + "]";
    }
}
