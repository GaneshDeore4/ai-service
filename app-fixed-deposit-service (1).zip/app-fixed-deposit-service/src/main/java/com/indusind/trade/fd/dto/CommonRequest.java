package com.indusind.trade.fd.dto;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
public class CommonRequest {
    private String appType;
    private String appVersion;
    private String authProduct;
    private String com_ImeiNo;
    private String customerId;
    private String deviceId;
    private String deviceModel;
    private String deviceName;
    private String deviceOS;
    private String deviceType;
    private String isUsrLoggedIn;
    private String platform;
    private String requestType;
    private String token;
    private String userCode;
    private String userId;
    private String userRole;
}
