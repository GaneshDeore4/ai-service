package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(setterPrefix = "set")
public class FDInterestRatesReqDto {

    private String cifId;

    @Builder.Default private String currencyCode = "INR";
    @Builder.Default private String daysInAYear = "365";
    private String amountValue;
    @Builder.Default private String channelId = "COR";


    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    @Builder.Default
    private LocalDateTime depositDate = LocalDateTime.now();

    private String days;
    private String months;
    @Builder.Default private String depositType = "T";
    @Builder.Default private String flowType = "I";
    @Builder.Default private String monthsInAYear = "12";
    @Builder.Default private String pegFlag = "Y";
    @Builder.Default private String schmCode = "TRGEN";
    @Builder.Default private String schmType = "TDA";
}