package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FDInterestRatesRespDto {

    /*private String status;





    private String errorCode;
    private String errorMessage;*/
    private String interestRate;
    private String maturityAmount;
    private String currency;
    private String interestAmount;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDate maturityDate;

    @JsonProperty("response")
    private Response response;

    // ===================== Response =====================
    @Data
    @Builder
    public static class Response {
        private Header header;
        private Body body;
    }

    // ===================== Header =====================
    @Data
    @Builder
    public static class Header {
        private String requestUUID;
        private String channelId;
        private String status;
    }

    // ===================== Body =====================
    @Data
    public static class Body {

        @JsonProperty("FDModelDepositResponse")
        private FDModelDepositResponse fdModelDepositResponse;
    }

    // ===================== FDModelDepositResponse =====================
    @Data
    public static class FDModelDepositResponse {

        private String brknPerdIntBase;
        private String brknPerdIntMthd;
        private String compoundFreqPerdDays;
        private String compoundFreqPerdMonths;
        private String currencyCode;
        private String daysInAYear;
        private String depositAmount;
        private String depositDate;
        private String depositPeriodDays;
        private String depositPeriodMonths;
        private String instlmntFreqPerdDays;
        private String instlmntFreqPerdMonths;
        private String interestAmount;
        private String interestTableCode;
        private String interestMethod;
        private String interestRate;
        private String leapYearAdjstmntDays;
        private String maturityAmt;
        private String maturityDate;
        private String monthsInAYear;
        private String pegFlag;
        private String resultStr;
        private String resultType;
        private String schmCode;
        private String schmType;

        @Override
        public String toString() {
            return "FDModelDepositResponse{" +
                    "currencyCode='" + currencyCode + '\'' +
                    ", depositAmount='" + depositAmount + '\'' +
                    ", interestRate='" + interestRate + '\'' +
                    ", interestAmount='" + interestAmount + '\'' +
                    ", maturityAmt='" + maturityAmt + '\'' +
                    ", maturityDate='" + maturityDate + '\'' +
                    ", depositDate='" + depositDate + '\'' +
                    ", depositPeriodMonths='" + depositPeriodMonths + '\'' +
                    ", depositPeriodDays='" + depositPeriodDays + '\'' +
                    ", schmCode='" + schmCode + '\'' +
                    ", schmType='" + schmType + '\'' +
                    '}';
        }

    }


    public static FDInterestRatesRespDto failureResponse(String requestUUID, String channelId) {
        return FDInterestRatesRespDto.builder()
                .response(
                        Response.builder()
                                .header(
                                        Header.builder()
                                                .requestUUID(requestUUID)
                                                .channelId(channelId)
                                                .status("FAILURE")
                                                .build()
                                )
                                .build()
                )
                .build();
    }


}
