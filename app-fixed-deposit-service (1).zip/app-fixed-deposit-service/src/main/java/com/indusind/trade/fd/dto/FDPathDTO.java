package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class FDPathDTO {
    private Long authMatrixId;
    private boolean isSequential;
    private boolean selected;
    private List<PathNodeDTO> nodes; 
}
