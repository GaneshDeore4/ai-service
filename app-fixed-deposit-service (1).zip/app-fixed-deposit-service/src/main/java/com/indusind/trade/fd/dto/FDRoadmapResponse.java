package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class FDRoadmapResponse {
    private Integer currentLevel;
    private String fdStatus;
    private List<FDPathDTO> paths;
}