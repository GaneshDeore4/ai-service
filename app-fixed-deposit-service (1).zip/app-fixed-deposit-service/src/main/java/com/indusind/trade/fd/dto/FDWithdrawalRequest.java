package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FDWithdrawalRequest {
    private RequestContainer request;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RequestContainer {
        private Header header;
        private Body body;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Header {
        private String requestUUID;
        private String channelId;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Body {
        @JsonProperty("FDFullWithdrawlRequest")
        private FDFullWithdrawlRequest FDFullWithdrawlRequest;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class FDFullWithdrawlRequest {
        private String acctNum;
        private String repymntAcctId;
        private double amt;
    }
}