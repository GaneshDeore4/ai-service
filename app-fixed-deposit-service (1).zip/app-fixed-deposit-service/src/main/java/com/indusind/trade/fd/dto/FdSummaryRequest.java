package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FdSummaryRequest {
    private String cifId;
    private String accountNumber;
}
