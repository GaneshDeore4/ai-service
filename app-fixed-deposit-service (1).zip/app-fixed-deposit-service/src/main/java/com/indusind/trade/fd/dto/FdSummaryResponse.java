package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FdSummaryResponse {
    private String responseCode;
    private String responseDesc;
    private List<Map<String, Object>> fdDetails;
}
