package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
public class GetFDByStatusRequestDto {
    private List<String> status;
    private String cifId;
}
