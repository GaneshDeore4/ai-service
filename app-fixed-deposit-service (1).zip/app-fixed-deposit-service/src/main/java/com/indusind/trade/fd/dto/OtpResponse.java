package com.indusind.trade.fd.dto;

import lombok.Data;

@Data
public class OtpResponse {
    private String otpHint;
    private String sentTo;
    private String errorMsg;
    private String errorCode;
    private String mechanism;
    private String action;
}
