package com.indusind.trade.fd.dto;

import lombok.Data;

@Data
public class OtpVerifyResponse {
    private String responseCode;
    private String responseDesc;
}
