package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PathNodeDTO {
    private Integer level;
    private Long groupId;
    private String groupName;
    private String state;
    private boolean isActive;
    private boolean isCurrent;
}
