package com.indusind.trade.fd.dto.request_wrapper;

import com.indusind.trade.fd.dto.request_wrapper.create_fd.FDBookingRequestWrapper;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class Request {

    private Header header;
    private FDBookingRequestWrapper body;

}
