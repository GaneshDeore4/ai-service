package com.indusind.trade.fd.dto.request_wrapper.create_fd;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class NomineeDTO {

    private String addr1;
    private String city;
    private String stateProv;
    private String postalCode;
    private String country;

}
