package com.indusind.trade.fd.dto.response_wrapper;

import com.indusind.trade.fd.dto.response_wrapper.create_fd.FDBookingResponseDTO;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class Response {

    private String requestUUID;
    private String channelId;
    private String status;
    private FDBookingResponseDTO body;
    private Error error;

}
