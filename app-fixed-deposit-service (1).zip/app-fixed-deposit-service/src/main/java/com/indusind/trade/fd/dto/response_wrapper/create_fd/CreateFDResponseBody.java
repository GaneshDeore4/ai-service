package com.indusind.trade.fd.dto.response_wrapper.create_fd;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
public class CreateFDResponseBody {

    private FDBookingResponseDTO FDBookingResponse;
}
