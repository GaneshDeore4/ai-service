package com.indusind.trade.fd.dto.response_wrapper.create_fd;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class Error {

    private String errorCode;
    private String errorDesc;
}
