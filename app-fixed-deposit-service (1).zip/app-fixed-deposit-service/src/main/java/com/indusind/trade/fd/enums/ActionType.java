package com.indusind.trade.fd.enums;

public enum ActionType {
    CREATED,

    APPROVED,

    REJECTED,
    REOPENED,
    CLOSED,

    MID_OFFICE_APPROVED,

    MID_OFFICE_REJECTED,

    FD_APPROVED,

    FD_CREATED_AT_FINACLE,

    FD_CREATED_AT_FINACLE_FAILED


}
