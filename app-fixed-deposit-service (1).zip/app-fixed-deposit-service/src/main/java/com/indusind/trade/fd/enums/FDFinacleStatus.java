package com.indusind.trade.fd.enums;

public enum FDFinacleStatus {

    FAILED_AT_FINACLE, CREATED_AT_FINACLE,SUCCESS
}
