package com.indusind.trade.fd.facade;

import com.indusind.trade.fd.dto.ApplicationResponse;
import com.indusind.trade.fd.dto.FDInterestRatesReqDto;
import com.indusind.trade.fd.dto.FDInterestRatesRespDto;
import com.indusind.trade.fd.dto.FixedDepositDto;

public interface FixedDepositFacade {
    FDInterestRatesRespDto calculateFDInterest(FDInterestRatesReqDto fdInterestRatesReqDto);

    ApplicationResponse createFD(FixedDepositDto request);
}
