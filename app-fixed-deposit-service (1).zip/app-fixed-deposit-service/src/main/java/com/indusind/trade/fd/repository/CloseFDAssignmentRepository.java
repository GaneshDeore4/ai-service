package com.indusind.trade.fd.repository;

import com.indusind.trade.fd.entity.CloseFDAssignment;
import com.indusind.trade.fd.entity.FDAssignment;
import com.indusind.trade.fd.enums.AssignmentStatus;
import com.indusind.trade.fd.projection.CheckerTrayProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CloseFDAssignmentRepository extends JpaRepository<CloseFDAssignment, Long> {

    List<CloseFDAssignment> findByFdId(Long fdId);

    @Query("""
                SELECT a FROM FDAssignment a
                WHERE a.fdId = :fdId
                AND a.groupId = :groupId
                AND a.isActive = true
            """)
    List<FDAssignment> findActiveAssignment(Long fdId, Long groupId);


    @Query("""
            SELECT 
            f.id as fdId,
             
            CASE 
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'APPROVED'
                ) THEN 'APPROVED'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'PENDING'
                    AND a.isActive = true
                ) THEN 'PENDING'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'WAITING'
                ) THEN 'WAITING'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'REJECTED'
                ) THEN 'REJECTED'
             
                ELSE 'VIEW ONLY'
            END as status,
             
            f.status as fdStatus,
            f.currentLevel as currentLevel,
            f.accountNumber as accountNumber,
            f.accountNumberHash as accountNumberHash,
            f.amount as amount,
            f.currency as currency,
            f.tenureMonths as tenureMonths,
            f.maturityInstruction as maturityInstruction,
            f.maturityAmount as maturityAmount,
            f.maturityDate as maturityDate,
            f.tenureYears as tenureYears,
            f.tenureDays as tenureDays,
            f.interestRate as interestRate
             
            FROM FixedDeposit f
             
            WHERE EXISTS (
                SELECT 1 FROM FDAssignment a
                WHERE a.fdId = f.id
                AND a.groupId = :groupId
            )
             
            AND f.accountNumberHash IN (
                SELECT acc.accountNumberHash
                FROM User u
                JOIN u.accountMapping acc
                WHERE u.userId = :userId
            )
            """)
    Page<CheckerTrayProjection> findCheckerTray(
            Long userId,
            Long groupId,
            Pageable pageable
    );

    @Query("""
            SELECT
            f.id as fdId,
            
            CASE
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'APPROVED'
            ) THEN 'APPROVED'
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'PENDING'
            AND a.isActive = true
            ) THEN 'PENDING'
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'WAITING'
            ) THEN 'WAITING'
           
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'REJECTED'
            ) THEN 'REJECTED'
            
            ELSE 'VIEW_ONLY'
            
            END as status,
            
            f.status as fdStatus,
            f.currentLevel as currentLevel,
            f.accountNumber as accountNumber,
            f.accountNumberHash as accountNumberHash,
            f.amount as amount,
            f.currency as currency,
            f.tenureMonths as tenureMonths,
            f.maturityInstruction as maturityInstruction,
            f.maturityAmount as maturityAmount,
            f.maturityDate as maturityDate,
            f.tenureYears as tenureYears,
            f.tenureDays as tenureDays,
            f.interestRate as interestRate
            FROM FixedDeposit f
            WHERE EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            )
            AND f.accountNumberHash IN (
            SELECT acc.accountNumberHash
            FROM User u
            JOIN u.accountMapping acc
            WHERE u.userId = :userId
            )
            """)
    Page<CheckerTrayProjection> findReleaserOrVerifierTray(
            Long userId,
            String roleName,
            Pageable pageable
    );

    List<FDAssignment> findByFdIdOrderByLevel(Long fdId);

    List<FDAssignment> findByFdIdAndStatus(Long fdId, AssignmentStatus status);


}
