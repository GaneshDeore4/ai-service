package com.indusind.trade.fd.repository;

import com.indusind.trade.fd.entity.CloseFixedDeposit;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.model.dtos.projection.MidOfficeCountProjection;
import com.indusind.trade.model.utility.HashUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CloseFixedDepositRepository extends JpaRepository<CloseFixedDeposit, Long> {


    Optional<CloseFixedDeposit> findByStateId(String stateId);

    Page<CloseFixedDeposit> findByMakerId(Long makerId, Pageable pageable);

    default Page<CloseFixedDeposit> findByCifId(String cifId, Pageable pageable) {
        return findByCifIdHash(HashUtils.HAMCMD5Hash(cifId), pageable);
    }

    Page<CloseFixedDeposit> findByCifIdHash(String cifId, Pageable pageable);

    @Query("""
        SELECT 
            SUM(CASE WHEN f.status = 'PENDING_AT_MID_OFFICE' THEN 1 ELSE 0 END) AS pendingAtBank,
            SUM(CASE WHEN f.status IN ('IN_APPROVAL','REJECTED', 'MID_OFFICE_REJECTED') THEN 1 ELSE 0 END) AS pendingAtClient,
            SUM(CASE WHEN f.status = 'MID_OFFICE_APPROVED' AND f.isMidOfficeApproved = true THEN 1 ELSE 0 END) AS processedByBank,
            SUM(CASE WHEN f.status = 'APPROVED' AND (f.isMidOfficeApproved = false OR f.isMidOfficeApproved IS NULL) THEN 1 ELSE 0 END) AS processedByClient
        FROM CloseFixedDeposit f
        """)
    MidOfficeCountProjection getMidOfficeCounts();


    Page<CloseFixedDeposit> findAllByStatusIn(List<String> status, Pageable page);

}
