package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.*;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface CloseFDService {

    public void approve(Long fdId,
                        Long userId,
                        String loginId,
                        String userName,
                        Long groupId,
                        String groupName,
                        String roleName,
                        boolean midOffice);

    // REJECT
    void reject(Long fdId, Long userId, String loginId,String userName, Long groupId, String reason);

    // REOPEN
    void reopen(FixedDepositDto updated);


    // MAKER TRAY
    Page<MakerTrayDTO> getMakerTray(Long makerId, Pageable pageable);

    // CHECKER TRAY
    Page<CheckerFDTrayDTO> getCheckerTray(Long userId, Long groupId, Pageable pageable);

   // Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTray(Long userId, String groupName, Pageable pageable);


    void approveFdMidOffice(Long fdId, Long midOfficeId, String midOfficeLoginId, String midOfficeUserName);

    void rejectFdMidOffice(Long fdId, Long midOfficeId, String midOfficeLoginId,String midOfficeUserName);

    Page<FdActionAuditsDto> getFDAuditsByFdId(Long fdId, Pageable page);

    void closeFD(CloseFDDto fd);

}
