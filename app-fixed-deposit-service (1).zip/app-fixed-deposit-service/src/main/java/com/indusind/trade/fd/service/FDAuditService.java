package com.indusind.trade.fd.service;

public interface FDAuditService {
    void saveAudit(String cifId, String action, String details, String status, String userCode);
}
