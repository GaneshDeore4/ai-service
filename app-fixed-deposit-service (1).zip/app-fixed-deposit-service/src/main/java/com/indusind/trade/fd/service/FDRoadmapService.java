package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.FDRoadmapResponse;

public interface FDRoadmapService {
    FDRoadmapResponse getRoadmap(Long fdId);
}
