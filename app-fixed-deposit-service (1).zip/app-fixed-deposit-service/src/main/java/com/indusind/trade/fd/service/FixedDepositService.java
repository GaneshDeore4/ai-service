package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.*;
import com.indusind.trade.fd.entity.FixedDeposit;

public interface FixedDepositService {
    AccountDetailsResponse getAccountDetails(String acid, CommonRequest common);
    FdModelResponse calculateFdInterest(FdModelRequest request);
    Object createFd(java.util.Map<String, Object> request);
    FdSummaryResponse getFdSummary(FdSummaryRequest request);

    FDInterestRatesRespDto calculateFdInterestJson(FDInterestRatesReqDto request);

    FixedDeposit saveFixedDeposit(FixedDeposit fixedDeposit);
}
