package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.client.FixedDepositSoapFeignClient;
import com.indusind.trade.fd.service.CoreBankingBackendService;
import com.indusind.trade.fd.utils.SslTrustUtils;
import com.indusind.trade.model.common.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;


@Service
@RequiredArgsConstructor
public class CoreBankingBackendServiceImpl implements CoreBankingBackendService {

    private final FixedDepositSoapFeignClient soapFeignClient;

    @Override
    public String callCalculateFDIntgerestSoap(String soapRequest) {

        try {
            SslTrustUtils.trustAllSSL();
            return soapFeignClient.executeSoapRequest(soapRequest);
        } catch (Exception e) {
            throw new GTPAppException(e.getMessage(), e);
        }
    }
}
