package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.dto.FDPathDTO;
import com.indusind.trade.fd.dto.FDRoadmapResponse;
import com.indusind.trade.fd.dto.PathNodeDTO;
import com.indusind.trade.fd.entity.CloseFixedDeposit;
import com.indusind.trade.fd.entity.FDAssignment;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.enums.AssignmentStatus;
import com.indusind.trade.fd.enums.FDStatus;
import com.indusind.trade.fd.enums.NodeType;
import com.indusind.trade.fd.repository.CloseFixedDepositRepository;
import com.indusind.trade.fd.repository.FDAssignmentRepository;
import com.indusind.trade.fd.repository.FixedDepositRepository;
import com.indusind.trade.fd.service.FDRoadmapService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class FDRoadmapServiceImpl implements FDRoadmapService {
    private final FixedDepositRepository fdRepo;
    private final FDAssignmentRepository assignmentRepo;
    private final CloseFixedDepositRepository clfs;

    @Override
    public FDRoadmapResponse getRoadmap(Long fdId) {

        FixedDeposit fd = fdRepo.findById(fdId).orElseGet(() -> {
            CloseFixedDeposit cls = clfs.findById(fdId)
                    .orElseThrow(() -> new RuntimeException("Fixed Deposit record not found for ID: " + fdId));
            FixedDeposit shadow = new FixedDeposit();
            shadow.setId(cls.getId());
            shadow.setAuthMatrixId(cls.getAuthMatrixId());
            shadow.setCurrentLevel(cls.getCurrentLevel());

            if (cls.getStatus() != null) {
                shadow.setStatus(FDStatus.valueOf(String.valueOf(cls.getStatus())));
            }
            return shadow;
        });

        List<FDAssignment> all =
                assignmentRepo.findByFdIdOrderByLevel(fdId);

        Map<Long, List<FDAssignment>> grouped =
                all.stream().collect(Collectors.groupingBy(FDAssignment::getAuthMatrixId));
        List<FDPathDTO> paths = new ArrayList<>();
        for (Map.Entry<Long, List<FDAssignment>> entry : grouped.entrySet()) {
            Long matrixId = entry.getKey();
            List<FDAssignment> list = entry.getValue();


            boolean selected =
                    fd.getAuthMatrixId() != null &&
                            fd.getAuthMatrixId().equals(matrixId);
         
            List<PathNodeDTO> nodes = list.stream()
                    .sorted(Comparator.comparing(FDAssignment::getLevel))
                    .map(a -> mapNode(a, fd, selected))
                    .toList();
            paths.add(new FDPathDTO(
                    matrixId,
                    Boolean.TRUE.equals(list.get(0).getIsSequential()),
                    selected,
                    nodes
            ));
        }
        return new FDRoadmapResponse(
                fd.getCurrentLevel(),
                fd.getStatus().name(),
                paths
        );
    }
    // NODE MAPPING
    private PathNodeDTO mapNode(FDAssignment a,
                                FixedDeposit fd,
                                boolean isSelectedPath) {
        String displayName = resolveName(a);
        AssignmentStatus finalStatus = resolveFinalStatus(a, fd, isSelectedPath);
        boolean active = isActive(a, fd, isSelectedPath, finalStatus);
        boolean current = isCurrent(a, fd, active);
        return new PathNodeDTO(
                a.getLevel(),
                a.getGroupId(),
                displayName,
                finalStatus.name(),
                active,
                current
        );
    }
    // STATUS RESOLUTION
    private AssignmentStatus resolveFinalStatus(FDAssignment a,
                                                FixedDeposit fd,
                                                boolean isSelectedPath) {
        // If path is not selected → everything becomes view only (except history)
        if (fd.getAuthMatrixId() != null && !isSelectedPath) {
            if (a.getStatus() == AssignmentStatus.APPROVED
                    || a.getStatus() == AssignmentStatus.REJECTED) {
                return a.getStatus(); // keep history
            }
            return AssignmentStatus.VIEW_ONLY;
        }
        // FD Final States
        if (fd.getStatus() == FDStatus.APPROVED
                || fd.getStatus() == FDStatus.PENDING_AT_MID_OFFICE) {
            if (a.getStatus() != AssignmentStatus.APPROVED) {
                return AssignmentStatus.VIEW_ONLY;
            }
        }
        if (fd.getStatus() == FDStatus.REJECTED) {
            if (a.getStatus() != AssignmentStatus.APPROVED
                    && a.getStatus() != AssignmentStatus.REJECTED) {
                return AssignmentStatus.VIEW_ONLY;
            }
        }
        return a.getStatus();
    }
    // ACTIVE LOGIC
    private boolean isActive(FDAssignment a,
                             FixedDeposit fd,
                             boolean isSelectedPath,
                             AssignmentStatus finalStatus) {
        if (finalStatus != AssignmentStatus.PENDING) return false;
        // If path already selected → only that path is active
        if (fd.getAuthMatrixId() != null && !isSelectedPath) {
            return false;
        }
        return Boolean.TRUE.equals(a.getIsActive());
    }
    // CURRENT NODE
    private boolean isCurrent(FDAssignment a,
                              FixedDeposit fd,
                              boolean active) {
        if (!active) return false;
        // Verifier / Releaser always current if active
        if (a.getNodeType() == NodeType.VERIFIER
                || a.getNodeType() == NodeType.RELEASER) {
            return true;
        }
        // Sequential → match level
        if (Boolean.TRUE.equals(a.getIsSequential())) {
            return fd.getCurrentLevel() != null
                    && fd.getCurrentLevel().equals(a.getLevel());
        }
        // Non-sequential → all active are current
        return true;
    }
    //  NAME RESOLUTION
    private String resolveName(FDAssignment a) {
        if (a.getNodeType() == NodeType.VERIFIER) {
            return "Client Verifier";
        }
        if (a.getNodeType() == NodeType.RELEASER) {
            return "Client Releaser";
        }
        return a.getGroupName();
    }
}
