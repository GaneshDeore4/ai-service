package com.indusind.trade.fd.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import com.indusind.app.jose.constant.InputType;
import com.indusind.app.jose.operations.JoseHelper;
import com.indusind.app.jose.operations.JoseUtility;
import com.indusind.trade.fd.client.FDWithdrawalClient;
import com.indusind.trade.fd.dto.FDWithdrawalRequest;
import com.indusind.trade.fd.dto.FDWithdrawalResponse;
import com.indusind.trade.fd.service.FDWithdrawalService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class FDWithdrawalServiceImpl implements FDWithdrawalService {

    private final FDWithdrawalClient fdWithdrawalClient;
    private final ObjectMapper objectMapper;
    private final JoseHelper joseHelper;

    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    @Override
    public FDWithdrawalResponse initiateFullWithdrawal(String acctNum, String repaymentAcctId, double amount) {
        log.info("Inside initiateFullWithdrawal");

        FDWithdrawalRequest.Header header = FDWithdrawalRequest.Header.builder()
                .requestUUID(UUID.randomUUID().toString())
                .channelId("COR")
                .build();

        FDWithdrawalRequest.FDFullWithdrawlRequest bodyContent = FDWithdrawalRequest.FDFullWithdrawlRequest.builder()
                .acctNum(acctNum)
                .repymntAcctId(repaymentAcctId)
                .amt(amount)
                .build();

        FDWithdrawalRequest request = FDWithdrawalRequest.builder()
                .request(FDWithdrawalRequest.RequestContainer.builder()
                        .header(header)
                        .body(FDWithdrawalRequest.Body.builder()
                                .FDFullWithdrawlRequest(bodyContent)
                                .build())
                        .build())
                .build();

        JoseUtility ju = joseHelper.getJoseUtility();

        try {
            String requestJson = objectMapper.writeValueAsString(request);
            log.info("Plain FD full withdrawal request: {}", requestJson);

            String encryptedEnvelope = ju.createIblGatewayRequestString(null, requestJson, InputType.STRING);
            log.debug("Encrypted FD full withdrawal envelope: {}", encryptedEnvelope);

            IBLGatewayResponse encryptedResponse = fdWithdrawalClient.fullWithdrawal(clientId, clientSecret, encryptedEnvelope);

            if (encryptedResponse == null || encryptedResponse.getData() == null) {
                throw new RuntimeException("Empty encrypted response from bank");
            }

            return ju.getPayloadFromResponseObject(
                    null, encryptedResponse.getData(), FDWithdrawalResponse.class, InputType.STRING);

        } catch (Exception e) {
            log.error("Error calling Full Withdrawal API: {}", e.getMessage(), e);
            throw new RuntimeException("FD full withdrawal API error", e);
        }
    }
}
