package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.adapter.FixedDepositAdapter;
import com.indusind.trade.fd.adapter.FixedDepositJsonAdapter;
import com.indusind.trade.fd.dto.*;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.entity.FixedDepositAudit;
import com.indusind.trade.fd.repository.FixedDepositAuditRepository;
import com.indusind.trade.fd.repository.FixedDepositRepository;
import com.indusind.trade.fd.service.FixedDepositService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class FixedDepositServiceImpl implements FixedDepositService {

    private final FixedDepositAdapter fixedDepositAdapter;
    private final FixedDepositRepository fixedDepositRepository;
    private final FixedDepositAuditRepository fixedDepositAuditRepository;
    private final FixedDepositJsonAdapter fixedDepositJsonAdapter;

    @Override
    public AccountDetailsResponse getAccountDetails(String acid, CommonRequest common) {
    	
        AccountDetailsResponse response = fixedDepositAdapter.fetchAccountDetails(acid, common);
        
        saveAudit(common.getCustomerId(), "ACCOUNT_DETAILS_FETCH", "Fetched details for " + acid, "SUCCESS", common.getUserCode());

        return response;
    }

    @Override
    public FdModelResponse calculateFdInterest(FdModelRequest request) {
        FdModelResponse response = fixedDepositAdapter.calculateFdModel(request);
        saveAudit(request.getCustomerId(), "FD_CALCULATE", "Calculated for amount: " + request.getAmountValue(), "SUCCESS", request.getUserCode());

        return response;
    }

    @Override
    public FDInterestRatesRespDto calculateFdInterestJson(FDInterestRatesReqDto request) {
        FDInterestRatesRespDto response = fixedDepositJsonAdapter.calculateFdModel(request);
        //saveAudit(request.getCustomerId(), "FD_CALCULATE", "Calculated for amount: " + request.getAmountValue(), "SUCCESS", request.getUserCode());

        return response;
    }

    @Override
    public FixedDeposit saveFixedDeposit(FixedDeposit fixedDeposit) {
        return fixedDepositRepository.save(fixedDeposit);
    }

    @Override
    public Object createFd(Map<String, Object> payload) {
        // Resolve UI mapping
        String tempAccount = (String) payload.get("account");
        final String accountNumber = tempAccount != null ? tempAccount : (String) payload.get("accountNumber");
        String currency = (String) payload.get("currency");
        Object amountObj = payload.get("amount");
        String amountStr = amountObj != null ? String.valueOf(amountObj) : "0";

        // Defaults for required security/audit contexts missing in UI payload
        String customerId = payload.containsKey("customerId") ? (String) payload.get("customerId") : "35133028";
        String userCode = payload.containsKey("userCode") ? (String) payload.get("userCode") : "UI_USER";
        String stateId = payload.containsKey("action") ? (String) payload.get("action") : java.util.UUID.randomUUID().toString();
        
        // Extract new extended payload fields
        String userId = (String) payload.get("userId");
        String loginId = (String) payload.get("loginId");
        Boolean termsAccepted = (Boolean) payload.get("termsAccepted");
        String interestFreq = (String) payload.get("interestFrequency");
        String maturityInstr = (String) payload.get("maturityInstruction");
        
        Integer tYears = 0, tMonths = 0, tDays = 0;
        if (payload.get("tenure") instanceof Map) {
             Map<String, Object> tMap = (Map<String, Object>) payload.get("tenure");
             tYears = tMap.get("years") != null ? Integer.valueOf(tMap.get("years").toString()) : 0;
             tMonths = tMap.get("months") != null ? Integer.valueOf(tMap.get("months").toString()) : 0;
             tDays = tMap.get("days") != null ? Integer.valueOf(tMap.get("days").toString()) : 0;
        }

        payload.put("amount", amountStr); 
        payload.put("account", accountNumber);
        payload.put("currency", currency != null ? currency : "INR");
        payload.put("customerId", customerId);

        // Step 1: Pre-requisite Call - Fetch Interest Rate
        FdModelRequest fdRequest = FdModelRequest.builder()
                .amountValue(amountStr)
                .currencyCode((String)payload.get("currency"))
                .build();
        
        log.info("Step 1: Calling Interest Rate API (modelDeposit) with payload Amount: {}, Currency: {}", amountStr, payload.get("currency"));
        FdModelResponse intRateResponse = fixedDepositAdapter.calculateFdModel(fdRequest);
        
        log.info("Successfully fetched Interest Rate {}% before FD creation. Response: {}", intRateResponse.getInterestRates(), intRateResponse);

        // Step 2: Create FD
        log.info("Step 2: Calling Create FD API (TDAcctAdd) with payload: {}", payload);
        Object response = fixedDepositAdapter.createFd(payload);
        
        // Parse Success or Failed
        boolean isSuccess = false;
        String fdAcctInfo = null;
        if (response instanceof java.util.Map) {
            java.util.Map<String, String> resMap = (java.util.Map<String, String>) response;
            isSuccess = "00".equals(resMap.get("responseCode"));
            fdAcctInfo = isSuccess ? resMap.get("fdAccountNumber") : null;
        }

        // Persist to Database 
        FixedDeposit fd = FixedDeposit.builder()
                .cifId(customerId)
                //.status(isSuccess ? "COMPLETED" : "FAILED")
                .stateId(stateId)
                .accountNumber(fdAcctInfo != null ? fdAcctInfo : "N/A")
                //.amount(new BigDecimal(amountStr))
                .currency(currency)
                .userId(userId)
                .loginId(loginId)
                .termsAccepted(termsAccepted)
                .interestFrequency(interestFreq)
                .maturityInstruction(maturityInstr)
                .tenureYears(tYears)
                .tenureMonths(tMonths)
                .tenureDays(tDays)
                //.interestRate(intRateResponse.getInterestRates() != null ? new BigDecimal(intRateResponse.getInterestRates()) : null)
                .build();
        fixedDepositRepository.save(fd);

        /* AUDIT LOG: Track creator explicitly */
        saveAudit(customerId, "FD_CREATE", "FD Creation for A/C: " + accountNumber + " Rate: " + intRateResponse.getInterestRates() + "%", isSuccess ? "SUCCESS" : "FAILURE", userCode);

        return response;
    }

    @Override
    public FdSummaryResponse getFdSummary(FdSummaryRequest request) {
        log.info("Service: Fetching FD summary for CIF: {}", request.getCifId());
        FdSummaryResponse response = fixedDepositAdapter.fetchFdSummary(request);
        
        saveAudit(request.getCifId(), "FD_SUMMARY", "Fetched summary for CIF: " + request.getCifId(), 
                "00".equals(response.getResponseCode()) ? "SUCCESS" : "FAILURE", "SYSTEM");

        return response;
    }


    private void saveAudit(String cifId, String action, String details, String status, String userCode) {
        FixedDepositAudit audit = FixedDepositAudit.builder()
                .cifId(cifId)
                .action(action)
                .details(details)
                .status(status)
                .updatedBy(userCode)
                .build();
        fixedDepositAuditRepository.save(audit);
    }
}
