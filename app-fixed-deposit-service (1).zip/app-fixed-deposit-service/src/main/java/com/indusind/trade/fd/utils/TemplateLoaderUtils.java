package com.indusind.trade.fd.utils;

import org.springframework.core.io.ClassPathResource;

public class TemplateLoaderUtils {

    public static String load(String path) {
        try {
            ClassPathResource resource = new ClassPathResource(path);
            return new String(resource.getInputStream().readAllBytes());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
