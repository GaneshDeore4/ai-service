package com.indusind.trade.fd.adapter;

import com.indusind.trade.fd.dto.*;
import java.util.List;

public interface FixedDepositAdapter {
	
    AccountDetailsResponse fetchAccountDetails(String acid, CommonRequest common);
    
    FdModelResponse calculateFdModel(FdModelRequest request);
    
    Object createFd(java.util.Map<String, Object> request);
    
    FdSummaryResponse fetchFdSummary(FdSummaryRequest request);
}
