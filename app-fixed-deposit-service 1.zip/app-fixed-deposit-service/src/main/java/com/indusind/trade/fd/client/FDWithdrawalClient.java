package com.indusind.trade.fd.client;

import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "fd-withdrawal-client", url = "${app.fd.close.url}")
public interface FDWithdrawalClient {

    @PostMapping(value = "/fd-servicing/fdfullwithdrawl/V1",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    IBLGatewayResponse fullWithdrawal(
            @RequestHeader("IBL-Client-Id") String clientID,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody String encryptedEnvelope);
}
