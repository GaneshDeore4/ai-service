package com.indusind.trade.fd.controller;

import com.indusind.trade.fd.dto.*;
import com.indusind.trade.fd.service.FixedDepositService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/fd")
@ConditionalOnProperty(name = "app.fd.adapter.type", havingValue = "json", matchIfMissing = true)
@RequiredArgsConstructor
public class FixedDepositJsonController {

    private final FixedDepositService fixedDepositService;

    @PostMapping("/account-details")
    public ResponseEntity<ApplicationResponse> getAccountDetails(@RequestBody Map<String, Object> payload) {
        String acid = (String) payload.get("acid");
        CommonRequest common = mapToCommon(payload);
        AccountDetailsResponse response = fixedDepositService.getAccountDetails(acid, common);
        return ResponseEntity.ok(new ApplicationResponse("SUCCESS", response, "Account details fetched successfully"));
    }

    @PostMapping("/calculateFDInterest")
    public ResponseEntity<ApplicationResponse> calculateFDInterest(@RequestBody FDInterestRatesReqDto request) {
        FDInterestRatesRespDto response = fixedDepositService.calculateFdInterestJson(request);
        return ResponseEntity.ok(new ApplicationResponse("SUCCESS", response, "FD calculation successful"));
    }


    @PostMapping("/summary")
    public ResponseEntity<ApplicationResponse> getFdSummary(@RequestBody FdSummaryRequest request) {
        FdSummaryResponse response = fixedDepositService.getFdSummary(request);
        return ResponseEntity.ok(new ApplicationResponse("SUCCESS", response, "Fixed Deposit Summary Fetch Successful"));
    }

    @PostMapping("/createfd")
    public ResponseEntity<ApplicationResponse> createFd(@RequestBody Map<String, Object> payload) {
        Object response = fixedDepositService.createFd(payload);
        return ResponseEntity.ok(new ApplicationResponse("SUCCESS", response, "Fixed Deposit registration initiated"));
    }

    private CommonRequest mapToCommon(Map<String, Object> payload) {
        return CommonRequest.builder()
                .appType((String) payload.get("appType"))
                .appVersion((String) payload.get("appVersion"))
                .authProduct((String) payload.get("authProduct"))
                .com_ImeiNo((String) payload.get("com_ImeiNo"))
                .customerId((String) payload.get("customerId"))
                .deviceId((String) payload.get("deviceId"))
                .deviceModel((String) payload.get("deviceModel"))
                .deviceName((String) payload.get("deviceName"))
                .deviceOS((String) payload.get("deviceOS"))
                .deviceType((String) payload.get("deviceType"))
                .isUsrLoggedIn((String) payload.get("isUsrLoggedIn"))
                .platform((String) payload.get("platform"))
                .requestType((String) payload.get("requestType"))
                .token((String) payload.get("token"))
                .userCode((String) payload.get("userCode"))
                .userId((String) payload.get("userId"))
                .userRole((String) payload.get("userRole"))
                .build();
    }
}
