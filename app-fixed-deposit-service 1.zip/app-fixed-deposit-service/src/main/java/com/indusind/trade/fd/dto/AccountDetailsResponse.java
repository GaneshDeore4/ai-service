package com.indusind.trade.fd.dto;

import lombok.Data;
import java.util.List;

@Data
public class AccountDetailsResponse {
    private String responseDesc;
    private String responseCode;
    private List<MappedAccount> listAcno;

    @Data
    public static class MappedAccount {
        private String acctName;
        private String acno;
        private String isMapped;
    }
}
