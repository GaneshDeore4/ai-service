package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountJson {

    private String schemeCode;
    private String cifId;
    private String accID;
    private String accountNumber;
    private String accountBalance;
    private String accountOpenDate;
    private String acctClsFlg;
    private String acctClsDate;
    private String schemeType;
    private String modeOfOperation;
    private String frezCode;
    private String currency;
    private String lienAmount;
    private String lienFlag;
    private String nomFlg;
    private String accountStatus;
    private String startDate;
    private String maturityAmount;
    private String maturityDate;
    private String maturityInsc;
    private String depositAmount;
    private String depositPeriodDays;
    private String depositPeriodMonths;
    private String c5Code;
    private String nomName;
    private String renewalOption;
    private String nomReltnCode;
    private Double applRateOfInterest;
    private String interestTableCode;
    private String schemeDesc;
    private String c5CodeDescription;
    private String ifscCode;
    private String pdFlg;
    private String relationShipType;
    private String glSubHeadCode;
    private String frezReasonCode_1;
    private String frezReasonCode_2;
    private String frezReasonCode_3;
    private String frezReasonCode_4;
    private String frezReasonCode_5;
    private String entityCreFlag;
    private String SOL_ID;
    private String FDType;
    private String FDSBALinked;
    private String TDTerm;
    private String PAN;
    private String Nre_Nro;
    private String Acct_crncy_code;
}
