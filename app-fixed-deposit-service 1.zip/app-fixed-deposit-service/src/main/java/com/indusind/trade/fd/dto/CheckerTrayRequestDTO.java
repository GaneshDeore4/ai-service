package com.indusind.trade.fd.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class CheckerTrayRequestDTO {

    private Long userId;
    private Long groupId;
    private List<String> status;

}
