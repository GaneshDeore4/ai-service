package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Map;

@Data
public class ExternalFDModelDTOs {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RequestWrapper {
        @JsonProperty("request")
        private RequestContent request;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RequestContent {
        private RequestHeader header;
        private RequestBody body;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RequestHeader {
        private String requestUUID;
        private String channelId;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RequestBody {
        @JsonProperty("FDModelDepositRequest")
        private FDModelDepositRequest fdModelDepositRequest;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FDModelDepositRequest {
        private String depositAmount;
        private String depositPeriodDays;
        private String depositPeriodMonths;
        private String depositDate;
        private String depositcurrencyCode;
        private String currencyCode;
        private String schmCode;
        private String interestTableCode;
        private String daysInAYear;
        private String monthsInYear;
        private String flowType;
        private String pegFlag;
        private String depositType;
        private String schmType;
    }

    // Response Classes
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResponseWrapper {
        @JsonProperty("response")
        private ResponseContent response;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResponseContent {
        private ResponseHeader header;
        private ResponseBody body;
        private ErrorInfo error;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResponseHeader {
        private String requestUUID;
        private String channelId;
        private String status;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResponseBody {
        @JsonProperty("FDModelDepositResponse")
        private FDModelDepositResponse fdModelDepositResponse;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FDModelDepositResponse {
        private String brknPerdIntBase;
        private String brknPerdIntMthd;
        private String compoundFreqPerdDays;
        private String compoundFreqPerdMonths;
        private String currencyCode;
        private String daysInAYear;
        private String depositAmount;
        private String depositDate;
        private String depositPeriodDays;
        private String depositPeriodMonths;
        private String instlmntFreqPerdDays;
        private String instlmntFreqPerdMonths;
        private String interestAmount;
        private String interestTableCode;
        private String interestMethod;
        private String interestRate;
        private String leapYearAdjstmntDays;
        private String maturityAmt;
        private String maturityDate;
        private String monthsInAYear;
        private String pegFlag;
        private String resultStr;
        private String resultType;
        private String schmCode;
        private String schmType;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ErrorInfo {
        private String errorCode;
        private String errorDesc;
    }
}
