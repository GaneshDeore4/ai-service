package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.RequestParam;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FDActionDto {
    private Long fdId;
    private Long userId;
    private String loginId;
    private String userName;
    private Long groupId;
    private String groupName;
    private Long makerId;
    private String userType;

    @JsonSetter(nulls = Nulls.SKIP)
    private Boolean isMidOffice = false;
    private String reason;
}
