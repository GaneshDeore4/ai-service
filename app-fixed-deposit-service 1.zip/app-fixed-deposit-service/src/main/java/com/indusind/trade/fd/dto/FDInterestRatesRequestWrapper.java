package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FDInterestRatesRequestWrapper {

    @JsonProperty("request")
    private RequestContainer request;

    @Getter
    @Setter
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RequestContainer {
        @JsonProperty("header")
        private Header header;

        @JsonProperty("body")
        private Body body;
    }

    @Getter
    @Setter
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Header {
        private String requestUUID;
        private String channelId;
    }

    @Getter
    @Setter
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Body {
        @JsonProperty("FDModelDepositRequest")
        private FDModelDepositRequest fdModelDepositRequest;
    }

    @Getter
    @Setter
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class FDModelDepositRequest {
        private String depositAmount;
        private String depositPeriodDays;
        private String depositPeriodMonths;
        private String depositDate;
        private String depositcurrencyCode;
        private String currencyCode;
        private String schmCode;
        private String interestTableCode;
        private String daysInAYear;
        private String monthsInYear;
        private String flowType;
        private String pegFlag;
        private String depositType;
        private String schmType;
    }
}
