package com.indusind.trade.fd.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FDWithdrawalResponse {
    private ResponseContainer response;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ResponseContainer {
        private Header header;
        private ErrorDetails error;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Header {
        private String requestUUID;
        private String channelId;
        private String status; // e.g., "success" or "failure"
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ErrorDetails {
        private String errorCode;
        private String errorDesc;
    }
}