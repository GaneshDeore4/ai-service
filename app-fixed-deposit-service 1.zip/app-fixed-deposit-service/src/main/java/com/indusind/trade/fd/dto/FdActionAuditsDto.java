package com.indusind.trade.fd.dto;

import com.indusind.trade.fd.entity.ApprovalAudit;
import com.indusind.trade.fd.enums.ActionType;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;


@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
public class FdActionAuditsDto {
    private Long id;
    private Long fdId;
    private Long userId;
    private String loginId;
    private Long groupId;
    private String userName;
    private String groupName;
    private Integer level;
    private ActionType action;

    private String remarks;
    private LocalDateTime timestamp;

    public static FdActionAuditsDto convertEntityToDto(ApprovalAudit approvalAudit){
        FdActionAuditsDto dto = new FdActionAuditsDto();
        BeanUtils.copyProperties(approvalAudit, dto);
        return dto;
    }
}
