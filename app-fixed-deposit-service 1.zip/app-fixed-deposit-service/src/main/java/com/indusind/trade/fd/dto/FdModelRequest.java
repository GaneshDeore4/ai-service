package com.indusind.trade.fd.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class FdModelRequest extends CommonRequest {
    private String amountValue;
    private String currencyCode;
    private String currencyCodes;
    private String days;
    private int daysInAYear;
    private String depositDate;
    private String depositType;
    private String flowType;
    private String months;
    private String monthsInAYear;
    private String pegFlag;
    private String schmCode;
    private String schmType;
}
