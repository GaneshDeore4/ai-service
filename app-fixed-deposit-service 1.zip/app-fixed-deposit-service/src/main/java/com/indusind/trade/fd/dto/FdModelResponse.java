package com.indusind.trade.fd.dto;

import lombok.Data;

@Data
public class FdModelResponse {
    private String status;
    private String interestRates;
    private String error;
}
