package com.indusind.trade.fd.dto;

import com.indusind.trade.fd.enums.FDStatus;
import lombok.*;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MakerTrayDTO {

    private Long fdId;
    private Double amount;
    private FDStatus status;
    private String rejectReason;
}
