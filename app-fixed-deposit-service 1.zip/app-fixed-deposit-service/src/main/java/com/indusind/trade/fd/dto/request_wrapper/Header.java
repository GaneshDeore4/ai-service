package com.indusind.trade.fd.dto.request_wrapper;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class Header {

    private String requestUUID;
    private String channelId;

}
