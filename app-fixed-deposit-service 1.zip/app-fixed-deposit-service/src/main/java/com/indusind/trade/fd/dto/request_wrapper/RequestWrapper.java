package com.indusind.trade.fd.dto.request_wrapper;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class RequestWrapper {

    @JsonProperty("request")
    private Request request;

}
