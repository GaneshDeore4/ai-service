package com.indusind.trade.fd.dto.request_wrapper.create_fd;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class CreateFDBody {

    private String custId;
    private String currencyCode;

    private String rePayacctId;
    private String rePayschmCode;
    private String rePayschmType;

    private String debitacctId;
    private String debitschmCode;
    private String debitschmType;

    @JsonProperty("TDschmCode")
    private String tdSchmCode;
    @JsonProperty("TDschmType")
    private String tdSchmType;

    private String branchId;
    private String amountValue;

    private String depositDays;
    private String depositMonths;

    private String autoCloseOnMaturityFlg;
    private String maxNumOfRenewalAllwd;
    private String autoRenewalflg;

    private String intTblCode;
    private String renewalSchmCode;

    private String nomineeFlag;
    private String nomineeName;
    private String relType;

    private String guardianName;
    private String guardianCode;

    private String mobNum;

    private PostalAddressDTO postalAdd;

    private String saLinkFlg;
    private String nomineeMinorFlg;

    @JsonProperty("nomineeBirthDt")
    private String nomineeBirthDt;
    private String nomineePercent;

    private String solID;
    private String inttBLCD;

    private String modeOfOper;
    private String freeCode4;
}
