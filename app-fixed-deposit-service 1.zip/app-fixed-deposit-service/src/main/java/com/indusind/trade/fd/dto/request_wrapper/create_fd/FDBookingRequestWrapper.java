package com.indusind.trade.fd.dto.request_wrapper.create_fd;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FDBookingRequestWrapper {
    @JsonProperty("FDBookingRequest")
    private CreateFDBody fdBookingRequest;
}
