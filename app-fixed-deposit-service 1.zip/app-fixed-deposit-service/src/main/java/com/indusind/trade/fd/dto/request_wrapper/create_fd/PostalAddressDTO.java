package com.indusind.trade.fd.dto.request_wrapper.create_fd;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class PostalAddressDTO {

    private NomineeDTO nominee;

}
