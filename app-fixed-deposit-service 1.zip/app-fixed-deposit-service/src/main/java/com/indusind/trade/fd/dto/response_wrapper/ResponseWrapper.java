package com.indusind.trade.fd.dto.response_wrapper;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class ResponseWrapper {

    private Response response;

}
