package com.indusind.trade.fd.dto.response_wrapper.create_fd;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class FDBookingResponseDTO {

    private String acctId;

}
