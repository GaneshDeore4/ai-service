package com.indusind.trade.fd.entity;


import com.indusind.trade.fd.enums.AssignmentStatus;
import com.indusind.trade.fd.enums.AssignmentType;
import com.indusind.trade.fd.enums.NodeType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "gtp_fd_closure_assignment")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CloseFDAssignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "fd_id")
    private Long fdId;

    @Column(name = "closure_type", length = 10, nullable = false)
    private String closureType;

    @Column(name = "assignment_type", length = 255)
    private AssignmentType assignmentType;

    @Column(name = "auth_matrix_id")
    private Long authMatrixId;

    @Column(name = "group_id")
    private Long groupId;

    @Column(name = "group_name", length = 255)
    private String groupName;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "is_sequential")
    private Boolean isSequential;

    @Column(name = "level")
    private Integer level;

    @Column(name = "node_type", length = 255)
    private NodeType nodeType;

    @Column(name = "status", length = 255)
    private AssignmentStatus status;

    @Column(name = "user_type")
    private String userType;

}
