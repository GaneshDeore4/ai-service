package com.indusind.trade.fd.entity;

import com.indusind.trade.fd.enums.FDStatus;
import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "close_fixed_deposits")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(HashListener.class)
public class CloseFixedDeposit {


    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Convert(converter = CryptoConverter.class)
    @HashField
    @Column(name = "cif_id", length = 255)
    private String cifId;

    @Column(name = "cif_id_hash", length = 255)
    private String cifIdHash;

    @Column(name = "login_id", length = 255)
    private String loginId;

    @Convert(converter = CryptoConverter.class)
    @HashField
    @Column(name = "fd_account_number", length = 255)
    private String fdAccountNumber;

    @Column(name = "fd_account_number_hash", length = 255)
    private String fdAccountNumberHash;

    @Column(name = "amount")
    private Double amount;

    @Column(name = "currency", length = 5)
    private String currency;

    @Column(name = "repayment_account", length = 255)
    private String repaymentAccount;

    @Column(name = "interest_frequency", length = 255)
    private String interestFrequency;

    @Column(name = "interest_rate")
    private Double interestRate;

    @Column(name = "interest_amount")
    private Double interestAmount;

    @Column(name = "maturity_instruction", length = 255)
    private String maturityInstruction;

    @Column(name = "maturity_amount")
    private Double maturityAmount;

    @Column(name = "maturity_date")
    private LocalDate maturityDate;

    @Column(name = "tenure_days")
    private Integer tenureDays;

    @Column(name = "tenure_months")
    private Integer tenureMonths;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "user_id", length = 255)
    private String userId;

    @Column(name = "state_id", length = 255)
    private String stateId;

    @Column(name = "status", length = 255)
    @Enumerated(EnumType.STRING)
    private FDStatus status;

    @Column(name = "auth_matrix_id")
    private Long authMatrixId;

    @Column(name = "current_level")
    private Integer currentLevel;

    @Column(name = "maker_id")
    private Long makerId;

    @Version
    @Column(name = "version")
    private Long version;

    @Column(name = "is_mid_office_approved")
    private Boolean isMidOfficeApproved;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "reject_reason")
    private String rejectReason;

}
