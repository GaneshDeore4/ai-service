package com.indusind.trade.fd.enums;

public enum AssignmentStatus {
    WAITING,
    PENDING,

    APPROVED,
    VIEW_ONLY,

    REJECTED
}
