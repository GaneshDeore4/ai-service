package com.indusind.trade.fd.enums;

public enum AssignmentType {
    GROUP, ROLE
}
