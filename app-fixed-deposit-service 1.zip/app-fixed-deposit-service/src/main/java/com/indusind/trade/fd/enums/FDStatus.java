package com.indusind.trade.fd.enums;

public enum FDStatus {
    IN_APPROVAL, APPROVED, REJECTED, CLOSED, PENDING_AT_MID_OFFICE,MID_OFFICE_APPROVED,MID_OFFICE_REJECTED
}
