package com.indusind.trade.fd.enums;

public enum NodeType {

    VERIFIER, APPROVER, RELEASER
}
