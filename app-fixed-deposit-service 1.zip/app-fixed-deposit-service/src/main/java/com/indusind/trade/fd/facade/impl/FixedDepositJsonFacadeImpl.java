package com.indusind.trade.fd.facade.impl;

import com.indusind.trade.fd.adapter.FixedDepositJsonAdapter;
import com.indusind.trade.fd.dto.ApplicationResponse;
import com.indusind.trade.fd.dto.FDInterestRatesReqDto;
import com.indusind.trade.fd.dto.FDInterestRatesRespDto;
import com.indusind.trade.fd.dto.FixedDepositDto;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.facade.FixedDepositFacade;
import com.indusind.trade.fd.service.FDAuditService;
import com.indusind.trade.fd.service.FixedDepositService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Component
@ConditionalOnProperty(name = "app.fd.adapter.type", havingValue = "json")
@RequiredArgsConstructor
public class FixedDepositJsonFacadeImpl implements FixedDepositFacade {

    private final FixedDepositJsonAdapter jsonAdapter;
    private final FDAuditService fdAuditService;
    private final FixedDepositService fixedDepositService;

    @Override
    public FDInterestRatesRespDto calculateFDInterest(FDInterestRatesReqDto fdInterestRatesReqDto) {
    	
        FDInterestRatesRespDto resp = jsonAdapter.calculateFdModel(fdInterestRatesReqDto);
        
       /* fdAuditService.saveAudit(fdInterestRatesReqDto.getCifId(), "FD_INTEREST_RATE_JSON",
                "Fetched Interest Rate via JSON for CIF: " + fdInterestRatesReqDto.getCifId(),
                "SUCCESS".equals(resp.getStatus()) ? "SUCCESS" : "FAILURE", "SYSTEM");*/
                
        return resp;
    }

    @Override
    @Transactional
    public ApplicationResponse createFD(FixedDepositDto request) {
        // First save to local DB
        FixedDeposit fd = FixedDepositDto.convertToEntity(request);
        FixedDeposit savedFd = fixedDepositService.saveFixedDeposit(fd);

        // Then notify external system via adapter (Dummy/Stubbed for now in JSON)
        Map<String, Object> externalReq = new HashMap<>();
        externalReq.put("accountNumber", request.getAccountNumber());
        externalReq.put("amount", request.getAmount());
        jsonAdapter.createFd(externalReq);

        fdAuditService.saveAudit(savedFd.getCifId(), "FD_CREATE_JSON", "Fixed Deposit Created via JSON", "SUCCESS", savedFd.getUserId());

        return new ApplicationResponse("SUCCESS", FixedDepositDto.convertToDto(savedFd), "FD created successfully via JSON adapter");
    }
}
