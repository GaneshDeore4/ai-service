package com.indusind.trade.fd.repository;

import com.indusind.trade.fd.entity.FixedDepositAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FixedDepositAuditRepository extends JpaRepository<FixedDepositAudit, Long> {
    List<FixedDepositAudit> findByCifId(String cifId);
}
