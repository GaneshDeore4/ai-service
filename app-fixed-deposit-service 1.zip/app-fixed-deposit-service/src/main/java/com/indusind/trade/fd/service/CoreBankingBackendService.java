package com.indusind.trade.fd.service;

public interface CoreBankingBackendService {

    String callCalculateFDIntgerestSoap(String req);
}
