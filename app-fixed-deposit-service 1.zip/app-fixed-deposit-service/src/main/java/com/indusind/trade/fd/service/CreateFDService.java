package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.response_wrapper.ResponseWrapper;
import com.indusind.trade.fd.entity.FixedDeposit;

public interface CreateFDService {

    ResponseWrapper createFD(FixedDeposit fd);

}
