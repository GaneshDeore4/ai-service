package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.FDWithdrawalResponse;


public interface FDWithdrawalService {
    FDWithdrawalResponse initiateFullWithdrawal(String acctNum, String repaymentAcctId, double amount);
}