package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.FDInterestRatesReqDto;
import com.indusind.trade.fd.dto.FDInterestRatesRespDto;

public interface SoapTransformationService {
    String convertFDInterestRatesReqToSoap(FDInterestRatesReqDto fdInterestRatesReqDto);

    FDInterestRatesRespDto parseFDInterestRatesRespToJson(String soapResp);
}
