package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.entity.FixedDepositAudit;
import com.indusind.trade.fd.repository.FixedDepositAuditRepository;
import com.indusind.trade.fd.repository.FixedDepositRepository;
import com.indusind.trade.fd.service.FDAuditService;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class FDAuditServiceImpl implements FDAuditService {

    private final FixedDepositAuditRepository fixedDepositAuditRepository;

    @Override
    public void saveAudit(String cifId, String action, String details, String status, String userCode) {
        FixedDepositAudit audit = FixedDepositAudit.builder()
                .cifId(cifId)
                .action(action)
                .details(details)
                .status(status)
                .updatedBy(userCode)
                .build();
        fixedDepositAuditRepository.save(audit);
    }
}
