package com.indusind.trade.fd.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class DateUtils {

    public static final DateTimeFormatter FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");

    private static final List<DateTimeFormatter> FORMATTERS = List.of(
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
            DateTimeFormatter.ISO_LOCAL_DATE_TIME,
            DateTimeFormatter.ISO_LOCAL_DATE
    );

    public static String now() {
        return LocalDateTime.now().format(FORMAT);
    }

    public static String format(LocalDateTime dt) {
        return dt.format(FORMAT);
    }

    public static LocalDate parseToLocalDate(String dateStr) {
        if (dateStr == null || dateStr.isBlank()) {
            return null;
        }

        return LocalDateTime.parse(dateStr, FORMAT).toLocalDate();
    }

    public static LocalDate parseToLocalDateMultiple(String dateStr) {
        if (dateStr == null || dateStr.isBlank()) {
            return null;
        }

        for (DateTimeFormatter formatter : FORMATTERS) {
            try {
                if (dateStr.length() > 10) {
                    return LocalDateTime.parse(dateStr, formatter).toLocalDate();
                } else {
                    return LocalDate.parse(dateStr, formatter);
                }
            } catch (DateTimeParseException ignored) {
                //log.warn("Unable to parse maturityDate: {}", dateStr);
            }
        }
        return null;
    }
}
