package com.indusind.trade.fd.adapter.impl;

import com.indusind.trade.fd.adapter.FixedDepositAdapter;
import com.indusind.trade.fd.client.BankJsonFeignClient;
import com.indusind.trade.fd.dto.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.fd.adapter.type", havingValue = "json")
@RequiredArgsConstructor
public class FixedDepositJsonAdapter implements FixedDepositAdapter {

    private final BankJsonFeignClient bankJsonFeignClient;

    @Override
    public AccountDetailsResponse fetchAccountDetails(String acid, CommonRequest common) {
        log.info("Fetching account details for ACID: {}", acid);
        Map<String, Object> request = mapToMap(common);
        request.put("acid", acid);
        
        try {
            // return bankJsonFeignClient.getAccountDetailsLcr(request);
            return getDummyAccountDetails(acid);
        } catch (Exception e) {
            log.error("Error fetching account details: {}", e.getMessage());
            return getDummyAccountDetails(acid);
        }
    }

    @Override
    public FdModelResponse calculateFdModel(FdModelRequest request) {
        log.info("Calculating FD model for amount: {}", request.getAmountValue());
        try {
            // return bankJsonFeignClient.getDepositModel(request);
            return getDummyFdModel();
        } catch (Exception e) {
            log.error("Error calculating FD model: {}", e.getMessage());
            return getDummyFdModel();
        }
    }
    
    
    @Override
    public Object createFd(Map<String, Object> request) {
        log.info("Creating FD (td-add-account)");
        // Dummy implementation for now
        Map<String, String> response = new HashMap<>();
        response.put("responseCode", "00");
        response.put("responseDesc", "Fixed Deposit Created Successfully");
        return response;
    }

    private Map<String, Object> mapToMap(CommonRequest common) {
        Map<String, Object> map = new HashMap<>();
        map.put("appType", common.getAppType());
        map.put("appVersion", common.getAppVersion());
        map.put("authProduct", common.getAuthProduct());
        map.put("com_ImeiNo", common.getCom_ImeiNo());
        map.put("customerId", common.getCustomerId());
        map.put("deviceId", common.getDeviceId());
        map.put("deviceModel", common.getDeviceModel());
        map.put("deviceName", common.getDeviceName());
        map.put("deviceOS", common.getDeviceOS());
        map.put("deviceType", common.getDeviceType());
        map.put("isUsrLoggedIn", common.getIsUsrLoggedIn());
        map.put("platform", common.getPlatform());
        map.put("requestType", common.getRequestType());
        map.put("token", common.getToken());
        map.put("userCode", common.getUserCode());
        map.put("userId", common.getUserId());
        map.put("userRole", common.getUserRole());
        return map;
    }

    private AccountDetailsResponse getDummyAccountDetails(String acid) {
        AccountDetailsResponse resp = new AccountDetailsResponse();
        resp.setResponseCode("R000");
        resp.setResponseDesc("Success");
        resp.setListAcno(new ArrayList<>());
        
        AccountDetailsResponse.MappedAccount acc = new AccountDetailsResponse.MappedAccount();
        acc.setAcctName("XYZ Limited - MOCKED");
        acc.setAcno(acid);
        acc.setIsMapped("1");
        resp.getListAcno().add(acc);
        return resp;
    }

    private FdModelResponse getDummyFdModel() {
        FdModelResponse resp = new FdModelResponse();
        resp.setStatus("SUCCESS");
        resp.setInterestRates("6.75");
        return resp;
    }

    private OtpResponse getDummyOtpResponse() {
        OtpResponse resp = new OtpResponse();
        resp.setErrorCode("00");
        resp.setOtpHint("1189");
        resp.setSentTo("878882XXXX");
        resp.setAction("STATE_ID_MOCKED_123456");
        return resp;
    }

    private OtpVerifyResponse getDummyOtpVerifyResponse() {
        OtpVerifyResponse resp = new OtpVerifyResponse();
        resp.setResponseCode("00");
        resp.setResponseDesc("Otp Verified Successfully");
        return resp;
    }

    @Override
    public FdSummaryResponse fetchFdSummary(FdSummaryRequest request) {
        log.info("Fetching FD summary via JSON (Dummy) for CIF: {}", request.getCifId());
        return FdSummaryResponse.builder()
                .responseCode("00")
                .responseDesc("Success (MOCK)")
                .fdDetails(new ArrayList<>())
                .build();
    }
}
