package com.indusind.trade.fd.client;

import com.indusind.trade.fd.dto.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.Map;

@FeignClient(name = "bank-json-client", url = "${app.bank.api.json.gateway-url}")
public interface BankJsonFeignClient {

    @PostMapping("/soap-service/core-banking//get-account-details-lcr")
    AccountDetailsResponse getAccountDetailsLcr(@RequestBody Map<String, Object> request);

    @PostMapping("/soap-service/core-banking/deposit-model")
    FDInterestRatesRespDto getDepositModel(@RequestBody FDInterestRatesReqDto request);

    @PostMapping("/us-mgmt/generateverifyotp")
    OtpResponse generateOtp(@RequestBody Map<String, Object> request);

    @PostMapping("/us-mgmt/verifyotp")
    OtpVerifyResponse verifyOtp(@RequestBody Map<String, Object> request);
}
