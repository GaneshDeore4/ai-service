package com.indusind.trade.fd.controller;

import com.indusind.trade.fd.dto.*;
import com.indusind.trade.fd.entity.FDAssignment;
import com.indusind.trade.fd.enums.AssignmentStatus;
import com.indusind.trade.fd.enums.AssignmentType;
import com.indusind.trade.fd.facade.FixedDepositFacade;
import com.indusind.trade.fd.repository.FDAssignmentRepository;
import com.indusind.trade.fd.service.FDRoadmapService;
import com.indusind.trade.fd.service.FDService;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import com.indusind.trade.model.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.Set;

@RestController
@RequestMapping("/api/fd/v2")
@RequiredArgsConstructor
public class FDController {

    private final FixedDepositFacade fixedDepositFacade;

    private final FDRoadmapService roadmapService;

    private final FDService service;

    @PostMapping("/calculateFDInterest")
    public ApplicationResponse calculateFDInterest(@RequestBody FDInterestRatesReqDto fdInterestRatesReqDto) {
        FDInterestRatesRespDto fdInterestRatesRespDto = fixedDepositFacade.calculateFDInterest(fdInterestRatesReqDto);
        return new ApplicationResponse("SUCCESS", fdInterestRatesRespDto, "Interest rates fetched successfully");
    }

    @PostMapping("/createFd")
    public ResponseEntity<ApplicationResponse> create(@RequestBody FixedDepositDto fd) {
        service.createFD(fd);
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd created successfully."));
    }

    @PostMapping("/approveFd")
    public ResponseEntity<ApplicationResponse> approve(@RequestBody FDActionDto request) {
        try {
            service.approve(request.getFdId(), request.getUserId(), request.getGroupId(), request.getUserType(), request.getIsMidOffice());
            return ResponseEntity.ok(
                    new ApplicationResponse("SUCCESS", null, "Approval successful")
            );
        } catch (Exception ex) {
            throw new GTPAppException("FD Approval failed", null);
        }
    }

    @PostMapping("/rejectFd")
    public ResponseEntity<ApplicationResponse> reject(@RequestBody FDActionDto request) {
        service.reject(request.getFdId(), request.getUserId(), request.getGroupId(), request.getReason());
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd rejected successfully."));
    }

    @PostMapping("/reopenFd")
    public ResponseEntity<ApplicationResponse> reopen(@RequestBody FixedDepositDto updated) {
        service.reopen(updated);
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd reopened successfully."));
    }

    @PostMapping("/closeFd")
    public ResponseEntity<ApplicationResponse> closeFd(@RequestBody FDActionDto fdActionDto) {
        service.close(fdActionDto.getFdId(), fdActionDto.getMakerId());
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd closed successfully."));
    }

    @GetMapping("/makerFDTray")
    public ResponseEntity<ApplicationResponse> makerTray(@RequestParam Long makerId,
                                                         @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getMakerTray(makerId, pageable), "Maker Fd tray fetched successfully."));
    }

    @GetMapping("/checkerFDTray")
    public ResponseEntity<ApplicationResponse> checkerTray(@RequestParam Long userId, @RequestParam Long groupId,
                                                           @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getCheckerTray(userId, groupId, pageable), "Checker Fd tray fetched successfully."));
    }

    @GetMapping("/releaserOrVerifierFDTray")
    public ResponseEntity<ApplicationResponse> releaserOrVerifierFDTray(@RequestParam Long userId, @RequestParam String roleName,
                                                                        @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getRelaeaserOrVerifierTray(userId, roleName, pageable), "Releaser/ Verifier Fd tray fetched successfully."));
    }

    @PostMapping("/getAllFDsByCifId")
    public ApplicationResponse getAllFDsByCifId(@RequestParam String cifId, @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return new ApplicationResponse("SUCCESS", service.getAllFDByCifId(cifId, pageable), "all fds fetched successfully");
    }

    @GetMapping("/roadmapPaths")
    public FDRoadmapResponse getRoadmap(@RequestParam Long fdId) {
        return roadmapService.getRoadmap(fdId);
    }

    @PostMapping("/approveFdMidOffice")
    public ApplicationResponse approveFdMidOffice(@RequestParam Long fdId, @RequestParam Long midOfficeUserId) {
        service.approveFdMidOffice(fdId, midOfficeUserId);
        return new ApplicationResponse("SUCCESS", null, "FD Approved at mid office successfully");

    }

    @PostMapping("/rejectFdMidOffice")
    public ApplicationResponse rejectFdMidOffice(@RequestParam Long fdId, @RequestParam Long midOfficeUserId) {
        service.rejectFdMidOffice(fdId, midOfficeUserId);
        return new ApplicationResponse("SUCCESS", null, "FD Approved at mid office successfully");

    }


    @GetMapping("/count")
    public MidOfficeCountDTO getCounts() {
        return service.getMidOfficeCounts();
    }

    @PostMapping("/getFDByStatus")
    public ApplicationResponse getFDByStatus(@RequestBody GetFDByStatusRequestDto request, @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        Page<FixedDepositDto> fdPage = service.getFDByStatus(request.getStatus(), pageable);
        return new ApplicationResponse("SUCCESS", fdPage, "FD list fetched");
    }

}

