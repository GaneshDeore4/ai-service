package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class FDActionDto {
    private Long fdId;
    private Long userId;
    private Long groupId;
    private Long makerId;
    private String userType;

    @JsonSetter(nulls = Nulls.SKIP)
    private Boolean isMidOffice = false;
    private String reason;
}
