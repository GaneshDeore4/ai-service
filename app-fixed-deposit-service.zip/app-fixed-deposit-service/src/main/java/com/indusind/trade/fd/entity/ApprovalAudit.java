package com.indusind.trade.fd.entity;

import com.indusind.trade.fd.enums.ActionType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "gtp_fd_approval_audit")
@Getter
@Setter
public class ApprovalAudit {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long fdId;
    private Long userId;
    private Long groupId;
    private Long userName;
    private Long groupName;
    private Integer level;

    @Enumerated(EnumType.STRING)
    private ActionType action;

    private String remarks;
    private LocalDateTime timestamp;
}
