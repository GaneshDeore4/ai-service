package com.indusind.trade.fd.entity;

import com.indusind.trade.fd.enums.AssignmentStatus;
import com.indusind.trade.fd.enums.AssignmentType;
import com.indusind.trade.fd.enums.NodeType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "gtp_fd_assignment")
@Getter
@Setter
public class FDAssignment {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long fdId;
    private Long authMatrixId;
    private Long groupId;
    private String groupName;
    private Integer level;
    private Boolean isSequential;

    private Boolean isActive;

    @Enumerated(EnumType.STRING)
    private AssignmentStatus status;

    @Enumerated(EnumType.STRING)
    private NodeType nodeType;

    @Enumerated(EnumType.STRING)
    private AssignmentType assignmentType;

    private String userType;

    @Version
    private Long version;

}
