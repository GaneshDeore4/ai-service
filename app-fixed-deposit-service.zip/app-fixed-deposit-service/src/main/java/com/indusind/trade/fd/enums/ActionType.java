package com.indusind.trade.fd.enums;

public enum ActionType {
    CREATED,
    APPROVED,
    REJECTED,
    REOPENED,
    CLOSED,

    MID_OFFICE_APPROVED,

    MID_OFFICE_REJECTED

}
