package com.indusind.trade.fd.repository;

import com.indusind.trade.fd.entity.ApprovalAudit;
import com.indusind.trade.fd.enums.ActionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApprovalAuditRepository extends JpaRepository<ApprovalAudit, Long> {

    long countByFdIdAndGroupIdAndAction(Long fdId, Long groupId, ActionType action);

    boolean existsByFdIdAndUserIdAndGroupId(Long fdId, Long userId, Long groupId);
}
