package com.indusind.trade.fd.repository;

import com.indusind.trade.fd.entity.FDAssignment;
import com.indusind.trade.fd.enums.AssignmentStatus;
import com.indusind.trade.fd.projection.CheckerTrayProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FDAssignmentRepository extends JpaRepository<FDAssignment, Long> {

    List<FDAssignment> findByFdId(Long fdId);

    @Query("""
                SELECT a FROM FDAssignment a
                WHERE a.fdId = :fdId
                AND a.groupId = :groupId
                AND a.isActive = true
            """)
    List<FDAssignment> findActiveAssignment(Long fdId, Long groupId);

//    @Query("""
//            SELECT
//                f.id as fdId,
//
//                CASE
//                    WHEN EXISTS (
//                        SELECT 1 FROM FDAssignment a2
//                        WHERE a2.fdId = f.id
//                          AND a2.groupId = :groupId
//                          AND a2.status = 'PENDING'
//                    ) THEN 'PENDING'
//
//                    WHEN EXISTS (
//                        SELECT 1 FROM FDAssignment a3
//                        WHERE a3.fdId = f.id
//                          AND a3.groupId = :groupId
//                          AND a3.status = 'WAITING'
//                    ) THEN 'WAITING'
//
//                    WHEN EXISTS (
//                        SELECT 1 FROM FDAssignment a4
//                        WHERE a4.fdId = f.id
//                          AND a4.groupId = :groupId
//                          AND a4.status = 'APPROVED'
//                    ) THEN 'APPROVED'
//
//                    WHEN EXISTS (
//                        SELECT 1 FROM FDAssignment a5
//                        WHERE a5.fdId = f.id
//                          AND a5.groupId = :groupId
//                          AND a5.status = 'PENDING_AT_MID_OFFICE'
//                    ) THEN 'PENDING AT MID OFFICE'
//
//                    WHEN EXISTS (
//                        SELECT 1 FROM FDAssignment a6
//                        WHERE a6.fdId = f.id
//                          AND a6.groupId = :groupId
//                          AND a6.status = 'REJECTED'
//                    ) THEN 'REJECTED'
//
//                    ELSE 'VIEW ONLY'
//                END as status,
//
//                f.status as fdStatus,
//                f.currentLevel as currentLevel,
//                f.accountNumber as accountNumber,
//                f.amount as amount,
//                f.currency as currency,
//                f.tenureMonths as tenureMonths,
//                f.maturityInstruction as maturityInstruction,
//                f.tenureYears as tenureYears,
//                f.tenureDays as tenureDays,
//                f.interestRate as interestRate
//
//            FROM FixedDeposit f
//
//            WHERE EXISTS (
//                SELECT 1 FROM FDAssignment a
//                WHERE a.fdId = f.id
//                  AND a.groupId = :groupId
//            )
//            AND f.accountNumber IN (
//                SELECT acc.accountNumber
//                FROM User u
//                JOIN u.accountMapping acc
//                WHERE u.userId = :userId
//            )
//            """)
//    Page<CheckerTrayProjection> findCheckerTray(
//            Long userId,
//            Long groupId,
//            Pageable pageable
//    );

    @Query("""
            SELECT 
            f.id as fdId,
             
            CASE 
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'APPROVED'
                ) THEN 'APPROVED'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'PENDING'
                ) THEN 'PENDING'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'WAITING'
                ) THEN 'WAITING'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'REJECTED'
                ) THEN 'REJECTED'
             
                ELSE 'VIEW ONLY'
            END as status,
             
            f.status as fdStatus,
            f.currentLevel as currentLevel,
            f.accountNumber as accountNumber,
            f.amount as amount,
            f.currency as currency,
            f.tenureMonths as tenureMonths,
            f.maturityInstruction as maturityInstruction,
            f.tenureYears as tenureYears,
            f.tenureDays as tenureDays,
            f.interestRate as interestRate
             
            FROM FixedDeposit f
             
            WHERE EXISTS (
                SELECT 1 FROM FDAssignment a
                WHERE a.fdId = f.id
                AND a.groupId = :groupId
            )
             
            AND f.accountNumber IN (
                SELECT acc.accountNumber
                FROM User u
                JOIN u.accountMapping acc
                WHERE u.userId = :userId
            )
            """)
    Page<CheckerTrayProjection> findCheckerTray(
            Long userId,
            Long groupId,
            Pageable pageable
    );

//    @Query("""
//            SELECT
//            f.id as fdId,
//            CASE
//                WHEN EXISTS (
//                    SELECT 1 FROM FDAssignment a
//                    WHERE a.fdId = f.id
//                    AND a.groupId is null
//                    AND a.groupName = :roleName
//                    AND a.userType = :roleName
//                    AND a.status = 'APPROVED'
//                ) THEN 'APPROVED'
//
//                WHEN EXISTS (
//                    SELECT 1 FROM FDAssignment a
//                    WHERE a.fdId = f.id
//                    AND a.groupId is null
//                    AND a.groupName = :roleName
//                    AND a.userType = :roleName
//                    AND a.status = 'PENDING'
//                ) THEN 'PENDING'
//
//                WHEN EXISTS (
//                    SELECT 1 FROM FDAssignment a
//                    WHERE a.fdId = f.id
//                    AND a.groupId is null
//                    AND a.groupName = :roleName
//                    AND a.userType = :roleName
//                    AND a.status = 'WAITING'
//                ) THEN 'WAITING'
//
//                WHEN EXISTS (
//                    SELECT 1 FROM FDAssignment a
//                    WHERE a.fdId = f.id
//                    AND a.groupId is null
//                    AND a.groupName = :roleName
//                    AND a.userType = :roleName
//                    AND a.status = 'REJECTED'
//                ) THEN 'REJECTED'
//
//                ELSE 'VIEW ONLY'
//            END as status,
//
//            f.status as fdStatus,
//            f.currentLevel as currentLevel,
//            f.accountNumber as accountNumber,
//            f.amount as amount,
//            f.currency as currency,
//            f.tenureMonths as tenureMonths,
//            f.maturityInstruction as maturityInstruction,
//            f.tenureYears as tenureYears,
//            f.tenureDays as tenureDays,
//            f.interestRate as interestRate
//
//            FROM FixedDeposit f
//
//            WHERE EXISTS (
//                SELECT 1 FROM FDAssignment a
//                WHERE a.fdId = f.id
//                AND a.groupId is null
//                AND a.groupName = :roleName
//                AND a.userType = :roleName
//            )
//
//            AND f.accountNumber IN (
//                SELECT acc.accountNumber
//                FROM User u
//                JOIN u.accountMapping acc
//                WHERE u.userId = :userId
//            )
//            """)
//    Page<CheckerTrayProjection> findReleaserOrVerifierTray(
//            Long userId,
//            String roleName,
//            Pageable pageable
//    );

    @Query("""
            SELECT
            f.id as fdId,
            
            CASE
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'PENDING'
            AND a.isActive = true
            ) THEN 'PENDING'
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'WAITING'
            ) THEN 'WAITING'
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'APPROVED'
            ) THEN 'APPROVED'
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'REJECTED'
            ) THEN 'REJECTED'
            
            ELSE 'VIEW_ONLY'
            
            END as status,
            
            f.status as fdStatus,
            f.currentLevel as currentLevel,
            f.accountNumber as accountNumber,
            f.amount as amount,
            f.currency as currency,
            f.tenureMonths as tenureMonths,
            f.maturityInstruction as maturityInstruction,
            f.tenureYears as tenureYears,
            f.tenureDays as tenureDays,
            f.interestRate as interestRate
            FROM FixedDeposit f
            WHERE EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            )
            AND f.accountNumber IN (
            SELECT acc.accountNumber
            FROM User u
            JOIN u.accountMapping acc
            WHERE u.userId = :userId
            )
            """)
    Page<CheckerTrayProjection> findReleaserOrVerifierTray(
            Long userId,
            String roleName,
            Pageable pageable
    );

    List<FDAssignment> findByFdIdOrderByLevel(Long fdId);

    List<FDAssignment> findByFdIdAndStatus(Long fdId, AssignmentStatus status);


}
