package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.CheckerFDTrayDTO;
import com.indusind.trade.fd.dto.FixedDepositDto;
import com.indusind.trade.fd.dto.MakerTrayDTO;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface FDService {

    // CREATE FD
    
    void createFD(FixedDepositDto fd);

    void approve(Long fdId,
                 Long userId,
                 Long groupId,
                 String roleName,
                 boolean midOffice);

    // REJECT
    void reject(Long fdId, Long userId, Long groupId, String reason);

    // REOPEN
    void reopen(FixedDepositDto updated);

    // ================= CLOSE =================
    void close(Long fdId, Long makerId);

    // MAKER TRAY
    Page<MakerTrayDTO> getMakerTray(Long makerId, Pageable pageable);

    // CHECKER TRAY
    Page<CheckerFDTrayDTO> getCheckerTray(Long userId, Long groupId, Pageable pageable);

    Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTray(Long userId, String groupName, Pageable pageable);

    Page<FixedDepositDto> getAllFDByCifId(String cifId, Pageable pageable);

    public MidOfficeCountDTO getMidOfficeCounts();

    void approveFdMidOffice(Long fdId, Long midOfficeId);

    void rejectFdMidOffice(Long fdId, Long midOfficeId);

    Page<FixedDepositDto> getFDByStatus(List<String> status, Pageable page);
}
