package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.dto.CheckerFDTrayDTO;
import com.indusind.trade.fd.dto.FixedDepositDto;
import com.indusind.trade.fd.dto.MakerTrayDTO;
import com.indusind.trade.fd.entity.ApprovalAudit;
import com.indusind.trade.fd.entity.FDAssignment;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.enums.*;
import com.indusind.trade.fd.repository.ApprovalAuditRepository;
import com.indusind.trade.fd.repository.FDAssignmentRepository;
import com.indusind.trade.fd.repository.FixedDepositRepository;
import com.indusind.trade.fd.service.FDService;
import com.indusind.trade.model.dtos.projection.MidOfficeCountProjection;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import com.indusind.trade.model.entities.company.AuthLevel;
import com.indusind.trade.model.entities.company.AuthMatrix;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.AuthLevelDao;
import com.indusind.trade.model.repository.AuthMatrixDao;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FDServiceImpl implements FDService {

    private final FixedDepositRepository fdRepo;
    private final AuthMatrixDao matrixRepo;
    private final AuthLevelDao levelRepo;
    private final FDAssignmentRepository assignmentRepo;
    private final ApprovalAuditRepository auditRepo;


    @Transactional
    @Override
    public void createFD(FixedDepositDto fd) {
        fd.setStatus(FDStatus.IN_APPROVAL);
        fd.setCurrentLevel(0);
        fd.setAuthMatrixId(null);
        FixedDeposit entity = FixedDepositDto.convertToEntity(fd);
        fdRepo.saveAndFlush(entity);
        double fdAmount = fd.getAmount();
        if (!fd.getCurrency().equals(fd.getUserBaseCurrency())) {
            fdAmount = fd.getAmount() *
                    getExchangeRateByCurrency(fd.getCurrency(), fd.getUserBaseCurrency());
        }
        List<AuthMatrix> matrices =
                matrixRepo.findMatrices(
                        fd.getCifId(),
                        fd.getProductId(),
                        fd.getSubProductId(),
                        fdAmount,
                        fd.getUserBaseCurrency()
                );
        List<FDAssignment> assignments = new ArrayList<>();
        for (AuthMatrix m : matrices) {
            int offset = 0;
            //Verifier
            if (Boolean.TRUE.equals(m.getIsVerifier())) {
                FDAssignment v = new FDAssignment();
                v.setFdId(entity.getId());
                v.setAuthMatrixId(m.getId());
                v.setNodeType(NodeType.VERIFIER);
                v.setAssignmentType(AssignmentType.ROLE);
                v.setUserType("Client Verifier");
                v.setLevel(0);
                v.setIsSequential(m.getIsSequential());
                v.setStatus(AssignmentStatus.PENDING);
                v.setIsActive(true);
                assignments.add(v);
                offset = 1;
            }
            for (AuthLevel level : m.getAuthLevels()) {
                FDAssignment a = new FDAssignment();
                a.setFdId(entity.getId());
                a.setAuthMatrixId(m.getId());
                a.setNodeType(NodeType.APPROVER);
                a.setAssignmentType(AssignmentType.GROUP);
                a.setGroupId(level.getAuthGroup().getId());
                a.setGroupName(level.getAuthGroup().getAuthGroup());
                int nodeLevel = level.getSeqNo() + offset;
                a.setLevel(nodeLevel);
                a.setIsSequential(m.getIsSequential());
                // Sequential logic
                if (Boolean.TRUE.equals(m.getIsSequential())) {
                    if (nodeLevel == 0) {
                        a.setStatus(AssignmentStatus.PENDING);
                        a.setIsActive(true);
                    } else {
                        a.setStatus(AssignmentStatus.WAITING);
                        a.setIsActive(false);
                    }
                }
                //  Non-sequential logic
                else {
                    if (offset == 1) {
                        a.setStatus(AssignmentStatus.WAITING);
                        a.setIsActive(false);
                    } else {
                        a.setStatus(AssignmentStatus.PENDING);
                        a.setIsActive(true);
                    }
                }
                assignments.add(a);
            }
            // RELEASER
            if (Boolean.TRUE.equals(m.getIsReleaser())) {
                int maxLevel = m.getAuthLevels().stream()
                        .mapToInt(AuthLevel::getSeqNo)
                        .max()
                        .orElse(0);
                FDAssignment r = new FDAssignment();
                r.setFdId(entity.getId());
                r.setAuthMatrixId(m.getId());
                r.setNodeType(NodeType.RELEASER);
                r.setAssignmentType(AssignmentType.ROLE);
                r.setUserType("Client Releaser");
                int releaserLevel = maxLevel + offset + 1;
                r.setLevel(releaserLevel);
                r.setIsSequential(m.getIsSequential());
                r.setStatus(AssignmentStatus.WAITING);
                r.setIsActive(false);
                assignments.add(r);
            }
        }
        assignmentRepo.saveAll(assignments);
    }

    private Double getExchangeRateByCurrency(String currency, String userBaseCurrency) {
        return 93.20;
    }

    @Transactional
    @Override
    public void approve(Long fdId,
                        Long userId,
                        Long groupId,
                        String roleName,
                        boolean midOffice) {
        FixedDeposit fd = fdRepo.findById(fdId)
                .orElseThrow(() -> new RuntimeException("FD not found"));
        List<FDAssignment> all = assignmentRepo.findByFdId(fdId);
        List<FDAssignment> actionable = all.stream()
                .filter(FDAssignment::getIsActive)
                .filter(a -> match(a, groupId, roleName))
                .toList();
        if (actionable.isEmpty()) {
            throw new RuntimeException("No actionable node");
        }
        for (FDAssignment a : actionable) {
            if (a.getStatus() != AssignmentStatus.PENDING) {
                throw new RuntimeException("Invalid state");
            }
            a.setStatus(AssignmentStatus.APPROVED);
            audit(fd, userId, groupId, a.getLevel(), ActionType.APPROVED);
            a.setIsActive(false);
        }
        recompute(all, fd, midOffice);
        assignmentRepo.saveAll(all);
        fdRepo.save(fd);
    }

    private void recompute(List<FDAssignment> all,
                           FixedDeposit fd,
                           boolean midOffice) {
        Map<Long, List<FDAssignment>> pathMap =
                all.stream().collect(Collectors.groupingBy(FDAssignment::getAuthMatrixId));
        //  Releaser short-circuit
        if (handleReleaserCompletion(all, fd, midOffice)) return;
        // Reset state
        for (FDAssignment a : all) {
            if (a.getStatus() != AssignmentStatus.APPROVED) {
                a.setStatus(AssignmentStatus.WAITING);
                a.setIsActive(false);
            }
        }
        boolean verifierApproved = isVerifierApproved(all);
        boolean approverActed = isApproverActed(all);
        // VERIFIER / APPROVER-FIRST DECISION
        // CASE 1: Approver acted first → skip verifier
        if (approverActed && !verifierApproved) {
            for (List<FDAssignment> path : pathMap.values()) {
                boolean hasVerifier = path.stream()
                        .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER);
                if (hasVerifier) {
                    killPath(path);
                }
            }
        }
        // CASE 2: Verifier not yet approved → only verifier active
        else if (!verifierApproved) {
            for (List<FDAssignment> path : pathMap.values()) {
                path.stream()
                        .filter(n -> n.getNodeType() == NodeType.VERIFIER)
                        .forEach(n -> {
                            n.setStatus(AssignmentStatus.PENDING);
                            n.setIsActive(true);
                        });
            }
            return;
        }
        // CASE 3: Verifier completed → filter once
        else {
            applyPostVerifierFilter(pathMap);
        }

        // PARALLEL EXECUTION
        for (List<FDAssignment> path : pathMap.values()) {
            if (isKilled(path)) continue;
            boolean isSequential = path.stream()
                    .anyMatch(FDAssignment::getIsSequential);
            if (isSequential) {
                processSequential(path);
            } else {
                processNonSequential(path);
            }
        }
        // SEQUENTIAL DIVERGENCE
        applySequentialDivergence(pathMap);
        // RELEASER ACTIVATION
        activateReleasers(pathMap);
        // CONVERGENCE
        applyConvergence(pathMap);
        // FINALIZE
        finalizeFD(fd, pathMap, midOffice);
    }


    private boolean isVerifierApproved(List<FDAssignment> all) {
        return all.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER
                        && n.getStatus() == AssignmentStatus.APPROVED);
    }

    private boolean isApproverActed(List<FDAssignment> all) {
        return all.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                        && n.getStatus() == AssignmentStatus.APPROVED);
    }

    private void applyPostVerifierFilter(Map<Long, List<FDAssignment>> pathMap) {
        for (List<FDAssignment> path : pathMap.values()) {
            boolean hasVerifier = path.stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER);
            if (!hasVerifier) {
                killPath(path);
            }
        }
    }

    private void processSequential(List<FDAssignment> path) {
        path.stream()
                .filter(n -> n.getNodeType() == NodeType.APPROVER)
                .filter(n -> n.getStatus() != AssignmentStatus.APPROVED)
                .min(Comparator.comparing(FDAssignment::getLevel))
                .ifPresent(n -> {
                    n.setStatus(AssignmentStatus.PENDING);
                    n.setIsActive(true);
                });
    }

    private void processNonSequential(List<FDAssignment> path) {
        boolean anyApproved = path.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                        && n.getStatus() == AssignmentStatus.APPROVED);
        if (anyApproved) return;
        for (FDAssignment n : path) {
            if (n.getNodeType() == NodeType.APPROVER) {
                n.setStatus(AssignmentStatus.PENDING);
                n.setIsActive(true);
            }
        }
    }

    private void applySequentialDivergence(Map<Long, List<FDAssignment>> pathMap) {
        List<List<FDAssignment>> seqPaths = pathMap.values().stream()
                .filter(p -> p.stream().anyMatch(FDAssignment::getIsSequential))
                .toList();
        if (seqPaths.size() <= 1) return;
        Integer divergenceLevel = null;
        Set<Integer> levels = seqPaths.stream()
                .flatMap(p -> p.stream())
                .map(FDAssignment::getLevel)
                .collect(Collectors.toSet());
        for (Integer level : levels.stream().sorted().toList()) {
            Set<Long> groups = new HashSet<>();
            for (List<FDAssignment> path : seqPaths) {
                path.stream()
                        .filter(n -> level.equals(n.getLevel()))
                        .findFirst()
                        .ifPresent(n -> groups.add(n.getGroupId()));
            }
            if (groups.size() > 1) {
                divergenceLevel = level;
                break;
            }
        }
        if (divergenceLevel == null) return;
        Long selectedGroup = null;
        for (List<FDAssignment> path : seqPaths) {
            for (FDAssignment n : path) {
                if (divergenceLevel.equals(n.getLevel())
                        && n.getStatus() == AssignmentStatus.APPROVED) {
                    selectedGroup = n.getGroupId();
                }
            }
        }
        if (selectedGroup == null) return;
        for (List<FDAssignment> path : seqPaths) {
            Integer finalDivergenceLevel = divergenceLevel;
            Long finalSelectedGroup = selectedGroup;
            boolean match = path.stream()
                    .anyMatch(n -> finalDivergenceLevel.equals(n.getLevel())
                            && finalSelectedGroup.equals(n.getGroupId()));
            if (!match) killPath(path);
        }
    }

    private void activateReleasers(Map<Long, List<FDAssignment>> pathMap) {
        for (List<FDAssignment> path : pathMap.values()) {
            Optional<FDAssignment> r = path.stream()
                    .filter(n -> n.getNodeType() == NodeType.RELEASER)
                    .findFirst();
            if (r.isEmpty()) continue;
            boolean isSequential = path.stream()
                    .anyMatch(FDAssignment::getIsSequential);
            if (isSequential) {
                boolean done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
                if (done) {
                    r.get().setStatus(AssignmentStatus.PENDING);
                    r.get().setIsActive(true);
                }
            } else {
                boolean any = path.stream()
                        .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                                && n.getStatus() == AssignmentStatus.APPROVED);
                if (any) {
                    r.get().setStatus(AssignmentStatus.PENDING);
                    r.get().setIsActive(true);
                }
            }
        }
    }

    private void applyConvergence(Map<Long, List<FDAssignment>> pathMap) {
        Long winner = null;
        for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
            boolean nonSeq = e.getValue().stream()
                    .anyMatch(n -> !n.getIsSequential());
            if (!nonSeq) continue;
            boolean approved = e.getValue().stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                            && n.getStatus() == AssignmentStatus.APPROVED);
            if (approved) {
                winner = e.getKey();
                break;
            }
        }
        if (winner == null) {
            for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
                boolean seq = e.getValue().stream()
                        .anyMatch(FDAssignment::getIsSequential);
                if (!seq) continue;
                boolean done = e.getValue().stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
                if (done) {
                    winner = e.getKey();
                    break;
                }
            }
        }
        if (winner != null) {
            for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
                if (!e.getKey().equals(winner)) {
                    killPath(e.getValue());
                }
            }
        }
    }

    private void finalizeFD(FixedDeposit fd,
                            Map<Long, List<FDAssignment>> pathMap,
                            boolean midOffice) {
        for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
            List<FDAssignment> path = e.getValue();
            boolean hasReleaser = path.stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.RELEASER);
            boolean done;
            if (hasReleaser) {
                done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.RELEASER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
            } else {
                done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
            }
            if (done) {
                fd.setAuthMatrixId(e.getKey());
                fd.setStatus(midOffice
                        ? FDStatus.PENDING_AT_MID_OFFICE
                        : FDStatus.APPROVED);
                return;
            }
        }
    }

    private boolean handleReleaserCompletion(List<FDAssignment> all,
                                             FixedDeposit fd,
                                             boolean midOffice) {
        Optional<FDAssignment> r = all.stream()
                .filter(n -> n.getNodeType() == NodeType.RELEASER)
                .filter(n -> n.getStatus() == AssignmentStatus.APPROVED)
                .findFirst();
        if (r.isEmpty()) return false;
        Long pathId = r.get().getAuthMatrixId();
        fd.setAuthMatrixId(pathId);
        fd.setStatus(midOffice
                ? FDStatus.PENDING_AT_MID_OFFICE
                : FDStatus.APPROVED);
        for (FDAssignment n : all) {
            if (!n.getAuthMatrixId().equals(pathId)
                    && n.getStatus() != AssignmentStatus.APPROVED) {
                n.setStatus(AssignmentStatus.VIEW_ONLY);
                n.setIsActive(false);
            }
        }
        return true;
    }

    // =========================================================
    private void killPath(List<FDAssignment> path) {
        for (FDAssignment n : path) {
            if (n.getStatus() != AssignmentStatus.APPROVED) {
                n.setStatus(AssignmentStatus.VIEW_ONLY);
                n.setIsActive(false);
            }
        }
    }

    private boolean isKilled(List<FDAssignment> path) {
        return path.stream()
                .allMatch(n -> n.getStatus() == AssignmentStatus.VIEW_ONLY);
    }

    private boolean match(FDAssignment a,
                          Long groupId,
                          String roleName) {
        if (a.getAssignmentType() == AssignmentType.GROUP) {
            return groupId != null && groupId.equals(a.getGroupId());
        }
        if (a.getAssignmentType() == AssignmentType.ROLE) {
            return roleName != null && roleName.equals(a.getUserType());
        }
        return false;
    }

    private void audit(FixedDeposit fd,
                       Long userId,
                       Long groupId,
                       Integer level,
                       ActionType action) {
        ApprovalAudit a = new ApprovalAudit();
        a.setFdId(fd.getId());
        a.setUserId(userId);
        a.setGroupId(groupId);
        a.setLevel(level);
        a.setAction(action);
        a.setTimestamp(LocalDateTime.now());
        auditRepo.save(a);
    }

    @Transactional
    @Override
    public void reject(Long fdId, Long userId, Long groupId, String reason) {

        FixedDeposit fd = fdRepo.findById(fdId)
                .orElseThrow(() -> new GTPAppException("FD not found", null));

        if (fd.getStatus() == FDStatus.APPROVED
                || fd.getStatus() == FDStatus.PENDING_AT_MID_OFFICE) {
            throw new GTPAppException("FD already approved. Reject not allowed.", null);
        }

        List<FDAssignment> all = assignmentRepo.findByFdId(fdId);

        // Identify current active assignment
        FDAssignment current = all.stream()
                .filter(a -> a.getIsActive() && a.getGroupId().equals(groupId))
                .findFirst()
                .orElseThrow(() -> new GTPAppException("Not allowed", null));

        int currentLevel = current.getLevel();

        //Set selected path
        fd.setAuthMatrixId(current.getAuthMatrixId());

        // Mark FD rejected
        fd.setStatus(FDStatus.REJECTED);
        fd.setRejectReason(reason);

        for (FDAssignment a : all) {

            // CURRENT NODE REJECTED
            if (a.getIsActive() && a.getGroupId().equals(groupId)) {
                a.setStatus(AssignmentStatus.REJECTED);
                a.setIsActive(false);
                continue;
            }

            // NON-SEQUENTIAL ALWAYS VIEW_ONLY
            if (!a.getIsSequential()) {
                if (a.getStatus() != AssignmentStatus.APPROVED) {
                    a.setStatus(AssignmentStatus.VIEW_ONLY);
                }
                a.setIsActive(false);
                continue;
            }

            // FUTURE NODES (SEQ)VIEW_ONLY
            if (a.getLevel() >= currentLevel) {
                if (a.getStatus() != AssignmentStatus.APPROVED) {
                    a.setStatus(AssignmentStatus.VIEW_ONLY);
                }
            }

            a.setIsActive(false);
        }

        //Audit
        audit(fd, userId, groupId, currentLevel, ActionType.REJECTED);

        fdRepo.saveAndFlush(fd);
    }

    // ================= REOPEN =================
    @Transactional
    @Override
    public void reopen(FixedDepositDto updated) {
//        fdRepo.deleteById(updated.getId());
        assignmentRepo.deleteAll(assignmentRepo.findByFdId(updated.getId()));
        assignmentRepo.flush();
        updated.setRejectReason(null);
        updated.setId(null);
        createFD(updated);
        audit(FixedDepositDto.convertToEntity(updated), updated.getMakerId(), null, null, ActionType.REOPENED);
    }

    // ================= CLOSE =================
    @Transactional
    @Override
    public void close(Long fdId, Long makerId) {
        FixedDeposit fd = fdRepo.findById(fdId).orElseThrow();
        if (fd.getStatus() != FDStatus.REJECTED) {
            throw new GTPAppException("Only rejected FD can be closed", null);
        }
        fd.setStatus(FDStatus.CLOSED);
        audit(fd, makerId, null, null, ActionType.CLOSED);
        fdRepo.saveAndFlush(fd);
    }


    @Override
    public Page<MakerTrayDTO> getMakerTray(Long makerId, Pageable pageable) {
        return fdRepo.findByMakerId(makerId, pageable)
                .map(fd -> new MakerTrayDTO(
                        fd.getId(),
                        fd.getAmount(),
                        fd.getStatus(),
                        fd.getRejectReason()
                ));
    }

    @Override
    public Page<CheckerFDTrayDTO> getCheckerTray(Long userId, Long groupId, Pageable pageable) {
        return assignmentRepo.findCheckerTray(userId, groupId, pageable)
                .map(CheckerFDTrayDTO::convertToDto);
    }

    @Override
    public Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTray(Long userId, String roleName, Pageable pageable) {
        return assignmentRepo.findReleaserOrVerifierTray(userId, roleName, pageable)
                .map(CheckerFDTrayDTO::convertToDto);
    }

    @Override
    public Page<FixedDepositDto> getAllFDByCifId(String cifId, Pageable pageable) {
        return fdRepo.findByCifId(cifId, pageable).map(FixedDepositDto::convertToDto);
    }

    @Override
    public void approveFdMidOffice(Long fdId, Long midOfficeUserId) {
        FixedDeposit fd = fdRepo.findById(fdId).orElseThrow();
        if (fd.getStatus() != FDStatus.PENDING_AT_MID_OFFICE) {
            throw new GTPAppException("Only Pending at Mid Office status can be approved", null);
        }
        fd.setStatus(FDStatus.MID_OFFICE_APPROVED);
        fd.setIsMidOfficeApproved(true);
        audit(fd, midOfficeUserId, null, null, ActionType.MID_OFFICE_APPROVED);
        fdRepo.saveAndFlush(fd);

    }

    @Override
    public void rejectFdMidOffice(Long fdId, Long midOfficeUserId) {
        FixedDeposit fd = fdRepo.findById(fdId).orElseThrow();
        if (fd.getStatus() != FDStatus.PENDING_AT_MID_OFFICE) {
            throw new GTPAppException("Only Pending at Mid Office status can be rejected", null);
        }
        fd.setStatus(FDStatus.MID_OFFICE_REJECTED);
        audit(fd, midOfficeUserId, null, null, ActionType.MID_OFFICE_REJECTED);
        fdRepo.saveAndFlush(fd);

    }

    @Override
    public Page<FixedDepositDto> getFDByStatus(List<String> status, Pageable page) {
        Page<FixedDeposit> fdPage =  fdRepo.findAllByStatusIn(status, page);
        Page<FixedDepositDto> fdPageDto = fdPage.map(FixedDepositDto :: convertToDto);

        return fdPageDto;
    }

    @Override
    public MidOfficeCountDTO getMidOfficeCounts() {
        MidOfficeCountProjection p = fdRepo.getMidOfficeCounts();
        return new MidOfficeCountDTO(
                "FD",
                safe(p.getPendingAtBank()),
                safe(p.getPendingAtClient()),
                safe(p.getProcessedByBank()),
                safe(p.getProcessedByClient())
        );
    }

    private Long safe(Long val) {
        return val == null ? 0L : val;
    }

}
