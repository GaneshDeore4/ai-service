-- =============================================================================
-- Admin Service — MSSQL bootstrap script
-- Run this ONCE against an empty GIFTCITY database after the application has
-- created the schema (Hibernate ddl-auto=update on first start). Idempotent —
-- safe to re-run; existing rows are skipped via IF NOT EXISTS guards.
--
-- Why this exists: the application's DataSeeder is OFF by default in prod
-- (seed.enabled=false, spring.sql.init.mode=never). The bank runs this script
-- in place of the auto-seeder.
--
-- Usage:
--   sqlcmd -S <host> -U <user> -P <pass> -d GIFTCITY -i bootstrap-mssql.sql
-- =============================================================================

USE GIFTCITY;
GO

-- MSSQL needs these SET options for tables with filtered indexes / computed columns
-- (Hibernate creates some). sqlcmd defaults differ from SSMS; set them explicitly.
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

-- -----------------------------------------------------------------------------
-- Reference: gtp_auth_group  (auth groups A..H, ids 1..8)
-- IDs are explicit so user-type ↔ auth-group references stay deterministic.
-- -----------------------------------------------------------------------------
SET IDENTITY_INSERT gtp_auth_group ON;

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 1) INSERT INTO gtp_auth_group (id, auth_group) VALUES (1, 'A');
IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 2) INSERT INTO gtp_auth_group (id, auth_group) VALUES (2, 'B');
IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 3) INSERT INTO gtp_auth_group (id, auth_group) VALUES (3, 'C');
IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 4) INSERT INTO gtp_auth_group (id, auth_group) VALUES (4, 'D');
IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 5) INSERT INTO gtp_auth_group (id, auth_group) VALUES (5, 'E');
IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 6) INSERT INTO gtp_auth_group (id, auth_group) VALUES (6, 'F');
IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 7) INSERT INTO gtp_auth_group (id, auth_group) VALUES (7, 'G');
IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 8) INSERT INTO gtp_auth_group (id, auth_group) VALUES (8, 'H');

SET IDENTITY_INSERT gtp_auth_group OFF;
GO


-- -----------------------------------------------------------------------------
-- Reference: gtp_category_master  (Client=1, Bank=2)
-- IDs are explicit so user-type FK references stay deterministic.
-- -----------------------------------------------------------------------------
SET IDENTITY_INSERT gtp_category_master ON;

IF NOT EXISTS (SELECT 1 FROM gtp_category_master WHERE category_id = 1) INSERT INTO gtp_category_master (category_id, category_name) VALUES (1, 'Client');
IF NOT EXISTS (SELECT 1 FROM gtp_category_master WHERE category_id = 2) INSERT INTO gtp_category_master (category_id, category_name) VALUES (2, 'Bank');

SET IDENTITY_INSERT gtp_category_master OFF;
GO


-- -----------------------------------------------------------------------------
-- Reference: gtp_user_type  (13 fixed user types)
-- 20 = Super Admin (used by the first bank super-admin user — see below).
-- -----------------------------------------------------------------------------
SET IDENTITY_INSERT gtp_user_type ON;

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 20) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (20, 'Super Admin',              2);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 21) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (21, 'Bank Super Admin Maker',   2);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 22) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (22, 'Bank Super Admin Checker', 2);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 23) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (23, 'Bank Setup Maker',         2);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 24) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (24, 'Bank Setup Checker',       2);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 25) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (25, 'Bank View Only',           2);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 26) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (26, 'Bank Branch Verifier',     2);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 27) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (27, 'Client (M=C)',             1);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 28) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (28, 'Client Maker',             1);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 29) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (29, 'Client Checker',           1);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 30) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (30, 'Client Verifier',          1);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 31) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (31, 'Client Releaser',          1);
IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 32) INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (32, 'Client View',              1);

SET IDENTITY_INSERT gtp_user_type OFF;
GO


-- -----------------------------------------------------------------------------
-- Bank profile + initial super-admin user
-- TEMPLATE — replace placeholder values with the bank's actual details before
-- running. Password is BCrypt-hashed; generate via:
--   spring.security.crypto.bcrypt.BCryptPasswordEncoder().encode("YourPlaintext")
-- The hash below corresponds to "Admin@123" (10-round BCrypt).
-- -----------------------------------------------------------------------------
DECLARE @bank_profile_id BIGINT;
DECLARE @bank_user_id    BIGINT;

-- TODO: fill in bank-specific values
DECLARE @cif_id           VARCHAR(50)  = 'BANK_CIF_001';
DECLARE @abbv_name        VARCHAR(50)  = 'BANK';
DECLARE @bank_name        VARCHAR(255) = 'Bank Name Here';
DECLARE @base_currency    VARCHAR(10)  = 'INR';
DECLARE @bank_email       VARCHAR(255) = 'admin@bank.example.com';

DECLARE @login_id         VARCHAR(50)  = 'SUPERADMIN';
DECLARE @first_name       VARCHAR(100) = 'Super';
DECLARE @last_name        VARCHAR(100) = 'Admin';
DECLARE @user_email       VARCHAR(255) = 'superadmin@bank.example.com';
DECLARE @password_bcrypt  VARCHAR(255) = '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy'; -- "Admin@123"

IF NOT EXISTS (SELECT 1 FROM gtp_bank_profile WHERE cif_id = @cif_id)
BEGIN
    -- gtp_bank_profile_temp has IDENTITY; insert there first to mint bank_profile_id,
    -- then mirror to gtp_bank_profile (which is plain bigint, accepts the value).
    INSERT INTO gtp_bank_profile_temp (cif_id, abbv_name, name, base_currency, email, status, maker_name, created_date)
        VALUES (@cif_id, @abbv_name, @bank_name, @base_currency, @bank_email, 'APPROVED', 'SYSTEM', SYSUTCDATETIME());
    SET @bank_profile_id = SCOPE_IDENTITY();

    INSERT INTO gtp_bank_profile (bank_profile_id, cif_id, abbv_name, name, base_currency, email, maker_name, created_date)
        VALUES (@bank_profile_id, @cif_id, @abbv_name, @bank_name, @base_currency, @bank_email, 'SYSTEM', SYSUTCDATETIME());

    -- gtp_bank_user_temp has IDENTITY; mint bank_user_id then mirror to gtp_bank_user.
    INSERT INTO gtp_bank_user_temp (login_id, first_name, last_name, email, status, bank_user_status, user_type_id, user_password, maker_name, created_at)
        VALUES (@login_id, @first_name, @last_name, @user_email, 'APPROVED', 'Active', 20, @password_bcrypt, 'SYSTEM', SYSUTCDATETIME());
    SET @bank_user_id = SCOPE_IDENTITY();

    INSERT INTO gtp_bank_user (bank_user_id, login_id, first_name, last_name, email, bank_user_status, user_type_id, user_password, maker_name, created_at)
        VALUES (@bank_user_id, @login_id, @first_name, @last_name, @user_email, 'Active', 20, @password_bcrypt, 'SYSTEM', SYSUTCDATETIME());

    PRINT 'Bootstrap: created bank profile + super-admin user.';
END
ELSE
BEGIN
    PRINT 'Bootstrap: bank profile with cif_id=' + @cif_id + ' already exists; skipped.';
END
GO


-- -----------------------------------------------------------------------------
-- Widget structure (products / sub-products / tabs / actions)
--
-- The application's DataSeeder loads this from src/main/resources/basewidget.yml
-- via JPA (5 products × 4 actions × varying sub-products / tabs).
-- Reproducing that as portable SQL is verbose; for the first bootstrap, one of:
--
--   (a) Run admin once with seed.enabled=true and spring.sql.init.mode=always
--       just to load the widget structure, then turn both back off; OR
--   (b) Insert via the admin REST APIs (/api/product, /api/subproduct,
--       /api/master/tab, /api/action and the mapping endpoints).
--
-- Reference data above is mandatory; widget structure is required for menus
-- to render but can be edited after bootstrap.
-- -----------------------------------------------------------------------------
PRINT 'Bootstrap complete. Widget structure: see comment block above.';
GO
