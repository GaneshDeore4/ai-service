package com.indusind.trade.admin.client;

import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "CustomerProfileClient", url = "${app.feign.customer.profile.info-url}")
public interface CustomerProfileClient {

    @PostMapping(value = "/customerenquiry/cifid/V1",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    IBLGatewayResponse fetchCustomerProfile(
            @RequestHeader("IBL-Client-Id") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody String encryptedEnvelope
    );
}
