package com.indusind.trade.admin.client;

import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(
        name = "app-fixed-deposit-service",
        url = "${fd.service.url}",
        fallback = FDClientFallback.class
)
public interface FDClient {
    @GetMapping("/api/fd/v2/count")
    MidOfficeCountDTO getFDCounts();
}