package com.indusind.trade.admin.client;

import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import org.springframework.stereotype.Component;

@Component
public class FDClientFallback implements FDClient {
    public MidOfficeCountDTO getFDCounts() {
        return new MidOfficeCountDTO("FD",0L,0L,0L,0L);
    }
}
