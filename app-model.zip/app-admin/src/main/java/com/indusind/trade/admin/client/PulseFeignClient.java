package com.indusind.trade.admin.client;

import com.indusind.trade.admin.dto.AdrenalinTokenResponseDto;
import com.indusind.trade.admin.dto.PulseApiResponse;
import com.indusind.trade.admin.dto.PulseEmpRequestDto;
import com.indusind.trade.model.dtos.response.dtos.PulseDetailsResponseDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "pulseFeignClient", url = "${mpulse.uat.url}")
public interface PulseFeignClient {

    @Value("{}")

    @PostMapping
    public PulseDetailsResponseDto getPulseDeatilsByPulseId(@RequestHeader("IBL-Client-ID") String clientId,
                                                            @RequestHeader("IBL-Client-Secret") String clientSecret, @RequestBody String pulseId);

//    @PostMapping(value = "/CloudAPI/Adrenalintoken", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
//    public AdrenalinTokenResponseDto getAdrenalinToken(@RequestParam("username") String username,
//                                                       @RequestParam("password") String password,
//                                                       @RequestParam("grant_type") String grantType);

    @PostMapping(value = "/CloudAPI/Adrenalintoken", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public AdrenalinTokenResponseDto getAdrenalinToken(@RequestBody MultiValueMap<String, String> requestMap);


    @PostMapping(value = "/CloudAPI/HRdata/Getdata")
    public List<PulseApiResponse> getEmployeeData(@RequestHeader("Authorization") String token, @RequestBody List<PulseEmpRequestDto> pulseEmpRequestDto);
}
