package com.indusind.trade.admin.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@ConfigurationProperties(prefix = "seed.bank")
public class BankSeedProperties {

    private List<BankProfileSeed> profile;
    private List<BankUserSeed> user;

    @Data
    public static class BankProfileSeed {
        private String cifId;
        private String abbvName;
        private String name;
        private String baseCurrency;
        private String email;
    }

    @Data
    public static class BankUserSeed {
        private String loginId;
        private String firstName;
        private String lastName;
        private String userType;
        private String email;
        private String contactNo;
        private String password;
    }
}
