package com.indusind.trade.admin.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "seed.widget")
@Data
public class BaseWidgetSeedProperties {
    private List<ProductSeed> products;
    @Data
    public static class ProductSeed {
        private String name;
        private Long category;
        private List<String> actions;
        private Long sequenceId;
        private List<SubProductSeed> subProducts;
    }
    @Data
    public static class SubProductSeed {
        private String name;
        private Long sequenceId;
        private List<TabSeed> tabs;
    }
    @Data
    public static class TabSeed {
        private String name;
    }
}
