package com.indusind.trade.admin.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@Data
@ConfigurationProperties(prefix = "seed.company")
public class CompanySeedProperties {

    private List<CompanyProfileSeed> profile;
    private List<CompanyUserSeed> user;

    @Data
    public static class CompanyProfileSeed {
        private String cifId;
        private String abbvName;
        private String name;
        private String baseCurrency;
        private String email;
    }

    @Data
    public static class CompanyUserSeed {
        private String loginId;
        private String firstName;
        private String lastName;
        private String userType;
        private String email;
        private String password;
    }
}
