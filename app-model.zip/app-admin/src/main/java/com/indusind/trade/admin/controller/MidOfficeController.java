package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.service.MidOfficeDashboardService;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/mid-office")
public class MidOfficeController {

    private final MidOfficeDashboardService service;


    @GetMapping("/dashboard")
    public ResponseEntity<List<MidOfficeCountDTO>> get() {
        return ResponseEntity.status(HttpStatus.OK).body(service.fd());
    }

}
