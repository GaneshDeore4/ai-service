package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.NotificationFacade;
import com.indusind.trade.model.dtos.requestdtos.NotificationRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notification")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationFacade notificationFacade;

    @PostMapping("/addNotification")
    public ResponseEntity<ApplicationResponse> saveNotification(@RequestBody NotificationRequestDto notificationRequestDto){
        ApplicationResponse response = notificationFacade.saveNotification(notificationRequestDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllNotifications")
    public ResponseEntity<ApplicationResponse> getAllNotifications(@PageableDefault(page = 0, size = 10, sort = "validUpto", direction = Sort.Direction.DESC) Pageable pageable){
        ApplicationResponse response = notificationFacade.getAllNotifications(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getClientNotificationById")
    public ResponseEntity<ApplicationResponse> getNotificationById(@RequestParam Long notificationId){
        ApplicationResponse response = notificationFacade.getNotificationById(notificationId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getNotificationById")
    public ResponseEntity<ApplicationResponse> getTempNotificationById(@RequestParam Long notificationId){
        ApplicationResponse response = notificationFacade.getNotificationTempById(notificationId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/deleteNotificationById")
    public ResponseEntity<ApplicationResponse> deleteNotificationById(@RequestParam Long notificationId){
        ApplicationResponse response = notificationFacade.deleteNotificationById(notificationId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllClientNotifications")
    public ResponseEntity<ApplicationResponse> getAllClientNotifications(){
        ApplicationResponse response = notificationFacade.getAllNotificationsClient();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveNotification")
    public ResponseEntity<ApplicationResponse> approveNotification(@RequestParam Long notificationId){
        ApplicationResponse response = notificationFacade.approveNotification(notificationId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectNotification")
    public ResponseEntity<ApplicationResponse> rejectNotification(@RequestParam Long notificationId){
        ApplicationResponse response = notificationFacade.rejectNotification(notificationId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/toggleNotification")
    public ResponseEntity<ApplicationResponse> toggleNotification(@RequestParam Long notificationId, @RequestBody NotificationRequestDto notificationRequestDto){
        ApplicationResponse response = notificationFacade.toggleNotification(notificationRequestDto, notificationId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
