package com.indusind.trade.admin.entities;

import com.indusind.trade.admin.enums.EmailCategory;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name="gtp_email_audit")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmailAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String recipientEmail;

    private String subject;

    private String emailContent;

    @Enumerated(EnumType.STRING)
    private EmailCategory emailCategory;

    @CreationTimestamp
    private LocalDateTime emailSentDate;

    private String status;

}
