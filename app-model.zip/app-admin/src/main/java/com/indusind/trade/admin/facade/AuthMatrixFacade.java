package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.AddAuthMatrixRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AuthMatrixFacade {
//    ApplicationResponse saveAuthMatrix(AddAuthMatrixRequestDto request);

    ApplicationResponse addAuthMatrix(AddAuthMatrixRequestDto request);

    ApplicationResponse getAuthMatrixById(Long id, String category);

    ApplicationResponse getAuthMatrixTempById(Long id, String category);

    ApplicationResponse getAllAuthMatrix(Pageable page, String category,Long companyId);

    ApplicationResponse getAllAuthMatrixTemp(Pageable page, String category, Long companyId);

    ApplicationResponse approveAuthMatrix(Long id);

    ApplicationResponse approveGroupedAuthMatrix(List<Long> ids);

    ApplicationResponse rejectGroupedAuthMatrix(List<Long> ids);

    ApplicationResponse rejectAuthMatrix(Long id);

    ApplicationResponse getAllAuthMatrixTempAllMapping(Pageable pageable,
                                                       String category,Long compnayId);

    ApplicationResponse getAllAuthMatrixAllMapping(Pageable pageable, String category, Long companyId);
}
