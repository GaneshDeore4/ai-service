package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.CompanyRequestDto;
import com.indusind.trade.model.dtos.requestdtos.CustomerProfileRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface CompanyFacade {

    ApplicationResponse saveCompanyTemp(CompanyRequestDto companyDto);

    ApplicationResponse getAllTempCompanies(Pageable pageable);

    ApplicationResponse getAllCompanies(Pageable pageable);

    ApplicationResponse getCompanyTempById(Long companyId);

    ApplicationResponse getCompanyById(Long companyId);

    ApplicationResponse approveCompanyTemp(Long companyId);

    ApplicationResponse rejectCompanyTemp(Long companyId);

    ApplicationResponse getProdSubProdMapByCompanyTemp(Long companyTempTd);

    ApplicationResponse getProdSubProdMapByCompany(Long companyId);

    ApplicationResponse fetchCustomerProfileByCifId(Long cifId);

//    ApplicationResponse getAllTempCompaniesByCategory(Pageable pageable, Long categoryId);
//
//    ApplicationResponse getAllCompaniesByCategory(Pageable pageable, Long categoryId);
}
