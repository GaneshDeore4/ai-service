package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.DepartmentRequestDto;
import com.indusind.trade.model.dtos.requestdtos.DepartmentToUserTypeMappingRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;


public interface DepartmentFacade {

    ApplicationResponse getAllDepartments();

    ApplicationResponse getDeptByCategoryId(Long categoryId);

    ApplicationResponse approveDepartment(Long departmentId);

    ApplicationResponse rejectDepartment(Long departmentId);

    ApplicationResponse getAllTempDepartments(Pageable pageable);

    ApplicationResponse getTempDeptById(Long departmentId);

    ApplicationResponse getDeptById(Long departmentId);

    ApplicationResponse mapUserTypesWithDepartment(DepartmentToUserTypeMappingRequestDto request);

    ApplicationResponse createDepartment(DepartmentRequestDto request);
}
