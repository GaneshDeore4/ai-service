package com.indusind.trade.admin.facade;

import com.indusind.trade.admin.enums.EmailCategory;

import java.util.Map;

public interface EmailFacade {
//    Map<String, Object> sendEmail(String toAddress, String subject, String emailContent);

    Map<String, Object> sendEmail(String toAddress, String subject, String emailContent, EmailCategory category);
}
