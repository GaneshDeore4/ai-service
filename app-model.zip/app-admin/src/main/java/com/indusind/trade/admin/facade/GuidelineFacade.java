package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.GuidelineRequestDto;
import com.indusind.trade.model.dtos.requestdtos.NotificationRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface GuidelineFacade {

    ApplicationResponse saveGuideline(GuidelineRequestDto guidelineRequestDto);
    ApplicationResponse getAllGuidelines(Pageable pageable);
    ApplicationResponse getGuidelineById(Long id);

    ApplicationResponse getGuidelineTempById(Long id);
    ApplicationResponse approveGuideline(Long id);

    ApplicationResponse rejectGuideline(Long id);

    ApplicationResponse toggleGuideline(GuidelineRequestDto guidelineRequestDto, Long id);

    ApplicationResponse getAllGuidelinesClient(Pageable pageable);

    ApplicationResponse deleteGuidelineById(Long id);
}
