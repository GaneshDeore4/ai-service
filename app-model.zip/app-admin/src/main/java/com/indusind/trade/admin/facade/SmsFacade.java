package com.indusind.trade.admin.facade;

import java.util.HashMap;

public interface SmsFacade {

    public HashMap<String, String> sendSms(long contactNo);
}
