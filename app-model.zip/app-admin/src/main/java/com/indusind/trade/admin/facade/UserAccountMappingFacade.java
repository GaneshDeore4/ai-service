package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.AddUserAccountMappingRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;

import java.util.List;

public interface UserAccountMappingFacade {

    ApplicationResponse getAccountsByCifId(String cifId);

    ApplicationResponse addUserAccountMapping(AddUserAccountMappingRequestDto request);

    ApplicationResponse addBulkUserAccountMapping(List<AddUserAccountMappingRequestDto> request);

    ApplicationResponse getAccountsByUserId(Long userId);

}
