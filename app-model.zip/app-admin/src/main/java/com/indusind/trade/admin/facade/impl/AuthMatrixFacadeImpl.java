package com.indusind.trade.admin.facade.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.trade.admin.facade.AuthMatrixFacade;
import com.indusind.trade.model.dtos.requestdtos.AddAuthMatrixRequestDto;
import com.indusind.trade.model.dtos.response.dtos.AccountDetailsDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupedDto;
import com.indusind.trade.model.dtos.response.dtos.AuthMatrixResponseDto;
import com.indusind.trade.model.entities.company.*;
import com.indusind.trade.model.entities.master.EventTypeTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.enums.AuthType;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.service.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Component
@RequiredArgsConstructor
public class AuthMatrixFacadeImpl implements AuthMatrixFacade {

    private static final Logger log = LoggerFactory.getLogger(AuthMatrixFacadeImpl.class);
    private final AuthMatrixTempService authMatrixTempService;
    private final AuthMatrixService authMatrixService;
    private final ProductMasterService productMasterService;
    private final SubProductMasterService subProductMasterService;
    private final AuthGroupService authGroupService;
    private final CompanyService companyService;
    private final ObjectMapper objectMapper;
    private final UserAccountMappingService accountMappingService;

//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public ApplicationResponse saveAuthMatrix(AddAuthMatrixRequestDto request) {
//
//        Company company = companyService.getCompanyById(request.companyId());
//
//        AuthMatrixTemp authMatrixTemp = null;
//        if(Objects.nonNull(request.authMatId())) {
//            authMatrixTemp = authMatrixTempService.getAuthMatrixTempById(request.authMatId());
//
//            clearAuthMatrixTempAuthLevelMapping(authMatrixTemp);
//
//            authMatrixTemp = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, authMatrixTemp);
//
//        } else {
//            authMatrixTemp = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, new AuthMatrixTemp());
//        }
//
//        authMatrixTemp.setStatus(Status.PENDING.toString());
//        authMatrixTempService.flush();
//
//
//        List<AuthLevelTemp> authLevel = createAuthLevelTempMapping(request, authMatrixTemp);
//
//
//        authMatrixTemp.getAuthLevels().addAll(authLevel);
//
//        createProductSubProductCompanyMapping(request, authMatrixTemp, company);
//
//        authMatrixTemp.setAuthType(getAuthType(request.eventType()));
//
//        AuthMatrixTemp savedMatrix = authMatrixTempService.saveAuthMatrix(authMatrixTemp);
//
//        AuthMatrixResponseDto authMatrixResponseDto = AuthMatrixResponseDto.builder()
//                .authMatId(savedMatrix.getId())
//                .build();
//
//        return new ApplicationResponse("SUCCESS", authMatrixResponseDto, "Matrix saved successfully");
//    }

//    @Override
//    @Transactional(rollbackFor = Exception.class)
//    public ApplicationResponse saveAuthMatrix(AddAuthMatrixRequestDto request) {
//
//        Company company = companyService.getCompanyById(request.companyId());
//
//        AuthMatrixTemp authMatrixTemp = null;
//        if(Objects.nonNull(request.authMatId())) {
//            authMatrixTemp = authMatrixTempService.getAuthMatrixTempById(request.authMatId());
//
//            clearAuthMatrixTempAuthLevelMapping(authMatrixTemp);
//            authMatrixTempService.flush();
//
//            authMatrixTemp = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, authMatrixTemp);
//
//        } else {
//            authMatrixTemp = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, new AuthMatrixTemp());
//        }
//
//        authMatrixTemp.setStatus(Status.PENDING.toString());
//
//
//        if(request.allProductFlag()) {
//            List<ProductMaster> productsList = productMasterService.getAllProducts();
//
//            if(productsList.size() == 0 || productsList.isEmpty()){
//                throw new GTPAppException("No products found", null);
//            }
//
//            List<AuthMatrixTemp> authMatList = new ArrayList<>();
//
//            for(ProductMaster product : productsList) {
//                List<SubProductMaster> subProductMasterList = product.getSubProductMasterList();
//
//                for(SubProductMaster subProduct : subProductMasterList) {
//                    AuthMatrixTemp authMatrixTemp1 = new AuthMatrixTemp();
//                    BeanUtils.copyProperties(authMatrixTemp, authMatrixTemp1);
//                    List<AuthLevelTemp> authLevel = createAuthLevelTempMapping(request, authMatrixTemp1);
//
//                    authMatrixTemp1.getAuthLevels().addAll(authLevel);
//
//                    createProductSubProductCompanyMapping(product, authMatrixTemp1, subProduct, company);
//
//                    List<EventTypeTemp> eventTypes = createEventTypeTempMapping(request.eventType(), authMatrixTemp1);
//
//                    authMatrixTemp1.setEventTypes(eventTypes);
//                    authMatrixTemp1.setIsAllProductFlag(true);
//
////                    authMatrixTempService.saveAuthMatrix(authMatrixTemp1);
//
//                    authMatList.add(authMatrixTemp1);
//
//                }
//
//            }
//
//            authMatrixTempService.saveAllAuthMatrix(authMatList);
//        } else {
//            List<AuthLevelTemp> authLevel = createAuthLevelTempMapping(request, authMatrixTemp);
//
//
//            authMatrixTemp.getAuthLevels().addAll(authLevel);
//
//            createProductSubProductCompanyMapping(request, authMatrixTemp, company);
//
//            List<EventTypeTemp> eventTypeTemps = createEventTypeTempMapping(request.eventType(), authMatrixTemp);
//
//            authMatrixTemp.setEventTypes(eventTypeTemps);
//
//            authMatrixTempService.saveAuthMatrix(authMatrixTemp);
//        }
//
//        return new ApplicationResponse("SUCCESS", null, "Matrix saved successfully");
//    }


    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse addAuthMatrix(AddAuthMatrixRequestDto request) {

        Company company = companyService.getCompanyById(request.companyId());
        List<AccountDetail> accounts = accountMappingService.findAccountsById(request.accountIds());

        if(request.isUpdate()) {
            // update case
            if(request.allProductFlag()) {
                // update for all

                boolean existsByNewAmount = isExistsByNewAmount(request);

                if(!request.oldAmount().equals(request.amount()) && existsByNewAmount && !request.isAccListUpdated()) {
                    throw new GTPAppException("This combination already exists", null);
                }

                List<AuthMatrixTemp> authMatrixTempList = authMatrixTempService.getByCompanyAmountIsAllProductFlag(company.getCompanyId(), request.oldAmount(), true, request.currencyType());



                List<AuthMatrixTemp> authMatrixUpdatedList = new ArrayList<>();

                for(int i = 0; i < authMatrixTempList.size();i++) {
                    AuthMatrixTemp authMatrixTemp1 = authMatrixTempList.get(i);
                    List<ProductMaster> productsList = productMasterService.getAllProducts();

                    if(productsList.size() == 0 || productsList.isEmpty()){
                        throw new GTPAppException("No products found", null);
                    }

                    for(ProductMaster product : productsList) {
                        List<SubProductMaster> subProductMasterList = product.getSubProductMasterList();

                        for(SubProductMaster subProduct : subProductMasterList) {
                            clearAuthMatrixTempAuthLevelMapping(authMatrixTemp1);
                            authMatrixTempService.flush();

                            Long authMatId = authMatrixTemp1.getId();

                            authMatrixTemp1 = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, authMatrixTemp1);

                            authMatrixTemp1.setId(authMatId);

                            authMatrixTemp1 = getAuthMatrixTempForInsertion(request, product, subProduct, authMatrixTemp1, company);

                            authMatrixTemp1.getAccounts().addAll(accounts);

                            authMatrixUpdatedList.add(authMatrixTemp1);
                        }

                    }



                }

                authMatrixTempService.saveAllAuthMatrix(authMatrixUpdatedList);

            } else {
                // explicit update scenario
                ProductMaster product = productMasterService.getProductById(request.productId());

                SubProductMaster subProduct = subProductMasterService.getSubProductById(request.subProductId());

                boolean existsFlag = authMatrixTempService.existsByCompanyProductSubProductAmt(company, product, subProduct, request.amount(), request.currencyType());

                if(!request.oldAmount().equals(request.amount()) && existsFlag && !request.isAccListUpdated()) {
                    throw new GTPAppException("This combination of Auth Matrix Already exists.", null);
                }

                AuthMatrixTemp authMatrixTemp1 = authMatrixTempService.getAuthMatrixTempById(request.authMatId());

                clearAuthMatrixTempAuthLevelMapping(authMatrixTemp1);
                authMatrixTempService.flush();

                authMatrixTemp1 = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, authMatrixTemp1);

                authMatrixTemp1 = getAuthMatrixTempForInsertion(request, product, subProduct, authMatrixTemp1, company);

                authMatrixTemp1.getAccounts().addAll(accounts);


                authMatrixTempService.saveAuthMatrix(authMatrixTemp1);

            }
        } else {
            // new insert case
            if(request.allProductFlag()) {
                // insert for all

                List<ProductMaster> productMasterList = productMasterService.getAllProducts();

                if(productMasterList.size() == 0 || productMasterList.isEmpty()){
                    throw new GTPAppException("No products found", null);
                }

                List<AuthMatrixTemp> authMatList = new ArrayList<>();

                for(ProductMaster product : productMasterList) {

                    List<SubProductMaster> subProductMasterList = product.getSubProductMasterList();

                    for(SubProductMaster subProduct : subProductMasterList) {

                        if(!authMatrixTempService.existsByCompanyProductSubProductAmt(company, product, subProduct, request.amount(), request.currencyType())) {

                            AuthMatrixTemp authMatrixTemp1 = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, new AuthMatrixTemp());

                            authMatrixTemp1 = getAuthMatrixTempForInsertion(request, product, subProduct, authMatrixTemp1, company);
                            authMatrixTemp1.setIsAllProductFlag(true);
                            authMatrixTemp1.getAccounts().addAll(accounts);

                            authMatList.add(authMatrixTemp1);
                        }

                    }

                }

                authMatrixTempService.saveAllAuthMatrix(authMatList);

            } else {
                // explicit insert scenario
                ProductMaster product = productMasterService.getProductById(request.productId());

                SubProductMaster subProduct = subProductMasterService.getSubProductById(request.subProductId());

                if(authMatrixTempService.existsByCompanyProductSubProductAmtIsAllProductFlag(company, product, subProduct, request.amount(), false, request.currencyType())) {
                    // update the authMatrix
                    AuthMatrixTemp existingAuthMatrixTemp = authMatrixTempService.findByCompanyProductSubProductAmtIsAllProductFlag(company.getCompanyId(), product.getProductId(), subProduct.getSubProductId(), request.amount(), false, request.currencyType());

                    clearAuthMatrixTempAuthLevelMapping(existingAuthMatrixTemp);
                    authMatrixTempService.flush();

                    Long existingId = existingAuthMatrixTemp.getId();

                    existingAuthMatrixTemp = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, existingAuthMatrixTemp);

                    existingAuthMatrixTemp.setId(existingId);

                    existingAuthMatrixTemp = getAuthMatrixTempForInsertion(request, product, subProduct, existingAuthMatrixTemp, company);

                    existingAuthMatrixTemp.getAccounts().addAll(accounts);


                    authMatrixTempService.saveAuthMatrix(existingAuthMatrixTemp);



                } else {

                    AuthMatrixTemp authMatrixTemp1 = AuthMatrixTemp.convertFromAddReqDtoToTemp(request, new AuthMatrixTemp());

                    authMatrixTemp1 = getAuthMatrixTempForInsertion(request, product, subProduct, authMatrixTemp1, company);

                    authMatrixTemp1.setIsAllProductFlag(false);

                    authMatrixTemp1.getAccounts().addAll(accounts);

                    authMatrixTempService.saveAuthMatrix(authMatrixTemp1);

                }
            }
        }


        return new ApplicationResponse("SUCCESS", null, "Auth matrix saved");
    }

    private boolean isExistsByNewAmount(AddAuthMatrixRequestDto request) {
        boolean existsByNewAmount = authMatrixTempService.existsByCompanyIdAmountIsAllFlag(request.companyId(), request.amount(), true, request.currencyType());
        return existsByNewAmount;
    }

    private AuthMatrixTemp getAuthMatrixTempForInsertion(AddAuthMatrixRequestDto request, ProductMaster product, SubProductMaster subProduct, AuthMatrixTemp authMatrixTemp, Company company) {
        AuthMatrixTemp authMatrixTemp1 = new AuthMatrixTemp();
        BeanUtils.copyProperties(authMatrixTemp, authMatrixTemp1);

        authMatrixTemp1.setStatus(Status.PENDING.toString());
        List<AuthLevelTemp> authLevel = createAuthLevelTempMapping(request, authMatrixTemp1);

        authMatrixTemp1.getAuthLevels().addAll(authLevel);

        createProductSubProductCompanyMapping(product, authMatrixTemp1, subProduct, company);

//        List<EventTypeTemp> eventTypes = createEventTypeTempMapping(request.eventType(), authMatrixTemp1);
//
//        authMatrixTemp1.setEventTypes(eventTypes);

        return authMatrixTemp1;
    }

    private List<EventTypeTemp> createEventTypeTempMapping(String event, AuthMatrixTemp authMatrixTemp1) {
        List<EventTypeTemp> eventTypeTemps = new ArrayList<>();
        if(event.equalsIgnoreCase("all")) {
            for(AuthType authType : AuthType.values()) {
                EventTypeTemp eventTypeTemp = EventTypeTemp.builder()
                        .authMatrix(authMatrixTemp1)
                        .eventType(authType)
                        .build();

                eventTypeTemps.add(eventTypeTemp);
            }
        } else {
            AuthType authType = getAuthType(event);
            EventTypeTemp eventTypeTemp = EventTypeTemp.builder()
                    .authMatrix(authMatrixTemp1)
                    .eventType(authType)
                    .build();

            eventTypeTemps.add(eventTypeTemp);
        }

        return eventTypeTemps;
    }

    private List<AuthLevelTemp> createAuthLevelTempMapping(AddAuthMatrixRequestDto request, AuthMatrixTemp authMatrixTemp) {
        List<AuthLevelTemp> authLevel = new ArrayList<>();

        if(!request.isSequential()) {
            authLevel = request.authGroupIds().stream()
                    .map(level -> getAuthLevel(level, -1, authMatrixTemp))
                    .toList();
        } else {
            for(int i = 0; i< request.authGroupIds().size(); i++) {
                authLevel.add(getAuthLevel(request.authGroupIds().get(i), i, authMatrixTemp));
            }
        }
        return authLevel;
    }

    private void createProductSubProductCompanyMapping(AddAuthMatrixRequestDto request, AuthMatrixTemp authMatrixTemp, Company company) {
        ProductMaster product = productMasterService.getProductById(request.productId());

        SubProductMaster subProduct = subProductMasterService.getSubProductById(request.subProductId());

        authMatrixTemp.setCompany(company);
        authMatrixTemp.setProduct(product);
        authMatrixTemp.setSubProduct(subProduct);
    }

    private void createProductSubProductCompanyMapping(ProductMaster product, AuthMatrixTemp authMatrixTemp, SubProductMaster subProduct, Company company) {

        authMatrixTemp.setCompany(company);
        authMatrixTemp.setProduct(product);
        authMatrixTemp.setSubProduct(subProduct);
    }

    private void clearAuthMatrixTempAuthLevelMapping(AuthMatrixTemp authMatrixTemp) {
        authMatrixTemp.getAuthLevels().clear();
//        authMatrixTemp.getEventTypes().clear();
        authMatrixTemp.getAccounts().clear();
    }

    @Override
    public ApplicationResponse getAuthMatrixById(Long id, String category) {
        AuthMatrix matrix = authMatrixService.getAuthMatrixById(id, category);
        AuthMatrixResponseDto dto = convertToDto(matrix);
        dto.setAuthGroup(
                matrix.getAuthLevels().stream()
                        .map(level -> Map.of(level.getAuthGroup().getId() + "-" + level.getAuthGroup().getAuthGroup(),  Objects.nonNull(level.getSeqNo()) ? level.getSeqNo():-1))
                        .toList()
        );
        return new ApplicationResponse("SUCCESS", dto, "auth matrix fetched");
    }

    @Override
    public ApplicationResponse getAuthMatrixTempById(Long id, String category) {
        AuthMatrixTemp matrix = authMatrixTempService.getAuthMatrixTempById(id);
        AuthMatrixResponseDto dto = convertTempToDto(matrix);
        dto.setAuthGroup(
                matrix.getAuthLevels().stream()
                        .map(level -> Map.of(level.getAuthGroup().getId() + "-" + level.getAuthGroup().getAuthGroup(),  Objects.nonNull(level.getSeqNo()) ? level.getSeqNo():-1))
                        .toList()
        );
        return new ApplicationResponse("SUCCESS", dto, "auth matrix fetched");
    }

    @Override
    public ApplicationResponse getAllAuthMatrix(Pageable page, String category, Long companyId) {
        Page<AuthMatrix> authMatrixPage = authMatrixService.getAllAuthMatrix(page, category,companyId);

        Page<AuthMatrixResponseDto> responsePage = authMatrixPage.map(this::convertToDto);

        return new ApplicationResponse("SUCCESS", responsePage, "auth matrix list fetched");
    }

    @Override
    public ApplicationResponse getAllAuthMatrixTemp(Pageable pageable, String category, Long companyId) {
        Page<AuthMatrixTemp> authMatrixPage = authMatrixTempService.getAllAuthMatrix(pageable, category, companyId);

        Page<AuthMatrixResponseDto> responsePage = authMatrixPage.map(this::convertTempToDto);

        return new ApplicationResponse("SUCCESS", responsePage, "auth matrix list fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse approveAuthMatrix(Long id) {
        AuthMatrixTemp authMatrixTemp = null;
        AuthMatrix authMatrix = null;
        authMatrixTemp = authMatrixTempService.getAuthMatrixTempById(id);
        authMatrixTemp.setStatus(Status.APPROVED.toString());

        authMatrixTemp = authMatrixTempService.saveAuthMatrix(authMatrixTemp);

        Boolean existsFlag = authMatrixService.existsAuthMatrix(id);

        if(existsFlag) {
            authMatrix = authMatrixService.getAuthMatrixById(id);
            clearAuthMatrixAuthLevelMapping(authMatrix);
            authMatrixService.flush();

            authMatrix = AuthMatrixTemp.convertToMaster(authMatrixTemp, authMatrix);
        } else {
            authMatrix = AuthMatrixTemp.convertToMaster(authMatrixTemp, new AuthMatrix());
        }

        authMatrix.setCompany(authMatrixTemp.getCompany());
        authMatrix.setProduct(authMatrixTemp.getProduct());
        authMatrix.setSubProduct(authMatrixTemp.getSubProduct());

        AuthMatrix savedAuthMatrix  = authMatrixService.saveAuthMatrix(authMatrix);

        AuthMatrixResponseDto authMatrixResponseDto = AuthMatrixResponseDto.builder()
                .authMatId(savedAuthMatrix.getId())
                .build();

        return new ApplicationResponse("SUCCESS", authMatrixResponseDto, "auth matrix approved");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse approveGroupedAuthMatrix(List<Long> ids) {
        List<AuthMatrixResponseDto> responseList = new ArrayList<>();
        for(Long id : ids) {
            AuthMatrixResponseDto responseDto = (AuthMatrixResponseDto) approveAuthMatrix(id).getPayload();
            responseList.add(responseDto);
        }
        return new ApplicationResponse("SUCCESS", responseList, "auth matrix approved");
    }

    @Override
    public ApplicationResponse rejectGroupedAuthMatrix(List<Long> ids) {
        List<AuthMatrixResponseDto> responseList = new ArrayList<>();
        for(Long id : ids) {
            AuthMatrixResponseDto responseDto = (AuthMatrixResponseDto) rejectAuthMatrix(id).getPayload();
            responseList.add(responseDto);
        }
        return new ApplicationResponse("SUCCESS", responseList, "auth matrix rejected");
    }

    private void clearAuthMatrixAuthLevelMapping(AuthMatrix authMatrix) {
        authMatrix.getAuthLevels().clear();
        authMatrix.getAccounts().clear();
//        authMatrix.getEventTypes().clear();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse rejectAuthMatrix(Long id) {
        AuthMatrixTemp authMatrixTempSaved = null;

        AuthMatrixTemp authMatrixTemp = authMatrixTempService.getAuthMatrixTempById(id);



        boolean existsFlag = authMatrixService.existsAuthMatrix(id);

        if(existsFlag) {
            clearAuthMatrixTempAuthLevelMapping(authMatrixTemp);
            authMatrixTempService.flush();
            AuthMatrix authMatrix = authMatrixService.getAuthMatrixById(id);

            authMatrixTemp = AuthMatrix.convertToTemp(authMatrix, authMatrixTemp);

            authMatrixTemp.setStatus(Status.UPDATE_REJECTED.toString());

            authMatrixTempSaved = authMatrixTempService.saveAuthMatrix(authMatrixTemp);

            clearAuthMatrixAuthLevelMapping(authMatrix);

            authMatrixService.flush();

//            authMatrix.setCompany(authMatrixTempSaved.getCompany());
//            authMatrix.setProduct(authMatrixTempSaved.getProduct());
//            authMatrix.setSubProduct(authMatrixTempSaved.getSubProduct());

            authMatrix.getAuthLevels().addAll((authMatrixTemp.getAuthLevels().stream().map(
                    mat -> {
                        AuthLevel authLevel = AuthLevelTemp.convertToMaster(mat);
                        authLevel.setAuthMatrix(authMatrix);
                        return authLevel;
                    }
            ).toList()));

            authMatrixService.saveAuthMatrix(authMatrix);


        } else {
            //authMatrixTemp.getAuthLevels().clear();
            authMatrixTemp.setStatus(Status.REJECTED.toString());

            authMatrixTempSaved = authMatrixTempService.saveAuthMatrix(authMatrixTemp);
        }


        AuthMatrixResponseDto authMatrixResponseDto = AuthMatrixResponseDto.builder()
                .authMatId(authMatrixTempSaved.getId())
                .status(authMatrixTempSaved.getStatus())
                .build();

        return new ApplicationResponse("SUCCESS", authMatrixResponseDto, "auth matrix list fetched");
    }

    @Override
    public ApplicationResponse getAllAuthMatrixTempAllMapping(Pageable pageable,
                                                              String category,
                                                              Long companyId) {
        Page<AuthMatrixGroupedDto> page = authMatrixTempService.getAllAuthMatrixAllMapping(pageable, category, companyId);
        return new ApplicationResponse("SUCCESS", page, "");
    }

    @Override
    public ApplicationResponse getAllAuthMatrixAllMapping(Pageable pageable,
                                                          String category,
                                                          Long companyId) {
        Page<AuthMatrixGroupedDto> page = authMatrixService.getAllAuthMatrixAllMapping(pageable, category, companyId);
        return new ApplicationResponse("SUCCESS", page, "");
    }

    private List<AuthType> parseEventTypes(String csv) {
        if (csv == null || csv.isBlank()) return List.of();
        return Arrays.stream(csv.split(","))
                .map(String::trim)
                .map(AuthType::valueOf)
                .toList();
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Integer>> parseAuthGroup(String json) {
        if (json == null || json.isBlank()) return List.of();
        try {
            List<Map<String, Object>> raw = objectMapper.readValue(json, List.class);
            // Convert number types to Integer
            return raw.stream().map(m -> {
                Map<String, Integer> out = new LinkedHashMap<>();
                Object g = m.get("group");
                Object s = m.get("seqNo");
                out.put(String.valueOf(g), s == null ? null : ((Number) s).intValue());
                return out;
            }).toList();
        } catch (Exception e) {
            throw new IllegalStateException("Failed to parse authGroup JSON: " + json, e);
        }
    }

    private AuthLevelTemp getAuthLevel(Long levelId, Integer seqNo, AuthMatrixTemp authMatrixTemp) {
        AuthGroup authGroup = authGroupService.getAuthGroupById(levelId);

        return (AuthLevelTemp) AuthLevelTemp.builder()
                .authGroup(authGroup)
                .seqNo(seqNo)
                .authMatrixTemp(authMatrixTemp)
                .build();
    }

    private AuthType getAuthType(String type) {
        return switch (type.toLowerCase()) {
            case "new" -> AuthType.NEW;
            case "amend" -> AuthType.AMEND;
            case "payment" -> AuthType.PAYMENT;
            case "close" -> AuthType.CLOSE;
            default -> null;
        };
    }

    private AuthMatrixResponseDto convertToDto(AuthMatrix authMatrix) {
        return AuthMatrixResponseDto.builder()
                .authMatId(authMatrix.getId())
                .companyId(authMatrix.getCompany().getCompanyId())
                .companyName(authMatrix.getCompany().getAbbvName())
                .productId(authMatrix.getProduct().getProductId())
                .productName(authMatrix.getProduct().getProductName())
                .subProductId(authMatrix.getSubProduct().getSubProductId())
                .subProductName(authMatrix.getSubProduct().getSubProductName())
                .currencyType(authMatrix.getCurrencyType())
                .amount(authMatrix.getAmount())
//                .type(authMatrix.getAuthType())
//                .eventType(
//                        authMatrix.getEventTypes().stream()
//                                .map(event -> event.getEventType())
//                                .toList()
//                )
                .isSequential(authMatrix.getIsSequential())
                .isVerifier(authMatrix.getIsVerifier())
                .isReleaser(authMatrix.getIsReleaser())
                .authGroup(authMatrix.getAuthLevels().stream().map(
                        level -> Map.of(level.getAuthGroup().getId() + "-" + level.getAuthGroup().getAuthGroup(),  Objects.nonNull(level.getSeqNo()) ? level.getSeqNo():-1)).toList())
                .isAllProductFlag(authMatrix.getIsAllProductFlag())
                .accounts(authMatrix.getAccounts().stream().map(AccountDetailsDto :: convertToDto).toList())
                .createdAt(authMatrix.getCreatedAt())
                .makerName(authMatrix.getMakerName())
                .approvedAt(authMatrix.getApprovedAt())
                .checkerName(authMatrix.getCheckerName())
                .editedAt(authMatrix.getEditedAt())
                .editorName(authMatrix.getEditorName())
                .lastModifiedAt(authMatrix.getLastModifiedAt())
                .lastModifiedBy(authMatrix.getLastModifiedBy())
                .rejectedAt(authMatrix.getRejectedAt())
                .rejectedBy(authMatrix.getRejectedBy())
                .build();
    }

    private AuthMatrixResponseDto convertTempToDto(AuthMatrixTemp authMatrix) {
        return AuthMatrixResponseDto.builder()
                .authMatId(authMatrix.getId())
                .companyId(authMatrix.getCompany().getCompanyId())
                .companyName(authMatrix.getCompany().getAbbvName())
                .productId(authMatrix.getProduct().getProductId())
                .productName(authMatrix.getProduct().getProductName())
                .subProductId(authMatrix.getSubProduct().getSubProductId())
                .subProductName(authMatrix.getSubProduct().getSubProductName())
                .currencyType(authMatrix.getCurrencyType())
                .amount(authMatrix.getAmount())
//                .type(authMatrix.getAuthType())
//                .eventType(
//                        authMatrix.getEventTypes().stream()
//                                .map(event -> event.getEventType())
//                                .toList()
//                )
                .isSequential(authMatrix.getIsSequential())
                .isVerifier(authMatrix.getIsVerifier())
                .isReleaser(authMatrix.getIsReleaser())
                .authGroup(authMatrix.getAuthLevels().stream().map(
                        level -> Map.of(level.getAuthGroup().getId() + "-" + level.getAuthGroup().getAuthGroup(), Objects.nonNull(level.getSeqNo()) ? level.getSeqNo():-1)
                ).toList())
                .status(authMatrix.getStatus())
                .isAllProductFlag(authMatrix.getIsAllProductFlag())
                .accounts(authMatrix.getAccounts().stream().map(AccountDetailsDto :: convertToDto).toList())
                .createdAt(authMatrix.getCreatedAt())
                .makerName(authMatrix.getMakerName())
                .approvedAt(authMatrix.getApprovedAt())
                .checkerName(authMatrix.getCheckerName())
                .editedAt(authMatrix.getEditedAt())
                .editorName(authMatrix.getEditorName())
                .lastModifiedAt(authMatrix.getLastModifiedAt())
                .lastModifiedBy(authMatrix.getLastModifiedBy())
                .rejectedAt(authMatrix.getRejectedAt())
                .rejectedBy(authMatrix.getRejectedBy())
                .build();
    }
}
