package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.BankProfileFacade;
import com.indusind.trade.admin.utility.MappingUtil;
import com.indusind.trade.model.dtos.requestdtos.BankProfileRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.BankResponseDto;
import com.indusind.trade.model.entities.bank.BankProfile;
import com.indusind.trade.model.entities.bank.BankProfileTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.service.BankProfileService;
import com.indusind.trade.model.service.ProductMasterService;
import com.indusind.trade.model.service.SubProductMasterService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class BankProfileFacadeImpl implements BankProfileFacade {

    private final BankProfileService bankProfileService;
    private final ProductMasterService productMasterService;
    private final SubProductMasterService subProductMasterService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse saveBankProfile(BankProfileRequestDto bankProfileDto) {
        BankProfileTemp bankProfileTemp = null;
        if(Objects.nonNull(bankProfileDto.getIsUpdate()) && bankProfileDto.getIsUpdate()){
            bankProfileTemp = bankProfileService.getBankProfileTempById(bankProfileDto.getBankProfileId());
            bankProfileTemp = BankProfileRequestDto.convertToTempEntity(bankProfileDto, bankProfileTemp);
        }else{
            bankProfileTemp = BankProfileRequestDto.convertToTempEntity(bankProfileDto, new BankProfileTemp());
        }
        bankProfileTemp.setStatus(Status.PENDING.toString());
        bankProfileService.flushBankProfileTemp();
        mapProductSubProductToBankProfileTemp(bankProfileDto, bankProfileTemp);
        BankProfileTemp bankProfileSaved = bankProfileService.saveBankProfileTemp(bankProfileTemp);

        return new ApplicationResponse("SUCCESS", Map.of(bankProfileTemp.getBankProfileId(), bankProfileSaved.getName()), "Bank Temp saved successfully.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse approveBankProfile(Long bankProfileId) {
        BankProfile bankProfile = null;
        BankProfileTemp bankProfileTemp = bankProfileService.getBankProfileTempById(bankProfileId);
        bankProfileTemp.setStatus(Status.APPROVED.toString());
        bankProfileTemp = bankProfileService.saveBankProfileTemp(bankProfileTemp);

        Boolean existsFlag = bankProfileService.existsBank(bankProfileId);

        if (existsFlag) {
            bankProfile = bankProfileService.getBankProfileById(bankProfileId);
            bankProfileService.flushBankProfile();
            bankProfile = BankProfileTemp.convertToMasterEntity(bankProfileTemp, bankProfile);
        } else {
            bankProfile = BankProfileTemp.convertToMasterEntity(bankProfileTemp, new BankProfile());
        }

        BankProfile bankProfileSaved = bankProfileService.saveBankProfile(bankProfile);
        return new ApplicationResponse("SUCCESS", Map.of(bankProfileTemp.getBankProfileId(), bankProfileSaved.getName()), "Bank approved successfully.");
    }

    @Override
    public ApplicationResponse getBankTempById(Long bankProfileId) {
        BankProfileTemp bankProfileTemp = bankProfileService.getBankProfileTempById(bankProfileId);
        BankResponseDto bankResponseDto = BankResponseDto.convertTempToDto(bankProfileTemp);
        List<ProductMaster> productMasterList = bankProfileTemp.getProducts();
        List<SubProductMaster> subProductMasterList = bankProfileTemp.getSubProducts();
        Map<String, Set<String>> prodSubProdMapping = MappingUtil.getProductSubProductMapping(productMasterList, subProductMasterList);
        bankResponseDto.setProdSubProdMapping(prodSubProdMapping);
        return new ApplicationResponse("SUCCESS", bankResponseDto, "BankTemp fetched successfully");
    }

    @Override
    public ApplicationResponse getBankById(Long bankProfileId) {
        BankProfile bankProfile = bankProfileService.getBankProfileById(bankProfileId);
        BankResponseDto bankResponseDto = BankResponseDto.convertToDto(bankProfile);
        List<ProductMaster> productMasterList = bankProfile.getProducts();
        List<SubProductMaster> subProductMasterList = bankProfile.getSubProducts();
        Map<String, Set<String>> prodSubProdMapping = MappingUtil.getProductSubProductMapping(productMasterList, subProductMasterList);
        bankResponseDto.setProdSubProdMapping(prodSubProdMapping);
        return new ApplicationResponse("SUCCESS", bankResponseDto, "Bank fetched successfully");
    }

    @Override
    public ApplicationResponse getAllTempBanks(Pageable pageable) {
        Page<BankProfileTemp> bankProfileTempPage = bankProfileService.getAllTempBanks(pageable);
        Page<BankResponseDto> bankResponseDtoPage = bankProfileTempPage.map(BankResponseDto::convertTempToDto);
        return new ApplicationResponse("SUCCESS", bankResponseDtoPage, "All temp banks fetched successfully.");
    }

    @Override
    public ApplicationResponse getAllBanks(Pageable pageable) {
        Page<BankProfile> bankProfilePage = bankProfileService.getAllBanks(pageable);
        Page<BankResponseDto> bankResponseDtoPage = bankProfilePage.map(BankResponseDto::convertToDto);
        return new ApplicationResponse("SUCCESS", bankResponseDtoPage, "All banks fetched successfully.");
    }

    @Override
    public ApplicationResponse rejectBankTemp(Long bankProfileId) {
        BankProfileTemp bankProfileTempSaved = null;
        BankProfileTemp bankProfileTemp = bankProfileService.getBankProfileTempById(bankProfileId);
        if(bankProfileService.existsBank(bankProfileId)){
            BankProfile bankProfile = bankProfileService.getBankProfileById(bankProfileId);
            bankProfileTemp = BankProfile.convertToTempEntity(bankProfile, bankProfileTemp);
            bankProfileTemp.setStatus(Status.UPDATE_REJECTED.toString());
            bankProfileTempSaved = bankProfileService.saveBankProfileTemp(bankProfileTemp);
        }else{
            bankProfileTemp.setStatus(Status.REJECTED.toString());
            bankProfileTempSaved = bankProfileService.saveBankProfileTemp(bankProfileTemp);
        }
        return new ApplicationResponse("SUCCESS", Map.of(bankProfileTempSaved.getBankProfileId(), bankProfileTempSaved.getName()), "Company updates rejected successfully.");
    }

    public void mapProductSubProductToBankProfileTemp(BankProfileRequestDto bankProfileRequestDto, BankProfileTemp bankProfileTemp){
        if (Objects.nonNull(bankProfileRequestDto.getProductIdList()) && CollectionUtils.isNotEmpty(bankProfileRequestDto.getProductIdList())) {
            List<ProductMaster> productMasterList = productMasterService.getProductsByIds(bankProfileRequestDto.getProductIdList());
            bankProfileTemp.setProducts(productMasterList);
        }
        if (Objects.nonNull(bankProfileRequestDto.getSubProductList()) && CollectionUtils.isNotEmpty(bankProfileRequestDto.getSubProductList())) {
            List<SubProductMaster> subProductMasterList = subProductMasterService.getSubProductMasterList(bankProfileRequestDto.getSubProductList());
            bankProfileTemp.setSubProducts(subProductMasterList);
        }
    }




}
