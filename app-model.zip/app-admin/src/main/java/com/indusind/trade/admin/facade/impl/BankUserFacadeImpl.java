package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.client.PulseFeignClient;
import com.indusind.trade.admin.dto.AdrenalinTokenResponseDto;
import com.indusind.trade.admin.dto.PulseApiResponse;
import com.indusind.trade.admin.dto.PulseEmpRequestDto;
import com.indusind.trade.admin.enums.EmailCategory;
import com.indusind.trade.admin.facade.BankUserFacade;
import com.indusind.trade.admin.facade.EmailFacade;
import com.indusind.trade.admin.facade.SmsFacade;
import com.indusind.trade.model.dtos.requestdtos.BankUserRequestDto;
import com.indusind.trade.model.dtos.requestdtos.UserDTO;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.BankUserResponseDto;
import com.indusind.trade.model.dtos.response.dtos.PulseDetailsResponseDto;
import com.indusind.trade.model.entities.bank.*;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.service.*;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MultiValuedMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@RequiredArgsConstructor
public class BankUserFacadeImpl implements BankUserFacade {

    private final BankUserService bankUserService;
    private final PasswordEncoder passwordEncoder;
    private final BankProfileService bankProfileService;
    private final UserTypeService userTypeService;
    private final EmailFacade emailService;
    private final SmsFacade smsService;
    private final ProductMasterService productMasterService;
    private final SubProductMasterService subProductMasterService;
    private final EmailFacade emailFacade;
    private final PulseFeignClient pulseFeignClient;

    @Value("${user.default.password}")
    private String defaultUserPassword;

    @Value(("${email.content}"))
    private String emailContentTemplate;

    @Value(("${email.welcome.subject}"))
    private String welcomeEmailSubject;

    @Value(("${email.welcome.content}"))
    private String welcomeEmailContent;

    @Value(("${email.password.subject}"))
    private String passwordEmailSubject;

    @Value(("${email.password.content}"))
    private String passwordEmailContent;

    @Value(("${token-username}"))
    private String tokenUsername;

    @Value(("${token-password}"))
    private String tokenPassword;

    @Value(("${token-grant-type}"))
    private String tokenGrantType;

    @Value(("${emp-data-param}"))
    private String empDataParam;

    @Value(("${emp-api-no}"))
    private String empApino;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse saveBankUserTemp(BankUserRequestDto bankUserRequestDto) {

        BankUserTemp bankUserTemp = null;
        if(Objects.nonNull(bankUserRequestDto.getIsUpdate()) && bankUserRequestDto.getIsUpdate()){
            bankUserTemp = bankUserService.getBankUserTempById(bankUserRequestDto.getBankUserId());
            bankUserTemp = BankUserRequestDto.convertToTempEntity(bankUserRequestDto, bankUserTemp);
            clearProdSubProdMappingTemp(bankUserTemp);
        }else{
            bankUserTemp = BankUserRequestDto.convertToTempEntity(bankUserRequestDto, new BankUserTemp());
            bankUserTemp.setUserPassword(passwordEncoder.encode(defaultUserPassword));
        }

        if(Objects.nonNull(bankUserRequestDto.getDepartment()) && bankUserRequestDto.getDepartment().equalsIgnoreCase("other")){
            bankUserTemp.setDepartment(bankUserRequestDto.getOtherDept());
        }

        BankProfile bankProfile = bankProfileService.getBankProfileById(bankUserRequestDto.getBankId());
        bankUserTemp.setBankProfile(bankProfile);

        UserType userType = userTypeService.getUserTypeById(bankUserRequestDto.getUserTypeId());
        bankUserTemp.setUserType(userType);

        if(Objects.nonNull(bankUserRequestDto.getProductSubProdRespMap()) && !bankUserRequestDto.getProductSubProdRespMap().isEmpty()){
            Map<Long, List<Long>> prodSubProdMap = bankUserRequestDto.getProductSubProdRespMap();
            for(Map.Entry<Long, List<Long>> entry : prodSubProdMap.entrySet()){
                Long productId = entry.getKey();
                List<Long> subProductList = entry.getValue();

                ProductMaster productMaster = productMasterService.getProductById(productId);

                if(subProductList == null || subProductList.isEmpty()){
                    BankUserProductSubProductMappingTemp tempMapping = new BankUserProductSubProductMappingTemp();
                    tempMapping.setBankUserTemp(bankUserTemp);
                    tempMapping.setProductMaster(productMaster);
                    tempMapping.setSubProductMaster(null);
                    bankUserTemp.getBankUserMappingTemp().add(tempMapping);
                } else{
                    for(Long subProdId : subProductList){
                        BankUserProductSubProductMappingTemp tempMapping = new BankUserProductSubProductMappingTemp();
                        SubProductMaster subProductMaster = subProductMasterService.getSubProductById(subProdId);
                        tempMapping.setBankUserTemp(bankUserTemp);
                        tempMapping.setProductMaster(productMaster);
                        tempMapping.setSubProductMaster(subProductMaster);
                        bankUserTemp.getBankUserMappingTemp().add(tempMapping);
                    }
                }
            }
        }

        bankUserTemp.setStatus(Status.PENDING.toString());

        BankUserTemp savedBankUserTemp = bankUserService.saveBankUserTemp(bankUserTemp);

        emailFacade.sendEmail(savedBankUserTemp.getEmail(), welcomeEmailSubject, welcomeEmailContent, EmailCategory.WELCOME);

        return new ApplicationResponse("SUCCESS", Map.of(savedBankUserTemp.getBankUserId(), savedBankUserTemp.getUserType().getUserTypeName()), "Bank User Saved Successfully");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse approveBankUser(Long id) {
        BankUser bankUser = null;
        BankUserTemp bankUserTemp = bankUserService.getBankUserTempById(id);
        bankUserTemp.setStatus(Status.APPROVED.toString());

        bankUserTemp = bankUserService.saveBankUserTemp(bankUserTemp);

        Boolean existsFlag = bankUserService.existsBankUser(id);

        if(existsFlag){
            bankUser = bankUserService.getBankUSerById(id);
            clearProdSubProdMapping(bankUser);
            bankUserService.flushBankUser();
            bankUser = BankUserTemp.convertToMaster(bankUserTemp, bankUser);
        }else{
            bankUser = BankUserTemp.convertToMaster(bankUserTemp, new BankUser());

//            String emailContent = emailContentTemplate.replace("$UserName", bankUser.getFirstName())
//                    .replace("$role", bankUser.getUserType().getUserTypeName())
//                    .replace("$Email", bankUser.getEmail())
//                    .replace("$Defaultpassword", defaultUserPassword); //sending mail with plain text password
//
//            System.out.println("emailContent "+emailContent);

//            send email
//            Map<String, Object> emailRes = emailService.sendEmail(bankUser.getEmail(), "Bank User Approved for Trade", emailContent);
//            System.out.println("emailRes "+emailRes);
//            System.out.println("SUCCESS: Email sent to user " + bankUser.getLoginId() + " at " + bankUser.getEmail());

//            bankUserTemp.setUserPassword(passwordEncoder.encode(defaultUserPassword));
//            bankUser.setUserPassword(passwordEncoder.encode(defaultUserPassword));
        }

        addProdSubProdMappingFromTemp(bankUser, bankUserTemp);
        bankUser = bankUserService.saveBankUser(bankUser);

        emailFacade.sendEmail(bankUser.getEmail(), passwordEmailSubject, passwordEmailContent, EmailCategory.PASSWORD_GENERATOR);

        return new ApplicationResponse("SUCCESS", Map.of(bankUser.getBankUserId(), bankUser.getUserType().getUserTypeName()), "Bank User approved successfully");

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getBankUserTempById(Long bankUserId) {
        BankUserTemp bankUserTemp = bankUserService.getBankUserTempById(bankUserId);
        BankUserResponseDto bankUserResponseDto = BankUserResponseDto.convertTempToDto(bankUserTemp);
        return new ApplicationResponse("SUCCESS", bankUserResponseDto, "BankUserTemp fetched successfully.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getBankUserById(Long bankUserId) {
        BankUser bankUser = bankUserService.getBankUSerById(bankUserId);
        BankUserResponseDto bankUserResponseDto = BankUserResponseDto.convertToDto(bankUser);
        return new ApplicationResponse("SUCCESS", bankUserResponseDto, "BankUser fetched successfully.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getAllTempBankUsers(Pageable pageable) {
        Page<BankUserTemp> bankUserTempPage = bankUserService.getAllTempBankUsers(pageable);
        Page<BankUserResponseDto> bankUserResponseDtoPage = bankUserTempPage.map(BankUserResponseDto :: convertTempToDto);
        return new ApplicationResponse("SUCCESS", bankUserResponseDtoPage, "All Temp Bank Users fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getAllBankUsers(Pageable pageable) {
        Page<BankUser> bankUserPage = bankUserService.getAllBankUsers(pageable);
        Page<BankUserResponseDto> bankUserResponseDtoPage = bankUserPage.map(BankUserResponseDto :: convertToDto);
        return new ApplicationResponse("SUCCESS", bankUserResponseDtoPage, "All Bank Users fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse rejectBankUser(Long bankUserId) {
        BankUserTemp bankUserTempSaved = null;
        BankUserTemp bankUserTemp = bankUserService.getBankUserTempById(bankUserId);

        if(bankUserService.existsBankUser(bankUserId)){
            clearProdSubProdMappingTemp(bankUserTemp);
            bankUserService.flushBankUserTemp();
            BankUser bankUser = bankUserService.getBankUSerById(bankUserId);
            bankUserTemp = BankUser.convertToTempEntity(bankUser, bankUserTemp);
            addProdSubProdMapping(bankUserTemp, bankUser);
            bankUserTemp.setStatus(Status.UPDATE_REJECTED.toString());
            bankUserTempSaved = bankUserService.saveBankUserTemp(bankUserTemp);

            clearProdSubProdMapping(bankUser);
            bankUserService.flushBankUser();
            addProdSubProdMappingFromTemp(bankUser, bankUserTempSaved);
            bankUserService.saveBankUser(bankUser);

        }else{
            bankUserTemp.setStatus(Status.REJECTED.toString());
            bankUserTempSaved = bankUserService.saveBankUserTemp(bankUserTemp);
        }

        return new ApplicationResponse("SUCCESS", Map.of(bankUserTempSaved.getBankUserId(), bankUserTempSaved.getUserType().getUserTypeName()), "Bank User updates rejected successfully.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getTempBankUsersByBankId(Long bankId, Pageable pageable) {
        Page<BankUserTemp> page = bankUserService.getTempBankUsersByBankId(bankId, pageable);
        Page<BankUserResponseDto> responseDtoPage = page.map(BankUserResponseDto :: convertTempToDto);
        return new ApplicationResponse("SUCCESS", responseDtoPage, "Temp Bank Users fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getBankUsersByBankId(Long bankId, Pageable pageable) {
        Page<BankUser> page = bankUserService.getBankUsersByBankId(bankId, pageable);
        Page<BankUserResponseDto> responseDtoPage = page.map(BankUserResponseDto :: convertToDto);
        return new ApplicationResponse("SUCCESS", responseDtoPage, "Bank Users fetched");
    }

    public void addProdSubProdMappingFromTemp(BankUser bankUser, BankUserTemp bankUserTemp){
        if(Objects.nonNull(bankUserTemp.getBankUserMappingTemp()) && CollectionUtils.isNotEmpty(bankUserTemp.getBankUserMappingTemp())){
            for(BankUserProductSubProductMappingTemp bankUserMap : bankUserTemp.getBankUserMappingTemp()){
                BankUserProductSubProductMapping bankUserProductSubProductMapping = BankUserProductSubProductMappingTemp.convertToMasterEntity(bankUserMap);
                bankUser.addBankUserProdSubProd(bankUserProductSubProductMapping);
            }
        }
    }

    public void addProdSubProdMapping(BankUserTemp bankUserTemp, BankUser bankUser){
        if(Objects.nonNull(bankUser.getMappingUser()) && CollectionUtils.isNotEmpty(bankUser.getMappingUser())){
            for(BankUserProductSubProductMapping bankUserMap : bankUser.getMappingUser()){
                BankUserProductSubProductMappingTemp bankUserProductSubProductMappingTemp = BankUserProductSubProductMapping.convertToTempEntity(bankUserMap);
                bankUserTemp.addBankUserProdSubProd(bankUserProductSubProductMappingTemp);
            }
        }
    }

    public void clearProdSubProdMapping(BankUser bankUser){
        bankUser.getMappingUser().clear();
    }

    public void clearProdSubProdMappingTemp(BankUserTemp bankUserTemp){
        bankUserTemp.getBankUserMappingTemp().clear();
    }

    @Override
    public ApplicationResponse getPulseDetailsByPulseId(Long pulseId) {
        BankUserResponseDto responseDto;
        try{
            PulseDetailsResponseDto pulseDetailsResponseDto;
            //need to update client id and secret
            //response = pulseFeignClient.getPulseDeatilsByPulseId("IBL_CLIENT_ID", "IBL_CLIENT_SECRET",pulseId);
            AdrenalinTokenResponseDto tokenDto;

            MultiValueMap<String, String> requestMap = new LinkedMultiValueMap<>();

            requestMap.add("username", tokenUsername);
            requestMap.add("password", tokenPassword);
            requestMap.add("grant_type", tokenGrantType);

            tokenDto = pulseFeignClient.getAdrenalinToken(requestMap);

            String accessToken = "Bearer "+ tokenDto.getAccessToken();

            PulseEmpRequestDto pulseEmpRequestDto = new PulseEmpRequestDto();

            pulseEmpRequestDto.setParam(String.valueOf(pulseId));
            pulseEmpRequestDto.setApiNo(empApino);

            List<PulseEmpRequestDto> requestDtoList = List.of(pulseEmpRequestDto);

            List<PulseApiResponse> apiResponse = pulseFeignClient.getEmployeeData(accessToken, requestDtoList);

            if(apiResponse==null || apiResponse.isEmpty() || apiResponse.get(0).getData().getPulseDetailsResponseDto() == null || apiResponse.get(0).getData().getPulseDetailsResponseDto().isEmpty()){
                return new ApplicationResponse("SUCCESS", null, "Employee Details not found");
            }

            PulseApiResponse pulseApiResponse = apiResponse.get(0);

            pulseDetailsResponseDto = pulseApiResponse.getData().getPulseDetailsResponseDto().get(0);

            responseDto = mapPulseDetailsToUserDto(pulseDetailsResponseDto);

        } catch (Exception e){
            throw  new GTPAppException("Error while calling pulse api", e);
        }

        return new ApplicationResponse("SUCCESS", responseDto, "Pulse emp fetched.");
    }

    private BankUserResponseDto mapPulseDetailsToUserDto(PulseDetailsResponseDto resp) {
        if (Objects.isNull(resp)){
            throw new GTPAppException("User not found with given ECN", null);
        }
        String name = resp.getName();
        System.out.println("full name "+name);
        String firstName;
        String lastName = null;

        if (name != null && name.contains("-")) {
            String[] parts = name.split("-", 2);
            firstName = parts[0];
            lastName = parts.length > 1 ? parts[1] : null;
        } else {
            firstName = name;
        }

        return BankUserResponseDto.builder()
                .loginId("IBL" + resp.getEmployeeNumber())
                .firstName(firstName)
                .lastName(lastName)
                .department(resp.getDepartment())
                .contactNo(resp.getMobileNumber())
                .status(resp.getStatus())
                .email(resp.getMailId())
                .build();
    }
}
