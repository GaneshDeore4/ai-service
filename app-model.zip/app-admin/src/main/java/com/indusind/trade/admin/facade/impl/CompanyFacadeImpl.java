package com.indusind.trade.admin.facade.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.app.jose.constant.InputType;
import com.indusind.app.jose.operations.JoseHelper;
import com.indusind.app.jose.operations.JoseUtility;
import com.indusind.trade.admin.client.CustomerProfileClient;
import com.indusind.trade.admin.facade.CompanyFacade;
import com.indusind.trade.admin.utility.MappingUtil;
import com.indusind.trade.model.dtos.requestdtos.*;
import com.indusind.trade.model.dtos.response.dtos.*;
import com.indusind.trade.model.entities.company.*;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.service.*;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
@RequiredArgsConstructor
public class CompanyFacadeImpl implements CompanyFacade {

    private final CompanyService companyService;

    private final ProductMasterService productMasterService;

    private final SubProductMasterService subProductMasterService;

    private final UserTypeService userTypeService;

    private final UserService userService;

    private final PasswordEncoder passwordEncoder;

    private final CategoryMasterService categoryMasterService;

    private final ObjectMapper objectMapper;

    private final CustomerProfileClient customerProfileClient;

    private final JoseHelper joseHelper;

    @Value("${admin.user.default.password}")
    private String adminDefaultPassword;

    @Value("${admin.user.default.login.id}")
    private String adminDefaultLoginId;

    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    @Value("${ibl.env:UAT}")
    private String iblEnv;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse saveCompanyTemp(CompanyRequestDto companyDto) {
        //CifIdResponse response = getDataByCifId(companyDto.getCifId());
//        if(Objects.nonNull(response)){
//              //set AddressDto
        //set SwiftAddressdto
        //set IEdeatils
//        }
        CompanyTemp companyTemp = null;
        if (Objects.nonNull(companyDto.getIsUpdate()) && companyDto.getIsUpdate()) {
            companyTemp = companyService.getCompanyTempById(companyDto.getCompanyId());
            companyTemp = CompanyRequestDto.convertToTempEntity(companyDto, companyTemp);
            clearCompanyTempAccountCustRefLegalIdMapping(companyTemp);

        } else {
            companyTemp = CompanyRequestDto.convertToTempEntity(companyDto, new CompanyTemp());

        }
        companyTemp.setStatus(Status.PENDING.toString());
        //companyTemp.setCategoryMaster(categoryMasterService.getCategoryById(companyDto.getCategoryId()));
        companyService.flushCompanyTemp();
        createAccountCustRefLegalIdMappingDtoToCompanyTemp(companyDto, companyTemp);
        CompanyTemp companyTempSaved = companyService.saveComapnyTemp(companyTemp);

        List<CompanyProductLimitMappingTemp> mapping = companyDto.getProductLimit().stream()
                .map(p -> {
                    CompanyProductLimitMappingTemp temp = new CompanyProductLimitMappingTemp();
                    CompanyProductId id = new CompanyProductId(companyTempSaved.getCompanyId(), p.getProductId());
                    temp.setId(id);
                    temp.setLimitAmount(p.getLimitAmt());
                    temp.setMidOfficeFlag(p.getMidOfficeFlag());
                    return temp;
                })
                .toList();

        companyTempSaved.getCompanyProductLimitMapping().clear();
        companyTempSaved.getCompanyProductLimitMapping().addAll(mapping);
        companyService.saveComapnyTemp(companyTempSaved);

        return new ApplicationResponse("SUCCESS", Map.of(companyTempSaved.getCompanyId(), companyTempSaved.getName()), "Company saved successfully.");

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse approveCompanyTemp(Long companyId) {
        Company company = null;
        CompanyTemp companyTemp = companyService.getCompanyTempById(companyId);
        companyTemp.setStatus(Status.APPROVED.toString());
        companyTemp = companyService.saveComapnyTemp(companyTemp);

        Boolean existsFlag = companyService.existsCompany(companyId);

        if (existsFlag) {
            company = companyService.getCompanyById(companyId);
            clearCompanyAccountCustRefLegalIdMapping(company);
            companyService.flushCompany();
            company = CompanyTemp.convertToMasterEntity(companyTemp, company);

        } else {
            company = CompanyTemp.convertToMasterEntity(companyTemp, new Company());
        }

        addCompanyLatestAccountCustRefLegalIdMapping(company, companyTemp);

        Company savedCompany = companyService.saveCompany(company);

        savedCompany.getCompanyProductLimitMapping().clear();
        savedCompany.getCompanyProductLimitMapping().addAll(
                companyTemp.getCompanyProductLimitMapping().stream()
                .map(p -> {
                    CompanyProductLimitMapping entity = new CompanyProductLimitMapping();
                    entity.setId(new CompanyProductId(savedCompany.getCompanyId(), p.getId().getProductId()));
                    entity.setLimitAmount(p.getLimitAmount());
                    entity.setMidOfficeFlag(p.getMidOfficeFlag());
                    return entity;
                })
                .toList()
        );

        companyService.saveCompany(savedCompany);
//        if (!existsFlag && StringUtils.equalsIgnoreCase("Y", companyTemp.getInitialAdmin())) {
//            UserTemp userTemp = new UserTemp();
//            userTemp.setFirstName("Admin");
//            userTemp.setLastName("Admin");
//            userTemp.setLoginId(company.getAbbvName() + "-" + adminDefaultLoginId);
//            userTemp.setCompany(savedCompany);
//            userTemp.setStatus(Status.APPROVED.toString());
//            userTemp.setUserStatus("Active");
//            userTemp.setUserType(userTypeService.getUserTypeByType("Admin"));
//            userTemp.setUserPassword(passwordEncoder.encode(adminDefaultPassword));
//            UserTemp useTemp = userService.saveUserTemp(userTemp);
//
//            User user = UserTemp.convertToMaster(useTemp, new User());
//            User userSaved = userService.saveUser(user);
//
//        }
        return new ApplicationResponse("SUCCESS", this.createCompanyResponseFromCompany(savedCompany), "Company approved successfully.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse rejectCompanyTemp(Long companyId) {
        CompanyTemp companyTempSaved = null;
        CompanyTemp companyTemp = companyService.getCompanyTempById(companyId);
        if (companyService.existsCompany(companyId)) {
            clearCompanyTempAccountCustRefLegalIdMapping(companyTemp);
            companyService.flushCompanyTemp();
            Company company = companyService.getCompanyById(companyId);
            companyTemp = Company.convertToTempEntity(company, companyTemp);
            addCompanyTempLatestAccountCustRefLegalIdMapping(companyTemp, company);
            companyTemp.setStatus(Status.UPDATE_REJECTED.toString());
            companyTempSaved = companyService.saveComapnyTemp(companyTemp);

            companyTempSaved.getCompanyProductLimitMapping().clear();
            companyTempSaved.getCompanyProductLimitMapping().addAll(company.getCompanyProductLimitMapping().stream()
                    .map(p -> CompanyProductLimitMappingTemp.convertToTemp(p))
                    .toList()
            );

            companyService.saveComapnyTemp(companyTempSaved);

            //to make id of both temp and master consistent
            clearCompanyAccountCustRefLegalIdMapping(company);
            companyService.flushCompany();
            addCompanyLatestAccountCustRefLegalIdMapping(company, companyTempSaved);
            companyService.saveCompany(company);

        } else {
//            companyTemp.getProducts().clear();
//            companyTemp.getSubProducts().clear();
            companyTemp.setStatus(Status.REJECTED.toString());
            companyTempSaved = companyService.saveComapnyTemp(companyTemp);

        }

        return new ApplicationResponse("SUCCESS", this.createCompanyResponseFromCompanyTemp(companyTempSaved), "Company updates rejected successfully.");
    }

    @Override
    public ApplicationResponse getAllTempCompanies(Pageable pageable) {
        Page<CompanyTemp> companyTempPage = companyService.getAllTempCompanies(pageable);
//        Map<String, String> companyIdNameMap = companyTempPage.stream().collect(Collectors.toMap(c -> c.getCompanyId() + "|" + c.getName(), c -> c.getAbbvName()));
//        companyIdNameMap.putIfAbsent("totalPages", String.valueOf(companyTempPage.getTotalPages()));
//        companyIdNameMap.putIfAbsent("totalElements", String.valueOf(companyTempPage.getTotalElements()));
//        companyIdNameMap.putIfAbsent("number", String.valueOf(companyTempPage.getNumberOfElements()));

        Page<CompanyIdNameRespDto> companyIdNameRespDto = companyTempPage.map(CompanyIdNameRespDto::convertToTempDto);
        return new ApplicationResponse("SUCCESS", companyIdNameRespDto, "All Company name map fetched successfully.");
    }

    @Override
    public ApplicationResponse getAllCompanies(Pageable pageable) {
        Page<Company> companyPage = companyService.getAllCompanies(pageable);
//        Map<String, String> companyIdNameMap = companyPage.stream().collect(Collectors.toMap(c -> c.getCompanyId() + "|" + c.getName(), c -> c.getAbbvName()));
//        companyIdNameMap.putIfAbsent("totalPages", String.valueOf(companyPage.getTotalPages()));
//        companyIdNameMap.putIfAbsent("totalElements", String.valueOf(companyPage.getTotalElements()));
//        companyIdNameMap.putIfAbsent("number", String.valueOf(companyPage.getNumberOfElements()));
        Page<CompanyIdNameRespDto> companyIdNameRespDto = companyPage.map(CompanyIdNameRespDto::convertToDto);
        return new ApplicationResponse("SUCCESS", companyIdNameRespDto, "All Company name map fetched successfully.");
    }

    @Override
    public ApplicationResponse getCompanyTempById(Long companyId) {
        CompanyTemp companyTemp = companyService.getCompanyTempById(companyId);
        CompanyResponseDto companyTempResponseDto = this.createCompanyResponseFromCompanyTemp(companyTemp);
        return new ApplicationResponse("SUCCESS", companyTempResponseDto, "CompanyTemp fetched successfully.");
    }

    private CompanyResponseDto createCompanyResponseFromCompanyTemp(CompanyTemp companyTemp) {
        CompanyResponseDto companyTempResponseDto = CompanyResponseDto.convertToTempDto(companyTemp);
        List<ProductMaster> prodList = companyTemp.getProducts();
        List<SubProductMaster> subProductMasterList = companyTemp.getSubProducts();
        Map<String, Set<String>> prodSubProdMapping = MappingUtil.getProductSubProductMapping(prodList, subProductMasterList);

        companyTempResponseDto.setProdSubProdMapping(prodSubProdMapping);
        companyTempResponseDto.setAccountDtoList(companyTemp.getAccountTempList().stream().map(AccountDto::convertToDtoFromTemp).collect(Collectors.toList()));
        companyTempResponseDto.setCustomerReferenceDtoList(companyTemp.getCustomerReferenceTempList().stream().map(CustomerReferenceDto::convertToDtoFromTemp).collect(Collectors.toList()));
        companyTempResponseDto.setLegalIdDetailsDtoList(companyTemp.getLegalIdDetailsTempList().stream().map(LegalIdDetailsDto::convertToDtoFromTemp).collect(Collectors.toList()));
        return companyTempResponseDto;
    }

    @Override
    public ApplicationResponse getCompanyById(Long companyId) {
        Company company = companyService.getCompanyById(companyId);
        CompanyResponseDto companyTempResponseDto = this.createCompanyResponseFromCompany(company);
        return new ApplicationResponse("SUCCESS", companyTempResponseDto, "Company fetched successfully.");

    }

    private CompanyResponseDto createCompanyResponseFromCompany(Company company) {
        CompanyResponseDto companyTempResponseDto = CompanyResponseDto.convertToDto(company);
        List<ProductMaster> prodList = company.getProducts();
        Map<String, Set<String>> prodSubProdMapping = new HashMap<>();
        List<SubProductMaster> subProductMasterList = company.getSubProducts();
        prodSubProdMapping = MappingUtil.getProductSubProductMapping(prodList, subProductMasterList);
        companyTempResponseDto.setProdSubProdMapping(prodSubProdMapping);
        companyTempResponseDto.setAccountDtoList(company.getAccountList().stream().map(AccountDto::convertToDto).collect(Collectors.toList()));
        companyTempResponseDto.setCustomerReferenceDtoList(company.getCustomerReferenceList().stream().map(CustomerReferenceDto::convertToDto).collect(Collectors.toList()));
        companyTempResponseDto.setLegalIdDetailsDtoList(company.getLegalIdDetailsList().stream().map(LegalIdDetailsDto::convertToDto).collect(Collectors.toList()));
        return companyTempResponseDto;
    }

    private void clearCompanyTempAccountCustRefLegalIdMapping(CompanyTemp companyTemp) {
        companyTemp.getAccountTempList().clear();
        companyTemp.getCustomerReferenceTempList().clear();
        companyTemp.getLegalIdDetailsTempList().clear();
        companyTemp.getCompanyProductLimitMapping().clear();
    }

    private void addCompanyTempLatestAccountCustRefLegalIdMapping(CompanyTemp companyTemp, Company company) {
        if (Objects.nonNull(company.getAccountList()) && CollectionUtils.isNotEmpty(company.getAccountList())) {
            for (Account account : company.getAccountList()) {
                AccountTemp accountTemp = Account.convertToTempEntity(account);
                companyTemp.addAccountTemp(accountTemp);
            }
        }

        if (Objects.nonNull(company.getCustomerReferenceList()) && CollectionUtils.isNotEmpty(company.getCustomerReferenceList())) {
            for (CustomerReference customerReference : company.getCustomerReferenceList()) {
                CustomerReferenceTemp customerReferenceTemp = CustomerReference.convertToTempEntity(customerReference);
                companyTemp.addCustomerReferenceTemp(customerReferenceTemp);
            }
        }

        if (Objects.nonNull(company.getLegalIdDetailsList()) && CollectionUtils.isNotEmpty(company.getLegalIdDetailsList())) {
            for (LegalIdDetails legalIdDetails : company.getLegalIdDetailsList()) {
                LegalIdDetailsTemp legalIdDetailsTemp = LegalIdDetails.convertToTempEntity(legalIdDetails);
                companyTemp.addLegalIdTemp(legalIdDetailsTemp);
            }
        }
    }

    private void clearCompanyAccountCustRefLegalIdMapping(Company company) {
        company.getAccountList().clear();
        company.getCustomerReferenceList().clear();
        company.getLegalIdDetailsList().clear();
    }

    private void addCompanyLatestAccountCustRefLegalIdMapping(Company company, CompanyTemp companyTemp) {
        if (Objects.nonNull(companyTemp.getAccountTempList()) && CollectionUtils.isNotEmpty(companyTemp.getAccountTempList())) {
            for (AccountTemp accountTemp : companyTemp.getAccountTempList()) {
                Account account = AccountTemp.convertToMasterEntity(accountTemp);
                company.addAccount(account);
            }
        }

        if (Objects.nonNull(companyTemp.getCustomerReferenceTempList()) && CollectionUtils.isNotEmpty(companyTemp.getCustomerReferenceTempList())) {
            for (CustomerReferenceTemp customerReferenceTemp : companyTemp.getCustomerReferenceTempList()) {
                CustomerReference customerReference = CustomerReferenceTemp.convertToMasterEntity(customerReferenceTemp);
                company.addCustomerReference(customerReference);
            }
        }

        if (Objects.nonNull(companyTemp.getLegalIdDetailsTempList()) && CollectionUtils.isNotEmpty(companyTemp.getLegalIdDetailsTempList())) {
            for (LegalIdDetailsTemp legalIdDetailsTemp : companyTemp.getLegalIdDetailsTempList()) {
                LegalIdDetails legalIdDetails = LegalIdDetailsTemp.convertToMasterEntity(legalIdDetailsTemp);
                company.addLegalId(legalIdDetails);
            }
        }
    }

    private void createAccountCustRefLegalIdMappingDtoToCompanyTemp(CompanyRequestDto companyDto, CompanyTemp companyTemp) {
//        if (Objects.nonNull(companyDto.getProductIdList()) && CollectionUtils.isNotEmpty(companyDto.getProductIdList())) {
//            List<ProductMaster> productMasterList = productMasterService.getProductsByIds(companyDto.getProductIdList());
//            companyTemp.setProducts(productMasterList);
//        }
        if (Objects.nonNull(companyDto.getProductLimit()) && CollectionUtils.isNotEmpty(companyDto.getProductLimit())) {
            List<Long> productIds = companyDto.getProductLimit().stream()
                    .map(ProductLimitDto::getProductId)
                    .toList();
            List<ProductMaster> productMasterList = productMasterService.getProductsByIds(productIds);
            companyTemp.setProducts(productMasterList);
        }
        if (Objects.nonNull(companyDto.getSubProductList()) && CollectionUtils.isNotEmpty(companyDto.getSubProductList())) {
            List<SubProductMaster> subProductMasterList = subProductMasterService.getSubProductMasterList(companyDto.getSubProductList());
            companyTemp.setSubProducts(subProductMasterList);
        }

        if (Objects.nonNull(companyDto.getAccountDtoList()) && CollectionUtils.isNotEmpty(companyDto.getAccountDtoList())) {
            for (AccountDto accountDto : companyDto.getAccountDtoList()) {
                //accountDto.setAccountId(null);
                AccountTemp accountTemp = AccountDto.convertToTempEntity(accountDto);
                accountTemp.setStatus(Status.PENDING.toString());
                companyTemp.addAccountTemp(accountTemp);
            }
        }

        if (Objects.nonNull(companyDto.getCustomerReferenceDtoList()) && CollectionUtils.isNotEmpty(companyDto.getCustomerReferenceDtoList())) {
            for (CustomerReferenceDto customerReferenceDto : companyDto.getCustomerReferenceDtoList()) {
                //customerReferenceDto.setCustomerReferenceId(null);
                CustomerReferenceTemp customerReferenceTemp = customerReferenceDto.convertToTempEntity(customerReferenceDto);
                customerReferenceTemp.setStatus(Status.PENDING.toString());
                companyTemp.addCustomerReferenceTemp(customerReferenceTemp);
            }
        }

        if (Objects.nonNull(companyDto.getLegalIdDetailsDtoList()) && CollectionUtils.isNotEmpty(companyDto.getLegalIdDetailsDtoList())) {
            for (LegalIdDetailsDto legalIdDetailsDto : companyDto.getLegalIdDetailsDtoList()) {
                //legalIdDetailsDto.setId(null);
                LegalIdDetailsTemp legalIdDetailsTemp = LegalIdDetailsDto.convertToTempEntity(legalIdDetailsDto);
                legalIdDetailsTemp.setStatus(Status.PENDING.toString());
                companyTemp.addLegalIdTemp(legalIdDetailsTemp);
            }
        }
    }

    @Override
    public ApplicationResponse getProdSubProdMapByCompanyTemp(Long companyTempTd) {
        CompanyTemp companyTemp = companyService.getCompanyTempById(companyTempTd);
        List<ProductMaster> prodList = companyTemp.getProducts();
        List<SubProductMaster> subProductMasterList = companyTemp.getSubProducts();
        Map<String, Set<String>> prodSubProdMapping = MappingUtil.getProductSubProductMapping(prodList, subProductMasterList);
        return new ApplicationResponse("SUCCESS", prodSubProdMapping, "product - subproduct mapping fetched successfully.");
    }

    @Override
    public ApplicationResponse getProdSubProdMapByCompany(Long companyId) {
        Company company = companyService.getCompanyById(companyId);
        List<ProductMaster> prodList = company.getProducts();
        List<SubProductMaster> subProductMasterList = company.getSubProducts();
        Map<String, Set<String>> prodSubProdMapping = MappingUtil.getProductSubProductMapping(prodList, subProductMasterList);
        return new ApplicationResponse("SUCCESS", prodSubProdMapping, "product - subproduct mapping fetched successfully.");
    }

    @Override
    public ApplicationResponse fetchCustomerProfileByCifId(Long cifId) {
        JoseUtility ju = joseHelper.getJoseUtility();

        try {
            CustomerProfileRequestDto request = new CustomerProfileRequestDto();
            request.setCifid(String.valueOf(cifId));

            String requestJson = objectMapper.writeValueAsString(request);
            log.info("Plain customer profile request: {}", requestJson);

            String encryptedEnvelope = ju.createIblGatewayRequestString(null, requestJson, InputType.STRING);
            log.debug("Encrypted customer profile envelope: {}", encryptedEnvelope);

            com.indusind.app.jose.domain.response.IBLGatewayResponse encryptedResponse =
                    customerProfileClient.fetchCustomerProfile(clientId, clientSecret, encryptedEnvelope);

            if (encryptedResponse == null || encryptedResponse.getData() == null) {
                throw new RuntimeException("Empty encrypted response from bank");
            }

            CompanyProfileResponseDto response = ju.getPayloadFromResponseObject(
                    null, encryptedResponse.getData(), CompanyProfileResponseDto.class, InputType.STRING);
            return new ApplicationResponse("SUCCESS", response, "Customer profile fetched");

        } catch (Exception ex) {
            log.error("Error processing customer profile API", ex);
            throw new RuntimeException("Error processing customer profile API", ex);
        }
    }

//    @Override
//    public ApplicationResponse getAllTempCompaniesByCategory(Pageable pageable, Long categoryId) {
//        Page<CompanyTemp> companyTempPage = companyService.getAllTempCompaniesByCategory(pageable, categoryId);
//        Page<CompanyIdNameRespDto> companyIdNameRespDto = companyTempPage.map(CompanyIdNameRespDto::convertToTempDto);
//        return new ApplicationResponse("SUCCESS", companyIdNameRespDto, "All Company name map based on category fetched successfully.");
//    }
//
//    @Override
//    public ApplicationResponse getAllCompaniesByCategory(Pageable pageable, Long categoryId) {
//        Page<Company> companyPage = companyService.getAllCompaniesByCategory(pageable, categoryId);
//        Page<CompanyIdNameRespDto> companyIdNameRespDto = companyPage.map(CompanyIdNameRespDto::convertToDto);
//        return new ApplicationResponse("SUCCESS", companyIdNameRespDto, "All Company name map based on category fetched successfully.");
//    }
}

