package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.entities.EmailAudit;
import com.indusind.trade.admin.enums.EmailCategory;
import com.indusind.trade.admin.facade.EmailFacade;
import com.indusind.trade.admin.repository.EmailAuditDao;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class EmailFacadeImpl implements EmailFacade {

    private final WebClient webClient;

    @Value("${email.url}")
    private String emailUrl;

    @Value("${email.api.user.id}")
    private String emailApiUser;

    @Value("${email.api.pass}")
    private String emailApiPass;

    @Value("${email.api.from}")
    private String emailFrom;

    @Value("${ibl.client.id}")
    private String iblClientId;

    @Value("${ibl.client.secret}")
    private String iblClientSecret;

    private final EmailAuditDao emailAuditDao;

    private static final Logger logger = LoggerFactory.getLogger(EmailFacadeImpl.class);

    @Override
    public Map<String, Object> sendEmail(String toAddress, String subject, String emailContent, EmailCategory category) {

        Map<String, Object> responseMap = new HashMap<>();

        try {

            MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();

            formData.add("method", "EMS_POST_CAMPAIGN");
            formData.add("userid", emailApiUser);
            formData.add("password", emailApiPass);
            formData.add("v", "1.1");
            formData.add("name", "No Reply");
            formData.add("fromEmailId", URLEncoder.encode(emailFrom, StandardCharsets.UTF_8));
            formData.add("recipients", URLEncoder.encode(toAddress, StandardCharsets.UTF_8));
            formData.add("content_type", "text/html");
            formData.add("content", URLEncoder.encode(emailContent, StandardCharsets.UTF_8));
            formData.add("subject", URLEncoder.encode(subject, StandardCharsets.UTF_8));

//            String response = webClient.post()
//                    .uri(emailUrl)
//                    .header("IBL-Client-Secret", iblClientSecret)
//                    .header("IBL-Client-Id", iblClientId)
//                    .contentType(MediaType.MULTIPART_FORM_DATA)
//                    .body(BodyInserters.fromMultipartData(formData))
//                    .retrieve()
//                    .onStatus(HttpStatusCode::is4xxClientError, clientResponse ->
//                            clientResponse.bodyToMono(String.class)
//                                    .flatMap(error -> {
//                                        logger.error("Client error: {}", error);
//                                        return Mono.error(new RuntimeException(error));
//                                    })
//                    )
//                    .onStatus(HttpStatusCode::is5xxServerError, clientResponse ->
//                            clientResponse.bodyToMono(String.class)
//                                    .flatMap(error -> {
//                                        logger.error("Server error: {}", error);
//                                        return Mono.error(new RuntimeException(error));
//                                    })
//                    )
//                    .bodyToMono(String.class)
//                    .retryWhen(
//                            Retry.backoff(3, Duration.ofSeconds(2))
//                                    .doBeforeRetry(retrySignal ->
//                                            logger.warn("Retrying email API... Attempt {}",
//                                                    retrySignal.totalRetries() + 1))
//                    )
//                    .timeout(Duration.ofSeconds(30))
//                    .block();

            String response = "success | 5686901531967291515 | Campaign posted";

            logger.info("Email API response: {}", response);
            responseMap.put("status", "SUCCESS");
            responseMap.put("response", response);
            if("success".equals(response.split("\\|")[0].trim())) {
                //log in audit table
                EmailAudit emailAudit = EmailAudit.builder()
                        .emailCategory(category)
                        .emailContent(emailContent)
                        .subject(subject)
                        .recipientEmail(toAddress)
                        .status("success")
                        .build();
                emailAuditDao.save(emailAudit);
            } else {
                EmailAudit emailAudit = EmailAudit.builder()
                        .emailCategory(category)
                        .emailContent(emailContent)
                        .subject(subject)
                        .recipientEmail(toAddress)
                        .status("failure")
                        .build();
                emailAuditDao.save(emailAudit);
            }
        } catch (Exception e) {
            logger.error("Email sending failed", e);
            responseMap.put("status", "FAILED");
            responseMap.put("error", e.getMessage());
        }
        return responseMap;
    }
}