package com.indusind.trade.admin.repository;

import com.indusind.trade.admin.entities.EmailAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmailAuditDao extends JpaRepository<EmailAudit, Long> {
}
