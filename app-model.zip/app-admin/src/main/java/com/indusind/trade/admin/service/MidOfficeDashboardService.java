package com.indusind.trade.admin.service;

import com.indusind.trade.admin.client.FDClient;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
public class MidOfficeDashboardService {
    private final FDClient fdClient;


    public List<MidOfficeCountDTO> fd() {
//        return List.of(CompletableFuture.completedFuture(fdClient.getFDCounts()).join());
        return Collections.singletonList(fdClient.getFDCounts());
    }

}