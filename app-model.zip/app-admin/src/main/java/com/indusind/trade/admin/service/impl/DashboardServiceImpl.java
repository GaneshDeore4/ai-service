package com.indusind.trade.admin.service.impl;

import com.indusind.trade.admin.dto.DashboardStatsDTO;
import com.indusind.trade.admin.service.DashboardService;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.repository.BankUserDao;
import com.indusind.trade.model.repository.CompanyDao;
import com.indusind.trade.model.repository.UserDao;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final CompanyDao companyDao;
    private final BankUserDao bankUserDao;
    private final UserDao userDao;

    @Override
    public ApplicationResponse getDashboardStats() {
        DashboardStatsDTO stats = DashboardStatsDTO.builder()
                .totalCustomers(companyDao.count())
                .totalBankUsers(bankUserDao.count())
                .totalCustomerUsers(userDao.count())
                .build();

        return new ApplicationResponse("SUCCESS", stats, "Dashboard statistics fetched successfully.");
    }
}
