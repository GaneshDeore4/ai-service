-- Schema for Admin Service
-- Active DB: MSSQL. Tables are created automatically by Hibernate via
-- spring.jpa.hibernate.ddl-auto=update based on @Entity classes
-- (no explicit MSSQL DDL needed here).

SELECT 1;

-- ===== PostgreSQL fallback (commented) =====
CREATE TABLE IF NOT EXISTS gtp_auth_group (
    id BIGINT PRIMARY KEY,
    auth_group VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS gtp_category_master (
    category_id SERIAL PRIMARY KEY,
    category_name VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP,
    modified_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gtp_user_type (
    user_type_id BIGINT PRIMARY KEY,
    user_type_name VARCHAR(255) NOT NULL,
    category_id BIGINT NOT NULL,
    created_at TIMESTAMP,
    CONSTRAINT uk_user_type_with_category UNIQUE (user_type_name, category_id),
    CONSTRAINT fk_user_type_category FOREIGN KEY (category_id) REFERENCES gtp_category_master(category_id)
);

-- =========================================================================================

---- Oracle Script
--
----/* =========================================
----   TABLE: GTP_AUTH_GROUP
----   ========================================= */
--
--BEGIN
--  EXECUTE IMMEDIATE '
--    CREATE TABLE gtp_auth_group (
--      id NUMBER(19) PRIMARY KEY,
--      auth_group VARCHAR2(255)
--    )
--  ';
--EXCEPTION
--  WHEN OTHERS THEN
--    IF SQLCODE != -955 THEN RAISE; END IF; -- table already exists
--END;
--/
--
----/* =========================================
----   TABLE: GTP_CATEGORY_MASTER
----   ========================================= */
--
--BEGIN
--  EXECUTE IMMEDIATE '
--    CREATE TABLE gtp_category_master (
--      category_id NUMBER(19) PRIMARY KEY,
--      category_name VARCHAR2(255) NOT NULL UNIQUE,
--      created_at TIMESTAMP,
--      modified_at TIMESTAMP
--    )
--  ';
--EXCEPTION
--  WHEN OTHERS THEN
--    IF SQLCODE != -955 THEN RAISE; END IF;
--END;
--/
--
----/* =========================================
----   SEQUENCE FOR CATEGORY_ID (SERIAL EQUIVALENT)
----   ========================================= */
--
--BEGIN
--  EXECUTE IMMEDIATE '
--    CREATE SEQUENCE gtp_category_master_seq
--    START WITH 1
--    INCREMENT BY 1
--    NOCACHE
--    NOCYCLE
--  ';
--EXCEPTION
--  WHEN OTHERS THEN
--    IF SQLCODE != -955 THEN RAISE; END IF;
--END;
--/
--
----/* =========================================
----   TRIGGER TO AUTO-POPULATE CATEGORY_ID
----   ========================================= */
--
--CREATE OR REPLACE TRIGGER trg_gtp_category_master_bi
--BEFORE INSERT ON gtp_category_master
--FOR EACH ROW
--WHEN (new.category_id IS NULL)
--BEGIN
--  SELECT gtp_category_master_seq.NEXTVAL
--  INTO :new.category_id
--  FROM dual;
--END;
--/
--
----/* =========================================
----   TABLE: GTP_USER_TYPE
----   ========================================= */
--
--BEGIN
--  EXECUTE IMMEDIATE '
--    CREATE TABLE gtp_user_type (
--      user_type_id NUMBER(19) PRIMARY KEY,
--      user_type_name VARCHAR2(255) NOT NULL,
--      category_id NUMBER(19) NOT NULL,
--      created_at TIMESTAMP,
--      CONSTRAINT uk_user_type_with_category
--        UNIQUE (user_type_name, category_id),
--      CONSTRAINT fk_user_type_category
--        FOREIGN KEY (category_id)
--        REFERENCES gtp_category_master(category_id)
--    )
--  ';
--EXCEPTION
--  WHEN OTHERS THEN
--    IF SQLCODE != -955 THEN RAISE; END IF;
--END;
--/
--
--==================================================================================

----/* =========================================================
--
----   MSSQL
----   SCHEMA CREATION SCRIPT – MSSQL
----
----   ========================================================= */
--
----/* =========================================================
----   TABLE: gtp_auth_group
----   ========================================================= */
--
--IF OBJECT_ID('gtp_auth_group', 'U') IS NULL
--BEGIN
--    CREATE TABLE gtp_auth_group (
--        id BIGINT PRIMARY KEY,
--        auth_group VARCHAR(255)
--    );
--END;
--GO
--
--
----/* =========================================================
----   TABLE: gtp_category_master
----   SERIAL → IDENTITY(1,1)
----   ========================================================= */
--
--IF OBJECT_ID('gtp_category_master', 'U') IS NULL
--BEGIN
--    CREATE TABLE gtp_category_master (
--        category_id BIGINT IDENTITY(1,1) PRIMARY KEY,
--        category_name VARCHAR(255) NOT NULL,
--        created_at DATETIME2 NULL,
--        modified_at DATETIME2 NULL,
--        CONSTRAINT uk_category_name UNIQUE (category_name)
--    );
--END;
--GO
--
--
----/* =========================================================
----   TABLE: gtp_user_type
----   ========================================================= */
--
--IF OBJECT_ID('gtp_user_type', 'U') IS NULL
--BEGIN
--    CREATE TABLE gtp_user_type (
--        user_type_id BIGINT PRIMARY KEY,
--        user_type_name VARCHAR(255) NOT NULL,
--        category_id BIGINT NOT NULL,
--        created_at DATETIME2 NULL,
--        CONSTRAINT uk_user_type_with_category
--            UNIQUE (user_type_name, category_id),
--        CONSTRAINT fk_user_type_category
--            FOREIGN KEY (category_id)
--            REFERENCES gtp_category_master(category_id)
--    );
--END;
--GO


-- =======================================================================================
---- MySQL Script
--
----/* =========================================
----   TABLE: GTP_AUTH_GROUP
----   ========================================= */
--
--CREATE TABLE IF NOT EXISTS gtp_auth_group (
--  id BIGINT PRIMARY KEY,
--  auth_group VARCHAR(255)
--) ENGINE=InnoDB;
--
--
----/* =========================================
----   TABLE: GTP_CATEGORY_MASTER
----   ========================================= */
--
--CREATE TABLE IF NOT EXISTS gtp_category_master (
--  category_id BIGINT AUTO_INCREMENT,
--  category_name VARCHAR(255) NOT NULL,
--  created_at TIMESTAMP NULL,
--  modified_at TIMESTAMP NULL,
--  PRIMARY KEY (category_id),
--  UNIQUE KEY uk_category_name (category_name)
--) ENGINE=InnoDB;
--
--
----/* =========================================
----   TABLE: GTP_USER_TYPE
----   ========================================= */
--
--CREATE TABLE IF NOT EXISTS gtp_user_type (
--  user_type_id BIGINT PRIMARY KEY,
--  user_type_name VARCHAR(255) NOT NULL,
--  category_id BIGINT NOT NULL,
--  created_at TIMESTAMP NULL,
--  CONSTRAINT uk_user_type_with_category
--    UNIQUE (user_type_name, category_id),
--  CONSTRAINT fk_user_type_category
--    FOREIGN KEY (category_id)
--    REFERENCES gtp_category_master(category_id)
--    ON UPDATE RESTRICT
--    ON DELETE RESTRICT
--) ENGINE=InnoDB;