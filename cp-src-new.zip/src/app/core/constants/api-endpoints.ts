// const API_IP = (typeof window !== 'undefined' && (window as any).API_IP);
// const BASE_URL = `http://${API_IP}:8080`;
// const BASE_URL_AUTH = `http://${API_IP}:8080`;

// const BASE_URL = `https://api-giftcity-dev.trusthub.in`;
// const BASE_URL_AUTH = `https://api-giftcity-dev.trusthub.in`;

const BASE_URL = `http://localhost:8080`;
const BASE_URL_AUTH = `http://localhost:8080`;

export const ApiEndpoints = {
  dashboard: {
    Notification: `${BASE_URL}/api/notification/getAllClientNotifications`,
    Guidelines: `${BASE_URL}/api/guideline/getAllClientGuidelines`,
  },
  auth: {
    login: `${BASE_URL}/api/auth/client/clientLogin`,
    logout: `${BASE_URL}/api/auth/logout`,
    privacyPolicy: `${BASE_URL}/api/auth/client/privacy-policy`,
    myaccess: `${BASE_URL}/api/user/myaccess`,
    resetpassword: `${BASE_URL}/api/auth/client/resetUserPassword`,
    unlockUser: `${BASE_URL}/api/auth/client/unclockUser`,
    unlockUserBeforeLogin: `${BASE_URL}/api/auth/client/unclockUserBeforeLogin`,
    forgotPassword: `${BASE_URL}/api/auth/client/resetUserPassword`,
    forgotPasswordBeforeLogin: `${BASE_URL}/api/auth/client/resetUserPasswordBeforeLogin`,
    forgotUserId: `${BASE_URL}/api/auth/client/forgotUserId`,
  },
  accounts: {
    list: `${BASE_URL}/api/accounts`,
    sync: (cif: string) => `${BASE_URL}/api/accounts/sync/${cif}`,
    syncBalance: (accountNumber: string) => `${BASE_URL}/api/accounts/sync-balance/${accountNumber}`,
    byCif: (cif: string) => `${BASE_URL}/api/accounts/cif/${cif}`,
    balance: `${BASE_URL}/api/accounts/balance`,
    accountByUser: (userId: string) =>
      `${BASE_URL}/api/account_mapping/account-details-userId?userId=${userId}`,
  },
  statements: {
    mini: () => `${BASE_URL}/api/statements/fetchMiniStatement`,
    full: (ref?: string, type?: string, continueToken?: string) => {
      let params = new URLSearchParams();
      if (ref) params.append('tranId', ref);
      if (type) params.append('debitOrCredit', type);
      if (continueToken) params.append('continueToken', continueToken);
      return `${BASE_URL}/api/statements/fetchAccountStatement?${params.toString()}`;
    },
    sync: () => `${BASE_URL}/api/statements/fetchAccountStatement`,
    filter: (ref?: string, type?: string) => {
      let params = new URLSearchParams();
      if (ref) params.append('tranId', ref);
      if (type) params.append('debitOrCredit', type);
      return `${BASE_URL}/api/statements/fetchAccountStatement?${params.toString()}`;
      // return `${BASE_URL}/api/statements/sync/${acc}?fromDate=${start}&toDate=${end}`;
    },
    downloadPdf: () => `${BASE_URL}/api/statements/download/pdf`,
  },
  fixedDeposit: {
    fdEnquiry: (cifId: string) =>
      `${BASE_URL}/api/fd/v2/getAllFDsByCifId?cifId=${cifId}`,
    checkerTray: () =>
      `${BASE_URL}/api/fd/v2/checkerFDTrayByStatus`,
    vrTray: () =>
      `${BASE_URL}/api/fd/v2/releaserOrVerifierFDTrayByStatus`,
    enquiryFDDetails: () =>
      `${BASE_URL}/api/accounts/detail`,
    closeFDEnquiry: () =>
      `${BASE_URL}/api/fd/v2/fdClosureReq`,
    checkerPendingTray: (userId: string, groupId: string) =>
      `${BASE_URL}/api/fd/v2/checkerPendingFDTray?userId=${userId}&groupId=${groupId}`,
    vrPendingTray: (userId: string, roleName: string) =>
      `${BASE_URL}/api/fd/v2/releaserOrVerifierFDPendingTray?userId=${userId}&roleName=${roleName}`,
    allowedCallableTypes: (cifId: string) =>
      `${BASE_URL}/api/fd/v2/allowedCallableTypes?cifId=${cifId}`,
    IntRate: `${BASE_URL}/api/fd/v2/calculateFDInterest`,
    createfd: `${BASE_URL}/api/fd/v2/createFd`,
    approvefd: `${BASE_URL}/api/fd/v2/approveFd`,
    rejectfd: `${BASE_URL}/api/fd/v2/rejectFd`,
    fdRoadmap: (fdId: number) =>
      `${BASE_URL}/api/fd/v2/roadmapPaths?fdId=${fdId}`,
    fdAudit: (fdId: number) =>
      `${BASE_URL}/api/fd/v2/getFDAuditsByFdId?fdId=${fdId}`,
  },
  otp: {
    sendOtp: `${BASE_URL}/api/communication/sendUserOtp`,
    sendOtpBeforeLogin: `${BASE_URL}/api/communication/sendUserOtpBeforeLogin`,
    resendOtp: `${BASE_URL}/api/communication/resendUserOtp`,
    validateOtp: `${BASE_URL}/api/communication/confirmUserOtp`,
    validateOtpBeforeLogin: `${BASE_URL}/api/communication/confirmUserOtpBeforeLogin`,
  },
};

// const BASE_URL_AUTH = 'http://localhost:8080/';

// LOGIN/LOGOUT URL
export const LOGIN_URL = BASE_URL_AUTH + '/api/auth/bank/bankLogin';
export const FORCE_LOGOUT = BASE_URL_AUTH + '/api/auth/logout/force';
export const FORGOT_PASSWORD =
  BASE_URL_AUTH + '/api/auth/bank/resetBankUserPassword';

// COMPANY USER
export const CREATE_COMPANY_USER = BASE_URL + '/api/user/submitUser';
export const AUTHORIZE_COMPANY_USER = BASE_URL + '/api/user/authoriseUser';
export const GET_USER_BY_COMPANY_ID = BASE_URL + '/api/user/getUsersByCompanyId';
export const GET_TEMP_USER_BY_COMPANY_ID =
  BASE_URL + '/api/user/getTempUsersByCompanyId';
export const APPROVE_USER = BASE_URL + '/api/user/approveUser';
export const REJECT_USER = BASE_URL + '/api/user/rejectUser';
export const GET_TEMP_USER_BY_ID = BASE_URL + '/api/user/getTempUserById';
export const GET_PRO_SUBPRO_MAP_BY_COMPANY_ID =
  BASE_URL + '/api/company/getProdSubProdMapByCompanyTemp';

// COMPANY
export const CREATE_COMPANY = BASE_URL + '/api/company/saveCompanyDetails';
export const AUTHORIZE_COMPANY = BASE_URL + '/api/company/authoriseCompany';
export const GET_ALL_TEMP_COMPANIES =
  BASE_URL + '/api/company/getAllTempCompanies';
export const GET_ALL_COMPANIES = BASE_URL + '/api/company/getAllCompanies';
export const GET_ALL_TEMP_COMPANY_BY_ID =
  BASE_URL + '/api/company/getCompanyTempById';
export const GET_ALL_TXN_COMPANIES =
  BASE_URL + '/api/company/getAllTnxCompanies';
export const APPROVE_COMPANY = BASE_URL + '/api/company/approveCompany';
export const REJECT_COMPANY = BASE_URL + '/api/company/rejectCompany';
export const GET_PRODUCTS_BY_COMPANY_ID =
  BASE_URL + '/api/company/getProductsByCompanyId';

// ROLE
export const GET_ALL_TXN_ROLE = BASE_URL + '/api/role/getTempRoleList';
export const GET_ALL_ROLE = BASE_URL + '/api/role/getRoleList';
export const CREATE_ROLE = BASE_URL + '/api/role/saveOrSubmitRoleTemp';
export const EDIT_ROLE = BASE_URL + '/api/role/editRole';
export const AUTHORISE_ROLE = BASE_URL + '//api/company/authoriseCompany';

// ROLE MASTER
export const GET_ALL_MASTER_ROLE = BASE_URL + '/api/role/getTempRoleList';
export const CREATE_MASTER_ROLE = BASE_URL + '/api/role/saveOrSubmitRoleTemp';
export const EDIT_MASTER_ROLE = BASE_URL + '/api/role/editRole';
export const DELETE_MASTER_ROLE = BASE_URL + '/api/company/authoriseCompany';

//CATEGORY MASTER
export const GET_ALL_CATEGORY = BASE_URL + '/api/category/getAllCategories';
export const CREATE_MASTER_CATEGORY = BASE_URL + '/api/category/saveCategory';
export const EDIT_MASTER_CATEGORY = BASE_URL + '/api/category/updateCategory';
export const DELETE_MASTER_CATEGORY = BASE_URL + '/api/category/deleteCategory';
export const GET_PRODUCTS_CATEGORY_ID =
  BASE_URL + '/api/category/getProductsByCategoryId';
export const GET_PRODUCTS_BY_CATEGORY_ID =
  BASE_URL + '/api/category/getProductsByCategoryId';
export const GET_CATEGORY_BY_CATEGORY_NAME =
  BASE_URL + '/api/category/getCategoryByName';

//USER TYPE MASTER
export const GET_ALL_USERTYPE = BASE_URL + '/api/userType/getAllUserTypes';
export const GET_USERTYPE_BY_ID = BASE_URL + '/api/userType/getUserType';
export const CREATE_MASTER_USERTYPE = BASE_URL + '/api/userType/saveUserType';
export const EDIT_MASTER_USERTYPE = BASE_URL + '/api/userType/updateUserType';
export const DELETE_MASTER_USERTYPE = BASE_URL + '/api/userType/deleteUserType';
export const GET_USER_TYPE_BY_CATEGORY_ID =
  BASE_URL + '/api/category/getUserTypeByCategoryId';
export const GET_USER_TYPE_BY_CATEGORY =
  BASE_URL + '/api/category/getUserTypeByCategory';
export const GET_CATEGORY_BY_ID = BASE_URL + '/api/category/getCategory';

// PRODUCT MASTER
export const GET_ALL_MASTER_PRODUCT = BASE_URL + '/api/product/getAllProducts';
export const CREATE_MASTER_PRODUCT = BASE_URL + '/api/product/saveProduct';
export const EDIT_MASTER_PRODUCT = BASE_URL + '/api/product/updateProduct';
export const DELETE_MASTER_PRODUCT = BASE_URL + '/api/product/deleteProduct';
export const GET_PRO_SUBPRO_MAP_BY_CATEGORY_ID =
  BASE_URL + '/api/product/getProdSubProdMapByCategoryId';

// SUB PRODUCT MASTER
export const GET_ALL_MASTER_SUBPRODUCT =
  BASE_URL + '/api/subproduct/getAllSubProducts';
export const CREATE_MASTER_SUBPRODUCT =
  BASE_URL + '/api/subproduct/saveSubProduct';
export const EDIT_MASTER_SUBPRODUCT =
  BASE_URL + '/api/subproduct/updateSubProduct';
export const DELETE_MASTER_SUBPRODUCT =
  BASE_URL + '/api/subproduct/deleteSubProduct';
export const GET_ALL_SUBPRO_BY_PRO_LIST =
  BASE_URL + '/api/product/getSubProductsByProductList';
export const GET_ALL_SUB_PRODUCTS =
  BASE_URL + '/api/subproduct/getAllSubProducts/all';
export const GET_SUBPRODUCTS_BY_PRODUCT_ID =
  BASE_URL + '/api/product/getSubProductsByProductId';

// ACTION MASTER
export const GET_ALL_MASTER_ACTION = BASE_URL + '/api/action/getAllActions';
export const CREATE_MASTER_ACTION = BASE_URL + '/api/action/saveAction';
export const EDIT_MASTER_ACTION = BASE_URL + '/api/action/updateAction';
export const GET_ACTION_BY_PRODUCT_ID =
  BASE_URL + '/api/product/getActionsByProductId';

// TAB MASTER
export const GET_ALL_MASTER_TAB = BASE_URL + '/api/master/getAllTabs';
export const CREATE_MASTER_TAB = BASE_URL + '/api/master/addTab';
export const EDIT_MASTER_TAB = BASE_URL + '/api/master/updateTab';
export const GET_TABS_BY_SUBPRODUCT_ID =
  BASE_URL + '/api/subproduct/getTabsBySubProductId';

// ACTION MAPPING MASTER
export const GET_MY_ACCESS = BASE_URL + '/api/usertype-tab-action/myaccess';
export const ADD_ACTION_MAPPING =
  BASE_URL + '/api/usertype-tab-action/addMapping';
export const GET_ACTION_MAPPING =
  BASE_URL + '/api/usertype-tab-action/getMappingByTabIds';

//AuthGroup
export const GET_AUTH_GROUPS = BASE_URL + '/api/authGroup/getAuthGroups';

//AuthMatrix
export const ADD_AUTH_MATRIX = BASE_URL + '/api/authMatrix/addAuthMatrix';
export const GET_GROUPED_AUTH_MATRIX =
  BASE_URL + '/api/authMatrix/getAllGroupedAuthMatrixTemp';
export const APPROVE_GROUPED_MATRIX =
  BASE_URL + '/api/authMatrix/approveGroupedAuthMatrix';
export const REJECT_GROUPED_MATRIX =
  BASE_URL + '/api/authMatrix/rejectGroupedAuthMatrix';
export const GET_ALL_AUTH_MATRIX =
  BASE_URL + '/api/authMatrix/getAllAuthMatrixTemp';
export const GET_AUTH_MATRIX_BY_ID =
  BASE_URL + '/api/authMatrix/getAuthMatrixTempById';
export const AUTH_MATRIX_APPROVE =
  BASE_URL + '/api/authMatrix/approveAuthMatrix';
export const AUTH_MATRIX_REJECT = BASE_URL + '/api/authMatrix/rejectAuthMatrix';

// BANK
export const GET_ALL_TEMP_BANK = BASE_URL + '/api/bankprofile/getAllTempBanks';
export const GET_ALL_BANK = BASE_URL + '/api/bankprofile/getAllBanks';
export const GET_TEMP_BANK_BY_ID = BASE_URL + '/api/bankprofile/getBankTempById';
export const SAVE_BANK_PROFILE = BASE_URL + '/api/bankprofile/saveBankProfile';
export const APPROVE_BANK = BASE_URL + '/api/bankprofile/approveBankProfile';
export const REJECT_BANK = BASE_URL + '/api/bankprofile/rejectBankProfile';

//BANK USERS
export const GET_ALL_TEMP_BANK_USERS_BY_BANK_ID =
  BASE_URL + '/api/bankuser/getTempBankUsersByBankProfileId';
export const GET_ALL_TEMP_BANK_USERS =
  BASE_URL + '/api/bankuser/getAllTempBankUsers';
export const GET_TEMP_BANK_USER_BY_ID =
  BASE_URL + '/api/bankuser/getBankUserTempById';
export const SAVE_BANK_USERS = BASE_URL + '/api/bankuser/saveBankUser';
export const APPROVE_BANK_USER = BASE_URL + '/api/bankuser/approveBankUser';
export const REJECT_BANK_USER = BASE_URL + '/api/bankuser/rejectBankUser';
export const GET_BANK_USER_BY_ID = BASE_URL + '/api/bankuser/getBankUserById';

// USER ACCOUNT MAPPING
export const GET_ALL_ACCOUNT_BY_CIF =
  BASE_URL + '/api/account_mapping/account-details-cif';
export const SYNC_API = BASE_URL + '/api/accounts/sync';
export const GET_ACCOUNT_BY_CIF = BASE_URL + '/api/accounts/cif';
export const SAVE_USER_ACCOUNT_MAPPING =
  BASE_URL + '/api/account_mapping/user-account-mapping-grouped';
// OTP
export const SEND_OTP = BASE_URL + '/api/communication/sendBankUserOtp';
export const RESEND_OTP = BASE_URL + '/api/communication/resendBankUserOtp';
export const VALIDATE_OTP = BASE_URL + '/api/communication/confirmBankUserOtp';

export const GET_FD_BY_STATUS = BASE_URL + '/api/fd/v2/getFDByStatus';
export const GET_FD_BY_STATUS_AND_CIF = BASE_URL + '/api/fd/v2/getFDByCIFAndStatus';
export const SAVE_MID_OFFICE_ACCESS =
  BASE_URL + '/api/product/mapProductToMidOffice';
export const GET_ALL_PRODUCTS_BY_CATEGORY_ID =
  BASE_URL + '/api/product/getAllProductsByCategoryId';
  export const PRE_EXISTING_COMPANY_DETAILS_BY_CIF =
  BASE_URL + 'api/company/fetchCompanyByCif';