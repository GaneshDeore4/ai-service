import { Product } from './../../../../core/models/access.models';
import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
  ViewChildren,
  QueryList,
  ElementRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ApiService } from '../../../../core/services/api.service';
import { TableComponent } from '../../../../shared/components/table/table.component';
import { Deposit, DepositEnquiryDetail, Roadmap } from '../../../../core/models/banking.models';
import { DepositSummaryModalComponent } from '../../../../shared/components/deposit-summary-modal/deposit-summary-modal.component';
import { FdReceiptModalComponent } from '../../../../shared/components/fd-receipt-modal/fd-receipt-modal.component';
import { UserProfile } from '../../../../core/models/auth.models';
import { AuthService } from '../../../../core/services/auth.service';
import {
  CLIENTCHECKER,
  CLIENTMAKER,
  CLIENTMC,
  CLIENTRELEASER,
  CLIENTVERIFIER,
} from '../../../../core/constants/roles';
import { AccessService } from '../../../../core/services/access.service';
import { UserAccessProfile } from '../../../../core/models/access.models';
import { FdRoadmapComponent } from '../../../../shared/components/fd-roadmap/fd-roadmap.component';
import { FormsModule } from '@angular/forms';
import { GET_FD_BY_STATUS, GET_FD_BY_STATUS_AND_CIF } from '../../../../core/constants/api-endpoints';
import { OtpPopupComponent } from '../../../../shared/components/otp-popup/otp-popup.component';
import { ClosureModalComponent } from "../../../../shared/components/closure-modal/closure-modal.component";
import { ToastComponent } from "../../../../shared/components/toast/toast.component";


@Component({
  selector: 'app-deposit-list',
  templateUrl: './deposit-list.component.html',
  styleUrls: ['./deposit-list.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    TableComponent,
    DepositSummaryModalComponent,
    FdReceiptModalComponent,
    FormsModule,
    FdRoadmapComponent,
    OtpPopupComponent,
    ClosureModalComponent,
    ToastComponent
  ],
})
export class DepositListComponent implements OnInit {
  @ViewChild('actionTemplate', { static: true })
  actionTemplate!: TemplateRef<any>;

  showOtpPopup = false;
  deposits: Deposit[] = [];
  filteredDeposits: Deposit[] = [];
  columns: any[] = [];
  isSummaryOpen = false;
  isReceiptOpen = false;
  selectedDeposit: Deposit | null = null;
  productId: number | null = null;
  subProductId: number | null = null;
  tabs = [
    { label: 'FD Summary', key: 'FD_ENQUIRY' },
    { label: 'Action Required', key: 'ACTION_REQUIRED' },
    { label: 'Pending Approval', key: 'PENDING_APPROVAL' },
    { label: 'Pending At Bank', key: 'PENDING_AT_BANK' },
  ];
  statusMap: Record<string, string[]> = {
    FD_ENQUIRY: ['APPROVED', 'MID_OFFICE_APPROVED'],
    ACTION_REQUIRED: ['REJECTED', 'MID_OFFICE_REJECTED'],
    PENDING_APPROVAL: ['IN_APPROVAL'],
    PENDING_AT_BANK: ['PENDING_AT_MID_OFFICE'],
  };
  activeTab = 'FD_ENQUIRY';
  currentUser: UserProfile | null = null;
  isFilterOpen = false;
  userRole = '';
  userId: string = '';
  cif: string = '';
  groupId: number | null = null;
  showCheckerButtons = false;
  searchText: string = '';
  isLoading: boolean = false;
  isReasonEditable = false;
  isMidoffice: Boolean = false;
  LoginID: string | null = '';
  userName: string | null = '';
  groupName: string | null = '';
  pendingAction: 'approve' | 'reject' | null = null;
  pendingReason: string = '';
  auditData: any[] = [];
  auditVisible = false;

  // Success modal state
  isSuccessModalOpen: boolean = false;
  successModalTitle: string = '';
  successModalMessage: string = '';

  auditPage = 0;
  auditSize = 5;
  auditSort: 'ASC' | 'DESC' = 'ASC';

  selectedFdId: number | null = null;
  totalPages = 0;

  getFdAudit(fdId: number) {
    this.isLoading = true;

    const payload = {
      page: this.auditPage,
      size: this.auditSize,
      sort: [`timestamp,${this.auditSort}`],
    };

    this.apiService.fdAudit(fdId, payload).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.auditData = res.payload.content;
          this.totalPages = res.payload.totalPages;
        }
      },
      error: (err) => console.error('Audit API Error', err),
      complete: () => (this.isLoading = false),
    });
  }

  openAudit(row: Deposit) {
    if (row.fdId == undefined) {
      this.selectedFdId = row.id;
    } else {
      this.selectedFdId = row.fdId;
    }

    this.auditPage = 0; // reset page
    this.auditVisible = true;

    this.getFdAudit(this.selectedFdId);
  }


  constructor(
    private apiService: ApiService,
    private authService: AuthService,
    private accessService: AccessService
  ) {
    this.authService.currentUser$.subscribe((user: UserProfile | null) => {
      this.currentUser = user;
      this.userRole = user?.role ?? '';
      console.log(this.userRole);
      this.userId = user?.userId ?? '';
      this.groupId = user?.groupId ?? null;
      this.LoginID = user?.loginId ?? null;
      this.userName = user?.userFirstName ?? null;
      this.groupName = user?.groupName ?? null;
      this.cif = user?.cif ?? '';
    });


    if (
      this.userRole == CLIENTCHECKER ||
      this.userRole == CLIENTMC ||
      this.userRole == CLIENTVERIFIER ||
      this.userRole == CLIENTRELEASER
    ) {
      this.showCheckerButtons = true;
    }

    this.getProductId();
  }

  ngOnInit() {
    this.accessService.accessProfile$.subscribe(
      (access: UserAccessProfile | null) => {
        if (access && access.products) {
          const fdProduct = access.products.find((p) => p.productName === 'FD');
          if (fdProduct) {
            this.isMidoffice =
              fdProduct.isMidOffice == null ? false : fdProduct.isMidOffice;
          }
        }
      }
    );
    console.log('[DEBUG] ngOnInit: Initial userRole:', this.userRole);
    console.log('[DEBUG] ngOnInit: Initial activeTab:', this.activeTab);
    this.updateHeaders();
    this.changeActiveTab(this.activeTab);
  }

  // changeActiveTab(tab: string) {
  //   this.activeTab = tab;
  //   // Clear the data first when switching tabs
  //   this.deposits = [];
  //   this.filteredDeposits = [];

  //   if (tab === 'FD_ENQUIRY') {
  //     this.getTableData(); // Finacle Data
  //   } else if (tab === 'ACTION_REQUIRED') {
  //     if (this.userRole == CLIENTCHECKER || this.userRole == CLIENTMC) {
  //       this.getFdForChecker();
  //     } else if (
  //       this.userRole == CLIENTVERIFIER ||
  //       this.userRole == CLIENTRELEASER
  //     ) {
  //       this.getFdForVR();
  //     } else {
  //       this.getOtherFDS('REJECTED', true);
  //       this.getOtherFDS('MID_OFFICE_REJECTED', false);
  //     }
  //   } else if (tab === 'PENDING_APPROVAL') {
  //     this.getOtherFDS('IN_APPROVAL', true);
  //   } else if (tab === 'PENDING_AT_BANK') {
  //     this.getOtherFDS('PENDING_AT_MID_OFFICE', true);
  //   }

  //   this.updateHeaders();
  //   console.log('[DEBUG] changeActiveTab: Columns after updateHeaders:', this.columns);
  // }/


  changeActiveTab(tab: string) {
    this.activeTab = tab;
    if (tab === 'ACTION_REQUIRED') {
      if (this.userRole == CLIENTCHECKER || this.userRole == CLIENTMC)
        this.getFdForChecker();
      else if (
        this.userRole == CLIENTVERIFIER ||
        this.userRole == CLIENTRELEASER
      ) {
        this.getFdForVR();
      } else {
        // this.getOtherFDS('REJECTED', true);
        // this.getOtherFDS('MID_OFFICE_REJECTED');
        this.getTableData();
      }
    } else {
      this.getTableData();
    }
    // else if (tab === 'FD_ENQUIRY') {
    //   this.getOtherFDS('APPROVED', true); // ✅ first call clears
    //   this.getOtherFDS('MID_OFFICE_APPROVED'); // ✅ append
    // } else if (tab === 'PENDING_AT_BANK') {
    //   this.getOtherFDS('PENDING_AT_MID_OFFICE', true);
    // }
    // else if(tab=='PENDING_APPROVAL'){
    //   this.getTableData();
    // }
    this.updateHeaders();
  }


  updateHeaders() {
    if (
      (this.userRole == CLIENTCHECKER ||
        this.userRole == CLIENTMC ||
        this.userRole == CLIENTVERIFIER ||
        this.userRole == CLIENTRELEASER) &&
      this.activeTab == 'ACTION_REQUIRED'
    ) {
      this.showCheckerButtons = true;
      this.columns = [
        { field: 'accountNumber', header: 'Account Number' }, //not present
        { field: 'interestRate', header: 'Interest Rate' }, //present
        { field: 'currency', header: 'Currency' }, //present
        // { field: 'principalAmount', header: 'Principal Amount' },//there is only one amount in api res
        { field: 'amount', header: 'Amount' }, //there is only one amount in api res
        { field: 'tenure', header: 'Tenure' }, //present in form of year, months, days indivualy in res
        { field: 'maturityInstruction', header: 'Maturity Instructions' }, //present
        { field: 'status', header: 'Approval Status' }, //present
        { field: 'fdStatus', header: 'FD Status' }, //present
        { field: 'actions', header: 'Action', template: this.actionTemplate },
      ];
    } else {
      // Default columns for other tabs
      this.columns = [
        { field: 'accountNumber', header: 'Account Number' }, //not present
        { field: 'interestRate', header: 'Interest Rate' }, //present
        { field: 'currency', header: 'Currency' }, //present
        // { field: 'principalAmount', header: 'Principal Amount' },//there is only one amount in api res
        { field: 'amount', header: 'Amount' }, //there is only one amount in api res
        { field: 'tenure', header: 'Tenure' }, //present in form of year, months, days indivualy in res
        { field: 'maturityInstruction', header: 'Maturity Instructions' }, //present
        { field: 'status', header: 'Status' }, //present
        { field: 'actions', header: 'Action', template: this.actionTemplate },
      ];
    }
    console.log('[DEBUG] updateHeaders: Columns set to:', this.columns);
  }

  // changeActiveTab(tab: string) {
  //   this.activeTab = tab;
  //   this.getTableData();
  // }

  // This method is for other status-based fetches, likely for other tabs
  // It uses a POST request with a payload containing statuses
  // This is likely for FDCheckerTray or FDVRTray (the ones that take a payload)
  // It's not directly used for releaserOrVerifierFDPendingTray (which is a GET)
  // Renamed to getTableDataByStatus for clarity
  getTableData() {
    this.isLoading = true;
    const statuses = this.statusMap[this.activeTab] || [];
    const payload = {
      status: statuses,
      cifId: this.cif
    };
    console.log('[DEBUG] getTableData: Calling sendData with payload:', payload);
    // this.apiService.sendData(GET_FD_BY_STATUS, payload).subscribe({
    const URL = this.activeTab === 'FD_ENQUIRY' ? GET_FD_BY_STATUS : GET_FD_BY_STATUS_AND_CIF
    this.apiService.sendData(URL, payload).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.deposits = (res.payload?.content || []).map((item: any) => ({
            ...item,
            amount: item.depositAmount || item.amount,
            interestRate: item.applRateOfInterest || item.interestRate,
            maturityInstruction: item.maturityInsc || item.maturityInstruction,
            status: item.accountStatus || item.status,
            tenure: `${item.depositPeriodMonths || item.tenureMonths || 0} months ${item.depositPeriodDays || item.tenureDays || 0} days`,
          }));
          this.filteredDeposits = [...this.deposits];
          console.log('Mapped Deposits:', this.deposits);
        } else {
          console.error(res.description);
        }
      },
      error: (err) => {
        console.error('API Error', err);
        this.isLoading = false;
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  isAddBtnVisible(): boolean {
    if (this.userRole == CLIENTMAKER || this.userRole == CLIENTMC) return true;
    return false;
  }

  getFdSummary() {
    this.deposits = [];
  }

  getAllFd() {
    this.isLoading = true;
    let cifId = this.currentUser?.cif ?? '35133028';
    this.apiService.FDEnquiry(cifId).subscribe({
      // This method is likely for FD_ENQUIRY tab
      next: (res: any) => {
        this.isLoading = false;
        this.deposits = [];
        this.filteredDeposits = [];
        if (res.status == 'SUCCESS') {
          this.deposits = res.payload.content.map((item: any) => ({
            ...item,
            tenure: `${item.tenureYears || 0} years ${item.tenureMonths || 0
              } months ${item.tenureDays || 0} days`,
          }));
          console.log('[DEBUG] getAllFd: Mapped Deposits:', this.deposits);
          this.filteredDeposits = [...this.deposits];
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error('Error fetching fd by status', err);
      },
      complete: () => { },
    });
  }

  getOtherFDS(status: string, isFirstCall = false) {
    this.isLoading = true;
    const payload = {
      userId: this.userId,
      cifId: this.cif,
      groupId: this.groupId,
      status: [status],
    };
    console.log(`[DEBUG] getOtherFDS: Calling FDCheckerTray with payload:`, payload);
    this.apiService.FDCheckerTray(payload).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          const newData = res.payload.content.map((item: any) => ({
            ...item,
            tenure: `${item.tenureYears || 0} years ${item.tenureMonths || 0
              } months ${item.tenureDays || 0} days`,
          }));
          // ✅ Only clear ONCE (first call)
          if (isFirstCall) {
            this.deposits = [];
            this.filteredDeposits = [];
          }
          // ✅ Merge instead of replace
          this.deposits = [...this.deposits, ...newData];
          this.filteredDeposits = [...this.deposits]; // Ensure filteredDeposits is updated
          console.log(`[DEBUG] getOtherFDS: Final filteredDeposits for status ${status}:`, this.filteredDeposits);
        } else {
          console.log(`[DEBUG] getOtherFDS: No content or unsuccessful response for status: ${status}`);
        }
      },
      error: (err) => console.error('Error fetching fd', err),
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  // getFdForChecker() {
  //   this.isLoading = true;
  //   const payload = {
  //     userId: this.userId,
  //     groupId: this.groupId,
  //     status: ['IN_APPROVAL'],
  //   };
  //   this.apiService.FDCheckerTray(payload).subscribe({
  //     next: (res: any) => {
  //       this.isLoading = false;
  //       this.deposits = [];
  //       this.filteredDeposits = [];
  //       if (res.status == 'SUCCESS') {
  //         this.deposits = res.payload.content.map((item: any) => ({
  //           ...item,
  //           tenure: `${item.tenureYears || 0} years ${
  //             item.tenureMonths || 0
  //           } months ${item.tenureDays || 0} days`,
  //         }));
  //         console.log(JSON.stringify(this.deposits, null, 2));
  //         this.deposits = [...this.deposits];
  //       }
  //     },
  //     error: (err) => console.error('Error fetching fd by status', err),
  //     complete: () => {},
  //   });
  // }

  // getFdForVR() {
  //   const payload = {
  //     userId: this.userId,
  //     roleName: this.userRole,
  //     groupId: this.groupId,
  //     status: ['IN_APPROVAL'],
  //   };
  //   this.apiService.FDVRTray(payload).subscribe({
  //     next: (res: any) => {
  //       this.deposits = [];
  //       if (res.status == 'SUCCESS') {
  //         this.deposits = res.payload.content.map((item: any) => ({
  //           ...item,
  //           tenure: `${item.tenureYears || 0} years ${
  //             item.tenureMonths || 0
  //           } months ${item.tenureDays || 0} days`,
  //         }));
  //         console.log(JSON.stringify(this.deposits, null, 2));
  //         this.deposits = [...this.deposits];
  //       }
  //     },
  //     error: (err) => console.error('Error fetching fd by status', err),
  //     complete: () => {},
  //   });
  // }

  getFdForChecker() {
    this.isLoading = true;
    this.apiService.FDCheckerPendingTray(this.userId, this.groupId?.toString() ?? '').subscribe({
      //console.log(`[DEBUG] getFdForChecker: Calling FDCheckerPendingTray for userId: ${this.userId}, groupId: ${this.groupId}`);
      next: (res: any) => {
        this.isLoading = false;
        this.deposits = [];
        this.filteredDeposits = [];
        console.log('[DEBUG] getFdForChecker: API Response:', res);
        if (res.status == 'SUCCESS') {
          this.deposits = res.payload.content.map((item: any) => ({
            ...item,
            tenure: `${item.tenureYears || 0} years ${item.tenureMonths || 0
              } months ${item.tenureDays || 0} days`,
          }));
          console.log('[DEBUG] getFdForChecker: Mapped Deposits:', JSON.stringify(this.deposits, null, 2));
          // Removed redundant line: this.deposits = [...this.deposits];
          this.filteredDeposits = [...this.deposits];
          console.log('[DEBUG] getFdForChecker: Final filteredDeposits:', this.filteredDeposits);
        } else {
          console.log('[DEBUG] getFdForChecker: No content or unsuccessful response.');
        }
      },
      error: (err) => console.error('Error fetching fd by status', err),
      complete: () => {
        this.isLoading = false;
      },
    });
  }
  getFdForVR() {
    this.isLoading = true;
    this.apiService.FDVRPendingTray(this.userId, this.userRole).subscribe({
      //console.log(`[DEBUG] getFdForVR: Calling FDVRPendingTray for userId: ${this.userId}, userRole: ${this.userRole}`);
      next: (res: any) => {
        this.deposits = [];
        this.filteredDeposits = []; // Ensure filteredDeposits is cleared here too
        console.log('[DEBUG] getFdForVR: API Response:', res);
        if (res.status == 'SUCCESS') {
          this.deposits = res.payload.content.map((item: any) => ({
            ...item,
            tenure: `${item.tenureYears || 0} years ${
              item.tenureMonths || 0
            } months ${item.tenureDays || 0} days`,
          }));
          console.log('[DEBUG] getFdForVR: Mapped Deposits:', JSON.stringify(this.deposits, null, 2));
          // Removed redundant line: this.deposits = [...this.deposits];
          this.filteredDeposits = [...this.deposits];
          console.log('[DEBUG] getFdForVR: Final filteredDeposits:', this.filteredDeposits);
        } else {
          console.log('[DEBUG] getFdForVR: No content or unsuccessful response.');
        }
      },
      error: (err) => console.error('Error fetching fd by status', err),
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  // validateOtp() {
  //   if (!this.enteredOtp || this.enteredOtp.length < 6) return;

  //   this.showOtpPopup = false;

  //   // 👉 Dummy OTP validation (since you said no API)
  //   const isValidOtp = true;

  //   if (!isValidOtp) {
  //     alert('Invalid OTP');
  //     return;
  //   }

  //   // ✅ Now call API AFTER OTP
  //   if (this.pendingAction === 'approve') {
  //     this.approveFd(this.pendingReason);
  //   } else if (this.pendingAction === 'reject') {
  //     this.rejectFd(this.pendingReason);
  //   }

  //   // reset
  //   this.pendingAction = null;
  //   this.pendingReason = '';
  // }

  handleOtpVerify(otp: string) {
    this.showOtpPopup = false;

    // 👉 Dummy validation (you said no API)
    if (otp.length !== 6) {
      // alert('Invalid OTP'); // replaced by toast
      this.showToast('error', 'Invalid OTP', 'The OTP entered is incorrect. Please try again.');
      return;
    }

    // ✅ Call API AFTER OTP
    if (this.pendingAction === 'approve') {
      this.approveFd(this.pendingReason);
      alert(this.pendingAction)
    } else if (this.pendingAction === 'reject') {
      this.rejectFd(this.pendingReason);
    }

    // reset
    this.pendingAction = null;
    this.pendingReason = '';
  }

  checkerAction(event: { action: string; reason: string }) {
    this.pendingAction = event.action as 'approve' | 'reject';
    this.pendingReason = event.reason;
    this.showOtpPopup = true;
  }

  approveFd(reason: string) {
    const payload = {
      fdId: this.selectedDeposit?.fdId,
      userId: this.userId,
      groupId: this.groupId,
      userType: this.currentUser?.role,
      isMidOffice: this.isMidoffice,
      reason: reason,
      loginId: this.LoginID,
      userName: this.userName,
      groupName: this.groupName,
    };
    this.apiService.approveFd(payload).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          // TODO ADD A POPUP IF NEEDED → replaced by success modal
          this.showSuccessModal('FD Approved', 'The Fixed Deposit has been approved successfully.');
          this.changeActiveTab(this.activeTab);
          this.isSummaryOpen = false;
        } else {
          this.showToast('error', 'Approval Failed', res.description || 'Could not approve the Fixed Deposit.');
        }
      },
      error: (err) => {
        console.error('Error approving fd', err);
        this.showToast('error', 'Error', 'An error occurred while approving. Please try again.');
      },
      complete: () => { },
    });
  }
  rejectFd(reason: string) {
    const payload = {
      fdId: this.selectedDeposit?.fdId,
      userId: this.userId,
      groupId: this.groupId,
      isMidOffice: this.isMidoffice,
      reason: reason,
      loginId: this.LoginID,
      userName: this.userName,
      userType: this.currentUser?.role,
      groupName: this.groupName,
    };
    this.apiService.rejectFd(payload).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          // TODO ADD A POPUP IF NEEDED → replaced by success modal
          this.showSuccessModal('FD Rejected', 'The Fixed Deposit has been rejected successfully.');
          this.changeActiveTab(this.activeTab);
          this.isSummaryOpen = false;
        } else {
          this.showToast('error', 'Rejection Failed', res.description || 'Could not reject the Fixed Deposit.');
        }
      },
      error: (err) => {
        console.error('Error rejecting fd', err);
        this.showToast('error', 'Error', 'An error occurred while rejecting. Please try again.');
      },
      complete: () => { },
    });
  }

  onSearch() {
    if (!this.searchText) {
      this.filteredDeposits = [...this.deposits];
      return;
    }
    const search = this.searchText.toLowerCase();
    this.filteredDeposits = this.deposits.filter(
      (d) =>
        String(d.fdId || '')
          .toLowerCase()
          .includes(search) ||
        String(d.accountNumber || '')
          .toLowerCase()
          .includes(search) ||
        String(d.status || '')
          .toLowerCase()
          .includes(search) ||
        String(d.amount || '')
          .toLowerCase()
          .includes(search)
    );
  }

  actionButtonClick(row: Deposit, activePopup: string) {
    if (activePopup == 'summary') this.isSummaryOpen = true;
    if (activePopup == 'receipt') this.isReceiptOpen = true;
    this.selectedDeposit = row;
    if (this.selectedDeposit.status == 'PENDING')
      this.showCheckerButtons = true;
    else this.showCheckerButtons = false;
  }

  // ROADMAP FUNCTIONALITY
  showRoadMapPopup = false;
  roadmapData: Roadmap | null = null;

  closeRoadMap() {
    this.showRoadMapPopup = false;
  }

  openRoadMap(row: Deposit) {
    let id = row.fdId;
    if (id == null) id = row.id;
    this.apiService.fdRoadmap(id).subscribe({
      next: (res: any) => {
        this.roadmapData = res;
        this.showRoadMapPopup = true;
      },
      error: (err) => console.error('Error fetching fd roadmap', err),
      complete: () => { },
    });
  }
  nextAuditPage() {
    if (this.auditPage + 1 < this.totalPages) {
      this.auditPage++;
      this.getFdAudit(this.selectedFdId!);
    }
  }

  prevAuditPage() {
    if (this.auditPage > 0) {
      this.auditPage--;
      this.getFdAudit(this.selectedFdId!);
    }
  }


  // CLOSURE LOGIC
  closurePopupVisible = false;
  selectedEnquiry: DepositEnquiryDetail | null = null;
  openClosure(row: Deposit) {
    if (row.accountNumber == undefined) return;
    this.selectedDeposit = row;
    this.getEnquiryFdDetails(row.accountNumber);
  }
  onCloseClosurePopup() {
    this.closurePopupVisible = false;
    this.selectedDeposit = null;
  }
  onClosureApiHit() {
    this.closeFdEnquiry();
  }
  getEnquiryFdDetails(accountNumber: string) {
    const payload = {
      accountNumber: accountNumber
      //accountNumber: '371000115212' //USE TEMP FOR DETAILS
    };
    this.apiService.EnquiryFdDetailsByAccount(payload).subscribe({
      next: (res: any) => {
        this.selectedEnquiry = res;
        this.closurePopupVisible = true;
      },
      error: (err) => console.error('Error fetching fd by status', err),
      complete: () => { },
    });
  }
  closeFdEnquiry() {
    // Reverting to Number() as requested to ignore formatting for now,
    // but ensuring it's a number type.
    const finalAmount = Number(this.selectedEnquiry?.maturityAmount || 0);
    console.log('DEBUG: Original maturityAmount:', this.selectedEnquiry?.maturityAmount);
    console.log('DEBUG: Converted amount (number):', finalAmount, 'Type:', typeof finalAmount);

    const payload = {
      "cifId": this.cif,
      "loginId": this.LoginID,
      "fdAccountNumber": this.selectedDeposit?.accountNumber,
      "amount": finalAmount,
      "currency": this.selectedEnquiry?.currency,
      "repaymentAccount": this.selectedDeposit?.accountNumber,
      "interestFrequency": 'MONTHLY', //ASK IN API RESPONSE
      "interestRate": this.selectedEnquiry?.applRateOfInterest,
      "interestAmount": 404.99, //ASK IN API RESPONSE
      "maturityInstruction": this.selectedDeposit?.maturityInstructions,
      "maturityAmount": finalAmount,
      "maturityDate": this.selectedEnquiry?.maturityDate ? this.selectedEnquiry.maturityDate.substring(0, 11) : '',
      // "tenureDays": this.selectedDeposit?.tenureDays,
      // "tenureMonths": this.selectedDeposit?.tenureMonths,
      // "tenureYears": this.selectedDeposit?.tenureYears,
      // "userId": this.userId,
      // "currentLevel": 0,
      // "makerId": this.userId, 
      "tenureDays": this.selectedDeposit?.tenureDays == undefined ? 0 : this.selectedDeposit?.tenureDays,
      "tenureMonths": this.selectedDeposit?.depositPeriodMonths == undefined ? 0 : this.selectedDeposit?.depositPeriodMonths,
      "tenureYears": this.selectedDeposit?.tenureYears == undefined ? 0 : this.selectedDeposit?.tenureYears,
      "userId": this.userId,
      "currentLevel": 0,
      "makerId": this.userId, //NOT NEEDED
      // "createdAt": "2026-04-27T11:00:00", //BACKEND
      // "updatedAt": "2026-04-27T11:00:00", //BACKEND

      "productId": this.productId,
      "subProductId": this.subProductId,
      "closureType": true
    };
    console.log(payload);
    this.apiService.closeFDEqiury(payload).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          this.showToast('success', 'Success', 'FD Closed Successfully');
          this.showToast('success', 'Fixed Deposit Clouser', (res.description));
          this.closurePopupVisible = false;
        }
        else {
          // this.showToast('error', 'Error', 'FD Creation Failed');
          this.showToast('error', 'Fixed Deposit Failed', 'Could not create Fixed Deposit. Reason: ' + (res.description || 'System Error'));
        }
      },
      error: (err) => {
        console.error('Error fetching fd by status', err);
        this.showToast('error', 'Error', 'FD Creation Failed');
      },
      complete: () => { },
    });
  }

  getProductId() {
    this.accessService.accessProfile$.subscribe(
      (access: UserAccessProfile | null) => {
        if (access && access.products) {
          const fdProduct = access.products.find((p) => p.productName === 'FD');
          if (fdProduct) {
            this.productId = fdProduct.productId;
            if (fdProduct.subProducts) {
              const fdSubProduct = fdProduct.subProducts.find(
                (sp: any) => sp.subProductName === 'FD'
              );
              if (fdSubProduct) {
                this.subProductId = fdSubProduct.subProductId;
              }
            }
          }
        }
      }
    );
  }


  // TOAST:
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  showSuccessModal(title: string, message: string) {
    this.successModalTitle = title;
    this.successModalMessage = message;
    this.isSuccessModalOpen = true;
  }

  closeSuccessModal() {
    this.isSuccessModalOpen = false;
  }


}
