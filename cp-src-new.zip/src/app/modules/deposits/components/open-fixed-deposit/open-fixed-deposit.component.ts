import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { ApiService } from '../../../../core/services/api.service';
import { Account } from '../../../../core/models/banking.models';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth.service';
import { AccessService } from '../../../../core/services/access.service';
import { UserAccessProfile } from '../../../../core/models/access.models';
import { EncryptionDecryptionUtil } from '../../../../shared/components/utility/encryption-decryption.util';
import { RsaKeyUtil } from '../../../../shared/components/utility/rsa-key.util';
import { SessionService } from '../../../../core/services/sessionService/session.service';
import { FixedDepositStateService } from '../../../../core/services/fixed-deposit-state.service';
import { ToastComponent } from '../../../../shared/components/toast/toast.component';

@Component({
  selector: 'app-open-fixed-deposit',
  templateUrl: './open-fixed-deposit.component.html',
  styleUrls: ['./open-fixed-deposit.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, ToastComponent],
})
export class OpenFixedDepositComponent implements OnInit {
  accounts: Account[] = [];
  fdForm: any;

  showTermsModal = false;
  cifid: string | '' | undefined;
  openTerms(event: Event) {
    event.preventDefault(); // prevent instant check
    this.showTermsModal = true;
  }
  closeTerms() {
    this.showTermsModal = false;
  }
  acceptTerms() {
    this.fdForm.termsAccepted = true;
    this.onFormChange();
    this.showTermsModal = false;
  }

  yearsList = Array.from({ length: 11 }, (_, i) => i);
  monthsList = Array.from({ length: 13 }, (_, i) => i);
  daysList = Array.from({ length: 31 }, (_, i) => i);

  payoutOptions = ['Yearly', 'Quarterly', 'Monthly', 'OnMaturity'];
  maturityOptions = ['Auto Renewal', 'No Renewal'];
  payoutTypeOptions = ['Principal', 'Principal + Interest'];
  interestPayoutOptions = ['Interest Compounding', 'Interest Payout'];
  allowedCallableTypes: string[] = ['Callable', 'Non-Callable'];
  static readonly MIN_FD_AMOUNT = 1000;

  calculatedInterestRate: string | null = null;
  maturityAmount: string | null = null;
  maturityDate: string | null = null;
  interestAmount: string | null = null;
  totalValue: string | null = null;
  productId: number | null = null;
  subProductId: number | null = null;
  returnRatio: number = 0;
  rawInterestRate: number | null = null;
  userBaseCurrency: string | null = null;
  UserFirstName: string = '';
  availableBalance: string | null = null;
  isBalanceLoading: boolean = false;
  isRateLoading: boolean = false;
  isAmountTouched: boolean = false;

  // Toast state
  toastVisible: boolean = false;
  toastHiding: boolean = false;
  toastType: string = 'warning';
  toastTitle: string = '';
  toastMessage: string = '';


  constructor(
    private rsaUtil: RsaKeyUtil,
    private apiService: ApiService,
    private authService: AuthService,
    private router: Router,
    private accessService: AccessService,
    private stateService: FixedDepositStateService
  ) {
    const nav = this.router.getCurrentNavigation();
    if (nav?.extras.state && nav.extras.state['fromReview']) {
      this.fdForm = this.stateService.getFormData();
    } else {
      this.stateService.clearFormData();
      this.fdForm = this.stateService.getFormData();
    }
    this.getProductId();
  }

  get filteredMaturityOptions(): string[] {
    if (this.fdForm.callableType === 'Non-Callable') {
      return this.maturityOptions.filter(opt => opt !== 'Auto Renewal');
    }
    return this.maturityOptions;
  }

  onFormChange() {
    this.stateService.setFormData(this.fdForm);
  }

  onCallableTypeChange() {
    if (this.fdForm.callableType === 'Non-Callable' && this.fdForm.maturityInstruction === 'Auto Renewal') {
      this.fdForm.maturityInstruction = '';
      this.fdForm.payoutType = '';
    }
    this.onFormChange();
  }

  onMaturityChange() {
    this.fdForm.payoutType = '';
    this.onFormChange();
  }

  fetchBalance() {
    if (!this.fdForm.account || !this.fdForm.account.accountNumber) {
      // alert('Please select an account first'); // replaced by toast
      this.showToast('warning', 'No Account Selected', 'Please select an account first.');
      return;
    }

    this.isBalanceLoading = true;
    this.apiService.syncBalance(this.fdForm.account.accountNumber).subscribe({
      next: (res: any) => {
        this.isBalanceLoading = false;
        if (res.status === 'SUCCESS') {
          // The syncBalance API returns the updated AccountDetail object in payload
          const effectiveBalance = res.payload.effectiveAvailBalance;
          this.availableBalance = effectiveBalance != null ? effectiveBalance.toString() : '0.00';
        } else {
          console.error('Failed to sync balance:', res.message);
          // alert('Failed to fetch balance. Please try again.'); // replaced by toast
          this.showToast('error', 'Balance Fetch Failed', 'Failed to fetch balance. Please try again.');
        }
      },
      error: (err) => {
        this.isBalanceLoading = false;
        console.error('Error fetching balance', err);
        // alert('An error occurred while fetching the balance.'); // replaced by toast
        this.showToast('error', 'Error', 'An error occurred while fetching the balance.');
      }
    });
  }

  ngOnInit() {
    this.authService.currentUser$.subscribe((user) => {
      if (user && user.cif) {
        this.cifid = user.cif;
        this.userBaseCurrency = user.baseCurrency;
        this.UserFirstName = user.userFirstName;
        this.apiService
          .getAccountsByUserId(user.userId)
          .subscribe((response: any) => {
            const fetchedAccounts = Array.isArray(response) ? response : (response.payload || []);
            this.accounts = fetchedAccounts;

            // Re-bind selected account if it exists in state
            if (this.fdForm.account && this.accounts.length > 0) {
              const matched = this.accounts.find(a => a.accountNumber === this.fdForm.account.accountNumber);
              if (matched) this.fdForm.account = matched;
            }
          });

        this.fetchAllowedCallableTypes(user.cif);
      }
    });

    // Trigger interest calculation if data exists
    if (this.fdForm.amount && (this.fdForm.tenure.months > 0 || this.fdForm.tenure.days > 0)) {
      this.onTenureChange();
    }
    console.log(this.UserFirstName);
  }

  fetchAllowedCallableTypes(cifId: string) {
    this.apiService.getAllowedCallableTypes(cifId).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS' && res.payload) {
          this.allowedCallableTypes = Array.isArray(res.payload) ? res.payload : Array.from(res.payload);
          if (this.allowedCallableTypes.length === 1) {
            this.fdForm.callableType = this.allowedCallableTypes[0];
            this.onCallableTypeChange();
          }
        }
      },
      error: (err) => {
        console.error('Error fetching allowed callable types', err);
      }
    });
  }

  getProductId() {
    this.accessService.accessProfile$.subscribe(
      (access: UserAccessProfile | null) => {
        if (access && access.products) {
          const fdProduct = access.products.find((p) => p.productName === 'FD');
          if (fdProduct) {
            this.productId = fdProduct.productId;
            if (fdProduct.subProducts) {
              const fdSubProduct = fdProduct.subProducts.find(
                (sp: any) => sp.subProductName === 'FD'
              );
              if (fdSubProduct) {
                this.subProductId = fdSubProduct.subProductId;
              }
            }
          }
        }
      }
    );
  }

  get isAmountValid(): boolean {
    if (!this.fdForm.amount) return false;
    return Number(this.fdForm.amount) >= OpenFixedDepositComponent.MIN_FD_AMOUNT;
  }

  onlyNumberKey(event: any) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  syncBalance(row: Account) {
    if (!row || !row.accountNumber) return;

    this.apiService.syncBalance(row.accountNumber).subscribe({
      next: (response) => {
        if (response.status === 'SUCCESS') {
          const index = this.accounts.findIndex(acc => acc.accountNumber === row.accountNumber);
          if (index !== -1) {
            this.accounts[index].effectiveAvailBalance = response.payload.effectiveAvailBalance;
          }
          // alert('Balance synchronized successfully!'); // replaced by toast
          this.showToast('success', 'Balance Synced', 'Balance synchronized successfully!');
        }
      },
      error: (err) => {
        console.error('Failed to sync balance', err);
        // alert('Failed to sync balance. Please try again.'); // replaced by toast
        this.showToast('error', 'Sync Failed', 'Failed to sync balance. Please try again.');
      }
    });
  }

  onTenureChange() {
    if (
      this.fdForm.amount &&
      (this.fdForm.tenure.years > 0 ||
        this.fdForm.tenure.months > 0 ||
        this.fdForm.tenure.days > 0)
    ) {
      const payload = {
        cifId: this.cifid,
        amountValue: this.fdForm.amount,
        currencyCode: this.fdForm.account.currency,
        days: this.fdForm.tenure.days,
        months: this.fdForm.tenure.months + 12 * this.fdForm.tenure.years,
      };

      console.log("payload : ", payload)

      this.isRateLoading = true;

      this.apiService.IntRate(payload).subscribe({
        next: (res: any) => {
          this.isRateLoading = false;
          if (res.status == 'SUCCESS') {
            this.rawInterestRate = Number(res.payload.interestRate);
            this.calculatedInterestRate = this.rawInterestRate + '%';
            this.maturityAmount = res.payload.maturityAmount;
            this.maturityDate = res.payload.maturityDate;
            this.interestAmount = res.payload.interestAmount;
            this.totalValue = res.payload.maturityAmount;

            // Calculate ratio for donut chart (Interest vs Principle)
            const principle = Number(this.fdForm.amount);
            const total = Number(this.totalValue);
            if (total > 0) {
              this.returnRatio = (Number(this.interestAmount) / total) * 100;
            } else {
              this.returnRatio = 0;
            }
          } else {
            console.error('API Error:', res.errorMessage);
            this.resetCalculations();
          }
        },
        error: (err) => {
          this.isRateLoading = false;
          console.error('Error fetching interest rate', err);
          this.resetCalculations();
        },
      });
    }
  }

  private resetCalculations() {
    this.calculatedInterestRate = null;
    this.maturityAmount = null;
    this.maturityDate = null;
    this.interestAmount = null;
    this.totalValue = null;
    this.returnRatio = 0;
    this.rawInterestRate = null;
  }

  reset() {
    // Reset logic
  }

  // submit() {
  //   this.router.navigate(['/deposits/review']);
  // }

  async submit() {
    if (!this.isAmountValid) {
      this.showToast('warning', 'Invalid Amount', `Minimum Fixed Deposit amount is ${OpenFixedDepositComponent.MIN_FD_AMOUNT}.`);
      return;
    }

    let userId = '';
    let loginId = '';
    let cif = '';
    let role = '';
    const currentUserStr = sessionStorage.getItem('currentUser');
    if (currentUserStr) {
      try {
        const currentUser = JSON.parse(currentUserStr);
        console.log('currency user: ' + JSON.stringify(currentUser, null, 2));
        userId = currentUser.userId || '';
        loginId = currentUser.loginId || '';
        cif = currentUser.cif;
        role = currentUser.role;
      } catch (e) { }
    }

    const payload = {
      accountNumber: this.fdForm.account?.accountNumber,
      currency: this.fdForm.account?.currency,
      amount: Number(this.fdForm.amount),
      userName: this.UserFirstName,
      tenureYears: this.fdForm.tenure.years,
      tenureMonths: this.fdForm.tenure.months,
      tenureDays: this.fdForm.tenure.days,
      interestFrequency: this.fdForm.interestPayout,
      payoutType: this.fdForm.payoutType,
      maturityInstruction: this.fdForm.maturityInstruction,
      interestPayout: this.fdForm.interestPayout,
      callableType: this.fdForm.callableType,
      termsAccepted: this.fdForm.termsAccepted,
      maturityAmount: this.maturityAmount,
      interestRate: this.rawInterestRate,
      maturityDate: this.maturityDate,
      interestAmount: this.interestAmount,
      userId: userId,
      loginId: loginId,
      cifId: cif,
      productId: this.productId,
      subProductId: this.subProductId,
      userType: role,
      userBaseCurrency: this.fdForm.account?.currency,
    };
    // const key = 'vToxrzEiK9bgE1DKl7xp5ez7BF8Xxc55SdLP/NBsVPc=';
    // const encryptedAesKey = await this.rsaUtil.encryptAESKeyFromBase64(key);
    // const iv = '3+q21Bm2czSp/3nD';
    // const ENC_iv = await this.rsaUtil.encryptAESKeyFromBase64(iv);
    // const encrypted = await EncryptionDecryptionUtil.encryptJSON(
    //   payload,
    //   key,
    //   iv
    // );
    // const encrypted =
    // '64pOHUvsHWBqEYckxWFSgwg/s7gkly867cGejdt/XVkuLeobie6lRFCZZSXLqNMgojCWBwV14tv7unUcjJ47Z3evtI5Rfpo6WnsYoDbAeq78WMgKA8liQYWTXbDBiK/p8FXWE0hv1OEASTIPQgetsMkH+XbOmwnSCHJmGOEpTiI1QzHu44cSwAt6BSuI+pdslDKdmQ6Su1coEjq0GNRDYu9DQlJazOOrXvRwl8gA7BucWJFue6pvCs1BmJJ7ABLhtdVYHp0lmPqVaYvSEZKU/f644wuNuWCduorHM5KIdj4K7wSaLA0KJADGFJww5wr+W1fqjsVLR84JVXAub2bhnbGEWF2S2uPRjyrk1nT+hKDzo+jQrQh0pc2xbRyE/TxJgd2e1Nv8/ueBYlHnyQMAy67ih40BrhBbshYgfiNGSNs/YAteRWZAynZleSA4PjC08JhPN4GL3wa8+rRkfEVEofg3DS24LHnN/YRsPD/aHD+vBhauyKR1y+ziI62bkRHrC15W08uKtnptvAcbrk5C7iDbsfZM/iKmoclh1UBI7fpQ/yYEGo2P9C/LOaY2jSh2Fsy+G4Crc4eytLOkjBs2uJBFhGtEOccPiITmuIeZRftFlUU0/oRYLKFDILmmNWLLvETP+uUIvF+S9Br7TMVxg5Q3lxfwU+0DFVg=';
    // console.log(
    //   JSON.stringify(
    //     {
    //       key: key,
    //       iv: iv,
    //       payload: payload,
    //     },
    //     null,
    //     2
    //   )
    // );
    // console.log(
    //   JSON.stringify(
    //     {
    //       ENC_key: encryptedAesKey,
    //       ENC_payload: encrypted,
    //       ENC_IV: ENC_iv,
    //     },
    //     null,
    //     2
    //   )
    // );

    // console.log(
    //   JSON.stringify({
    //     enc_payload: encrypted,
    //     enc_key: encryptedAesKey,
    //   }),
    //   null,
    //   2
    // );
    // console.log(
    //   JSON.stringify({
    //     key: key,
    //     enc_key: encryptedAesKey,
    //   }, null, 2)
    // );

    // const decrypt = await EncryptionDecryptionUtil.decryptJSON(
    //   encrypted,
    //   key,
    //   iv
    // );
    // console.log('Decrypted:', JSON.stringify(decrypt,null,2));

    // console.log(JSON.stringify(payload, null, 2));
    // navigate or send to API
    this.router.navigate(['/deposits/review'], {
      state: payload,
    });
  }

  showToast(type: string, title: string, message: string) {
    this.toastType = type;
    this.toastTitle = title;
    this.toastMessage = message;
    this.toastHiding = false;
    this.toastVisible = true;
    setTimeout(() => {
      this.toastHiding = true;
      setTimeout(() => { this.toastVisible = false; }, 400);
    }, 5000);
  }

  closeToast() {
    this.toastHiding = true;
    setTimeout(() => { this.toastVisible = false; }, 400);
  }
}
