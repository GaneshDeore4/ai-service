import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { ApiService } from '../../../../core/services/api.service';
import { OtpModalComponent } from '../../../../shared/components/otp-modal/otp-modal.component';
import { AuthService } from '../../../../core/services/auth.service';
import { UserProfile } from '../../../../core/models/auth.models';
import { AccessService } from '../../../../core/services/access.service';
import { UserAccessProfile } from '../../../../core/models/access.models';
import { FixedDepositStateService } from '../../../../core/services/fixed-deposit-state.service';
import { ToastComponent } from '../../../../shared/components/toast/toast.component';
import { LoaderComponent } from '../../../../shared/components/loader/loader.component';

@Component({
  selector: 'app-review-fixed-deposit',
  templateUrl: './review-fixed-deposit.component.html',
  styleUrls: ['./review-fixed-deposit.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, OtpModalComponent, ToastComponent, LoaderComponent]
})
export class ReviewFixedDepositComponent {
  public isOtpOpen = false;
  public payload: any;
  public currentUser: UserProfile | null = null;
  public otpReference: string = '';

  // Loader state
  isLoading: boolean = false;

  // Toast state
  toastVisible: boolean = false;
  toastHiding: boolean = false;
  toastType: string = 'error';
  toastTitle: string = '';
  toastMessage: string = '';

  // Success modal state
  isSuccessModalOpen: boolean = false;
  successModalTitle: string = '';
  successModalMessage: string = '';

  constructor(
    private router: Router,
    private apiService: ApiService,
    private authService: AuthService,
    private stateService: FixedDepositStateService
  ) {
    // Try to get state from navigation first
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras.state) {
      this.payload = navigation.extras.state;
    } else {
      // Fallback to shared state service (handles refresh/back navigation)
      const storedData = this.stateService.getFormData();
      if (storedData && storedData.amount) {
        // Reconstruct payload from stored form data
        this.payload = {
          accountNumber: storedData.account?.accountNumber,
          currency: storedData.account?.currency || 'USD',
          amount: Number(storedData.amount),
          tenureYears: storedData.tenure.years,
          tenureMonths: storedData.tenure.months,
          tenureDays: storedData.tenure.days,
          interestFrequency: storedData.interestPayout,
          payoutType: storedData.payoutType,
          maturityInstruction: storedData.maturityInstruction,
          interestPayout: storedData.interestPayout,
          callableType: storedData.callableType,
          // Note: interestRate and maturityAmount might need recalculation or separate storage
          // For now, we assume they are passed via state if possible
        };
      }
    }

    this.authService.currentUser$.subscribe((user: UserProfile | null) => {
      this.currentUser = user;
    });
  }

  get tenureString(): string {
    if (!this.payload) return '';
    const parts = [];
    if (this.payload.tenureYears) parts.push(`${this.payload.tenureYears} Years`);
    if (this.payload.tenureMonths) parts.push(`${this.payload.tenureMonths} Months`);
    if (this.payload.tenureDays) parts.push(`${this.payload.tenureDays} Days`);
    return parts.join(', ');
  }

  public toWords(num: any, currency: string = 'USD'): string {
    if (num === null || num === undefined || num === '') return '';

    const amount = Number(num);
    if (isNaN(amount)) return '';

    const mainPart = Math.floor(amount);
    const fractionalPart = Math.round((amount - mainPart) * 100);

    let result = this.numberToWords(mainPart) + ' ' + currency;

    if (fractionalPart > 0) {
      const fractionalUnit = this.getFractionalUnit(currency);
      result += ' AND ' + this.numberToWords(fractionalPart) + ' ' + fractionalUnit;
    }

    return (result + ' ONLY').toUpperCase();
  }

  private getFractionalUnit(currency: string): string {
    switch (currency.toUpperCase()) {
      case 'INR': return 'PAISE';
      case 'GBP': return 'PENCE';
      case 'EUR': return 'CENTS';
      case 'USD': return 'CENTS';
      default: return 'CENTS';
    }
  }

  private numberToWords(num: number): string {
    const a = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    const b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

    if (num === 0) return 'zero';
    if (num < 20) return a[num];
    if (num < 100) return b[Math.floor(num / 10)] + (num % 10 !== 0 ? ' ' + a[num % 10] : '');
    if (num < 1000) return a[Math.floor(num / 100)] + ' hundred' + (num % 100 !== 0 ? ' and ' + this.numberToWords(num % 100) : '');
    if (num < 1000000) return this.numberToWords(Math.floor(num / 1000)) + ' thousand' + (num % 1000 !== 0 ? ' ' + this.numberToWords(num % 1000) : '');
    if (num < 1000000000) return this.numberToWords(Math.floor(num / 1000000)) + ' million' + (num % 1000000 !== 0 ? ' ' + this.numberToWords(num % 1000000) : '');
    return 'very large number';
  }

  public sendOtp() {
    this.isOtpOpen = true;
    const payload = {
      loginId: this.currentUser?.loginId,
      companyCifId: this.currentUser?.cif
    }
    this.apiService.sendOtp(payload).subscribe({
      next: (res: any) => {
        console.log(res);
        if (res == 'SUCCESS') {
          this.otpReference = res.otpReference;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err: any) => {
        console.error(err);
      }
    });
  }

  public onOtpResend() {
    const payload = {
      loginId: this.currentUser?.loginId,
      companyCifId: this.currentUser?.cif,
      otpReference: this.otpReference
    }
    this.apiService.resendOtp(payload).subscribe({
      next: (res) => {
        if (res && res.responseCode === '00') {
          this.otpReference = res.otpReference;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }


  validateOtp(otp: string) {
    // const payload = {
    //   loginId: this.currentUser?.loginId,
    //   companyCifId: this.currentUser?.cif,
    //   otp: otp,
    //   otpReference: this.otpReference
    // };

    // this.apiService.confirmUserOtp(payload).subscribe({
    //   next: (res: any) => {
    //     if (res && (res.responseCode === '00' || res.status === 'SUCCESS')) {
    //       this.onOtpVerify();
    //     } else {
    //       alert('Invalid OTP. Please try again.');
    //     }
    //   },
    //   error: (err: any) => {
    //     alert('OTP Verification Failed: ' + err.message);
    //     console.error(err);
    //   }
    // });

    this.onOtpVerify();
  }

  public onOtpVerify() {
    this.isOtpOpen = false;
    if (this.payload) {
      console.log('>>>> FINAL FD CREATION PAYLOAD:', JSON.stringify(this.payload, null, 2));
      this.isLoading = true;
      this.apiService.createfd(this.payload).subscribe({
        next: (res: any) => {
          this.isLoading = false;
          if (res.status == 'SUCCESS') {
            // alert('SUCCESS: Fixed Deposit Initiated.'); // replaced by success modal
            this.otpReference = '';
            this.stateService.clearFormData();
            this.showSuccessModal('Fixed Deposit Initiated', 'Your Fixed Deposit has been initiated and sent for approval.');
          } else {
            // alert('FAILED: Could not create Fixed Deposit.\nReason: ' + (res.description || 'System Error')); // replaced by toast
            this.otpReference = '';
            this.stateService.clearFormData();
            this.showToast('error', 'Fixed Deposit Failed', 'Could not create Fixed Deposit. Reason: ' + (res.description || 'System Error'));
          }
        },
        error: (err: any) => {
          this.isLoading = false;
          // alert('FAILED: The API encountered an error creating the Fixed Deposit.\nError: ' + err.message); // replaced by toast
          this.otpReference = '';
          this.stateService.clearFormData();
          this.showToast('error', 'API Error', 'An error occurred while creating the Fixed Deposit. Please try again.');
          console.error(err);
        }
      });
    } else {
      this.otpReference = '';
      this.stateService.clearFormData();
      this.router.navigate(['/deposits']);
    }
  }

  showToast(type: string, title: string, message: string) {
    this.toastType = type;
    this.toastTitle = title;
    this.toastMessage = message;
    this.toastHiding = false;
    this.toastVisible = true;
    setTimeout(() => {
      this.toastHiding = true;
      setTimeout(() => { this.toastVisible = false; }, 400);
    }, 5000);
  }

  closeToast() {
    this.toastHiding = true;
    setTimeout(() => { this.toastVisible = false; }, 400);
  }

  showSuccessModal(title: string, message: string) {
    this.successModalTitle = title;
    this.successModalMessage = message;
    this.isSuccessModalOpen = true;
  }

  onSuccessModalClose() {
    this.isSuccessModalOpen = false;
    this.router.navigate(['/deposits']);
  }

  goBack() {
    this.router.navigate(['/deposits/open'], { state: { fromReview: true, ...this.payload } });
  }

}
