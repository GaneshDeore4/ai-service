package com.indusind.trade.fd.repository;

import com.indusind.trade.fd.dto.FixedDepositDto;
import com.indusind.trade.fd.entity.ApprovalAudit;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.model.dtos.projection.MidOfficeCountProjection;
import com.indusind.trade.model.utility.HashUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FixedDepositRepository extends JpaRepository<FixedDeposit, Long> {
    //List<FixedDeposit> findByCifId(String cifId);
    Optional<FixedDeposit> findByStateId(String stateId);

    Page<FixedDeposit> findByMakerId(Long makerId, Pageable pageable);

    Page<FixedDeposit> findByCifIdHash(String cifId, Pageable pageable);

    default Page<FixedDeposit> findByCifId(String cifId, Pageable pageable){
        return findByCifIdHash(HashUtils.HAMCMD5Hash(cifId), pageable);
    }

    @Query("""
        SELECT 
            SUM(CASE WHEN f.status = 'PENDING_AT_MID_OFFICE' THEN 1 ELSE 0 END) as pendingAtBank,
            SUM(CASE WHEN f.status IN ('IN_APPROVAL','REJECTED', 'MID_OFFICE_REJECTED') THEN 1 ELSE 0 END) As pendingAtClient,
            SUM(CASE WHEN f.status = 'MID_OFFICE_APPROVED' AND f.isMidOfficeApproved = true THEN 1 ELSE 0 END) As processedByBank,
            SUM(CASE WHEN f.status = 'APPROVED' AND (f.isMidOfficeApproved = false OR f.isMidOfficeApproved IS NULL) THEN 1 ELSE 0 END) As processedByClient
        FROM FixedDeposit f
        """)
    MidOfficeCountProjection getMidOfficeCounts();


    Page<FixedDeposit> findAllByStatusIn(List<String> status, Pageable page);

    Page<FixedDeposit> findByCifIdHashAndStatusIn(String cifId, List<String> status, Pageable page);

    default Page<FixedDeposit> findByCifIdAndStatusIn(String cifId, List<String> status, Pageable page) {
        return findByCifIdHashAndStatusIn(HashUtils.HAMCMD5Hash(cifId), status, page);
    }

}
