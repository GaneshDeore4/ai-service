package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.dto.*;
import com.indusind.trade.fd.entity.*;
import com.indusind.trade.fd.enums.*;
import com.indusind.trade.fd.repository.ApprovalAuditRepository;
import com.indusind.trade.fd.repository.FDAssignmentRepository;
import com.indusind.trade.fd.repository.CloseFixedDepositRepository;
import com.indusind.trade.fd.service.CloseFDService;
import com.indusind.trade.fd.service.FDWithdrawalService;
import com.indusind.trade.model.entities.company.AuthLevel;
import com.indusind.trade.model.entities.company.AuthMatrix;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.AuthLevelDao;
import com.indusind.trade.model.repository.AuthMatrixDao;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CloseFDServiceImpl implements CloseFDService {

    private final AuthMatrixDao matrixRepo;
    //private final AuthLevelDao levelRepo;
    private final CloseFixedDepositRepository clsFD;
    private final FDAssignmentRepository assignmentRepo;
    private final ApprovalAuditRepository auditRepo;
    private final FDWithdrawalService withdrawalService;

    @Override
    public void closeFD(CloseFDDto fd) {
        System.out.println("Inside closeFD");
        fd.setStatus(FDStatus.IN_APPROVAL);
        fd.setCurrentLevel(0);
        fd.setAuthMatrixId(null);
        fd.setCreatedAt(LocalDateTime.now());
        fd.setUpdatedAt(LocalDateTime.now());
        double fdAmount = fd.getAmount();

        List<AuthMatrix> matrices =
                matrixRepo.findMatrices(
                        fd.getCifId(),
                        fd.getProductId(),
                        fd.getSubProductId(),
                        fdAmount,
                        fd.getCurrency(),
                        fd.getFdAccountNumber()
                );
        if (Objects.isNull(matrices) || CollectionUtils.isEmpty(matrices)) {
            throw new GTPAppException("Unable to process request as No auth matrix found for FD data FD Amount, User Base Currency or Accout Number. Please contact administrator", null);
        }


        CloseFixedDeposit entity= CloseFDDto.convertToEntity(fd);

        clsFD.saveAndFlush(entity);
        List<FDAssignment> assignments = new ArrayList<>();
        for (AuthMatrix m : matrices) {
            int offset = 0;
            //Verifier
            if (Boolean.TRUE.equals(m.getIsVerifier())) {
                FDAssignment v = new FDAssignment();

                v.setFdId(entity.getId());
                v.setAuthMatrixId(m.getId());
                v.setNodeType(NodeType.VERIFIER);
                v.setAssignmentType(AssignmentType.ROLE);
                v.setUserType("Client Verifier");
                v.setLevel(0);
                v.setIsSequential(m.getIsSequential());
                v.setStatus(AssignmentStatus.PENDING);
                v.setIsActive(true);
                v.setClosureFlag("Y");
                assignments.add(v);
                offset = 1;
            }
            for (AuthLevel level : m.getAuthLevels()) {
                FDAssignment a = new FDAssignment();
                a.setFdId(entity.getId());
                a.setAuthMatrixId(m.getId());
                a.setNodeType(NodeType.APPROVER);
                a.setAssignmentType(AssignmentType.GROUP);
                a.setGroupId(level.getAuthGroup().getId());
                a.setGroupName(level.getAuthGroup().getAuthGroup());
                int nodeLevel = level.getSeqNo() + offset;
                a.setLevel(nodeLevel);
                a.setIsSequential(m.getIsSequential());
                a.setClosureFlag("Y");
                // Sequential logic
                if (Boolean.TRUE.equals(m.getIsSequential())) {
                    if (nodeLevel == 0) {
                        a.setStatus(AssignmentStatus.PENDING);
                        a.setIsActive(true);
                    } else {
                        a.setStatus(AssignmentStatus.WAITING);
                        a.setIsActive(false);
                    }
                }
                //  Non-sequential logic
                else {
                    a.setClosureFlag("Y");
                    if (offset == 1) {
                        a.setStatus(AssignmentStatus.WAITING);
                        a.setIsActive(false);
                    } else {
                        a.setStatus(AssignmentStatus.PENDING);
                        a.setIsActive(true);
                    }
                }
                assignments.add(a);
            }
            // RELEASER
            if (Boolean.TRUE.equals(m.getIsReleaser())) {
                int maxLevel = m.getAuthLevels().stream()
                        .mapToInt(AuthLevel::getSeqNo)
                        .max()
                        .orElse(0);
                FDAssignment r = new FDAssignment();
                r.setFdId(entity.getId());
                r.setAuthMatrixId(m.getId());
                r.setNodeType(NodeType.RELEASER);
                r.setAssignmentType(AssignmentType.ROLE);
                r.setUserType("Client Releaser");
                int releaserLevel = maxLevel + offset + 1;
                r.setLevel(releaserLevel);
                r.setIsSequential(m.getIsSequential());
                r.setStatus(AssignmentStatus.WAITING);
                r.setIsActive(false);
                r.setClosureFlag("Y");
                assignments.add(r);
            }
        }
        assignmentRepo.saveAll(assignments);
      /*  if (fd.isReopend()) {
            audit(entity, fd.getUserId(), fd.getLoginId(), fd.getUserName(), null, 0, ActionType.REOPENED);
        } else {
            audit(entity, fd.getUserId(), fd.getLoginId(), fd.getUserName(), null, 0, ActionType.CREATED);
        }*/
    }

    private void executeFDClosureRequest(CloseFixedDeposit fd) {

        withdrawalService.initiateFullWithdrawal(fd.getFdAccountNumber(),fd.getRepaymentAccount(),fd.getAmount());
    }

    @Override
    public void approve(Long fdId,
                        Long userId,
                        String loginId,
                        String userName,
                        Long groupId,
                        String groupName,
                        String roleName,
                        boolean midOffice) {

        CloseFixedDeposit fd = clsFD.findById(fdId)
                .orElseThrow(() -> new RuntimeException("FD not found"));
        List<FDAssignment> all = assignmentRepo.findByFdId(fdId);
        List<FDAssignment> actionable = all.stream()
                .filter(FDAssignment::getIsActive)
                .filter(a -> match(a, groupId, roleName))
                .toList();
        if (actionable.isEmpty()) {
            throw new RuntimeException("No actionable node");
        }
        for (FDAssignment a : actionable) {
            if (a.getStatus() != AssignmentStatus.PENDING) {
                throw new RuntimeException("Invalid state");
            }
            a.setStatus(AssignmentStatus.APPROVED);
            a.setIsActive(false);
        }
        recompute(all, fd, midOffice);
        assignmentRepo.saveAll(all);
        fd.setUpdatedAt(LocalDateTime.now());
        clsFD.save(fd);
        if (Objects.nonNull(roleName) && Arrays.asList("Client Verifier", "Client Releaser").contains(roleName)) {
            groupName = roleName;
        }
        audit(fd, userId, loginId, userName, groupId, groupName, fd.getCurrentLevel(), ActionType.APPROVED);
        if (fd.getStatus().equals(FDStatus.APPROVED)) {
            audit(fd, userId, loginId, userName, groupId, groupName, fd.getCurrentLevel(), ActionType.FD_APPROVED);
            executeFDClosureRequest(fd);
        }
    }

    @Override
    public void reject(Long fdId, Long userId, String loginId, String userName, Long groupId, String reason) {

    }

    @Override
    public void reopen(FixedDepositDto updated) {

    }


    public Page<MakerTrayDTO> getMakerTray(Long makerId, Pageable pageable) {
        return clsFD.findByMakerId(makerId, pageable)
                .map(fd -> new MakerTrayDTO(
                        fd.getId(),
                        fd.getAmount(),
                        fd.getStatus(),
                        fd.getRejectReason()
                ));
    }

    @Override
    public Page<CheckerFDTrayDTO> getCheckerTray(Long userId, Long groupId, Pageable pageable) {
        return assignmentRepo.findCheckerTray(userId, groupId, pageable)
                .map(CheckerFDTrayDTO::convertToDto);
    }

   /* @Override
    public Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTray(Long userId, String roleName, Pageable pageable) {
        return assignmentRepo.findReleaserOrVerifierTray(userId, roleName, pageable)
                .map(CheckerFDTrayDTO::convertToDto);
    }*/

    @Override
    public void approveFdMidOffice(Long fdId, Long midOfficeId, String midOfficeLoginId, String midOfficeUserName) {

        CloseFixedDeposit fd = clsFD.findById(fdId).orElseThrow();
        if (fd.getStatus() != FDStatus.PENDING_AT_MID_OFFICE) {
            throw new GTPAppException("Only Pending at Mid Office status can be approved", null);
        }
        fd.setStatus(FDStatus.MID_OFFICE_APPROVED);
        fd.setIsMidOfficeApproved(true);
        audit(fd, midOfficeId, midOfficeLoginId, midOfficeUserName, null, "Mid Office", null, ActionType.MID_OFFICE_APPROVED);
        clsFD.saveAndFlush(fd);
    }

    @Override
    public void rejectFdMidOffice(Long fdId, Long midOfficeId, String midOfficeLoginId, String midOfficeUserName) {

    }

    private void recompute(List<FDAssignment> all,
                           CloseFixedDeposit fd,
                           boolean midOffice) {
        Map<Long, List<FDAssignment>> pathMap =
                all.stream().collect(Collectors.groupingBy(FDAssignment::getAuthMatrixId));
        //  Releaser short-circuit
        if (handleReleaserCompletion(all, fd, midOffice)) return;
        // Reset state
        for (FDAssignment a : all) {
            if (a.getStatus() != AssignmentStatus.APPROVED) {
                a.setStatus(AssignmentStatus.WAITING);
                a.setIsActive(false);
            }
        }
        boolean verifierApproved = isVerifierApproved(all);
        boolean approverActed = isApproverActed(all);
        // VERIFIER / APPROVER-FIRST DECISION
        // CASE 1: Approver acted first → skip verifier
        if (approverActed && !verifierApproved) {
            for (List<FDAssignment> path : pathMap.values()) {
                boolean hasVerifier = path.stream()
                        .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER);
                if (hasVerifier) {
                    killPath(path);
                }
            }
        }
        // CASE 2: Verifier not yet approved → only verifier active
        else if (!verifierApproved) {
            for (List<FDAssignment> path : pathMap.values()) {
                path.stream()
                        .filter(n -> n.getNodeType() == NodeType.VERIFIER)
                        .forEach(n -> {
                            n.setStatus(AssignmentStatus.PENDING);
                            n.setIsActive(true);
                        });
            }
            return;
        }
        // CASE 3: Verifier completed → filter once
        else {
            applyPostVerifierFilter(pathMap);
        }

        // PARALLEL EXECUTION
        for (List<FDAssignment> path : pathMap.values()) {
            if (isKilled(path)) continue;
            boolean isSequential = path.stream()
                    .anyMatch(FDAssignment::getIsSequential);
            if (isSequential) {
                processSequential(path);
            } else {
                processNonSequential(path);
            }
        }
        // SEQUENTIAL DIVERGENCE
        applySequentialDivergence(pathMap);
        // RELEASER ACTIVATION
        activateReleasers(pathMap);
        // CONVERGENCE
        applyConvergence(pathMap);
        // FINALIZE
        finalizeFD(fd, pathMap, midOffice);
    }

    @Override
    public Page<FdActionAuditsDto> getFDAuditsByFdId(Long fdId, Pageable page) {
        return null;
    }

    private boolean isVerifierApproved(List<FDAssignment> all) {
        return all.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER
                        && n.getStatus() == AssignmentStatus.APPROVED);
    }

    private boolean isApproverActed(List<FDAssignment> all) {
        return all.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                        && n.getStatus() == AssignmentStatus.APPROVED);
    }

    private void applyPostVerifierFilter(Map<Long, List<FDAssignment>> pathMap) {
        for (List<FDAssignment> path : pathMap.values()) {
            boolean hasVerifier = path.stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER);
            if (!hasVerifier) {
                killPath(path);
            }
        }
    }

    private void processSequential(List<FDAssignment> path) {
        path.stream()
                .filter(n -> n.getNodeType() == NodeType.APPROVER)
                .filter(n -> n.getStatus() != AssignmentStatus.APPROVED)
                .min(Comparator.comparing(FDAssignment::getLevel))
                .ifPresent(n -> {
                    n.setStatus(AssignmentStatus.PENDING);
                    n.setIsActive(true);
                });
    }

    private void processNonSequential(List<FDAssignment> path) {
        boolean anyApproved = path.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                        && n.getStatus() == AssignmentStatus.APPROVED);
        if (anyApproved) return;
        for (FDAssignment n : path) {
            if (n.getNodeType() == NodeType.APPROVER) {
                n.setStatus(AssignmentStatus.PENDING);
                n.setIsActive(true);
            }
        }
    }

    private void applySequentialDivergence(Map<Long, List<FDAssignment>> pathMap) {
        List<List<FDAssignment>> seqPaths = pathMap.values().stream()
                .filter(p -> p.stream().anyMatch(FDAssignment::getIsSequential))
                .toList();
        if (seqPaths.size() <= 1) return;
        Integer divergenceLevel = null;
        Set<Integer> levels = seqPaths.stream()
                .flatMap(p -> p.stream())
                .map(FDAssignment::getLevel)
                .collect(Collectors.toSet());
        for (Integer level : levels.stream().sorted().toList()) {
            Set<Long> groups = new HashSet<>();
            for (List<FDAssignment> path : seqPaths) {
                path.stream()
                        .filter(n -> level.equals(n.getLevel()))
                        .findFirst()
                        .ifPresent(n -> groups.add(n.getGroupId()));
            }
            if (groups.size() > 1) {
                divergenceLevel = level;
                break;
            }
        }
        if (divergenceLevel == null) return;
        Long selectedGroup = null;
        for (List<FDAssignment> path : seqPaths) {
            for (FDAssignment n : path) {
                if (divergenceLevel.equals(n.getLevel())
                        && n.getStatus() == AssignmentStatus.APPROVED) {
                    selectedGroup = n.getGroupId();
                }
            }
        }
        if (selectedGroup == null) return;
        for (List<FDAssignment> path : seqPaths) {
            Integer finalDivergenceLevel = divergenceLevel;
            Long finalSelectedGroup = selectedGroup;
            boolean match = path.stream()
                    .anyMatch(n -> finalDivergenceLevel.equals(n.getLevel())
                            && finalSelectedGroup.equals(n.getGroupId()));
            if (!match) killPath(path);
        }
    }

    private void activateReleasers(Map<Long, List<FDAssignment>> pathMap) {
        for (List<FDAssignment> path : pathMap.values()) {
            Optional<FDAssignment> r = path.stream()
                    .filter(n -> n.getNodeType() == NodeType.RELEASER)
                    .findFirst();
            if (r.isEmpty()) continue;
            boolean isSequential = path.stream()
                    .anyMatch(FDAssignment::getIsSequential);
            if (isSequential) {
                boolean done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
                if (done) {
                    r.get().setStatus(AssignmentStatus.PENDING);
                    r.get().setIsActive(true);
                }
            } else {
                boolean any = path.stream()
                        .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                                && n.getStatus() == AssignmentStatus.APPROVED);
                if (any) {
                    r.get().setStatus(AssignmentStatus.PENDING);
                    r.get().setIsActive(true);
                }
            }
        }
    }

    private void applyConvergence(Map<Long, List<FDAssignment>> pathMap) {
        Long winner = null;
        for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
            boolean nonSeq = e.getValue().stream()
                    .anyMatch(n -> !n.getIsSequential());
            if (!nonSeq) continue;
            boolean approved = e.getValue().stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                            && n.getStatus() == AssignmentStatus.APPROVED);
            if (approved) {
                winner = e.getKey();
                break;
            }
        }
        if (winner == null) {
            for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
                boolean seq = e.getValue().stream()
                        .anyMatch(FDAssignment::getIsSequential);
                if (!seq) continue;
                boolean done = e.getValue().stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
                if (done) {
                    winner = e.getKey();
                    break;
                }
            }
        }
        if (winner != null) {
            for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
                if (!e.getKey().equals(winner)) {
                    killPath(e.getValue());
                }
            }
        }
    }

    private void finalizeFD(CloseFixedDeposit fd,
                            Map<Long, List<FDAssignment>> pathMap,
                            boolean midOffice) {
        for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
            List<FDAssignment> path = e.getValue();
            boolean hasReleaser = path.stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.RELEASER);
            boolean done;
            if (hasReleaser) {
                done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.RELEASER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
            } else {
                done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
            }
            if (done) {
                fd.setAuthMatrixId(e.getKey());
                fd.setStatus(midOffice
                        ? FDStatus.PENDING_AT_MID_OFFICE
                        : FDStatus.APPROVED);
                return;
            }
        }
    }

    private boolean handleReleaserCompletion(List<FDAssignment> all,
                                             CloseFixedDeposit fd,
                                             boolean midOffice) {
        Optional<FDAssignment> r = all.stream()
                .filter(n -> n.getNodeType() == NodeType.RELEASER)
                .filter(n -> n.getStatus() == AssignmentStatus.APPROVED)
                .findFirst();
        if (r.isEmpty()) return false;
        Long pathId = r.get().getAuthMatrixId();
        fd.setAuthMatrixId(pathId);
        fd.setStatus(midOffice
                ? FDStatus.PENDING_AT_MID_OFFICE
                : FDStatus.APPROVED);
        for (FDAssignment n : all) {
            if (!n.getAuthMatrixId().equals(pathId)
                    && n.getStatus() != AssignmentStatus.APPROVED) {
                n.setStatus(AssignmentStatus.VIEW_ONLY);
                n.setIsActive(false);
            }
        }
        return true;
    }

    private void killPath(List<FDAssignment> path) {
        for (FDAssignment n : path) {
            if (n.getStatus() != AssignmentStatus.APPROVED) {
                n.setStatus(AssignmentStatus.VIEW_ONLY);
                n.setIsActive(false);
            }
        }
    }

    private boolean isKilled(List<FDAssignment> path) {
        return path.stream()
                .allMatch(n -> n.getStatus() == AssignmentStatus.VIEW_ONLY);
    }

    private boolean match(FDAssignment a,
                          Long groupId,
                          String roleName) {
        if (a.getAssignmentType() == AssignmentType.GROUP) {
            return groupId != null && groupId.equals(a.getGroupId());
        }
        if (a.getAssignmentType() == AssignmentType.ROLE) {
            return roleName != null && roleName.equals(a.getUserType());
        }
        return false;
    }

    private void audit(CloseFixedDeposit fd,
                       Long userId,
                       String loginId,
                       String userName,
                       Long groupId,
                       String groupName,
                       Integer level,
                       ActionType action) {
        ApprovalAudit a = new ApprovalAudit();
        a.setFdId(fd.getId());
        a.setLoginId(loginId);
        a.setUserId(userId);
        a.setGroupId(groupId);
        a.setGroupName(groupName);
        a.setUserName(userName);
        a.setLevel(level);
        a.setAction(action);
        a.setTimestamp(LocalDateTime.now());
        auditRepo.save(a);
    }


}

