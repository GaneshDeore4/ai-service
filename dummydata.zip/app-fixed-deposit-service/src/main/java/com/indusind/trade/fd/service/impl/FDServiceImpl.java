package com.indusind.trade.fd.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.app.jose.constant.InputType;
import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import com.indusind.app.jose.operations.JoseHelper;
import com.indusind.app.jose.operations.JoseUtility;
import com.indusind.trade.fd.client.FetchFDAccountFeignClient;
import com.indusind.trade.fd.dto.*;
import com.indusind.trade.fd.dto.response_wrapper.ResponseWrapper;
import com.indusind.trade.fd.entity.ApprovalAudit;
import com.indusind.trade.fd.entity.CloseFixedDeposit;
import com.indusind.trade.fd.entity.FDAssignment;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.enums.*;
import com.indusind.trade.fd.projection.CheckerTrayProjection;
import com.indusind.trade.fd.repository.ApprovalAuditRepository;
import com.indusind.trade.fd.repository.CloseFixedDepositRepository;
import com.indusind.trade.fd.repository.FDAssignmentRepository;
import com.indusind.trade.fd.repository.FixedDepositRepository;
import com.indusind.trade.fd.service.CreateFDService;
import com.indusind.trade.fd.service.FDService;
import com.indusind.trade.fd.service.FDWithdrawalService;
import com.indusind.trade.model.dtos.projection.MidOfficeCountProjection;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import com.indusind.trade.model.entities.company.AuthLevel;
import com.indusind.trade.model.entities.company.AuthMatrix;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.AuthLevelDao;
import com.indusind.trade.model.repository.AuthMatrixDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class FDServiceImpl implements FDService {

//    private static final Logger log = LoggerFactory.getLogger(FDServiceImpl.class);

    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    private final FixedDepositRepository fdRepo;
    private final AuthMatrixDao matrixRepo;
    private final AuthLevelDao levelRepo;
    private final FDAssignmentRepository assignmentRepo;
    private final ApprovalAuditRepository auditRepo;
    private final CreateFDService createFDService;
    private final CloseFixedDepositRepository clsFD;
    private final FDWithdrawalService withdrawalService;
    private final JoseHelper joseHelper;
    private final ObjectMapper objectMapper;

    private final FetchFDAccountFeignClient fetchFDAccountFeignClient;


    @Transactional
    @Override
    public void createFD(FixedDepositDto fd) {
        fd.setStatus(FDStatus.IN_APPROVAL);
        fd.setCurrentLevel(0);
        fd.setAuthMatrixId(null);
        double fdAmount = fd.getAmount();
//        if (!fd.getCurrency().equals(fd.getUserBaseCurrency())) {
//            fdAmount = fd.getAmount() *
//                    getExchangeRateByCurrency(fd.getCurrency(), fd.getUserBaseCurrency());
//        }

        List<AuthMatrix> matrices =
                matrixRepo.findMatrices(
                        fd.getCifId(),
                        fd.getProductId(),
                        fd.getSubProductId(),
                        fdAmount,
                        fd.getCurrency(),
                        fd.getAccountNumber()
                );
        if (Objects.isNull(matrices) || CollectionUtils.isEmpty(matrices)) {
            throw new GTPAppException("Unable to create FD as No auth matrix found for FD data FD Amount, User Base Currency or Accout Number. Please contact administrator", null);
        }

        FixedDeposit entity = FixedDepositDto.convertToEntity(fd);
        fdRepo.saveAndFlush(entity);
        List<FDAssignment> assignments = new ArrayList<>();
        for (AuthMatrix m : matrices) {
            int offset = 0;
            //Verifier
            if (Boolean.TRUE.equals(m.getIsVerifier())) {
                FDAssignment v = new FDAssignment();
                v.setFdId(entity.getId());
                v.setAuthMatrixId(m.getId());
                v.setNodeType(NodeType.VERIFIER);
                v.setAssignmentType(AssignmentType.ROLE);
                v.setUserType("Client Verifier");
                v.setGroupName("Client Verifier");
                v.setLevel(0);
                v.setIsSequential(m.getIsSequential());
                v.setStatus(AssignmentStatus.PENDING);
                v.setIsActive(true);
                v.setClosureFlag("N");
                assignments.add(v);
                offset = 1;
            }
            for (AuthLevel level : m.getAuthLevels()) {
                FDAssignment a = new FDAssignment();
                a.setFdId(entity.getId());
                a.setAuthMatrixId(m.getId());
                a.setNodeType(NodeType.APPROVER);
                a.setAssignmentType(AssignmentType.GROUP);
                a.setGroupId(level.getAuthGroup().getId());
                a.setGroupName(level.getAuthGroup().getAuthGroup());
                int nodeLevel = level.getSeqNo() + offset;
                a.setLevel(nodeLevel);
                a.setIsSequential(m.getIsSequential());
                a.setClosureFlag("N");
                // Sequential logic
                if (Boolean.TRUE.equals(m.getIsSequential())) {
                    if (nodeLevel == 0) {
                        a.setStatus(AssignmentStatus.PENDING);
                        a.setIsActive(true);
                    } else {
                        a.setStatus(AssignmentStatus.WAITING);
                        a.setIsActive(false);
                    }
                }
                //  Non-sequential logic
                else {
                    if (offset == 1) {
                        a.setStatus(AssignmentStatus.WAITING);
                        a.setIsActive(false);
                    } else {
                        a.setStatus(AssignmentStatus.PENDING);
                        a.setIsActive(true);
                    }
                }
                assignments.add(a);
            }
            // RELEASER
            if (Boolean.TRUE.equals(m.getIsReleaser())) {
                int maxLevel = m.getAuthLevels().stream()
                        .mapToInt(AuthLevel::getSeqNo)
                        .max()
                        .orElse(0);
                FDAssignment r = new FDAssignment();
                r.setFdId(entity.getId());
                r.setAuthMatrixId(m.getId());
                r.setNodeType(NodeType.RELEASER);
                r.setAssignmentType(AssignmentType.ROLE);
                r.setUserType("Client Releaser");
                r.setGroupName("Client Releaser");
                int releaserLevel = maxLevel + offset + 1;
                r.setLevel(releaserLevel);
                r.setIsSequential(m.getIsSequential());
                r.setStatus(AssignmentStatus.WAITING);
                r.setIsActive(false);
                r.setClosureFlag("N");
                assignments.add(r);
            }
        }
        assignmentRepo.saveAll(assignments);
        if (fd.isReopend()) {
            audit(entity, fd.getUserId(), fd.getLoginId(), fd.getUserName(), null, "Client Maker", 0, ActionType.REOPENED);
        } else {
            audit(entity, fd.getUserId(), fd.getLoginId(), fd.getUserName(), null, "Client Maker", 0, ActionType.CREATED);
        }
    }

    private Double getExchangeRateByCurrency(String currency, String userBaseCurrency) {
        return 100.0;
    }

    @Transactional
    @Override
    public void approve(Long fdId,
                        Long userId,
                        String loginId,
                        String userName,
                        Long groupId,
                        String groupName,
                        String roleName,
                        boolean midOffice) {
        System.out.println("Inside approve");
        System.out.println("FD ID=" +fdId);
        System.out.println("User ID=" +userId);
        System.out.println("Login ID=" +loginId);
        System.out.println("User Name=" +userName);
        System.out.println("Group ID=" +groupId);
        System.out.println("Role Name=" +roleName);
        System.out.println("MID Office Flag=" +midOffice);
        /*FixedDeposit fd = fdRepo.findById(fdId)
                .orElseThrow(() -> new RuntimeException("FD not found"));*/
        FixedDeposit fd = fdRepo.findById(fdId).orElseGet(() -> {
            CloseFixedDeposit cls = clsFD.findById(fdId)
                    .orElseThrow(() -> new RuntimeException("Fixed Deposit record not found for ID: " + fdId));
            FixedDeposit shadow = new FixedDeposit();
            shadow.setId(cls.getId());
            shadow.setAuthMatrixId(cls.getAuthMatrixId());
            shadow.setCurrentLevel(cls.getCurrentLevel());

            if (cls.getStatus() != null) {
                shadow.setStatus(FDStatus.valueOf(String.valueOf(cls.getStatus())));
            }
            return shadow;
        });
        List<FDAssignment> all = assignmentRepo.findByFdId(fdId);
        List<FDAssignment> actionable = all.stream()
                .filter(FDAssignment::getIsActive)
                .filter(a -> match(a, groupId, roleName))
                .toList();

        if (actionable.isEmpty()) {
            throw new RuntimeException("No actionable node");
        }

        for (FDAssignment a : actionable) {
            if (a.getStatus() != AssignmentStatus.PENDING) {
                throw new RuntimeException("Invalid state");
            }
            a.setStatus(AssignmentStatus.APPROVED);
            a.setIsActive(false);
        }
        recompute(all, fd, midOffice);
        assignmentRepo.saveAll(all);




        if (actionable.get(0).getClosureFlag() != null && actionable.get(0).getClosureFlag().equalsIgnoreCase("Y")) {
            CloseFixedDeposit closureEntity = clsFD.findById(fdId)
                    .orElseThrow(() -> new GTPAppException("Closure record not found during approval synchronization", null));

            // Sync updated workflow state from the shadow object back to the closure entity
            closureEntity.setStatus(fd.getStatus());
            closureEntity.setCurrentLevel(fd.getCurrentLevel());
            closureEntity.setAuthMatrixId(fd.getAuthMatrixId());
            clsFD.save(closureEntity);
        } else {
            System.out.println("Inside FD Repo Save");
            fdRepo.save(fd);
        }
        if (Objects.nonNull(roleName) && Arrays.asList("Client Verifier", "Client Releaser").contains(roleName)) {
            groupName = roleName;
        }
        System.out.println("Before Audit");
        System.out.println("FD Status=" +fd.getStatus());

        audit(fd, userId, loginId, userName, groupId, groupName, fd.getCurrentLevel(), ActionType.APPROVED);
        if (fd.getStatus().equals(FDStatus.APPROVED)) {
            System.out.println("Inside FD Status is approved");
            audit(fd, userId, loginId, userName, groupId, groupName, fd.getCurrentLevel(), ActionType.FD_APPROVED);
            if (actionable.get(0).getClosureFlag() != null && actionable.get(0).getClosureFlag().equalsIgnoreCase("Y")) {
                CloseFixedDeposit closureEntity = clsFD.findById(fdId)
                        .orElseThrow(() -> new GTPAppException("Closure record not found during approval synchronization", null));

                System.out.println("Inside FD Closure Request" );
                System.out.println("Entity Value="  +closureEntity);
                executeFDClosureRequest(closureEntity.getFdAccountNumber(), closureEntity.getRepaymentAccount(), closureEntity.getAmount());
            }
            if (actionable.get(0).getClosureFlag() != null && actionable.get(0).getClosureFlag().equalsIgnoreCase("N")) {

                callFinacleFDCreationService(fd);
            }


        }

    }

    private void callFinacleFDCreationService(FixedDeposit fd) {
        System.out.println("Inside callFinacleFDCreationService");
        ResponseWrapper resp = null;
        try {
            resp = createFDService.createFD(fd);
            fd.setFinacleStatus(FDFinacleStatus.SUCCESS);
            log.info("Finacle FD Creation failed for FD ID: " + fd.getId() + " Response: " + resp);

        } catch (Exception e) {
            fd.setFinacleStatus(FDFinacleStatus.FAILED_AT_FINACLE);
            audit(fd, null, null, "FINACLE", null, null, null, ActionType.FD_CREATED_AT_FINACLE_FAILED);

        } finally {
            if (Objects.nonNull(resp) && "success".equalsIgnoreCase(resp.getResponse().getStatus())) {
                fd.setFinacleStatus(FDFinacleStatus.CREATED_AT_FINACLE);
                audit(fd, null, null, "FINACLE", null, null, null, ActionType.FD_CREATED_AT_FINACLE);
            } else {
                fd.setFinacleStatus(FDFinacleStatus.FAILED_AT_FINACLE);
                audit(fd, null, null, "FINACLE", null, null, null, ActionType.FD_CREATED_AT_FINACLE_FAILED);

            }

        }
    }

    private void recompute(List<FDAssignment> all,
                           FixedDeposit fd,
                           boolean midOffice) {
        System.out.println("Inside recompute");
        System.out.println("FixedDeposit " +fd);
        Map<Long, List<FDAssignment>> pathMap =
                all.stream().collect(Collectors.groupingBy(FDAssignment::getAuthMatrixId));
        //  Releaser short-circuit
        if (handleReleaserCompletion(all, fd, midOffice)) return;
        // Reset state
        for (FDAssignment a : all) {
            if (a.getStatus() != AssignmentStatus.APPROVED) {
                a.setStatus(AssignmentStatus.WAITING);
                a.setIsActive(false);
            }
        }
        boolean verifierApproved = isVerifierApproved(all);
        boolean approverActed = isApproverActed(all);
        // VERIFIER / APPROVER-FIRST DECISION
        // CASE 1: Approver acted first → skip verifier
        if (approverActed && !verifierApproved) {
            for (List<FDAssignment> path : pathMap.values()) {
                boolean hasVerifier = path.stream()
                        .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER);
                if (hasVerifier) {
                    killPath(path);
                }
            }
        }
        // CASE 2: Verifier not yet approved → only verifier active
        else if (!verifierApproved) {
            for (List<FDAssignment> path : pathMap.values()) {
                path.stream()
                        .filter(n -> n.getNodeType() == NodeType.VERIFIER)
                        .forEach(n -> {
                            n.setStatus(AssignmentStatus.PENDING);
                            n.setIsActive(true);
                        });
            }
            return;
        }
        // CASE 3: Verifier completed → filter once
        else {
            applyPostVerifierFilter(pathMap);
        }

        // PARALLEL EXECUTION
        for (List<FDAssignment> path : pathMap.values()) {
            if (isKilled(path)) continue;
            boolean isSequential = path.stream()
                    .anyMatch(FDAssignment::getIsSequential);
            if (isSequential) {
                processSequential(path);
            } else {
                processNonSequential(path);
            }
        }
        // SEQUENTIAL DIVERGENCE
        applySequentialDivergence(pathMap);
        // RELEASER ACTIVATION
        activateReleasers(pathMap);
        // CONVERGENCE
        applyConvergence(pathMap);
        // FINALIZE
        finalizeFD(fd, pathMap, midOffice);
    }


    private boolean isVerifierApproved(List<FDAssignment> all) {
        return all.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER
                        && n.getStatus() == AssignmentStatus.APPROVED);
    }

    private boolean isApproverActed(List<FDAssignment> all) {
        return all.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                        && n.getStatus() == AssignmentStatus.APPROVED);
    }

    private void applyPostVerifierFilter(Map<Long, List<FDAssignment>> pathMap) {
        for (List<FDAssignment> path : pathMap.values()) {
            boolean hasVerifier = path.stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.VERIFIER);
            if (!hasVerifier) {
                killPath(path);
            }
        }
    }

    private void processSequential(List<FDAssignment> path) {
        path.stream()
                .filter(n -> n.getNodeType() == NodeType.APPROVER)
                .filter(n -> n.getStatus() != AssignmentStatus.APPROVED)
                .min(Comparator.comparing(FDAssignment::getLevel))
                .ifPresent(n -> {
                    n.setStatus(AssignmentStatus.PENDING);
                    n.setIsActive(true);
                });
    }

    private void processNonSequential(List<FDAssignment> path) {
        boolean anyApproved = path.stream()
                .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                        && n.getStatus() == AssignmentStatus.APPROVED);
        if (anyApproved) return;
        for (FDAssignment n : path) {
            if (n.getNodeType() == NodeType.APPROVER) {
                n.setStatus(AssignmentStatus.PENDING);
                n.setIsActive(true);
            }
        }
    }

    private void applySequentialDivergence(Map<Long, List<FDAssignment>> pathMap) {
        List<List<FDAssignment>> seqPaths = pathMap.values().stream()
                .filter(p -> p.stream().anyMatch(FDAssignment::getIsSequential))
                .toList();
        if (seqPaths.size() <= 1) return;
        Integer divergenceLevel = null;
        Set<Integer> levels = seqPaths.stream()
                .flatMap(p -> p.stream())
                .map(FDAssignment::getLevel)
                .collect(Collectors.toSet());
        for (Integer level : levels.stream().sorted().toList()) {
            Set<Long> groups = new HashSet<>();
            for (List<FDAssignment> path : seqPaths) {
                path.stream()
                        .filter(n -> level.equals(n.getLevel()))
                        .findFirst()
                        .ifPresent(n -> groups.add(n.getGroupId()));
            }
            if (groups.size() > 1) {
                divergenceLevel = level;
                break;
            }
        }
        if (divergenceLevel == null) return;
        Long selectedGroup = null;
        for (List<FDAssignment> path : seqPaths) {
            for (FDAssignment n : path) {
                if (divergenceLevel.equals(n.getLevel())
                        && n.getStatus() == AssignmentStatus.APPROVED) {
                    selectedGroup = n.getGroupId();
                }
            }
        }
        if (selectedGroup == null) return;
        for (List<FDAssignment> path : seqPaths) {
            Integer finalDivergenceLevel = divergenceLevel;
            Long finalSelectedGroup = selectedGroup;
            boolean match = path.stream()
                    .anyMatch(n -> finalDivergenceLevel.equals(n.getLevel())
                            && finalSelectedGroup.equals(n.getGroupId()));
            if (!match) killPath(path);
        }
    }

    private void activateReleasers(Map<Long, List<FDAssignment>> pathMap) {
        for (List<FDAssignment> path : pathMap.values()) {
            Optional<FDAssignment> r = path.stream()
                    .filter(n -> n.getNodeType() == NodeType.RELEASER)
                    .findFirst();
            if (r.isEmpty()) continue;
            boolean isSequential = path.stream()
                    .anyMatch(FDAssignment::getIsSequential);
            if (isSequential) {
                boolean done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
                if (done) {
                    r.get().setStatus(AssignmentStatus.PENDING);
                    r.get().setIsActive(true);
                }
            } else {
                boolean any = path.stream()
                        .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                                && n.getStatus() == AssignmentStatus.APPROVED);
                if (any) {
                    r.get().setStatus(AssignmentStatus.PENDING);
                    r.get().setIsActive(true);
                }
            }
        }
    }

    private void applyConvergence(Map<Long, List<FDAssignment>> pathMap) {
        Long winner = null;
        for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
            boolean nonSeq = e.getValue().stream()
                    .anyMatch(n -> !n.getIsSequential());
            if (!nonSeq) continue;
            boolean approved = e.getValue().stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.APPROVER
                            && n.getStatus() == AssignmentStatus.APPROVED);
            if (approved) {
                winner = e.getKey();
                break;
            }
        }
        if (winner == null) {
            for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
                boolean seq = e.getValue().stream()
                        .anyMatch(FDAssignment::getIsSequential);
                if (!seq) continue;
                boolean done = e.getValue().stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
                if (done) {
                    winner = e.getKey();
                    break;
                }
            }
        }
        if (winner != null) {
            for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
                if (!e.getKey().equals(winner)) {
                    killPath(e.getValue());
                }
            }
        }
    }

    private void finalizeFD(FixedDeposit fd,
                            Map<Long, List<FDAssignment>> pathMap,
                            boolean midOffice) {
        for (Map.Entry<Long, List<FDAssignment>> e : pathMap.entrySet()) {
            List<FDAssignment> path = e.getValue();
            boolean hasReleaser = path.stream()
                    .anyMatch(n -> n.getNodeType() == NodeType.RELEASER);
            boolean done;
            if (hasReleaser) {
                done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.RELEASER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
            } else {
                done = path.stream()
                        .filter(n -> n.getNodeType() == NodeType.APPROVER)
                        .allMatch(n -> n.getStatus() == AssignmentStatus.APPROVED);
            }
            if (done) {
                fd.setAuthMatrixId(e.getKey());
                fd.setStatus(midOffice
                        ? FDStatus.PENDING_AT_MID_OFFICE
                        : FDStatus.APPROVED);
                return;
            }
        }
    }

    private boolean handleReleaserCompletion(List<FDAssignment> all,
                                             FixedDeposit fd,
                                             boolean midOffice) {
        System.out.println("Inside handleReleaserCompletion");
        Optional<FDAssignment> r = all.stream()
                .filter(n -> n.getNodeType() == NodeType.RELEASER)
                .filter(n -> n.getStatus() == AssignmentStatus.APPROVED)
                .findFirst();
        System.out.println("Whether R is empty=" +r.isEmpty());
        if (r.isEmpty()) return false;
        Long pathId = r.get().getAuthMatrixId();
        fd.setAuthMatrixId(pathId);
        fd.setStatus(midOffice
                ? FDStatus.PENDING_AT_MID_OFFICE
                : FDStatus.APPROVED);
        for (FDAssignment n : all) {
            if (!n.getAuthMatrixId().equals(pathId)
                    && n.getStatus() != AssignmentStatus.APPROVED) {
                n.setStatus(AssignmentStatus.VIEW_ONLY);
                n.setIsActive(false);
            }
        }
        return true;
    }

    // =========================================================
    private void killPath(List<FDAssignment> path) {
        for (FDAssignment n : path) {
            if (n.getStatus() != AssignmentStatus.APPROVED) {
                n.setStatus(AssignmentStatus.VIEW_ONLY);
                n.setIsActive(false);
            }
        }
    }

    private boolean isKilled(List<FDAssignment> path) {
        return path.stream()
                .allMatch(n -> n.getStatus() == AssignmentStatus.VIEW_ONLY);
    }

    private boolean match(FDAssignment a,
                          Long groupId,
                          String roleName) {
        if (a.getAssignmentType() == AssignmentType.GROUP) {
            return groupId != null && groupId.equals(a.getGroupId());
        }
        if (a.getAssignmentType() == AssignmentType.ROLE) {
            return roleName != null && roleName.equals(a.getUserType());
        }
        return false;
    }

    private void audit(FixedDeposit fd,
                       Long userId,
                       String loginId,
                       String userName,
                       Long groupId,
                       String groupName,
                       Integer level,
                       ActionType action) {
        ApprovalAudit a = new ApprovalAudit();
        a.setFdId(fd.getId());
        a.setLoginId(loginId);
        a.setUserId(userId);
        a.setGroupId(groupId);
        a.setGroupName(groupName);
        a.setUserName(userName);
        a.setLevel(level);
        a.setAction(action);
        a.setTimestamp(LocalDateTime.now());
        auditRepo.save(a);
    }

    @Transactional
    @Override
    public void reject(Long fdId, Long userId, String loginId, String userName, Long groupId, String groupName, String reason, String roleName) {

        FixedDeposit fd = fdRepo.findById(fdId)
                .orElseThrow(() -> new GTPAppException("FD not found", null));

        if (fd.getStatus() == FDStatus.APPROVED
                || fd.getStatus() == FDStatus.PENDING_AT_MID_OFFICE) {
            throw new GTPAppException("FD already approved. Reject not allowed.", null);
        }

        List<FDAssignment> all = assignmentRepo.findByFdId(fdId);

        // Identify current active assignment
        FDAssignment current = all.stream()
                .filter(a -> a.getIsActive())
                .filter(a -> match(a, groupId, roleName))
                .findFirst()
                .orElseThrow(() -> new GTPAppException("Not allowed", null));

        int currentLevel = current.getLevel();

        //Set selected path
        fd.setAuthMatrixId(current.getAuthMatrixId());

        // Mark FD rejected
        fd.setStatus(FDStatus.REJECTED);
        fd.setRejectReason(reason);

        for (FDAssignment a : all) {

            // CURRENT NODE REJECTED
            if (a.getIsActive() && match(a, groupId, roleName)) {
                a.setStatus(AssignmentStatus.REJECTED);
                a.setIsActive(false);
                continue;
            }

            // NON-SEQUENTIAL ALWAYS VIEW_ONLY
            if (!a.getIsSequential()) {
                if (a.getStatus() != AssignmentStatus.APPROVED) {
                    a.setStatus(AssignmentStatus.VIEW_ONLY);
                }
                a.setIsActive(false);
                continue;
            }

            // FUTURE NODES (SEQ)VIEW_ONLY
            if (a.getLevel() >= currentLevel) {
                if (a.getStatus() != AssignmentStatus.APPROVED) {
                    a.setStatus(AssignmentStatus.VIEW_ONLY);
                }
            }

            a.setIsActive(false);
        }

        fdRepo.saveAndFlush(fd);
        //Audit
        audit(fd, userId, loginId, userName, groupId, groupName, currentLevel, ActionType.REJECTED);

    }

    // ================= REOPEN =================
    @Transactional
    @Override
    public void reopen(FixedDepositDto updated) {
//        fdRepo.deleteById(updated.getId());
        assignmentRepo.deleteAll(assignmentRepo.findByFdId(updated.getId()));
        assignmentRepo.flush();
        updated.setRejectReason(null);
        updated.setReopend(true);
        createFD(updated);
    }

    // ================= CLOSE =================
    @Transactional
    @Override
    public void close(Long fdId, Long makerId, String loginId, String userName) {
        FixedDeposit fd = fdRepo.findById(fdId).orElseThrow();
        if (fd.getStatus() != FDStatus.REJECTED) {
            throw new GTPAppException("Only rejected FD can be closed", null);
        }
        fd.setStatus(FDStatus.CLOSED);
        audit(fd, makerId, loginId, userName, null, "Client Maker", null, ActionType.CLOSED);
        fdRepo.saveAndFlush(fd);
    }


    @Override
    public Page<MakerTrayDTO> getMakerTray(Long makerId, Pageable pageable) {
        return fdRepo.findByMakerId(makerId, pageable)
                .map(fd -> new MakerTrayDTO(
                        fd.getId(),
                        fd.getAmount(),
                        fd.getStatus(),
                        fd.getRejectReason()
                ));
    }

    @Override
    public Page<CheckerFDTrayDTO> getCheckerTray(Long userId, Long groupId, Pageable pageable) {
        return assignmentRepo.findCheckerTray(userId, groupId, pageable)
                .map(CheckerFDTrayDTO::convertToDto);
    }

    @Override
    public Page<CheckerFDTrayDTO> getCheckerTrayByStatus(Long userId, Long groupId, List<String> status, Pageable pageable) {

        // 1. Fetch all records from both sources using Pageable.unpaged() to ensure we have the full dataset for global sorting/merging.
        List<CheckerTrayProjection> fdOpeningList = assignmentRepo.findCheckerTrayByStatusFD(userId, groupId,status,Pageable.unpaged());
        List<CheckerTrayProjection> fdclosureList = assignmentRepo.findCheckerTrayByStatusCloseFD(userId, groupId,status,Pageable.unpaged());

        System.out.println("getCheckerTrayByStatus FD Opening List Size=" +fdOpeningList.size());

        System.out.println("getCheckerTrayByStatus FD Closure List Size=" +fdclosureList.size());

        List<CheckerFDTrayDTO> combined = new ArrayList<>();

        // 2. Map Opening Projection results to DTOs
        if (CollectionUtils.isNotEmpty(fdOpeningList)) {
            fdOpeningList.forEach(fd -> combined.add(CheckerFDTrayDTO.convertToDto(fd)));
        }

        // 3. Map Closure Projection results to DTOs
        if (CollectionUtils.isNotEmpty(fdclosureList)) {
            fdclosureList.forEach(cfd -> combined.add(CheckerFDTrayDTO.convertToDto(cfd)));
        }

        // 4. Sort the combined list globally.
        // Note: If getId() is still unresolved, please check CheckerFDTrayDTO for the correct getter (e.g., getFdId()).
        combined.sort(Comparator.comparing(CheckerFDTrayDTO::getFdId, Comparator.nullsLast(Comparator.reverseOrder())));

        // 5. Apply manual pagination to the combined list
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), combined.size());
        List<CheckerFDTrayDTO> subList = (start < combined.size()) ? combined.subList(start, end) : Collections.emptyList();

        return new PageImpl<>(subList, pageable, combined.size());

        /*return assignmentRepo.findCheckerTrayByStatus(userId, groupId, status, pageable)
                .map(CheckerFDTrayDTO::convertToDto);*/
    }

    @Override
    public Page<CheckerFDTrayDTO> getCheckerPendingTray(Long userId, Long groupId, Pageable pageable) {
       /* return assignmentRepo.findCheckerTrayWithPending(userId, groupId, pageable)
                .map(CheckerFDTrayDTO::convertToDto);*/

        List<CheckerTrayProjection> fdOpeningList = assignmentRepo.findCheckerTrayWithPendingFD(userId, groupId,
                Pageable.unpaged());
        List<CheckerTrayProjection> fdclosureList = assignmentRepo.findCheckerTrayWithPendingCloseFD(userId, groupId,
                Pageable.unpaged());

        System.out.println("getCheckerPendingTray FD Opening List Size=" +fdOpeningList.size());

        System.out.println("getCheckerPendingTray FD Closure List Size=" +fdclosureList.size());

        List<CheckerFDTrayDTO> combined = new ArrayList<>();

        // 2. Map Opening Projection results to DTOs
        if (CollectionUtils.isNotEmpty(fdOpeningList)) {
            fdOpeningList.forEach(fd -> combined.add(CheckerFDTrayDTO.convertToDto(fd)));
        }

        // 3. Map Closure Projection results to DTOs
        if (CollectionUtils.isNotEmpty(fdclosureList)) {
            fdclosureList.forEach(cfd -> combined.add(CheckerFDTrayDTO.convertToDto(cfd)));
        }

        // 4. Sort the combined list globally.
        // Note: If getId() is still unresolved, please check CheckerFDTrayDTO for the correct getter (e.g., getFdId()).
        combined.sort(Comparator.comparing(CheckerFDTrayDTO::getFdId, Comparator.nullsLast(Comparator.reverseOrder())));

        // 5. Apply manual pagination to the combined list
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), combined.size());
        List<CheckerFDTrayDTO> subList = (start < combined.size()) ? combined.subList(start, end) : Collections.emptyList();

        return new PageImpl<>(subList, pageable, combined.size());
    }

    @Override
    public Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTray(Long userId, String roleName, Pageable pageable) {

        return assignmentRepo.findReleaserOrVerifierTray(userId, roleName, pageable)
                .map(CheckerFDTrayDTO::convertToDto);
    }

    @Override
    public Page<CheckerFDTrayDTO> getRelaeaserOrVerifierPendingTray(Long userId, String roleName, Pageable pageable) {

        // 1. Fetch all records from both sources using Pageable.unpaged() to ensure we have the full dataset for global sorting/merging.
        List<CheckerTrayProjection> fdOpeningList = assignmentRepo.findReleaserOrVerifierTrayFD(userId, roleName,
                Pageable.unpaged());
        List<CheckerTrayProjection> fdclosureList = assignmentRepo.findReleaserOrVerifierTrayCloseFD(userId, roleName,
                Pageable.unpaged());

        System.out.println("FD Opening List Size=" +fdOpeningList.size());

        System.out.println("FD Closure List Size=" +fdclosureList.size());

        List<CheckerFDTrayDTO> combined = new ArrayList<>();

        // 2. Map Opening Projection results to DTOs
        if (CollectionUtils.isNotEmpty(fdOpeningList)) {
            fdOpeningList.forEach(fd -> combined.add(CheckerFDTrayDTO.convertToDto(fd)));
        }

        // 3. Map Closure Projection results to DTOs
        if (CollectionUtils.isNotEmpty(fdclosureList)) {
            fdclosureList.forEach(cfd -> combined.add(CheckerFDTrayDTO.convertToDto(cfd)));
        }

        // 4. Sort the combined list globally.
        // Note: If getId() is still unresolved, please check CheckerFDTrayDTO for the correct getter (e.g., getFdId()).
        combined.sort(Comparator.comparing(CheckerFDTrayDTO::getFdId, Comparator.nullsLast(Comparator.reverseOrder())));

        // 5. Apply manual pagination to the combined list
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), combined.size());
        List<CheckerFDTrayDTO> subList = (start < combined.size()) ? combined.subList(start, end) : Collections.emptyList();

        return new PageImpl<>(subList, pageable, combined.size());

        //return assignmentRepo.findReleaserOrVerifierPendingTray(userId, roleName, pageable).map(CheckerFDTrayDTO::convertToDto);

    }

//    @Override
//    public Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTrayByStatus(Long userId, String roleName, List<String> status, Pageable pageable) {
//        System.out.println("Inside getRelaeaserOrVerifierTrayByStatus");
//        return assignmentRepo.findReleaserOrVerifierTrayByStatus(userId, roleName, status, pageable)
//                .map(CheckerFDTrayDTO::convertToDto);
//    }

        @Override
        public Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTrayByStatus (Long userId, String
        roleName, List < String > status, Pageable pageable){
            System.out.println("Inside getRelaeaserOrVerifierTrayByStatus");
            return assignmentRepo.findReleaserOrVerifierTrayByStatus(userId, roleName, status, pageable)
                    .map(CheckerFDTrayDTO::convertToDto);
        }

        @Override
        public Page<FixedDepositDto> getAllFDByCifId (String cifId, Pageable pageable){
            return fdRepo.findByCifId(cifId, pageable).map(FixedDepositDto::convertToDto);
        }

    @Override
    @Transactional
    public void approveFdMidOffice(Long fdId, Long midOfficeUserId, String midOfficeLoginId, String midOfficeUserName) {
        FixedDeposit fd = fdRepo.findById(fdId).orElseGet(() -> {
            CloseFixedDeposit cls = clsFD.findById(fdId)
                    .orElseThrow(() -> new RuntimeException("Fixed Deposit record not found for ID: " + fdId));
            FixedDeposit shadow = new FixedDeposit();
            shadow.setId(cls.getId());
            shadow.setAuthMatrixId(cls.getAuthMatrixId());
            shadow.setCurrentLevel(cls.getCurrentLevel());

            if (cls.getStatus() != null) {
                shadow.setStatus(FDStatus.valueOf(String.valueOf(cls.getStatus())));
            }
            return shadow;
        });

        if (fd.getStatus() != FDStatus.PENDING_AT_MID_OFFICE) {
            throw new GTPAppException("Only Pending at Mid Office status can be approved", null);
        }

        //Handeling Premature FD Closure
        //FDAssignment fdAssigment= assignmentRepo.getById(fdId);

        List<FDAssignment> all = assignmentRepo.findByFdId(fdId);
      /*  List<FDAssignment> actionable = all.stream()
                .filter(FDAssignment::getIsActive)
                .filter(a -> FDStatus.PENDING_AT_MID_OFFICE.toString().equals(a.getStatus()))
                .toList();*/

        if(all.get(0).getClosureFlag() != null && all.get(0).getClosureFlag().equalsIgnoreCase("Y")) {

            CloseFixedDeposit cls = clsFD.findById(fdId).orElseThrow();


            cls.setStatus(FDStatus.MID_OFFICE_APPROVED);
            cls.setIsMidOfficeApproved(true);
            audit(fd, midOfficeUserId, midOfficeLoginId, midOfficeUserName, null, "Mid Office", null, ActionType.MID_OFFICE_APPROVED);
            executeFDClosureRequest(cls.getFdAccountNumber(), cls.getRepaymentAccount(), cls.getAmount());
            clsFD.saveAndFlush(cls);
        }

        if(all.get(0).getClosureFlag() != null && all.get(0).getClosureFlag().equalsIgnoreCase("N")){

            fd.setStatus(FDStatus.MID_OFFICE_APPROVED);
            fd.setIsMidOfficeApproved(true);
            audit(fd, midOfficeUserId, midOfficeLoginId, midOfficeUserName, null, "Mid Office", null, ActionType.MID_OFFICE_APPROVED);
            callFinacleFDCreationService(fd);
            fdRepo.saveAndFlush(fd);
        }

        }

    @Override
    @Transactional
    public void rejectFdMidOffice(Long fdId, Long midOfficeUserId, String midOfficeLoginId, String midOfficeUserName) {
        FixedDeposit fd = fdRepo.findById(fdId).orElseGet(() -> {
            CloseFixedDeposit cls = clsFD.findById(fdId)
                    .orElseThrow(() -> new RuntimeException("Fixed Deposit record not found for ID: " + fdId));
            FixedDeposit shadow = new FixedDeposit();
            shadow.setId(cls.getId());
            shadow.setAuthMatrixId(cls.getAuthMatrixId());
            shadow.setCurrentLevel(cls.getCurrentLevel());

            if (cls.getStatus() != null) {
                shadow.setStatus(FDStatus.valueOf(String.valueOf(cls.getStatus())));
            }
            return shadow;
        });
        if (fd.getStatus() != FDStatus.PENDING_AT_MID_OFFICE) {
            throw new GTPAppException("Only Pending at Mid Office status can be rejected", null);
        }

        //Handeling Premature FD Closure
        //FDAssignment fdAssigment= assignmentRepo.getById(fdId);

        List<FDAssignment> all = assignmentRepo.findByFdId(fdId);
      /*  List<FDAssignment> actionable = all.stream()
                .filter(FDAssignment::getIsActive)
                .filter(a -> FDStatus.PENDING_AT_MID_OFFICE.toString().equals(a.getStatus()))
                .toList();*/

        if(all.get(0).getClosureFlag() != null && all.get(0).getClosureFlag().equalsIgnoreCase("Y")){

            CloseFixedDeposit cls = clsFD.findById(fdId).orElseThrow();
            cls.setStatus(FDStatus.MID_OFFICE_REJECTED);
            audit(fd, midOfficeUserId, midOfficeLoginId, midOfficeUserName, null, "Mid Office", null, ActionType.MID_OFFICE_REJECTED);
            clsFD.saveAndFlush(cls);
        }
        if(all.get(0).getClosureFlag() != null && all.get(0).getClosureFlag().equalsIgnoreCase("N")){
            fd.setStatus(FDStatus.MID_OFFICE_REJECTED);
            audit(fd, midOfficeUserId, midOfficeLoginId, midOfficeUserName, null, "Mid Office", null, ActionType.MID_OFFICE_REJECTED);
            fdRepo.saveAndFlush(fd);
        }

        }


    public Page<AccountJson> getFDByStatus(String cifId, Pageable page) {
        System.out.println("getFDByStatus");
        AccountRequestDto accountRequestDto = AccountRequestDto.builder().cifid(cifId).build();
        System.out.println("Plaint Acccount JSON REquest=" +accountRequestDto);
        JoseUtility ju = joseHelper.getJoseUtility();
        AccountJsonResponse jsonResponses = new AccountJsonResponse();

        try{

            String requestJson = objectMapper.writeValueAsString(accountRequestDto);
            String encryptedEnvelope = ju.createIblGatewayRequestString(null, requestJson, InputType.STRING);
            System.out.println("Encrypted String=" +encryptedEnvelope);
            byte[] keyBytes = ju.getCurrentKey().getEncoded();
            String base64Key = Base64.getEncoder().encodeToString(keyBytes);
            System.out.println("Key is=" +base64Key);
            IBLGatewayResponse encryptedResponse =fetchFDAccountFeignClient.fetchAccountsByCifId( clientId, clientSecret,encryptedEnvelope);


            if (encryptedResponse == null || encryptedResponse.getData() == null) {
                throw new RuntimeException("Empty encrypted response from bank");
            }
             jsonResponses = ju.getPayloadFromResponseObject(
                    null, encryptedResponse.getData(), AccountJsonResponse.class, InputType.STRING);
        System.out.println("Acccount JSON Response=" +jsonResponses.toString());
        }catch(Exception e){
            e.printStackTrace();
        }


        List<AccountJson> tdaAccounts =
                Optional.ofNullable(jsonResponses.getAccounts())
                        .orElse(Collections.emptyList())
                        .stream()
                        .filter(account -> "TDA".equalsIgnoreCase(account.getSchemeType()))
                        .collect(Collectors.toList());

        tdaAccounts.sort(Comparator.comparing(AccountJson::getAccountNumber).reversed());

        int start = (int) page.getOffset();
        int end = Math.min((start + page.getPageSize()), tdaAccounts.size());
        List<AccountJson> subList = (start < tdaAccounts.size()) ? tdaAccounts.subList(start, end) : new ArrayList<>();

        return new PageImpl<>(subList, page, tdaAccounts.size());
    }

    //@Override
    /*public Page<FixedDepositDto> getFDByStatus(List<String> status, Pageable page) {
        // To provide a unified view for the Mid-Office tray, we merge results from
        // both standard FD requests and FD Closure requests into a single paginated result.
        List<FixedDepositDto> unifiedList = new ArrayList<>();

        // 1. Fetch and Map standard Fixed Deposits (Creation)
        fdRepo.findAllByStatusIn(status, Pageable.unpaged()).forEach(fd ->
            unifiedList.add(FixedDepositDto.convertToDto(fd))
        );

        // 2. Fetch and Map Close Fixed Deposits (Closure)
        clsFD.findAllByStatusIn(status, Pageable.unpaged()).forEach(entity -> {
            FixedDepositDto dto = new FixedDepositDto();
            BeanUtils.copyProperties(entity, dto);

            // Manually bridge field naming and type differences between Entity and DTO
            dto.setAccountNumber(entity.getFdAccountNumber());
            if (entity.getAmount() != null) {
                dto.setAmount(entity.getAmount().doubleValue()); // Convert BigDecimal to Double
            }
            if (entity.getStatus() != null) {
                dto.setStatus(FDStatus.valueOf(String.valueOf(entity.getStatus()))); // Map String status to Enum
            }
            unifiedList.add(dto);
        });

        // 3. Apply a common sort order across the combined dataset (e.g., ID descending)
        unifiedList.sort(Comparator.comparing(FixedDepositDto::getId).reversed());

        // 4. Implement manual pagination to extract the correct sublist for the requested page
        int start = (int) page.getOffset();
        int end = Math.min((start + page.getPageSize()), unifiedList.size());
        List<FixedDepositDto> subList = (start < unifiedList.size()) ? unifiedList.subList(start, end) : new ArrayList<>();

        return new PageImpl<>(subList, page, unifiedList.size());
    }*//*public Page<FixedDepositDto> getFDByStatus(List<String> status, Pageable page) {
        // To provide a unified view for the Mid-Office tray, we merge results from
        // both standard FD requests and FD Closure requests into a single paginated result.
        List<FixedDepositDto> unifiedList = new ArrayList<>();

        // 1. Fetch and Map standard Fixed Deposits (Creation)
        fdRepo.findAllByStatusIn(status, Pageable.unpaged()).forEach(fd ->
            unifiedList.add(FixedDepositDto.convertToDto(fd))
        );

        // 2. Fetch and Map Close Fixed Deposits (Closure)
        clsFD.findAllByStatusIn(status, Pageable.unpaged()).forEach(entity -> {
            FixedDepositDto dto = new FixedDepositDto();
            BeanUtils.copyProperties(entity, dto);

            // Manually bridge field naming and type differences between Entity and DTO
            dto.setAccountNumber(entity.getFdAccountNumber());
            if (entity.getAmount() != null) {
                dto.setAmount(entity.getAmount().doubleValue()); // Convert BigDecimal to Double
            }
            if (entity.getStatus() != null) {
                dto.setStatus(FDStatus.valueOf(String.valueOf(entity.getStatus()))); // Map String status to Enum
            }
            unifiedList.add(dto);
        });

        // 3. Apply a common sort order across the combined dataset (e.g., ID descending)
        unifiedList.sort(Comparator.comparing(FixedDepositDto::getId).reversed());

        // 4. Implement manual pagination to extract the correct sublist for the requested page
        int start = (int) page.getOffset();
        int end = Math.min((start + page.getPageSize()), unifiedList.size());
        List<FixedDepositDto> subList = (start < unifiedList.size()) ? unifiedList.subList(start, end) : new ArrayList<>();

        return new PageImpl<>(subList, page, unifiedList.size());
    }*/

    @Override
    public Page<FixedDepositDto> getFDByCifIdAndStatus(String cifId, List<String> status, Pageable page) {
        // To provide a unified view for the Mid-Office tray, we merge results from
        // both standard FD requests and FD Closure requests into a single paginated result.
        List<FixedDepositDto> unifiedList = new ArrayList<>();

        // 1. Fetch and Map standard Fixed Deposits (Creation)
        fdRepo.findByCifIdAndStatusIn(cifId, status, Pageable.unpaged()).forEach(fd ->
                unifiedList.add(FixedDepositDto.convertToDto(fd))
        );

        // 2. Fetch and Map Close Fixed Deposits (Closure)
        clsFD.findByCifIdAndStatusIn(cifId, status, Pageable.unpaged()).forEach(entity -> {
            FixedDepositDto dto = new FixedDepositDto();
            BeanUtils.copyProperties(entity, dto);

            // Manually bridge field naming and type differences between Entity and DTO
            dto.setAccountNumber(entity.getFdAccountNumber());
            if (entity.getAmount() != null) {
                dto.setAmount(entity.getAmount().doubleValue()); // Convert BigDecimal to Double
            }
            if (entity.getStatus() != null) {
                dto.setStatus(FDStatus.valueOf(String.valueOf(entity.getStatus()))); // Map String status to Enum
            }
            unifiedList.add(dto);
        });

        // 3. Apply a common sort order across the combined dataset (e.g., ID descending)
        unifiedList.sort(Comparator.comparing(FixedDepositDto::getId).reversed());

        // 4. Implement manual pagination to extract the correct sublist for the requested page
        int start = (int) page.getOffset();
        int end = Math.min((start + page.getPageSize()), unifiedList.size());
        List<FixedDepositDto> subList = (start < unifiedList.size()) ? unifiedList.subList(start, end) : new ArrayList<>();

        return new PageImpl<>(subList, page, unifiedList.size());
    }


    @Override
    public Page<FdActionAuditsDto> getFDAuditsByFdId(Long fdId, Pageable page) {
        Page<ApprovalAudit> approvalAudits = auditRepo.findAllByFdId(fdId, page);
        return approvalAudits.map(FdActionAuditsDto::convertEntityToDto);
    }



    @Override
    public MidOfficeCountDTO getMidOfficeCounts() {
        MidOfficeCountProjection p = fdRepo.getMidOfficeCounts();



        MidOfficeCountProjection cls = clsFD.getMidOfficeCounts();

        return new MidOfficeCountDTO(
                "FD",
                safe(p.getPendingAtBank()) + safe(cls.getPendingAtBank()),
                safe(p.getPendingAtClient()) + safe(cls.getPendingAtClient()),
                safe(p.getProcessedByBank()) + safe(cls.getProcessedByBank()),
                safe(p.getProcessedByClient()) + safe(cls.getProcessedByClient())
        );

    }

    private Long safe(Long val) {
        return val == null ? 0L : val;
    }

    private void executeFDClosureRequest(String fdAccountNumber, String repaymentAccount, Double amount) {
        System.out.println("Inside executeFDClosureRequest");
        System.out.println("Account Number=" +fdAccountNumber);
        System.out.println("Repayment Account Number=" +repaymentAccount);
        System.out.println("Amount=" +amount);
        withdrawalService.initiateFullWithdrawal(fdAccountNumber,repaymentAccount,amount);
    }

    @Override
    public Page<FixedDepositDto> getMidOfficeList(List<String> status, Pageable page) {
        // To provide a unified view for the Mid-Office tray, we merge results from
        // both standard FD requests and FD Closure requests into a single paginated result.
        List<FixedDepositDto> unifiedList = new ArrayList<>();

        // 1. Fetch and Map standard Fixed Deposits (Creation)
        fdRepo.findAllByStatusIn(status, Pageable.unpaged()).forEach(fd ->
                unifiedList.add(FixedDepositDto.convertToDto(fd))
        );

        // 2. Fetch and Map Close Fixed Deposits (Closure)
        clsFD.findAllByStatusIn(status, Pageable.unpaged()).forEach(entity -> {
            FixedDepositDto dto = new FixedDepositDto();
            BeanUtils.copyProperties(entity, dto);

            // Manually bridge field naming and type differences between Entity and DTO
            dto.setAccountNumber(entity.getFdAccountNumber());
            if (entity.getAmount() != null) {
                dto.setAmount(entity.getAmount().doubleValue()); // Convert BigDecimal to Double
            }
            if (entity.getStatus() != null) {
                dto.setStatus(FDStatus.valueOf(String.valueOf(entity.getStatus()))); // Map String status to Enum
            }
            unifiedList.add(dto);
        });

        // 3. Apply a common sort order across the combined dataset (e.g., ID descending)
        unifiedList.sort(Comparator.comparing(FixedDepositDto::getId).reversed());

        // 4. Implement manual pagination to extract the correct sublist for the requested page
        int start = (int) page.getOffset();
        int end = Math.min((start + page.getPageSize()), unifiedList.size());
        List<FixedDepositDto> subList = (start < unifiedList.size()) ? unifiedList.subList(start, end) : new ArrayList<>();

        return new PageImpl<>(subList, page, unifiedList.size());
    }

}
