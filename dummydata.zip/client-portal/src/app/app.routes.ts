import { Routes } from '@angular/router';
import { MainLayoutComponent } from './layout/main-layout/main-layout.component';
import { LoginComponent } from './modules/auth/login/login.component';
import { SignupComponent } from './modules/auth/signup/signup.component';
import { PoliciesComponent } from './modules/auth/policies/policies.component';
import { NotFoundComponent } from './shared/components/not-found/not-found.component';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'policies', component: PoliciesComponent },
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./modules/dashboard/dashboard.component').then(
            (m) => m.DashboardComponent
          ),
      },
      {
        path: 'accounts',
        children: [
          {
            path: 'balance',
            loadComponent: () =>
              import(
                './modules/accounts/components/balance-list/balance-list.component'
              ).then((m) => m.BalanceListComponent),
          },
          {
            path: 'statements',
            loadComponent: () =>
              import(
                './modules/accounts/components/statement-list/statement-list.component'
              ).then((m) => m.StatementListComponent),
          },
        ],
      },
      {
        path: 'deposits',
        children: [
          {
            path: '',
            loadComponent: () =>
              import(
                './modules/deposits/components/deposit-list/deposit-list.component'
              ).then((m) => m.DepositListComponent),
          },
          {
            path: 'open',
            loadComponent: () =>
              import(
                './modules/deposits/components/open-fixed-deposit/open-fixed-deposit.component'
              ).then((m) => m.OpenFixedDepositComponent),
          },
          {
            path: 'review',
            loadComponent: () =>
              import(
                './modules/deposits/components/review-fixed-deposit/review-fixed-deposit.component'
              ).then((m) => m.ReviewFixedDepositComponent),
          },
        ],
      },
      {
        path: 'deal-booking',
        children: [
          {
            path: '',
            loadComponent: () =>
              import(
                './modules/dealbooking/dealbooking-list/dealbooking-list.component'
              ).then((m) => m.DealbookingComponent),
          },
          {
            path: 'open',
            loadComponent: () =>
              import('./modules/dealbooking/fxdeal/fxdeal.component').then(
                (m) => m.FxDealComponent
              ),
          },
        ],
      },
      {
        path: 'remittance',
        children: [
          {
            path: 'inwardlist',
            loadComponent: () =>
              import(
                './modules/remittances/inwardremittance/inwardlist/inwardlist.component'
              ).then((m) => m.InwardlistComponent),
          },
          {
            path: 'inwardlist/edit',
            loadComponent: () =>
              import(
                './modules/remittances/inwardremittance/inwardadd/inwardadd.component'
              ).then((m) => m.InwardaddComponent),
          },
          {
            path: 'outwardlist',
            loadComponent: () =>
              import(
                './modules/remittances/outwardremittance/outwardlist/outwardlist.component'
              ).then((m) => m.OutwardlistComponent),
          },
          {
            path: 'outwardlist/add',
            loadComponent: () =>
              import(
                './modules/remittances/outwardremittance/outwardadd/outwardadd.component'
              ).then((m) => m.OutwardaddComponent),
          },
          {
            path: 'beneficiarylist',
            loadComponent: () =>
              import(
                './modules/remittances/BeneficiaryMaintenance/beneficiarylist/beneficiarylist.component'
              ).then((m) => m.BeneficiarylistComponent),
          },
          {
            path: 'beneficiarylist/add',
            loadComponent: () =>
              import(
                './modules/remittances/BeneficiaryMaintenance/addbeneficiary/addbeneficiary.component'
              ).then((m) => m.AddbeneficiaryComponent),
          },
        ],
      },
      {
        path: 'user-management',
        children: [
          {
            path: 'user-list',
            loadComponent: () =>
              import(
                './modules/UserManagement/Create-user/user-list/user-list.component'
              ).then((m) => m.UserListComponent),
          },
          {
            path: 'approval-list',
            loadComponent: () =>
              import(
                './modules/UserManagement/Approvals/approval-list/approval-list.component'
              ).then((m) => m.ApprovalListComponent),
          },
          {
            path: 'cm-user-profile',
            loadComponent: () =>
              import(
                './modules/UserManagement/cm-user-profile/cm-user-profile.component'
              ).then((m) => m.CmUserProfileComponent),
          },
          {
            path: 'cm-profile',
            loadComponent: () =>
              import(
                './modules/UserManagement/cm-profiles/cm-profiles.component'
              ).then((m) => m.CmProfilesComponent),
          },
        ],
      },
    ],
  },
  { path: '**', component: NotFoundComponent },
];
