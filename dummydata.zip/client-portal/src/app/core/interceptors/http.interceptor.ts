import { HttpInterceptorFn, HttpRequest, HttpHandlerFn, HttpErrorResponse, HttpEvent, HttpResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { SessionService } from '../services/sessionService/session.service';
import { catchError, tap, throwError } from 'rxjs';

const PUBLIC_URLS = [
  '/api/auth/client/clientLogin',
  '/api/auth/bank/bankLogin',
  '/api/auth/logout',
  '/api/auth/client/privacy-policy',
  '/api/auth/bank/privacy-policy',
];

export const authInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
) => {
  const sessionService = inject(SessionService);
  const router = inject(Router);

  // Skip token for public/auth endpoints
  const isPublic = PUBLIC_URLS.some(url => req.url.includes(url));
  if (isPublic) {
    return next(req);
  }

  const token = sessionService.getToken();

  // No token yet (e.g. first load before login) — forward as-is
  if (!token) {
    return next(req);
  }

  // Clone request and add Authorization header
  const authReq = req.clone({
    setHeaders: {
      Authorization: `Bearer ${token}`
    }
  });

  return next(authReq).pipe(
    tap((event: HttpEvent<any>) => {
      if (event instanceof HttpResponse) {
        const authError = event.headers.get('x-auth-error');
        if (authError === 'SESSION_EXPIRED') {
          sessionService.clearSession();
          localStorage.clear();
          router.navigate(['/login']);
        }
      }
    }),
    catchError((error: HttpErrorResponse) => {
      const authError = error.headers.get('x-auth-error');
      if (error.status === 401 || authError === 'SESSION_EXPIRED') {
        sessionService.clearSession();
        localStorage.clear();
        router.navigate(['/login']);
      }
      return throwError(() => error);
    })
  );
};