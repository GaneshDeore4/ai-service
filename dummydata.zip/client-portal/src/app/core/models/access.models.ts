export interface UserAccessProfile {
  userId: number;
  username: string;
  userType: string;
  products: Product[];
}

export interface Product {
  isMidOffice:Boolean;
  productId: number;
  productName: string;
  subProducts: SubProduct[];
}

export interface SubProduct {
  subProductId: number;
  subProductName: string;
  tabActionMapping: TabActionMapping[];
}

export interface TabActionMapping {
  tabId: number;
  tabName: string;
  actions: Action[];
}

export interface Action {
  id: number;
  name: string;
}

export interface UserAccessResponse {
  status: string;
  payload: UserAccessProfile;
  description: string;
}
