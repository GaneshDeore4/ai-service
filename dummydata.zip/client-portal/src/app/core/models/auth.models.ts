export interface LoginRequest {
  loginId: string;
  cifId: string;
  password: string;
}

export interface UserProfile {
  userId: string;
  loginId: string;
  role: string;
  cif: string;
  email: string;
  permissions: string[];
  termsSecurityPrivacyPolicyAccepted: boolean;
  groupId: number;
  userFirstName: string;
  userLastName: string;
  groupName: string;
  baseCurrency: string;
  lastLogin: string;
}


export interface LoginResponse {
  email: string;
  token: string;
  loginId: string;
  role: string;
  userId: number;
  userFirstName: string;
  userLastName: string;
  termsSecurityPrivacyAccepted: boolean;
  groupId: number;
  groupName: string;
  baseCurrency: string;
  lastLogin: string;
}
