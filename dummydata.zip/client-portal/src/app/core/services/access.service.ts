import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { UserAccessProfile, UserAccessResponse } from '../models/access.models';
import { ApiEndpoints } from '../constants/api-endpoints';

@Injectable({
  providedIn: 'root'
})
export class AccessService {
  private accessProfileSubject = new BehaviorSubject<UserAccessProfile | null>(null);
  public accessProfile$ = this.accessProfileSubject.asObservable();

  // private readonly ACCESS_API = 'http://localhost:8080/api/user/myaccess';

  constructor(private http: HttpClient) {
    const storedAccess = sessionStorage.getItem('userAccess');
    if (storedAccess) {
      this.accessProfileSubject.next(JSON.parse(storedAccess));
    }
  }

  fetchUserAccess(userId: number): Observable<UserAccessResponse> {
    return this.http.get<UserAccessResponse>(`${ApiEndpoints.auth.myaccess}?userId=${userId}`).pipe(
      tap(response => {
        if (response.status === 'SUCCESS' && response.payload) {
          sessionStorage.setItem('userAccess', JSON.stringify(response.payload));
          this.accessProfileSubject.next(response.payload);
        }
      })
    );
  }

  clearAccess() {
    sessionStorage.removeItem('userAccess');
    this.accessProfileSubject.next(null);
  }

  get currentAccessValue(): UserAccessProfile | null {
    return this.accessProfileSubject.value;
  }
}
