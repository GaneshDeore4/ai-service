import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  Account,
  Deposit,
  Transaction,
  Notification,
  Guidelines,
} from '../models/banking.models';
import { ApiEndpoints } from '../constants/api-endpoints';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(private http: HttpClient) {}

  getAccounts(): Observable<Account[]> {
    return this.http.get<Account[]>(ApiEndpoints.accounts.list);
  }
  getAllNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(ApiEndpoints.dashboard.Notification);
  }

  getAccountsByUserId(userId: string): Observable<any> {
    return this.http.get<any>(ApiEndpoints.accounts.accountByUser(userId));
  }

  getAllGuidelines(): Observable<Guidelines[]> {
    return this.http.get<Guidelines[]>(ApiEndpoints.dashboard.Guidelines);
  }

  getAccountsByCif(cif: string): Observable<any> {
    return this.http.get<any>(ApiEndpoints.accounts.byCif(cif));
  }

  syncAccounts(cif: string): Observable<any> {
    return this.http.post<any>(ApiEndpoints.accounts.sync(cif), {});
  }
  
  syncBalance(accountNumber: string): Observable<any> {
    return this.http.post<any>(ApiEndpoints.accounts.syncBalance(accountNumber), {});
  }

  getTransactions(
    acc?: string,
    start?: string,
    end?: string,
    ref?: string,
    type?: string
  ): Observable<any> {
    return this.http.get<any>(ApiEndpoints.statements.filter(ref, type));
  }

  syncTransactions(acc: string, from: string, to: string): Observable<any> {
    return this.http.post<any>(ApiEndpoints.statements.sync(), {});
  }

  FDEnquiry(cifId: string): Observable<any> {
    return this.http.post<any>(ApiEndpoints.fixedDeposit.fdEnquiry(cifId), {});
  }

  FDCheckerTray(payload: any): Observable<any> {
    return this.http.post<any>(
      ApiEndpoints.fixedDeposit.checkerTray(),
      payload
    );
  }
  FDVRTray(payload: any): Observable<any> {
    return this.http.post<any>(
      ApiEndpoints.fixedDeposit.vrTray(),
      payload
    );
  }

  FDCheckerPendingTray(userId: string, groupId: string): Observable<any> {
    return this.http.get<any>(
      ApiEndpoints.fixedDeposit.checkerPendingTray(userId, groupId),
      {}
    );
  }
  FDVRPendingTray(userId: string, roleName: string): Observable<any> {
    return this.http.get<any>(
      ApiEndpoints.fixedDeposit.vrPendingTray(userId, roleName),
      {}
    );
  }

  EnquiryFdDetailsByAccount(payload: any): Observable<any> {
    return this.http.post<any>(
      ApiEndpoints.fixedDeposit.enquiryFDDetails(),
      payload
    );
  }

  closeFDEqiury(payload: any): Observable<any> {
    return this.http.post<any>(
      ApiEndpoints.fixedDeposit.closeFDEnquiry(),
      payload
    );
  }

  IntRate(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.fixedDeposit.IntRate, payload);
  }

  createfd(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.fixedDeposit.createfd, payload);
  }

  approveFd(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.fixedDeposit.approvefd, payload);
  }

  rejectFd(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.fixedDeposit.rejectfd, payload);
  }

  fdRoadmap(fdId: number): Observable<any> {
    return this.http.get<any>(ApiEndpoints.fixedDeposit.fdRoadmap(fdId));
  }
  fdAudit(fdId: number, payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.fixedDeposit.fdAudit(fdId),payload);
  }

  sendOtp(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.otp.sendOtp, payload);
  }

  sendOtpBeforeLogin(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.otp.sendOtpBeforeLogin, payload);
  }

  resendOtp(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.otp.resendOtp, payload);
  }

  validateOtp(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.otp.validateOtp, payload);
  }

  validateOtpBeforeLogin(payload: any): Observable<any> {
    return this.http.post<any>(ApiEndpoints.otp.validateOtpBeforeLogin, payload);
  }

  getData(url: string, data: any): Observable<any> {
    return this.http.get<any>(url.toString(), data);
  }

  sendData(url: string, body: any, headers?: any): Observable<any> {
    let httpHeaders = new HttpHeaders();
    // ✅ Case 1: If string passed → treat as action role
    if (typeof headers === 'string') {
      httpHeaders = httpHeaders.set('X-ACTION-ROLE', headers);
    }
    // ✅ Case 2: If proper headers object passed → use it
    else if (headers instanceof HttpHeaders) {
      httpHeaders = headers;
    }
    // ✅ Case 3: If plain object passed → convert
    else if (headers && typeof headers === 'object') {
      Object.keys(headers).forEach((key) => {
        httpHeaders = httpHeaders.set(key, headers[key]);
      });
    }
    return this.http.post(url, body, { headers: httpHeaders });
  }
}
