import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) { 
  }

  getData(url:string,data:any):Observable<any>{
    return this.http.get<any>(url.toString(),data);
  }

  getDataWithParam(url: string, params: any) {
  return this.http.get<any>(url.toString(), { params });
}

  sendData(url:string,data:any):Observable<any>{
    return this.http.post<any>(url.toString(),data);
  }

}
