import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, BehaviorSubject, tap } from 'rxjs';
import { LoginRequest, LoginResponse, UserProfile } from '../models/auth.models';
import { ApiEndpoints } from '../constants/api-endpoints';
import { AccessService } from './access.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<UserProfile | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();





  constructor(
    private http: HttpClient,
    private accessService: AccessService,
    private router: Router
  ) {
    const storedUser = sessionStorage.getItem('currentUser');
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
    }
  }

  login(credentials: LoginRequest): Observable<LoginResponse> {
    // Real API call
    return this.http.post<LoginResponse>(ApiEndpoints.auth.login, credentials).pipe(
      tap(response => {
        sessionStorage.setItem('token', response.token);
        console.log(response);
        const userProfile: UserProfile = {
          userId: response.userId.toString(),
          loginId: response.loginId,
          email: response.email,
          role: response.role,
          cif: credentials.cifId,
          userFirstName: response.userFirstName,
          userLastName: response.userLastName,
          groupId: response.groupId,
          groupName: response.groupName,
          permissions: [],
          baseCurrency: response.baseCurrency,
          lastLogin: response.lastLogin,
          termsSecurityPrivacyPolicyAccepted: response.termsSecurityPrivacyAccepted
        };
        sessionStorage.setItem('currentUser', JSON.stringify(userProfile));
        sessionStorage.setItem('isFirstTimeLoginFlag', (!response.termsSecurityPrivacyAccepted).toString());
        this.currentUserSubject.next(userProfile);

        // Fetch dynamic access profile
        this.accessService.fetchUserAccess(response.userId).subscribe();
      })
    );
  }

  logout() {
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('currentUser');
    this.accessService.clearAccess();
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  hasAccess(moduleName: string): boolean {
    const user = this.currentUserSubject.value;
    if (!user) return false;

    // Simple logic: if permissions include the module name or if it's SUPERADMIN
    return user.role === 'SUPERADMIN' || user.permissions.includes(moduleName);
  }

  isLoggedIn(): boolean {
    return !!sessionStorage.getItem('token');
  }

  forceLogout(data: any): Observable<any> {
    // Determine if it's a client or bank user based on the context or just try both
    // But since we enabled it globally in DefaultSecurityConfig at /api/auth/logout/force/**
    return this.http.post(`${ApiEndpoints.auth.logout}/force`, data);
  }

  unlockUser(data: any): Observable<any> {
    return this.http.post(ApiEndpoints.auth.unlockUser, data);
  }
  unlockUserBeforeLogin(data: any): Observable<any> {
    return this.http.post(ApiEndpoints.auth.unlockUserBeforeLogin, data);
  }
  forgotPassword(data: any): Observable<any> {
    return this.http.post(ApiEndpoints.auth.resetpassword, data);
  }
  resetPassword(data: any): Observable<any> {
    return this.http.post(ApiEndpoints.auth.forgotPassword, data);
  }
  resetPasswordBeforeLogin(data: any): Observable<any> {
    return this.http.post(ApiEndpoints.auth.forgotPasswordBeforeLogin, data);
  }
  forgotUserId(data: any): Observable<any> {
    return this.http.post(ApiEndpoints.auth.forgotUserId, data);
  }

  updatePrivacyPolicy(payload: any): Observable<any> {
    return this.http.patch(ApiEndpoints.auth.privacyPolicy, payload).pipe(
      tap(() => {
        const user = this.currentUserSubject.value;
        if (user && user.loginId === payload.loginId) {
          user.termsSecurityPrivacyPolicyAccepted = payload.accepted;
          sessionStorage.setItem('currentUser', JSON.stringify(user));
          this.currentUserSubject.next(user);
        }
      })
    );
  }
}
