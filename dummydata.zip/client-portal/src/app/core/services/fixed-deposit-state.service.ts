import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FixedDepositStateService {
  private initialForm = {
    account: null,
    currency: 'INR',
    amount: '',
    tenure: {
      years: 0,
      months: 0,
      days: 0,
    },
    interestFrequency: '',
    maturityInstruction: '',
    payoutType: '',
    termsAccepted: false,
  };

  private fdFormSubject = new BehaviorSubject<any>({ ...this.initialForm });
  fdForm$ = this.fdFormSubject.asObservable();

  constructor() {}

  setFormData(data: any) {
    this.fdFormSubject.next({ ...data });
  }

  getFormData() {
    return this.fdFormSubject.value;
  }

  clearFormData() {
    this.fdFormSubject.next({ ...this.initialForm });
  }
}
