import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccessService } from '../../../core/services/access.service';
import { UserAccessProfile } from '../../../core/models/access.models';
import { AuthService } from '../../../core/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  standalone: true,
  imports: [CommonModule],
})
export class HeaderComponent {
  showProfileMenu: boolean = false;
  @Output() toggle = new EventEmitter<void>();
  accessProfile: UserAccessProfile | null = null;
  groupName = '';
  primaryColor: string = '#0b2e63'; // default
  lastLogin: string = ''
  fontScale = 1;
  email: any;
  increaseFont() {
    if (this.fontScale < 1.2) {
      this.fontScale += 0.05;
      this.applyScale();
    }
  }
  decreaseFont() {
    if (this.fontScale > 0.8) {
      this.fontScale -= 0.05;
      this.applyScale();
    }
  }
  resetFont() {
    this.fontScale = 1;
    this.applyScale();
  }
  applyScale() {
    document.documentElement.style.setProperty(
      '--font-scale',
      this.fontScale.toString()
    );
    localStorage.setItem('fontScale', this.fontScale.toString());
  }
  ngOnInit() {
    const storedUser = sessionStorage.getItem('currentUser');
    if (storedUser) {
      const currentUser = JSON.parse(storedUser);
      this.groupName = currentUser.groupName;
      this.email = currentUser.email;
      this.lastLogin = currentUser.lastLogin
    }
    const saved = localStorage.getItem('fontScale');
    if (saved) {
      this.fontScale = +saved;
      this.applyScale();
    }
    const savedColor = localStorage.getItem('primaryColor');
    if (savedColor) {
      this.primaryColor = savedColor;
      this.applyPrimaryColor(savedColor);
    }
  }

  onColorChange(event: any) {
    const color = event.target.value;
    this.primaryColor = color;

    this.applyPrimaryColor(color);

    // Save for persistence
    localStorage.setItem('primaryColor', color);
  }

  applyPrimaryColor(color: string) {
    document.documentElement.style.setProperty('--primary-color', color);

    // OPTIONAL: derive light/dark shades automatically
    document.documentElement.style.setProperty(
      '--primary-light',
      this.adjustColor(color, 40)
    );
    document.documentElement.style.setProperty(
      '--primary-dark',
      this.adjustColor(color, -40)
    );
  }
  adjustColor(color: string, amount: number): string {
    let usePound = false;
    if (color[0] === '#') {
      color = color.slice(1);
      usePound = true;
    }
    let num = parseInt(color, 16);
    let r = (num >> 16) + amount;
    let g = ((num >> 8) & 0x00ff) + amount;
    let b = (num & 0x0000ff) + amount;
    r = Math.max(Math.min(255, r), 0);
    g = Math.max(Math.min(255, g), 0);
    b = Math.max(Math.min(255, b), 0);
    return (
      (usePound ? '#' : '') +
      ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')
    );
  }

  constructor(
    private accessService: AccessService,
    private authService: AuthService,
    private router: Router
  ) {
    this.accessService.accessProfile$.subscribe((profile) => {
      this.accessProfile = profile;
    });
  }

  toggleSidebar() {
    this.toggle.emit();
  }
  toggleProfileMenu(event?: Event) {
    if (event) {
      event.stopPropagation();
    }
    this.showProfileMenu = !this.showProfileMenu;
    console.log('Profile menu toggled:', this.showProfileMenu);
  }

  logout() {
    // Clear all storage — removes token, user, access profile
    sessionStorage.clear();
    localStorage.clear();
    // Reset service state
    this.authService.logout();
    // Redirect to login page
    this.router.navigate(['/login']);
  }
}
