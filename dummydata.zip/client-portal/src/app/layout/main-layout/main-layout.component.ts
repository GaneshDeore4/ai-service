import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HeaderComponent } from './header/header.component';
import { SessionTimeoutService } from '../../core/services/sessionService/session-timeout.service';
import { SessionExpiryComponent } from '../../shared/components/session-expiry/session-expiry.component';

@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, SidebarComponent, HeaderComponent, SessionExpiryComponent]
})
export class MainLayoutComponent {
  isSidebarOpen = true;

  constructor(private sessionTimeoutService: SessionTimeoutService) {
    // Initialize session timer on layout load
    this.sessionTimeoutService.resetTimer();
  }

  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }
}
