import { Component } from '@angular/core';

@Component({
  selector: 'app-approval-list',
  imports: [],
  templateUrl: './approval-list.component.html',
  styleUrl: './approval-list.component.css'
})
export class ApprovalListComponent {

}
