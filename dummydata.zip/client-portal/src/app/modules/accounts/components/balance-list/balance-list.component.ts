import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
  AfterViewInit,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../../core/services/api.service';
import { AuthService } from '../../../../core/services/auth.service';
import { TableComponent } from '../../../../shared/components/table/table.component';
import { Account, ApiResponse } from '../../../../core/models/banking.models';
import { DownloadModalComponent } from '../../../../shared/components/download-modal/download-modal.component';
import { AccountDetailsModalComponent } from '../../../../shared/components/account-details-modal/account-details-modal.component';

@Component({
  selector: 'app-balance-list',
  templateUrl: './balance-list.component.html',
  styleUrls: ['./balance-list.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    TableComponent,
    DownloadModalComponent,
    AccountDetailsModalComponent,
    FormsModule,
  ],
})
export class BalanceListComponent implements OnInit, AfterViewInit {
  @ViewChild('actionTemplate') actionTemplate!: TemplateRef<any>;
  accounts: Account[] = [];
  filteredAccounts: Account[] = [];
  searchTerm: string = '';
  columns: any[] = [];
  isFilterOpen = false;
  isDownloadOpen = false;
  isDetailsOpen = false;
  selectedAccount: Account | null = null;
  cif: string | undefined;

  constructor(
    private apiService: ApiService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    this.authService.currentUser$.subscribe((user) => {
      this.cif = user?.cif;
      if (user && user.cif) {
        this.apiService
          .getAccountsByUserId(user.userId)
          .subscribe((response: any) => {
            const fetchedAccounts = Array.isArray(response) ? response : (response.payload || []);
            this.accounts = fetchedAccounts;
            this.filteredAccounts = [...fetchedAccounts];
          });
      }
    });



  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.columns = [
        { field: 'accountNumber', header: 'Account Number' },
        { field: 'schemeDescription', header: 'Description' },
        { field: 'schemeType', header: 'Type' },
        { field: 'currency', header: 'Currency' },
        { field: 'effectiveAvailBalance', header: 'Balance' },
        {
          field: 'action',
          header: 'Action',
          template: this.actionTemplate, // ✅ NOW AVAILABLE
        },
      ];
    });
  }

  openDetails(row: Account) {
    this.selectedAccount = row;
    console.log(this.selectedAccount)
    this.isDetailsOpen = true;
  }


  syncBalance(row: Account) {
    if (!row || !row.accountNumber) return;

    this.apiService.syncBalance(row.accountNumber).subscribe({
      next: (response) => {
        if (response.status === 'SUCCESS') {
          const index = this.accounts.findIndex(acc => acc.accountNumber === row.accountNumber);
          if (index !== -1) {
            this.accounts[index].effectiveAvailBalance = response.payload.effectiveAvailBalance;
            // Re-apply search filter after updating the master list
            this.onSearch();
          }
          alert('Balance synchronized successfully!');
        }
      },
      error: (err) => {
        console.error('Failed to sync balance', err);
        alert('Failed to sync balance. Please try again.');
      }
    });
  }

  onSearch() {
    if (!this.searchTerm || this.searchTerm.trim() === '') {
      this.filteredAccounts = [...this.accounts];
      return;
    }

    const term = this.searchTerm.toLowerCase().trim();
    this.filteredAccounts = this.accounts.filter((acc) => {
      const accNo = acc.accountNumber ? acc.accountNumber.toLowerCase() : '';
      const desc = acc.schemeDescription ? acc.schemeDescription.toLowerCase() : '';
      const type = acc.schemeType ? acc.schemeType.toLowerCase() : '';

      return accNo.includes(term) || desc.includes(term) || type.includes(term);
    });
  }
}
