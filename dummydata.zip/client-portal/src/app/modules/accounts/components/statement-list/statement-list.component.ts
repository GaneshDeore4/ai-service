import {
  Component,
  OnInit,
  ViewChild,
  TemplateRef,
  AfterViewInit,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../../core/services/api.service';
import { TableComponent } from '../../../../shared/components/table/table.component';
import {
  Transaction,
  ApiResponse,
} from '../../../../core/models/banking.models';
import { Account } from '../../../../core/models/banking.models';

import { DownloadModalComponent } from '../../../../shared/components/download-modal/download-modal.component';
import { AccountDetailsModalComponent } from '../../../../shared/components/account-details-modal/account-details-modal.component';
import { LoaderComponent } from '../../../../shared/components/loader/loader.component';
import { StatementService } from '../../../../core/services/statement.service';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth.service';

@Component({
  selector: 'app-statement-list',
  templateUrl: './statement-list.component.html',
  styleUrls: ['./statement-list.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    TableComponent,
    DownloadModalComponent,
    AccountDetailsModalComponent,
    LoaderComponent,
    FormsModule,
  ],
})
export class StatementListComponent implements OnInit, AfterViewInit {
  @ViewChild('actionTemplate') actionTemplate!: TemplateRef<any>;
  @ViewChild('typeTemplate') typeTemplate!: TemplateRef<any>;
  transactions: any[] = [];
  miniColumns: any[] = [];
  columns: any[] = [];
  fullColumns: any[] = [];
  isDownloadOpen = false;
  isFilterOpen = false;
  isDetailsOpen = false;
  activeTab = 'mini';

  // Filter fields
  requestUUID: string = 'REQ12782423433';
  channelID: string = 'COR';
  limit: number = 10;
  accountNumber: string = '';
  selectedAccountNumber: string = '';
  startDate: string = '';
  endDate: string = '';
  refNumber: string = '';
  tranType: string = '';
  continueToken = '';
  headerAccNumber: String = this.accountNumber;
  selectedAccount: any | null = null;
  searchText: string = '';
  isLoading: boolean = false;

  // Allowed columns for PDF Export
  allowedPdfColumns: string[] = [
    'tranDate',
    'tranId',
    'debitOrCredit',
    'amount',
    'particulars',
  ];
  accounts: any;
  currency: any;

  constructor(
    private apiService: ApiService,
    private statementService: StatementService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    this.setDefaultDates();
    this.authService.currentUser$.subscribe((user) => {
      if (user && user.cif) {
        this.apiService
          .getAccountsByUserId(user.userId)
          .subscribe((response: any) => {
            const fetchedAccounts = Array.isArray(response) ? response : (response.payload || []);
            this.accounts = fetchedAccounts;
            if (this.accounts.length > 0) {
              this.selectedAccountNumber = this.accounts[0].accountNumber;
              this.accountNumber = this.selectedAccountNumber;
              this.currency = this.accounts[0].currency;
              this.headerAccNumber = this.selectedAccountNumber;
              this.loadData(); // Ensure data loads after account is set
            }
          });
      }
    });
    this.loadData();
  }

  private setDefaultDates() {
    const today = new Date();
    const last30Days = new Date();
    last30Days.setDate(today.getDate() - 30);

    this.endDate = this.formatDate(today);
    this.startDate = this.formatDate(last30Days);
  }

  private formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  ngAfterViewInit() {
    setTimeout(() => {
      // ✅ MINI STATEMENT (less fields)
      this.miniColumns = [
        { field: 'tranDate', header: 'Tran Date' },
        { field: 'tranId', header: 'Tran ID' },
        { field: 'debitOrCredit', header: 'Type', template: this.typeTemplate },
        { field: 'amount', header: 'Amount' },
      ];

      // ✅ FULL STATEMENT (detailed)
      this.fullColumns = [
        { field: 'tranDate', header: 'Tran Date' },
        { field: 'tranId', header: 'Tran ID' },
        { field: 'particulars', header: 'Particulars' },
        { field: 'debitOrCredit', header: 'Type', template: this.typeTemplate },
        { field: 'amount', header: 'Amount' },
        { field: 'balance', header: 'Balance' },
      ];

      // ✅ set default
      this.updateColumns();
    });
  }
  updateColumns() {
    this.columns =
      this.activeTab === 'mini' ? this.miniColumns : this.fullColumns;
  }

  openDetails(row: any) {
    this.selectedAccount = row;
    console.log(this.selectedAccount);
    this.isDetailsOpen = true;
  }

  switchTab(tab: string) {
    this.activeTab = tab;
    this.transactions = [];
    this.continueToken = '';

    this.updateColumns(); // 🔥 IMPORTANT

    this.loadData();
  }

  loadData() {
    this.isLoading = true;
    if (this.activeTab === 'mini') {
      this.statementService
        .fetchMiniStatement(
          this.selectedAccountNumber,
          this.requestUUID,
          this.channelID,
          this.startDate,
          this.endDate,
          100 // Fetch a larger batch for client-side filtering and pagination
        )
        .subscribe(
          (res: ApiResponse<any>) => {
            if (res.status === 'SUCCESS') {
              let fetchedTransactions = res.payload.transactions || [];

              // Client-side filtering for Mini Statement
              if (this.refNumber || this.tranType || this.searchText) {
                this.transactions = fetchedTransactions.filter((tran: any) => {
                  const matchRef =
                    !this.refNumber ||
                    (tran.tranId &&
                      tran.tranId
                        .toLowerCase()
                        .includes(this.refNumber.toLowerCase()));
                  const matchType =
                    !this.tranType ||
                    (tran.debitOrCredit &&
                      tran.debitOrCredit.trim() === this.tranType);
                  const matchSearch =
                    !this.searchText ||
                    (tran.tranId &&
                      tran.tranId
                        .toLowerCase()
                        .includes(this.searchText.toLowerCase())) ||
                    (tran.particulars &&
                      tran.particulars
                        .toLowerCase()
                        .includes(this.searchText.toLowerCase())) ||
                    (tran.amount &&
                      tran.amount.toString().includes(this.searchText));
                  return matchRef && matchType && matchSearch;
                });
              } else {
                this.transactions = fetchedTransactions;
              }

              this.continueToken = '';
            }
            this.isLoading = false;
          },
          (err) => {
            this.isLoading = false;
            console.error('Error fetching mini statement', err);
          }
        );
    } else {
      // Full Statement uses server-side fetch but now also supports client-side search over the returned page
      this.statementService
        .fetchFullStatement(
          this.selectedAccountNumber,
          this.requestUUID,
          this.channelID,
          this.startDate,
          this.endDate,
          this.limit,
          this.refNumber,
          this.tranType,
          this.continueToken
        )
        .subscribe(
          (res: ApiResponse<any>) => {
            if (res.status === 'SUCCESS') {
              let fetchedTransactions = res.payload.transactions || [];

              // Apply client-side filtering on the fetched page
              if (this.searchText || this.refNumber || this.tranType) {
                this.transactions = fetchedTransactions.filter((tran: any) => {
                  const matchRef =
                    !this.refNumber ||
                    (tran.tranId &&
                      tran.tranId
                        .toLowerCase()
                        .includes(this.refNumber.toLowerCase()));
                  const matchType =
                    !this.tranType ||
                    (tran.debitOrCredit &&
                      tran.debitOrCredit.trim() === this.tranType);
                  const matchSearch =
                    !this.searchText ||
                    (tran.tranId &&
                      tran.tranId
                        .toLowerCase()
                        .includes(this.searchText.toLowerCase())) ||
                    (tran.particulars &&
                      tran.particulars
                        .toLowerCase()
                        .includes(this.searchText.toLowerCase())) ||
                    (tran.amount &&
                      tran.amount.toString().includes(this.searchText));
                  return matchRef && matchType && matchSearch;
                });
              } else {
                this.transactions = fetchedTransactions;
              }

              this.continueToken = res.payload.continueToken;
            }
            this.isLoading = false;
          },
          (err) => {
            this.isLoading = false;
            console.error('Error fetching full statement', err);
          }
        );
    }
  }

  onAccountChange() {
    if (!this.selectedAccountNumber) return;
    this.accountNumber = this.selectedAccountNumber; // 👈 IMPORTANT
    this.continueToken = '';
    this.transactions = [];

    this.loadData(); // 🔥 reload data with new account
  }

  applyFilters() {
    this.isFilterOpen = false;
    this.continueToken = '';
    this.loadData();
  }

  resetFilters() {
    this.setDefaultDates();
    this.refNumber = '';
    this.tranType = '';
    this.continueToken = '';
    this.isFilterOpen = false;
    this.loadData();
  }

  onNextPage() {
    if (this.activeTab === 'full' && this.continueToken) {
      this.loadData();
    }
  }

  handlePageSizeChange(size: number) {
    this.limit = size;
    this.continueToken = '';
    this.loadData();
  }

  private downloadAsCSV() {
    const { headers, fields } = this.getExportConfig();

    const csvData = this.transactions.map((row) =>
      fields.map((field) => `"${row[field] || ''}"`).join(',')
    );

    const csvContent = [headers.join(','), ...csvData].join('\n');
    this.downloadFile(
      csvContent,
      `Statement_${this.accountNumber}.csv`,
      'text/csv'
    );
  }

  private downloadAsXML() {
    const { fields } = this.getExportConfig();
    let xmlContent = '<?xml version="1.0" encoding="UTF-8"?>\n<Statement>\n';

    this.transactions.forEach((row) => {
      xmlContent += '  <Transaction>\n';
      fields.forEach((field) => {
        const tagName = field.replace(/\s+/g, '');
        xmlContent += `    <${tagName}>${row[field] || ''}</${tagName}>\n`;
      });
      xmlContent += '  </Transaction>\n';
    });

    xmlContent += '</Statement>';
    this.downloadFile(
      xmlContent,
      `Statement_${this.accountNumber}.xml`,
      'application/xml'
    );
  }

  onDownloadConfirm(fileType: string) {
    if (!this.transactions || this.transactions.length === 0) {
      alert('No data available to download.');
      return;
    }

    switch (fileType) {
      case 'CSV':
        this.downloadAsCSV();
        break;
      case 'XML':
        this.downloadAsXML();
        break;
      case 'JSON':
        this.downloadAsJSON();
        break;
      case 'PDF':
        this.downloadAsPDF();
        break;
      default:
        console.error('Unsupported file type:', fileType);
    }
  }

  private downloadAsPDF() {
    // Filter transactions to only include allowed columns for PDF
    const filteredTransactions = this.transactions.map((tran) => {
      const filteredTran: any = {};
      this.allowedPdfColumns.forEach((col) => {
        filteredTran[col] = tran[col];
      });
      return filteredTran;
    });

    // Call backend for professional PDF generation
    const statementData = {
      accountId: this.accountNumber,
      name: 'Valued Customer', // In a real app, get from user profile
      currency: 'INR',
      availableBalance:
        this.transactions.length > 0 ? this.transactions[0].balance : 0,
      transactions: filteredTransactions,
    };

    this.statementService.downloadPdf(statementData).subscribe({
      next: (blob: Blob) => {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `Statement_${this.accountNumber}.pdf`;
        link.click();
        window.URL.revokeObjectURL(url);
      },
      error: (err) => {
        console.error('PDF Download failed', err);
        alert('Failed to download PDF. Please try again.');
      },
    });
  }

  /* private downloadAsPDF() {
    // For PDF, we use the browser's print functionality which is the most reliable way
    // to generate a high-quality PDF without external libraries like jsPDF.
    const printContent = document.querySelector('app-table');
    if (printContent) {
      const originalTitle = document.title;
      document.title = `Statement_${this.accountNumber}`;
      window.print();
      document.title = originalTitle;
    }
  } */

  private getExportConfig() {
    if (!this.transactions || this.transactions.length === 0) {
      return { headers: [], fields: [] };
    }

    // Get all keys from the first transaction record
    const allKeys = Object.keys(this.transactions[0]);

    // Create a map of existing field -> header for quick lookup
    const headerMap: { [key: string]: string } = {};
    this.columns.forEach((col) => {
      if (col.field && col.field !== 'action') {
        headerMap[col.field] = col.header;
      }
    });

    // Exclude internal or unwanted fields
    const excludedKeys = ['action', 'internalId'];
    const fields = allKeys.filter((key) => !excludedKeys.includes(key));

    // Map to headers, using existing ones or humanizing new ones
    const headers = fields.map((field) => {
      let header = headerMap[field] || this.humanize(field);
      // Map 'Particulars' to 'Remarks' as per user request
      if (header === 'Particulars' || field === 'particulars') {
        header = 'Remarks';
      }
      return header;
    });

    return { headers, fields };
  }

  private humanize(text: string) {
    if (!text) return '';

    // Special case for particulars
    // if (text.toLowerCase() === 'particulars') return 'Remarks';

    // Convert camelCase or snake_case to Space Separated Title case
    const result = text
      .replace(/([A-Z])/g, ' $1')
      .replace(/_/g, ' ')
      .trim();
    return result.charAt(0).toUpperCase() + result.slice(1);
  }

  private downloadAsJSON() {
    const jsonContent = JSON.stringify(this.transactions, null, 2);
    this.downloadFile(
      jsonContent,
      `Statement_${this.accountNumber}.json`,
      'application/json'
    );
  }

  private downloadFile(content: string, fileName: string, contentType: string) {
    const blob = new Blob([content], { type: contentType });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.click();
    window.URL.revokeObjectURL(url);
  }
}
