import { ViewChildren, QueryList, ElementRef } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators,
  FormsModule,
} from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { OtpPopupComponent } from '../../../shared/components/otp-popup/otp-popup.component';
import { ApiService } from '../../../core/services/api.service';
import { AccessService } from '../../../core/services/access.service';
import { UserAccessResponse } from '../../../core/models/access.models';
import { Observable } from 'rxjs';
import { ApiEndpoints } from '../../../core/constants/api-endpoints';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css', '../auth-layout.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, OtpPopupComponent, FormsModule],
})
export class LoginComponent implements OnInit {
  @ViewChildren('otpInput') otpInputs!: QueryList<ElementRef>;
  showPassword = false;
  showOtpPopup = false;
  enteredOtp = '';
  termsAccepted = false;
  loginForm: FormGroup;
  captchaCode: string = '';
  submitted = false;
  isLoading = false;
  loginError = '';
  isAlreadyActive = false;
  showForceLogoutPopup = false;
  showPopup = false;
  popupMessage = '';

  // BELOW VARIABLES ARE FOR HELPER FORMS
  cifId: string = '';
  loginId: string = '';
  mobileNumber: string = '';
  captcha: string = '';
  cifIdErrorMsg: string = '';
  loginIdErrorMsg: string = '';
  mobileNumberErrorMsg: string = '';
  captchaErrorMsg: string = '';
  cifIdError = false;
  loginIdError = false;
  mobileNumberError = false;
  captchaError = false;
  password: string = '';
  confirmPassword: string = '';
  passwordErrorMsg: string = '';
  passwordError = false;
  //

  viewMode: 'login' | 'otp' | 'resetPassword' = 'login';
  flowType: 'mobile' | 'loginId' | 'forgotPassword' = 'mobile';
  goToOtp(type: 'mobile' | 'loginId' | 'forgotPassword') {
    this.cleanHelperVariables();
    this.viewMode = 'otp';
    this.flowType = type;
  }
  cleanHelperVariables() {
    this.cifId = '';
    this.loginId = '';
    this.mobileNumber = '';
    this.captcha = '';
    this.cifIdErrorMsg = '';
    this.loginIdErrorMsg = '';
    this.mobileNumberErrorMsg = '';
    this.captchaErrorMsg = '';
    this.cifIdError = false;
    this.loginIdError = false;
    this.mobileNumberError = false;
    this.captchaError = false;
    this.password = '';
    this.confirmPassword = '';
    this.passwordErrorMsg = '';
    this.passwordError = false;
  }
  togglePassword() {
    this.showPassword = !this.showPassword;
  }
  onOtpInput(event: any, index: number) {
    const input = event.target;
    const value = input.value;
    // allow only 1 char
    if (value.length > 1) {
      input.value = value.charAt(0);
    }
    // move forward
    if (value && index < this.otpInputs.length - 1) {
      this.otpInputs.toArray()[index + 1].nativeElement.focus();
    }
    this.updateOtpValue();
  }
  updateOtpValue() {
    this.enteredOtp = this.otpInputs
      .toArray()
      .map((el) => el.nativeElement.value)
      .join('');
  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.otpInputs.first?.nativeElement.focus();
    });
  }

  onOtpKeyDown(event: KeyboardEvent, index: number) {
    const input = event.target as HTMLInputElement;
    // backspace → go previous
    if (event.key === 'Backspace' && !input.value && index > 0) {
      this.otpInputs.toArray()[index - 1].nativeElement.focus();
    }
  }

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private authService: AuthService,
    private apiService: ApiService,
    private accessService: AccessService,
  ) {
    this.loginForm = this.fb.group({
      cifId: ['', [Validators.required]],
      loginId: ['', Validators.required],
      password: ['', Validators.required],
      captcha: ['', Validators.required],
    });
  }
  handleOtpVerify(otp: string) {
    this.showOtpPopup = false;
    console.log('OTP:', otp);
    if (this.viewMode == 'otp') {
      this.validateOtp(otp);
    }
    else {
      if (!this.termsAccepted) {
        this.router.navigate(['/policies']);
      } else {
        this.router.navigate(['/dashboard']);
      }
    }
  }

  verifyOtp() {
    if (this.flowType === 'mobile') {
      this.popupMessage =
        'Login ID has been sent to your registered mobile number';
      this.showPopup = true;
    }
    if (this.flowType === 'loginId') {
      this.popupMessage = 'User ID has been enabled successfully';
      this.showPopup = true;
    }
    if (this.flowType === 'forgotPassword') {
      this.viewMode = 'resetPassword';
    }
  }

  closePopup() {
    this.showPopup = false;
    if (this.helperSuccessState == false) {
      //NOTHING OVER HERE
    }
    else {
      // After forgot password → go back to login
      if (this.flowType === 'forgotPassword') {
        this.viewMode = 'login';
      } else {
        this.viewMode = 'login';
      }
    }
  }

  ngOnInit() {
    this.generateCaptcha();
  }

  generateCaptcha() {
    const chars =
      '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)] + ' ';
    }
    this.captchaCode = code.trim();
  }

  onLogin() {
    this.submitted = true;
    this.loginError = '';

    // Compare captcha (normalize spaces for comparison)
    // const enteredCaptcha = this.loginForm.get('captcha')?.value;
    // const actualCaptcha = this.captchaCode.replace(/\s/g, '');

    if (this.loginForm.valid) {
      // if (enteredCaptcha === actualCaptcha) {
      if (true) {
        this.isLoading = true;
        const { captcha, ...loginData } = this.loginForm.value;
        this.authService.login(loginData).subscribe({
          next: (response: any) => {
            if (response.status === 'SUCCESS') {
              this.isLoading = false;
              // Fetch dynamic access profile
              this.fetchAccess(response.userId);
              this.termsAccepted = response.termsSecurityPrivacyAccepted;
            }
          },
          error: (err: any) => {
            this.isLoading = false;
            if (err.status === 409) {
              this.showForceLogoutPopup = true;
            } else {
              this.loginError = 'Invalid credentials. Please try again.';
            }
            this.generateCaptcha();
          },
        });
      } else {
        this.loginForm.get('captcha')?.setErrors({ mismatch: true });
        this.generateCaptcha();
      }
    }
  }

  fetchAccess(userId: number) {
    // Fetch dynamic access profile
    this.accessService.fetchUserAccess(userId).subscribe(
      {
        next: (accessResponse) => {
          if (accessResponse.status === 'SUCCESS') {
            this.showOtpPopup=true;
          }
        },
        error: (err) => {
          console.error('Error fetching access profile:', err);
        }
      }
    );
  }

  cancelForceLogout() {
    this.showForceLogoutPopup = false;
  }
  confirmForceLogout() {
    this.showForceLogoutPopup = false;
    this.forceLogout();
  }

  forceLogout() {
    const forceLogoutPayload = {
      cifOrAbbvName: this.loginForm.get('cifId')?.value,
      loginId: this.loginForm.get('loginId')?.value,
    };
    if (this.loginForm.get('loginId')?.value) {
      this.isLoading = true;
      this.authService.forceLogout(forceLogoutPayload).subscribe({
        next: () => {
          this.isLoading = false;
          this.isAlreadyActive = false;
          this.loginError = 'Session cleared. Please login again.';
          this.generateCaptcha();
        },
        error: (err) => {
          this.isLoading = false;
          this.loginError =
            'Failed to clear session. Please contact administrator.';
          console.error('Force logout error', err);
        },
      });
    }
  }
  speakCaptcha() {
    if (!this.captchaCode) return;
    // remove spaces so it's spoken clearly
    const text = this.captchaCode.split('').join(' ');
    const speech = new SpeechSynthesisUtterance(text);
    speech.rate = 0.8; // slower for clarity
    speech.pitch = 1;
    speech.volume = 1;
    window.speechSynthesis.cancel(); // stop previous
    window.speechSynthesis.speak(speech);
  }



  // HELPER FORM FUNCTION--------------------------------------
  showResetPassword = false;
  showConfirmResetPassword = false;
  helperSuccessState = true;
  toggleResetPassword() {
    this.showResetPassword = !this.showResetPassword;
  }
  toggleConfirmResetPassword() {
    this.showConfirmResetPassword = !this.showConfirmResetPassword;
  }
  submitHelperForm() {
    if (this.viewMode == 'otp' && this.flowType == 'mobile')
      this.forgotUserId();
    if (this.viewMode == 'otp' && this.flowType == 'loginId')
      this.unlockUser();
    if (this.viewMode == 'otp' && this.flowType == 'forgotPassword')
      this.viewMode = 'resetPassword';
  }
  forgotUserId() {
    if (!this.validateCifMobile())
      return;
    const payload = {
      cifId: this.cifId,
      mobileNumber: this.mobileNumber,
    };
    this.authService.unlockUser(payload).subscribe({
      next: (res: any) => {
        if (res.status == 'STATUS') {
          this.popupMessage = 'User has been Unlocked';
          this.showPopup = true;
          this.getToLoginScreen();
        }
        else {
          this.popupMessage = res.description;
          this.showPopup = true;
        }
      },
      error: (err) => {
        this.popupMessage = 'Something Went wrong';
        this.showPopup = true;
        console.error('Force logout error', err);
      },
    });
  }
  unlockUser() {
    if (!this.validateCifLoginId())
      return;
    const payload = {
      cifId: this.cifId,
      loginId: this.loginId,
    };
    this.authService.unlockUserBeforeLogin(payload).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          this.helperSuccessState = true;
          this.popupMessage = 'Your User ID has been successfully unlocked.';
          this.showPopup = true;
          this.getToLoginScreen();
        }
        else {
          this.helperSuccessState = false;
          this.popupMessage = res.description;
          this.showPopup = true;
        }
      },
      error: (err) => {
        this.helperSuccessState = false;
        this.popupMessage = err.error.message;
        this.showPopup = true;
        console.error('Force logout error', err);
      },
    });
  }

  resetPassword() {
    if (!this.validatePasswords())
      return;
    const payload = {
      comanyCifId: this.cifId,
      loginId: this.loginId,
      newPassword: this.password,
      afterLogin: false
    };
    this.authService.resetPasswordBeforeLogin(payload).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          this.helperSuccessState = true;
          this.popupMessage = 'Your password has been set successfully.';
          this.showPopup = true;
          this.getToLoginScreen();
        }
        else {
          this.helperSuccessState = false;
          this.popupMessage = res.description;
          this.showPopup = true;
        }
      },
      error: (err) => {
        this.helperSuccessState = false;
        this.popupMessage = err.error.message;
        this.showPopup = true;
        console.error('Force logout error', err);
      },
    });
  }


  validateCifLoginId(): boolean {
    this.clearErrors();
    let errorCounter = 0;
    if (this.cifId == '') {
      errorCounter++;
      this.cifIdError = true;
      this.cifIdErrorMsg = 'Invalid Customer ID';
    }
    if (this.loginId == '') {
      errorCounter++;
      this.loginIdError = true;
      this.loginIdErrorMsg = 'Login ID is required';
    }
    const actualCaptcha = this.captchaCode.replace(/\s/g, '');
    if (this.captcha == '' || this.captcha != actualCaptcha) {
      errorCounter++;
      this.captchaError = true;
      this.captchaErrorMsg = 'Invalid Captcha';
    }
    if (errorCounter > 0) {
      return false;
    }
    return true;
  }
  validateCifMobile(): boolean {
    this.clearErrors();
    let errorCounter = 0;
    if (this.cifId == '') {
      errorCounter++;
      this.cifIdError = true;
      this.cifIdErrorMsg = 'CIF ID is required';
    }
    if (this.mobileNumber == '') {
      errorCounter++;
      this.mobileNumberError = true;
      this.mobileNumberErrorMsg = 'Mobile number is required';
    }
    // regex to match mobile number
    const mobileRegex = /^[0-9]{10}$/;
    if (!mobileRegex.test(this.mobileNumber)) {
      errorCounter++;
      this.mobileNumberError = true;
      this.mobileNumberErrorMsg = 'Enter a valid 10-digit mobile number';
    }
    const actualCaptcha = this.captchaCode.replace(/\s/g, '');
    if (this.captcha == '' || this.captcha != actualCaptcha) {
      errorCounter++;
      this.captchaError = true;
      this.captchaErrorMsg = 'Invalid Captcha';
    }
    if (errorCounter > 0) {
      return false;
    }
    return true;
  }
  validatePasswords(): boolean {
    this.passwordError = false;
    this.passwordErrorMsg = '';

    const password = (this.password || '').trim();
    const confirmPassword = (this.confirmPassword || '').trim();

    /* a. Length: 8–20 */
    if (password.length < 8 || password.length > 20) {
      this.passwordErrorMsg = 'Password must be between 8 and 20 characters';
      this.passwordError = true;
      return false;
    }

    /* b. Composition */
    const compositionRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#%*])[A-Za-z\d!@#%*]+$/;

    if (!compositionRegex.test(password)) {
      this.passwordErrorMsg = 'Password must include uppercase, lowercase, number, and special character (! @ # % *)';
      this.passwordError = true;
      return false;
    }

    /* d. No character repeated 3+ times */
    if (/(.)\1{2,}/.test(password)) {
      this.passwordErrorMsg = 'No character should repeat more than twice consecutively';
      this.passwordError = true;
      return false;
    }

    /* c. Block sequential patterns (abcd, 1234) */
    const sequences = [
      'abcdefghijklmnopqrstuvwxyz',
      'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
      '0123456789'
    ];

    for (const seq of sequences) {
      for (let i = 0; i <= seq.length - 4; i++) {
        const pattern = seq.substring(i, i + 4);
        if (password.includes(pattern)) {
          this.passwordErrorMsg = 'Sequential patterns like abcd or 1234 are not allowed';
          this.passwordError = true;
          return false;
        }
      }
    }

    if (password !== confirmPassword) {
      this.passwordErrorMsg = 'Passwords do not match';
      this.passwordError = true;
      return false;
    }
    return true;

  }

  clearErrors() {
    this.cifIdError = false;
    this.loginIdError = false;
    this.mobileNumberError = false;
    this.captchaError = false;
    this.cifIdErrorMsg = '';
    this.loginIdErrorMsg = '';
    this.mobileNumberErrorMsg = '';
    this.captchaErrorMsg = '';
  }
  clearHelperFormInputs() {
    this.cifId = '';
    this.loginId = '';
    this.mobileNumber = '';
    this.captcha = '';
  }
  getToLoginScreen() {
    this.clearErrors();
    this.clearHelperFormInputs();
    this.viewMode = 'login';
    this.generateCaptcha();
    this.showResetPassword = false;
    this.showConfirmResetPassword = false;
    this.helperSuccessState = true;
  }


  // OTP LOGIC---------------------------------------------------
  otpReference: string = '';
  recievedOtp: string = '';//TEMP
  sendOtp() {
    if (this.viewMode == 'otp' && this.flowType == 'mobile') {
      if (!this.validateCifMobile())
        return;
    }
    if (this.viewMode == 'otp' && (this.flowType == 'loginId' || this.flowType == 'forgotPassword')) {
      if (!this.validateCifLoginId())
        return;
    }
    const payload = {
      loginId: this.loginId,
      companyCifId: this.cifId
    }
    this.apiService.sendOtpBeforeLogin(payload).subscribe({
      next: (res: any) => {
        console.log(res);
        if (res.status == 'SUCCESS') {
          this.helperSuccessState = true;
          this.showOtpPopup = true;
          this.otpReference = res.payload.otpReference;
          this.recievedOtp = res.payload.enteredOtp;
        } else {
          this.helperSuccessState = false;
          this.popupMessage = res.message;
          this.showPopup = true;
        }
      },
      error: (err: any) => {
        this.helperSuccessState = false;
        this.popupMessage = err.error.message;
        this.showPopup = true;
        console.error(err);
      }
    });
  }

  validateOtp(otp: string) {
    const payload = {
      loginId: this.loginId,
      companyCifId: this.cifId,
      enteredOtp: this.recievedOtp,//TEMP
      otpReference: this.otpReference,
      fromLoginScreen:true
    };

    this.apiService.validateOtpBeforeLogin(payload).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.helperSuccessState = true;
          this.closeOtpPopup();
          this.submitHelperForm();
        } else {
          this.helperSuccessState = false;
          this.popupMessage = res.description;
          this.showPopup = true;
        }
      },
      error: (err: any) => {
        this.helperSuccessState = false;
        this.popupMessage = 'OTP verification failed. Please try again.';
        this.showPopup = true;
        console.error(err);
      }
    });
  }

  closeOtpPopup() {
    this.showOtpPopup = false;
    this.otpReference = '';
    this.recievedOtp = '';
  }
}
