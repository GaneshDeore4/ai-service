import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css', '../auth-layout.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule]
})
export class SignupComponent {
  signupForm: FormGroup;
  step: number = 1; // 1: Initial, 2: OTP
  submitted = false;
  otpError = '';

  constructor(private router: Router, private fb: FormBuilder) {
    this.signupForm = this.fb.group({
      companyId: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      captcha: ['', Validators.required]
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.signupForm.valid) {
      this.step = 2;
      this.submitted = false;
    }
  }

  moveFocus(event: any, current: any, next: any, prev: any) {
    if (event.key === 'Backspace' && prev) {
      prev.focus();
    } else if (current.value.length === current.maxLength && next) {
      next.focus();
    }
  }

  onVerifyOtp() {
    this.submitted = true;
    this.otpError = '';

    // In a real app, we'd concatenate values from the 6 boxes.
    // For now, this is a mock success.
    this.router.navigate(['/policies']);
  }

  backToStep1() {
    this.step = 1;
    this.submitted = false;
  }
}
