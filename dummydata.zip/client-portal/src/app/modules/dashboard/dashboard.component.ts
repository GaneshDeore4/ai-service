import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AfterViewInit } from '@angular/core';
import {
  Chart,
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from 'chart.js';
import { ApiService } from '../../core/services/api.service';
import { UserProfile } from '../../core/models/auth.models';
import { AuthService } from '../../core/services/auth.service';
import { ApiEndpoints } from '../../core/constants/api-endpoints';
import { FormsModule } from '@angular/forms';
import { ToastComponent } from "../../shared/components/toast/toast.component";
Chart.register(
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule, ToastComponent],
})
export class DashboardComponent implements AfterViewInit {
  isCurrencyOpen = false;
  currencies = [
    { code: 'USD', country: 'us' },
    { code: 'EUR', country: 'eu' },
    { code: 'GBP', country: 'gb' },
    { code: 'INR', country: 'in' },
    { code: 'AED', country: 'ae' },
    { code: 'CAD', country: 'ca' },
    { code: 'AUD', country: 'au' },
    { code: 'JPY', country: 'jp' },
    { code: 'CNY', country: 'cn' },
    { code: 'SGD', country: 'sg' },
    { code: 'CHF', country: 'ch' },
    { code: 'ZAR', country: 'za' },
    { code: 'SAR', country: 'sa' },
    { code: 'HKD', country: 'hk' },
    { code: 'NZD', country: 'nz' },
  ];

  notifications = [
    {
      title: 'USD-INR Exchange Rate Update',
      description: 'USD has strengthened against INR due to market demand.',
      date: 'Feb 27, 2026',
    },
    {
      title: 'System Maintenance',
      description: 'Bank services will be unavailable from 2 AM to 4 AM.',
      date: 'Mar 02, 2026',
    },
  ];

  guidelines = [
    {
      title: 'Transaction Limits',
      description:
        'Daily limit: $500,000 per currency. Monthly limit: $5,000,000.',
    },
    {
      title: 'KYC Compliance',
      description:
        'Ensure all documents are updated to avoid service interruptions.',
    },
  ];
  targetCurrencies = [
    { code: 'EUR', country: 'eu' },
    { code: 'GBP', country: 'gb' },
    { code: 'CAD', country: 'ca' },
    { code: 'AED', country: 'ae' },
  ];
  selectedCurrency = this.currencies[0];

  toggleCurrency() {
    this.isCurrencyOpen = !this.isCurrencyOpen;
  }

  selectCurrency(curr: any) {
    this.selectedCurrency = curr;
    this.isCurrencyOpen = false;
    this.updateExchangeRates();
  }
  constructor(
    private apiService: ApiService,
    private authService: AuthService,
  ) {
    this.authService.currentUser$.subscribe((user: UserProfile | null) => {
      this.currentUser = user;
      this.userId = user?.userId ? Number(user.userId) : null;
      this.loginId = user?.loginId ?? '';
      this.cif = user?.cif ?? '';
    });
    this.firstTimeLoginFlag = sessionStorage.getItem('isFirstTimeLoginFlag') =='true'?true:false;
  }

  allRates: {
    [key: string]: { [key: string]: number };
  } = {
      USD: { EUR: 0.85, GBP: 0.74, CAD: 1.38, AED: 3.67 },
      EUR: { EUR: 1, GBP: 0.87, CAD: 1.45, AED: 3.95 },
      GBP: { EUR: 1.15, GBP: 1, CAD: 1.7, AED: 4.6 },
      INR: { EUR: 0.011, GBP: 0.0095, CAD: 0.016, AED: 0.044 },
      CAD: { EUR: 0.68, GBP: 0.59, CAD: 1, AED: 2.7 },
      AED: { EUR: 0.23, GBP: 0.2, CAD: 0.37, AED: 1 },
    };
  exchangeRates: any[] = [];
  updateExchangeRates() {
    const base = this.selectedCurrency.code;
    this.exchangeRates = this.targetCurrencies.map((target) => ({
      from: base,
      to: target.code,
      value: this.allRates[base]?.[target.code] || 0,
      fromCountry: this.selectedCurrency.country,
      toCountry: target.country,
    }));
  }

  ngOnInit() {
    this.updateExchangeRates();
    this.getAllGuidelines();
    this.getAllNotifications();
  }

  chartData = [
    { day: 'Mon', inflow: 60, outflow: 40 },
    { day: 'Tue', inflow: 80, outflow: 50 },
    { day: 'Wed', inflow: 40, outflow: 20 },
    { day: 'Thu', inflow: 90, outflow: 60 },
    { day: 'Fri', inflow: 50, outflow: 30 },
    { day: 'Sat', inflow: 70, outflow: 50 },
  ];
  // exchangeRates = [
  //   { from: 'USD', to: 'EUR', value: 0.85, fromCountry: 'us', toCountry: 'eu' },
  //   { from: 'USD', to: 'GBP', value: 0.74, fromCountry: 'us', toCountry: 'gb' },
  //   { from: 'USD', to: 'CAD', value: 1.38, fromCountry: 'us', toCountry: 'ca' },
  //   { from: 'USD', to: 'AED', value: 3.67, fromCountry: 'us', toCountry: 'ae' },
  // ];
  getFlag(code: string) {
    return `https://flagcdn.com/24x18/${code}.png`;
  }

  tradeData = [
    { label: 'Outward Remittance', value: 4, color: '#2f2f2f' },
    { label: 'Inward Remittance', value: 5, color: '#6fa8dc' },
    { label: 'Import LC', value: 10, color: '#6aa84f' },
    { label: 'Bank Guarantee', value: 3, color: '#cfe2f3' },
  ];

  getDonutGradient(): string {
    const total = this.tradeData.reduce((sum, item) => sum + item.value, 0);
    let current = 0;
    const segments = this.tradeData.map((item) => {
      const start = (current / total) * 100;
      const end = ((current + item.value) / total) * 100;
      current += item.value;
      return `${item.color} ${start}% ${end}%`;
    });
    return `conic-gradient(${segments.join(',')})`;
  }

  ngAfterViewInit() {
    this.createChart();
    this.createMiniCharts();
  }
  createChart() {
    new Chart('inflowChart', {
      type: 'bar',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        datasets: [
          {
            label: 'Inflow',
            data: [5, 5, 2, 7.5, 7, 5],
            backgroundColor: '#c45b5e',
            borderRadius: {
              bottomLeft: 6,
              bottomRight: 6,
            },
            borderSkipped: false,
            stack: 'stack1',
            barThickness: 20,
            maxBarThickness: 25,
            categoryPercentage: 0.5,
            barPercentage: 0.6,
          },
          {
            label: 'Outflow',
            data: [5, 10, 8, 7.5, 3, 10],
            backgroundColor: '#97272b',
            stack: 'stack1',
            borderSkipped: false,
            borderRadius: {
              topLeft: 6,
              topRight: 6,
            },
            barThickness: 20,
            maxBarThickness: 25,
            categoryPercentage: 0.5,
            barPercentage: 0.6,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
            position: 'top',
            align: 'end',
            labels: {
              usePointStyle: true,
              pointStyle: 'circle',
              boxWidth: 6,
              font: { size: 11 },
            },
          },
          tooltip: {
            enabled: true,
          },
        },
        scales: {
          x: {
            stacked: true,
            border: {
              display: false,
            },
            grid: {
              display: false,
            },
          },
          y: {
            stacked: true,
            beginAtZero: true,
            border: {
              display: false,
            },
            ticks: {
              stepSize: 5,
              precision: 0,
              font: { size: 10 },
            },
            grid: {
              color: '#eee',
            },
          },
        },
      },
    });
  }

  createMiniCharts() {
    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    // INWARD
    new Chart('inwardChart', {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            data: [20, 15, 18, 22, 17, 10],
            backgroundColor: [
              '#4e73df',
              '#6cc24a',
              '#36cfc9',
              '#f5222d',
              '#fadb14',
              '#d633ff',
            ],
            borderRadius: 4,
            borderSkipped: false,
            barThickness: 20,
          },
        ],
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 10 } },
            border: {
              display: false,
            },
          },
          y: {
            grid: { color: '#eee' },
            ticks: { font: { size: 10 } },
            border: {
              display: false,
            },
          },
        },
      },
    });
    // OUTWARD
    new Chart('outwardChart', {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            data: [22, 14, 19, 23, 16, 11],
            backgroundColor: [
              '#4e73df',
              '#6cc24a',
              '#36cfc9',
              '#f5222d',
              '#fadb14',
              '#d633ff',
            ],
            borderRadius: 4,
            borderSkipped: false,
            barThickness: 20,
          },
        ],
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 10 } },
            border: {
              display: false,
            },
          },
          y: {
            grid: { color: '#eee' },
            ticks: { font: { size: 10 } },
            border: {
              display: false,
            },
          },
        },
      },
    });
  }
  getAllNotifications() {
    this.apiService.getAllNotifications().subscribe((response: any) => {
      if (response?.status === 'SUCCESS' && Array.isArray(response.payload)) {
        this.notifications = response.payload.map((item: any) => ({
          title: item.notificationTitle,
          description: item.notificationDesc,
        }));
      } else {
        this.notifications = [];
      }

      console.log('Notifications:', this.notifications);
    });
  }
  getAllGuidelines() {
    this.apiService.getAllGuidelines().subscribe((response: any) => {
      if (response?.status === 'SUCCESS' && Array.isArray(response.payload)) {
        this.guidelines = response.payload.map((item: any) => ({
          title: item.guidelineTitle,
          description: item.guidelineDesc,
        }));
      } else {
        this.guidelines = [];
      }

      console.log('Guidelines:', this.guidelines);
    });
  }

  //RESET PASS LOGIC
  currentUser: UserProfile | null = null;
  firstTimeLoginFlag = false;
  userId:number|null=null;
  loginId = '';
  cif='';
  password = '';
  confirmPassword = '';
  passwordError = false;
  passwordErrorMsg = '';

  passwordValidator(): boolean {
    this.passwordError = false;
    this.passwordErrorMsg = '';
    if (this.password != this.confirmPassword) {
      this.passwordError = true;
      this.passwordErrorMsg = 'Passwords do not match';
      return false;
    }
    if (this.password.length < 8) {
      this.passwordError = true;
      this.passwordErrorMsg = 'Password length';
      return false;
    }
    return true;
  }
  resetPassword() {
    if(!this.passwordValidator())
      return;
    const data = {
      userId: this.userId,
      newPassword: this.password,
      afterLogin: true,
      loginId: this.loginId,
      cif: this.cif,
    }

    this.apiService.sendData(ApiEndpoints.auth.resetpassword, data).subscribe({
      next: (res: any) => {
        if (res.status == "SUCCESS") {
          if (this.currentUser) {
            sessionStorage.setItem('isFirstTimeLoginFlag', 'false');
            this.firstTimeLoginFlag = false; //close the popup
            this.showToast(
              'success',
              'Success',
              'Password updated successfully'
            );
          }
        } else {
          console.error('Password reset failed:', res.description);
          this.showToast(
              'error',
              'Error',
              res.description
            );
        }
      },
      error: (err: any) => {
        console.error('Error during password reset:', err);
        this.showToast(
              'error',
              'Error',
              'Something Went Wrong. Please Try Again Later'
            );
      },
      complete: () => {
      }
    });
  }


  // TOAST USAGE
    toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
    showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }
}
