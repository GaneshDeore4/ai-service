import { CommonModule } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-fx-deal',
  templateUrl: './fxdeal.component.html',
  styleUrls: ['./fxdeal.component.css'],
  imports: [CommonModule, FormsModule, RouterModule],
})
export class FxDealComponent implements OnDestroy {
  today = '23/03/2026';
  state: 'initial' | 'editing' | 'timer' | 'locked' = 'initial';
  dealType: 'sell' | 'purchase' = 'purchase';
  sellCurrency = 'USD';
  buyCurrency = 'INR';
  sellAmount: number = 0;
  buyAmount: number = 0;
  rate = 90.15;
  timer = 60;
  interval: any;

  converterFromAmount: number = 1;
  converterToAmount: number = 0;
  converterFromCurrency = 'USD';
  converterToCurrency = 'INR';

  convertCurrency() {
    this.converterToAmount = this.converterFromAmount * this.rate;
  }
  selectType(type: 'sell' | 'purchase') {
    this.dealType = type;
    this.state = 'editing';
  }

  onSellAmountChange() {
    this.buyAmount = this.sellAmount * this.rate;
    this.startTimer();
  }

  startTimer() {
    if (this.state === 'timer') return;
    this.state = 'timer';
    this.timer = 60;
    this.interval = setInterval(() => {
      this.timer--;
      if (this.timer <= 0) {
        clearInterval(this.interval);
      }
    }, 1000);
  }

  lockRate() {
    clearInterval(this.interval);
    this.state = 'locked';
  }

  reset() {
    this.state = 'initial';
    this.sellAmount = 0;
    this.buyAmount = 0;
  }
  ngOnDestroy() {
    clearInterval(this.interval);
  }
}
