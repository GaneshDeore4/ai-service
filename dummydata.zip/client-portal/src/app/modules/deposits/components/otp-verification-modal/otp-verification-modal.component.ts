import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalComponent } from '../../../../shared/components/modal/modal.component';
import { FormsModule } from '@angular/forms';


interface OTP{
  d1: string;
  d2: string;
  d3: string;
  d4: string;
  d5: string;
  d6: string;
}
@Component({
  selector: 'app-otp-verification-modal',
  templateUrl: './otp-verification-modal.component.html',
  styleUrls: ['./otp-verification-modal.component.css'],
  standalone: true,
  imports: [CommonModule, ModalComponent,FormsModule]
})

export class OtpVerificationModalComponent {
  enteredOtp: OTP={
    d1: '',
    d2: '',
    d3: '',
    d4: '',
    d5: '',
    d6: ''
  };
  @Output() onVerify = new EventEmitter<string>();
  @Output() onCancel = new EventEmitter<void>();
  @Output() onResend = new EventEmitter<void>();


  verify() {
    if (!this.enteredOtp.d1 || !this.enteredOtp.d2 || !this.enteredOtp.d3 || !this.enteredOtp.d4 || !this.enteredOtp.d5 || !this.enteredOtp.d6)
      return;
    //concat add elements in enteredOtp
    let otp = `${this.enteredOtp.d1}${this.enteredOtp.d2}${this.enteredOtp.d3}${this.enteredOtp.d4}${this.enteredOtp.d5}${this.enteredOtp.d6}`;
    this.onVerify.emit(otp);
  }

  resend(){
    this.onResend.emit();
  }

  cancel() {
    this.onCancel.emit();
  }
}
