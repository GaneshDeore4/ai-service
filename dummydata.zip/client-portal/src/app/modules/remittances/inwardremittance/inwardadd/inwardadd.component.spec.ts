import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InwardaddComponent } from './inwardadd.component';

describe('InwardaddComponent', () => {
  let component: InwardaddComponent;
  let fixture: ComponentFixture<InwardaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InwardaddComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InwardaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
