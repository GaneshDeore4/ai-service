import { CommonModule } from '@angular/common';

import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-inwardadd',
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './inwardadd.component.html',
  styleUrl: './inwardadd.component.css',
})
export class InwardaddComponent {
  selectedFile: File | null = null;
  selectedCurrency: string = '';
  remarks: string = '';
  remittanceCurrency: string = '';
  remittanceAmount: any = '';
  selectedRemittanceCurrency: string = '';
  showPreview = false;
  previewData: any = {};
  showSuccessPopup = false;
  purposeCodes = [
    {
      code: 'P0101',
      short: 'Export of services',
      description: 'Export proceeds received against services',
    },
    {
      code: 'P0102',
      short: 'Export of goods',
      description: 'Export proceeds received against goods',
    },
    {
      code: 'P0103',
      short: 'Export of services (IT / ITeS / consultancy)',
      description:
        'Export proceeds received against IT / ITeS / consultancy services',
    },
  ];
  currencies = [
    { code: 'USD', name: 'US Dollar' },
    { code: 'INR', name: 'Indian Rupee' },
    { code: 'EUR', name: 'Euro' },
    { code: 'CAD', name: 'Canadian Dollar' },
    { code: 'SGD', name: 'Singapore Dollar' },
  ];

  accounts = [
    {
      accountNumber: '827493017563',
      name: 'XYZ USD Account',
      currency: 'USD',
    },
    {
      accountNumber: '938475920162',
      name: 'ABS CAD Account',
      currency: 'CAD',
    },
    {
      accountNumber: '639204857392',
      name: 'STA EUR Account',
      currency: 'EUR',
    },
  ];
  fxDeals = [
    {
      fxDealId: '',
      fxAmount: '',
      utilizedAmount: '',
    },
  ];
  constructor(private router: Router) {}
  save() {
    this.previewData = {
      // DISPOSAL
      purposeCode: this.selectedPurpose?.code,
      purposeLabel: this.selectedPurpose?.short,
      description: this.selectedPurpose?.description,
      remarks: this.remarks,
      chargeType: 'OUR',
      fileName: this.selectedFile?.name || '',
      fileSize: this.selectedFile
        ? (this.selectedFile.size / 1024 / 1024).toFixed(2) + ' MB'
        : '',
      // ACCOUNT
      accountNumber: this.selectedAccount?.accountNumber,
      currency: this.selectedCurrency,
      // REMITTANCE
      remittanceCurrency: this.selectedRemittanceCurrency,
      remittanceAmount: this.remittanceAmount,
      // FX DEALS
      fxDeals: this.fxDeals,
    };
    this.showPreview = true;
  }
  submit() {
    const finalPayload = {
      ...this.previewData,
    };
    console.log('FINAL SUBMIT DATA:', JSON.stringify(finalPayload, null, 2)); // ✅ for now
    // console.log(JSON.stringify(user, null, 2));
    this.showSuccessPopup = true;
  }
  addFxDeal() {
    this.fxDeals.push({
      fxDealId: '',
      fxAmount: '',
      utilizedAmount: '',
    });
  }
  removeFxDeal(index: number) {
    this.fxDeals.splice(index, 1);
  }

  selectedAccount: any = null;
  onAccountChange(event: any) {
    const accNo = event.target.value;
    this.selectedAccount = this.accounts.find(
      (acc) => acc.accountNumber === accNo
    );
  }
  selectedPurpose: any = null;
  description: string = '';
  showTermsModal = false;
  openTerms(event: Event) {
    event.preventDefault(); // prevent instant check
    this.showTermsModal = true;
  }
  closeTerms() {
    this.showTermsModal = false;
  }
  acceptTerms() {
    this.showTermsModal = false;
  }
  onPurposeChange(event: any) {
    const selectedCode = event.target.value;
    this.selectedPurpose = this.purposeCodes.find(
      (p) => p.code === selectedCode
    );
    this.description = this.selectedPurpose?.description || '';
  }
  onFileSelect(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
    }
  }
  removeFile() {
    this.selectedFile = null;
  }
  proceed() {
    this.showSuccessPopup = false;
    this.router.navigate(['/remittance/inwardlist']);
  }
}
