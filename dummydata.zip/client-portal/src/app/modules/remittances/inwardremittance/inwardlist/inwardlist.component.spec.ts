import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InwardlistComponent } from './inwardlist.component';

describe('InwardlistComponent', () => {
  let component: InwardlistComponent;
  let fixture: ComponentFixture<InwardlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InwardlistComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InwardlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
