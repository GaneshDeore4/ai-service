import { CommonModule } from '@angular/common';
import {
  Component,
  ViewChild,
  TemplateRef,
  AfterViewInit,
} from '@angular/core';
import { Router } from '@angular/router';
import { TableComponent } from '../../../../shared/components/table/table.component';

@Component({
  selector: 'app-inwardlist',
  imports: [CommonModule, TableComponent],
  templateUrl: './inwardlist.component.html',
  styleUrl: './inwardlist.component.css',
})
export class InwardlistComponent {
  @ViewChild('statusTemplate') statusTemplate!: TemplateRef<any>;
  @ViewChild('actionTemplate') actionTemplate!: TemplateRef<any>;
  columns: any[] = [];
  constructor(private router: Router) {}
  ngAfterViewInit() {
    setTimeout(() => {
      this.columns = [
        { field: 'irReference', header: 'IR Reference' },
        { field: 'remitterName', header: 'Remitter Name' },
        { field: 'bankName', header: 'Remitter Bank Name' },
        { field: 'currency', header: 'Currency' },
        { field: 'amount', header: 'Amount' },
        {
          field: 'status',
          header: 'Status',
          template: this.statusTemplate,
        },
        { field: 'date', header: 'Date' },
        {
          field: 'action',
          header: 'Action',
          template: this.actionTemplate,
        },
      ];
    });
  }
  remittances = [
    {
      irReference: 'IR241874889748375435',
      remitterName: 'Twitter England Limited',
      bankName: 'HSBC Bank',
      currency: 'USD',
      amount: '11,000.00',
      status: 'Pending for Approval',
      date: '12/01/2026',
    },
    {
      irReference: 'IR241874889748375435',
      remitterName: 'USPA Limited',
      bankName: 'HSBC Bank',
      currency: 'USD',
      amount: '13,000.00',
      status: 'Pending for Approval',
      date: '15/01/2026',
    },
    {
      irReference: 'IR998712347812398712',
      remitterName: 'Amazon UK Pvt Ltd',
      bankName: 'Barclays Bank',
      currency: 'USD',
      amount: '25,500.00',
      status: 'Pending for Approval',
      date: '18/01/2026',
    },
    {
      irReference: 'IR778812349999123456',
      remitterName: 'Google Payments',
      bankName: 'Citibank',
      currency: 'USD',
      amount: '45,000.00',
      status: 'Pending for Approval',
      date: '19/01/2026',
    },
    {
      irReference: 'IR556612341234567890',
      remitterName: 'Meta Platforms Inc',
      bankName: 'JP Morgan',
      currency: 'USD',
      amount: '30,000.00',
      status: 'Pending for Approval',
      date: '20/01/2026',
    },
  ];
  openedit(row: any) {
    this.router.navigate(['/remittance/inwardlist/edit'], { state: { lc: row } });
  }
}
