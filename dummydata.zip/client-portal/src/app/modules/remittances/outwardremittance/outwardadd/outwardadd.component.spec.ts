import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardaddComponent } from './outwardadd.component';

describe('OutwardaddComponent', () => {
  let component: OutwardaddComponent;
  let fixture: ComponentFixture<OutwardaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OutwardaddComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OutwardaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
