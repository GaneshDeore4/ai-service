import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-account-details-modal',
  templateUrl: './account-details-modal.component.html',
  styleUrls: ['./account-details-modal.component.css'],
  standalone: true,
  imports: [CommonModule]
})
export class AccountDetailsModalComponent {
  @Input() isOpen = false;
  @Input() account: any = null;
  @Output() onClose = new EventEmitter<void>();

  close() {
    this.isOpen = false;
    this.onClose.emit();
  }
}
