import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClosureModalComponent } from './closure-modal.component';

describe('ClosureModalComponent', () => {
  let component: ClosureModalComponent;
  let fixture: ComponentFixture<ClosureModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClosureModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClosureModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
