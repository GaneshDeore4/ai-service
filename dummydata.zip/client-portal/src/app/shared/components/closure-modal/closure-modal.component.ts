import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Deposit, DepositEnquiryDetail } from '../../../core/models/banking.models';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-closure-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen">
      <div class="modal-container summary-modal">
        <div class="modal-header">
          <div>
            <h3>Premature FD Closure</h3>
            <h4>Deposit Account Details</h4>
          </div>
          <button class="close-btn" (click)="onClose.emit()">&times;</button>
        </div>
        <div class="modal-body">
          <div class="summary-grid">
            <div class="summary-item">
              <label>Cif Id</label>
              <div class="value">{{selectedEnquiry?.cifId}}</div>
            </div>
            <div class="summary-item">
              <label>Deposit Account Number</label>
              <div class="value">{{selectedEnquiry?.accountNumber}}</div>
            </div>
            <div class="summary-item">
              <label>Account open Date</label>
              <div class="value">{{formatToDDMMYYYY(selectedEnquiry?.accountOpenDate??'')}}</div>
            </div>
            <div class="summary-item">
              <label>Scheme Code</label>
              <div class="value">{{selectedEnquiry?.schemeCode}}</div>
            </div>
            <div class="summary-item">
              <label>Currency</label>
              <div class="value">{{selectedEnquiry?.currency}}</div>
            </div>
            <div class="summary-item">
              <label>Actual Maturity Date</label>
              <div class="value">{{formatToDDMMYYYY(selectedEnquiry?.maturityDate??'')}}</div>
            </div>
            <div class="summary-item">
              <label>Actual Maturity Amount</label>
              <div class="value">{{selectedEnquiry?.maturityAmount}}</div>
            </div>
            <div class="summary-item">
              <label>Deposit Period</label>
              <div class="value">{{getDeppositPeriod()}}</div>
            </div>
            <div class="summary-item">
              <label>Credit Account</label>
              <div class="value">{{selectedEnquiry?.repaymentAccount}}</div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
            <!-- <div class="reason-input-container">
                <label for="reason">Reason</label>
                <textarea [disabled]="!isReasonEditable" id="reason" name="reason" [(ngModel)]="reason" rows="3" class="reason-textarea"></textarea>
            </div> -->
            <div class="modal-footer-1">
              <!-- <button class="btn btn-reject" (click)="onAction('reject')">Reject</button> -->
            <button class="btn btn-approve" (click)="onAction()">Close FD</button>
            </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); display: flex; align-items: center; justify-content: center; z-index: 100; }
    h4{color:black}
    .modal-container { background: white; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); overflow: hidden; }
    .modal-header { padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; }
    .modal-header h3 { font-size: 14px; font-weight: 600; color: #333; }
    .close-btn { background: transparent; border: none; font-size: 20px; color: var(--primary-color); cursor: pointer; }
    .summary-modal { max-width: 500px !important; width: 90%; }
    .summary-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; padding: 20px; }
    .summary-item label { font-size: 11px; color: #999; display: block; margin-bottom: 4px; }
    .summary-item .value { font-size: 13px; font-weight: 600; color: var(--secondary-color); }
    .modal-footer { padding: 15px 20px; display: flex; justify-content: flex-end; gap: 10px; border-top: 1px solid #eee; flex-wrap: wrap; }
    .modal-footer-1 { padding: 15px 20px; display: flex; justify-content: flex-end; gap: 10px; }
    .reason-input-container { width: 100%; margin-bottom: 10px; }
    .reason-input-container label { display: block; margin-bottom: 5px; font-size: 12px; color: #555; }
    .reason-textarea { width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc; font-family: inherit; }
    .btn { padding: 8px 16px; border: none; border-radius: 4px; font-size: 13px; font-weight: 600; cursor: pointer; }
    .btn-approve { background-color: var(--primary-color, #0056b3); color: white; }
    .btn-reject { background-color: #dc3545; color: white; }
  `],

})
export class ClosureModalComponent implements OnChanges {
  @Input() isOpen = false;
  @Input() selectedDeposit: Deposit | null = null;
  @Input() selectedEnquiry: DepositEnquiryDetail | null = null;
  @Output() onClose = new EventEmitter<void>();
  @Output() checkerAction = new EventEmitter<void>();

  reason: string = '';

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['selectedDeposit'] && this.selectedDeposit) {
      this.reason = this.selectedDeposit.reason ?? '';
    }
  }
  onAction() {
   this.checkerAction.emit();
  }

  formatToDDMMYYYY(dateTime: string): string {
    if (!dateTime) {
      return '';
    }
    // Split date and time
    const [datePart] = dateTime.split(' ');
    const [year, month, day] = datePart.split('-');
    return `${day}/${month}/${year}`;
  }

  getDeppositPeriod(): string {
    return this.selectedEnquiry?.depositPeriodMonths + ' months ' + this.selectedEnquiry?.depositPeriodDays + ' days';
  }


}
