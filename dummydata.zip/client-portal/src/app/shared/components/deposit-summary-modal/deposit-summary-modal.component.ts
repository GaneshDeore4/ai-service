import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Deposit } from '../../../core/models/banking.models';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-deposit-summary-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen">
      <div class="modal-container summary-modal">
        <div class="modal-header">
          <h3>Deposit Summary</h3>
          <button class="close-btn" (click)="onClose.emit()">&times;</button>
        </div>
        <div class="modal-body">
          <div class="summary-grid">
            <div class="summary-item">
              <label>Deposit Number</label>
              <div class="value">{{ selectedDeposit?.fdId || 'N/A' }}</div>
            </div>
            <div class="summary-item">
              <label>Maturity Type</label>
              <div class="value">{{selectedDeposit?.maturityInstruction}}</div>
            </div>
            <div class="summary-item">
              <label>Principal Amount</label>
              <div class="value">{{selectedDeposit?.currency}}  {{selectedDeposit?.amount}}</div>
            </div>
            <div class="summary-item">
              <label>Interest Rate</label>
              <div class="value">{{selectedDeposit?.interestRate}}%</div>
            </div>
            <div class="summary-item">
              <label>Maturity Amount</label>
              <div class="value">{{selectedDeposit?.currency}}  {{selectedDeposit?.maturityAmount}}</div>
            </div>
            <div class="summary-item">
              <label>Status</label>
              <div class="value">{{selectedDeposit?.status}}</div>
            </div>
            <div class="summary-item">
              <label>FD Booking Date</label>
              <div class="value">16/01/2026</div>
            </div>
            <div class="summary-item">
              <label>Maturity Date</label>
              <div class="value">{{selectedDeposit?.maturityDate}}</div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
            <div class="reason-input-container">
                <label for="reason">Reason</label>
                <textarea [disabled]="!isReasonEditable" id="reason" name="reason" [(ngModel)]="reason" rows="3" class="reason-textarea"></textarea>
            </div>
            <div class="modal-footer-1" *ngIf="showCheckerButtons">
              <button class="btn btn-reject" (click)="onAction('reject')">Reject</button>
            <button class="btn btn-approve" (click)="onAction('approve')">Approve</button>
            </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); display: flex; align-items: center; justify-content: center; z-index: 100; }
    .modal-container { background: white; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); overflow: hidden; }
    .modal-header { padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; }
    .modal-header h3 { font-size: 14px; font-weight: 600; color: #333; }
    .close-btn { background: transparent; border: none; font-size: 20px; color: var(--primary-color); cursor: pointer; }
    .summary-modal { max-width: 500px !important; width: 90%; }
    .summary-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; padding: 20px; }
    .summary-item label { font-size: 11px; color: #999; display: block; margin-bottom: 4px; }
    .summary-item .value { font-size: 13px; font-weight: 600; color: var(--secondary-color); }
    .modal-footer { padding: 15px 20px; display: flex; justify-content: flex-end; gap: 10px; border-top: 1px solid #eee; flex-wrap: wrap; }
    .modal-footer-1 { padding: 15px 20px; display: flex; justify-content: flex-end; gap: 10px; }
    .reason-input-container { width: 100%; margin-bottom: 10px; }
    .reason-input-container label { display: block; margin-bottom: 5px; font-size: 12px; color: #555; }
    .reason-textarea { width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc; font-family: inherit; }
    .btn { padding: 8px 16px; border: none; border-radius: 4px; font-size: 13px; font-weight: 600; cursor: pointer; }
    .btn-approve { background-color: var(--primary-color, #0056b3); color: white; }
    .btn-reject { background-color: #dc3545; color: white; }
  `],

})
export class DepositSummaryModalComponent implements OnChanges {
  @Input() isOpen = false;
  @Input() selectedDeposit: Deposit | null = null;
  @Input() showCheckerButtons = false;
  @Input() isReasonEditable: boolean = false;
  @Output() onClose = new EventEmitter<void>();
  @Output() checkerAction = new EventEmitter<{ action: string; reason: string }>();

  reason: string = '';

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['selectedDeposit'] && this.selectedDeposit) {
      this.reason = this.selectedDeposit.reason ?? '';
    }
    if(changes['showCheckerButtons']){
      this.showCheckerButtons = this.showCheckerButtons
    }
  }
  onAction(action: string) {
    this.checkerAction.emit({ action, reason: this.reason });
  }
}
