import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-fd-receipt-modal',
  template: `
    <div class="modal-overlay" *ngIf="isOpen">
      <div class="modal-container receipt-modal">
        <div class="modal-header">
          <h3>FD Receipt</h3>
          <button class="close-btn" (click)="onClose.emit()">&times;</button>
        </div>
        <div class="modal-body p-4">
          <!-- Institution Details -->
          <div class="receipt-section mb-4">
            <h4 class="section-title">Institution Details</h4>
            <div class="receipt-grid">
              <div class="receipt-item"><label>Bank Name:</label><span>Your bank</span></div>
              <div class="receipt-item"><label>Address:</label><span>Gandhinagar, Gujarat, 382355</span></div>
              <div class="receipt-item"><label>Branch:</label><span>GIFT City</span></div>
              <div class="receipt-item"><label>IFSC:</label><span>EXBL0001234</span></div>
            </div>
          </div>

          <!-- Depositor Details -->
          <div class="receipt-section mb-4">
            <h4 class="section-title">Depositor Details</h4>
            <div class="receipt-grid">
              <div class="receipt-item"><label>Primary Holder Name:</label><span>XYZ Limited</span></div>
              <div class="receipt-item"><label>Contact Number:</label><span>+91 98765 43210 / atul&#64;xyz.co.in</span></div>
              <div class="receipt-item"><label>Customer ID:</label><span>CID0012456789</span></div>
              <div class="receipt-item"><label>PAN:</label><span>ACGHM0918D</span></div>
            </div>
          </div>

          <!-- Receipt Details -->
          <div class="receipt-section-highlight p-3">
            <h4 class="section-title text-green">Receipt Details</h4>
            <div class="receipt-grid-3">
              <div class="receipt-item"><label>Receipt No.:</label><span>{{ data?.fdId || 'N/A' }}</span></div>
              <div class="receipt-item"><label>Issue Date:</label><span>{{ (data?.createdDate | date:'dd/MM/yyyy') || 'N/A' }}</span></div>
              <div class="receipt-item"><label>FDR No.:</label><span>{{ data?.fdAccountNumber || data?.fdId || 'N/A' }}</span></div>
              <div class="receipt-item"><label>Deposit Amount:</label><span>{{ data?.currency }} {{ data?.amount | number:'1.2-2' }}</span></div>
              <div class="receipt-item"><label>Interest Rate (% p.a):</label><span>{{ data?.interestRate }}%</span></div>
              <div class="receipt-item"><label>Start Date:</label><span>{{ (data?.createdDate | date:'dd/MM/yyyy') || 'N/A' }}</span></div>
              <div class="receipt-item"><label>Maturity Date:</label><span>{{ data?.maturityDate || 'N/A' }}</span></div>
              <div class="receipt-item"><label>Maturity Amount:</label><span>{{ data?.currency }} {{ data?.maturityAmount || '0.00' | number:'1.2-2' }}</span></div>
              <div class="receipt-item"><label>Maturity Instructions:</label><span>{{ data?.maturityInstruction || 'N/A' }}</span></div>
            </div>
          </div>

          <div class="text-right mt-4 no-print">
            <button class="btn btn-primary" (click)="downloadReceipt()">
              <i class="fas fa-download mr-1"></i> Download Receipt
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.5); display: flex; align-items: center; justify-content: center; z-index: 1100; }
    .modal-container { background: white; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); overflow: hidden; }
    .modal-header { padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; }
    .modal-header h3 { font-size: 14px; font-weight: 600; color: #333; }
    .close-btn { background: transparent; border: none; font-size: 20px; color: var(--primary-color); cursor: pointer; }
    .receipt-modal { padding: 15px; max-width: 800px !important; width: 95%; }
    .section-title { font-size: 12px; font-weight: 600; margin-bottom: 12px; color: var(--secondary-color); }
    .receipt-grid { display: grid; grid-template-columns: 1fr 1.5fr; gap: 10px; }
    .receipt-item { display: flex; gap: 8px; font-size: 11px; margin-bottom: 5px; }
    .receipt-item label { color: #888; white-space: nowrap; }
    .receipt-item span { font-weight: 500; color: var(--secondary-color); }
    .receipt-section-highlight { padding: 10px; background: #f1f8f1; border: 1px solid #d0e8d1; border-radius: 8px; }
    .receipt-grid-3 { display: grid; grid-template-columns: 1fr 1fr 1.5fr; gap: 10px; }
    .text-green { color: var(--primary-color) !important; }
    .text-right { text-align: right; }
    @media print {
      body { visibility: hidden; background: white !important; }
      .modal-overlay { position: absolute; left: 0; top: 0; width: 100%; height: 100%; background: white !important; visibility: visible; }
      .receipt-modal { visibility: visible; position: absolute; left: 0; top: 0; width: 100%; border: none; box-shadow: none; padding: 0; margin: 0; }
      .no-print, .close-btn, .modal-header h3::after { display: none !important; }
      .receipt-section-highlight { background: #f1f8f1 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      /* Ensure text is black for clarity */
      * { color: black !important; }
      .text-green { color: #28a745 !important; }
    }
  `],
  standalone: true,
  imports: [CommonModule]
})
export class FdReceiptModalComponent {
  @Input() isOpen = false;
  @Input() data: any;
  @Output() onClose = new EventEmitter<void>();

  downloadReceipt() {
    window.print();
  }
}
