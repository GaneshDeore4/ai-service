import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FdRoadmapComponent } from './fd-roadmap.component';

describe('FdRoadmapComponent', () => {
  let component: FdRoadmapComponent;
  let fixture: ComponentFixture<FdRoadmapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FdRoadmapComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FdRoadmapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
