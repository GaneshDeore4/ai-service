import { NgClass, NgFor, NgIf } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { Roadmap, RoadmapNode } from '../../../core/models/banking.models';

@Component({
  selector: 'app-fd-roadmap',
  standalone: true,
  imports: [NgIf, NgFor, NgClass],
  templateUrl: './fd-roadmap.component.html',
  styleUrl: './fd-roadmap.component.css'
})
export class FdRoadmapComponent implements OnChanges {
  @Input() isOpen = false;
  @Input() data: Roadmap | null = null;
  @Output() onClose = new EventEmitter<void>();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data']) {
      if (this.data && this.data.paths) {
        this.data.paths.forEach(path => {
          if (path.sequential === false && path.nodes) {
            const verifierIndex = path.nodes.findIndex(node => node.groupName === 'Client Verifier');
            if (verifierIndex > 0) {
              const verifierNode = path.nodes.splice(verifierIndex, 1)[0];
              path.nodes.unshift(verifierNode);
            }

            const releaserIndex = path.nodes.findIndex(node => node.groupName === 'Client Releaser');
            if (releaserIndex > -1 && releaserIndex < path.nodes.length - 1) {
              const releaserNode = path.nodes.splice(releaserIndex, 1)[0];
              path.nodes.push(releaserNode);
            }
          }
        });
      }
    }
  }

  closeModal() {
    this.onClose.emit();
  }

  getStepClass(node: RoadmapNode): string {
    let classes = '';

    if (node.state === 'APPROVED') classes += ' approved';
    if (node.state === 'PENDING') classes += ' pending';
    if (node.state === 'WAITING') classes += ' waiting';
    if (node.state === 'VIEW_ONLY') classes += ' view-only';
    if (node.current) classes += ' current';

    return classes;
  }

  getConnectorClass(current: RoadmapNode): string {
    if (current.state === 'APPROVED') return 'approved';
    if (current.state === 'PENDING') return 'pending';
    if (current.state === 'VIEW_ONLY') return 'view-only';
    return '';
  }

  getDisplayName(node: RoadmapNode): string {
    if (node.groupName === 'Client Releaser') {
      return 'Releaser';
    }
    if (node.groupName === 'Client Verifier') {
      return 'Verifier';
    }
    return node.groupName ?? '';
  }
}
