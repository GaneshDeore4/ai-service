import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnDestroy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface OTP{
  d1: string;
  d2: string;
  d3: string;
  d4: string;
  d5: string;
  d6: string;
}
@Component({
  selector: 'app-otp',
  template: `
    <div class="modal-overlay" *ngIf="isOpen">
      <div class="modal-container otp-modal" *ngIf="!showSuccess">
        <button class="close-btn" (click)="closePopup()">&times;</button>
        <div class="modal-body text-center p-5">
          <p class="mb-4 text-muted">
            OTP has been sent to your registered mobile Number<br />It
            is valid only for the next 100 seconds.
          </p>

          <div class="resend-success-alert mb-3" *ngIf="showResendSuccess">
            <i class="fas fa-check-circle mr-1"></i> OTP Resent Successfully
          </div>
          <!-- <div class="timer-container mb-4">
            <svg class="timer-svg" viewBox="0 0 100 100">
              <circle class="timer-bg" cx="50" cy="50" r="45"></circle>
              <circle
                class="timer-progress"
                cx="50"
                cy="50"
                r="45"
                [style.stroke-dashoffset]="dashOffset"
              ></circle>
            </svg>
            <div class="timer-text">{{ timeLeft }}</div>
          </div> -->

          <div class="otp-inputs mb-4">
            <input type="text" maxlength="1" #i1 (keyup)="move(i1, i2)" [(ngModel)]="enteredOtp.d1">
            <input type="text" maxlength="1" #i2 (keyup)="move(i2, i3)" [(ngModel)]="enteredOtp.d2">
            <input type="text" maxlength="1" #i3 (keyup)="move(i3, i4)" [(ngModel)]="enteredOtp.d3">
            <input type="text" maxlength="1" #i4 (keyup)="move(i4, i5)" [(ngModel)]="enteredOtp.d4">
            <input type="text" maxlength="1" #i5 (keyup)="move(i5, i6)" [(ngModel)]="enteredOtp.d5">
            <input type="text" maxlength="1" #i6 [(ngModel)]="enteredOtp.d6">
          </div>

          <div class="modal-actions-horizontal">
            <button class="btn btn-outline" (click)="resend()">
              Resend OTP
            </button>
            <button class="btn btn-primary" (click)="verify()">Submit</button>
          </div>
        </div>
      </div>

      <!-- Success State -->
      <!-- <div class="modal-container success-modal" *ngIf="showSuccess">
        <div class="modal-body text-center p-5">
          <div class="success-icon mb-3">
            <i class="far fa-check-circle"></i>
          </div>
          <h3 class="text-green mb-2">Success</h3>
          <p class="mb-4" style="font-size: 16px">Your FD has been Created</p>
          <div class="text-muted text-sm mb-4">
            Reference Number : 00221133445<br />
            FD receipt no. 23456
          </div>
          <button class="btn btn-primary px-5" style="width: 100px;"(click)="done()">Okay</button>
        </div>
      </div> -->
    </div>
  `,
  styles: [
    `
      .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1200;
      }
      .modal-container {
        width: 350px;
        position: relative;
        background: white;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        overflow: hidden;
        padding: 20px;
      }
      .otp-modal,
      .success-modal {
        width: 350px;
        border-radius: 12px;
      }
      .close-btn {
        position: absolute;
        top: 15px;
        right: 15px;
        background: transparent;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: #999;
      }
      .close-btn:hover {
        color: #333;
      }
      .timer-container {
        position: relative;
        width: 60px;
        height: 60px;
        margin: 0 auto;
        margin-bottom: 10px
      }
      .timer-svg {
        transform: rotate(-90deg);
      }
      .timer-bg {
        fill: none;
        stroke: #eee;
        stroke-width: 8;
      }
      .timer-progress {
        fill: none;
        stroke: var(--primary-color);
        stroke-width: 8;
        stroke-dasharray: 283;
        transition: stroke-dashoffset 1s linear;
      }
      .timer-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 18px;
        font-weight: bold;
        color: var(--secondary-color);
      }
      .otp-inputs {
        display: flex;
        gap: 10px;
        justify-content: center;
      }
      .otp-inputs input {
        width: 45px;
        height: 45px;
        text-align: center;
        font-size: 20px;
        font-weight: 600;
        border: 1px solid #ddd;
        border-radius: 8px;
      }
      .modal-actions-horizontal {
        display: flex;
        gap: 15px;
      }
      .modal-actions-horizontal button {
        flex: 1;
        padding: 10px;
        border-radius: 8px;
        font-weight: 600;
      }
      .success-icon {
        font-size: 60px;
        color: var(--primary-color);
      }
      .text-green {
        font-size: 20px;

        color: var(--primary-color);
      }
      .text-sm {
        font-size: 13px;
      }
      .resend-success-alert {
        background: #d4edda;
        color: #155724;
        padding: 10px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
      }
    `,
  ],
  standalone: true,
  imports: [CommonModule,FormsModule]
})
export class OtpComponent implements OnInit, OnDestroy {
  @Input() isOpen = false;
  @Output() onClose = new EventEmitter<void>();
  @Output() onVerify = new EventEmitter<string>();

  enteredOtp: OTP={
    d1: '',
    d2: '',
    d3: '',
    d4: '',
    d5: '',
    d6: ''
  };
  timeLeft = 100;
  showSuccess = false;
  showResendSuccess = false;
  private timer: any;

  get dashOffset() {
    return 283 - (283 * this.timeLeft) / 100;
  }

  ngOnInit() {
    this.startTimer();
  }

  startTimer() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => {
      if (this.timeLeft > 0) this.timeLeft--;
      else clearInterval(this.timer);
    }, 1000);
  }

  move(curr: any, next: any) {
    if (curr.value.length === 1) next.focus();
  }

  resend() {
    this.timeLeft = 100;
    this.showResendSuccess = true;
    this.startTimer();
    setTimeout(() => (this.showResendSuccess = false), 3000);
  }

  verify() {
    this.showSuccess = true;
    if (!this.enteredOtp.d1 || !this.enteredOtp.d2 || !this.enteredOtp.d3 || !this.enteredOtp.d4 || !this.enteredOtp.d5 || !this.enteredOtp.d6)
      return;
    //concat add elements in enteredOtp
    let otp:string = `${this.enteredOtp.d1}${this.enteredOtp.d2}${this.enteredOtp.d3}${this.enteredOtp.d4}${this.enteredOtp.d5}${this.enteredOtp.d6}`;
    this.onVerify.emit(otp);
  }

  done() {
    this.showSuccess = false;
    this.isOpen = false;
    this.onVerify.emit("");
  }

  closePopup() {
    this.isOpen=false;
    this.timeLeft = 100;
    this.showSuccess = false;
    this.showResendSuccess = false;
    this.enteredOtp={
    d1: '',
    d2: '',
    d3: '',
    d4: '',
    d5: '',
    d6: ''
  };
  this.onClose.emit();
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
  }
}
