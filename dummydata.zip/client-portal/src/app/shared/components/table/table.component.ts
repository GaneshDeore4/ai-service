import { Component, Input, ContentChild, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Output, EventEmitter } from '@angular/core';

interface TableColumn {
  field: string;
  header: string;
  template?: TemplateRef<any>; // 👈 optional
}

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
  standalone: true,
  imports: [CommonModule],
})
export class TableComponent {
  @Input() title: string = '';
  @Input() data: any[] = [];
  @Input() columns: TableColumn[] = [];
  @Input() showPagination: boolean = true;
  @Input() paginationType: 'client' | 'server' = 'server';
  @Output() pageSizeChange = new EventEmitter<number>();
  @Output() next = new EventEmitter<void>();

  currentPage: number = 1;
  pageSize: number = 10;

  get paginatedData(): any[] {
    if (this.paginationType === 'server') {
      return this.data; // data is already a single page
    }
    const start = (this.currentPage - 1) * this.pageSize;
    const end = start + this.pageSize;
    return this.data.slice(start, end);
  }

  get totalPages(): number {
    if (this.paginationType === 'server') {
      // For server pagination, we assume the parent handles the end of data (e.g. continueToken)
      return this.currentPage + 1;
    }
    return Math.ceil(this.data.length / this.pageSize);
  }

  get startIndex(): number {
    if (this.paginationType === 'server') {
      return (this.currentPage - 1) * this.pageSize + 1;
    }
    return this.data.length === 0
      ? 0
      : (this.currentPage - 1) * this.pageSize + 1;
  }

  get endIndex(): number {
    if (this.paginationType === 'server') {
      return this.currentPage * this.pageSize; // Approximation for display
    }
    return Math.min(this.currentPage * this.pageSize, this.data.length);
  }

  nextPage() {
    if (this.paginationType === 'server') {
      this.next.emit();
      return;
    }

    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    } else {
      // If client-side reaches end, still allow 'next' for hybrid cases (e.g. load more)
      this.next.emit();
    }
  }

  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  onPageSizeChange(event: any) {
    const size = Number(event.target.value);
    this.pageSize = size;
    this.currentPage = 1;
    this.pageSizeChange.emit(size);
  }
}
