import { NgFor, NgIf, NgStyle } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';
import { StatusService } from '../../../core/services/statusService/status.service';
import { FormsModule } from '@angular/forms';
import { FloatLabel, FloatLabelModule } from 'primeng/floatlabel';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MultiSelectModule } from 'primeng/multiselect';
import { PAGE_SIZE } from '../../../core/constants/Constants';
import { Product } from '../../../shared/components/product-integration/product-integration.component';

@Component({
  selector: 'app-tbl',
  imports: [
    NgIf,
    NgFor,
    NgStyle,
    FormsModule,
    FloatLabel,
    MatFormFieldModule,
    MultiSelectModule,
    FloatLabelModule,
  ],
  templateUrl: './tbl.component.html',
  styleUrl: './tbl.component.css',
})
export class TblComponent implements OnChanges {
  @Input()
  showIcon: Boolean = false;

  @Input()
  title!: string;

  @Input()
  headers!: { key: string; value: string }[];

  @Input()
  rows: any = [];

  @Input()
  columnWidths!: string[];

  @Input()
  actions!: string[];

  @Input()
  enableCheckboxes: boolean = false;

  @Input()
  selectedIndices: number[] = [];

  @Input()
  isServerSide: boolean = false;

  @Input()
  totalRecords: number = 0;

  @Input()
  currentPage: number = 1;

  @Input()
  pageSize: number = PAGE_SIZE;

  @Input()
  tableId?: string;

  @Output()
  selectedIndicesChange = new EventEmitter<number[]>();

  @Output()
  eyeClicked = new EventEmitter<{ row: any; index: number }>();

  @Output()
  editClicked = new EventEmitter<{ row: any; index: number }>();

  @Output()
  auditClicked = new EventEmitter<{ row: any; index: number }>();

  @Output()
  deleteClicked = new EventEmitter<{ row: any; index: number }>();

  @Output()
  replicateClicked = new EventEmitter<{ row: any }>();

  @Output()
  viewUsers = new EventEmitter<{ row: any }>();

  @Output()
  dropdownChanged = new EventEmitter<{
    row: any;
    key: string;
    newValue: any;
    index: number;
  }>();

  @Input()
  dropdownColumn?: string;

  @Input()
  dropdownOptions: any[] = [];

  @Input()
  dropdownDisplayKey?: string;

  @Input() selectColumn?: string; // 👈 which column is single select
  @Input() selectOptions: any[] = [];
  @Input() selectDisplayKey?: string;

  @Input()
  linkColumns: string[] = [];

  @Output()
  linkClick = new EventEmitter<{ row: any; key: string; index: number }>();

  @Output()
  pageChange = new EventEmitter<{
    page: number;
    pageSize: number;
    tableId?: string;
  }>();

  @Output()
  checkboxChanged = new EventEmitter<{
    row: any;
    key: string;
    checked: boolean;
    index: number;
  }>();

  @Output() selectChanged = new EventEmitter<{
    row: any;
    key: string;
    value: any;
    index: number;
  }>();

  onToggleChange(row: any, index: number) {
    this.selectChanged.emit({
      row: row,
      key: 'active',
      value: row.active,
      index: index,
    });
  }

  onSelectChange(row: any, key: string, value: any, index: number) {
    this.selectChanged.emit({ row, key, value, index });
  }

  constructor(private statusService: StatusService) {
    this.updatePagination();
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (
      changes['rows'] ||
      changes['totalRecords'] ||
      changes['currentPage'] ||
      changes['pageSize']
    ) {
      this.updatePagination();
    }
  }
  // pagination logic start
  total = 0;
  start: number = 1;
  end: number = PAGE_SIZE;
  paginatedData: any[] = [];
  updatePagination() {
    if (this.isServerSide) {
      this.paginatedData = this.rows || [];
      this.total = this.totalRecords || 0;
      this.start =
        this.total === 0 ? 0 : (this.currentPage - 1) * this.pageSize + 1;
      this.end = Math.min(this.currentPage * this.pageSize, this.total);
    } else {
      const startIndex = (this.currentPage - 1) * this.pageSize;
      const endIndex = startIndex + this.pageSize;
      this.paginatedData = this.rows
        ? this.rows.slice(startIndex, endIndex)
        : [];
      this.total = this.rows ? this.rows.length : 0;
      this.start = this.total === 0 ? 0 : startIndex + 1;
      this.end = Math.min(this.currentPage * this.pageSize, this.total);
    }
  }

  nextPage() {
    const maxPage = Math.ceil(this.total / this.pageSize);
    if (this.currentPage < maxPage) {
      if (this.isServerSide) {
        this.pageChange.emit({
          page: this.currentPage + 1,
          pageSize: this.pageSize,
          tableId: this.tableId,
        });
      } else {
        this.currentPage++;
        this.updatePagination();
      }
    }
  }

  prevPage() {
    if (this.currentPage > 1) {
      if (this.isServerSide) {
        this.pageChange.emit({
          page: this.currentPage - 1,
          pageSize: this.pageSize,
          tableId: this.tableId,
        });
      } else {
        this.currentPage--;
        this.updatePagination();
      }
    }
  }

  startPage() {
    if (this.currentPage > 1) {
      if (this.isServerSide) {
        this.pageChange.emit({
          page: 1,
          pageSize: this.pageSize,
          tableId: this.tableId,
        });
      } else {
        this.currentPage = 1;
        this.updatePagination();
      }
    }
  }

  endPage() {
    const maxPage = Math.ceil(this.total / this.pageSize);
    if (this.currentPage < maxPage) {
      if (this.isServerSide) {
        this.pageChange.emit({
          page: maxPage,
          pageSize: this.pageSize,
          tableId: this.tableId,
        });
      } else {
        this.currentPage = maxPage;
        this.updatePagination();
      }
    }
  }
  // pagination logic end

  onEyeClicked(row: any, index: number) {
    this.eyeClicked.emit({ row, index });
  }
  onEditClicked(row: any, index: number) {
    this.editClicked.emit({ row, index });
  }
  onAuditClicked(row: any, index: number) {
    this.auditClicked.emit({ row, index });
  }
  onDeleteClicked(row: any, index: number) {
    this.deleteClicked.emit({ row, index });
  }
  onReplicateClicked(row: any) {
    this.replicateClicked.emit(row);
  }
  onViewUsersClick(row: any) {
    this.viewUsers.emit(row);
  }
  actionIncluded(action: string): boolean {
    return this.actions && this.actions.includes(action);
  }

  onDropdownChange(row: any, key: string, newValue: any, index: number) {
    this.dropdownChanged.emit({
      row: row,
      key: key,
      newValue: newValue,
      index: index,
    });
  }

  onCheckboxToggled(row: Product, key: string, event: any, index: number) {
    this.checkboxChanged.emit({
      row: row,
      key: key,
      checked: event.target.checked,
      index: index,
    });
  }

  isLinkColumn(key: string): boolean {
    return this.linkColumns.includes(key);
  }

  onLinkClick(row: any, key: string, index: number) {
    this.linkClick.emit({ row, key, index });
  }

  compareDropdownOptions(o1: any, o2: any): boolean {
    return o1 && o2 ? o1.categoryId === o2.categoryId : o1 === o2;
  }

  // Checkbox logic
  isAllSelected(): boolean {
    return (
      this.selectedIndices.length === this.rows.length && this.rows.length > 0
    );
  }

  toggleAll() {
    if (this.isAllSelected()) {
      this.selectedIndices = [];
    } else {
      this.selectedIndices = Array.from(
        { length: this.rows.length },
        (_, i) => i
      );
    }
    this.selectedIndicesChange.emit(this.selectedIndices);
  }

  isSelected(globalIndex: number): boolean {
    return this.selectedIndices.includes(globalIndex);
  }

  toggleRow(globalIndex: number) {
    const index = this.selectedIndices.indexOf(globalIndex);
    if (index > -1) {
      this.selectedIndices.splice(index, 1);
    } else {
      this.selectedIndices.push(globalIndex);
    }
    this.selectedIndicesChange.emit([...this.selectedIndices]);
  }

  // getValue(row: any, header: { key: string; value: string }) {
  //   // if(header.value=='Status'){
  //   //   return this.statusService.getStatus(row['tnxStatCode'],row['tnxTypeCode']);
  //   // }
  //   // else
  //   // if else for event type in authorisation page
  //   if (header.key === 'eventType') {
  //     if (row[header.key].length > 1) return 'All';
  //     else return row[header.key][0];
  //   }
  //   if (row[header.key] === true) return 'Yes';
  //   else if (row[header.key] === false) return 'No';
  //   return row[header.key];
  // }

  getValue(row: any, header: { key: string; value: string }) {
    if (header.key === 'validTill' && row[header.key]) {
      const date = new Date(row[header.key]);
      return date.toLocaleDateString(); // ✅ formatted date
    }
    // if (header.key === 'eventType') {
    //   if (row[header.key].length > 1) return 'All';
    //   else return row[header.key][0];
    // }
    if (row[header.key] === true) return 'Yes';
    else if (row[header.key] === false) return 'No';
    return row[header.key];
  }
}
