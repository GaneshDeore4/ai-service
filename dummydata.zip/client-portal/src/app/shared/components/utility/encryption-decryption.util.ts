export class EncryptionDecryptionUtil {
  private static AES_KEY_SIZE = 256;
  private static GCM_IV_SIZE = 12;
  private static GCM_TAG_SIZE = 128;
  // Generate AES Key (Base64)
  static async getKey(): Promise<string> {
    const key = await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: this.AES_KEY_SIZE },
      true,
      ['encrypt', 'decrypt']
    );
    const rawKey = await crypto.subtle.exportKey('raw', key);
    return this.arrayBufferToBase64(rawKey);
  }
  // Generate IV (Base64)
  static getIV(): string {
    const iv = crypto.getRandomValues(new Uint8Array(this.GCM_IV_SIZE));
    return this.arrayBufferToBase64(iv.buffer);
  }
  // 🔐 Encrypt JSON Payload
  static async encryptJSON(
    payload: any,
    base64SecretKey: string,
    base64Iv: string
  ): Promise<string> {
    const jsonString = JSON.stringify(payload);
    return this.encryptPayload(jsonString, base64SecretKey, base64Iv);
  }
  // 🔓 Decrypt JSON Payload
  static async decryptJSON<T>(
    cipherPayload: string,
    base64SecretKey: string,
    base64Iv: string
  ): Promise<T> {
    const decryptedString = await this.decryptPayload(
      cipherPayload,
      base64SecretKey,
      base64Iv
    );
    return JSON.parse(decryptedString) as T;
  }
  // 🔐 Encrypt string
  private static async encryptPayload(
    plainPayload: string,
    base64SecretKey: string,
    base64Iv: string
  ): Promise<string> {
    const keyBytes = this.base64ToArrayBuffer(base64SecretKey);
    const ivBytes = this.base64ToArrayBuffer(base64Iv);
    if (keyBytes.byteLength !== 32) {
      throw new Error('AES256 key must be 32 bytes');
    }
    if (ivBytes.byteLength !== 12) {
      throw new Error('GCM IV must be 12 bytes');
    }
    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'AES-GCM' },
      false,
      ['encrypt']
    );
    const encodedPayload = new TextEncoder().encode(plainPayload);
    const cipherBuffer = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: ivBytes,
        tagLength: this.GCM_TAG_SIZE,
      },
      cryptoKey,
      encodedPayload
    );
    return this.arrayBufferToBase64(cipherBuffer);
  }
  // 🔓 Decrypt string
  private static async decryptPayload(
    cipherPayload: string,
    base64SecretKey: string,
    base64Iv: string
  ): Promise<string> {
    const cipherBytes = this.base64ToArrayBuffer(cipherPayload);
    const keyBytes = this.base64ToArrayBuffer(base64SecretKey);
    const ivBytes = this.base64ToArrayBuffer(base64Iv);
    if (keyBytes.byteLength !== 32) {
      throw new Error('Invalid AES256 key length');
    }
    if (ivBytes.byteLength !== 12) {
      throw new Error('Invalid GCM IV length');
    }
    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'AES-GCM' },
      false,
      ['decrypt']
    );
    const plainBuffer = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: ivBytes,
        tagLength: this.GCM_TAG_SIZE,
      },
      cryptoKey,
      cipherBytes
    );
    return new TextDecoder().decode(plainBuffer);
  }
  // Helpers
  private static arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }
  private static base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }
}
