// src/app/utils/rsa-key.util.ts
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root',
})
export class RsaKeyUtil {
  private readonly PUBLIC_KEY_PEM = `-----BEGIN CERTIFICATE-----
  MIIDoTCCAomgAwIBAgIUINReb4v8A4v2gSySqsRzK1ep71IwDQYJKoZIhvcNAQEL
  BQAwYDELMAkGA1UEBhMCSU4xCzAJBgNVBAgMAk1IMQ8wDQYDVQQHDAZNdW1iYWkx
  FjAUBgNVBAoMDUluZHVzSW5kIEJhbmsxGzAZBgNVBAMMEnBheWxvYWQtZW5jcnlw
  dGlvbjAeFw0yNjA0MjAxMTI0NTVaFw0zOTEyMjgxMTI0NTVaMGAxCzAJBgNVBAYT
  AklOMQswCQYDVQQIDAJNSDEPMA0GA1UEBwwGTXVtYmFpMRYwFAYDVQQKDA1JbmR1
  c0luZCBCYW5rMRswGQYDVQQDDBJwYXlsb2FkLWVuY3J5cHRpb24wggEiMA0GCSqG
  SIb3DQEBAQUAA4IBDwAwggEKAoIBAQC5HTowNPx0J0NyptuR/DLmiT91TaBCFmrL
  b/NSRU7NpQ2aUqCDAXf5IixICAitXy1z35U/FVWMRiYjfwRmDVuFmSF1NVFeg8EW
  3R+VOcJUukON5026C0Nvo6GdBaZE1zYI0k0d736UkhVAN72lA0zyLglX4NR4L3YT
  BND/lTYcQTUd9sqYiPqjg0s86fl34LWntZOndTz7t6VOnsam+9dX7p/Oc16ue3sj
  zsW4KE4C/aEUpIlIFMntjZweNO5ce2Q0EBY3FCM/I5YHQmiNd8coqjHOVG4C3ElY
  AQaBdB/2yBfYGOanTeTiLH3aUyA7JbKFNdbmVjDvcRztZPzfbH7jAgMBAAGjUzBR
  MB0GA1UdDgQWBBR2oEIeMgkLbQy0V1+Z5lEPMS8HWzAfBgNVHSMEGDAWgBR2oEIe
  MgkLbQy0V1+Z5lEPMS8HWzAPBgNVHRMBAf8EBTADAQH/MA0GCSqGSIb3DQEBCwUA
  A4IBAQAAG4HtLtWljgn9YsIReIpzQLkythYkymibJaHHB9y6fIXhUQY/kZSkmdkh
  ZSUwVHVrnRioPoBurjPzXKiEPkdxX9TJZrCC9TBkTLuBNCfLJXb6QfPRaYCWCTF7
  lHHJdyK1n974SydRZBTqddSyTXn/ao8dwvbjj5790fQP5lYPlFhRzlxumHBdYdBC
  uALU7tQfL/Piy/Kuee6Ra2hKTnHKxSin1LrvfLn8//Ybdc8IYGDn8Z3ah9095E4v
  zBpte1XdGKUZviLB/k5sej1YL48DIjKb9d5a76Occ1oB1TwMWkyZ51t5L8FVkfda
  Tnn8YoAYBTtNby4iHbvARJq2+kZV
  -----END CERTIFICATE-----
  `;
  private readonly PRIVATE_KEY_PEM = `-----BEGIN PRIVATE KEY-----
  MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC5HTowNPx0J0Ny
  ptuR/DLmiT91TaBCFmrLb/NSRU7NpQ2aUqCDAXf5IixICAitXy1z35U/FVWMRiYj
  fwRmDVuFmSF1NVFeg8EW3R+VOcJUukON5026C0Nvo6GdBaZE1zYI0k0d736UkhVA
  N72lA0zyLglX4NR4L3YTBND/lTYcQTUd9sqYiPqjg0s86fl34LWntZOndTz7t6VO
  nsam+9dX7p/Oc16ue3sjzsW4KE4C/aEUpIlIFMntjZweNO5ce2Q0EBY3FCM/I5YH
  QmiNd8coqjHOVG4C3ElYAQaBdB/2yBfYGOanTeTiLH3aUyA7JbKFNdbmVjDvcRzt
  ZPzfbH7jAgMBAAECggEBALPTmcBU6N4pelM5ltmlZwkfUT8yDrnErzA76+MDIz+Q
  1LsTA4zgc1zY/q1m6I8Lg8sp6wFiRz3Cs7AN5wcAeOU60g7bodUwJvaADvtXJdpL
  K+8BQTe3U2ZzTj+Mym3bp0lAitvG2W+Yzf4ZaCiSIUCuyjLNXXn3mTt2lVWD7RHZ
  +UCrSN6Lcc0Q21EoIZMC7cOKGZazz31sTFiN63Ly91cooAXiomsnryfa4pxJxl4s
  mLk+HaGm62e3c0q+LFM33THw1T8i9Y9pW0PUCAVOF2N4Nb3Kw5Ej6/n9bZA76xLH
  O1Coc7Tff6tXVu8c2STw1qDYyV9rSwYdIwNqsxsZEVECgYEA8pwGgcj+T9/p+/Fs
  SuyOKWJi8WcMZPTC3t2CkE4t0YKvTK806Vv8LtsYzeOcGOkVbPgH4fsmGse05aYT
  W2unMczJfZkgO8WZl7owMOGLRbCU04fL6TOkROlW4zpSfVxHhVk278ntuxmWPDg/
  kKUUtBLDuvhycrUYPZjAqTAMGYsCgYEAw1TQ92GTqi3P7A0llfR3gJRox/1r2tdJ
  mJgteYHIFy/1VCIf2lX5nOyJQpzuV6yjpSXow7Cm8cYneyVeOimX4CAioZN2BLr8
  ZsmIkMfZfc7DRhGdP/cpdOW20WYMGvFQv+K68U5tM4f9IDAwbEUqwB9Aq2ASmDQI
  kUm0r7pH6wkCgYBd/3XF80oVSHwv0WpT3TN3dVdAkNyMgQi/sLNVlfTKqAejfn7R
  q4IZ5WnG29kvDZ/viGoFdHlfBuFf2OjHEv7EnMO0lg+XGQhZcRoa1khPyArhqkun
  HwsWaBHyGDa9u3M6h0ZxwZsKUu+ShXibYlqTKnILjxdIukGaHAUJiEQn4QKBgQCi
  d/bD/P5ky2wpLBo6KzgG0+p/hhNi2DUX3mPcsA0s9C/7hdK2uVJAqyHULVG1zRvk
  bq63rkR9z1LhhAhnGleADVqgyFWew6TTHgggXIpTsVoM+vOv07ZAzB0O+PFSq6t9
  n2nc8l20QgVR86MjOzi+yn/wy51LyePibMsEa04MeQKBgQC02l3GOB+Yc1c9U21p
  xuHgolsmXF5vKCtHHsBUK+Qo+sFvyHQQEshiA9DB4QG4UyArIVXeG+uTCHnLC3uL
  ogeN3DmDdwJ4tlRQJt7mPGLXlX2I99rARA/vwGiMp4ZFCBn6xV/CLcQcrF6Jhj8J
  1cz4vNlYGMv7Y23n7VnM2RaX3Q==
  -----END PRIVATE KEY-----
  `;
  constructor() {}
  // ─── ENCRYPT ────────────────────────────────────────────────
  async encryptAESKeyFromBase64(base64AesKey: string): Promise<string> {
    const publicKey = await this.loadPublicKey();
    // ✅ Pass raw 32 bytes directly — no import/export round-trip
    const aesKeyBytes = this.base64ToArrayBuffer(base64AesKey);
    const encryptedKey = await crypto.subtle.encrypt(
      { name: 'RSA-OAEP' }, // ✅ SHA-256 + MGF1-SHA-256 matches Java
      publicKey,
      aesKeyBytes
    );
    return this.arrayBufferToBase64(encryptedKey);
  }
  // ─── DECRYPT ────────────────────────────────────────────────
  async decryptAESKeyFromBase64(encryptedKeyBase64: string): Promise<string> {
    const privateKey = await this.loadPrivateKey();
    const encryptedBytes = this.base64ToArrayBuffer(encryptedKeyBase64);
    const aesKeyBytes = await crypto.subtle.decrypt(
      { name: 'RSA-OAEP' }, // ✅ Matches Java
      privateKey,
      encryptedBytes
    );
    return this.arrayBufferToBase64(aesKeyBytes);
  }
  async decryptAESKey(
    encryptedKeyBase64: string,
    privateKey: CryptoKey
  ): Promise<CryptoKey> {
    const encryptedBytes = this.base64ToArrayBuffer(encryptedKeyBase64);
    const aesKeyBytes = await crypto.subtle.decrypt(
      { name: 'RSA-OAEP' },
      privateKey,
      encryptedBytes
    );
    return crypto.subtle.importKey(
      'raw',
      aesKeyBytes,
      { name: 'AES-GCM' },
      true,
      ['encrypt', 'decrypt']
    );
  }
  // ─── LOAD KEYS ──────────────────────────────────────────────
  async loadPublicKey(): Promise<CryptoKey> {
    return this.importPublicKeyFromCert(this.PUBLIC_KEY_PEM);
  }
  async loadPrivateKey(): Promise<CryptoKey> {
    const pemBody = this.PRIVATE_KEY_PEM.replace(
      /-----BEGIN PRIVATE KEY-----/,
      ''
    )
      .replace(/-----END PRIVATE KEY-----/, '')
      .replace(/-----BEGIN RSA PRIVATE KEY-----/, '')
      .replace(/-----END RSA PRIVATE KEY-----/, '')
      .replace(/\s+/g, '');
    const keyDer = this.base64ToArrayBuffer(pemBody);
    return crypto.subtle.importKey(
      'pkcs8',
      keyDer,
      {
        name: 'RSA-OAEP' as const,
        hash: { name: 'SHA-256' }, // ✅ Matches Java OAEPWithSHA-256AndMGF1Padding
      },
      true,
      ['decrypt']
    );
  }
  // ─── CERT PARSING ───────────────────────────────────────────
  private async importPublicKeyFromCert(certPem: string): Promise<CryptoKey> {
    const pemBody = certPem
      .replace(/-----BEGIN CERTIFICATE-----/, '')
      .replace(/-----END CERTIFICATE-----/, '')
      .replace(/\s+/g, '');
    const certDer = new Uint8Array(this.base64ToArrayBuffer(pemBody));
    const spkiDer = this.extractSPKIFromCert(certDer);
    return crypto.subtle.importKey(
      'spki',
      spkiDer,
      {
        name: 'RSA-OAEP' as const,
        hash: { name: 'SHA-256' }, // ✅ Matches Java OAEPWithSHA-256AndMGF1Padding
      },
      true,
      ['encrypt']
    );
  }
  private extractSPKIFromCert(certDer: Uint8Array): ArrayBuffer {
    let offset = 0;
    offset = this.skipTag(certDer, offset, 0x30); // SEQUENCE (Certificate)
    offset = this.skipTag(certDer, offset, 0x30); // SEQUENCE (TBSCertificate)
    offset = this.skipElement(certDer, offset); // version
    offset = this.skipElement(certDer, offset); // serialNumber
    offset = this.skipElement(certDer, offset); // signature
    offset = this.skipElement(certDer, offset); // issuer
    offset = this.skipElement(certDer, offset); // validity
    offset = this.skipElement(certDer, offset); // subject
    const spkiStart = offset;
    const spkiLength = this.getElementLength(certDer, offset);
    const spkiEnd = offset + spkiLength;
    return certDer.slice(spkiStart, spkiEnd).buffer;
  }
  // ─── ASN.1 HELPERS ──────────────────────────────────────────
  private skipTag(
    data: Uint8Array,
    offset: number,
    expectedTag: number
  ): number {
    if (data[offset] !== expectedTag) {
      throw new Error(
        `Expected tag 0x${expectedTag.toString(
          16
        )} at offset ${offset}, got 0x${data[offset].toString(16)}`
      );
    }
    return this.skipLength(data, offset + 1);
  }
  private skipLength(data: Uint8Array, offset: number): number {
    if (data[offset] & 0x80) {
      const numBytes = data[offset] & 0x7f;
      return offset + 1 + numBytes;
    }
    return offset + 1;
  }
  private getElementLength(data: Uint8Array, offset: number): number {
    offset += 1;
    if (data[offset] & 0x80) {
      const numBytes = data[offset] & 0x7f;
      let length = 0;
      for (let i = 0; i < numBytes; i++) {
        length = (length << 8) | data[offset + 1 + i];
      }
      return 1 + numBytes + length + 1;
    }
    return 1 + 1 + data[offset];
  }
  private skipElement(data: Uint8Array, offset: number): number {
    return offset + this.getElementLength(data, offset);
  }
  // ─── BASE64 HELPERS ─────────────────────────────────────────
  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    bytes.forEach((b) => (binary += String.fromCharCode(b)));
    return btoa(binary);
  }
  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }
}
