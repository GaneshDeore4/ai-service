import { Directive, Input, TemplateRef, ViewContainerRef, OnInit, OnDestroy } from '@angular/core';
import { AccessService } from '../../core/services/access.service';
import { Subscription } from 'rxjs';

@Directive({
  selector: '[appHasAction]',
  standalone: true
})
export class HasActionDirective implements OnInit, OnDestroy {
  @Input('appHasAction') actionName!: string;
  private subscription: Subscription = new Subscription();

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private accessService: AccessService
  ) {}

  ngOnInit() {
    this.subscription.add(
      this.accessService.accessProfile$.subscribe(profile => {
        if (this.hasPermission(profile)) {
          this.viewContainer.createEmbeddedView(this.templateRef);
        } else {
          this.viewContainer.clear();
        }
      })
    );
  }

  private hasPermission(profile: any | null): boolean {
    if (!profile || !this.actionName) return false;

    // Check if the action exists anywhere in the user's products/subproducts/tabs
    // This is a global check. For more granular check, we could pass context.
    for (const product of profile.products) {
      for (const sub of product.subProducts) {
        for (const mapping of sub.tabActionMapping) {
          if (mapping.actions.some((a: any) => a.name.toLowerCase() === this.actionName.toLowerCase())) {
            return true;
          }
        }
      }
    }
    return false;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
