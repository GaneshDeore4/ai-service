package com.indusind.trade.fd.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.indusind.trade.fd.config.FeignConfig;

@FeignClient(name = "fixed-deposit-soap-client", url = "${app.bank.api.soap.url}")
public interface FixedDepositSoapFeignClient {

    @PostMapping(
            consumes = "text/xml",
            produces = "text/xml")
    String executeSoapRequest(@RequestBody String soapEnvelope);
}
