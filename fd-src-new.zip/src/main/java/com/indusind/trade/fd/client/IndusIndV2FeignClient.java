package com.indusind.trade.fd.client;

import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import com.indusind.trade.fd.config.FeignConfig;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "indus-fd-v2-client", url = "${app.bank.api.json.url}")
public interface IndusIndV2FeignClient {

    @PostMapping(value = "/cbs/v25/fd-servicing/fdmodeldeposit/V1",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    IBLGatewayResponse getDepositModelV1(
            @RequestHeader("IBL-Client-Id") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody String encryptedEnvelope
    );
}
