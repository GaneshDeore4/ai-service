package com.indusind.trade.fd.config;

import java.util.Set;

public final class EntityTypeConstants {

    private EntityTypeConstants() {}

    /**
     * Entity types that ONLY allow Non-Callable FDs (premature closure NOT allowed).
     * All entity types NOT in this set allow both Callable and Non-Callable.
     */
    public static final Set<String> NON_CALLABLE_ONLY = Set.of(
            "CF",   // Partnership
            "LL",   // Limited Liability Partnership
            "UP",   // Unregistered Partnership
            "AE",   // Association (Trust Income Exempt)
            "AF",   // Auto-Finance Co.
            "AN",   // Association (Trust Income Not Exempt)
            "AO",   // Other Associations
            "AS",   // Association (Society Income Exempt)
            "AZ",   // Dairy Co-Op Societies
            "BO",   // Unit Trust of India
            "BQ",   // Other Finance Company
            "BY",   // Housing Finance Companies
            "BZ",   // Other Financial Instit
            "C10",  // Central Govt Society With TDS Exemption
            "C5",   // Central Government (Society)
            "C7",   // Central Government (Trust)
            "CA",   // Co-Op Agricultural Society
            "CD",   // Hindu Undivided Family
            "CH",   // Co-Op Housing Society
            "CI",   // Club (Society Income Exempt)
            "CN",   // Club (Trust Income Not Exempt)
            "CP",   // Proprietorship
            "CT",   // Club (Trust Income Exempt)
            "CY",   // Club (Society Income Not Exempt)
            "DE",   // Resident Welfare Association
            "DF",   // Family/Private Trust
            "DH",   // Government Society NT
            "DK",   // Co-Op Society NT
            "DM",   // Trust NT
            "DN",   // Society NT
            "DP",   // Club Non NPO
            "DT",   // State Government (Trust)
            "DU",   // Association Non NPO
            "DW",   // Association of Person Non NPO
            "F1",   // Co-Op Society (Income Exempt)
            "FH",   // Farmers - HUF
            "FS",   // Financial Service Co.
            "GG",   // Central Government (Co-Op Society)
            "HC",   // Club/Association/Society
            "HF",   // Co-op Credit Society
            "HH",   // State Government (Society)
            "HI",   // Asset_Mutualfund_Trust
            "HO",   // Agriculture/Housing/Co-Op Society
            "HT",   // Trust (Income Not Exempt)
            "MF",   // Micro Finance Institutions
            "NF",   // Association (Society Income Not Exempt)
            "OC",   // Club (Others)
            "S9",   // State Government (Co-Op Society)
            "SB",   // Society (Income Exempt)
            "TE",   // Trust (Income Exempt)
            "UT"    // Unregistered Trust
    );

    public static Set<String> getAllowedCallableTypes(String entityTypeCode) {
        if (entityTypeCode == null || entityTypeCode.isBlank()) {
            return Set.of("Callable", "Non-Callable");
        }
        if (NON_CALLABLE_ONLY.contains(entityTypeCode.toUpperCase().trim())) {
            return Set.of("Non-Callable");
        }
        return Set.of("Callable", "Non-Callable");
    }

    public static boolean isCallableAllowed(String entityTypeCode) {
        return !NON_CALLABLE_ONLY.contains(
                entityTypeCode != null ? entityTypeCode.toUpperCase().trim() : ""
        );
    }
}
