package com.indusind.trade.fd.config;

import feign.Logger;
import feign.RequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignConfig {

    @Value("${app.feign.api-key:MOCK-SECRET-KEY}")
    private String apiKey;

    @Value("${app.bank.adapter.type:soap}")
    private String adapterType;

    @Bean
    Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }

    @Bean
    public RequestInterceptor requestInterceptor() {
        return requestTemplate -> {
            requestTemplate.header("X-API-KEY", apiKey);
            
            // Professional Tip: Dynamic Content-Type based on adapter type
            if ("soap".equalsIgnoreCase(adapterType)) {
                requestTemplate.header("Content-Type", "text/xml");
            } else {
                requestTemplate.header("Content-Type", "application/json");
            }
        };
    }

    /**
     * Professional SSL Configuration.
     * Use 'app.feign.ssl.insecure=true' ONLY for testing/bypass.
     */
    @Bean
    public feign.Client feignClient(
            @Value("${app.feign.ssl.insecure:false}") boolean insecure,
            @Value("${app.feign.ssl.protocol:TLS}") String protocol) {
        
        if (insecure) {
            return new feign.Client.Default(getInsecureSSLSocketFactory(protocol), (hostname, session) -> true);
        }
        // In production, Feign uses the JVM default SSL settings (cacerts).
        // For mutual TLS (KeyStore), you would configure a custom SSLSocketFactory
        // here.
        return new feign.Client.Default(null, null);
    }

    private javax.net.ssl.SSLSocketFactory getInsecureSSLSocketFactory(String protocol) {
        try {
            javax.net.ssl.SSLContext sslContext = javax.net.ssl.SSLContext.getInstance(protocol);
            sslContext.init(null, new javax.net.ssl.TrustManager[] {
                    new javax.net.ssl.X509TrustManager() {
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }
                    }
            }, new java.security.SecureRandom());
            return sslContext.getSocketFactory();
        } catch (Exception e) {
            throw new RuntimeException("Failed to create insecure SSL socket factory", e);
        }
    }
}
