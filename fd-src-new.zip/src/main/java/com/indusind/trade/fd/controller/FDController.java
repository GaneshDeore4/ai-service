package com.indusind.trade.fd.controller;

import com.indusind.trade.fd.dto.*;
import com.indusind.trade.fd.entity.FDAssignment;
import com.indusind.trade.fd.enums.AssignmentStatus;
import com.indusind.trade.fd.enums.AssignmentType;
import com.indusind.trade.fd.facade.FixedDepositFacade;
import com.indusind.trade.fd.repository.FDAssignmentRepository;
import com.indusind.trade.fd.service.CloseFDService;
import com.indusind.trade.fd.service.FDRoadmapService;
import com.indusind.trade.fd.service.FDSchemeService;
import com.indusind.trade.fd.service.FDService;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import com.indusind.trade.model.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.Set;

@RestController
@RequestMapping("/api/fd/v2")
@RequiredArgsConstructor
public class FDController {

    private final FixedDepositFacade fixedDepositFacade;

    private final FDRoadmapService roadmapService;

    private final FDService service;

    private final CloseFDService clsService;

    private final FDSchemeService fdSchemeService;

    @PostMapping("/calculateFDInterest")
    public ApplicationResponse calculateFDInterest(@RequestBody FDInterestRatesReqDto fdInterestRatesReqDto) {
        FDInterestRatesRespDto fdInterestRatesRespDto = fixedDepositFacade.calculateFDInterest(fdInterestRatesReqDto);
        return new ApplicationResponse("SUCCESS", fdInterestRatesRespDto, "Interest rates fetched successfully");
    }

    @GetMapping("/allowedCallableTypes")
    public ApplicationResponse getAllowedCallableTypes(@RequestParam String cifId) {
        return new ApplicationResponse("SUCCESS", service.getAllowedCallableTypesForCif(cifId), "Callable types fetched successfully");
    }

    @PostMapping("/createFd")
    public ResponseEntity<ApplicationResponse> create(@RequestBody FixedDepositDto fd) {
        try {
            service.createFD(fd);
            return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd created successfully."));
        } catch (GTPAppException ex) {
            return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("FAILED", null, ex.getMessage()));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("FAILED", null, ex.getMessage()));
        }
    }

    @PostMapping("/approveFd")
    public ResponseEntity<ApplicationResponse> approve(@RequestBody FDActionDto request) {
        try {
            service.approve(request.getFdId(), request.getUserId(), request.getLoginId(), request.getUserName(),request.getGroupId(),request.getGroupName(), request.getUserType(), request.getIsMidOffice());
            return ResponseEntity.ok(
                    new ApplicationResponse("SUCCESS", null, "Approval successful")
            );
        } catch (Exception ex) {
            throw new GTPAppException("FD Approval failed", null);
        }
    }

    @PostMapping("/rejectFd")
    public ResponseEntity<ApplicationResponse> reject(@RequestBody FDActionDto request) {
        service.reject(request.getFdId(), request.getUserId(),request.getLoginId(),request.getUserName(), request.getGroupId(), request.getGroupName(),request.getReason(), request.getUserType());
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd rejected successfully."));
    }

    @PostMapping("/reopenFd")
    public ResponseEntity<ApplicationResponse> reopen(@RequestBody FixedDepositDto updated) {
        service.reopen(updated);
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd reopened successfully."));
    }

   @PostMapping("/closeFd")
    public ResponseEntity<ApplicationResponse> closeFd(@RequestBody FDActionDto fdActionDto) {
        service.close(fdActionDto.getFdId(), fdActionDto.getUserId(), fdActionDto.getLoginId(), fdActionDto.getUserName());
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd closed successfully."));
    }


    @GetMapping("/makerFDTray")
    public ResponseEntity<ApplicationResponse> makerTray(@RequestParam Long makerId,
                                                         @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getMakerTray(makerId, pageable), "Maker Fd tray fetched successfully."));
    }

    @GetMapping("/checkerFDTray")
    public ResponseEntity<ApplicationResponse> checkerTray(@RequestParam Long userId, @RequestParam Long groupId,
                                                           @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getCheckerTray(userId, groupId, pageable), "Checker Fd tray fetched successfully."));
    }

    @PostMapping("/checkerFDTrayByStatus")
    public ResponseEntity<ApplicationResponse> checkerTrayByStatus(@RequestBody CheckerTrayRequestDTO request,
                                                           @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getCheckerTrayByStatus(request.getUserId(), request.getGroupId(), request.getStatus(),pageable), "Checker Fd tray fetched successfully."));
    }

    @GetMapping("/checkerPendingFDTray")

    public ResponseEntity<ApplicationResponse> checkerPendingFDTray(@RequestParam Long userId, @RequestParam Long groupId,
                                                                    @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {

        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getCheckerPendingTray(userId, groupId, pageable), "Checker Fd tray fetched successfully."));

    }


    @GetMapping("/releaserOrVerifierFDTray")
    public ResponseEntity<ApplicationResponse> releaserOrVerifierFDTray(@RequestParam Long userId, @RequestParam String roleName,
                                                                        @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getRelaeaserOrVerifierTray(userId, roleName, pageable), "Releaser/ Verifier Fd tray fetched successfully."));
    }

    @PostMapping("/releaserOrVerifierFDTrayByStatus")
    public ResponseEntity<ApplicationResponse> releaserOrVerifierFDTrayByStatus(@RequestBody VerifierTrayRequestDTO request,
                                                                        @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getRelaeaserOrVerifierTrayByStatus(request.getUserId(), request.getRoleName(), request.getStatus(), pageable), "Releaser/ Verifier Fd tray fetched successfully."));
    }

    @GetMapping("/releaserOrVerifierFDPendingTray")
    public ResponseEntity<ApplicationResponse> releaserOrVerifierFDTPendingTray(@RequestParam Long userId, @RequestParam String roleName,
                                                                        @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", service.getRelaeaserOrVerifierPendingTray(userId, roleName, pageable), "Releaser/ Verifier Fd tray fetched successfully."));
    }

    @PostMapping("/getAllFDsByCifId")
    public ApplicationResponse getAllFDsByCifId(@RequestParam String cifId, @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        return new ApplicationResponse("SUCCESS", service.getAllFDByCifId(cifId, pageable), "All fds fetched successfully");
    }

    @GetMapping("/roadmapPaths")
    public FDRoadmapResponse getRoadmap(@RequestParam Long fdId) {
        return roadmapService.getRoadmap(fdId);
    }

    @PostMapping("/approveFdMidOffice")
    public ApplicationResponse approveFdMidOffice(@RequestBody FDActionDto fdActionDto) {
        service.approveFdMidOffice(fdActionDto.getFdId(), fdActionDto.getUserId(), fdActionDto.getLoginId(), fdActionDto.getUserName());
        return new ApplicationResponse("SUCCESS", null, "FD Approved at mid office successfully");

    }

    @PostMapping("/rejectFdMidOffice")
    public ApplicationResponse rejectFdMidOffice(@RequestBody FDActionDto fdActionDto) {
        service.rejectFdMidOffice(fdActionDto.getFdId(), fdActionDto.getUserId(), fdActionDto.getLoginId(), fdActionDto.getUserName());
        return new ApplicationResponse("SUCCESS", null, "FD Rejected at mid office successfully");

    }


    @GetMapping("/count")
    public MidOfficeCountDTO getCounts() {
        return service.getMidOfficeCounts();
    }

    @PostMapping("/getFDByStatus")
    public ApplicationResponse getFDByStatus(@RequestBody GetFDByStatusRequestDto request, @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        Page<AccountJson> fdPage = service.getFDByStatus(request.getCifId(), pageable);
        return new ApplicationResponse("SUCCESS", fdPage, "FD list fetched");
    }

    @PostMapping("/getFDAuditsByFdId")
    public ApplicationResponse getFDAuditsByFdId(@RequestParam Long  fdId, @PageableDefault(page = 0, size = 10, sort = "timestamp") Pageable pageable) {
        Page<FdActionAuditsDto> fdAudits = service.getFDAuditsByFdId(fdId, pageable);
        return new ApplicationResponse("SUCCESS", fdAudits, "FD audit list fetched successfully");

    }

    @PostMapping("/fdClosureReq")
    public ResponseEntity<ApplicationResponse> create(@RequestBody CloseFDDto fd) {
        System.out.println("Inside of new controller fdClosureReq" + fd);
        try {
            clsService.closeFD(fd);
            return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("SUCCESS", null, "Fd closure request submitted  successfully and pending for approval."));
        }catch(GTPAppException gtpAppException){
            System.out.println("Inside of GTPAppException");
            System.out.println("Exception Message=" +gtpAppException.getMessage());
            return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("FAILED", null, gtpAppException.getMessage()));

        }catch(Exception ex){
            System.out.println("Inside of Global Catch");
            return ResponseEntity.status(HttpStatus.OK).body(new ApplicationResponse("FAILED", null, ex.getMessage()));
        }
    }

    
    @PostMapping("/getMidOfficeList")
    public ApplicationResponse getMidOfficeList(@RequestBody GetFDByStatusRequestDto request, @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        Page<FixedDepositDto> fdPage = service.getMidOfficeList(request.getStatus(), pageable);
        return new ApplicationResponse("SUCCESS", fdPage, "FD list fetched");
    }
    
    @PostMapping("/getFDByCIFAndStatus")
    public ApplicationResponse getFDByCIFAndStatus(@RequestBody GetFDByStatusRequestDto request, @PageableDefault(page = 0, size = 10, sort = "id") Pageable pageable) {
        Page<FixedDepositDto> fdPage = service.getFDByCifIdAndStatus(request.getCifId(), request.getStatus(), pageable);
        return new ApplicationResponse("SUCCESS", fdPage, "FD list fetched");
    }
    
}

