package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.enums.FDStatus;
import jakarta.persistence.Version;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FixedDepositDto {

    private Long id;
    private String cifId;
    private String accountNumber;
    private Double amount;
    private String currency;
    private Integer tenureMonths;
    private Double interestRate;
    private Long userId;
//  private String userCurrencyType;
    private String userBaseCurrency;
    private String loginId;
    private String userName;
    private Boolean termsAccepted;
    private String interestFrequency;
    private String maturityInstruction;
    private Double maturityAmount;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDate maturityDate;
    private  Double interestAmount ;
    private Integer tenureYears;
    private Integer tenureDays;
    private FDStatus status;
    private String stateId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long authMatrixId;
    private Integer currentLevel;
    private String rejectReason;
    private Long makerId;
    private Long productId;
    private Long subProductId;
    private Long version;
    private boolean isReopend;
    private String schmCode;
    private String callableType;
    private String interestPayout;


    public static FixedDeposit convertToEntity(FixedDepositDto fdReq) {
        FixedDeposit fd = new FixedDeposit();
        BeanUtils.copyProperties(fdReq, fd);

        return fd;
    }

    public static FixedDepositDto convertToDto(FixedDeposit fd) {
        FixedDepositDto fdDto = new FixedDepositDto();
        BeanUtils.copyProperties(fd, fdDto);

        return fdDto;
    }
}
