package com.indusind.trade.fd.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "fd_scheme_master")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FDSchemeMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "schm_code", unique = true, nullable = false, length = 10)
    private String schmCode;

    @Column(name = "schm_desc", length = 500)
    private String schmDesc;

    @Column(name = "eur", length = 1)
    private String eur;

    @Column(name = "gbp", length = 1)
    private String gbp;

    @Column(name = "usd", length = 1)
    private String usd;

    @Column(name = "flow_code", nullable = false, length = 5)
    private String flowCode;

    @Column(name = "flow_freq_mths")
    private Integer flowFreqMths;

    @Column(name = "flow_freq_days")
    private Integer flowFreqDays;

    @Column(name = "min_deposit_amt", nullable = false)
    private Double minDepositAmt;

    @Column(name = "max_deposit_amt", nullable = false)
    private Double maxDepositAmt;

    @Column(name = "nre_flag", nullable = false, length = 1)
    private String nreFlag;

    @Column(name = "int_rate_code", length = 10)
    private String intRateCode;

    @Column(name = "maturity_instruction", nullable = false, length = 20)
    private String maturityInstruction;

    @Column(name = "premature_closure_allowed", nullable = false, length = 1)
    private String prematureClosureAllowed;

    @Column(name = "partial_closure_allowed", length = 5)
    private String partialClosureAllowed;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "channel", nullable = false, length = 30)
    private String channel;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    public boolean isCurrencySupported(String currency) {
        if (currency == null) return false;
        return switch (currency.toUpperCase().trim()) {
            case "EUR" -> "Y".equalsIgnoreCase(this.eur);
            case "GBP" -> "Y".equalsIgnoreCase(this.gbp);
            case "USD" -> "Y".equalsIgnoreCase(this.usd);
            default -> false;
        };
    }
}
