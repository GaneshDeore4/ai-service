package com.indusind.trade.fd.enums;

import lombok.Getter;

@Getter
public enum FlowCode {

    IO("IO", "Interest Outflow"),
    II("II", "Interest Inflow");

    private final String code;
    private final String description;

    FlowCode(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public static FlowCode fromInterestPayout(String interestPayout) {
        if ("Interest Payout".equalsIgnoreCase(interestPayout)) {
            return IO;
        }
        return II;
    }
}
