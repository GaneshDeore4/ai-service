package com.indusind.trade.fd.enums;

import lombok.Getter;

@Getter
public enum NreFlag {

    YES("Y"),
    NO("N");

    private final String code;

    NreFlag(String code) {
        this.code = code;
    }

    public static NreFlag fromCountry(String countryOfIncorporation) {
        if (countryOfIncorporation == null || countryOfIncorporation.isBlank()) {
            return YES;
        }
        String normalized = countryOfIncorporation.toUpperCase().trim();
        if ("IN".equals(normalized) || "INDIA".equals(normalized) || "IND".equals(normalized)) {
            return NO;
        }
        return YES;
    }
}
