package com.indusind.trade.fd.repository;

import com.indusind.trade.fd.entity.FDSchemeMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FDSchemeMasterRepository extends JpaRepository<FDSchemeMaster, Long> {

    List<FDSchemeMaster> findByChannelAndIsActive(String channel, Boolean isActive);

    Optional<FDSchemeMaster> findBySchmCode(String schmCode);

    List<FDSchemeMaster> findByChannelAndIsActiveAndNreFlag(String channel, Boolean isActive, String nreFlag);
}
