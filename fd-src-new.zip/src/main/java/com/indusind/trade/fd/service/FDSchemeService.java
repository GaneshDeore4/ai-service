package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.FixedDepositDto;

import java.util.Set;

public interface FDSchemeService {

    /**
     * Resolves the scheme code based on FD inputs and CIF data.
     * Called during FD creation to determine which Finacle scheme to use.
     *
     * @param fd the FD creation request from the UI
     * @param countryOfIncorporation the entity's country (from CIF details)
     * @return the resolved SCHM_CODE (e.g., FDIBR, FNIBU, TGNFN, etc.)
     */
    String resolveSchemeCode(FixedDepositDto fd, String countryOfIncorporation);

    /**
     * Returns allowed callable types (Callable / Non-Callable) for the given entity type.
     *
     * @param entityType the entity type code from CIF (e.g., EC, CJ, CF, LL)
     * @return set of allowed callable type strings
     */
    Set<String> getAllowedCallableTypes(String entityType);
}
