package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.config.EntityTypeConstants;
import com.indusind.trade.fd.dto.FixedDepositDto;
import com.indusind.trade.fd.entity.FDSchemeMaster;
import com.indusind.trade.fd.enums.FlowCode;
import com.indusind.trade.fd.enums.NreFlag;
import com.indusind.trade.fd.repository.FDSchemeMasterRepository;
import com.indusind.trade.fd.service.FDSchemeService;
import com.indusind.trade.model.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class FDSchemeServiceImpl implements FDSchemeService {

    private static final String CHANNEL = "GIFT_CITY";

    private final FDSchemeMasterRepository schemeMasterRepo;

    @Override
    public String resolveSchemeCode(FixedDepositDto fd, String countryOfIncorporation) {
        String nreFlag = NreFlag.fromCountry(countryOfIncorporation).getCode();
        String flowCode = FlowCode.fromInterestPayout(fd.getInterestPayout()).getCode();
        String prematureClosureFlag = mapCallableType(fd.getCallableType());
        String maturityInstruction = mapMaturityInstruction(fd.getMaturityInstruction());

        log.info("Resolving scheme: currency={}, amount={}, nreFlag={}, flowCode={}, callable={}, maturity={}",
                fd.getCurrency(), fd.getAmount(), nreFlag, flowCode, prematureClosureFlag, maturityInstruction);

        List<FDSchemeMaster> allSchemes = schemeMasterRepo.findByChannelAndIsActive(CHANNEL, true);

        List<FDSchemeMaster> matches = allSchemes.stream()
                .filter(s -> s.isCurrencySupported(fd.getCurrency()))
                .filter(s -> fd.getAmount() >= s.getMinDepositAmt() && fd.getAmount() <= s.getMaxDepositAmt())
                .filter(s -> nreFlag.equals(s.getNreFlag()))
                .filter(s -> flowCode.equals(s.getFlowCode()))
                .filter(s -> prematureClosureFlag.equals(s.getPrematureClosureAllowed()))
                .filter(s -> maturityInstruction.equals(s.getMaturityInstruction()))
                .collect(Collectors.toList());

        if (matches.isEmpty()) {
            log.error("No eligible FD scheme found for inputs: currency={}, amount={}, nreFlag={}, flowCode={}, callable={}, maturity={}",
                    fd.getCurrency(), fd.getAmount(), nreFlag, flowCode, prematureClosureFlag, maturityInstruction);
            throw new GTPAppException("No eligible FD scheme found for the given inputs. Please verify the deposit details.", null);
        }

        if (matches.size() > 1) {
            String codes = matches.stream().map(FDSchemeMaster::getSchmCode).collect(Collectors.joining(", "));
            log.warn("Multiple schemes matched: {}. Using first match.", codes);
        }

        String resolved = matches.get(0).getSchmCode();
        log.info("Resolved scheme code: {}", resolved);
        return resolved;
    }

    @Override
    public Set<String> getAllowedCallableTypes(String entityType) {
        return EntityTypeConstants.getAllowedCallableTypes(entityType);
    }

    private String mapCallableType(String callableType) {
        if ("Callable".equalsIgnoreCase(callableType)) {
            return "Y";
        }
        return "N";
    }

    private String mapMaturityInstruction(String maturityInstruction) {
        if ("Auto Renewal".equalsIgnoreCase(maturityInstruction)) {
            return "U";
        }
        return "No Renewal";
    }
}
