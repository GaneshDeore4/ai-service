-- =====================================================
-- FD Scheme Master Table for GIFT City Project
-- =====================================================

CREATE TABLE fd_scheme_master (
    id                        BIGINT IDENTITY(1,1) PRIMARY KEY,
    schm_code                 VARCHAR(10)    NOT NULL UNIQUE,
    schm_desc                 VARCHAR(500),
    eur                       CHAR(1)        NOT NULL DEFAULT 'N',
    gbp                       CHAR(1)        NOT NULL DEFAULT 'N',
    usd                       CHAR(1)        NOT NULL DEFAULT 'N',
    flow_code                 VARCHAR(5)     NOT NULL,
    flow_freq_mths            INT            DEFAULT 0,
    flow_freq_days            INT            DEFAULT 0,
    min_deposit_amt           DECIMAL(20,2)  NOT NULL,
    max_deposit_amt           DECIMAL(20,2)  NOT NULL,
    nre_flag                  CHAR(1)        NOT NULL,
    int_rate_code             VARCHAR(10),
    maturity_instruction      VARCHAR(20)    NOT NULL,
    premature_closure_allowed CHAR(1)        NOT NULL,
    partial_closure_allowed   CHAR(5),
    end_date                  DATE,
    channel                   VARCHAR(30)    NOT NULL DEFAULT 'GIFT_CITY',
    is_active                 BIT            NOT NULL DEFAULT 1
);

-- =====================================================
-- Seed Data: 5 FD Schemes for GIFT City
-- =====================================================

INSERT INTO fd_scheme_master (schm_code, schm_desc, eur, gbp, usd, flow_code, flow_freq_mths, flow_freq_days, min_deposit_amt, max_deposit_amt, nre_flag, int_rate_code, maturity_instruction, premature_closure_allowed, partial_closure_allowed, end_date, channel, is_active)
VALUES
('FNIBR', 'IBU GIFT DEPOSIT ACCOUNT (REINVESTMENT) PREMATURE CLOSURE NOT ALLOWED FOR RESIDENT INDIAN', 'Y', 'Y', 'Y', 'II', 6, 0, 1000, 100000000000000.00, 'N', 'TBZRO', 'No Renewal', 'N', 'NA', '2099-12-31', 'GIFT_CITY', 1),
('FDIBR', 'IBU GIFT DEPOSIT ACCOUNT (REINVESTMENT) FOR RESIDENT INDIAN', 'Y', 'Y', 'Y', 'II', 6, 0, 1000, 100000000000000.00, 'N', 'TGINT', 'U', 'Y', 'Y', '2099-12-31', 'GIFT_CITY', 1),
('FNIBU', 'IBU GIFT DEPOSIT ACCOUNT (REINVESTMENT) PREMATURE CLOSURE NOT ALLOWED', 'Y', 'Y', 'Y', 'II', 6, 0, 1000, 100000000000000.00, 'Y', 'TBZRO', 'No Renewal', 'N', 'NA', '2099-12-31', 'GIFT_CITY', 1),
('TGNFN', 'IBU GIFT CITY FIXED DEPOSIT - PAYOUT', 'Y', 'Y', 'Y', 'IO', 0, 180, 1000, 100000000000000.00, 'Y', 'TGINT', 'U', 'Y', 'Y', '2099-12-31', 'GIFT_CITY', 1),
('FDIBU', 'IBU GIFT DEPOSIT ACCOUNT (REINVESTMENT)', 'Y', 'Y', 'Y', 'II', 6, 0, 1000, 100000000000000.00, 'Y', 'TGINT', 'U', 'Y', 'Y', '2099-12-31', 'GIFT_CITY', 1);

-- =====================================================
-- Add schm_code, callable_type, interest_payout to fixed_deposits table
-- =====================================================

ALTER TABLE fixed_deposits ADD schm_code VARCHAR(10);
ALTER TABLE fixed_deposits ADD callable_type VARCHAR(20);
ALTER TABLE fixed_deposits ADD interest_payout VARCHAR(30);
