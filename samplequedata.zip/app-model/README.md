# app-model

Repository under project **GIFTCITYINNOVATION** in workspace `transbnk`.
