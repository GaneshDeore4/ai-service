package com.indusind.trade.model.constants;

public class CryptoConstants {

    public static final String ALGORITHM = "AES/GCM/NoPadding";
    public static final int GCM_TAG_LENGTH = 16; // 128 bits
    public static final int IV_LENGTH = 12; // 96 bits
    public static final String NEW_PREFIX = "{AES3}";

//    public final static String AES_SECRET_KEY = "252A726D4801E120084A503AD5B145EA";
}
