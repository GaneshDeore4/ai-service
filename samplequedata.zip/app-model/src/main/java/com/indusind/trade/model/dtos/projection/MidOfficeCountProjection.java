package com.indusind.trade.model.dtos.projection;

public interface MidOfficeCountProjection {
    Long getPendingAtBank();
    Long getPendingAtClient();
    Long getProcessedByBank();
    Long getProcessedByClient();
}
