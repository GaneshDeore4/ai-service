package com.indusind.trade.model.dtos.requestdtos;

import java.util.List;

public record AddAuthMatrixRequestDto(
        Long authMatId,
        Long companyId,
        Long productId,
        Long subProductId,
        Boolean isSequential,
        Boolean isVerifier,
        Boolean isReleaser,
        String currencyType,
        Long amount,
        Long oldAmount,
        List<Long> authGroupIds,
        List<String> accountIds,
        Boolean allProductFlag,
        Boolean isUpdate,
        String category,
        Boolean isAccListUpdated
) {
}
