package com.indusind.trade.model.dtos.requestdtos;

import java.util.List;

public record ApproveRejectGroupedAuthMatrixRequestDto(
        List<Long> authMatrixIds
) {
}
