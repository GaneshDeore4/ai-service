package com.indusind.trade.model.dtos.requestdtos;

import com.indusind.trade.model.entities.company.AuthGroup;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Getter
@Setter
@RequiredArgsConstructor
public class AuthGroupDto {

    private Long id;
    private String authGroup;

    public static AuthGroupDto convertToDto(AuthGroup authGroup) {
        AuthGroupDto authGroupDto = new AuthGroupDto();
        BeanUtils.copyProperties(authGroup, authGroupDto);
        return authGroupDto;
    }

    public static AuthGroup convertToDto(AuthGroupDto authGroupDto) {
        AuthGroup authGroup = new AuthGroup();
        BeanUtils.copyProperties(authGroupDto, authGroup);
        return authGroup;
    }

}
