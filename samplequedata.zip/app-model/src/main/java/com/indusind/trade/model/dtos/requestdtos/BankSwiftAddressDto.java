package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.bank.BankSwiftAddress;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankSwiftAddressDto {

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String countryCode;

    public static BankSwiftAddressDto convertToDto(BankSwiftAddress swiftAddress) {
        BankSwiftAddressDto swiftAddressDto = new BankSwiftAddressDto();
        BeanUtils.copyProperties(swiftAddress, swiftAddressDto);
        return swiftAddressDto;
    }
}