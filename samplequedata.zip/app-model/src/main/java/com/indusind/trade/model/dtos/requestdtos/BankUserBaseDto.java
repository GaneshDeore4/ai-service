package com.indusind.trade.model.dtos.requestdtos;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

@MappedSuperclass
@Getter
@Setter
@SuperBuilder
@RequiredArgsConstructor
public class BankUserBaseDto {

    private Long bankUserId;
    private Long bankId;
    private String bankName;
    private String loginId;
    private String firstName;
    private String lastName;
    private String employeeNo;
    private String department;
    private String otherDept;
    private Long userTypeId;
    private String userType;
    private OfficeAddressDto officeAddress;
    private String bankUserStatus; //ACTIVE,INACTIVE
    private String status; //APPROVED,REJECTED
    private String timeZone;
    private String corrLanguage;
    private String baseCurr;
    private String solId;
    private String branchName;
    private String contactNo;
    private String contactNoCountryCode;
    private String email;
    private String groupEmail;
    private String transNotify;
    private Map<Long, List<Long>> productSubProdRespMap;
    private Map<String, Set<String>> productSubProdMap;
    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;
    private Boolean isFirstLoginFlag;

}
