package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;


@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyBaseDto {

    private Long companyId;
    private String cifId;
    private String abbvName;
    private String name;
    private AddressDto addressDto;
    private SwiftAddressDto swiftAddress;

    private String dualControl;
    private String controlStatus;
    private String authOwnTransaction;
    private String initialAdmin;
    private String baseCurrency;
    private String clientSegment;
    private String email;
    private String status;
    private LocalDateTime createdDate;
    private String createdBy;
    private LocalDateTime modifiedDate;
    private String modifiedBy;
    //private Long categoryId;

    private List<AccountDto> accountDtoList;

    private List<CustomerReferenceDto> customerReferenceDtoList;

    private List<LegalIdDetailsDto> legalIdDetailsDtoList;

    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;

}
