package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.company.Address;
import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.entities.company.CompanyTemp;
import com.indusind.trade.model.entities.company.SwiftAddress;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.Objects;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyRequestDto extends CompanyBaseDto {

    private Boolean isUpdate;

    private List<Long> productIdList;

    private List<Long> subProductList;

    private List<ProductLimitDto> productLimit;

    public static CompanyTemp convertToTempEntity(CompanyRequestDto companyRequestDto, CompanyTemp companyTemp) {
        BeanUtils.copyProperties(companyRequestDto, companyTemp);
        if(Objects.nonNull(companyRequestDto.getAddressDto())) {
            Address address =  new Address();
            BeanUtils.copyProperties(companyRequestDto.getAddressDto(),address);
            companyTemp.setAddress(address);
        }
        if(Objects.nonNull(companyRequestDto.getSwiftAddress())) {
            SwiftAddress swiftAddress = new SwiftAddress();
            BeanUtils.copyProperties(companyRequestDto.getSwiftAddress(), swiftAddress);
            companyTemp.setSwiftAddress(swiftAddress);
        }
//        companyTemp.setAccountTempList(
//                companyRequestDto.getAccountDtoList().stream()
//                        .map(AccountDto::convertToTempEntity)
//                        .toList()
//        );
//
//        companyTemp.setCustomerReferenceTempList(
//                companyRequestDto.getCustomerReferenceDtoList().stream()
//                        .map(CustomerReferenceDto::convertToTempEntity)
//                        .toList()
//        );
//        companyTemp.setLegalIdDetailsTempList(
//                companyRequestDto.getLegalIdDetailsDtoList().stream()
//                        .map(LegalIdDetailsDto::convertToTempEntity)
//                        .toList()
//        );
        return companyTemp;
    }

    public static Company convertToEntity(CompanyRequestDto companyRequestDto) {
        Company company = new Company();
        BeanUtils.copyProperties(companyRequestDto, company);
        return company;
    }
}
