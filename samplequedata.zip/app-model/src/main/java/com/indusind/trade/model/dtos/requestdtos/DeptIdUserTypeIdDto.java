package com.indusind.trade.model.dtos.requestdtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class DeptIdUserTypeIdDto {

    private Long deptId;
    private List<Long> userTypeIds;

}
