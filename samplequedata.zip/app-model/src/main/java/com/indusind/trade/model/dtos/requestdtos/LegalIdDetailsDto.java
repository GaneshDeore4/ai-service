package com.indusind.trade.model.dtos.requestdtos;


import com.indusind.trade.model.entities.company.LegalIdDetails;
import com.indusind.trade.model.entities.company.LegalIdDetailsTemp;
import com.indusind.trade.model.enums.LegalIdType;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Getter
@Setter
@RequiredArgsConstructor
public class LegalIdDetailsDto {

    private Long id;
    private LegalIdType legalIdType;
    private String legalIdNo;
    private String legalIdIssuingAuthority;

    public static LegalIdDetailsDto convertToDto(LegalIdDetails legalIdDetails) {
        LegalIdDetailsDto legalIdDetailsDto = new LegalIdDetailsDto();
        BeanUtils.copyProperties(legalIdDetails, legalIdDetailsDto);
        return legalIdDetailsDto;
    }

    public static LegalIdDetails convertToEntity(LegalIdDetailsDto legalIdDetailsDto) {
        LegalIdDetails legalIdDetails = new LegalIdDetails();
        BeanUtils.copyProperties(legalIdDetailsDto, legalIdDetails);
        return legalIdDetails;
    }

    public static LegalIdDetailsDto convertToDtoFromTemp(LegalIdDetailsTemp legalIdDetailsTemp) {
        LegalIdDetailsDto legalIdDetailsDto = new LegalIdDetailsDto();
        BeanUtils.copyProperties(legalIdDetailsTemp, legalIdDetailsDto);
        return legalIdDetailsDto;
    }

    public static LegalIdDetailsTemp convertToTempEntity(LegalIdDetailsDto legalIdDetailsDto) {
        LegalIdDetailsTemp legalIdDetailsTemp = new LegalIdDetailsTemp();
        BeanUtils.copyProperties(legalIdDetailsDto, legalIdDetailsTemp);
        return legalIdDetailsTemp;
    }

}
