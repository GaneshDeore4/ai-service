package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.indusind.trade.model.entities.company.Notification;
import com.indusind.trade.model.entities.company.NotificationTemp;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.time.LocalDate;

@Data
public class NotificationRequestDto {

    private Long notificationId;
    private String notificationTitle;
    private String notificationDesc;
    private Boolean isUpdate;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate validUpto;
    private String status;
    private Boolean isActive;

    public Notification convertToEntity(NotificationRequestDto notificationRequestDto, Notification notification){
//        Notification notification = new Notification();
        BeanUtils.copyProperties(notificationRequestDto, notification);
        return notification;
    }

    public NotificationTemp convertToTempEntity(NotificationRequestDto notificationRequestDto, NotificationTemp notificationTemp){
        BeanUtils.copyProperties(notificationRequestDto, notificationTemp);
        return notificationTemp;
    }
}
