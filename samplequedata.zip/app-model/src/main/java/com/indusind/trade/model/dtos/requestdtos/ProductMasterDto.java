package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.enums.Status;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductMasterDto {

    private Long productId;

    private String productName;

    private Long categoryId;

    private String categoryName;

    private Set<SubProductMasterDto> subProductMasterDtoList;

    private Boolean midOfficeFlag;

    private Long sequenceId;

    private Status status;

    private Boolean isUpdate;

    private String productNameLabel;

    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;


    public static ProductMasterDto convertToDto(ProductMaster productMaster) {
        ProductMasterDto productMasterDto = new ProductMasterDto();
        BeanUtils.copyProperties(productMaster, productMasterDto);
        productMasterDto.setCategoryId(productMaster.getCategory().getCategoryId());
        productMasterDto.setCategoryName(productMaster.getCategory().getCategoryName());
        return productMasterDto;
    }

    public static ProductMaster convertToEntity(ProductMasterDto productMasterDto) {
        ProductMaster productMaster = new ProductMaster();
        BeanUtils.copyProperties(productMasterDto, productMaster);
        return productMaster;
    }

}
