package com.indusind.trade.model.dtos.requestdtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class ProductMidOfficeMappingDto {

    private Long productId;
    private Boolean midOfficeFlag;

}
