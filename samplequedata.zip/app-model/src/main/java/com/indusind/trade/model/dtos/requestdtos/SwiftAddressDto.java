package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.company.SwiftAddress;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;


@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SwiftAddressDto {

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String countryCode;

    private String contactReference;

    private String strtName;

    private String buildingNumber;

    private String buildingName;

    private String floor;

    private String room;

    private String districtName;

    private String countrySubdivision;

    private String department;

    private String subDepartment;

    private Long postalCode;

    private String swiftTownName;

    private String country;

    public static SwiftAddressDto convertToDto(SwiftAddress swiftAddress) {
        SwiftAddressDto swiftAddressDto = new SwiftAddressDto();
        BeanUtils.copyProperties(swiftAddress, swiftAddressDto);
        return swiftAddressDto;
    }
}
