package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.enums.Status;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.List;

@Data
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserTypeDto {

    private Long userTypeId;
    private String userTypeName;
    private Long categoryId;
    private String categoryName;
    private Status status;
    private Boolean isUpdate;
    private String userTypeNameLabel;
    private List<UserTypeTabActionMappingDto> tabActionMapping;
    private String makerName;
    private String checkerName;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;

    public static UserTypeDto convertToDto(UserType userType) {
        UserTypeDto userTypeDto = new UserTypeDto();
        BeanUtils.copyProperties(userType, userTypeDto);
        userTypeDto.setCategoryId(userType.getCategory().getCategoryId());
        userTypeDto.setCategoryName(userType.getCategory().getCategoryName());
        return userTypeDto;
    }

    public static UserType convertToEntity(UserTypeDto userTypeDto) {
        UserType userType = new UserType();
        BeanUtils.copyProperties(userTypeDto, userType);
        return userType;
    }
}
