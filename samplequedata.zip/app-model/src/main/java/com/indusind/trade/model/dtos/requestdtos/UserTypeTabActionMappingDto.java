package com.indusind.trade.model.dtos.requestdtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.Map;


@Data
@RequiredArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserTypeTabActionMappingDto {
    private Long productId;
    private Long subProductId;
    private Long userTypeId;
    private String userTypeName;
    private Long tabId;
    private String tabName;
    private List<Map<String, Object>> actions;

}
