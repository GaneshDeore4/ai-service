package com.indusind.trade.model.dtos.requestdtos;

import java.util.List;

//public record UserTypeTabActionMappingRequestDto(Long productId,
//                                                 Long subProductId,
//                                                 Long userTypeId,
//                                                 List<TabActionMappingReqDto> tabActionMappingReqDtoList) {
//}

public record UserTypeTabActionMappingRequestDto(Long productId,
                                                 Long subProductId,
                                                 List<UserTypeTabActionMappingReqDto> userTypeTabActionMappingReqDtos) {
}
