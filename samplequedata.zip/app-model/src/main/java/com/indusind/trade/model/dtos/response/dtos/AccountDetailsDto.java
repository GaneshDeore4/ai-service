package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.entities.company.AccountDetail;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@RequiredArgsConstructor
public class AccountDetailsDto {

    private String id;
    private String cifId;
    private String accountNumber;
    private String currency;
    private String schemeDescription;
    private String schemeType;
    private BigDecimal effectiveAvailBalance;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;

    public static AccountDetail convertToEntity(AccountDetailsDto accountDetailsDto) {
        AccountDetail accountDetail = new AccountDetail();
        BeanUtils.copyProperties(accountDetailsDto, accountDetail);

        return accountDetail;
    }

    public static AccountDetailsDto convertToDto(AccountDetail accountDetail) {
        AccountDetailsDto accountDetailsDto = new AccountDetailsDto();
        BeanUtils.copyProperties(accountDetail, accountDetailsDto);

        return accountDetailsDto;
    }

}
