package com.indusind.trade.model.dtos.response.dtos;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
public class AddUserAccountMappingResponseDto {

    private Long userId;
    private List<AccountDetailsDto> accountDetails;

}
