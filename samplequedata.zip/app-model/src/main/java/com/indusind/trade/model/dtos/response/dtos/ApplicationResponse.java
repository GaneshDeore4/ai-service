package com.indusind.trade.model.dtos.response.dtos;


public class ApplicationResponse {

    private String status;
    private Object payload;
    private String description;


    public ApplicationResponse() {
        super();
    }

    public ApplicationResponse(String status, Object payload, String description) {
        super();
        this.status = status;
        this.payload = payload;
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getPayload() {
        return payload;
    }

    public void setPayload(Object payload) {
        this.payload = payload;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "ApplicationResponse [status=" + status + ", payload=" + payload + ", description=" + description + "]";
    }

}

