package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.enums.AuthType;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AuthMatrixGroupedDto {

    private Long companyId;
    private Long amount;
    private Boolean isVerifier;
    private Boolean isReleaser;
    private Boolean isSequential;
    private Boolean isAllProductFlag;
//    private List<AuthType> eventType;
    private String currencyType;
    private Set<Map<String, Integer>> authGroup;
    private String status;
    private String ids;
    private List<AccountDetailsDto> accounts;
    private String makerName;
    private LocalDateTime createdAt;
    private String lastModifiedBy;
    private LocalDateTime lastModifiedAt;
    private String editorName;
    private LocalDateTime editedAt;
    private String checkerName;
    private LocalDateTime approvedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;

}
