package com.indusind.trade.model.dtos.response.dtos;

public interface AuthMatrixGroupedProjection {
    Long getCompanyId();
    Long getAmount();
    Boolean getIsVerifier();
    Boolean getIsReleaser();
    Boolean getIsSequential();
    Boolean getIsAllProductFlag();
    String getCurrencyType();
    String getStatus();
    String getIds();        // comma-separated IDs
    String getEventType();  // Postgres array text e.g., {CREATE,UPDATE}
    String getAuthGroup();       // comma-separated "id_companyId_amount" list
}
