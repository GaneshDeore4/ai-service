package com.indusind.trade.model.dtos.response.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyProfileResponseDto {

    private String cifid;
    private String lastName;
    private String emailId;
    private String segment;
    private List<PostalAddressDto> address;

}
