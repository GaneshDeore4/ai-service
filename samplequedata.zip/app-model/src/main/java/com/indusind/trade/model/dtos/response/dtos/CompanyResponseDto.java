package com.indusind.trade.model.dtos.response.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.indusind.trade.model.dtos.requestdtos.AddressDto;
import com.indusind.trade.model.dtos.requestdtos.CompanyBaseDto;
import com.indusind.trade.model.dtos.requestdtos.ProductLimitDto;
import com.indusind.trade.model.dtos.requestdtos.SwiftAddressDto;
import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.entities.company.CompanyTemp;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyResponseDto extends CompanyBaseDto {

    private Map<String, Set<String>> prodSubProdMapping;

    private List<ProductLimitDto> prodLimits;


    public static CompanyResponseDto convertToDto(Company company) {
        CompanyResponseDto companyResponseDto = new CompanyResponseDto();
        BeanUtils.copyProperties(company, companyResponseDto);
        companyResponseDto.setProdLimits(company.getCompanyProductLimitMapping().stream()
                .map(p -> {
                    ProductLimitDto dto = new ProductLimitDto();
                    dto.setProductId(p.getId()
                            .getProductId());
                    dto.setLimitAmt(p.getLimitAmount());
                    dto.setMidOfficeFlag(p.getMidOfficeFlag());

                    return dto;
                })
                .toList()
        );
        return companyResponseDto;
    }

    public Company convertToEntity(CompanyResponseDto companyResponseDto) {
        Company company = new Company();
        BeanUtils.copyProperties(companyResponseDto, company);
        return company;
    }

    public static CompanyResponseDto convertToTempDto(CompanyTemp companyTemp) {
        CompanyResponseDto companyResponseDto = new CompanyResponseDto();
        BeanUtils.copyProperties(companyTemp, companyResponseDto);
        if (Objects.nonNull(companyTemp.getSwiftAddress())) {
            companyResponseDto.setSwiftAddress(SwiftAddressDto.convertToDto(companyTemp.getSwiftAddress()));
        } if(Objects.nonNull(companyTemp.getAddress())) {
            companyResponseDto.setAddressDto(AddressDto.convertToDto(companyTemp.getAddress()));
        }
        companyResponseDto.setProdLimits(companyTemp.getCompanyProductLimitMapping().stream()
                .map(p -> {
                    ProductLimitDto dto = new ProductLimitDto();
                    dto.setProductId(p.getId()
                            .getProductId());
                    dto.setLimitAmt(p.getLimitAmount());
                    dto.setMidOfficeFlag(p.getMidOfficeFlag());

                    return dto;
                })
                .toList()
        );
        return companyResponseDto;
    }

    public CompanyTemp convertToTempEntity(CompanyResponseDto companyResponseDto) {
        CompanyTemp companyTemp = new CompanyTemp();
        BeanUtils.copyProperties(companyResponseDto, companyTemp);
        return companyTemp;
    }
}
