package com.indusind.trade.model.dtos.response.dtos;

import com.indusind.trade.model.dtos.requestdtos.UserDTO;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class JwtResponse {
    private String token;
    private String type = "Bearer";
    private String loginId;
    private String userFirstName;
    private String userLastName;
    private String email;
    private String role;
    private Long userId; // Added for dynamic access fetching
    private boolean termsSecurityPrivacyAccepted;
    private Long groupId;
    private String groupName;
    private String status;
    private String baseCurrency;
    private String lastLogin;

    public JwtResponse(String token, String loginId, String role, Long userId) {
        this.token = token;
        this.loginId = loginId;
        this.role = role;
        this.userId = userId;
    }

    public JwtResponse(String token, String loginId, String role, Long userId, boolean termsSecurityPrivacyAccepted) {
        this.token = token;
        this.loginId = loginId;
        this.role = role;
        this.userId = userId;
        this.termsSecurityPrivacyAccepted = termsSecurityPrivacyAccepted;
    }
    
    public JwtResponse(String token, String loginId, String email, String role, Long userId, boolean termsSecurityPrivacyAccepted) {
        this.token = token;
        this.loginId = loginId;
        this.email = email;
        this.role = role;
        this.userId = userId;
        this.termsSecurityPrivacyAccepted = termsSecurityPrivacyAccepted;
    }
}
