package com.indusind.trade.model.dtos.response.dtos;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class MyAccessResponseDto {

    private Long userId;
    private String username;
    private String userType;
    private List<ProductAccessDto> products = new ArrayList<>();

}
