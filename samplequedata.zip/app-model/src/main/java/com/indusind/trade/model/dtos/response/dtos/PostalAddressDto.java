package com.indusind.trade.model.dtos.response.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostalAddressDto {

    private String address1;
    private String address2;
    private String address3;
    private String city;
    private String state;
    private String country;
    private String pincode;
    private String category;

}
