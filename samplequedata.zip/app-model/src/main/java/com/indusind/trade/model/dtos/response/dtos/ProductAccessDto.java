package com.indusind.trade.model.dtos.response.dtos;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class ProductAccessDto {

    private Long productId;
    private String productName;
    private Boolean isMidOffice;
    private Long sequenceId;

    private List<SubProductAccessDto> subProducts = new ArrayList<>();

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<TabActionMappingAccessDto> tabActionMapping = new ArrayList<>();

}