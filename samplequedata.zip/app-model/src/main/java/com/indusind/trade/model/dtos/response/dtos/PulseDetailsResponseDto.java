package com.indusind.trade.model.dtos.response.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDateTime;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PulseDetailsResponseDto {
    @JsonProperty("Name")
    private String name;

    @JsonProperty("GENDER")
    private String gender;

    @JsonProperty("DEPARTMENT")
    private String department;

    @JsonProperty("CURRENT_DESIGNATION")
    private String currentDesignation;

    @JsonProperty("BUSINESS_UNIT")
    private String businessUnit;

    @JsonProperty("OU NAME")
    private String ouName;

    @JsonProperty("MAIL ID")
    private String mailId;

    @JsonProperty("Mobile_Number")
    private String mobileNumber;

    @JsonProperty("REPORTING MANAGER")
    private String reportingManager;

    @JsonProperty("REPORTING_MANAGER_NAME")
    private String reportingManagerName;

    @JsonProperty("REPORTING_MANAGER_DESIGNATION")
    private String reportingManagerDesignation;

    @JsonProperty("REPORTING_MANAGER_MAILID")
    private String reportingManagerMailId;

    @JsonProperty("WEEKLY OFF")
    private String weeklyOff;

    @JsonProperty("FUNCTIONAL REPORTING MANAGER")
    private String functionalReportingManager;

    @JsonProperty("COUNTRY")
    private String country;

    @JsonProperty("EMPLOYEE STATUS")
    private String employeeStatus;

    @JsonProperty("STATUS")
    private String status;

    @JsonProperty("BRANCH_CODE")
    private String branchCode;

    @JsonProperty("BRANCH ADDRESS")
    private String branchAddress;

    @JsonProperty("CURRENT_LOCATION")
    private String currentLocation;

    @JsonProperty("CITY_NAME")
    private String cityName;

    @JsonProperty("EMPLOYEE NUMBER")
    private String employeeNumber;

    @JsonProperty("DOJ")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime doj;

}


