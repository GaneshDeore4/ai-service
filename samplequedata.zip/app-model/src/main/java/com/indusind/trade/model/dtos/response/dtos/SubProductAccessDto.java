package com.indusind.trade.model.dtos.response.dtos;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class SubProductAccessDto {

    private Long subProductId;
    private String subProductName;
    private Long sequenceId;

    private List<TabActionMappingAccessDto> tabActionMapping = new ArrayList<>();

}
