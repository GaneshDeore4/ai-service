package com.indusind.trade.model.dtos.response.dtos;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class TabActionMappingAccessDto {

    private Long tabId;
    private String tabName;
    private List<ActionAccessDto> actions = new ArrayList<>();

}
