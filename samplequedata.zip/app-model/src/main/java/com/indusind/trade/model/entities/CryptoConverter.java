package com.indusind.trade.model.entities;

import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.utility.CryptoUtils;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import lombok.extern.slf4j.Slf4j;

@Converter
@Slf4j
public class CryptoConverter implements AttributeConverter<String, String> {
    @Override
    public String convertToDatabaseColumn(String attribute) {
        try {
            return attribute == null ? null : CryptoUtils.encrypt(attribute);
        } catch (Exception e) {
           log.error("Exception occurred while encryption: {}",e.getMessage());
           return attribute;
        }
    }
    @Override
    public String convertToEntityAttribute(String dbData) {
        try {
            return dbData == null ? null : CryptoUtils.decrypt(dbData);
        } catch (Exception e) {
            log.error("Exception occurred while decryption: {}",e.getMessage());
            return dbData;
        }
    }
}

