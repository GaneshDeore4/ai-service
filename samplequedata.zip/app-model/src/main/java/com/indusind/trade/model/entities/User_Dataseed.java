//
//package com.indusind.trade.admin.entities;
//
//import java.math.BigDecimal;
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.stream.Collectors;
//
//import jakarta.persistence.*;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.springframework.beans.BeanUtils;
//
//@Entity
//@Table(name = "GTP_USER")
//@Data
//@NoArgsConstructor
////@SequenceGenerator(name = "company_seq", sequenceName = "gtp_company_seq", allocationSize = 1)
//public class User_Dataseed extends UserBase{
//
//    @OneToMany(fetch = FetchType.LAZY, mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
//    private List<LegalIdDetails> legalIdDetailsList = new ArrayList<>();
//
//    @OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
//    private List<UserCompanyProductSubProdMapping> mappingUser = new ArrayList<>();
//
//    public static UserTemp convertToMaster(User user){
//        UserTemp userTemp = new UserTemp();
//        BeanUtils.copyProperties(user, userTemp);
//        userTemp.setLegalIdDetailsTempList(user.getLegalIdDetailsList().stream().map(LegalIdDetails::convertToMasterEntity).collect(Collectors.toList()));
//        return userTemp;
//    }
//
//    @Column(name = "PASSWORD", nullable = false)
//    private String password;
//
//    @Column(name = "CHANGE_PASSWORD", nullable = false)
//    private LocalDateTime passwordChangedAt;
//
////    @ManyToOne(fetch = FetchType.LAZY)
////    private Company company;
//
//}
//
////package com.indusind.trade.admin.entities;
////
////import java.math.BigDecimal;
////import java.time.LocalDateTime;
////
////import jakarta.persistence.*;
////import lombok.Data;
////import lombok.NoArgsConstructor;
////
////@Entity
////@Table(name = "GTP_USER")
////@Data
////@NoArgsConstructor
////@SequenceGenerator(name = "company_seq", sequenceName = "gtp_company_seq", allocationSize = 1)
////public class User_Dataseed {
////
////    @Id
////    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "company_seq")
////    @Column(name = "USER_ID")
////    private Long userId;
////
////    @Column(name = "ACTV_FLAG")
////    private String activeFlag;
////
////    @Column(name = "COMPANY_ABBV_NAME")
////    private String companyAbbvName;
////
////    @Column(name = "COMPANY_ID")
////    private Long companyId;
////
////    @Column(name = "LOGIN_ID")
////    private String loginId;
////
////    @Column(name = "FIRST_NAME")
////    private String firstName;
////
////    @Column(name = "LAST_NAME")
////    private String lastName;
////
////    @Column(name = "EMAIL")
////    private String email;
////
////    @Column(name = "PHONE")
////    private String phone;
////
////    @Column(name = "TELEPHONE_NUMBER")
////    private String telephoneNumber;
////
////    @Column(name = "FAX")
////    private String fax;
////
////    @Column(name = "ADDRESS_LINE_1")
////    private String addressLine1;
////
////    @Column(name = "ADDRESS_LINE_2")
////    private String addressLine2;
////
////    @Column(name = "DOM")
////    private String dom;
////
////    @Column(name = "COUNTRY")
////    private String country;
////
////    @Column(name = "COUNTRY_SUB_DIV")
////    private String countrySubDiv;
////
////    @Column(name = "COUNTY")
////    private String county;
////
////    @Column(name = "COUNTRY_NAME")
////    private String countryName;
////
////    @Column(name = "TIME_ZONE")
////    private String timeZone;
////
////    @Column(name = "LANGUAGE")
////    private String language;
////
////    @Column(name = "CORRESPONDENCE_LANGUAGE")
////    private String correspondenceLanguage;
////
////    @Column(name = "CUR_CODE")
////    private String currencyCode;
////
////    @Column(name = "ORG_LOGIN_ID")
////    private String orgLoginId;
////
////    @Column(name = "REFERENCE")
////    private String reference;
////
////    @Column(name = "RMGROUP")
////    private String rmGroup;
////
////    @Column(name = "PASSWORD")
////    private String password;
////
////    @Column(name = "PASSWORD_EXPIRY")
////    private LocalDateTime passwordExpiry;
////
////    @Column(name = "PASSWORD_MIGRATED")
////    private String passwordMigrated;
////
////    @Column(name = "PASSWORD_SHA2_MIGRATED")
////    private String passwordSha2Migrated;
////
////    @Column(name = "LAST_PASSWORD_CHANGE_DATE")
////    private LocalDateTime lastPasswordChangeDate;
////
////    @Column(name = "LOGIN_ATTEMPTS")
////    private Long loginAttempts;
////
////    @Column(name = "LOCKED_TIME")
////    private LocalDateTime lockedTime;
////
////    @Column(name = "ONE_FA_LAST_LOGIN")
////    private LocalDateTime oneFALastLogin;
////
////    @Column(name = "REAUTH_MODE")
////    private String reauthMode;
////
////    @Column(name = "TERMS_CONDS_ACCEPT_DATE")
////    private LocalDateTime termsCondsAcceptDate;
////
////    @Column(name = "COMPANY_DEFAULT_USER")
////    private String companyDefaultUser;
////
////    @Column(name = "SELF_ADMIN_USER_PROF")
////    private String selfAdminUserProf;
////
////    @Column(name = "PENDING_TRANS_NOTIFY")
////    private String pendingTransNotify;
////
////    @Column(name = "CREATED")
////    private LocalDateTime created;
////
////    @Column(name = "MODIFIED")
////    private LocalDateTime modified;
////
////    @Column(name = "DELETED")
////    private LocalDateTime deleted;
////
////    @Column(name = "LASTLOGIN")
////    private LocalDateTime lastLogin;
////
////    @Column(name = "ACCESS_COUNTER")
////    private Long accessCounter;
////
////    @Column(name = "CREATOR_COMPANY")
////    private String creatorCompany;
////
////    @Column(name = "CREATOR_ID")
////    private BigDecimal creatorId;
////
////    @Column(name = "CREATOR_LOGIN")
////    private String creatorLogin;
////
////    @Column(name = "EMPLOYEE_DEPARTMENT")
////    private String employeeDepartment;
////
////    @Column(name = "EMPLOYEE_NO")
////    private String employeeNo;
////
////    @Column(name = "LEGAL_COUNTRY")
////    private String legalCountry;
////
////    @Column(name = "LEGAL_NO")
////    private String legalNo;
////
////    @Column(name = "LEGAL_TYPE")
////    private String legalType;
////
////    @Column(name = "ENTITLEMENT_CODE")
////    private String entitlementCode;
////
////    @Column(name = "EXTERNAL_LOB")
////    private String externalLob;
////
////    @Column(name = "AMT_FORMAT")
////    private Long amountFormat;
////
////    @Column(name = "BANK2CUST_COMMENTS")
////    private String bankToCustomerComments;
////
////    @Column(name = "CUST2BANK_COMMENTS")
////    private String customerToBankComments;
////}
