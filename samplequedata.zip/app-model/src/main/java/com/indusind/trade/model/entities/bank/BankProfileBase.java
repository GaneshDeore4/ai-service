package com.indusind.trade.model.entities.bank;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import com.indusind.trade.model.entities.company.Address;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@MappedSuperclass
@Getter
@Setter
@RequiredArgsConstructor
@EntityListeners(HashListener.class)
public class BankProfileBase extends Auditable {

    @Column(name = "CIF_ID")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String cifId;

    @Column(name = "CIF_ID_HASH", unique = true)
    private String cifIdHash;

    @Column(name = "ABBV_NAME", nullable = false)
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String abbvName;

    @Column(name = "ABBV_NAME_HASH", unique = true)
    private String abbvNameHash;

    @Column(name = "NAME")
    private String name;

    @Embedded
    private Address address;

    @Embedded
    private BankSwiftAddress bankSwiftAddress;

    @Column(name = "TIME_ZONE")
    private String timeZone;

    @Column(name = "BASE_CURRENCY")
    private String baseCurrency;

    @Column(name = "CORR_LANGUAGE")
    private String corrLanguage;

    @Column(name = "CONTACT_NAME")
    private String contactName;

    @Column(name = "CONTACT_NUMBER")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String contactNumber;

    @Column(name = "CONTACT_NUMBER_HASH")
    private String contactNumberHash;

    @Column(name = "EMAIL")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String email;

    @Column(name = "EMAIL_HASH")
    private String emailHash;

    @CreationTimestamp
    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreationTimestamp
    @Column(name = "MODIFIED_DATE")
    private LocalDateTime modifiedDate;

    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

}
