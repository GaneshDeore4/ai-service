package com.indusind.trade.model.entities.bank;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "gtp_bank_profile_temp")
@Getter
@Setter
@RequiredArgsConstructor
public class BankProfileTemp extends BankProfileBase{

    @Id
    @Column(name = "BANK_PROFILE_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bankProfileId;

    @Column(name = "STATUS", nullable = false)
    private String status;

    @ManyToMany
    @JoinTable(
            name = "gtp_bank_profile_temp_product_mapping",
            joinColumns = @JoinColumn(name = "BANK_PROFILE_ID"),
            inverseJoinColumns = @JoinColumn(name = "PRODUCT_ID")
    )
    private List<ProductMaster> products;

    @ManyToMany
    @JoinTable(
            name = "gtp_bank_profile_temp_sub_product_mapping",
            joinColumns = @JoinColumn(name = "BANK_PROFILE_ID"),
            inverseJoinColumns = @JoinColumn(name = "SUB_PRODUCT_ID")
    )
    private List<SubProductMaster> subProducts;

    public static BankProfile convertToMasterEntity(BankProfileTemp bankProfileTemp, BankProfile bankProfile) {
        BeanUtils.copyProperties(bankProfileTemp, bankProfile);
        bankProfile.setProducts(Objects.nonNull(bankProfileTemp.getProducts()) ? new ArrayList<>(bankProfileTemp.getProducts()) : new ArrayList<>());
        bankProfile.setSubProducts(Objects.nonNull(bankProfileTemp.getSubProducts()) ? new ArrayList<>(bankProfileTemp.getSubProducts()) : new ArrayList<>());
        return bankProfile;
    }

}
