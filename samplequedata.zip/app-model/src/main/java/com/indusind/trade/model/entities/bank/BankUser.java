package com.indusind.trade.model.entities.bank;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "gtp_bank_user")
@Getter
@Setter
@RequiredArgsConstructor
public class BankUser extends BankUserBase{

    @Id
    @Column(name = "BANK_USER_ID")
    private Long bankUserId;

    private Boolean isUserLocked = false;

    private LocalDateTime lockedDate;

    private LocalDateTime changePasswordDate;

    @Column(name = "OTP_FAILED_COUNT")
    private Long otpFailedCount = 0L;

    @Column(name = "LOGIN_FAILED_COUNT")
    private Long loginFailedCount = 0L;

    @Column(name ="TERMS_PRIVACY_ACCEPTED")
    private  boolean termPrivacyAccepted = false;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "bankUser", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<BankUserProductSubProductMapping> mappingUser = new ArrayList<>();

    public static BankUserTemp convertToTempEntity(BankUser user, BankUserTemp userTemp){

        BeanUtils.copyProperties(user, userTemp,"bankUserId");
        return userTemp;
    }

    public void addBankUserProdSubProd(BankUserProductSubProductMapping bankUserProductSubProductMapping){
        bankUserProductSubProductMapping.setBankUser(this);
        mappingUser.add(bankUserProductSubProductMapping);
    }

}