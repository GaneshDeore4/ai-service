package com.indusind.trade.model.entities.bank;


import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import com.indusind.trade.model.entities.master.UserType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@MappedSuperclass
@Getter
@Setter
@RequiredArgsConstructor
@EntityListeners(HashListener.class)
public class BankUserBase extends Auditable {


    @Column(name = "LOGIN_ID", unique = true)
    private String loginId;

    @Column(name = "FIRST_NAME")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String firstName;

    @Column(name = "FIRST_NAME_HASH")
    private String firstNameHash;

    @Column(name = "LAST_NAME")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String lastName;

    @Column(name = "LAST_NAME_HASH")
    private String lastNameHash;

    @Column(name = "EMPLOYEE_NO")
    private String employeeNo;

    @Column(name = "DEPARTMENT")
    private String department;

    @ManyToOne
    @JoinColumn(name = "USER_TYPE_ID")
    private UserType userType;

    @Embedded
    private OfficeAddress officeAddress;

    @Column(name = "BANK_USER_STATUS")
    private String bankUserStatus;

    @Column(name = "TIME_ZONE")
    private String timeZone;

    @Column(name = "CORR_LANGUAGE")
    private String corrLanguage;

    @Column(name = "BASE_CURR")
    private String baseCurr;

    @Column(name = "SOL_ID")
    private String solId;

    @Column(name = "BRANCH_NAME")
    private String branchName;

    @Column(name = "CONTACT_NO")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String contactNo;

    @Column(name = "CONTACT_NO_HASH")
    private String contactNoHash;

    @Column(name = "CONTACT_NO_COUNTRY_CODE")
    private String contactNoCountryCode;

    @Column(name = "EMAIL")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String email;

    @Column(name = "EMAIL_HASH")
    private String emailHash;

    @Column(name = "GROUP_EMAIL")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String groupEmail;

    @Column(name = "GROUP_EMAIL_HASH")
    private String groupEmailHash;

    @Column(name = "TRANS_NOTIFY")
    private String transNotify;

    @Column(name = "USER_PASSWORD")
    private String userPassword;

    @ManyToOne
    @JoinColumn(name = "BANK_ID")
    private BankProfile bankProfile;

    @Column(name = "LAST_LOGIN")
    private LocalDateTime lastLogin;

    @CreationTimestamp
    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreationTimestamp
    @Column(name = "MODIFIED_DATE")
    private LocalDateTime modifiedDate;

    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

    private Boolean isFirstLoginFlag = true;
}
