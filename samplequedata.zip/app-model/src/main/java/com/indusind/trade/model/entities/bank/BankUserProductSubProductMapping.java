package com.indusind.trade.model.entities.bank;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.BeanUtils;


@Entity
@Getter
@Setter
@Table(name = "gtp_bank_user_prod_subprod_mapping", uniqueConstraints = @UniqueConstraint(name = "uk_bank_user_permission_combination",
columnNames = {
        "bank_user_id",
        "product_id",
        "subproduct_id"
}))
public class BankUserProductSubProductMapping {

    @Id
    private Long bankUserprodsubprodId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bank_user_id", nullable = false)
    private BankUser bankUser;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster productMaster;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subproduct_id", nullable = false)
    private SubProductMaster subProductMaster;

    public static BankUserProductSubProductMappingTemp convertToTempEntity(BankUserProductSubProductMapping bankUserMap){
        BankUserProductSubProductMappingTemp bankUserProductSubProductMappingTemp = new BankUserProductSubProductMappingTemp();
        BeanUtils.copyProperties(bankUserMap, bankUserProductSubProductMappingTemp);
        return bankUserProductSubProductMappingTemp;
    }

}
