package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "account_audits")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(HashListener.class)
public class AccountAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cif_id")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String cifId;

    @Column(name = "cif_id_hash")
    private String cifIdHash;

    @Column(name = "account_number")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String accountNumber;

    @Column(name = "account_number_hash")
    private String accountNumberHash;

    @Column(name = "field_name")
    private String fieldName;

    @Column(name = "old_value", length = 1000)
    private String oldValue;

    @Column(name = "new_value", length = 1000)
    private String newValue;

    @Column(name = "updated_by")
    private String updatedBy;

    @CreationTimestamp
    @Column(name = "updated_at", updatable = false)
    private LocalDateTime updatedAt;
}
