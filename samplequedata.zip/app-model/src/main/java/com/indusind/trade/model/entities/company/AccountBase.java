package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;


@MappedSuperclass
@Getter
@Setter
@RequiredArgsConstructor
@EntityListeners(HashListener.class)
public class AccountBase {

    @Column(name = "ACCOUNT_NO", nullable = false)
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String accountNo;

    @Column(name = "ACCOUNT_NO_HASH", nullable = false)
    private String accountNoHash;

    @Column(name = "ACCOUNT_TYPE", nullable = false)
    private String accountType;

    @Column(name = "CURRENCY")
    private String currency;

    @Column(name = "SOL_ID")
    private String solId;

    @Column(name = "SOL_DESCRIPTION")
    private String solDescription;

    @Column(name = "ACTIVE_FLAG")
    private String activeFlag;

    @CreationTimestamp
    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreationTimestamp
    @Column(name = "MODIFIED_DATE")
    private LocalDateTime modifiedDate;

    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

}
