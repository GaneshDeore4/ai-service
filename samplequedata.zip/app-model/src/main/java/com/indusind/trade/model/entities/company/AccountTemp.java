package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_account_temp")
@Getter
@Setter
@RequiredArgsConstructor
public class AccountTemp extends AccountBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACCOUNT_ID")
    private Long accountId;

    @Column(name = "STATUS")
    private String status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID", nullable = false)
    private CompanyTemp companyTemp;

    public static Account convertToMasterEntity(AccountTemp accountTemp){
        Account account = new Account();
        BeanUtils.copyProperties(accountTemp, account);
        return account;
    }


}
