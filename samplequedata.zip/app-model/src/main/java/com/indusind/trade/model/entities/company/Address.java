package com.indusind.trade.model.entities.company;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Embeddable
@Getter
@Setter
@RequiredArgsConstructor
public class Address {

    @Column(name = "STREET_NAME")
    private String streetName;

    @Column(name = "TOWN_NAME")
    private String townName;

    @Column(name = "COUNTRY_SUB_DIV")
    private String countrySubDiv;

    @Column(name = "POST_CODE")
    private String postCode;

}
