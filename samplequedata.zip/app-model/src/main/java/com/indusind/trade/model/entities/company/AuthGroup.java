package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "gtp_auth_group")
@RequiredArgsConstructor
@Getter
@Setter
public class AuthGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String authGroup;

}
