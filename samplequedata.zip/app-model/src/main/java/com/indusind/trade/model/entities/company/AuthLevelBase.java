package com.indusind.trade.model.entities.company;

import jakarta.persistence.FetchType;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@MappedSuperclass
@Getter
@Setter
@SuperBuilder
@RequiredArgsConstructor
public class AuthLevelBase {

    private Integer seqNo;

    @ManyToOne(fetch = FetchType.LAZY)
    private AuthGroup authGroup;


}
