package com.indusind.trade.model.entities.company;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.enums.AuthType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@MappedSuperclass
@Getter
@Setter
@SuperBuilder
@RequiredArgsConstructor
public class AuthMatrixBase extends Auditable {

    @ManyToOne
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

//    @Enumerated(EnumType.STRING)
//    private AuthType authType;

    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster product;

    @ManyToOne
    @JoinColumn(name = "subproduct_id", nullable = false)
    private SubProductMaster subProduct;

    private String currencyType;

    private Long amount;

    private Boolean isSequential;

    private Boolean isVerifier;

    private Boolean isReleaser;

    private Boolean isAllProductFlag = false;

    private String category;

}
