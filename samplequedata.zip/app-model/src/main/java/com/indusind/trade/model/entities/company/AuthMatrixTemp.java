package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.dtos.requestdtos.AddAuthMatrixRequestDto;
import com.indusind.trade.model.entities.master.EventType;
import com.indusind.trade.model.entities.master.EventTypeTemp;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.BatchSize;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "gtp_auth_matrix_temp")
@Getter
@Setter
@AllArgsConstructor
@SuperBuilder
@NoArgsConstructor
public class AuthMatrixTemp extends AuthMatrixBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String status;

    @OneToMany(mappedBy = "authMatrixTemp", cascade = CascadeType.ALL, orphanRemoval = true)
    @BatchSize(size = 50)
    private List<AuthLevelTemp> authLevels = new ArrayList<>();

//    @OneToMany(mappedBy = "authMatrix", cascade = CascadeType.ALL, orphanRemoval = true)
//    @BatchSize(size = 50)
//    private List<EventTypeTemp> eventTypes = new ArrayList<>();

    @ManyToMany
    @JoinTable(
            name = "gtp_auth_mat_temp_account_mapping",
            joinColumns = @JoinColumn(name = "ID"),
            inverseJoinColumns = @JoinColumn(name = "ACCOUNT_ID")
    )
    private List<AccountDetail> accounts = new ArrayList<>();


    public static AuthMatrix convertToMaster(AuthMatrixTemp authMatrixTemp, AuthMatrix authMatrix) {
        BeanUtils.copyProperties(authMatrixTemp, authMatrix,"accounts");
        authMatrix.getAuthLevels().addAll((authMatrixTemp.getAuthLevels().stream().map(
                mat -> {
                    AuthLevel authLevel = AuthLevelTemp.convertToMaster(mat);
                    authLevel.setAuthMatrix(authMatrix);
                    return authLevel;
                }
        ).toList()));
//        List<AccountDetail> accountDetails = new ArrayList<>(authMatrixTemp.getAccounts());
            authMatrix.getAccounts().clear();
            authMatrix.getAccounts().addAll(authMatrixTemp.getAccounts());

//        authMatrix.getEventTypes().addAll((authMatrixTemp
//                .getEventTypes().stream().map(
//                        mat -> {
//                            EventType eventType = EventTypeTemp.convertToMaster(mat);
//                            eventType.setAuthMatrix(authMatrix);
//                            return eventType;
//                        }
//                ).toList()));
        return authMatrix;
    }

    public static AuthMatrixTemp convertToTemp(AuthMatrix authMatrix) {
        AuthMatrixTemp authMatrixTemp = new AuthMatrixTemp();
        BeanUtils.copyProperties(authMatrix, authMatrixTemp);
        authMatrixTemp.setAuthLevels(authMatrix.getAuthLevels().stream().map(AuthLevelTemp :: convertToTemp).toList());
        return authMatrixTemp;
    }

    public static AuthMatrixTemp convertFromAddReqDtoToTemp(AddAuthMatrixRequestDto request, AuthMatrixTemp authMatrixTemp) {
        BeanUtils.copyProperties(request, authMatrixTemp);
        authMatrixTemp.setId(request.authMatId());
        return authMatrixTemp;
    }
}
