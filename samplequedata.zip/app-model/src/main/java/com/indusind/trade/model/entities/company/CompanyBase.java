package com.indusind.trade.model.entities.company;

import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import com.indusind.trade.model.utility.HashUtils;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.Objects;


@MappedSuperclass
@Getter
@Setter
@RequiredArgsConstructor
@EntityListeners(HashListener.class)
public class CompanyBase extends Auditable {


        @Column(name = "CIF_ID", nullable = false)
        @Convert(converter = CryptoConverter.class)
        @HashField
        private String cifId;

        @Column(name = "CIF_ID_HASH", nullable = false, unique = true)
        private String cifIdHash;


        @Column(name = "ABBV_NAME", nullable = false)
        @Convert(converter = CryptoConverter.class)
        @HashField
        private String abbvName;

        @Column(name = "ABBV_NAME_HASH", nullable = false, unique = true)
        private String abbvNameHash;

        @Column(name = "NAME", nullable = false)
        @Convert(converter = CryptoConverter.class)
        @HashField
        private String name;

        @Column(name = "NAME_HASH", nullable = false, unique = true)
        private String nameHash;

        @Embedded
        private Address address;

        @Embedded
        private SwiftAddress swiftAddress;

        @Column(name = "DUAL_CONTROL")
        private String dualControl;

        @Column(name = "CONTROL_STATUS")
        private String controlStatus;

        @Column(name = "authorize_own_transaction")
        private String authOwnTransaction;

        @Column(name = "INITIAL_ADMIN")
        private String initialAdmin;

        @Column(name = "BASE_CURRENCY")
        private String baseCurrency;

        @Column(name = "CLIENT_SEGMENT")
        private String clientSegment;

        @Column(name = "EMAIL", nullable = false)
        @Convert(converter = CryptoConverter.class)
        @HashField
        private String email;

        @Column(name = "EMAIL_HASH", nullable = false, unique = true)
        private String emailHash;

        @CreationTimestamp
        @Column(name = "CREATED_DATE")
        private LocalDateTime createdDate;

        @Column(name = "CREATED_BY")
        private String createdBy;

        @CreationTimestamp
        @Column(name = "MODIFIED_DATE")
        private LocalDateTime modifiedDate;

        @Column(name = "MODIFIED_BY")
        private String modifiedBy;

//        @ManyToOne
//        @JoinColumn(name = "categoryId")
//        private CategoryMaster categoryMaster;

}
