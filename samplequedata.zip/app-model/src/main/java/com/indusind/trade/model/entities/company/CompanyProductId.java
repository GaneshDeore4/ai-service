package com.indusind.trade.model.entities.company;


import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Embeddable
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class CompanyProductId implements Serializable {

    private Long companyId;
    private Long productId;

}
