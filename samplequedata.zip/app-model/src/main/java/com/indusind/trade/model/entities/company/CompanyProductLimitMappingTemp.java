package com.indusind.trade.model.entities.company;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_company_product_limit_mapping_temp")
@Getter
@Setter
@RequiredArgsConstructor
public class CompanyProductLimitMappingTemp {

    @EmbeddedId
    private CompanyProductId id;

    private Long limitAmount;

    private Boolean midOfficeFlag = false;

    public static CompanyProductLimitMapping convertToMasterEntity(CompanyProductLimitMappingTemp dto) {
        CompanyProductLimitMapping entity = new CompanyProductLimitMapping();
        BeanUtils.copyProperties(dto, entity);

        return entity;
    }

    public static CompanyProductLimitMappingTemp convertToTemp(CompanyProductLimitMapping entity) {
        CompanyProductLimitMappingTemp dto = new CompanyProductLimitMappingTemp();
        BeanUtils.copyProperties(entity, dto);

        return dto;
    }
}
