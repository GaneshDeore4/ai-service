package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_customer_reference")
@Getter
@Setter
@RequiredArgsConstructor
public class CustomerReference extends CustomerReferenceBase{

    @Id
    @Column(name = "CUSTOMER_REFERENCE_ID")
    private Long customerReferenceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COMPANY_ID", referencedColumnName = "COMPANY_ID", nullable = false)
    private Company company;

    public static CustomerReferenceTemp convertToTempEntity(CustomerReference customerReference) {
        CustomerReferenceTemp customerReferenceTemp = new CustomerReferenceTemp();
        BeanUtils.copyProperties(customerReference, customerReferenceTemp, "customerReferenceId");
        return customerReferenceTemp;
    }

}

