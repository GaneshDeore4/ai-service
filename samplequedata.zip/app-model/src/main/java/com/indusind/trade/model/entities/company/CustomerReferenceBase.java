package com.indusind.trade.model.entities.company;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@MappedSuperclass
@Setter
@Getter
@RequiredArgsConstructor
public class CustomerReferenceBase {

    @Column(name = "TRADE_PRO_ZONE", nullable = false)
    private String tradeProZone;

    @Column(name = "SOL_ID", nullable = false)
    private String solId;

    @Column(name = "SOL_DESCRIPTION")
    private String solDescription;

    @Column(name = "CUSTOMER_REFERENCE")
    private String customerReference;

    @Column(name = "CUSTOMER_REFERENCE_DESCRIPTION")
    private String customerReferenceDescription;

    @Column(name = "DEFAULT_REFERENCE")
    private String defaultReference;

    @CreationTimestamp
    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreationTimestamp
    @Column(name = "MODIFIED_DATE")
    private LocalDateTime modifiedDate;

    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

}
