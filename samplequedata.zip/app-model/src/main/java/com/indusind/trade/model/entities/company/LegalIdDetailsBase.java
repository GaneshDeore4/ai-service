package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.enums.LegalIdType;
import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
@RequiredArgsConstructor
public class LegalIdDetailsBase {

    @Enumerated(EnumType.STRING)
    @Column(name = "legal_id_type", nullable = false)
    private LegalIdType legalIdType;

    @Column(name = "LEGAL_ID_NO")
    private String legalIdNo;

    @Column(name = "Legal_Id_Issuing_Authority")
    private String legalIdIssuingAuthority;

//    @Version
//    private Long version;

}