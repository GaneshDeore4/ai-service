package com.indusind.trade.model.entities.company;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "GTP_USER")
@Getter
@Setter
@NoArgsConstructor
//@SequenceGenerator(name = "company_seq", sequenceName = "gtp_company_seq", allocationSize = 1)
public class User extends UserBase {

    @Id
    @Column(name = "USER_ID")
    private Long userId;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LegalIdDetails> legalIdDetailsList = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserCompanyProductSubProdMapping> mappingUser = new ArrayList<>();

    private Boolean isUserLocked = false;

    private LocalDateTime lockedDate;

    @ManyToMany(fetch = FetchType.LAZY)
    private List<AccountDetail> accountMapping;

    @Column(name ="TERMS_PRIVACY_ACCEPTED")
    private  boolean termPrivacyAccepted = false;

    public static UserTemp convertToMaster(User user, UserTemp userTemp){
       // UserTemp userTemp = new UserTemp();
        BeanUtils.copyProperties(user, userTemp);
        //userTemp.setLegalIdDetailsTempList(user.getLegalIdDetailsList().stream().map(LegalIdDetails::convertToTempEntity).collect(Collectors.toList()));
        return userTemp;
    }

    @Column(name = "OTP_FAILED_COUNT")
    private Long otpFailedCount = 0L;

    @Column(name = "LOGIN_FAILED_COUNT")
    private Long loginFailedCount = 0L;

    @Column(name = "CHANGE_PASSWORD_DATE")
    private LocalDateTime changePasswordDate;

//    @ManyToMany
//    @JoinTable(
//            name = "user_authgroup_mapping",
//            joinColumns = @JoinColumn(name = "USER_ID"),
//            inverseJoinColumns = @JoinColumn(name = "id")
//                )
//    private List<AuthGroup> authGroup;

//    @ManyToOne(fetch = FetchType.LAZY)
//    private Company company;

    public static UserTemp convertToTempEntity(User user, UserTemp userTemp){

        BeanUtils.copyProperties(user, userTemp,"userId");
//        user.setAuthGroup(Objects.nonNull(userTemp.getAuthGroup()) ? new ArrayList<>(userTemp.getAuthGroup()) : new ArrayList<>());
        //user.setLegalIdDetailsList(userTemp.getLegalIdDetailsTempList().stream().map(LegalIdDetailsTemp::convertToMasterEntity).collect(Collectors.toList()));
        return userTemp;
    }

    public void addLegalId(LegalIdDetails legal) {
        legal.setUser(this);
        legalIdDetailsList.add(legal);
    }

    public void addUserCompanyProdSubProd(UserCompanyProductSubProdMapping userCompanyProductSubProdMapping) {
        userCompanyProductSubProdMapping.setUser(this);
        mappingUser.add(userCompanyProductSubProdMapping);
    }


}
