package com.indusind.trade.model.entities.company;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "gtp_user_company_product_subprod_mapping_temp",
        indexes = {
                @Index(name = "idx_user_company_prod_subprod_user_temp", columnList = "user_id"),
//                @Index(name = "idx_user_company_prod_subprod_company_temp", columnList = "company_id"),
                @Index(name = "idx_user_company_prod_subprod_prod_temp", columnList = "product_id"),
                @Index(name = "idx_user_company_prod_subprod_subprod_temp", columnList = "subproduct_id")
        },
        uniqueConstraints = @UniqueConstraint(
            name = "uk_user_company_permission_temp_combination",
            columnNames = {
                "user_id",
                "product_id",
                "subproduct_id"
            }
        )
)

@RequiredArgsConstructor
public class UserCompanyProductSubProdMappingTemp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long usercompanysubproductid;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private UserTemp userTemp;

//    @ManyToOne(fetch = FetchType.LAZY, optional = false)
//    @JoinColumn(name = "company_id", nullable = false)
//    private Company company;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    private ProductMaster productMaster;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subproduct_id")
    private SubProductMaster subProductMaster;

    public static List<UserCompanyProductSubProdMapping> convertToMasterList(List<UserCompanyProductSubProdMappingTemp> userMappingListTemp){
        List<UserCompanyProductSubProdMapping> userMappingList = new ArrayList<>();
        for(UserCompanyProductSubProdMappingTemp userTempMapping : userMappingListTemp){
            UserCompanyProductSubProdMapping userMapping = new UserCompanyProductSubProdMapping();
            BeanUtils.copyProperties(userTempMapping, userMapping);
            userMappingList.add(userMapping);
        }
        return userMappingList;
    }

    public static UserCompanyProductSubProdMapping convertToMasterEntity(UserCompanyProductSubProdMappingTemp userMapTemp) {
        UserCompanyProductSubProdMapping userCompanyProductSubProdMapping =  new UserCompanyProductSubProdMapping();
        BeanUtils.copyProperties(userMapTemp,userCompanyProductSubProdMapping );
        return userCompanyProductSubProdMapping;
    }
}
