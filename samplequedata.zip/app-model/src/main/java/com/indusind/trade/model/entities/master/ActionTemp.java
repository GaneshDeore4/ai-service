package com.indusind.trade.model.entities.master;
import com.indusind.audit.entity.Auditable;
import com.indusind.trade.model.enums.Status;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "gtp_action_master_temp",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_action",
                        columnNames = {"ACTION_CODE", "PRODUCT_ID", "SUB_PRODUCT_ID"})
        }
)
@Getter
@Setter
@RequiredArgsConstructor
public class ActionTemp extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ACTION_ID")
    private Long actionId;

    @Column(name = "ACTION_CODE", nullable = false)
    private String actionCode;

    @Column(name = "ACTION_NAME_LABEL")
    private String actionNameLabel;

    @Column(name="STATUS", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status status;

//    @ManyToMany(fetch = FetchType.LAZY)
//    @JoinTable(
//            name = "gtp_action_product_mapping_temp",
//            joinColumns = @JoinColumn(name = "ACTION_ID"),
//            inverseJoinColumns = @JoinColumn(name = "PRODUCT_ID")
//    )    private List<ProductMasterTemp> productMasterTemp = new ArrayList<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private ProductMaster product;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SUB_PRODUCT_ID")
    private SubProductMaster subProduct;

    @CreationTimestamp
    @Column(name = "CREATED_DATE", nullable = false, updatable = false)
    private LocalDateTime createdDate;
}

