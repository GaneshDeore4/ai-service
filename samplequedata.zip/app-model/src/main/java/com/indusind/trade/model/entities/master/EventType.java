package com.indusind.trade.model.entities.master;

import com.indusind.trade.model.entities.company.AuthMatrix;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "gtp_event_type")
@RequiredArgsConstructor
@Getter
@Setter
public class EventType extends EventTypeBase{

    @Id
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auth_matrix_id")
    private AuthMatrix authMatrix;

}
