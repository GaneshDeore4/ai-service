package com.indusind.trade.model.entities.master;

import com.indusind.trade.model.enums.AuthType;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@MappedSuperclass
@Getter
@Setter
@SuperBuilder
@RequiredArgsConstructor
public class EventTypeBase {

    @Enumerated(EnumType.STRING)
    private AuthType eventType;

}
