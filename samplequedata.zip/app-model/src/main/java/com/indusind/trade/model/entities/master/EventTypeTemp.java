package com.indusind.trade.model.entities.master;

import com.indusind.trade.model.entities.company.AuthMatrixTemp;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.springframework.beans.BeanUtils;

@Entity
@Table(name = "gtp_event_type_temp")
@RequiredArgsConstructor
@Getter
@Setter
@SuperBuilder
public class EventTypeTemp extends EventTypeBase{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "auth_matrix_id")
    private AuthMatrixTemp authMatrix;

    public static EventType convertToMaster(EventTypeTemp eventTypeTemp) {
        EventType eventType = new EventType();
        BeanUtils.copyProperties(eventTypeTemp, eventType);

        return eventType;
    }
}
