package com.indusind.trade.model.entities.master;

import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "gtp_otp", indexes = {
        @Index(name = "idx_mobile", columnList = "mobileNumber")
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(HashListener.class)
public class Otp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Convert(converter = CryptoConverter.class)
    @HashField
    private String mobileNumber;

    private String mobileNumberHash;

    private String encryptedOtp;

    private Boolean verified;

    private String loginId;

    @Convert(converter = CryptoConverter.class)
    @HashField
    private  String bankAbbvName;

    private  String bankAbbvNameHash;

    @Convert(converter = CryptoConverter.class)
    @HashField
    private String companyCifId;

    private String companyCifIdHash;

    private String otpReference;

    private LocalDateTime createdAt;

    private LocalDateTime expiryTime;
}
