package com.indusind.trade.model.entities.master;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

/**
 * Registry of trusted devices per user.
 * Status: TRUSTED | PENDING_APPROVAL | BLOCKED
 * Admin can approve/block devices.
 */
@Entity
@Table(name = "TRUSTED_DEVICE", indexes = {
        @Index(name = "idx_td_loginid", columnList = "LOGIN_ID"),
        @Index(name = "idx_td_fingerprint", columnList = "DEVICE_FINGERPRINT")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TrustedDevice {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "trusted_device_seq")
    @SequenceGenerator(name = "trusted_device_seq", sequenceName = "TRUSTED_DEVICE_SEQ", allocationSize = 1)
    @Column(name = "DEVICE_ID")
    private Long deviceId;

    @Column(name = "LOGIN_ID", nullable = false, length = 100)
    private String loginId;

    @Column(name = "CIF_ID_ABBV_NAME")
    private String cifIdAbbvName;

    /** SHA-256 of User-Agent + Accept-Language + IP subnet */
    @Column(name = "DEVICE_FINGERPRINT", nullable = false, length = 256)
    private String deviceFingerprint;

    @Column(name = "DEVICE_ALIAS", length = 100)
    private String deviceAlias; // "Office Laptop", "Mobile Chrome"

    /** TRUSTED | PENDING_APPROVAL | BLOCKED */
    @Column(name = "STATUS", nullable = false, length = 20)
    private String status;

    @CreationTimestamp
    @Column(name = "REGISTERED_AT", updatable = false)
    private Instant registeredAt;

    @Column(name = "LAST_USED_AT")
    private Instant lastUsedAt;

    @Column(name = "REGISTERED_BY_IP", length = 64)
    private String registeredByIp;

    @Column(name = "APPROVED_BY", length = 100)
    private String approvedBy;

    @Column(name = "APPROVED_AT")
    private Instant approvedAt;

    @Column(name = "BLOCKED_REASON", length = 255)
    private String blockedReason;
}
