package com.indusind.trade.model.entities.master;

import com.indusind.trade.model.entities.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.model.entities.HashListener;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Tracks full session lifecycle for audit compliance.
 * Persisted in Auth Service DB — append-only enrichment (no deletes).
 */
@Entity
@Table(name = "USER_SESSION", indexes = {
        @Index(name = "idx_session_loginid", columnList = "LOGIN_ID"),
        @Index(name = "idx_session_status", columnList = "STATUS")
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(HashListener.class)
public class UserSession {

    @Id
    @Column(name = "SESSION_ID", length = 36)
    private String sessionId; // UUID — embedded in JWT claim

    @Column(name = "LOGIN_ID", nullable = false)
    private String loginId;

    @Column(name = "CIF_ID_ABBV_NAME")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String cifIdAbbvName;

    @Column(name = "CIF_ID_ABBV_NAME_HASH")
    private String cifIdAbbvNameHash;

//    @Column(name = "ROLE_NAME")
//    private String roleName;

    @Column(name = "USER_TYPE")
    private String userType; // USER / SERVICE

    @Column(name = "IP_ADDRESS", length = 64)
    private String ipAddress;

    @Column(name = "DEVICE_FINGERPRINT", length = 256)
    private String deviceFingerprint;

    @Column(name = "DEVICE_ID", length = 64)
    private String deviceId; // From TrustedDevice registry

    @Column(name = "LOGIN_TIME", nullable = false, updatable = false)
    private Instant loginTime;

    @Column(name = "LAST_ACTIVE_TIME")
    private Instant lastActiveTime;

    @Column(name = "LOGOUT_TIME")
    private Instant logoutTime;

    @Column(name = "LOGOUT_REASON", length = 50)
    private String logoutReason; // EXPLICIT_LOGOUT / TOKEN_EXPIRED / ADMIN_REVOKED

    @Column(name = "STATUS", nullable = false, length = 20)
    private String status; // ACTIVE / LOGGED_OUT / EXPIRED / REVOKED
}
