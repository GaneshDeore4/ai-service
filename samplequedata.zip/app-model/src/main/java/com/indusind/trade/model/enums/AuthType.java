package com.indusind.trade.model.enums;

public enum AuthType {
    NEW,
    AMEND,
    CLOSE,
    PAYMENT
}
