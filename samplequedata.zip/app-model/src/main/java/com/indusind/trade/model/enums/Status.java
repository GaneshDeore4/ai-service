package com.indusind.trade.model.enums;

public enum Status {

    PENDING,

    APPROVED,

    UPDATE_REJECTED,

    REJECTED
}
