package com.indusind.trade.model.enums;


import jdk.jfr.Registered;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum UsersType {
    SUPERADMIN("Super Admin"),
    ADMINMAKER("Admin Maker"),
    ADMINCHECKER("Admin Checker"),
    ADMIN("Admin (M=C)"),
    MAKER("Maker"),
    CHECKER("Checker");

    private final String dbValue;
}
