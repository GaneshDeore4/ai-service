package com.indusind.trade.model.exception;

public class GTPAppException extends RuntimeException{
    public GTPAppException(String message, Throwable cause) {
        super(message, cause);
    }
}
