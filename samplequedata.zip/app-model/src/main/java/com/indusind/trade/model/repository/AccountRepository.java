package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.AccountDetail;
import com.indusind.trade.model.utility.HashUtils;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<AccountDetail, String> {

    default List<AccountDetail> findByCifId(String cifId){
        return findByCifIdHash(HashUtils.HAMCMD5Hash(cifId));
    }

    List<AccountDetail> findByCifIdHash(String cifId);

//    Optional<AccountDetail> findByAccountNumber(String accountNumber);

    default List<AccountDetail> findAllByAccountNumberIn(List<String> accountNumbers) {
        return findAllByAccountNumberHashIn(
                accountNumbers.stream()
                        .map(HashUtils :: HAMCMD5Hash)
                        .toList()
        );
    }
    List<AccountDetail> findAllByAccountNumberHashIn(List<String> accountNumbers);
}
