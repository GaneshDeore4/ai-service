package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.AccountTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountTempDao extends JpaRepository<AccountTemp, Long> {
}
