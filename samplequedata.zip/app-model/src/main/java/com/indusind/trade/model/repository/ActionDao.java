package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.Action;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ActionDao extends JpaRepository<Action, Long> {
    List<Action> findAllByOrderByActionCodeAsc();

    Optional<Action> findByActionCode(String actionName);

    List<Action> findByProductProductIdAndSubProductSubProductId(Long productId, Long subProductId);

    List<Action> findByProductProductId(Long productId);

    List<Action> findByProductProductIdAndSubProductSubProductIdIsNull(Long productId);
}
