package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.AuthGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthGroupDao extends JpaRepository<AuthGroup, Long> {
}
