package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.AuthLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthLevelDao extends JpaRepository<AuthLevel, Long> {
}
