package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.AuthLevelTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthLevelTempDao extends JpaRepository<AuthLevelTemp, Long> {
}
