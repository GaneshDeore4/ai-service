package com.indusind.trade.model.repository;

import com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupKeyDto;
import com.indusind.trade.model.entities.company.AuthMatrix;
import com.indusind.trade.model.entities.company.AuthMatrixTemp;
import com.indusind.trade.model.utility.HashUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AuthMatrixDao extends JpaRepository<AuthMatrix, Long> {
    Long deleteByCompanyCompanyIdAndProductProductId(Long companyId, Long productId);

    @Query("""
                SELECT a
                FROM AuthMatrix a
                WHERE a.isAllProductFlag = true
                AND a.category = :category
                AND (:companyId IS NULL OR a.company.companyId = :companyId)
            """)
    Page<AuthMatrixTemp> findPagedAuthMatrix(
            @org.springframework.data.repository.query.Param("category") String category,
            @org.springframework.data.repository.query.Param("companyId") Long companyId,
            Pageable pageable);

    @Query("""
                SELECT new com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupKeyDto(
                    a.company.id,
                    a.amount
                )
                FROM AuthMatrix a
                WHERE a.isAllProductFlag = true
                GROUP BY a.company.id, a.amount
            """)
    Page<AuthMatrixGroupKeyDto> findGroupedKeys(Pageable pageable);

//    Page<AuthMatrix> findByIsAllProductFlag(boolean productFlag, Pageable page);

    Optional<AuthMatrix> findByIdAndCategory(Long id, String category);

    Page<AuthMatrix> findByIsAllProductFlagAndCategory(boolean productFlag, String category, Pageable page);

    Page<AuthMatrix> findByIsAllProductFlagAndCategoryAndCompanyCompanyId(boolean productFlag, String category, Long companyId, Pageable page);

//    @Query("""
//            SELECT m FROM AuthMatrix m
//            WHERE m.company.cifId = :cifId
//            AND m.product.productId = :productId
//            AND m.subProduct.subProductId = :subProductId
//            AND m.currencyType = :userBaseCurrency
//            AND m.amount >= :amount
//            """)
//    List<AuthMatrix> findMatrices(String cifId, Long productId, Long subProductId,Double amount, String userBaseCurrency);

    @Query("""
            SELECT m FROM AuthMatrix m
            JOIN m.accounts a
            WHERE m.company.cifIdHash = :cifId
            AND m.product.productId = :productId
            AND m.subProduct.subProductId = :subProductId
            AND m.currencyType = :fdCurrency
            AND m.amount >= :amount
            AND a.accountNumberHash = :accountNumber
            """)
    List<AuthMatrix> findMatricesHash(
            String cifId,
            Long productId,
            Long subProductId,
            Double amount,
            String fdCurrency,
            String accountNumber
    );

    default List<AuthMatrix> findMatrices(
            String cifId,
            Long productId,
            Long subProductId,
            Double amount,
            String fdCurrency,
            String accountNumber
    ) {
        return findMatricesHash(HashUtils.HAMCMD5Hash(cifId),
                productId,
                subProductId,
                amount,
                fdCurrency,
                HashUtils.HAMCMD5Hash(accountNumber));
    }

    @Query("""
            SELECT l.authMatrix FROM AuthLevel l
            WHERE l.authGroup.id = :groupId
            """)
    AuthMatrix findMatrixByGroupId(Long groupId);
}
