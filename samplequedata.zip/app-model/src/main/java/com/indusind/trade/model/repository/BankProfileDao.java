package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.bank.BankProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BankProfileDao extends JpaRepository<BankProfile, Long> {
}
