package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.bank.BankProfileTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BankProfileTempDao extends JpaRepository<BankProfileTemp, Long> {
}
