package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.utility.HashUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BankUserDao extends JpaRepository<BankUser, Long> {
    default Boolean existsByBankProfileAbbvNameAndLoginId(String bankAbbvName, String loginId) {
        return  existsByBankProfile_AbbvNameHashAndLoginId(HashUtils.HAMCMD5Hash(bankAbbvName), loginId);
    }

    Boolean existsByBankProfile_AbbvNameHashAndLoginId(String bankAbbvName, String loginId);

    Optional<BankUser> findByLoginId(String loginId);

    default Optional<BankUser> findByLoginIdAndBankProfileAbbvName(String loginId, String bankAbbvName){
        // return findByLoginIdAndBankProfile_AbbvNameHash(loginId, HashUtils.HAMCMD5Hash(bankAbbvName)); // throws NonUniqueResultException if duplicate loginId rows exist
        return findFirstByLoginIdAndBankProfile_AbbvNameHash(loginId, HashUtils.HAMCMD5Hash(bankAbbvName));
    }

    // Optional<BankUser> findByLoginIdAndBankProfile_AbbvNameHash(String loginId, String bankAbbvName); // replaced: caused "Query did not return a unique result: 2 results"
    Optional<BankUser> findFirstByLoginIdAndBankProfile_AbbvNameHash(String loginId, String bankAbbvName);


    Page<BankUser> findByBankProfileBankProfileId(Long bankProfileId, Pageable pageable);

    @org.springframework.data.jpa.repository.Modifying(clearAutomatically = true, flushAutomatically = true)
    @org.springframework.data.jpa.repository.Query(value = "UPDATE gtp_bank_user SET TERMS_PRIVACY_ACCEPTED = :accepted WHERE UPPER(LOGIN_ID) = UPPER(:loginId)", nativeQuery = true)
    int updatePrivacyPolicy(@Param("loginId") String loginId,
                            @Param("bankAbbvName") String bankAbbvName, @Param("accepted") Boolean accepted);

}
