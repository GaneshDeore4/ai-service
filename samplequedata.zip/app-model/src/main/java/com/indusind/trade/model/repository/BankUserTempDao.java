package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.bank.BankUserTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BankUserTempDao extends JpaRepository<BankUserTemp, Long> {

    Page<BankUserTemp> findByBankProfileBankProfileId(Long bankProfileId, Pageable pageable);
}
