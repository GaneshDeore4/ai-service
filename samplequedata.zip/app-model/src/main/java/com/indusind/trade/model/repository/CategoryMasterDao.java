package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.CategoryMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CategoryMasterDao extends JpaRepository<CategoryMaster, Long> {

    List<CategoryMaster> findAllByOrderByCategoryNameAsc();

    CategoryMaster findByCategoryNameIgnoreCase(String category);

    CategoryMaster findByCategoryName(String categoryName);
}
