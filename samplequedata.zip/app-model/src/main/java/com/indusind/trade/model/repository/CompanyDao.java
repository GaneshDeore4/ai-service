package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.utility.HashUtils;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyDao extends JpaRepository<Company, Long> {
    default Company findByCifId(String cifId){
        Company company = findByCifIdHash(HashUtils.HAMCMD5Hash(cifId));
        return company;
    }
    Company findByCifIdHash(String cifId);

//    Page<Company> findByCategoryMasterCategoryId(Pageable pageable, Long categoryId);


}
