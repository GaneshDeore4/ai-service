package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.CompanyTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyTempDao extends JpaRepository<CompanyTemp, Long> {
//    Page<CompanyTemp> findByCategoryMasterCategoryId(Pageable pageable, Long categoryId);
}
