package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.CustomerReferenceTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerReferenceTempDao extends JpaRepository<CustomerReferenceTemp, Long> {
}
