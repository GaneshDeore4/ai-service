package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.EventType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface EventTypeDao extends JpaRepository<EventType, Long> {
}
