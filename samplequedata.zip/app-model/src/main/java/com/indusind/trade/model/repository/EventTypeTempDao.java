package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.EventTypeTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EventTypeTempDao extends JpaRepository<EventTypeTemp, Long> {
}
