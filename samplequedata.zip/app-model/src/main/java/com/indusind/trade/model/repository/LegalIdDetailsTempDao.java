package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.LegalIdDetailsTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LegalIdDetailsTempDao extends JpaRepository<LegalIdDetailsTemp, Long> {
}
