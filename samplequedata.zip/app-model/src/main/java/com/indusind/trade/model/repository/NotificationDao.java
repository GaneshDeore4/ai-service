package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.Notification;
import com.indusind.trade.model.entities.company.NotificationTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface NotificationDao extends JpaRepository<Notification, Long> {

    @Query("""
            SELECT n from Notification n
            WHERE n.isActive = true
            AND n.validUpto >= :currentDate
            """)
    List<Notification> fetchAllNotificationClient(LocalDate currentDate);

}
