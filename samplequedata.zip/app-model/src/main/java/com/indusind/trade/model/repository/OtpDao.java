package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.Otp;
import com.indusind.trade.model.utility.HashUtils;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface OtpDao extends JpaRepository<Otp, Long> {

    default Optional<Otp> findTopByLoginIdAndOtpReferenceAndVerifiedAndBankAbbvNameOrderByCreatedAtDesc(String loginId, String otpReference, Boolean isVerified, String bankAbbvName){
        return findTopByLoginIdAndOtpReferenceAndVerifiedAndBankAbbvNameHashOrderByCreatedAtDesc(loginId, otpReference, isVerified, HashUtils.HAMCMD5Hash(bankAbbvName));
    }
    Optional<Otp> findTopByLoginIdAndOtpReferenceAndVerifiedAndBankAbbvNameHashOrderByCreatedAtDesc(String loginId, String otpReference, Boolean isVerified, String bankAbbvName);

    default Optional<Otp> findTopByLoginIdAndOtpReferenceAndVerifiedAndCompanyCifIdOrderByCreatedAtDesc(String loginId, String otpReference, Boolean isVerified, String cifId){
        return findTopByLoginIdAndOtpReferenceAndVerifiedAndCompanyCifIdHashOrderByCreatedAtDesc(loginId, otpReference, isVerified, HashUtils.HAMCMD5Hash(cifId));
    }

    Optional<Otp> findTopByLoginIdAndOtpReferenceAndVerifiedAndCompanyCifIdHashOrderByCreatedAtDesc(String loginId, String otpReference, Boolean isVerified, String cifId);
}