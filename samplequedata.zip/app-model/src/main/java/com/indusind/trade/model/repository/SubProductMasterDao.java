package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubProductMasterDao extends JpaRepository<SubProductMaster, Long> {
    List<SubProductMaster> findBySubProductIdIn(List<Long> subProductIds);

    List<SubProductMaster> findAllByOrderBySubProductNameAsc();

    Optional<SubProductMaster> findBySubProductNameAndProductMaster(String name, ProductMaster product);

    @Query("""
                SELECT COALESCE(MAX(sp.sequenceId), 0)
                FROM SubProductMaster sp where
                sp.productMaster.productId = :productId
           """)
    Long findMaxSequenceIdByProductId(Long productId);


}
