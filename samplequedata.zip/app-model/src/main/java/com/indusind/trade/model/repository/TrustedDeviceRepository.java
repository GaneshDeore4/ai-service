package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.TrustedDevice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TrustedDeviceRepository extends JpaRepository<TrustedDevice, Long> {

    Optional<TrustedDevice> findByLoginIdAndCifIdAbbvNameAndDeviceFingerprint(String loginId, String cifOrAbbvName, String fingerprint);

    List<TrustedDevice> findByLoginIdAndCifIdAbbvNameOrderByLastUsedAtDesc(String loginId, String cifOrAbbvName);

    List<TrustedDevice> findByStatus(String status);
}
