package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMappingTemp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserCompanyProductSubProdMappingTempDao extends JpaRepository<UserCompanyProductSubProdMappingTemp, Long> {

    List<UserCompanyProductSubProdMappingTemp> findByUserTempUserId(Long userId);

    void deleteByUserTempUserId(Long userId);
}
