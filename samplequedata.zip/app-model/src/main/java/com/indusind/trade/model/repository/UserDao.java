package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.utility.HashUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserDao extends JpaRepository<User, Long> {

    Page<User> findByCompanyCompanyId(Long companyId, Pageable pageable);
    Page<User> findByCompanyCompanyIdAndUserStatusNot(Long companyId,String status, Pageable pageable);

    default Boolean existsByCompanyCifIdAndLoginId(String cifId, String loginId) {
        return existsByCompany_CifIdHashAndLoginId(HashUtils.HAMCMD5Hash(cifId), loginId);
    }

    Boolean existsByCompany_CifIdHashAndLoginId(String cifIdHash, String loginId);


    @EntityGraph(attributePaths = {
            "mappingUser",
            "mappingUser.productMaster",
            "mappingUser.subProductMaster",
            "userType"
    })
    Optional<User> findWithMappingsByUserId(Long userId);

    Optional<User> findByLoginId(String loginId);

    Optional<User> findByLoginIdAndCompany_CifIdHash(String loginId, String cifId);

    default Optional<User> findByLoginIdAndCompanyCifId(String loginId, String cifId) {
        return findByLoginIdAndCompany_CifIdHash(loginId, HashUtils.HAMCMD5Hash(cifId));
    }

    @org.springframework.data.jpa.repository.Modifying(clearAutomatically = true, flushAutomatically = true)
    @org.springframework.data.jpa.repository.Query(value = "UPDATE GTP_USER SET TERMS_SECURITY_PRIVACY_POLICY_ACCEPTED = :accepted WHERE UPPER(LOGIN_ID) = UPPER(:loginId)", nativeQuery = true)
    int updatePrivacyPolicy(@org.springframework.data.repository.query.Param("loginId") String loginId,
                            @org.springframework.data.repository.query.Param("accepted") Boolean accepted);

    boolean existsByCompany_CifIdHash(String cifId);

    default boolean existsByCompanyCifId(String cifId){
        return existsByCompany_CifIdHash(HashUtils.HAMCMD5Hash(cifId));
    }

    boolean existsByLoginId(String loginId);

    default Boolean existsByCompanyCifIdAndLoginIdAndUserStatus(String cifId, String loginId,String userStatus) {
        return existsByCompany_CifIdHashAndLoginIdAndUserStatus(HashUtils.HAMCMD5Hash(cifId), loginId,userStatus);
    }

    Boolean existsByCompany_CifIdHashAndLoginIdAndUserStatus(String cifIdHash, String loginId,String userStatus);

}
