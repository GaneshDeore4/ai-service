package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.UserSession;
import com.indusind.trade.model.utility.HashUtils;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public interface UserSessionRepository extends JpaRepository<UserSession, String> {

    default List<UserSession> findByLoginIdAndAndCifIdAbbvNameOrderByLoginTimeDesc(String loginId, String cifOrfAbbvName) {
        return findByLoginIdAndAndCifIdAbbvNameHashOrderByLoginTimeDesc(loginId, HashUtils.HAMCMD5Hash(cifOrfAbbvName));
    }

    List<UserSession> findByLoginIdAndAndCifIdAbbvNameHashOrderByLoginTimeDesc(String loginId, String cifOrfAbbvName);

    default List<UserSession> findByLoginIdAndCifIdAbbvNameAndStatus(String loginId, String cifOrAbvvName, String status) {
        return findByLoginIdAndCifIdAbbvNameHashAndStatus(loginId, HashUtils.HAMCMD5Hash(cifOrAbvvName), status);
    }

    List<UserSession> findByLoginIdAndCifIdAbbvNameHashAndStatus(String loginId, String cifOrAbvvName, String status);

    /** Mark expired: all ACTIVE sessions whose JWT expiry has passed */
    @Modifying
    @Query("UPDATE UserSession s SET s.status = 'EXPIRED', s.logoutReason = 'TOKEN_EXPIRED' " +
            "WHERE s.status = 'ACTIVE' AND s.lastActiveTime < :cutoff")
    int markExpiredBefore(Instant cutoff);
}
