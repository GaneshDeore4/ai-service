package com.indusind.trade.model.repository;

import com.indusind.trade.model.entities.master.UserTypeTabActionMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserTypeTabActionMappingDao extends JpaRepository<UserTypeTabActionMapping, Long> {

    Long deleteByUserTypeUserTypeIdAndProductProductIdAndSubProductSubProductId(Long userTypeId, Long productId,
                                                                                Long subProductId);

    List<UserTypeTabActionMapping> findByUserTypeUserTypeIdAndProductProductIdAndSubProductSubProductIdAndTabTabIdIn(Long userTypeId, Long productId, Long subProductId, List<Long> tabId);

    List<UserTypeTabActionMapping> findByUserTypeUserTypeId(Long userTypeId);

    @Query("""
                SELECT m
                FROM UserTypeTabActionMapping m
                JOIN FETCH m.product
                LEFT JOIN FETCH m.subProduct
                JOIN FETCH m.tab
                JOIN FETCH m.action
                WHERE m.userType.id = :userTypeId
            """)
    List<UserTypeTabActionMapping> findAllByUserType(Long userTypeId);

}
