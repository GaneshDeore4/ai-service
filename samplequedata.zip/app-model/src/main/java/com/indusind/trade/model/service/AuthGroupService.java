package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.company.AuthGroup;

import java.util.List;

public interface AuthGroupService {

    AuthGroup getAuthGroupById(Long id);

    public AuthGroup getAuthGroup(Long id);

    List<AuthGroup> getAllAuthGroups();

}
