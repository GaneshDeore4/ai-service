package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.company.AuthLevel;

public interface AuthLevelTempService {

    AuthLevel saveAuthLevelTemp(AuthLevel authLevel);
}
