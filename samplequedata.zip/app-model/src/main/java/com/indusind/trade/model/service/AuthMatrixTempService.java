package com.indusind.trade.model.service;

import com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupedDto;
import com.indusind.trade.model.entities.company.AuthMatrixTemp;
import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AuthMatrixTempService {

    AuthMatrixTemp saveAuthMatrix(AuthMatrixTemp authMatrixTemp);

    List<AuthMatrixTemp> saveAllAuthMatrix(List<AuthMatrixTemp> authMatrixTemp);

    AuthMatrixTemp getAuthMatrixTempById(Long id, String category);

    AuthMatrixTemp getAuthMatrixTempById(Long id);

    Page<AuthMatrixTemp> getAllAuthMatrix(Pageable page);

    Page<AuthMatrixTemp> getAllAuthMatrix(Pageable page, String category, Long companyId);

    void deleteAuthMatrixById(Long authMatId);

    void flush();

    boolean existsAuthMatrixTemp(Long id);

    boolean existsByCompanyProductSubProductAmt(Company company, ProductMaster product, SubProductMaster subProduct, Long amount, String currencyType);

    boolean existsByCompanyProductSubProductAmtIsAllProductFlag(Company company, ProductMaster product, SubProductMaster subProduct, Long amount, boolean isAllProductFlag, String currencyType);

    AuthMatrixTemp findByCompanyProductSubProductAmtIsAllProductFlag(Long companyId, Long productId, Long subProductId, Long amount, boolean b, String currencyType);

    List<AuthMatrixTemp> getByCompanyAmountIsAllProductFlag(Long companyId, Long aLong, boolean isAllProductFlag, String currencyType);

    boolean existsByCompanyIdAmountIsAllFlag(Long companyId, Long amount, boolean isAllProdFlag, String currencyType);

    Page<AuthMatrixGroupedDto> getAllAuthMatrixAllMapping(Pageable pageable, String category, Long companyId);
}
