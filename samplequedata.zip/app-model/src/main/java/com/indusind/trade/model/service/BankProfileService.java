package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.bank.BankProfile;
import com.indusind.trade.model.entities.bank.BankProfileTemp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface BankProfileService {

    public BankProfileTemp saveBankProfileTemp(BankProfileTemp bankProfileTemp);
    public BankProfile saveBankProfile(BankProfile bankProfile);
    public BankProfileTemp getBankProfileTempById(Long bankProfileId);
    public BankProfile getBankProfileById(Long bankProfileId);
    Page<BankProfileTemp> getAllTempBanks(Pageable pageable);
    Page<BankProfile> getAllBanks(Pageable pageable);
    public Boolean existsBank(Long bankProfileId);
    public Boolean existsBankTemp(Long bankProfileId);

    public void flushBankProfile();

    public void flushBankProfileTemp();

}
