package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.company.GuideLineTemp;
import com.indusind.trade.model.entities.company.Guideline;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface GuidelineService {

    GuideLineTemp saveGuidelineTemp(GuideLineTemp guideLineTemp);
    Guideline saveGuideline(Guideline guideline);
    Page<GuideLineTemp> getAllTempGuidelines(Pageable pageable);
    Guideline getGuidelineById(Long guidelineId);

    GuideLineTemp getGuidelineTempById(Long guidelineId);

    List<Guideline> getAllGuidelineClient();

    public void flushGuideline();

    public void flushGuidelineTemp();

    public Boolean existsGuideline(Long guidelineId);

}
