package com.indusind.trade.model.service;


import com.indusind.trade.model.entities.master.SubProductMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface SubProductMasterService {
    SubProductMaster saveSubProduct(SubProductMaster subProductMaster);

    Page<SubProductMaster> getAllSubProducts(Pageable pageable);

    SubProductMaster getSubProductById(Long subProductId);

    List<SubProductMaster> getAllSubProducts();

    List<SubProductMaster> getSubProductMasterList(List<Long> subProductIds);

    Long findMaxSequenceIdByProductId(Long productId);

    boolean existsById(Long id);
}
