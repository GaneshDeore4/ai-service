package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.TabMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface TabMasterService {

    TabMaster addTabMaster(TabMaster tabMaster);
    Page<TabMaster> getAllTabMaster(Pageable pageable);
    TabMaster getTabById(Long tabId);

    TabMaster updateTabMaster(Long tabId, String rolename);
    void deleteTabMaster(Long tabId);

    List<TabMaster> getTabListByTabIds(List<Long> tabIds);

    boolean existById(Long tabId);

    List<TabMaster> getAllTabMaster();

    List<TabMaster> findByProdAndSubProd(Long productId, Long subProductId);

    List<TabMaster> getTabsByProdId(Long productId);
}
