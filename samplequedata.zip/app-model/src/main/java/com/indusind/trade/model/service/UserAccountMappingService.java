package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.company.AccountDetail;

import java.util.List;

public interface UserAccountMappingService {

    List<AccountDetail> getAccountDetailsByCifId(String cifId);

    AccountDetail getAccountById(String accountId);

    List<AccountDetail> getAccountsById(List<String> accountId);

    List<AccountDetail> findAccountsById(List<String> accountId);

}
