package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMapping;
import com.indusind.trade.model.entities.company.UserCompanyProductSubProdMappingTemp;

import java.util.List;
import java.util.Map;

public interface UserCompanyProductSubProdMappingService {

    void addMappingTemp(Long userId,  Map<Long, List<Long>> prodSubProdMap);
    //void addMapping();

    List<UserCompanyProductSubProdMappingTemp> getMappingTempById(Long userId);

    List<UserCompanyProductSubProdMapping> getMappingById(Long userId);
//    void addMappingTemp(UserTemp userTemp);

    void addMapping(List<UserCompanyProductSubProdMapping> userMapping);

    void deleteByUserTempUserId(Long userId);

    void flush();

}
