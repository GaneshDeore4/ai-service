package com.indusind.trade.model.service;

import com.indusind.trade.model.entities.master.UserType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface UserTypeService {

    UserType saveUserType(UserType userType);

    Page<UserType> getAllUserTypes(Pageable pageable);

    UserType getUserTypeById(Long userTypeId);

    UserType getUserTypeByType(String admin);

    List<UserType> getUserTypeByIdIn(List<Long> userTypeIds);

    List<UserType> getUserTypeByCategoryId(Long category);

    Page<UserType> getUserTypePageByCategory(Pageable pageable, Long categoryId);

    Boolean existsById(Long userTypeId);
}
