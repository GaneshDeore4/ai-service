package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.company.AuthLevel;
import com.indusind.trade.model.service.AuthLevelService;
import org.springframework.stereotype.Service;

@Service
public class AuthLevelServiceImpl implements AuthLevelService {
    @Override
    public AuthLevel saveAuthLevel(AuthLevel authLevel) {
        return null;
    }
}
