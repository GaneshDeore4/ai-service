package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.company.AuthLevel;
import com.indusind.trade.model.service.AuthLevelTempService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthLevelTempServiceImpl implements AuthLevelTempService {


    @Override
    public AuthLevel saveAuthLevelTemp(AuthLevel authLevel) {
        return null;
    }
}
