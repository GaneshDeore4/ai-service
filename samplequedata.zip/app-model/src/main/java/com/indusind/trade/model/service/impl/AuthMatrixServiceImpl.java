package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.dtos.response.dtos.AccountDetailsDto;
import com.indusind.trade.model.dtos.response.dtos.AuthMatrixGroupedDto;
import com.indusind.trade.model.entities.company.AuthMatrix;
import com.indusind.trade.model.entities.company.AuthMatrixTemp;
import com.indusind.trade.model.entities.master.EventTypeTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.AuthMatrixDao;
import com.indusind.trade.model.service.AuthMatrixService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AuthMatrixServiceImpl implements AuthMatrixService {

    private final AuthMatrixDao authMatrixDao;

    @Override
    public AuthMatrix saveAuthMatrix(AuthMatrix authMatrix) {
        return authMatrixDao.save(authMatrix);
    }

    @Override
    public AuthMatrix getAuthMatrixById(Long id, String category) {
        return authMatrixDao.findByIdAndCategory(id, category).orElseThrow(()->new GTPAppException("Auth Matrix with id: " + id + " does not exists.", null));
    }

    @Override
    public AuthMatrix getAuthMatrixById(Long id) {
        return authMatrixDao.findById(id).orElseThrow(()->new GTPAppException("Auth Matrix with id: " + id + " does not exists.", null));
    }

    @Override
    public Page<AuthMatrix> getAllAuthMatrix(Pageable page, String category,Long companyId) {
        if (companyId != null) {
            return authMatrixDao.findByIsAllProductFlagAndCategoryAndCompanyCompanyId(false, category, companyId, page);
        }
        return authMatrixDao.findByIsAllProductFlagAndCategory(false, category, page);
    }

    @Override
    public void deleteAuthMatrixById(Long authMatId) {
        authMatrixDao.deleteById(authMatId);
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void flush() {
        authMatrixDao.flush();
    }

    @Override
    public Boolean existsAuthMatrix(Long id) {
        return authMatrixDao.existsById(id);
    }

    @Override
    public Page<AuthMatrixGroupedDto> getAllAuthMatrixAllMapping(Pageable pageable, String category, Long companyId) {
        Page<AuthMatrixTemp> page = authMatrixDao.findPagedAuthMatrix(category, companyId, pageable);

        Map<String, List<AuthMatrixTemp>> grouped =
                page.getContent().stream()
                        .collect(Collectors.groupingBy(
                                a -> a.getCompany().getCompanyId() + "_" + a.getAmount()
                        ));

        List<AuthMatrixGroupedDto> result =
                grouped.values().stream()
                        .map(this::convertToGroupedDto)
                        .toList();

        return new PageImpl<>(result, pageable, page.getTotalElements());
    }

    private AuthMatrixGroupedDto convertToGroupedDto(List<AuthMatrixTemp> records) {

        AuthMatrixTemp first = records.get(0);

        AuthMatrixGroupedDto dto = new AuthMatrixGroupedDto();

        dto.setCompanyId(first.getCompany().getCompanyId());
        dto.setAmount(first.getAmount());
        dto.setCurrencyType(first.getCurrencyType());
        dto.setIsSequential(first.getIsSequential());
        dto.setIsVerifier(first.getIsVerifier());
        dto.setIsReleaser(first.getIsReleaser());
        dto.setIsAllProductFlag(first.getIsAllProductFlag());
        dto.setStatus(first.getStatus());

        dto.setIds(records.stream()
                .map(r -> r.getId().toString())
                .collect(Collectors.joining(",")));

//        dto.setEventType(records.stream()
//                .flatMap(r -> r.getEventTypes().stream())
//                .map(EventTypeTemp::getEventType)
//                .distinct()
//                .toList());

        dto.setAuthGroup(records.stream()
                .flatMap(r -> r.getAuthLevels().stream())
                .map(level -> Map.of(
                        level.getAuthGroup().getId() + "_" +level.getAuthGroup().getAuthGroup(),
                        level.getSeqNo()))
                .collect(Collectors.toSet()));

        dto.setAccounts(first.getAccounts().stream().map(
                AccountDetailsDto :: convertToDto
        ).toList());

        dto.setMakerName(first.getMakerName());
        dto.setCreatedAt(first.getCreatedAt());
        dto.setCheckerName(first.getCheckerName());
        dto.setApprovedAt(first.getApprovedAt());
        dto.setLastModifiedAt(first.getLastModifiedAt());
        dto.setLastModifiedBy(first.getLastModifiedBy());
        dto.setRejectedAt(first.getRejectedAt());
        dto.setRejectedBy(first.getRejectedBy());

        return dto;
    }
}
