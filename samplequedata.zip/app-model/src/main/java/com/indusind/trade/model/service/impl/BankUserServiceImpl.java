package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.entities.bank.BankUserTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.BankUserDao;
import com.indusind.trade.model.repository.BankUserTempDao;
import com.indusind.trade.model.service.BankUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BankUserServiceImpl implements BankUserService {

    private final BankUserDao bankUserDao;
    private final BankUserTempDao bankUserTempDao;


    @Override
    public BankUserTemp saveBankUserTemp(BankUserTemp bankUserTemp) {
        return bankUserTempDao.save(bankUserTemp);
    }

    @Override
    public BankUser saveBankUser(BankUser bankUser) {
        return bankUserDao.save(bankUser);
    }

    @Override
    public BankUserTemp getBankUserTempById(Long bankUserId) {
        return bankUserTempDao.findById(bankUserId).orElseThrow(() -> new GTPAppException("BankUser id " + bankUserId + " does not exists", null));
    }

    @Override
    public BankUser getBankUSerById(Long bankUserId) {
        return bankUserDao.findById(bankUserId).orElseThrow(() -> new GTPAppException("BankUser id " + bankUserId + " does not exists.", null));
    }

    @Override
    public Page<BankUserTemp> getAllTempBankUsers(Pageable pageable) {
        return bankUserTempDao.findAll(pageable);
    }

    @Override
    public Page<BankUser> getAllBankUsers(Pageable pageable) {
        return bankUserDao.findAll(pageable);
    }

    @Override
    public Boolean existsBankUser(Long bankUserId) {
        return bankUserDao.existsById(bankUserId);
    }

    @Override
    public Boolean existsBankUserTemp(Long bankUserId) {
        return bankUserTempDao.existsById(bankUserId);
    }

    @Override
    public Page<BankUserTemp> getTempBankUsersByBankId(Long bankId, Pageable pageable) {
        return bankUserTempDao.findByBankProfileBankProfileId(bankId, pageable);
    }

    @Override
    public Page<BankUser> getBankUsersByBankId(Long bankId, Pageable pageable) {
        return bankUserDao.findByBankProfileBankProfileId(bankId, pageable);
    }

    @Override
    public void flushBankUser() {
        bankUserDao.flush();
    }

    @Override
    public void flushBankUserTemp() {
        bankUserTempDao.flush();
    }

    @Override
    public void lockUnlockUser(String loginId, boolean lockFlag, String bankAbbvName) {
        BankUser user = getBankUserByLoginIdAndAbbvName(loginId, bankAbbvName).orElseThrow(()-> new GTPAppException("User not found", null));
        if (lockFlag) {
            user.setIsUserLocked(true);
            user.setLockedDate(LocalDateTime.now());
        } else {
            user.setIsUserLocked(false);
            user.setLoginFailedCount(0L);
            user.setOtpFailedCount(0L);
            user.setLockedDate(null);
        }
        saveBankUser(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void resetBankUserPasswordByUserId(Long userId, String password) {
        BankUser user = getBankUSerById(userId);
        user.setUserPassword(password);
        user.setChangePasswordDate(LocalDateTime.now());
        user.setIsFirstLoginFlag(false);
        saveBankUser(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void resetBankUserPasswordByLoginIdAndBankAbbvName(String loginId, String password, String bankAbbvName) {
        BankUser user = getBankUserByLoginIdAndAbbvName(loginId, bankAbbvName).orElseThrow(()-> new GTPAppException("User not found", null));
        user.setUserPassword(password);
        user.setChangePasswordDate(LocalDateTime.now());
        saveBankUser(user);
    }

    @Override
    public Optional<BankUser> getBankUserByLoginIdAndAbbvName(String loginId, String abbvName) {
        return bankUserDao.findByLoginIdAndBankProfileAbbvName(loginId, abbvName);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updatePrivacyPolicy(String loginId, boolean accepted, String bankAbbvName) {
        BankUser user = getBankUserByLoginIdAndAbbvName(loginId, bankAbbvName).orElseThrow(() -> new GTPAppException("User not found", null));
        user.setTermPrivacyAccepted(true);
        this.saveBankUser(user);
    }


}
