package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.company.GuideLineTemp;
import com.indusind.trade.model.entities.company.Guideline;
import com.indusind.trade.model.entities.company.NotificationTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.GuidelineDao;
import com.indusind.trade.model.repository.GuidelineTempDao;
import com.indusind.trade.model.service.GuidelineService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class GuidelineServiceImpl implements GuidelineService {

    private final GuidelineDao guidelineDao;
    private final GuidelineTempDao guidelineTempDao;

    @Override
    public GuideLineTemp saveGuidelineTemp(GuideLineTemp guideLineTemp) {
        return guidelineTempDao.save(guideLineTemp);
    }

    @Override
    public Guideline saveGuideline(Guideline guideline) {
        return guidelineDao.save(guideline);
    }

    @Override
    public Page<GuideLineTemp> getAllTempGuidelines(Pageable pageable) {
        return guidelineTempDao.findAll(pageable);
    }

    @Override
    public Guideline getGuidelineById(Long guidelineId) {
        return guidelineDao.findById(guidelineId).orElseThrow(() -> new GTPAppException("Guideline with id "+guidelineId+ " not found.", null));
    }

    @Override
    public GuideLineTemp getGuidelineTempById(Long guidelineId) {
        return guidelineTempDao.findById(guidelineId).orElseThrow(() -> new GTPAppException("Guideline with id "+guidelineId+ " not found.", null));
    }

    @Override
    public List<Guideline> getAllGuidelineClient() {
        return guidelineDao.fetchAllGuidelineClient(LocalDate.now());
    }

    @Override
    public void flushGuideline() {
        guidelineDao.flush();
    }

    @Override
    public void flushGuidelineTemp() {
        guidelineTempDao.flush();
    }

    @Override
    public Boolean existsGuideline(Long id) {
        return guidelineDao.existsById(id);
    }
}
