package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.company.Notification;
import com.indusind.trade.model.entities.company.NotificationTemp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.NotificationDao;
import com.indusind.trade.model.repository.NotificationTempDao;
import com.indusind.trade.model.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService {

    private final NotificationDao notificationDao;
    private final NotificationTempDao notificationTempDao;

    @Override
    public NotificationTemp saveNotificationTemp(NotificationTemp notificationTemp) {
        return notificationTempDao.save(notificationTemp);
    }

    @Override
    public Notification saveNotification(Notification notification) {
        return notificationDao.save(notification);
    }

    @Override
    public Notification getNotificationById(Long notificationId) {
        return notificationDao.findById(notificationId).orElseThrow(() -> new GTPAppException("Notification with id "+notificationId+" not found.", null));
    }

    @Override
    public void flushNotification() {
        notificationDao.flush();
    }

    @Override
    public void flushNotificationTemp() {
        notificationTempDao.flush();
    }

    @Override
    public Boolean existsNotification(Long notificationId) {
        return notificationDao.existsById(notificationId);
    }

    @Override
    public Boolean existsNotificationTemp(Long notificationId) {
        return notificationTempDao.existsById(notificationId);
    }

    @Override
    public NotificationTemp getNotificationTempById(Long notificationId) {
        return notificationTempDao.findById(notificationId).orElseThrow(() -> new GTPAppException("Notification with id "+notificationId+" not found.", null));
    }

    @Override
    public List<Notification> getAllNotificationClients() {
        return notificationDao.fetchAllNotificationClient(LocalDate.now());
    }

    @Override
    public Page<NotificationTemp> getAllTempNotifications(Pageable pageable) {
        return notificationTempDao.findAll(pageable);
    }
}
