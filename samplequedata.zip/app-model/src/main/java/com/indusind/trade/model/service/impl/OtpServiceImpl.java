package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.master.Otp;
import com.indusind.trade.model.repository.OtpDao;
import com.indusind.trade.model.service.OtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OtpServiceImpl implements OtpService {

    private final OtpDao otpDao;


    @Override
    public Optional<Otp> findActiveBankOtpForUpdate(String loginId, String otpReference, String bankAbbvName, Boolean isVerified) {
        return otpDao.findTopByLoginIdAndOtpReferenceAndVerifiedAndBankAbbvNameOrderByCreatedAtDesc(loginId, otpReference, isVerified, bankAbbvName);
    }

    @Override
    public Optional<Otp> findActiveClientOtpForUpdate(String loginId, String otpReference, String cifId, Boolean isVerified) {
        return otpDao.findTopByLoginIdAndOtpReferenceAndVerifiedAndCompanyCifIdOrderByCreatedAtDesc(loginId, otpReference, isVerified, cifId);
    }


    @Override
    public Otp saveOtp(Otp otp){
        return otpDao.save(otp);
    }
}
