package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.ProductMasterDao;
import com.indusind.trade.model.service.ProductMasterService;
import jakarta.transaction.Transactional;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
public class ProductMasterServiceImpl implements ProductMasterService {

    ProductMasterDao productMasterDao;


    @Override
    @Transactional(rollbackOn = Exception.class)
    public ProductMaster saveProduct(ProductMaster productMaster) {
        return productMasterDao.save(productMaster);
    }

    @Override
    public Page<ProductMaster> getAllProducts(Pageable pageable) {
        return productMasterDao.findAll(pageable);
    }

    @Override
    public Page<ProductMaster> getAllProductsByCategoryId(Pageable pageable, Long categoryId) {
        return productMasterDao.findByCategoryCategoryId(categoryId, pageable);
    }

    @Override
    public List<ProductMaster> getAllProductsByCategoryId(Long categoryId) {
        return productMasterDao.findByCategoryCategoryId(categoryId);
    }

    @Override
    public List<ProductMaster> getAllProducts() {
        return productMasterDao.findAllByOrderByProductNameAsc();
    }

    @Override
    public Long findMaxSequenceId() {
        return productMasterDao.findMaxSequenceId();
    }

    @Override
    public Boolean existProductMaster(Long productId) {
        return productMasterDao.existsById(productId);
    }

    @Override
    public List<ProductMaster> getProductsByCategoryId(Long categoryId) {
        return productMasterDao.findByCategoryCategoryId(categoryId);
    }


    @Override
    public ProductMaster getProductById(Long productId) {
        return productMasterDao.findById(productId).orElseThrow(()-> new GTPAppException("Product with id: " + productId + " does not exists.", null));
    }

    @Override
    public List<SubProductMaster> getSubProductsByProductId(Long productId) {
        ProductMaster productMaster = productMasterDao.findById(productId).orElseThrow(()-> new GTPAppException("Product with id: "+ productId + " does not exists", null));
        return productMaster.getSubProductMasterList();
    }

    @Override
    public List<ProductMaster> getProductsByIds(List<Long> productIds) {
        return productMasterDao.findByProductIdIn(productIds);
    }

}
