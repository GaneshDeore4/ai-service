package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.master.TabMaster;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.TabMasterDao;
import com.indusind.trade.model.service.TabMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TabMasterServiceImpl implements TabMasterService {

    private final TabMasterDao tabMasterDao;
    @Override
    public TabMaster addTabMaster(TabMaster tabMaster) {
        return tabMasterDao.save(tabMaster);
    }

    @Override
    public Page<TabMaster> getAllTabMaster(Pageable pageable) {
        return tabMasterDao.findAll(pageable);
    }

    @Override
    public TabMaster getTabById(Long tabId) {
        return tabMasterDao.findById(tabId).orElseThrow(() -> new GTPAppException("Tab with id: " + tabId + " does not exists", null));
    }

    @Override
    public TabMaster updateTabMaster(Long tabId, String tabName) {
        TabMaster tabMasterEntity = tabMasterDao.findById(tabId).orElseThrow(() -> new GTPAppException("Tab with id: "+ tabId + " does not exists.", null));
        tabMasterEntity.setTabName(tabName);
        return tabMasterDao.save(tabMasterEntity);
    }


    @Override
    public void deleteTabMaster(Long tabId) {
        tabMasterDao.deleteById(tabId);
    }

    @Override
    public List<TabMaster> getTabListByTabIds(List<Long> tabIds) {
        return tabMasterDao.findByTabIdIn(tabIds);
    }

    @Override
    public boolean existById(Long tabId) {
        return tabMasterDao.existsById(tabId);
    }

    @Override
    public List<TabMaster> getAllTabMaster() {
        return tabMasterDao.findAll();
    }

    @Override
    public List<TabMaster> findByProdAndSubProd(Long productId, Long subProductId) {
        return tabMasterDao.findByProductProductIdAndSubProductSubProductId(productId, subProductId);
    }

    @Override
    public List<TabMaster> getTabsByProdId(Long productId) {
        return tabMasterDao.findByProductProductIdAndSubProductSubProductIdIsNull(productId);
    }

}
