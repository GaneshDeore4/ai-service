package com.indusind.trade.model.service.impl;

import com.indusind.trade.model.entities.company.AccountDetail;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.repository.AccountRepository;
import com.indusind.trade.model.service.UserAccountMappingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserAccountMappingServiceImpl implements UserAccountMappingService {

    private final AccountRepository accountDao;

    @Override
    public List<AccountDetail> getAccountDetailsByCifId(String cifId) {

        return accountDao.findByCifId(cifId);
    }

    @Override
    public AccountDetail getAccountById(String accountId) {
        return accountDao.findById(accountId).orElseThrow(() ->
                new GTPAppException("Account with id " + accountId +
                        " does not exists", null));
    }

    @Override
    public List<AccountDetail> getAccountsById(List<String> accountId) {

//        return accountDao.findAllById(accountId);
        return accountDao.findAllByAccountNumberIn(accountId);
    }

    @Override
    public List<AccountDetail> findAccountsById(List<String> accountId) {
        return accountDao.findAllById(accountId);
    }
}
