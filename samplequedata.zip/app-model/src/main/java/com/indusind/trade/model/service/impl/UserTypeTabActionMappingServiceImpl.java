package com.indusind.trade.model.service.impl;


import com.indusind.trade.model.entities.master.UserTypeTabActionMapping;
import com.indusind.trade.model.repository.UserTypeTabActionMappingDao;
import com.indusind.trade.model.service.UserTypeTabActionMappingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserTypeTabActionMappingServiceImpl implements UserTypeTabActionMappingService {

    private final UserTypeTabActionMappingDao userTypeTabActionMappingDao;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<UserTypeTabActionMapping> saveMappingList(List<UserTypeTabActionMapping> userTypeTabActionMappingList) {
        return userTypeTabActionMappingDao.saveAll(userTypeTabActionMappingList);
    }

    @Override
    public List<UserTypeTabActionMapping> findByUserTypeProductSubProductTabIds(Long userTypeId, Long productId, Long subProductId, List<Long> tabIds) {
        return userTypeTabActionMappingDao.findByUserTypeUserTypeIdAndProductProductIdAndSubProductSubProductIdAndTabTabIdIn(userTypeId,productId,subProductId,tabIds);
    }

    @Override
    public List<UserTypeTabActionMapping> findByUserTypeId(Long userTypeId) {
        return userTypeTabActionMappingDao.findByUserTypeUserTypeId(userTypeId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public  Long deleteUserTabActionMappingByUserTypeProdSubProd(Long userTypeId, Long productId, Long subProductId){
        return userTypeTabActionMappingDao.deleteByUserTypeUserTypeIdAndProductProductIdAndSubProductSubProductId(userTypeId,productId,subProductId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void flush() {
        userTypeTabActionMappingDao.flush();
    }

}
