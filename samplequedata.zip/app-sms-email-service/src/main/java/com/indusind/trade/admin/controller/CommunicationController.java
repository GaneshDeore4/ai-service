package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.EmailFacade;
import com.indusind.trade.admin.facade.OtpFacade;
import com.indusind.trade.admin.facade.SmsFacade;
import com.indusind.trade.admin.facade.impl.OtpFacadeImpl;
import com.indusind.trade.model.dtos.requestdtos.OtpDto;
//import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingRequestDto;
//import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingRequestGetDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/communication")
@RequiredArgsConstructor
public class CommunicationController {

    private final OtpFacade otpFacade;

    @PostMapping("/sendUserOtp")
    public ResponseEntity<ApplicationResponse> sendUserOtp(@RequestBody OtpDto otpDto) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(otpFacade.sendUserOtp(otpDto));
    }

    @PostMapping("/sendUserOtpBeforeLogin")
    public ResponseEntity<ApplicationResponse> sendUserOtpBeforeLogin(@RequestBody OtpDto otpDto) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(otpFacade.sendUserOtp(otpDto));
    }

    @PostMapping("/resendUserOtp")
    public ResponseEntity<ApplicationResponse> resendUserOtp(@RequestBody OtpDto otpDto) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(otpFacade.resendUserOtp(otpDto));
    }

    @PostMapping("/confirmUserOtp")
    public ResponseEntity<ApplicationResponse> confirmUserOtp(@RequestBody OtpDto otpDto) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(otpFacade.confirmUserOtp(otpDto));
    }

    @PostMapping("/confirmUserOtpBeforeLogin")
    public ResponseEntity<ApplicationResponse> confirmUserOtpBeforeLogin(@RequestBody OtpDto otpDto) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(otpFacade.confirmUserOtp(otpDto));
    }

    @PostMapping("/sendBankUserOtp")
    public ResponseEntity<ApplicationResponse> sendBankUserOtp(@RequestBody OtpDto otpDto) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(otpFacade.sendBankUserOtp(otpDto));
    }

    @PostMapping("/resendBankUserOtp")
    public ResponseEntity<ApplicationResponse> resendBankUserOtp(@RequestBody OtpDto otpDto) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(otpFacade.resendBankUserOtp(otpDto));
    }

    @PostMapping("/confirmBankUserOtp")
    public ResponseEntity<ApplicationResponse> confirmBankUserOtp(@RequestBody OtpDto otpDto) throws Exception {
        return ResponseEntity.status(HttpStatus.OK).body(otpFacade.confirmBankUserOtp(otpDto));
    }


}
