package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.OtpDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.transaction.annotation.Transactional;

public interface OtpFacade {

    @Transactional
    ApplicationResponse sendUserOtp(OtpDto otpDto) throws Exception;

    @Transactional
    ApplicationResponse resendUserOtp(OtpDto otpDto) throws Exception;

    @Transactional
    ApplicationResponse confirmUserOtp(OtpDto otpDto) throws Exception;

    @Transactional
    ApplicationResponse sendBankUserOtp(OtpDto otpDto) throws Exception;

    @Transactional
    ApplicationResponse resendBankUserOtp(OtpDto otpDto) throws Exception;

    @Transactional
    ApplicationResponse confirmBankUserOtp(OtpDto otpDto) throws Exception;
}
