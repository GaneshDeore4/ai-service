package com.indusind.trade.admin.facade;

import java.util.HashMap;

public interface SmsFacade {

    HashMap<String, String> sendSms(long contactNo, String message, boolean isOtp);
}
