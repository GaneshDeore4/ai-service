package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.exception.OtpException;
import com.indusind.trade.admin.facade.OtpFacade;
import com.indusind.trade.admin.facade.SmsFacade;
import com.indusind.trade.admin.utility.OtpUtil;
import com.indusind.trade.model.constants.AppConstants;
import com.indusind.trade.model.dtos.requestdtos.OtpDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.entities.master.Otp;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.service.BankUserService;
import com.indusind.trade.model.service.OtpService;
import com.indusind.trade.model.service.UserService;
import com.indusind.trade.model.utility.CryptoUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class OtpFacadeImpl implements OtpFacade {

    private final OtpService otpService;
    private final SmsFacade smsFacade;
    private final UserService userService;
    private final BankUserService bankUserService;

    @Value("${sms.user.max.fail.count}")
    private int maxUserOtpFailCount;

    @Value("${sms.user.expiry.in.minutes}")
    private int userOtpExpiry;

    @Value("${sms.bank.user.max.fail.count}")
    private int maxBankUserOtpFailCount;

    @Value("${sms.bank.user.expiry.in.minutes}")
    private int bankUserOtpExpiry;


    @Transactional
    @Override
    public ApplicationResponse sendUserOtp(OtpDto otpInDto) throws Exception {

        if (!userService.existsUserByCifId(otpInDto.getCompanyCifId())) {
            throw new GTPAppException("Invalid Customer ID", null);
        }
        if (!userService.existsUserByLoginId(otpInDto.getLoginId())) {
            throw new GTPAppException("Invalid User ID", null);
        }

        User user = userService.getUserByLoginIdAndCifId(otpInDto.getLoginId(), otpInDto.getCompanyCifId()).orElseThrow(() -> new GTPAppException("User Not found", null));
        if (user.getIsUserLocked()) {
            throw new GTPAppException("User is locked.", null);
        }

        if (user.getOtpFailedCount() >= maxUserOtpFailCount) {
            throw new OtpException("OTP Max attempts exceeded");
        }

        if (Objects.isNull(user.getContactNo())) {
            throw new GTPAppException("No contact number found for sending otp", null);
        }
        String mobileNumber = user.getContactNo();
        String otp = OtpUtil.generateOtp();

//        HashMap<String, String> sms =
//                smsFacade.sendSms(Long.parseLong(mobileNumber), otp, true);

//        if (!"success".equalsIgnoreCase(sms.get("status"))) {
//            throw new OtpException("SMS sending failed");
//        }
        Otp entity = Otp.builder()
                .mobileNumber(mobileNumber)
                .companyCifId(otpInDto.getCompanyCifId())
                .loginId(otpInDto.getLoginId())
                .encryptedOtp(CryptoUtils.encrypt(otp))
                //.encryptedOtp(CryptoUtils.encrypt(sms.get("otp")))
                .verified(false)
                .createdAt(LocalDateTime.now())
                .expiryTime(LocalDateTime.now().plusMinutes(userOtpExpiry))
                .build();

        Otp savedOtp = otpService.saveOtp(entity);
        String otpReference = savedOtp.getId() + UUID.randomUUID().toString();
        savedOtp.setOtpReference(otpReference);
        otpService.saveOtp(savedOtp);

        OtpDto otpDto = OtpDto.builder().enteredOtp(otp).loginId(otpInDto.getLoginId()).companyCifId(otpInDto.getCompanyCifId()).otpReference(otpReference).build();

        return new ApplicationResponse("SUCCESS", otpDto, "OTP sent successfully");
    }

    @Transactional
    @Override
    public ApplicationResponse resendUserOtp(OtpDto otpDto) throws Exception {

        Otp entity = otpService.findActiveClientOtpForUpdate(otpDto.getLoginId(), otpDto.getOtpReference(), otpDto.getCompanyCifId(), false)
                .orElseThrow(() -> new OtpException(AppConstants.OTP_NOT_FOUND));

        String otp = OtpUtil.generateOtp();

//        HashMap<String, String> sms =
//                smsFacade.sendSms(Long.parseLong(otp), otp, true);

//        if (!"success".equalsIgnoreCase(sms.get("status"))) {
//            throw new OtpException("SMS sending failed");
//        }
        String otpReference = entity.getId() + UUID.randomUUID().toString();
        entity.setOtpReference(otpReference);
        entity.setEncryptedOtp(CryptoUtils.encrypt(otp));
        //entity.setEncryptedOtp(CryptoUtils.encrypt(sms.get("otp")));

        entity.setExpiryTime(LocalDateTime.now().plusMinutes(userOtpExpiry));

        otpService.saveOtp(entity);
        otpDto = OtpDto.builder().enteredOtp(otp).loginId(entity.getLoginId()).bankAbbvName(entity.getCompanyCifId()).otpReference(entity.getOtpReference()).build();

        return new ApplicationResponse("SUCCESS", otpDto, "OTP resent successfully");
    }

    @Transactional
    @Override
    public ApplicationResponse confirmUserOtp(OtpDto otpDto) throws Exception {


        Otp entity = otpService.findActiveClientOtpForUpdate(otpDto.getLoginId(), otpDto.getOtpReference(),otpDto.getCompanyCifId() , false)
                .orElseThrow(() -> new OtpException("OTP not found"));

        if (LocalDateTime.now().isAfter(entity.getExpiryTime())) {
            throw new OtpException("OTP expired");
        }
        User user = userService.getUserByLoginIdAndCifId(otpDto.getLoginId(), otpDto.getCompanyCifId()).orElseThrow(() -> new GTPAppException("User Not found", null));

        if (user.getIsUserLocked()) {
            throw new GTPAppException("User is locked.", null);
        }

        if (user.getOtpFailedCount() >= maxUserOtpFailCount) {
            user.setIsUserLocked(true);
            userService.saveUser(user);
            throw new OtpException("OTP Max attempts exceeded. User is locked now.");
        }

        if (!otpDto.getEnteredOtp().equals(CryptoUtils.decrypt(entity.getEncryptedOtp()))) {
            user.setOtpFailedCount(user.getOtpFailedCount() + 1);
            userService.saveUser(user);
            throw new OtpException("Incorrect OTP, OTP verification failed");
        }

        entity.setVerified(true);
        otpService.saveOtp(entity);

        return new ApplicationResponse("SUCCESS", true, "OTP verified successfully");
    }

    @Transactional
    @Override
    public ApplicationResponse sendBankUserOtp(OtpDto otpInDto) throws Exception {

        BankUser user = bankUserService.getBankUserByLoginIdAndAbbvName(otpInDto.getLoginId(), otpInDto.getBankAbbvName()).orElseThrow(() -> new GTPAppException("Bank User Not found", null));
        if (user.getIsUserLocked()) {
            throw new GTPAppException("Bank User is locked.", null);
        }

        if (user.getOtpFailedCount() >= maxUserOtpFailCount) {
            throw new OtpException("OTP Max attempts exceeded");
        }

        if (Objects.isNull(user.getContactNo())) {
            throw new GTPAppException("No contact number found for sending otp", null);
        }

        String mobileNumber = user.getContactNo();
        String otp = OtpUtil.generateOtp();
//        HashMap<String, String> sms =
//                smsFacade.sendSms(Long.parseLong(mobileNumber), otp, true);

//        if (!"success".equalsIgnoreCase(sms.get("status"))) {
//            throw new OtpException("SMS sending failed");
//        }
        Otp entity = Otp.builder()
                .mobileNumber(mobileNumber)
                .encryptedOtp(CryptoUtils.encrypt(otp))
                //.encryptedOtp(CryptoUtils.encrypt(sms.get("otp")))
                .loginId(otpInDto.getLoginId())
                .bankAbbvName(otpInDto.getBankAbbvName())
                .verified(false)
                .createdAt(LocalDateTime.now())
                .expiryTime(LocalDateTime.now().plusMinutes(bankUserOtpExpiry))
                .build();

        Otp savedOtp = otpService.saveOtp(entity);
        String otpReference = savedOtp.getId() + UUID.randomUUID().toString();
        savedOtp.setOtpReference(otpReference);
        otpService.saveOtp(savedOtp);

        OtpDto otpDto = OtpDto.builder().enteredOtp(otp).loginId(otpInDto.getLoginId()).bankAbbvName(otpInDto.getBankAbbvName()).otpReference(otpReference).build();

        return new ApplicationResponse("SUCCESS", otpDto, "OTP sent successfully");
    }

    @Transactional
    @Override
    public ApplicationResponse resendBankUserOtp(OtpDto otpDto) throws Exception {

        Otp entity = otpService.findActiveBankOtpForUpdate(otpDto.getLoginId(), otpDto.getOtpReference(), otpDto.getBankAbbvName(), false)
                .orElseThrow(() -> new OtpException(AppConstants.OTP_NOT_FOUND));

        String otp = OtpUtil.generateOtp();

//        HashMap<String, String> sms =
//                smsFacade.sendSms(Long.parseLong(otp), otp, true);

//        if (!"success".equalsIgnoreCase(sms.get("status"))) {
//            throw new OtpException("SMS sending failed");
//        }
        String otpReference = entity.getId() + UUID.randomUUID().toString();
        entity.setOtpReference(otpReference);
        entity.setEncryptedOtp(CryptoUtils.encrypt(otp));
        //entity.setEncryptedOtp(CryptoUtils.encrypt(sms.get("otp")));
        entity.setExpiryTime(LocalDateTime.now().plusMinutes(bankUserOtpExpiry));

        otpService.saveOtp(entity);

        otpDto = OtpDto.builder().enteredOtp(otp).loginId(entity.getLoginId()).bankAbbvName(entity.getBankAbbvName()).otpReference(entity.getOtpReference()).build();


        return new ApplicationResponse("SUCCESS", otpDto, "OTP resent successfully");
    }

    @Transactional
    @Override
    public ApplicationResponse confirmBankUserOtp(OtpDto otpDto) throws Exception {

        Otp entity = otpService.findActiveBankOtpForUpdate(otpDto.getLoginId(), otpDto.getOtpReference(), otpDto.getBankAbbvName(), false)
                .orElseThrow(() -> new OtpException(AppConstants.OTP_NOT_FOUND));

        if (LocalDateTime.now().isAfter(entity.getExpiryTime())) {
            throw new OtpException("OTP expired");
        }
        BankUser user = bankUserService.getBankUserByLoginIdAndAbbvName(otpDto.getLoginId(), otpDto.getBankAbbvName()).orElseThrow(() -> new GTPAppException("Bank User Not found", null));

        if (user.getIsUserLocked()) {
            throw new GTPAppException("Bank User is locked.", null);
        }

        if (user.getOtpFailedCount() >= maxUserOtpFailCount) {
            user.setIsUserLocked(true);
            throw new OtpException("OTP Max attempts exceeded. Bank User is locked now.");
        }

        if (!otpDto.getEnteredOtp().equals(CryptoUtils.decrypt(entity.getEncryptedOtp()))) {
            user.setOtpFailedCount(user.getOtpFailedCount() + 1);
            bankUserService.saveBankUser(user);
            throw new OtpException("Incorrect OTP, OTP verification failed");
        }

        entity.setVerified(true);
        otpService.saveOtp(entity);

        return new ApplicationResponse("SUCCESS", true, "OTP verified successfully");
    }
}

