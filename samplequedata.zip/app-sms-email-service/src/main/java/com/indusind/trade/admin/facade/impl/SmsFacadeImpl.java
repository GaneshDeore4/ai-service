package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.SmsFacade;
import com.indusind.trade.admin.utility.OtpUtil;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SmsFacadeImpl implements SmsFacade {

    private final WebClient webClient;

    private static final Logger logger = LoggerFactory.getLogger(SmsFacadeImpl.class);

//    @Override
//    public HashMap<String, String> sendSms(long contactNo) {
//        Logger logger = LoggerFactory.getLogger(SmsFacadeImpl.class);
//        HashMap<String, String> smsResponse = new HashMap<>();
//
//        String otp = OtpUtil.generateOtp();
//        String smsUrl = "https://enterprise.smsgupshup.com/GatewayAPI/rest?method=SendMessage&send_to="+contactNo+"&msg="+otp+"%20is%20your%20OTP.%20Please%20do%20not%20share%20with%20anyone.-Indusind%20Bank&msg_type=TEXT&userid=2000237193&auth_scheme=plain&password=CcbhZT5P&v=1.1&format=text";
//
//        try{
//            String res = webClient.get()
//                    .uri(smsUrl)
//                    .retrieve()
//                    .onStatus(
//                            status -> !status.is2xxSuccessful(), //replace responseCode check
//                            clientResponse -> {
//                                logger.info("request failed");
//                                return Mono.error(new RuntimeException("Request failed"));
//                            }
//                    )
//                    .bodyToMono(String.class) //replace BufferedReader
//                    .block(); // keeps  existing sync behavior
//
//            smsResponse.put("status", res.split("\\|")[0].trim());
//            smsResponse.put("phone", res.split("\\|")[1].trim());
//            smsResponse.put("msgId", res.split("\\|")[2].trim());
//            smsResponse.put("otp", otp);
//            logger.info("sendSMSReq: Response- " + res);
//        } catch (Exception e) {
//            logger.info("Exception occurred: {}", e.getMessage());
//            // your existing fallback
//            smsResponse.put("status", "success");
//            smsResponse.put("phone", String.valueOf(contactNo));
//            smsResponse.put("msgId", UUID.randomUUID().toString());
//            smsResponse.put("otp", otp);
//        }
//        logger.info("smsResponse: " + smsResponse);
//        logger.info("sendSMSReq: end");
//        return smsResponse;
//    }

    @Override
    public HashMap<String, String> sendSms(long contactNo, String message, boolean isOtp) {

        Logger logger = LoggerFactory.getLogger(SmsFacadeImpl.class);
        HashMap<String, String> smsResponse = new HashMap<>();

        String otp = null;

        try {
            if (isOtp) {
                otp = OtpUtil.generateOtp();
                message = otp + " is your OTP. Please do not share with anyone.-Trade Portal";
            }

            String encodedMsg = URLEncoder.encode(message, StandardCharsets.UTF_8);

            String smsUrl = "https://enterprise.smsgupshup.com/GatewayAPI/rest?method=SendMessage"
                    + "&send_to=" + contactNo
                    + "&msg=" + encodedMsg
                    + "&msg_type=TEXT"
                    + "&userid=2000237193"
                    + "&auth_scheme=plain"
                    + "&password=CcbhZT5P"
                    + "&v=1.1&format=text";

            String res = webClient.get()
                    .uri(smsUrl)
                    .retrieve()

                    //HTTP error handling
                    .onStatus(
                            status -> !status.is2xxSuccessful(),
                            clientResponse -> clientResponse.bodyToMono(String.class)
                                    .flatMap(error -> {
                                        logger.error("SMS API error: {}", error);
                                        return reactor.core.publisher.Mono.error(
                                                new RuntimeException("SMS API failed"));
                                    })
                    )

                    .bodyToMono(String.class)

                    //Retry (same as email style)
                    .retryWhen(
                            reactor.util.retry.Retry.backoff(3, Duration.ofSeconds(2))
                                    .doBeforeRetry(retry ->
                                            logger.warn("Retrying SMS API... attempt={}",
                                                    retry.totalRetries() + 1))
                    )

                    //Timeout
                    .timeout(Duration.ofSeconds(30))

                    .block();

            String[] split = res.split("\\|");

            smsResponse.put("status", split[0].trim());
            smsResponse.put("phone", split[1].trim());
            smsResponse.put("msgId", split[2].trim());

            //Only include OTP if generated
            if (isOtp) {
                smsResponse.put("otp", otp);
            }

            logger.info("sendSMSReq: Response- {}", res);

        } catch (Exception e) {

            logger.error("Exception occurred while sending SMS", e);

            smsResponse.put("status", "FAIURE");
            smsResponse.put("phone", String.valueOf(contactNo));
            smsResponse.put("msgId", UUID.randomUUID().toString());

            if (isOtp) {
                smsResponse.put("otp", otp);
            }
        }

        logger.info("smsResponse: {}", smsResponse);
        logger.info("sendSMSReq: end");

        return smsResponse;
    }


}



