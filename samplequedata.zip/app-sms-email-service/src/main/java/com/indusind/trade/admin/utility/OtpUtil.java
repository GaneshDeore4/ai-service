package com.indusind.trade.admin.utility;

import com.indusind.trade.model.utility.CryptoUtils;

import java.security.SecureRandom;

public class OtpUtil {

    private static final SecureRandom random = new SecureRandom();


    public static String generateOtp(){
        SecureRandom random = new SecureRandom();
        int otp = random.nextInt(90000)+10000;
        return String.valueOf(otp);
    }

    public static String encryptOtp(String otp) {
        try {

            return CryptoUtils.enc(otp);

        } catch (Exception e) {
            throw new RuntimeException("OTP hashing failed");
        }
    }
}
