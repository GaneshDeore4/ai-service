export const CLIENTMC = "Client (M=C)";
export const CLIENTMAKER = "Client Maker";
export const CLIENTCHECKER = "Client Checker";
export const CLIENTVERIFIER = "Client Verifier";
export const CLIENTRELEASER = "Client Releaser";
export const CLIENTVIEW = "Client View";