export interface Account {
  accountNumber: string;
  currency: string;
  schemeDescription: string;
  schemeType: string;
  effectiveAvailBalance: number;
}
export interface Notification {
  title: string,
  desc: string
}
export interface Guidelines {
  title: string,
  desc: string
}

export interface ApiResponse<T> {
  status: string;
  payload: T;
  message: string;
}

export interface Deposit {
  id: number;
  fdId: number;
  depositNumber: string;
  interestRate: number;
  currency: string;
  principalAmount: number;
  amount: number;
  maturityAmount: number;
  maturityDate: string;
  tenure: string;
  tenureYears: string;
  tenureMonths: string;
  tenureDays: string;
  maturityInstructions: string;
  maturityInstruction: string;
  accountNumber: string;
  status: string;
  fdStatus: string;
  currentLevel: number;
  reason: string;
  version: number;
}

export interface DepositEnquiryDetail {
  cifId: string;
  accountNumber: string;
  accountOpenDate: string;
  acctClsFlg: string;
  acctClsDate: string;
  accountStatus: string | null;
  ifscCode: string;
  pdFlg: string;
  c5CodeDescription: string;
  schemeCode: string;
  schemeType: string;
  schemeDesc: string;
  modeOfOperation: string;
  frezCode: string;
  fraudFlag: string;
  currency: string;
  lienAmount: string;
  lienFlag: string;
  nomFlg: string;
  nomName: string;
  nomReltnCode: string;
  applRateOfInterest: number;
  startDate: string;
  maturityAmount: string;
  maturityDate: string;
  maturityInsc: string;
  depositAmount: string;
  depositPeriodDays: string;
  depositPeriodMonths: string;
  repaymentAccount: string;
  repaymentSchemeType: string;
  renewalOption: string;
  flowFreqMths: string;
  flowFreqDays: string;
  autoRenewalFlg: string;
  flowCode: string;
  constitutionCode: string;
  nomineePrintFlg: string;
  aas: Aas[];
  fdtype: string;
  c5Code: string;
  PAN: string;
  SOL_ID: string;
  FDSBALinked: string;
  TDTerm: string;
}
export interface Aas {
  cifId: string;
  modeofOperation: string;
}

export interface Transaction {
  transactionDate: string;
  referenceNumber: string;
  transactionType: 'CREDIT' | 'DEBIT';
  transactionAmount: number;
  runningBalance: number;
  narration: string;
}

export interface Roadmap {
  currentLevel: number;
  paths: RoadmapPath[];
}
export interface RoadmapPath {
  authMatrixId: number;
  selected: boolean;
  sequential: boolean;
  nodes: RoadmapNode[];
}
export interface RoadmapNode {
  level: number;
  groupId: number;
  groupName: string;
  state: string;
  active: boolean;
  current: boolean;
}