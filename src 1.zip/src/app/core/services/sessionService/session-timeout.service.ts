import { Injectable, NgZone, inject, PLATFORM_ID, OnDestroy, signal, Inject } from '@angular/core';
import { isPlatformBrowser, DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';
import { SessionService } from '../sessionService/session.service';
import { fromEvent, merge, Subscription, Subject } from 'rxjs';
import { throttleTime, takeUntil } from 'rxjs/operators';
import { AuthService } from '../auth.service';
import * as Constants from '../../constants/Constants';

@Injectable({
  providedIn: 'root'
})
export class SessionTimeoutService implements OnDestroy {
  private mainTimeoutId: any = null;
  private warningTimeoutId: any = null;
  private countdownInterval: any = null;
  private eventSubscription?: Subscription;
  private destroy$ = new Subject<void>();

  // UI State Signals
  sessionStatus = signal<'active' | 'warning' | 'expired'>('active');
  countdown = signal<number>(120);

  // Configuration (Aligned with session-service: 5m idle, 2m grace)
  private readonly SESSION_TIMEOUT = Constants.SESSION_TIMEOUT;
  private readonly WARNING_DURATION = Constants.WARNING_DURATION;

  constructor(
    private router: Router,
    private ngZone: NgZone,
    @Inject(PLATFORM_ID) private platformId: Object,
    @Inject(DOCUMENT) private document: any,
    private sessionService: SessionService,
    private authService: AuthService
  ) {
    console.log('SessionTimeoutService initialized');
    if (isPlatformBrowser(this.platformId)) {
      this.initListener();
    }
  }

  resetTimer() {
    if (!isPlatformBrowser(this.platformId)) return;

    // Safety check for token
    const token = this.sessionService.getToken();
    if (!token) {
      this.clearAllTimers();
      return;
    }

    console.log('Activity detected: Session timer reset');
    this.clearAllTimers();
    this.sessionStatus.set('active');

    // Start Warning Timer
    this.warningTimeoutId = setTimeout(() => {
      this.ngZone.run(() => this.showSessionWarning());
    }, this.SESSION_TIMEOUT - this.WARNING_DURATION);
  }

  private initListener() {
    if (!isPlatformBrowser(this.platformId) || !this.document) return;

    this.ngZone.runOutsideAngular(() => {
      try {
        const events = ['click', 'keydown', 'touchstart', 'scroll'];
        const eventStreams = events.map(ev => fromEvent(this.document, ev));

        this.eventSubscription = merge(...eventStreams)
          .pipe(
            throttleTime(2000),
            takeUntil(this.destroy$)
          )
          .subscribe(() => {
            this.ngZone.run(() => {
              if (this.sessionStatus() === 'active') {
                this.resetTimer();
              }
            });
          });
      } catch (err) {
        console.error('Error initializing activity listeners:', err);
      }
    });
  }

  showSessionWarning() {
    if (this.sessionStatus() === 'expired') return;

    this.sessionStatus.set('warning');
    this.countdown.set(this.WARNING_DURATION / 1000);

    this.countdownInterval = setInterval(() => {
      this.countdown.update(val => val - 1);
      if (this.countdown() <= 0) {
        this.expireSession();
      }
    }, 1000);
  }

  expireSession() {
    this.clearAllTimers();
    this.sessionStatus.set('expired');

    console.log('Session expired, triggering force logout...');

    const performFinalLogout = () => {
      this.authService.logout();
      this.sessionStatus.set('active');
    };

    // Call force logout API internally
    try {
      const storedUser = sessionStorage.getItem('currentUser');
      if (storedUser) {
        const user = JSON.parse(storedUser);
        if (user && user.loginId) {
          this.authService.forceLogout({ loginId: user.loginId }).subscribe({
            next: () => {
              console.log('Backend session forcefully expired');
              performFinalLogout();
            },
            error: (err) => {
              console.error('Force logout API failed', err);
              performFinalLogout(); // Still logout even if API fails
            }
          });
          return; // Exit here, navigation will happen in callback
        }
      }
    } catch (e) {
      console.error('Error during session expiry cleanup', e);
    }

    // Fallback: If no user or error, logout immediately
    performFinalLogout();
  }

  extendSession() {
    this.resetTimer();
  }

  redirectToLogin() {
    this.clearAllTimers();
    this.sessionStatus.set('active');
    this.router.navigate(['/login']);
  }

  private clearAllTimers() {
    if (this.mainTimeoutId) clearTimeout(this.mainTimeoutId);
    if (this.warningTimeoutId) clearTimeout(this.warningTimeoutId);
    if (this.countdownInterval) clearInterval(this.countdownInterval);
    this.mainTimeoutId = null;
    this.warningTimeoutId = null;
    this.countdownInterval = null;
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.clearAllTimers();
  }
}
