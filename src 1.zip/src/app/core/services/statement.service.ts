import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiEndpoints } from '../constants/api-endpoints';

@Injectable({
  providedIn: 'root',
})
export class StatementService {
  constructor(private http: HttpClient) { }

  fetchMiniStatement(
    accountNumber: string,
    requestUUID: string,
    channelID: string,
    fromDate?: string,
    toDate?: string,
    limit?: number
  ): Observable<any> {
    const url = ApiEndpoints.statements.mini();
    return this.http.post(url, {
      accountNo: accountNumber,
      requestUUID: requestUUID,
      channelID: channelID,
      fromDate: fromDate,
      toDate: toDate,
      limit: limit
    });
  }

  fetchFullStatement(
    accountNumber: string,
    requestUUID: string,
    channelID: string,
    fromDate: string,
    toDate: string,
    limit: number,
    refNumber?: string,
    tranType?: string,
    continueToken?: string
  ): Observable<any> {
    const url = ApiEndpoints.statements.full(refNumber, tranType, continueToken);
    return this.http.post(url, {
      requestUUID: requestUUID,
      channelID: channelID,
      accountNo: accountNumber,
      fromDate: fromDate,
      toDate: toDate,
      limit: limit
    });
  }

  downloadPdf(statementData: any): Observable<Blob> {
    const url = ApiEndpoints.statements.downloadPdf();
    return this.http.post(url, statementData, { responseType: 'blob' });
  }
}
