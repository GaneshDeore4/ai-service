/* gtp-company-object-tnx.dto.ts
 * Angular DTO mirroring backend GTPCompanyObjectTnxDto.
 * - All fields default to null so empty UI fields are sent explicitly as null.
 * - jsonToObject(): API JSON -> class instance (ensures undefined -> null).
 * - objectToJson(): class instance -> plain JSON (ensures undefined -> null).
 */

export type LocalDateTimeString = string | null; // Expect "dd-MM-yyyy hh:mm:ss a" or null

export class GTPCompanyObjectTnxDto {
  companyId: number | null = null;
  tnxId: string | null = null;
  name: string | null = null;

  decimalValue: number | null = null;
  scope: string | null = null;
  stringValue: string | null = null;
  textValue: string | null = null;

  /** String date-time per backend format or null */
  timeValue: LocalDateTimeString = null;

  type: string | null = null;

  constructor(init?: Partial<GTPCompanyObjectTnxDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof GTPCompanyObjectTnxDto)[];
    for (const k of keys) {
      if (this[k] === undefined) this[k] = null;
    }
  }

  /** Build DTO from incoming JSON (ensures missing fields are set to null). */
  static jsonToObject(json: any): GTPCompanyObjectTnxDto {
    const dto = new GTPCompanyObjectTnxDto();

    dto.companyId = valueOrNull<number>(json?.companyId);
    dto.tnxId = valueOrNull<string>(json?.tnxId);
    dto.name = valueOrNull<string>(json?.name);

    dto.decimalValue = valueOrNull<number>(json?.decimalValue);
    dto.scope = valueOrNull<string>(json?.scope);
    dto.stringValue = valueOrNull<string>(json?.stringValue);
    dto.textValue = valueOrNull<string>(json?.textValue);

    dto.timeValue = valueOrNull<string>(json?.timeValue);

    dto.type = valueOrNull<string>(json?.type);

    dto.normalizeNulls();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: GTPCompanyObjectTnxDto): Record<string, any> {
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);

    return {
      companyId: n(dto.companyId),
      tnxId: n(dto.tnxId),
      name: n(dto.name),

      decimalValue: n(dto.decimalValue),
      scope: n(dto.scope),
      stringValue: n(dto.stringValue),
      textValue: n(dto.textValue),

      timeValue: n(dto.timeValue),

      type: n(dto.type),
    };
  }
}

/** Helper: normalize possibly-undefined values to null */
function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}
