
export class LegalInfoDto {
  id?:number | null = null;
  legalIdType: string | null = null;
  legalIdNo: string | null = null;
  legalIdIssuingAuthority: string | null = null;

  constructor(init?: Partial<LegalInfoDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof LegalInfoDto)[];
    for (const k of keys) {
      if (this[k] === undefined) this[k] = null;
    }
  }

  /** Build DTO from incoming JSON (ensures missing fields are set to null). */
  static jsonToObject(json: any): LegalInfoDto {
    const dto = new LegalInfoDto();

    dto.id = valueOrNull<number>(json?.id);
    dto.legalIdType = valueOrNull<string>(json?.legalIdType);
    dto.legalIdNo = valueOrNull<string>(json?.legalIdNo);
    dto.legalIdIssuingAuthority = valueOrNull<string>(json?.legalIdIssuingAuthority);

    dto.normalizeNulls();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: LegalInfoDto): Record<string, any> {
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);

    return {
      id: n(dto.id),
      legalIdType: n(dto.legalIdType),
      legalIdNo: n(dto.legalIdNo),
      countryCode: n(dto.legalIdIssuingAuthority),
    };
  }
}

/** Helper: normalize possibly-undefined values to null */
function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}
