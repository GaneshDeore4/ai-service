export class GTPRoleDto {
  // Core
  roleId: number | null = null;
  tnxId: number | null = null;
  roleName: string | null = null;
  roleType: string | null = null;
  roleDest: string | null = null;
  ownerId: number | null = null;

  // Transaction meta
  tnxTypeCode: string | null = null;
  tnxStatCode: string | null = null;

  // Maker/Checker
  makerId: number | null = null;
  checkerId: number | null = null;
  makerDttm: string | null = null;   // ISO 8601 string (e.g., "2026-02-05T06:42:22.938Z")
  checkerDttm: string | null = null; // ISO 8601 string

  // Additional
  returnComments: string | null = null;
  permissionIds: number[] | null = null; // array of numbers
  ops: string | null = null;
  roleDescription: string | null = null;

  constructor(init?: Partial<GTPRoleDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
    this.normalizeCollections();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof GTPRoleDto)[];
    for (const k of keys) {
      if (this[k] === undefined) this[k] = null as any;
    }
  }

  /** Normalizes collection fields: empty/undefined -> null, coerces item types. */
  private normalizeCollections(): void {
    // permissionIds should be number[] | null
    if (!Array.isArray(this.permissionIds) || this.permissionIds.length === 0) {
      this.permissionIds = null;
    } else {
      this.permissionIds = this.permissionIds
        .map((v) => (typeof v === 'number' ? v : Number(v)))
        .filter((v) => Number.isFinite(v));
      if (this.permissionIds.length === 0) this.permissionIds = null;
    }
  }

  /** Build DTO from incoming JSON (ensures missing fields are set to null). */
  static jsonToObject(json: any): GTPRoleDto {
    const dto = new GTPRoleDto();

    // Core
    dto.roleId = valueOrNull<number>(json?.roleId);
    dto.tnxId = valueOrNull<number>(json?.tnxId);
    dto.roleName = valueOrNull<string>(json?.roleName);
    dto.roleType = valueOrNull<string>(json?.roleType);
    dto.roleDest = valueOrNull<string>(json?.roleDest);
    dto.ownerId = valueOrNull<number>(json?.ownerId);

    // Transaction meta
    dto.tnxTypeCode = valueOrNull<string>(json?.tnxTypeCode);
    dto.tnxStatCode = valueOrNull<string>(json?.tnxStatCode);

    // Maker/Checker
    dto.makerId = valueOrNull<number>(json?.makerId);
    dto.checkerId = valueOrNull<number>(json?.checkerId);
    dto.makerDttm = valueOrNull<string>(json?.makerDttm);
    dto.checkerDttm = valueOrNull<string>(json?.checkerDttm);

    // Additional
    dto.returnComments = valueOrNull<string>(json?.returnComments);
    dto.permissionIds = valueOrNullArrayNumber(json?.permissionIds);
    dto.ops = valueOrNull<string>(json?.ops);
    dto.roleDescription = valueOrNull<string>(json?.roleDescription);

    dto.normalizeNulls();
    dto.normalizeCollections();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: GTPRoleDto): Record<string, any> {
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);

    return {
      // Core
      roleId: n(dto.roleId),
      tnxId: n(dto.tnxId),
      roleName: n(dto.roleName),
      roleType: n(dto.roleType),
      roleDest: n(dto.roleDest),
      ownerId: n(dto.ownerId),

      // Transaction meta
      tnxTypeCode: n(dto.tnxTypeCode),
      tnxStatCode: n(dto.tnxStatCode),

      // Maker/Checker
      makerId: n(dto.makerId),
      checkerId: n(dto.checkerId),
      makerDttm: n(dto.makerDttm),     // keep as string (ISO)
      checkerDttm: n(dto.checkerDttm), // keep as string (ISO)

      // Additional
      returnComments: n(dto.returnComments),
      permissionIds: dto.permissionIds ? [...dto.permissionIds] : null, // ensure null if empty
      ops: n(dto.ops),
      roleDescription: n(dto.roleDescription),
    };
  }
}

/** Helper: normalize possibly-undefined values to null */
function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}

/** Helper: normalize arrays of numbers; returns null for undefined/non-array/empty */
function valueOrNullArrayNumber(v: any): number[] | null {
  if (!Array.isArray(v) || v.length === 0) return null;
  const out = v
    .map((x) => (typeof x === 'number' ? x : Number(x)))
    .filter((x) => Number.isFinite(x));
  return out.length ? out : null;
}