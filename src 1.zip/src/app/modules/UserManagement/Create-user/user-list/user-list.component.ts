// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';
// @Component({
//   selector: 'app-user-list',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './user-list.component.html',
//   styleUrl: './user-list.component.css',
// })
// export class UserListComponent {
//   cifId = '';
//   users = [
//     {
//       cif: '38383',
//       name: 'Vaibhav Tame',
//       mobile: '+91 9283748502',
//       email: 'vaibhav@gmail.com',
//       role: 'Checker',
//       accounts: true,
//       deposits: true,
//       deals: true,
//       payments: true,
//     },
//     {
//       cif: '12312',
//       name: 'Ahmed Ali',
//       mobile: '+91 8172635490',
//       email: 'ahmed@gmail.com',
//       role: 'Maker',
//       accounts: true,
//       deposits: true,
//       deals: true,
//       payments: true,
//     },
//   ];
//   matrix = [
//     {
//       from: 'USD 0',
//       to: 'USD 1,00,000.00',
//       rule: 'A + B',
//       sequence: 'Yes',
//     },
//     {
//       from: 'USD 1,00,000.00',
//       to: 'USD 10,00,000.00',
//       rule: 'B + B',
//       sequence: 'No',
//     },
//   ];
//   search() {
//     console.log('Searching CIF:', this.cifId);
//   }
// }

import { CommonModule } from '@angular/common';
import {
  Component,
  ViewChild,
  TemplateRef,
  AfterViewInit,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TableComponent } from '../../../../shared/components/table/table.component';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [CommonModule, TableComponent, FormsModule],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css',
})

export class UserListComponent implements AfterViewInit {
  @ViewChild('actionTemplate') actionTemplate!: TemplateRef<any>;
  @ViewChild('ruleTemplate') ruleTemplate!: TemplateRef<any>;
  userColumns: any[] = [];
  matrixColumns: any[] = [];
  ngAfterViewInit() {
    setTimeout(() => {
      // ✅ USERS TABLE
      this.userColumns = [
        { field: 'cif', header: 'CIF ID' },
        { field: 'name', header: 'User Name' },
        { field: 'mobile', header: 'Mobile Number' },
        { field: 'email', header: 'Email ID' },
        { field: 'role', header: 'Role' },
        { field: 'accounts', header: 'Accounts' },
        { field: 'deposits', header: 'Deposits' },
        { field: 'deals', header: 'Deal Booking' },
        { field: 'payments', header: 'Payments' },
        {
          field: 'action',
          header: 'Action',
          template: this.actionTemplate,
        },
      ];
      // ✅ MATRIX TABLE
      this.matrixColumns = [
        { field: 'from', header: 'From' },
        { field: 'to', header: 'Till' },
        {
          field: 'rule',
          header: 'Rules',
          template: this.ruleTemplate,
        },
        { field: 'sequence', header: 'Limit Sequence' },
      ];
    });
  }
  users = [
    {
      cif: '38383',
      name: 'Vaibhav Tame',
      mobile: '+91 9283748502',
      email: 'vaibhav@gmail.com',
      role: 'Checker',
      accounts: '✔',
      deposits: '✔',
      deals: '✔',
      payments: '✔',
    },
    {
      cif: '12312',
      name: 'Ahmed Ali',
      mobile: '+91 8172635490',
      email: 'ahmed@gmail.com',
      role: 'Maker',
      accounts: '✔',
      deposits: '✔',
      deals: '✔',
      payments: '✔',
    },
  ];
  matrix = [
    {
      from: 'USD 0',
      to: 'USD 1,00,000.00',
      rule: 'A + B',
      sequence: 'Yes',
    },
    {
      from: 'USD 1,00,000.00',
      to: 'USD 10,00,000.00',
      rule: 'B + B',
      sequence: 'No',
    },
  ];
}
