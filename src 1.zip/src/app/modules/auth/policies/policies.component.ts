import { ApiService } from './../../../core/services/api.service';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ApiEndpoints } from '../../../core/constants/api-endpoints';

@Component({
  selector: 'app-policies',
  templateUrl: './policies.component.html',
  styleUrls: ['./policies.component.css', '../auth-layout.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class PoliciesComponent implements OnInit {
  accepted: boolean = false;
  activeTab: string = 'terms';
  viewedTabs = new Set<string>();
  allTabsViewed: boolean = false;
  currentUser: any;
  showFirstTimePassPopup = false;
  userId: number | null = null;
  loginId = '';
  cif = '';


  constructor(private router: Router, private authService: AuthService, private apiService: ApiService) { }

  ngOnInit() {
    this.viewedTabs.add(this.activeTab);
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      this.userId = user?.userId ? Number(user.userId) : null;
      this.loginId = user?.loginId ?? '';
      this.cif = user?.cif ?? '';
    });
  }

  setActiveTab(tab: string) {
    this.activeTab = tab;
    this.viewedTabs.add(tab);
    if (this.viewedTabs.size >= 3) {
      this.allTabsViewed = true;
    }
  }

  onAccept() {
    const payload = {
      loginId: this.currentUser.loginId,
      cifId: this.currentUser.cif,
      accepted: true
    }
    if (this.accepted && this.allTabsViewed && this.currentUser) {
      const payload = {
        cifId: this.currentUser.cif,
        loginId: this.currentUser.loginId,
        accepted: true
      }
      this.authService.updatePrivacyPolicy(payload).subscribe({
        next: () => {
          this.showFirstTimePassPopup = true;
          // first reset password then move to dashboard
        },
        error: (err) => {
          console.error('Error updating privacy policy', err);
          this.router.navigate(['/login']);
        }
      });
    }
  }

  // RESET PASSWORD FLOW
  password = '';
  confirmPassword = '';
  passwordErrorMsg = '';
  passwordError = false;
  showResetPassword = false;
  showConfirmResetPasssword = false;
  toggleResetPassword() {
    this.showResetPassword = !this.showResetPassword;
  }
  toggleConfirmResetPassword() {
    this.showConfirmResetPasssword = !this.showConfirmResetPasssword;
  }


  validatePasswords(): boolean {
    this.passwordError = false;
    this.passwordErrorMsg = '';

    const password = (this.password || '').trim();
    const confirmPassword = (this.confirmPassword || '').trim();

    /* a. Length: 8–20 */
    if (password.length < 8 || password.length > 20) {
      this.passwordErrorMsg = 'Password must be between 8 and 20 characters';
      this.passwordError = true;
      return false;
    }

    /* b. Composition */
    const compositionRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#%*])[A-Za-z\d!@#%*]+$/;

    if (!compositionRegex.test(password)) {
      this.passwordErrorMsg = 'Password must include uppercase, lowercase, number, and special character (! @ # % *)';
      this.passwordError = true;
      return false;
    }

    /* d. No character repeated 3+ times */
    if (/(.)\1{2,}/.test(password)) {
      this.passwordErrorMsg = 'No character should repeat more than twice consecutively';
      this.passwordError = true;
      return false;
    }

    /* c. Block sequential patterns (abcd, 1234) */
    const sequences = [
      'abcdefghijklmnopqrstuvwxyz',
      'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
      '0123456789'
    ];

    for (const seq of sequences) {
      for (let i = 0; i <= seq.length - 4; i++) {
        const pattern = seq.substring(i, i + 4);
        if (password.includes(pattern)) {
          this.passwordErrorMsg = 'Sequential patterns like abcd or 1234 are not allowed';
          this.passwordError = true;
          return false;
        }
      }
    }

    if (password !== confirmPassword) {
      this.passwordErrorMsg = 'Passwords do not match';
      this.passwordError = true;
      return false;
    }
    return true;

  }
  resetPassword() {
    if (!this.validatePasswords())
      return;
    const data = {
      userId: this.userId,
      newPassword: this.password,
      afterLogin: true,
      loginId: this.loginId,
      cif: this.cif,
    }

    this.apiService.sendData(ApiEndpoints.auth.resetpassword, data).subscribe({
      next: (res: any) => {
        if (res.status == "SUCCESS") {
          this.forceLogout();
          sessionStorage.setItem('isFirstTimeLoginFlag', 'false');
          this.showFirstTimePassPopup = false; //close the popup
          this.popupMessage = 'Your password has been set successfully.'
          this.showPopup = true;
          this.firstPassChangeSuccess = true;
        } else {
          this.popupMessage = res.description;
          this.showPopup = true;
          this.firstPassChangeSuccess = false;
          console.error('Password reset failed:', res.description);
        }
      },
      error: (err: any) => {
        this.popupMessage = err.error.message;
        this.showPopup = true;
        this.firstPassChangeSuccess = false;
        console.error('Error during password reset:', err);
      },
      complete: () => {
      }
    });
  }

  forceLogout() {
    const forceLogoutPayload = {
      cifOrAbbvName: this.cif,
      loginId: this.loginId,
    };
    this.authService.forceLogout(forceLogoutPayload).subscribe({
      next: () => {
      },
      error: (err) => {
      },
    });
  }

  // POPUP USAGE
  showPopup = false;
  popupMessage = '';
  firstPassChangeSuccess = false;
  closePopup() {
    this.showPopup = false;
    if (this.firstPassChangeSuccess)
      this.router.navigate(['/login']);
  }

}
