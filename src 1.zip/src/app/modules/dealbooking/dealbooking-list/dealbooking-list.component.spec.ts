import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DealbookingComponent } from './dealbooking-list.component';

describe('DealbookingComponent', () => {
  let component: DealbookingComponent;
  let fixture: ComponentFixture<DealbookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DealbookingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DealbookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
