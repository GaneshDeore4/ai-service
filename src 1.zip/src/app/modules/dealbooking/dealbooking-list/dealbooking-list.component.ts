import { CommonModule } from '@angular/common';
import {
  Component,
  ViewChild,
  TemplateRef,
  AfterViewInit,
} from '@angular/core';
import { RouterModule } from '@angular/router';
import { TableComponent } from '../../../shared/components/table/table.component';

@Component({
  selector: 'app-dealbooking',
  imports: [TableComponent, CommonModule, RouterModule],
  templateUrl: './dealbooking-list.component.html',
  styleUrl: './dealbooking-list.component.css',
})
export class DealbookingComponent implements AfterViewInit {
  @ViewChild('statusTemplate') statusTemplate!: TemplateRef<any>;
  columns: any[] = [];

  ngAfterViewInit() {
    setTimeout(() => {
      this.columns = [
        { field: 'dealId', header: 'Deal ID' },
        { field: 'dateTime', header: 'Deal Date & Time' },
        { field: 'side', header: 'Side' },
        { field: 'currency', header: 'Currency' },
        { field: 'amount', header: 'Amount' },
        { field: 'pair', header: 'Currency Pair' },
        { field: 'rate', header: 'Rate' },
        { field: 'settlement', header: 'Settlement Date' },
        {
          field: 'status',
          header: 'Status',
          template: this.statusTemplate,
        },
      ];
    });
  }

  deals = [
    {
      dealId: 'Fx-82910',
      dateTime: '15/01/2026 12:32:45',
      side: 'Sell',
      currency: 'USD',
      amount: 200,
      pair: 'USD/INR',
      rate: 90.15,
      settlement: '23/02/2026',
      status: 'Active',
    },
    {
      dealId: 'Fx-82913',
      dateTime: '15/01/2026 12:32:45',
      side: 'Purchase',
      currency: 'USD',
      amount: 300,
      pair: 'USD/EUR',
      rate: 0.82,
      settlement: '01/02/2026',
      status: 'Active',
    },
  ];
}
