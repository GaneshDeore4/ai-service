import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FxdealComponent } from './fxdeal.component';

describe('FxdealComponent', () => {
  let component: FxdealComponent;
  let fixture: ComponentFixture<FxdealComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FxdealComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FxdealComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
