import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
@Component({
  selector: 'app-add-beneficiary',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './addbeneficiary.component.html',
  styleUrl: './addbeneficiary.component.css',
})
export class AddbeneficiaryComponent {
  selectedBankType: 'WITHIN' | 'OTHER' = 'WITHIN';
  showPreview = false;
  showSuccessPopup = false;
  // ✅ MAIN JSON DATA
  formData: any = {
    accountDetails: {},
    beneficiaryDetails: {},
  };

  constructor(private router: Router) {}

  selectBankType(type: 'WITHIN' | 'OTHER') {
    this.selectedBankType = type;
  }
  reset() {
    this.formData = {
      accountDetails: {},
      beneficiaryDetails: {},
    };
  }
  saveDraft() {
    this.showPreview = true;
    console.log('Draft:', this.formData);
  }
  submit() {
    this.showSuccessPopup = true;
    console.log('FINAL JSON:', this.formData);
  }
  proceed() {
    this.showSuccessPopup = false;
    this.router.navigate(['/remittance/beneficiarylist']);
  }
}
