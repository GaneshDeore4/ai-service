import { CommonModule } from '@angular/common';
import {
  Component,
  ViewChild,
  TemplateRef,
  AfterViewInit,
} from '@angular/core';
import { Router } from '@angular/router';
import { TableComponent } from '../../../../shared/components/table/table.component';

@Component({
  selector: 'app-beneficiarylist',
  imports: [CommonModule, TableComponent],
  templateUrl: './beneficiarylist.component.html',
  styleUrl: './beneficiarylist.component.css',
})
export class BeneficiarylistComponent {
  @ViewChild('actionTemplate') actionTemplate!: TemplateRef<any>;
  columns: any[] = [];
  constructor(private router: Router) {}
  ngAfterViewInit() {
    setTimeout(() => {
      this.columns = [
        { field: 'code', header: 'Bene Code' },
        { field: 'name', header: 'Beneficiary Name' },
        { field: 'type', header: 'Type' },
        { field: 'account', header: 'Account/IBAN No.' },
        { field: 'bank', header: 'Bank Name' },
        { field: 'country', header: 'Country' },
        { field: 'currency', header: 'Currency' },
        {
          field: 'action',
          header: 'Action',
          template: this.actionTemplate,
        },
      ];
    });
  }
  beneficiaries = [
    {
      code: 'AZ098',
      name: 'Global Solutions Ltd',
      type: 'Other Bank',
      account: '071605003363829',
      bank: 'DBS Bank',
      country: 'United States',
      currency: 'USD',
    },
    {
      code: 'SX976',
      name: 'Nova Enterprises Co',
      type: 'Within Bank',
      account: '071605003363829',
      bank: 'GIFT City Bank',
      country: 'United States',
      currency: 'USD',
    },
    {
      code: 'DC223',
      name: 'Zenith Dynamic Corp',
      type: 'Other Bank',
      account: '009292027484489',
      bank: 'HSBC Bank',
      country: 'United States',
      currency: 'USD',
    },
    {
      code: 'SX976',
      name: 'Apex Innovations Group',
      type: 'Other Bank',
      account: '939393930300303',
      bank: 'HSBC Bank',
      country: 'Singapore',
      currency: 'SGD',
    },
    {
      code: 'RY753',
      name: 'United Systems LLC',
      type: 'Within Bank',
      account: '071605003363829',
      bank: 'GIFT City Bank',
      country: 'India',
      currency: 'INR',
    },
  ];
  openadd() {
    this.router.navigate(['/remittance/beneficiarylist/add']);
  }
}
