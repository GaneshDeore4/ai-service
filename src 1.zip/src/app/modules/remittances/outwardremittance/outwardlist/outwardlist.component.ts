import { CommonModule } from '@angular/common';
import {
  Component,
  ViewChild,
  TemplateRef,
  AfterViewInit,
} from '@angular/core';
import { Router } from '@angular/router';
import { TableComponent } from '../../../../shared/components/table/table.component';

@Component({
  selector: 'app-outwardlist',
  imports: [CommonModule, TableComponent],
  templateUrl: './outwardlist.component.html',
  styleUrl: './outwardlist.component.css',
})
export class OutwardlistComponent {
  @ViewChild('statusTemplate') statusTemplate!: TemplateRef<any>;
  @ViewChild('actionTemplate') actionTemplate!: TemplateRef<any>;
  columns: any[] = [];
  ngAfterViewInit() {
    setTimeout(() => {
      this.columns = [
        { field: 'accountNo', header: 'Debit Account No.' },
        { field: 'accountName', header: 'Debit A/C Name' },
        { field: 'currency', header: 'Currency' },
        { field: 'amount', header: 'Amount' },
        { field: 'paymentType', header: 'Payment Type' },
        {
          field: 'paymentStatus',
          header: 'Payment Status',
          template: this.statusTemplate,
        },
        { field: 'fxApplied', header: 'FX Applied' },
        {
          field: 'action',
          header: 'Action',
          template: this.actionTemplate,
        },
      ];
    });
  }
  remittances = [
    {
      accountNo: '071605003363829',
      accountName: 'GSL GIFT City A/C',
      currency: 'USD',
      amount: '9,234.00',
      paymentType: 'IFT',
      paymentStatus: 'Completed',
      fxApplied: 'YES',
    },
    {
      accountNo: '071605003363829',
      accountName: 'NEC GIFT City A/C',
      currency: 'USD',
      amount: '12,589.00',
      paymentType: 'Outward Remittance',
      paymentStatus: 'Pending',
      fxApplied: 'NO',
    },
    {
      accountNo: '009292027484489',
      accountName: 'ZDC GIFT City A/C',
      currency: 'USD',
      amount: '6,721.00',
      paymentType: 'IFT',
      paymentStatus: 'Completed',
      fxApplied: 'YES',
    },
    {
      accountNo: '939393930300303',
      accountName: 'AIG GIFT City A/C',
      currency: 'SGD',
      amount: '14,999.00',
      paymentType: 'Outward Remittance',
      paymentStatus: 'Completed',
      fxApplied: 'YES',
    },
    {
      accountNo: '071605003363829',
      accountName: 'USL GIFT City A/C',
      currency: 'INR',
      amount: '7,456.00',
      paymentType: 'IFT',
      paymentStatus: 'Completed',
      fxApplied: 'YES',
    },
  ];
  constructor(private router: Router) {}
  openadd() {
    this.router.navigate(['/remittance/outwardlist/add']);
  }
}
