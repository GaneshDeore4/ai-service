import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-download-modal',
  templateUrl: './download-modal.component.html',
  styleUrls: ['./download-modal.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class DownloadModalComponent {
  @Input() isOpen = false;
  @Output() onClose = new EventEmitter<void>();
  @Output() onConfirm = new EventEmitter<string>();

  activeTab = 'pc';
  selectedFileType: string = 'PDF';

  close() {
    this.isOpen = false;
    this.onClose.emit();
  }

  /* confirm() {
    this.onConfirm.emit('PDF'); // In a real app, send the actual selected value
    this.close();
  } */

  confirm() {
    this.onConfirm.emit(this.selectedFileType);
    this.close();
  }
}
