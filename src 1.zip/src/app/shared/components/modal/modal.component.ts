import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css'],
  standalone: true,
  imports: [CommonModule]
})
export class ModalComponent {
  @Input() title: string = '';
  @Input() isOpen: boolean = false;
  @Input() showFooter: boolean = true;
  @Input() type: 'default' | 'success' | 'error' = 'default';
  @Output() onClose = new EventEmitter<void>();

  close() {
    this.onClose.emit();
  }
}
