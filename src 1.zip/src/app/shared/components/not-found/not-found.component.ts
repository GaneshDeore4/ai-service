import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="auth-split-layout">
      <div class="auth-right">
        <div class="login-card text-center">
          <div class="mb-4">
            <h1 class="text-primary" style="font-size: 80px; font-weight: 800; opacity: 0.2">404</h1>
            <h3 class="mb-3">Oops! Page Not Found</h3>
            <p class="text-muted mb-4">The page you are looking for might have been removed or is temporarily unavailable.</p>
            <a routerLink="/login" class="btn btn-primary">
              <i class="fas fa-home me-2"></i> Back to Login
            </a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .text-primary { color: var(--primary-color); }
  `]
})
export class NotFoundComponent {}
