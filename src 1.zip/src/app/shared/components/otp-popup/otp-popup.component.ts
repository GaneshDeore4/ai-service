import {
  Component,
  EventEmitter,
  Output,
  Input,
  ViewChildren,
  QueryList,
  ElementRef,
  AfterViewInit,
} from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-otp-popup',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './otp-popup.component.html',
  styleUrls: ['./otp-popup.component.css'],
})
export class OtpPopupComponent implements AfterViewInit {
  @Input() visible: boolean = false;

  @Output() verify = new EventEmitter<string>();
  @Output() close = new EventEmitter<void>();

  @ViewChildren('otpInput') otpInputs!: QueryList<ElementRef>;

  enteredOtp: string = '';

  ngAfterViewInit() {
    setTimeout(() => {
      this.otpInputs?.first?.nativeElement.focus();
    });
  }

  onOtpInput(event: any, index: number) {
    const input = event.target;
    const value = input.value;

    if (value.length > 1) {
      input.value = value.charAt(0);
    }

    if (value && index < this.otpInputs.length - 1) {
      this.otpInputs.toArray()[index + 1].nativeElement.focus();
    }

    this.updateOtp();
  }

  onOtpKeyDown(event: KeyboardEvent, index: number) {
    const input = event.target as HTMLInputElement;

    if (event.key === 'Backspace' && !input.value && index > 0) {
      this.otpInputs.toArray()[index - 1].nativeElement.focus();
    }
  }

  updateOtp() {
    this.enteredOtp = this.otpInputs
      .toArray()
      .map((el) => el.nativeElement.value)
      .join('');
  }

  onVerify() {
    if (this.enteredOtp.length !== 6) return;
    this.verify.emit(this.enteredOtp);
  }

  onClose() {
    this.close.emit();
  }
}
