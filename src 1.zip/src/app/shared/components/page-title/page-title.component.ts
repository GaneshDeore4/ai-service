import { NgIf } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';


@Component({
  selector: 'app-page-title',
  imports: [NgIf],
  templateUrl: './page-title.component.html',
  styleUrl: './page-title.component.css'
})
export class PageTitleComponent {

  @Output()
  back = new EventEmitter<boolean>();

  @Input()
  title!:string;

  @Input()
  showIcon:boolean=true;


  backToList(){
    console.log("clicked in event emmiter");
    this.back.emit(true);
  }
}
