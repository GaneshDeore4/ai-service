import { GET_ALL_PRODUCTS_BY_CATEGORY_ID } from '../../../core/constants/api-endpoints';
import { Component } from '@angular/core';
import { ToastComponent } from "../toast/toast.component";
import { LoaderComponent } from "../loader/loader.component";
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TblComponent } from "../tbl/tbl.component";
import { PAGE_SIZE } from '../../../core/constants/Constants';
import { SAVE_MID_OFFICE_ACCESS } from '../../../core/constants/api-endpoints';
import { ApiService } from '../../../core/services/api.service';
export interface Product{
  productId:number;
  productName:String;
  midOfficeFlag:Boolean;
  [key: string]: any;
  previousFlag:Boolean; //this is for frontend to track id the flag was changed
}
@Component({
  selector: 'app-product-integration',
  imports: [ToastComponent, LoaderComponent, NgIf, FormsModule, TblComponent],
  templateUrl: './product-integration.component.html',
  styleUrl: './product-integration.component.css'
})
export class ProductIntegrationComponent {

  constructor(private apiService: ApiService) { }
  ngOnInit() {
    this.getTableData();
  };


  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'productIntegrationTable';
  isLoading = false;
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'productIntegrationTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }


  headers: { key: string; value: string }[] = [
    { key: 'productName', value: 'Product' },
    // { key: 'categoryName', value: 'Category' },
    { key: 'midOfficeFlag', value: 'Mid Office Access' },
  ];
  data: Product[] = [];
  getTableData() {
    this.isLoading = true;
    this.apiService.getData(GET_ALL_PRODUCTS_BY_CATEGORY_ID + "?categoryId=1&page=" + (this.pageNumber - 1) + "&size=" + this.pageSize, {}).subscribe({
      next: (res) => {
        if (res.status == "SUCCESS") {
          this.data=[];
          this.data = res.payload.content.map((element:Product) => {
            if(element.midOfficeFlag==null)
                element.midOfficeFlag=false;
            element.previousFlag = element.midOfficeFlag;
            return element;
          });
          console.log("products: " + JSON.stringify(this.data, null, 2));
          if (res.payload.page) {
            this.totalElements = res.payload.page.totalElements;
          }
        } else {
          console.log("inside get else");
          this.showToast('error', 'Error', res.description);
        }
      },
      error: (err) => {
        this.showToast('error', 'Error', 'Something went wrong');
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }
  saveMatrix() { 
   let dataToSend:{productId:number,midOfficeFlag:Boolean}[]=[];
    this.data.forEach(element => {
      if(element.previousFlag!=element.midOfficeFlag){
        dataToSend.push({productId:element.productId,midOfficeFlag:element.midOfficeFlag});
      }
    });
    if(dataToSend.length==0){
      this.showToast('warning', 'Waning', 'Please make changes to update the data');
      return;
    }
    this.isLoading = true;
    const payload = { "mapping": dataToSend}
    this.apiService.sendData(SAVE_MID_OFFICE_ACCESS, payload).subscribe({
      next: (res) => {
        if (res.status == "SUCCESS") {
          this.getTableData();
          this.showToast('success', 'Success', 'Middle Office access for the products has been update');
        } else {
          console.log("inside get else");
          this.showToast('error', 'Error', res.description);
        }
      },
      error: (err) => {
        this.showToast('error', 'Error', 'Something went wrong');
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  onMidOfficeAccessChange(event: { row: Product; key: string; checked: boolean; index: number }) {
    // Update the checked status in the local data array
    if (this.data && this.data[event.index]) {
      this.data[event.index][event.key] = event.checked;
      console.log("after checkbox click: " + JSON.stringify(this.data, null, 2));
    }
  }
}
