import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SessionTimeoutService } from '../../../core/services/sessionService/session-timeout.service';

@Component({
  selector: 'app-session-expiry',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="session-modal-overlay" *ngIf="sessionService && sessionService.sessionStatus() !== 'active'">
      <div class="session-modal-card" [class.expired]="sessionService.sessionStatus() === 'expired'">
        <div class="icon-section">
          <i class="fas" [class.fa-clock]="sessionService.sessionStatus() === 'warning'" 
                        [class.fa-user-clock]="sessionService.sessionStatus() === 'expired'"></i>
        </div>
        
        <div class="content-section">
          <h3 *ngIf="sessionService.sessionStatus() === 'warning'">Session Timeout</h3>
          <h3 *ngIf="sessionService.sessionStatus() === 'expired'">Session Expired</h3>
          
          <p *ngIf="sessionService.sessionStatus() === 'warning'">
            Your session will expire in <strong>{{ sessionService.countdown() }}s</strong>. 
            Would you like to stay logged in?
          </p>
          <p *ngIf="sessionService.sessionStatus() === 'expired'">
            Your session has timed out due to inactivity. Please log in again.
          </p>
        </div>

        <div class="action-section">
          <button *ngIf="sessionService.sessionStatus() === 'warning'" 
                  class="btn-extend" (click)="sessionService.extendSession()">
            Stay Logged In
          </button>
          <button *ngIf="sessionService.sessionStatus() === 'expired'" 
                  class="btn-login" (click)="sessionService.redirectToLogin()">
            Back to Login
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .session-modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(2px);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }
    .session-modal-card {
      background: white;
      padding: 24px;
      border-radius: 12px;
      width: 360px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      text-align: center;
      animation: slideDown 0.3s ease-out;
    }
    @keyframes slideDown {
      from { transform: translateY(-20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    .icon-section {
      font-size: 32px;
      margin-bottom: 16px;
      color: #e63946;
    }
    .content-section h3 {
      margin: 0 0 8px 0;
      font-size: 18px;
      color: #1d3557;
    }
    .content-section p {
      margin: 0;
      font-size: 14px;
      color: #457b9d;
      line-height: 1.5;
    }
    .action-section {
      margin-top: 24px;
    }
    .btn-extend {
      background: #1d3557;
      color: white;
      border: none;
      padding: 10px 24px;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s;
    }
    .btn-extend:hover { background: #457b9d; }
    .btn-login {
      background: #e63946;
      color: white;
      border: none;
      padding: 10px 24px;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
    }
  `]
})
export class SessionExpiryComponent {
  public sessionService = inject(SessionTimeoutService);
}
