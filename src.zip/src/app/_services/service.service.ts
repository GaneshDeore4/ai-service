import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs/internal/operators/map';


// const BACKEND_URL = "http://localhost:3000/api/";
const BACKEND_URL = "https://spectrum-india.com:3000/api/";

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  constructor(private http: HttpClient, private router: Router) { }

  getPDFs() {
    const url = BACKEND_URL+'getPdfFiles';
    return this.http.get(url,{responseType:'json'}).pipe(map(res => {
      return res;
    }));
  }

  getFilterData(type: number,fyear: number) {
    const url = BACKEND_URL+'getFilterData/'+fyear+"/"+type;
    console.log(url)
    return this.http.get(url,{responseType:'json'}).pipe(map(res => {
      return res;
    }));
  }

  login(requestBody:any){
    const url = BACKEND_URL+'login';
    return this.http.post(url,requestBody,{responseType:'json'}).pipe(map(res => {
      return res;
    }));
  }

  isLoggedIn(){
    let token = localStorage.getItem("username")
    if(token==undefined || token ==='' || token== null){
      return false
    }else{
      return true
    }
  }

  deletePDF(requestBody:any){
    const url = BACKEND_URL+'removePdf/'+requestBody.id+'/'+requestBody.file
    return this.http.delete(url).pipe(map(res => {
      return res;
    }));
  }

  addPdf(requestBody:any){
    const url = BACKEND_URL+'addPdf';
    return this.http.post(url,requestBody,{responseType:'json'}).pipe(map(res => {
      return res;
    }));
  }

  getPdfCount(){
    const url = BACKEND_URL+'getPdfCount'
    return this.http.get(url).pipe(map(res => {
      return res;
    }));
  }
  
  getAnnType(){
    const url = BACKEND_URL+'getAnnType'
    return this.http.get(url).pipe(map(res => {
      return res;
    }));
  }
  
  getCurrentFinancialYear() {
    var fiscalyear = "";
    var today = new Date();
    if ((today.getMonth() + 1) <= 3) {
      fiscalyear = (today.getFullYear() - 1) + "-" + today.getFullYear()
    } else {
      fiscalyear = today.getFullYear() + "-" + (today.getFullYear() + 1)
    }
    return fiscalyear
  }
}
