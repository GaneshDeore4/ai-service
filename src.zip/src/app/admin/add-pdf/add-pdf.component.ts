import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/_services/service.service';
@Component({
  selector: 'app-add-pdf',
  templateUrl: './add-pdf.component.html',
  styleUrls: ['./add-pdf.component.css']
})
export class AddPdfComponent implements OnInit {
  submitted = false;
  file: any;
  requestBody!: { fileName: any; title: string | null | undefined; };
  myForm: any;
  annType: any;
  anypeStatus: any;
  finsalYear: any;
  financialYears: { value: string; label: string }[] = [];

  constructor(private router : Router,private service:ServiceService,private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.getAnnType();
    this.generateFinancialYears();
    this.myForm = new FormGroup({
      title: new FormControl('', [Validators.required, Validators.minLength(3)]),
      file: new FormControl('', [Validators.required]),
      anypeStatus: new FormControl('',[Validators.required]),
      fileSource: new FormControl('', [Validators.required])
    });    
  }

  generateFinancialYears() {
    const currentYear = new Date().getFullYear();
    const startYear = 2018;
    const endYear = currentYear;
    for (let y = endYear; y >= startYear; y--) {
      this.financialYears.push({ value: `${y}-${y + 1}`, label: `${y}-${y + 1}` });
    }
  }

  getAnnType(){
    this.service.getAnnType().subscribe((res: any) => {
      this.annType = res.data;
      console.log(this.annType);
    })
  }

  changeType(e: any) {
    this.anypeStatus = e.target.value;
  }
  changeYear(e: any) {
    this.finsalYear = e.target.value;
  }

  get f(){
    return this.myForm.controls;
  }

  onFileChange(event:any) {  
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.myForm.patchValue({
        fileSource: file
      });
    }
  }

  submit(){
    this.spinner.show();
    console.log(this.anypeStatus);    
    const formData = new FormData();
    formData.append('fileName', this.myForm.get('fileSource')?.value);
    formData.append('title', this.myForm.get('title')?.value);
    formData.append('result_section', this.anypeStatus);
    formData.append('fileType', this.anypeStatus);
    formData.append('fiscalYear', this.finsalYear);
    
    this.service.addPdf(formData).subscribe(res => {
        console.log(res);
        this.spinner.hide()
        alert('Uploaded Successfully.');
        this.router.navigate(['admin/pdf-list']);
      })
  }

}
