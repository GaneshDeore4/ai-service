import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-header',
  templateUrl: './admin-header.component.html',
  styleUrls: ['./admin-header.component.css']
})
export class AdminHeaderComponent implements OnInit {
  username!: string | null;

  constructor(private router:Router) { }

  ngOnInit(): void {
    this.username = localStorage.getItem("username");
  }

  logout(){
    localStorage.removeItem('username');
    localStorage.clear();
    this.router.navigate([''])
  }
}
