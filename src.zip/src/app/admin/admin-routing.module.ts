import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../_services/auth.guard';
import { AddPdfComponent } from './add-pdf/add-pdf.component';
import { AdminComponent } from './admin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PdfFilesComponent } from './pdf-files/pdf-files.component';

const routes: Routes = [
  { 
    path:"", 
    // canActivate:[AuthGuard],
    component:AdminComponent },
  { 
    path:"add-pdf",
    canActivate:[AuthGuard],
    component:AddPdfComponent },

  { 
    path:"dashboard",
    canActivate:[AuthGuard],
    component:DashboardComponent
   },
  { 
    path:"pdf-list",
    canActivate:[AuthGuard],
    component:PdfFilesComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
