import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from '../_services/service.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  form: any = {
    username: null,
    password: null
  };
  
  isLoggedIn = false;
  logindetails!: boolean;
  constructor(private router : Router,private service:ServiceService) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      username: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])
    });
  }

  onSubmit(){
    const requestBody = {
          username: this.form.value.username,
          password: this.form.value.password
        };
      if(requestBody != null){
        const token = this.service.login(requestBody).subscribe((res:any) => { 
          if(res.data != ""){
            if(res.status === "1"){
              localStorage.setItem("username",res.data[0].username);
              this.router.navigate(['admin/dashboard'])     
            } 
          }else{
            this.logindetails = true;
          }         
      });
    }
  }

  get f(){
    return this.form.controls;
  }
  
}
