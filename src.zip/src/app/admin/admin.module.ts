import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminHeaderComponent } from './admin-header/admin-header.component';
import { PdfFilesComponent } from './pdf-files/pdf-files.component';
import { AddPdfComponent } from './add-pdf/add-pdf.component';
import { AdminComponent } from './admin.component';
import {DataTablesModule} from 'angular-datatables';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from '../_services/auth.guard';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
  declarations: [
    AdminHeaderComponent,
    PdfFilesComponent,
    AddPdfComponent,
    AdminComponent,
    DashboardComponent
  ],
  imports: [
    FormsModule,
    DataTablesModule,
    ReactiveFormsModule,
    CommonModule,
    AdminRoutingModule,
    NgbModule,
    HttpClientModule,
    NgxSpinnerModule.forRoot({ type: 'ball-scale-multiple' }),       
  ],
  providers: [AuthGuard],
})
export class AdminModule { }
