import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/_services/service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  count: any;

  constructor(private router : Router, private service:ServiceService) { }

  ngOnInit(): void {

    this.getPdfCount();
  }
  gotopdf(){
    this.router.navigate(['admin/pdf-list'])
  } 

  getPdfCount(){
    this.service.getPdfCount().subscribe((res:any) => {  
      console.log(res);
      this.count = res.data[0].count;
    });
    
  }
}
