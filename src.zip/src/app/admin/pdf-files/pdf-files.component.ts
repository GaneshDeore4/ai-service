import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ServiceService } from 'src/app/_services/service.service';

@Component({
  selector: 'app-pdf-files',
  templateUrl: './pdf-files.component.html',
  styleUrls: ['./pdf-files.component.css']
})
export class PdfFilesComponent implements OnInit {
  data: any;

  constructor(private service:ServiceService,private spinner: NgxSpinnerService) { }

  ngOnInit(): void {

    this.getData();
    
  }

  getData(){
    this.spinner.show();
    this.service.getPDFs().subscribe((data:any) => {  
      this.spinner.hide();
    this.data = data.data;
    console.log(this.data);
    
        // setTimeout(()=>{   
        //   $('#datatableexample').DataTable( {
        //     pagingType: 'full_numbers',
        //     pageLength: 5,
        //     processing: true,
        //     lengthMenu : [5, 10, 25]
        // } );
        // }, 1);
    });
  }

  delete(data:any){
    console.log(data);
    this.service.deletePDF(data).subscribe((data:any) => {  
      alert("Delete successfull !! ")
      this.getData()
    });
  }

  // edit(data:any){
  //   console.log(data);
  //   this.service.edit(data).subscribe((data:any) => {  
  //     alert("Delete successfull !! ")
  //     this.getData()
  //   });
  // }

}
