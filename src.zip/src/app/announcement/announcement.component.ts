import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { saveAs } from "file-saver";
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: 'app-announcement',
  templateUrl: './announcement.component.html',
  styleUrls: ['./announcement.component.css']
})
export class AnnouncementComponent implements OnInit {
  name: any;
  pdfSrc: any;
  pdftitle: any;
  
  constructor(private router: Router,private httpClient: HttpClient,private spinner: NgxSpinnerService) { }
  public loading = false;

  ngOnInit(): void {
    this.spinner.show();
    var url = this.router.url.split('/')
    this.pdftitle = localStorage.getItem('name')
    this.name = url[2]
    this.spinner.hide();
    this.pdfSrc = "../assets/PDF/"+this.name;
    // console.log(this.pdfSrc);
    
 }
 
  downlaod() {
    const URL = "../assets/PDF/"+this.name;
    this.httpClient.get(URL, { responseType: "arraybuffer" }).subscribe(
      pdf => {
        const blob = new Blob([pdf], { type: "application/pdf" });
        const fileName = this.name;
        saveAs(blob, fileName);
      },
      err => {
        console.log("err->", err);
      }
    );
  }

}
