import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminComponent } from './admin/admin.component';
import { PdfFilesComponent } from './admin/pdf-files/pdf-files.component';
import { AnnouncementComponent } from './announcement/announcement.component';
import { ContactComponent } from './contact/contact.component';
import { ContactusComponent } from './contactus/contactus.component';
import { DocumentComponent } from './document/document.component';
import { HomeComponent } from './home/home.component';
import { InvestorRelationsComponent } from './investor-relations/investor-relations.component';
import { OurProductsComponent } from './our-products/our-products.component';
import { ServicesComponent } from './services/services.component';
import { TeamComponent } from './team/team.component';
import { AuthGuard } from './_services/auth.guard';

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "home", component: HomeComponent },
  { path: "about", component: AboutComponent },
  { path: "services", component: ServicesComponent },
  { path: "announcement/:name", component: AnnouncementComponent },
  { path: "contact-us", component: ContactusComponent },
  { path: "investor-relations", component: InvestorRelationsComponent },
  { path: "our-products", component: OurProductsComponent },
  { path: "team", component: TeamComponent },
  { path: "documents", component: DocumentComponent },
 
  // { 
  //   path: "login", 
  //   loadChildren:()=>import('./admin/admin.module').then(mod => mod.AdminModule) 
  // },

  { 
    path:"admin", 
    // component: MainShellComponent,
    children: [
    {    
      path:"",
      // canActivate:[AuthGuard],
      loadChildren:()=>import('./admin/admin.module').then(mod => mod.AdminModule)
    }
  ]
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes,{scrollPositionRestoration: 'enabled',useHash: true})
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { 

}
