import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import { OurProductsComponent } from './our-products/our-products.component';
import { InvestorRelationsComponent } from './investor-relations/investor-relations.component';
import { AnnouncementComponent } from './announcement/announcement.component';
import { TeamComponent } from './team/team.component';
import { ContactComponent } from './contact/contact.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DocumentComponent } from './document/document.component';
import { ContactusComponent } from './contactus/contactus.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { DisclosurePopupComponent } from './document/disclosure-popup/disclosure-popup.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ServicesComponent,
    OurProductsComponent,
    InvestorRelationsComponent,
    AnnouncementComponent,
    TeamComponent,
    ContactComponent,
    HeaderComponent,
    FooterComponent,
    DocumentComponent,
    ContactusComponent,
    DisclosurePopupComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    HttpClientModule,
    PdfViewerModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSpinnerModule.forRoot({ type: 'ball-scale-multiple' }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
