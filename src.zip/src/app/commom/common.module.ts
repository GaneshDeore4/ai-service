import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PreHeaderComponent } from './pre-header/pre-header.component';
import { MatDividerModule } from '@angular/material/divider';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule} from '@angular/material/list';
import { MainShellComponent } from './main-shell/main-shell.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SideNavbarComponent } from './side-navbar/side-navbar.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatExpansionModule } from '@angular/material/expansion';
import { RouterModule } from '@angular/router';


import { NgxsModule } from '@ngxs/store';
import { NgxsLoggerPluginModule } from '@ngxs/logger-plugin';
import { NgxsReduxDevtoolsPluginModule } from '@ngxs/devtools-plugin';
import { NgSelectModule } from '@ng-select/ng-select';
import { environment } from 'src/environments/environment';
import { userState } from '../admin/components/store/state/user.state';

@NgModule({
  declarations: [
    PreHeaderComponent,SidebarComponent, SideNavbarComponent,MainShellComponent
  ],
  exports: [PreHeaderComponent,SidebarComponent, SideNavbarComponent],
  imports: [
    CommonModule,
    RouterModule,
    MatDividerModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,MatToolbarModule,MatExpansionModule,

    NgxsModule.forRoot([userState], {
      developmentMode: !environment.production
    }),
    NgxsLoggerPluginModule.forRoot(),    
    NgxsReduxDevtoolsPluginModule.forRoot(),
    NgSelectModule,
  ]
})
export class CommonHModule { }
