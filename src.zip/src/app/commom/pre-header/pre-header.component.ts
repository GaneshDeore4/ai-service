import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ActivationStart, NavigationEnd, Router, RoutesRecognized } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, map, mergeMap, startWith, switchMap } from 'rxjs/operators';
import { AuthService } from 'src/app/_services/auth.service';
import { RoleStorageService } from 'src/app/_services/role-storage.service';

export interface userInfo {
  loginUserName: string,
  lastLoginTime: string
}

@Component({
  selector: 'app-pre-header',
  templateUrl: './pre-header.component.html',
  styleUrls: ['./pre-header.component.css']
})
export class PreHeaderComponent implements OnInit {

  componentTitle: string | undefined;
  loginUserName!: String | undefined | null;
  lastLoginTime: string | null | undefined;
  zones: any;
  zoneList: any;

  constructor(private router: Router, private roleStorageService:RoleStorageService,private activatedRoute: ActivatedRoute,private authService:AuthService) {
   
    this.router.events.subscribe(data => {
      if (data instanceof ActivationStart) {
        this.componentTitle = data.snapshot.data['title'];
      }

    });
    this.router.events.pipe(
      filter((event) => event instanceof NavigationEnd),
      startWith(this.router)
   )   
  }

  ngOnInit() {
    this.loginUserName = this.roleStorageService.getName();
    this.lastLoginTime = this.roleStorageService.getLastLoginTime();
    this.zoneList = this.roleStorageService.getZone();    
    this.zones = JSON.parse(this.zoneList);
  }

  signout(){
    this.authService.logout();
    this.router.navigate([""])
  }
}
