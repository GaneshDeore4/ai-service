import { Component, OnInit } from '@angular/core'; 
import { Observable } from 'rxjs';
import { Role } from 'src/app/Role';
import { RoleStorageService } from 'src/app/_services/role-storage.service';
import { HttpclientService } from './HttpClientServices';
 
export interface IMenu {
  text: string,
  icon: string,
  routerLink?: string;
  children: IMenuItem[]
}
export interface IMenuItem {
  text: string,
  icon: string,
  routerLink: string;
}

@Component({
  selector: 'app-side-navbar',
  templateUrl: './side-navbar.component.html',
  styleUrls: ['./side-navbar.component.css']
})
export class SideNavbarComponent implements OnInit{

  menuList!: Observable<IMenu[]>;

  constructor(private httpService: HttpclientService,private roleStorageService: RoleStorageService) { }

  ngOnInit() {
    if(this.roleStorageService.getRole() != Role.admin){
      this.menuList = this.httpService.getList<IMenu>("/assets/menu.json")
    }else{
      this.menuList = this.httpService.getList<IMenu>("/assets/adminSidebar.json")
    }
  }

}
