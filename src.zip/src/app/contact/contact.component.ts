import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../_services/service.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  data: any;
  constructor(private service:ServiceService) { }

  ngOnInit(): void {
    this.getData();
  }

  getData(){
    this.service.getPDFs().subscribe((data:any) => {  
    this.data = data.data;
    console.log(this.data);
    });
  }

}
