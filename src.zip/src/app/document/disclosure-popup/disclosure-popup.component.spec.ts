import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisclosurePopupComponent } from './disclosure-popup.component';

describe('DisclosurePopupComponent', () => {
  let component: DisclosurePopupComponent;
  let fixture: ComponentFixture<DisclosurePopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisclosurePopupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DisclosurePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
