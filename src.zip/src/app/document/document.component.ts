import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../_services/service.service';
import { saveAs } from "file-saver";
import { NgxSpinnerService } from 'ngx-spinner';
import { NgbModal} from '@ng-bootstrap/ng-bootstrap';



@Component({
  selector: 'app-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.css']
})
export class DocumentComponent implements OnInit {

  documentUrl = "../assets/PDF/PDF1688334300278";

  filteredData: any;
  quarterly: any;
  anually: any;
  qCount: any;
  aCount: any;
  types: any;
  fyear: any;
  name: any;
  public loading = false;
  annType: any;
  showYearFilter = true;
  financialYears: { value: string; label: string }[] = [];
  closeResult: string | undefined;
  modalRef: any;
  
  constructor(private service:ServiceService,private router : Router,private httpClient: HttpClient,private spinner: NgxSpinnerService,public modalService: NgbModal) { }

  ngOnInit(): void {
    let status = localStorage.getItem('status');
    this.showYearFilter = (status !== '4' && status !== '7' && status !== '23');
    this.generateFinancialYears();
    this.onSearchbtn();
    // this.getPDFs();
    this.getAnnType();
    // this.allPdfFiles();
  }

  generateFinancialYears() {
    const currentYear = new Date().getFullYear();
    const startYear = 2018;
    const endYear = currentYear;
    for (let y = endYear; y >= startYear; y--) {
      this.financialYears.push({
        value: `${y}-${y + 1}`,
        label: `${y}-${String(y + 1).slice(2)}`
      });
    }
  }

 


  getPDFs(){
    this.service.getPDFs().subscribe((data: any) => {
      try {      
        let  array = data.data;  
        this.quarterly = array.filter((x: { result_section: number; }) => x.result_section == 1);
        this.anually  = array.filter((x: { result_section: number; }) => x.result_section == 0);
        this.qCount = this.quarterly.length | 0;
        this.aCount = this.anually.length | 0;
        // console.log(this.quarterly);        
        this.gotoPDF(this.quarterly.file
          );
        // console.log(this.anually); 
      } catch (error) {
        console.log(error);        
      }
    });
    
  }

  changeType(e: any) {
    this.types = e.target.value;
    this.showYearFilter = (this.types !== '4' && this.types !== '7' && this.types !== '23');
    this.fyear = undefined;
  }

  changeYear(e: any) {
    this.fyear = e.target.value;
  }

  onSearchbtn(){
    this.filteredData = [];
    let status = localStorage.getItem('status');
    let types1: any;
    if(this.types != undefined ){
      types1 = this.types;
    }else{
      types1 = status;
    }

    if (String(types1) === '4' || String(types1) === '7' || String(types1) === '23') {
      this.service.getPDFs().subscribe((data: any) => {
        try {
          if (data.status == 1) {
            this.filteredData = (data.data || []).filter((x: any) => String(x.fileType) === String(types1));
          } else {
            alert("API failed Error");
          }
        } catch (error) {
          alert("Connection Error:" + error);
        }
      });
      return;
    }

    let fisYear = this.service.getCurrentFinancialYear();
    let fyear1
    if(this.fyear == undefined){
      fyear1 = fisYear;
    }else{
      fyear1 = this.fyear;
    }
    this.service.getFilterData(types1,fyear1).subscribe((data:any) => {
      // console.log(data);
      try {
        if(data.status == 1){
          if(data.data == ""){
            // console.log("if");

          }else{
            // console.log("else");
            this.filteredData = data.data;
          }
        }else{
          alert("API failed Error");
        }
      } catch (error) {
        alert("Connection Error:"+error);
      }

    });
    // alert(this.service.getCurrentFinancialYear())
  }

  allPdfFiles(){
  this.service.getPDFs().subscribe((data:any) => { 
    // console.log(data);
    try {
      if(data.status == 1){          
          this.filteredData = data.data;
      }else{
        alert("API failed Error");
      }
    } catch (error) {
      alert("Connection Error:"+error);
    }
    
  });
}

  gotoPDF(file: string){
    this.spinner.show();
    let currentUrl = this.router.url;
      this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
      this.router.navigate(['announcement/'+file]);
      });
  }

  getAnnType(){
    this.service.getAnnType().subscribe((res: any) => {
      this.annType = res.data;
      // console.log(this.annType);
    })
  }
  
  downlaod(fileName:any) {
    const URL = "../assets/PDF/"+fileName;
    this.httpClient.get(URL, { responseType: "arraybuffer" }).subscribe(
      pdf => {
        const blob = new Blob([pdf], { type: "application/pdf" });
        const fileName = this.name;
        saveAs(blob, fileName);
      },
      err => {
        console.log("err->", err);
      }
    );
  }

}
