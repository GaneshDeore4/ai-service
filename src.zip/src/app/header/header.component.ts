import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from '../_services/service.service';
var menulist = require('../../assets/menulist.json')
import { NgbModal} from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  documentUrl = "../assets/PDF/PDF1688334300278";

  newarr: any;
  id: any;
  tab: any;
  quarterly: any;
  anually: any;
  qCount: any;
  aCount: any;
  Quarterly = "Quarterly";
  Anually = "Anually";
  annType: any;  
  closeResult: string | undefined;
  modalRef: any;
  qipStatus: any;

  constructor(private router : Router,private route: ActivatedRoute,private service: ServiceService,public modalService: NgbModal) {
    this.id = route.snapshot.params['name'];
   }

  menulist = menulist;
  
  ngOnInit(): void {
    // this.newarr = menulist.sort((x: any, y: any) => y.id - x.id);
    // this.route.queryParams.subscribe((params: any) => {
    //     console.log(params);
    // })
    localStorage.removeItem('username');
    
    this.getAnnType();
    this.getPDFs()
  }


  open(content: any,urlQip:string): void {
    if(urlQip){

    }
    this.qipStatus = urlQip;
    const modalRef = this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
    });
    // modalRef.componentInstance.documentUrl = this.documentUrl;
  }

  doNotConfirm(): void {
    // if (this.modalRef) {
    //   this.modalRef.close();
    //   // this.router.navigateByUrl('/');
    // }
    this.modalService.dismissAll();
    this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
      this.router.navigate(['/']);
    });
  }

  confirmNClose(){
    this.modalService.dismissAll();
      localStorage.setItem('status',this.qipStatus);
      this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
        this.router.navigate(['/announcement/'+this.qipStatus+'.pdf']);
      });
      
      // this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
      //   this.router.navigate(['announcement']);
      // });
  }

  goDirectPdfPgae(pagePDf:any){
      this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
        this.router.navigate(['/announcement/'+pagePDf+'.pdf']);
  });
}

  // doNotConfirm() {
  //   this.modalRef.close();
  //     localStorage.setItem('status','4');
  //     this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
  //       this.router.navigate(['announcement/'+this.documentUrl]);
  //     });
  // }

  getAnnType(){
    this.service.getAnnType().subscribe((res: any) => {
      this.annType = res.data;
      // console.log(this.annType);
    })
  }

  getPDFs(){
    this.service.getPDFs().subscribe((data: any) => {
      try {      
        let  array = data.data;  
        this.quarterly = array.filter((x: { result_section: number; }) => x.result_section == 1);
        this.anually  = array.filter((x: { result_section: number; }) => x.result_section == 0);
        this.qCount = this.quarterly.length | 0;
        this.aCount = this.anually.length | 0;
        // console.log(this.quarterly);        
        // console.log(this.anually); 
      } catch (error) {
        console.log(error);        
      }
    });
    
  }

  // gotoLink(filename:any,title: any,file:any){
  //   localStorage.removeItem('name')
  //   localStorage.setItem("name",title) 
  //     let currentUrl = this.router.url;
  //     this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
  //     this.router.navigate(['announcement/'+file]);
  //     });
  //   // var pdfSrc = "../assets/PDF/"+name;  
  //   // window.open('announcement/'+name, "_blank");
  // }

  get flatAnnTypes() {
    return (this.annType || []).filter((t: any) => ![21, 22, 23].includes(Number(t.status)));
  }

  gotoLink(status:any,url:String){
      let currentUrl = this.router.url;
      localStorage.setItem('status',status)
      this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
      this.router.navigate([url]);});
  }

  goRouterLink(url: any){    
    localStorage.removeItem('name')
    if(this.id != undefined || this.id != ""){      
      this.tab = url;
      this.nextRouting(url);
      this.router.navigate([url]);
    }
  }

  nextRouting(url: any){
    this.router.navigate([url]);
    this.tab = url;
  }

}
