import { Component, OnInit, ViewChild } from '@angular/core';

import { NgbCarousel, NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  @ViewChild('myCarousel')
  myCarousel!: NgbCarousel;
  images = [
    {src: "assets/img/slider/slider1.JPG"},
    {src: "assets/img/slider/slider2.JPG"},
    {src: "assets/img/slider/slider3.JPG"},
    {title: 'Second Slide', short: 'Second Slide Short', src: "assets/img/slider/slider4.JPG"},
    {title: 'Third Slide', short: 'Third Slide Short', src: "assets/img/slider/slider5.JPG"}
  ];
   
  constructor(config: NgbCarouselConfig) {
    config.interval = 10000;
    config.keyboard = true;
    config.pauseOnHover = true;
  }

  ngOnInit(): void {
  }

}
