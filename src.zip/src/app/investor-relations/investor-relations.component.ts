import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { saveAs } from "file-saver";
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-investor-relations',
  templateUrl: './investor-relations.component.html',
  styleUrls: ['./investor-relations.component.css']
})
export class InvestorRelationsComponent {
    
    pdfSrc = "../assets/PDF/Spectrum Prospectus_PrintFIle_SD_Declaration.pdf";
    
    constructor(private httpClient: HttpClient,private spinner: NgxSpinnerService) { }
 
    downlaod() {
      // this.spinner.show();
      const URL = this.pdfSrc;
      this.httpClient.get(URL, { responseType: "arraybuffer" }).subscribe(
        pdf => {
          // this.spinner.hide(); 
          const blob = new Blob([pdf], { type: "application/pdf" });
          const fileName = "Spectrum Prospectus_PrintFIle_SD_Declaration.pdf";
          saveAs(blob, fileName);
        },
        err => {
          console.log("err->", err);
        }
      );
    }

   
}
