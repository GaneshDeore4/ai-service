import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-products',
  templateUrl: './our-products.component.html',
  styleUrls: ['./our-products.component.css']
})
export class OurProductsComponent implements OnInit {

  images = [
    {name:"Distribution Board", src: "assets/img/portfolio/1.jpg"},
    {name:"AC Box", src: "assets/img/portfolio/2.jpg"},
    {name:"Modular Electric Board Panels", src: "assets/img/portfolio/3.jpg"},
    {name:"Mini MCB Base & Cover", src: "assets/img/portfolio/4.jpg"},
    {name:"Lamp Angle Holders", src: "assets/img/portfolio/5.jpg"},
    {name:"Surface Coating Services", src: "assets/img/portfolio/6.jpg"}
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
