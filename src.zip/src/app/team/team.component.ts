import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {
  team = [
    {name:"Mr. Deepak Chaudhari",position:"Promoter Chairman & Managing Director",dealy:"100"},
    {name:"Mrs. Bharti Chaudhari",position:"Whole Time Director",dealy:"200"},
    {name:"Mr. Devendra Rane",position:"Director",dealy:"300"},
    // {name:"Mr. Chandrakant Rane",position:"Director",dealy:"400"},
    {name:"Mr. Sanjay Pawade",position:"Independent Director",dealy:"500"},
    {name:"Mr. Narendra Wagh",position:"Independent Director",dealy:"600"},
    {name:"Mr. Kishor Dhake",position:"Independent Director",dealy:"700"},
    {name:"Mr. Saurabh Malpani",position:"Independent Director",dealy:"800"},
    {name:"Mrs. Priya Rathi",position:"Independent Director",dealy:"800"},
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
