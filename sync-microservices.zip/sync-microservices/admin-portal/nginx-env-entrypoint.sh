#!/bin/sh
# Runtime env injection for the Angular SPA.
# Writes /usr/share/nginx/html/env.js from container env vars before starting
# nginx. The Helm chart sets these via values.yaml -> deployment env block.
#
# Override-able env vars (defaults match the dev gateway):
#   API_URL  - backend / gateway base URL the SPA hits via HttpClient
set -eu

: "${API_URL:=https://devapigatewaycib.np.gct.indusind.bank.in}"

WEB_ROOT="/usr/share/nginx/html"
ENV_JS="${WEB_ROOT}/env.js"

cat > "${ENV_JS}" <<EOF
// Generated at container start by nginx-env-entrypoint.sh — do not edit.
window.API_URL = "${API_URL}";
EOF

echo "[entrypoint] wrote ${ENV_JS} with API_URL=${API_URL}"

exec nginx -g 'daemon off;'
