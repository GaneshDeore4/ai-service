import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { LayoutComponent } from './components/layout/layout.component';
import { TestComponent } from './components/test/test.component';
import { LandingComponent } from './components/landing/landing.component';
import { NewsLandingComponent } from './components/news/news-landing/news-landing.component';
import { NewsInternalComponent } from './components/news/news-internal/news-internal.component';
import { NewsTickerComponent } from './components/news/news-ticker/news-ticker.component';
import { SfLandingComponent } from './components/system-features/sf-landing/sf-landing.component';
import { SfChangeProfileComponent } from './components/system-features/sf-change-profile/sf-change-profile.component';
import { JmRolesComponent } from './components/system-features/jurisdiction-maintenance/jm-roles/jm-roles.component';
import { JmAuthorisationComponent } from './components/system-features/jurisdiction-maintenance/jm-authorisation/jm-authorisation.component';
import { RateMaintenanceComponent } from './components/system-features/rate-maintenance/rate-maintenance.component';
import { CmProfilesComponent } from './components/system-features/customer-maintenance/cm-profiles/cm-profiles.component';
import { CmEntitiesComponent } from './components/system-features/customer-maintenance/cm-entities/cm-entities.component';
import { CmAuthorisationsComponent } from './components/system-features/customer-maintenance/cm-authorisations/cm-authorisations.component';
import { CmUserProfileComponent } from './components/system-features/customer-maintenance/cm-user-profile/cm-user-profile.component';
import { CmUserAccountComponent } from './components/system-features/customer-maintenance/cm-user-account/cm-user-account.component';
import { CmBoRefComponent } from './components/system-features/customer-maintenance/cm-bo-ref/cm-bo-ref.component';
import { CmAuthenticationComponent } from './components/system-features/customer-maintenance/cm-authentication/cm-authentication.component';
import { PendingEntitiesComponent } from './components/dashboard_tables/pending-entities/pending-entities.component';
import { MoLandingComponent } from './components/middle-office/mo-landing/mo-landing.component';
import { PrRecordListComponent } from './components/middle-office/pending-records/pr-record-list/pr-record-list.component';
import { TaskMonitoringComponent } from './components/middle-office/task-monitoring/task-monitoring.component';
import { UmProfileComponent } from './components/system-features/user-maintenance/um-profile/um-profile.component';
import { UmAuthenticationComponent } from './components/system-features/user-maintenance/um-authentication/um-authentication.component';
import { BmUserProfileComponent } from './components/system-features/bank-maintenance/bm-user-profile/bm-user-profile.component';
import { BmUserAuthenticationComponent } from './components/system-features/bank-maintenance/bm-user-authentication/bm-user-authentication.component';
import { ExternalAccountsComponent } from './components/system-features/customer-maintenance/external-accounts/external-accounts.component';
import { AlertMaintenanceComponent } from './components/system-features/alert-maintenance/alert-maintenance.component';
import { PrEditTransactionComponent } from './components/middle-office/pending-records/pr-edit-transaction/pr-edit-transaction.component';
import { RetrieveUnsignedComponent } from './components/middle-office/pending-records/retrieve-unsigned/retrieve-unsigned.component';
import { PrReleaseRejectTransactionComponent } from './components/middle-office/pending-records/pr-release-reject-transaction/pr-release-reject-transaction.component';
import { ErRecordListComponent } from './components/middle-office/exisiting-records/er-record-list/er-record-list.component';
import { CmFileUploadComponent } from './components/system-features/customer-maintenance/cm-file-upload/cm-file-upload.component';
import { RoleMasterComponent } from './components/system-features/jurisdiction-maintenance/role-master/role-master.component';
import { ProductMasterComponent } from './components/system-features/jurisdiction-maintenance/product-master/product-master.component';
import { SubProductMasterComponent } from './components/system-features/jurisdiction-maintenance/sub-product-master/sub-product-master.component';
import { CategoryMasterComponent } from './components/system-features/jurisdiction-maintenance/category-master/category-master.component';
import { UserMasterComponent } from './components/system-features/jurisdiction-maintenance/user-master/user-master.component';
import { ActionMasterComponent } from './components/system-features/jurisdiction-maintenance/action-master/action-master.component';
import { ActionMappingMasterComponent } from './components/system-features/jurisdiction-maintenance/action-mapping-master/action-mapping-master.component';
import { TranInquiryComponent } from './components/middle-office/mo-transactions/tran-inquiry/tran-inquiry.component';
import { PendingAtClientComponent } from './components/middle-office/mo-transactions/pending-at-client/pending-at-client.component';
import { PendingAtBankComponent } from './components/middle-office/mo-transactions/pending-at-bank/pending-at-bank.component';
import { ProcessedAtBankComponent } from './components/middle-office/mo-transactions/processed-at-bank/processed-at-bank.component';
import { BankProfileComponent } from './components/system-features/bank-maintenance/bank-profile/bank-profile.component';
import { DetailsComponent } from './commom/details/details.component';
import { UserAccountMappingComponent } from './components/system-features/customer-maintenance/user-account-mapping/user-account-mapping.component';
import { authGuard } from './service/authGuard/auth.guard';
import { UserTypeDepartmentMappingComponent } from './components/system-features/jurisdiction-maintenance/user-type-department-mapping/user-type-department-mapping.component';
import { ProductIntegrationComponent } from './components/system-features/jurisdiction-maintenance/product-integration/product-integration.component';
import { DepartmentsComponent } from './components/system-features/jurisdiction-maintenance/departments/departments.component';

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'content',
        component: LayoutComponent,
        children: [
            {
                path: 'landing',
                canActivate:[authGuard],
                component: LandingComponent
            },
            {
                path: 'news-landing',
                canActivate:[authGuard],
                component: NewsLandingComponent
            },
            {
                path: 'news-internal',
                canActivate:[authGuard],
                component: NewsInternalComponent
            },
            {
                path: 'news-ticker',
                canActivate:[authGuard],
                component: NewsTickerComponent
            },
            {
                path: 'sf-landing',
                canActivate:[authGuard],
                component: SfLandingComponent
            },
            {
                path: 'sf-change-profile',
                canActivate:[authGuard],
                component: SfChangeProfileComponent
            },
             {
                path: 'jm-roles',
                canActivate:[authGuard],
                component: JmRolesComponent
            },
             {
                path: 'jm-authorisation',
                canActivate:[authGuard],
                component: JmAuthorisationComponent
            },
             {
                path: 'rate-maintenance',
                canActivate:[authGuard],
                component: RateMaintenanceComponent
            },
            {
                path: 'cm-profiles',
                canActivate:[authGuard],
                component: CmProfilesComponent
            },
            {
                path: 'cm-entities',
                canActivate:[authGuard],
                component: CmEntitiesComponent
            },
            {
                path: 'pending-entities',
                canActivate:[authGuard],
                component: PendingEntitiesComponent
            },
            {
                path: 'cm-authorisation',
                canActivate:[authGuard],
                component: CmAuthorisationsComponent
            },
            {
                path: 'user-account-mapping',
                canActivate:[authGuard],
                component: UserAccountMappingComponent
            },
            {
                path: 'cm-user-profile',
                canActivate:[authGuard],
                component: CmUserProfileComponent
            },
            {
                path: 'cm-user-account',
                canActivate:[authGuard],
                component: CmUserAccountComponent
            },
            {
                path: 'cm-user-bo-ref',
                canActivate:[authGuard],
                component: CmBoRefComponent
            },
            {
                path: 'cm-external-accounts',
                canActivate:[authGuard],
                component: ExternalAccountsComponent
            },
            {
                path: 'cm-authentication',
                canActivate:[authGuard],
                component: CmAuthenticationComponent
            },
            {
                path: 'mo-landing',
                canActivate:[authGuard],
                component: MoLandingComponent
            },
            {
                path: 'pr-record-list',
                canActivate:[authGuard],
                component: PrRecordListComponent
            },
            {
                path: 'mo-task-monitoring',
                canActivate:[authGuard],
                component: TaskMonitoringComponent
            },
            {
                path: 'um-profile',
                canActivate:[authGuard],
                component: UmProfileComponent
            },
            {
                path: 'um-authentication',
                canActivate:[authGuard],
                component: UmAuthenticationComponent
            },
            {
                path: 'bm-user-profile',
                canActivate:[authGuard],
                component: BmUserProfileComponent
            },
            {
                path: 'bm-user-authentication',
                canActivate:[authGuard],
                component: BmUserAuthenticationComponent
            },
            {
                path: 'alert-maintenance',
                canActivate:[authGuard],
                component: AlertMaintenanceComponent
            },
            {
                path: 'pr-edit-transaction',
                canActivate:[authGuard],
                component: PrEditTransactionComponent
            },
            {
                path: 'retrieve-unsigned',
                canActivate:[authGuard],
                component: RetrieveUnsignedComponent
            },
            {
                path: 'pr-release-reject-tran',
                canActivate:[authGuard],
                component: PrReleaseRejectTransactionComponent
            },
            {
                path: 'er-record-list',
                canActivate:[authGuard],
                component: ErRecordListComponent
            },
            {
                path: 'cm-file-upload',
                canActivate:[authGuard],
                component: CmFileUploadComponent
            },
            {
                path: 'role-master',
                canActivate:[authGuard],
                component: RoleMasterComponent
            },
            {
                path: 'product-master',
                canActivate:[authGuard],
                component: ProductMasterComponent
            },
            {
                path: 'sub-product-master',
                canActivate:[authGuard],
                component: SubProductMasterComponent
            },
            {
                path: 'category-master',
                canActivate:[authGuard],
                component: CategoryMasterComponent
            },
            {
                path: 'user-type-master',
                canActivate:[authGuard],
                component: UserMasterComponent
            },
            {
                path: 'departments',
                canActivate:[authGuard],
                component: DepartmentsComponent
            },
            {
                path: 'user-type-department-mapping',
                canActivate:[authGuard],
                component: UserTypeDepartmentMappingComponent
            },
            {
                path: 'action-master',
                canActivate:[authGuard],
                component: ActionMasterComponent
            },
            {
                path: 'action-mapping-master',
                canActivate:[authGuard],
                component: ActionMappingMasterComponent
            },
            {
                path: 'product-integration',
                canActivate:[authGuard],
                component: ProductIntegrationComponent
            },
            {
                path: 'trans-inquiry',
                canActivate:[authGuard],
                component: TranInquiryComponent
            },
            {
                path: 'pending-at-client',
                canActivate:[authGuard],
                component: PendingAtClientComponent
            },
            {
                path: 'pending-at-bank',
                canActivate:[authGuard],
                component: PendingAtBankComponent
            },
            {
                path: 'processed-by-bank',
                canActivate:[authGuard],
                component: ProcessedAtBankComponent
            },
            {
                path: 'bank-profile',
                canActivate:[authGuard],
                component: BankProfileComponent
            },
            {
                path: 'details',
                canActivate:[authGuard],
                component: DetailsComponent
            },
        ]
    }
];
