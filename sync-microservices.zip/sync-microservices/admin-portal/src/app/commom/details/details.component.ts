import { Component } from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

import { ActivatedRoute, Router } from '@angular/router';

import { Location } from '@angular/common';
import { MoFdTableData } from '../../model/MoFd';
import {
  BANKBRANCHVERIFIER,
  PENDING_AT_MID_OFFICE,
} from '../../constants/Constants';
import { ApiService } from '../../service/apiService/api.service';
import { APPROVE_MO_FD, REJECT_MO_FD } from '../../constants/api_endpoints';
import { SessionService } from '../../service/sessionService/session.service';
import { ToastComponent } from '../toast/toast.component';
import { LoaderComponent } from '../loader/loader.component';

interface GenericField {
  key: string;

  label: string;
}

interface DetailSection {
  title: string;

  fields: GenericField[];
}

@Component({
  selector: 'app-details',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ToastComponent, LoaderComponent],
  templateUrl: './details.component.html',
  styleUrl: './details.component.css',
})
export class DetailsComponent {
  form!: FormGroup;

  sections: DetailSection[] = [];

  mode: 'view' | 'edit' | 'auth' = 'view';

  title = 'Details';

  subtitle = 'View or edit details.';

  originalRow: MoFdTableData | null = null;

  isLoading = false;

  showAuthBtns = false;

  constructor(
    private fb: FormBuilder,

    private route: ActivatedRoute,
    private router: Router,
    private location: Location,
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.route.queryParams.subscribe((params) => {
      let row: MoFdTableData | null = null;

      if (params['row']) {
        try {
          row = JSON.parse(params['row']);

          console.table(row);
        } catch {
          row = params['row'];
        }
      }

      this.originalRow = row;
      this.showAuthBtns =
        row?.status == PENDING_AT_MID_OFFICE &&
        sessionService.getRole() == BANKBRANCHVERIFIER
          ? true
          : false;
      if (row && typeof row === 'object') {
        row = { ...row };
        const fieldsToRemove = [
          'id',
          'userId',
          'userBaseCurrency',
          'loginId',
          'termsAccepted',
          'stateId',
          'authMatrixId',
          'currentLevel',
          'rejectReason',
          'makerId',
          'productId',
          'subProductId',
          'version',
          'tenure',
        ];
        fieldsToRemove.forEach((field) => delete (row as any)[field]);
      }

      const mode = params['mode'];
      this.mode = mode === 'edit' || mode === 'auth' ? mode : 'view';

      if (params['title']) {
        this.title = params['title'];
      }

      if (params['subtitle']) {
        this.subtitle = params['subtitle'];
      }

      this.buildFormAndSections(row);

      if (this.mode === 'view') {
        this.form.disable({ emitEvent: false });
      }
      if (this.mode === 'auth') {
        this.showAuthBtns = true;
      }
    });
  }

  ngOnInit(): void {}

  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  private buildFormAndSections(row: any): void {
    const group: { [key: string]: any } = {};

    const allFields: GenericField[] = [];

    Object.keys(row || {}).forEach((key) => {
      if (key === 'mode' || key === 'title' || key === 'subtitle') {
        return;
      }

      const value = row[key];

      group[key] = this.fb.control(
        value,

        this.mode === 'edit' ? Validators.required : []
      );

      allFields.push({
        key,

        label: this.labelize(key),
      });
    });

    this.form = this.fb.group(group);

    this.sections = this.buildSections(allFields);
  }

  private labelize(key: string): string {
    return key

      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')

      .replace(/_/g, ' ')

      .replace(/\s+/g, ' ')

      .trim()

      .replace(/^./, (c) => c.toUpperCase());
  }

  private buildSections(fields: GenericField[]): DetailSection[] {
    const titles = [
      'General Details',

      'Application Details',

      'Additional Details',

      'Other Details',

      'More Details',
    ];

    const sections: DetailSection[] = [];

    const chunkSize = 6;

    for (let i = 0; i < fields.length; i += chunkSize) {
      const chunk = fields.slice(i, i + chunkSize);

      if (!chunk.length) continue;

      const title =
        titles[sections.length] || `Details Group ${sections.length + 1}`;

      sections.push({
        title,

        fields: chunk,
      });
    }

    return sections;
  }

  onExit(): void {
    this.location.back();
  }

  onApprove() {
    this.isLoading = true;
    this.apiService
      .sendData(APPROVE_MO_FD, {
        loginId: this.sessionService.getLoginId(),
        userName: this.sessionService.getUsername(),
        fdId: this.originalRow?.id,
        userId: this.sessionService.getUserId(),
      })
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.showToast('success', 'Success', 'FD Approved Successfully');
            // this.router.navigate(['/content/processed-by-bank']);
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  onReject() {
    this.isLoading = true;
    this.apiService
      .sendData(REJECT_MO_FD, {
        loginId: this.sessionService.getLoginId(),
        userName: this.sessionService.getUsername(),
        fdId: this.originalRow?.id,
        userId: this.sessionService.getUserId(),
        
      })
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.showToast('success', 'Success', 'FD Rejected');
            // this.router.navigate(['/content/pending-at-client']);
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
}
