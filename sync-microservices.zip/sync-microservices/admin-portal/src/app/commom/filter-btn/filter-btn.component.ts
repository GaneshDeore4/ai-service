import {
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  OnInit,
  Output,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../service/apiService/api.service';
import { GET_ALL_CATEGORY } from '../../constants/api_endpoints';

export interface CategoryFilterEntity {
  categoryId?: number;
  categoryName?: string;
  status?: string; // ✅ ADD THIS
}

@Component({
  selector: 'app-filter-btn',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './filter-btn.component.html',
  styleUrls: ['./filter-btn.component.css'],
})
export class FilterBtnComponent implements OnInit {
  @Output() categorySelected = new EventEmitter<CategoryFilterEntity>();
  showDropdown = false;
  categoryList: CategoryFilterEntity[] = [];
  statuses = ['All', 'PENDING APPROVAL', 'APPROVED', 'RETURNED'];

  selectedCategory: CategoryFilterEntity = { categoryName: 'All' };
  selectedStatus: string = 'All';

  constructor(private apiService: ApiService, private elementRef: ElementRef) { }

  ngOnInit() {
    this.getCategoryList();
  }

  getCategoryList() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.categoryList = res.payload.content;
            this.categoryList.unshift({ categoryId: -1, categoryName: 'All' });
          }
        },
      });
  }

  toggle(event: MouseEvent) {
    event.stopPropagation();
    this.showDropdown = !this.showDropdown;
  }

  selectCategory(category: CategoryFilterEntity) {
    console.log('Selected category:', category);
    this.categorySelected.emit(category);
    this.showDropdown = false;
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.showDropdown = false;
    }
  }
}
