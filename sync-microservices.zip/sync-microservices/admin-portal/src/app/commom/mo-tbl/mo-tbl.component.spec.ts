import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoTblComponent } from './mo-tbl.component';

describe('MoTblComponent', () => {
  let component: MoTblComponent;
  let fixture: ComponentFixture<MoTblComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MoTblComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MoTblComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
