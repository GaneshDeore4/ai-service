import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
export type Column = { id: string; label: string; visible: boolean };

interface ViewPair {
  label1: string;
  value1: any;
  label2?: string;
  value2?: any;
}

interface EditPair {
  key1: string;
  label1: string;
  key2?: string;
  label2?: string;
}

type ToastType = 'success' | 'error' | 'info' | 'warning';
type ActionId =
  | 'Approve'
  | 'details'
  | 'generateRemittanceLetter'
  | 'correspondence'
  | 'disposal'
  | 'view'
  | 'edit'
  | 'delete'
  | 'userAudit'
  | 'amend'
  | 'requestSettlement'
  | 'cancel';
export type ActionContext =
  | 'disposalInstructions'
  | 'processedByBank'
  | 'rejected'
  | 'live'
  | 'draft'
  | 'pendingApproval'
  | 'pendingAtBank'
  | 'recentlyUpdated'
  | 'frequentlyUsed'
  | 'closed'
  | 'all';
export type TableScope = 'inward' | 'outward';

interface AuditCard {
  label: string;
  name: string;
  datetime: string;
}
@Component({
  selector: 'app-mo-tbl',
  imports: [CommonModule, FormsModule],
  templateUrl: './mo-tbl.component.html',
  styleUrl: './mo-tbl.component.css'
})
export class MoTblComponent {
  @Input() data: any[] = [];
  @Input() columns: Column[] | null = null;
  @Input() actionContext: ActionContext = 'all';
  @Input() tableScope: TableScope = 'inward';

  @Output() rowDeleted = new EventEmitter<any>();
  @Output() rowEdited = new EventEmitter<any>();
  @Output() rowView = new EventEmitter<any>();
  @Output() rowDetails = new EventEmitter<any>();
  @Output() rowGenerateRemittanceLetter = new EventEmitter<any>();
  @Output() rowCorrespondence = new EventEmitter<any>();
  @Output() rowDisposal = new EventEmitter<any>();
  @Output() rowUserAudit = new EventEmitter<any>();
  @Output() rowAmend = new EventEmitter<any>();
  @Output() rowApprove = new EventEmitter<any>();
  @Output() rowRequestSettlement = new EventEmitter<any>();
  @Output() rowCancel = new EventEmitter<any>();
  @Input() selectionMode: 'none' | 'single' = 'none';
  @Output() rowSelected = new EventEmitter<any>();

  defaultColumns: Column[] = [
    // { id: 'channelRef', label: 'Channel Reference', visible: true },
    // { id: 'customerRef', label: 'Customer Reference', visible: true },
    // { id: 'bankRef', label: 'Bank Reference', visible: true },
    // { id: 'status', label: 'Status', visible: true },
    // { id: 'issueDate', label: 'Issue Date', visible: true },
    // { id: 'applicantName', label: 'Applicant Name', visible: true },
    // { id: 'currency', label: 'Currency', visible: true },
    // { id: 'amount', label: 'Amount', visible: true },
    // { id: 'outstandingAmount', label: 'Outstanding Amount', visible: true },
  ];
  searchQuery = '';
  downloadDropdownOpen = false;
  showColumnsModal = false;
  modalColumns: Column[] = [];
  draggingIndex: number | null = null;
  rowsPerPageOptions = [5, 10, 25, 50];
  rowsPerPage = 10;
  currentPage = 1;
  removingRows = new Set<string>();
  removalAnimationMs = 600;
  confirmVisible = false;
  pendingDeleteKey: string | null = null;
  pendingDeleteLabel: string | null = null;
  pendingDeleteRow: any = null;
  toastVisible = false;
  toastHiding = false;
  toastMessage = '';
  toastTitle = '';
  toastType: ToastType = 'error';
  showViewModal = false;
  viewRowData: any | null = null;
  viewFieldPairs: ViewPair[] = [];
  showEditModal = false;
  editModel: any = null;
  editFieldPairs: EditPair[] = [];
  editingOriginalRow: any = null;
  extraMenuOpenKey: string | null = null;
  globalMoreRow: any | null = null;
  globalMoreTop = 0;
  globalMoreLeft = 0;
  showUserAuditModal = false;
  auditRow: any | null = null;
  auditCards: AuditCard[] = [];

  get activeColumns(): Column[] {
    return this.columns && this.columns.length
      ? this.columns
      : this.defaultColumns;
  }

  get visibleCount(): number {
    return this.activeColumns.filter((c) => c.visible).length;
  }

  getCell(row: any, colId: string): string | number | undefined {
    return row ? row[colId] : undefined;
  }

  get filteredData(): any[] {
    if (!this.searchQuery || !this.searchQuery.trim()) return this.data || [];

    const q = this.searchQuery.toLowerCase().trim();
    const visibleCols = this.activeColumns
      .filter((c) => c.visible)
      .map((c) => c.id);

    return (this.data || []).filter((row) =>
      visibleCols.some((colId) => {
        const v = row[colId];
        return (
          v !== null && v !== undefined && String(v).toLowerCase().includes(q)
        );
      })
    );
  }

  get totalItems(): number {
    return this.filteredData.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.rowsPerPage));
  }

  get pagedData(): any[] {
    if (this.currentPage > this.totalPages) this.currentPage = this.totalPages;
    if (this.currentPage < 1) this.currentPage = 1;

    const start = (this.currentPage - 1) * this.rowsPerPage;
    return this.filteredData.slice(start, start + this.rowsPerPage);
  }

  get startItem(): number {
    if (this.totalItems === 0) return 0;
    return (this.currentPage - 1) * this.rowsPerPage + 1;
  }

  get endItem(): number {
    return Math.min(this.currentPage * this.rowsPerPage, this.totalItems);
  }

  onSearchChange() {
    this.currentPage = 1;
  }

  onRowsPerPageChange(newVal: number) {
    this.rowsPerPage = Number(newVal) || 10;
    this.currentPage = 1;
  }

  setPage(n: number) {
    if (n < 1) n = 1;
    if (n > this.totalPages) n = this.totalPages;
    this.currentPage = n;
  }

  nextPage() {
    this.setPage(this.currentPage + 1);
  }

  prevPage() {
    this.setPage(this.currentPage - 1);
  }

  firstPage() {
    this.setPage(1);
  }

  lastPage() {
    this.setPage(this.totalPages);
  }

  get pageRange(): number[] {
    const total = this.totalPages;
    const current = this.currentPage;
    const window = 5;
    const half = Math.floor(window / 2);

    let start = Math.max(1, current - half);
    let end = Math.min(total, current + half);

    if (end - start + 1 < window) {
      if (start === 1) end = Math.min(total, start + window - 1);
      else if (end === total) start = Math.max(1, end - window + 1);
    }

    const pages: number[] = [];
    for (let i = start; i <= end; i++) pages.push(i);
    return pages;
  }
  openColumnsModal() {
    this.modalColumns = this.activeColumns.map((c) => ({ ...c }));
    this.showColumnsModal = true;
  }

  applyColumnsChanges() {
    if (this.columns && this.columns.length) {
      this.columns = this.modalColumns.map((c) => ({ ...c }));
    } else {
      this.defaultColumns = this.modalColumns.map((c) => ({ ...c }));
    }
    this.showColumnsModal = false;
  }

  cancelColumnsChanges() {
    this.modalColumns = [];
    this.showColumnsModal = false;
  }

  onDragStart(event: DragEvent, index: number) {
    this.draggingIndex = index;
    if (event.dataTransfer) {
      event.dataTransfer.setData('text/plain', String(index));
      event.dataTransfer.effectAllowed = 'move';
    }
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  }

  onDrop(event: DragEvent, dropIndex: number) {
    event.preventDefault();
    const fromIndexStr = event.dataTransfer
      ? event.dataTransfer.getData('text/plain')
      : null;
    const fromIndex = fromIndexStr ? Number(fromIndexStr) : this.draggingIndex;
    if (fromIndex == null || isNaN(fromIndex)) return;
    if (fromIndex === dropIndex) return;

    const cols = [...this.modalColumns];
    const [moved] = cols.splice(fromIndex, 1);
    cols.splice(dropIndex, 0, moved);
    this.modalColumns = cols;
    this.draggingIndex = null;
  }
  toggleDownloadDropdown() {
    this.downloadDropdownOpen = !this.downloadDropdownOpen;
  }

  onDownload(format: 'pdf' | 'excel' | 'csv') {
    this.downloadDropdownOpen = false;
    alert(`Download ${format.toUpperCase()} (demo)`);
  }

  closeViewModal() {
    this.showViewModal = false;
    this.viewRowData = null;
    this.viewFieldPairs = [];
  }

  editRow(row: any) {
    this.rowEdited.emit(row);
  }

  viewRow(row: any) {
    this.rowView.emit(row);
  }

  cancelEdit() {
    this.showEditModal = false;
    this.editModel = null;
    this.editFieldPairs = [];
    this.editingOriginalRow = null;
  }

  saveEdit() {
    if (!this.editModel || !this.data) return;

    this.data = this.data.map((r) =>
      r === this.editingOriginalRow ? { ...this.editModel } : r
    );

    this.rowEdited.emit({
      oldRow: this.editingOriginalRow,
      newRow: { ...this.editModel },
    });

    this.showToast('Row updated', 'success');
    this.cancelEdit();
  }
  getRowKey(row: any): string {
    return (
      row?.channelRef ??
      row?.channelReference ??
      row?.customerRef ??
      JSON.stringify(row)
    ).toString();
  }
  isRemoving(row: any): boolean {
    return this.removingRows.has(this.getRowKey(row));
  }
  requestDelete(row: any) {
    this.pendingDeleteKey = this.getRowKey(row);
    const visibleCols = this.activeColumns.filter((c) => c.visible);
    const firstKey = visibleCols.length ? visibleCols[0].id : null;
    this.pendingDeleteLabel =
      firstKey && row[firstKey] ? row[firstKey] : this.getRowKey(row);
    this.pendingDeleteRow = row;
    this.confirmVisible = true;
  }

  cancelDelete() {
    this.pendingDeleteKey = null;
    this.pendingDeleteLabel = null;
    this.pendingDeleteRow = null;
    this.confirmVisible = false;
  }

  confirmDelete() {
    if (!this.pendingDeleteKey) {
      this.confirmVisible = false;
      return;
    }

    const key = this.pendingDeleteKey;
    const rowToDelete = this.pendingDeleteRow;

    this.pendingDeleteKey = null;
    this.pendingDeleteLabel = null;
    this.pendingDeleteRow = null;
    this.confirmVisible = false;

    this.removingRows.add(key);

    setTimeout(() => {
      this.data = (this.data || []).filter((r) => this.getRowKey(r) !== key);
      this.removingRows.delete(key);

      if (rowToDelete) {
        this.rowDeleted.emit(rowToDelete);
      }

      this.showToast('Deleted', 'error');

      if (this.currentPage > this.totalPages) {
        this.currentPage = this.totalPages;
      }
    }, this.removalAnimationMs);
  }
  showToast(message: string, type: ToastType = 'error', duration = 2000) {
    this.toastMessage = message;
    this.toastType = type;
    this.toastVisible = true;
    this.toastHiding = false;
    if (type === 'error' && message.toLowerCase().includes('deleted')) {
      this.toastTitle = 'Action completed';
    } else if (type === 'success') {
      this.toastTitle = 'Action completed';
    } else if (type === 'warning') {
      this.toastTitle = 'warning';
    }

    setTimeout(() => {
      this.toastHiding = true;
      setTimeout(() => {
        this.toastVisible = false;
        this.toastHiding = false;
      }, 220);
    }, duration);
  }

  deleteRow(row: any) {
    this.requestDelete(row);
  }
  getRowActions(row: any): ActionId[] {
    if (this.tableScope === 'outward') {
      switch (this.actionContext) {
        case 'live':
          return [
            'amend',
            'details',
            'requestSettlement',
            'correspondence',
            'cancel',
            'view',
          ];
        case 'draft':
          return ['edit', 'view', 'details', 'delete'];
        case 'pendingApproval':
          return ['Approve', 'view', 'delete', 'details', 'userAudit'];
          case 'disposalInstructions':
            return ['disposal', 'details'];
        case 'pendingAtBank':
          return ['view', 'details', 'userAudit'];
        case 'rejected':
          return ['view', 'details'];
        case 'recentlyUpdated':
        case 'frequentlyUsed':
        case 'all':
        default:
          return ['edit', 'delete'];
      }
    }
    switch (this.actionContext) {
      case 'live':
        return [
          'details',
          'generateRemittanceLetter',
          'correspondence',
          'view',
        ];
      case 'draft':
        return ['edit', 'view', 'details', 'delete'];
      case 'pendingApproval':
        return ['view', 'details', 'delete', 'userAudit'];
      case 'pendingAtBank':
        return ['view', 'details', 'userAudit'];
      case 'disposalInstructions':
        return ['disposal', 'details'];
      case 'rejected':
        return ['view', 'details'];
      case 'processedByBank':
        return ['view', 'details'];
      case 'recentlyUpdated':
      case 'frequentlyUsed':
      case 'all':
      default:
        return ['edit', 'delete'];
    }
  }

  getActionLabel(action: ActionId): string {
    switch (action) {
      case 'details':
        return 'Details';
      case 'generateRemittanceLetter':
        return 'Generate remittance letter';
      case 'correspondence':
        return 'Correspondence';
      case 'disposal':
        return 'Disposal Instruction';
      case 'Approve':
        return 'Approve';
      case 'view':
        return 'View';
      case 'edit':
        return 'Edit';
      case 'delete':
        return 'Delete';
      case 'userAudit':
        return 'User audit';
      case 'amend':
        return 'Amend';
      case 'requestSettlement':
        return 'Request for settlement';
      case 'cancel':
        return 'Cancel';
      default:
        return action;
    }
  }
  getPrimaryActions(row: any): ActionId[] {
    const actions = this.getRowActions(row);
    return actions.slice(0, 3);
  }
  getExtraActions(row: any): ActionId[] {
    const actions = this.getRowActions(row);
    return actions.slice(3);
  }
  openGlobalMoreMenu(row: any, event: MouseEvent) {
    event.stopPropagation();
    const btn = event.currentTarget as HTMLElement;
    const rect = btn.getBoundingClientRect();
    const menuWidth = 190;

    this.globalMoreRow = row;
    this.globalMoreTop = rect.bottom + 4;
    this.globalMoreLeft = rect.right - menuWidth;

    if (this.globalMoreLeft < 8) this.globalMoreLeft = 8;
  }

  closeGlobalMoreMenu() {
    this.globalMoreRow = null;
  }

  hideToast() {
    this.toastHiding = true;

    setTimeout(() => {
      this.toastVisible = false;
      this.toastHiding = false;
    }, 250);
  }

  onGlobalMoreActionClick(action: ActionId) {
    if (!this.globalMoreRow) return;
    this.onActionClick(action, this.globalMoreRow);
    this.closeGlobalMoreMenu();
  }

  getActionIconClass(action: ActionId): string {
    switch (action) {
      case 'details':
        return 'fa fa-info-circle';
      case 'generateRemittanceLetter':
        return 'fa-regular fa-file';
      case 'correspondence':
        return 'fa fa-envelope';
      case 'disposal':
        return 'fa-solid fa-file-waveform';
      case 'Approve':
        return 'fa-solid fa-check';
      case 'view':
        return 'fa fa-eye';
      case 'edit':
        return 'fa fa-pencil';
      case 'delete':
        return 'fa fa-trash';
      case 'userAudit':
        return 'fa fa-user-circle';
      case 'amend':
        return 'fa fa-edit';
      case 'requestSettlement':
        return 'fa-regular fa-handshake';
      case 'cancel':
        return 'fa fa-times-circle';
      default:
        return 'fa fa-circle';
    }
  }
  openUserAuditModal(row: any) {
    this.auditRow = row;
    const initiatedBy = row?.initiatedBy || 'Rakesh Mehta';
    const initiatedAt = row?.initiatedAt || '01/11/2025 10:15';

    const authorisedBy = row?.authorisedBy || 'Priya Nair';
    const authorisedAt = row?.authorisedAt || '01/11/2025 11:00';

    const releasedBy = row?.releasedBy || 'Amit Khanna';
    const releasedAt = row?.releasedAt || '01/11/2025 11:30';

    this.auditCards = [
      {
        label: 'Initiated',
        name: initiatedBy,
        datetime: initiatedAt,
      },
      {
        label: 'Authorised',
        name: authorisedBy,
        datetime: authorisedAt,
      },
      {
        label: 'Released',
        name: releasedBy,
        datetime: releasedAt,
      },
    ];

    this.showUserAuditModal = true;
  }

  closeUserAuditModal() {
    this.showUserAuditModal = false;
    this.auditRow = null;
    this.auditCards = [];
  }

  onActionClick(action: ActionId, row: any) {
    switch (action) {
      case 'details':
        this.rowDetails.emit(row);
        break;
      case 'generateRemittanceLetter':
        this.rowGenerateRemittanceLetter.emit(row);
        break;
      case 'correspondence':
        this.rowCorrespondence.emit(row);
        break;
      case 'disposal':
        this.rowDisposal.emit(row);
        break;
      case 'view':
        this.viewRow(row);
        break;
      case 'edit':
        this.editRow(row);
        break;
      case 'delete':
        this.requestDelete(row);
        break;
      case 'userAudit':
        this.rowUserAudit.emit(row);
        this.openUserAuditModal(row);
        break;
      case 'amend':
        this.rowAmend.emit(row);
        break;
      case 'Approve':
        this.rowApprove.emit(row);
        break;
      case 'requestSettlement':
        this.rowRequestSettlement.emit(row);
        break;
      case 'cancel':
        this.rowCancel.emit(row);
        break;
    }
    this.extraMenuOpenKey = null;
    this.closeGlobalMoreMenu();
  }
  onRowClick(row: any) {
    if (this.selectionMode !== 'single') return;
    this.rowSelected.emit(row);
  }
}
