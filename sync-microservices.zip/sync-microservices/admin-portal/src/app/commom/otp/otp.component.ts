import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnDestroy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface OTP {
  d1: string;
  d2: string;
  d3: string;
  d4: string;
  d5: string;
  d6: string;
}
@Component({
  selector: 'app-otp',
  template: `
    <div class="modal-overlay" *ngIf="isOpen">
      <div class="modal-container otp-modal">
        <!-- Header -->
        <div class="modal-header">
          <h2>OTP Authentication</h2>
          <span class="close-btn" (click)="closePopup()">×</span>
        </div>

        <!-- Body -->
        <div class="modal-body text-center">
          <p class="subtitle">
            Your One-Time Password (OTP) has been sent to your registered mobile
            number.<br />
            The OTP will expire in {{ timeLeft }} seconds.
          </p>

          <div class="otp-inputs">
            <input
              type="text"
              maxlength="1"
              #i1
              (keyup)="move(i1, i2)"
              [(ngModel)]="enteredOtp.d1"
            />
            <input
              type="text"
              maxlength="1"
              #i2
              (keyup)="move(i2, i3)"
              [(ngModel)]="enteredOtp.d2"
            />
            <input
              type="text"
              maxlength="1"
              #i3
              (keyup)="move(i3, i4)"
              [(ngModel)]="enteredOtp.d3"
            />
            <input
              type="text"
              maxlength="1"
              #i4
              (keyup)="move(i4, i5)"
              [(ngModel)]="enteredOtp.d4"
            />
            <input
              type="text"
              maxlength="1"
              #i5
              (keyup)="move(i5, i6)"
              [(ngModel)]="enteredOtp.d5"
            />
            <input type="text" maxlength="1" #i6 [(ngModel)]="enteredOtp.d6" />
          </div>

          <div class="actions">
            <button class="btn resend" (click)="resend()">Resend OTP</button>
            <button class="btn submit" (click)="verify()">Submit</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .modal-overlay {
      z-index:999;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
      }
      .modal-container {
        width: 520px;
        background: #fff;
        border-radius: 20px;
        padding: 10px 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        position: relative;
      }
      /* Header */
      .modal-header {
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
      }
      .modal-header h2 {
        font-size: 22px;
        font-weight: 700;
      }
      .close-btn {
        position: absolute;
        right: 0;
        top: 0;
        font-size: 22px;
        cursor: pointer;
        color: #444;
      }
      /* Subtitle */
      .subtitle {
        margin-top: 15px;
        font-size: 14px;
        color: #777;
        line-height: 1.6;
      }
      /* OTP Inputs */
      .otp-inputs {
        display: flex;
        justify-content: center;
        gap: 15px;
        margin: 25px 0;
      }
      .otp-inputs input {
        width: 45px;
        height: 45px;
        border: 1px solid #ccc;
        border-radius: 10px;
        text-align: center;
        font-size: 16px;
        font-weight: 600;
        outline: none;
        transition: 0.2s;
      }
      .otp-inputs input:focus {
        border-color: #ff4d4f;
        box-shadow: 0 0 5px rgba(255, 77, 79, 0.4);
      }
      /* Buttons */
      .actions {
        display: flex;
        justify-content: center;
        gap: 20px;
      }
      .btn {
        width: 160px;
        padding: 8px;
        border-radius: 8px;
        font-weight: 600;
        border: none;
        cursor: pointer;
        font-size: 14px;
      }
      /* Red buttons like image */
      .resend,
      .submit {
        background: #e74c3c;
        color: white;
      }
      .resend:hover,
      .submit:hover {
        background: #d84333;
      }
    `,
  ],
  standalone: true,
  imports: [CommonModule, FormsModule],
})
export class OtpComponent implements OnInit, OnDestroy {
  @Input() isOpen = false;
  @Output() onClose = new EventEmitter<void>();
  @Output() onVerify = new EventEmitter<string>();

  enteredOtp: OTP = {
    d1: '',
    d2: '',
    d3: '',
    d4: '',
    d5: '',
    d6: '',
  };
  timeLeft = 100;
  showSuccess = false;
  showResendSuccess = false;
  private timer: any;

  get dashOffset() {
    return 283 - (283 * this.timeLeft) / 100;
  }

  ngOnInit() {
    this.startTimer();
  }

  startTimer() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => {
      if (this.timeLeft > 0) this.timeLeft--;
      else clearInterval(this.timer);
    }, 1000);
  }

  move(curr: any, next: any) {
    if (curr.value.length === 1) next.focus();
  }

  resend() {
    this.timeLeft = 100;
    this.showResendSuccess = true;
    this.startTimer();
    setTimeout(() => (this.showResendSuccess = false), 3000);
  }

  verify() {
    this.showSuccess = true;
    if (
      !this.enteredOtp.d1 ||
      !this.enteredOtp.d2 ||
      !this.enteredOtp.d3 ||
      !this.enteredOtp.d4 ||
      !this.enteredOtp.d5 ||
      !this.enteredOtp.d6
    )
      return;
    //concat add elements in enteredOtp
    let otp: string = `${this.enteredOtp.d1}${this.enteredOtp.d2}${this.enteredOtp.d3}${this.enteredOtp.d4}${this.enteredOtp.d5}${this.enteredOtp.d6}`;
    this.onVerify.emit(otp);
  }

  done() {
    this.showSuccess = false;
    this.isOpen = false;
    this.onVerify.emit('');
  }

  closePopup() {
    this.isOpen = false;
    this.timeLeft = 100;
    this.showSuccess = false;
    this.showResendSuccess = false;
    this.enteredOtp = {
      d1: '',
      d2: '',
      d3: '',
      d4: '',
      d5: '',
      d6: '',
    };
    this.onClose.emit();
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
  }
}
