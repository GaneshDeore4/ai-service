import {NgFor, NgIf, NgStyle } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-table',
  imports: [NgFor, NgStyle, NgIf],
  templateUrl: './table.component.html',
  styleUrl: './table.component.css'
})
export class TableComponent implements OnChanges {

  @Input()
  showIcon:Boolean=false;

  @Input()
  title!: string;

  @Input()
  headers!: string[];

  @Input()
  rows: any = [];

  @Input()
  columnWidths!: string[];

  @Input()
  actions!: string[];

  @Input()
  enableCheckboxes: boolean = false;

  @Input()
  selectedIndices: number[] = [];

  @Output()
  selectedIndicesChange = new EventEmitter<number[]>();

  @Output()
  eyeClicked = new EventEmitter<{ row: any; index: number }>();

  @Output()
  editClicked = new EventEmitter<{ row: any; index: number }>();

  @Output()
  deleteClicked = new EventEmitter<number>();

  @Output()
  replicateClicked = new EventEmitter<{ row: any}>();

  @Output()
  viewUsers = new EventEmitter<{ row: any}>();

  constructor() {
    this.updatePagination();
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['rows']) {
      this.paginatedData = [];
      this.total = this.rows.length;
      this.updatePagination();
    }
  }
  // pagination logic start
  currentPage: number = 1;
  pageSize: number = 10;
  total = this.rows.length;
  start: number = 1;
  end: number = 10;
  paginatedData: any[] = [];
  updatePagination() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.paginatedData = this.rows.slice(startIndex, endIndex);
    this.start = ((this.currentPage - 1) * this.pageSize) + 1;
    this.end = Math.min(this.currentPage * this.pageSize, this.rows.length);
  }

  nextPage() {
    if ((this.currentPage * this.pageSize) < this.rows.length) {
      this.currentPage++;
      this.updatePagination();
    }
  }

  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePagination();
    }
  }

  startPage() {
    this.currentPage = 1;
    this.updatePagination();
  }

  endPage() {
    this.currentPage = Math.ceil(this.rows.length / this.pageSize);
    this.updatePagination();
  }
  // pagination logic end

  onEyeClicked(row:any, index:number) {
    this.eyeClicked.emit({ row, index });
  }
  onEditClicked(row:any, index:number) {
    this.editClicked.emit({ row, index });
  }
    onDeleteClicked(index:number) {
    this.deleteClicked.emit(index);
  }
    onReplicateClicked(row:any) {
    this.replicateClicked.emit(row);
  }
      onViewUsersClick(row:any) {
    this.viewUsers.emit(row);
  }
  actionIncluded(action: string): boolean {
    return this.actions && this.actions.includes(action);
  }

  // Checkbox logic
  isAllSelected(): boolean {
    return this.selectedIndices.length === this.rows.length && this.rows.length > 0;
  }

  toggleAll() {
    if (this.isAllSelected()) {
      this.selectedIndices = [];
    } else {
      this.selectedIndices = Array.from({ length: this.rows.length }, (_, i) => i);
    }
    this.selectedIndicesChange.emit(this.selectedIndices);
  }

  isSelected(globalIndex: number): boolean {
    return this.selectedIndices.includes(globalIndex);
  }

  toggleRow(globalIndex: number) {
    const index = this.selectedIndices.indexOf(globalIndex);
    if (index > -1) {
      this.selectedIndices.splice(index, 1);
    } else {
      this.selectedIndices.push(globalIndex);
    }
    this.selectedIndicesChange.emit([...this.selectedIndices]);
  }

}
