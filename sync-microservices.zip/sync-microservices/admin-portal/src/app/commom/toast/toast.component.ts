import { NgClass, NgIf } from '@angular/common';
import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-toast',
  imports: [NgIf, NgClass],
  templateUrl: './toast.component.html',
  styleUrl: './toast.component.css'
})
export class ToastComponent {
  @Input() toastType: string = '';
  @Input() toastTitle: string = '';
  @Input() toastMessage: string = '';
  @Input() toastVisible: boolean = false;
  @Input() toastHiding: boolean = true;

  @Output() close = new EventEmitter<void>();


  onClose() {
    this.close.emit();
    this.toastHiding = true;
  }

}

