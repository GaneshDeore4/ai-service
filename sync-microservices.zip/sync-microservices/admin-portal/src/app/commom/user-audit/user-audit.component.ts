import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OnChanges } from '@angular/core';
export type AuditStatus = 'completed' | 'current' | 'pending' | 'inprogress';

export interface AuditCard {
  label: string;
  name: string;
  datetime?: string; // optional for pending
  status: AuditStatus;
  group?: string;
}

interface GroupedAuditCard {
  label: string;
  group: string;
  users: AuditCard[];
  status: AuditStatus;
}

@Component({
  selector: 'app-user-audit',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-audit.component.html',
  styleUrls: ['./user-audit.component.css'],
})
export class UserAuditComponent implements OnChanges {
  @Input() visible = false;
  @Input() channelRef: string | null = null;
  @Input() auditCards: AuditCard[] = [];

  @Output() close = new EventEmitter<void>();

  groupedCards: GroupedAuditCard[] = [];
  ngOnChanges() {
    this.buildGroupedCards();
  }
  private buildGroupedCards() {
    const grouped: GroupedAuditCard[] = [];
    const groupMap = new Map<string, GroupedAuditCard>();
    for (const card of this.auditCards) {
      if (!card.group) {
        grouped.push({
          label: card.label,
          group: '',
          users: [card],
          status: card.status,
        });
        continue;
      }
      if (groupMap.has(card.group)) {
        const group = groupMap.get(card.group)!;
        group.users.push(card);
        if (card.status === 'current') {
          group.status = 'current';
        }
      } else {
        const newGroup: GroupedAuditCard = {
          label: card.label,
          group: card.group,
          users: [card],
          status: card.status,
        };
        groupMap.set(card.group, newGroup);
        grouped.push(newGroup);
      }
    }
    this.groupedCards = grouped;
  }

  closeModal() {
    this.close.emit();
  }
  // get currentStepIndex(): number {
  //   const current = this.auditCards.findIndex((c) => c.status === 'current');

  //   // If everything is completed → full progress
  //   if (current === -1) {
  //     return this.auditCards.length;
  //   }

  //   // Convert to 1-based index for CSS
  //   return current + 1;
  // }
  get currentStepIndex(): number {
    const i = this.auditCards.findIndex((s) => s.status === 'inprogress');
    return i === -1 ? this.auditCards.length : i;
  }

  

  // get currentStep(): number {
  //   const index = this.auditCards.findIndex(
  //     (c) => c.status === 'inprogress'
  //   );
  //   return index === -1 ? this.auditCards.length - 1 : index;
  // }

  get currentStep(): number {
    const index = this.groupedCards.findIndex(
      g => g.status === 'inprogress' || g.status === 'current'
    );
  
    return index === -1 ? this.groupedCards.length - 1 : index;
  }
  
}
