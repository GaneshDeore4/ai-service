import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShippingGuaranteeComponent } from './shipping-guarantee.component';

describe('ShippingGuaranteeComponent', () => {
  let component: ShippingGuaranteeComponent;
  let fixture: ComponentFixture<ShippingGuaranteeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShippingGuaranteeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShippingGuaranteeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
