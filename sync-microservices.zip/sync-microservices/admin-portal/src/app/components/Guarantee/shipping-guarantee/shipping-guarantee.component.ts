import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { TableComponent } from '../../table/table.component';

import { TabsComponent } from '../../tabs/tabs.component';

import { HeaderComponent } from '../../header/header.component';

type TabName =
  | 'Draft'
  | 'Action'
  | 'Pending Approval'
  | 'Pending at Bank'
  | 'Live'
  | 'Rejected'
  | 'Closed';

interface ShippingGuarantee {
  channelRef: string;

  customerRef: string;

  bankRef: string;

  issueDate: string;

  event: string;

  applicationName: string;

  beneficiary: string;

  currency: string;

  amount: string;

  outstandingAmount: string;

  expiryType: string;

  expiryDate: string;

  inputUser: string;

  controlUser: string;

  tab: TabName;
}

@Component({
  selector: 'app-shipping-guarantee',

  standalone: true,

  imports: [TableComponent, HeaderComponent, TabsComponent],

  templateUrl: './shipping-guarantee.component.html',

  styleUrls: ['../../../common css/inward-letter-of-credit.component.css'],
})
export class ShippingGuaranteeComponent implements OnInit {
  constructor(private router: Router) {}

  activeTab: TabName = 'Draft';

  tabs: { name: TabName; count: number }[] = [];

  columns = [
    { id: 'channelRef', label: 'Channel Reference', visible: true },

    { id: 'customerRef', label: 'Customer Reference', visible: false },

    { id: 'bankRef', label: 'Bank Reference', visible: true },

    { id: 'issueDate', label: 'Issue Date', visible: true },

    { id: 'event', label: 'Event', visible: true },

    { id: 'applicationName', label: 'Application Name', visible: false },

    { id: 'beneficiary', label: 'Beneficiary', visible: true },

    { id: 'currency', label: 'Currency', visible: true },

    { id: 'amount', label: 'Amount', visible: true },
    { id: 'amount', label: 'Amount', visible: true },

    {
      id: 'outstandingAmount',

      label: 'Outstanding Amount',

      visible: true,
    },

    { id: 'expiryType', label: 'Expiry Type', visible: false },

    { id: 'expiryDate', label: 'Expiry Date', visible: true },

    { id: 'inputUser', label: 'Input User', visible: false },

    { id: 'controlUser', label: 'Control User', visible: false },
  ];

  guarantees: ShippingGuarantee[] = [
    {
      channelRef: 'CH-25110000100001',

      customerRef: 'CUST-9001',

      bankRef: 'SG-BK-01',

      issueDate: '02/11/2025',

      event: 'New Shipping Guarantee Drafted',

      applicationName: 'Harbor Import Finance',

      beneficiary: 'Blue Ocean Lines',

      currency: 'USD',

      amount: '$45,000.00',

      outstandingAmount: '$45,000.00',

      expiryType: 'Fixed',

      expiryDate: '31/12/2025',

      inputUser: 'user_sg01',

      controlUser: 'ctrl_sg01',

      tab: 'Draft',
    },

    {
      channelRef: 'CH-25100000100002',

      customerRef: 'CUST-9002',

      bankRef: 'SG-BK-02',

      issueDate: '29/10/2025',

      event: 'Document Pending',

      applicationName: 'Steel Import Program',

      beneficiary: 'Port Authority Dubai',

      currency: 'INR',

      amount: '₹5,50,000',

      outstandingAmount: '₹5,50,000',

      expiryType: 'Open ended',

      expiryDate: '-',

      inputUser: 'user_sg02',

      controlUser: 'ctrl_sg02',

      tab: 'Draft',
    },

    {
      channelRef: 'CH-25090000100003',

      customerRef: 'CUST-9003',

      bankRef: 'SG-BK-03',

      issueDate: '15/09/2025',

      event: 'Awaiting Customer Approval',

      applicationName: 'Textile Imports',

      beneficiary: 'Royal Shipping Co.',

      currency: 'EUR',

      amount: '€19,500',

      outstandingAmount: '€19,500',

      expiryType: 'Fixed',

      expiryDate: '15/03/2026',

      inputUser: 'user_sg03',

      controlUser: 'ctrl_sg03',

      tab: 'Draft',
    },

    {
      channelRef: 'CH-25080000100004',

      customerRef: 'CUST-9004',

      bankRef: 'SG-BK-04',

      issueDate: '05/08/2025',

      event: 'Pending Invoice Upload',

      applicationName: 'Agro Import Scheme',

      beneficiary: 'Evergreen Shipping',

      currency: 'USD',

      amount: '$8,750.00',

      outstandingAmount: '$8,750.00',

      expiryType: 'Fixed',

      expiryDate: '05/02/2026',

      inputUser: 'user_sg04',

      controlUser: 'ctrl_sg04',

      tab: 'Draft',
    },

    {
      channelRef: 'CH-25070000100005',

      customerRef: 'CUST-9005',

      bankRef: 'SG-BK-05',

      issueDate: '22/07/2025',

      event: 'Customer Clarification Required',

      applicationName: 'Machinery Import',

      beneficiary: 'Baltic Freight Lines',

      currency: 'GBP',

      amount: '£12,200',

      outstandingAmount: '£12,200',

      expiryType: 'Fixed',

      expiryDate: '22/01/2026',

      inputUser: 'user_sg05',

      controlUser: 'ctrl_sg05',

      tab: 'Action',
    },

    {
      channelRef: 'CH-25060000100006',

      customerRef: 'CUST-9006',

      bankRef: 'SG-BK-06',

      issueDate: '11/06/2025',

      event: 'LC Amendment Mismatch',

      applicationName: 'Electronics Credit Line',

      beneficiary: 'Pacific Star Shipping',

      currency: 'USD',

      amount: '$27,000.00',

      outstandingAmount: '$27,000.00',

      expiryType: 'Fixed',

      expiryDate: '11/12/2025',

      inputUser: 'user_sg06',

      controlUser: 'ctrl_sg06',

      tab: 'Action',
    },

    {
      channelRef: 'CH-25050000100007',

      customerRef: 'CUST-9007',

      bankRef: 'SG-BK-07',

      issueDate: '09/05/2025',

      event: 'Approval Pending – RM',

      applicationName: 'Global Logistics Finance',

      beneficiary: 'Sunrise Shipping Lines',

      currency: 'INR',

      amount: '₹8,20,000',

      outstandingAmount: '₹8,20,000',

      expiryType: 'Fixed',

      expiryDate: '09/11/2025',

      inputUser: 'user_sg07',

      controlUser: 'ctrl_sg07',

      tab: 'Pending Approval',
    },

    {
      channelRef: 'CH-25040000100008',

      customerRef: 'CUST-9008',

      bankRef: 'SG-BK-08',

      issueDate: '27/04/2025',

      event: 'Approval Pending – Compliance',

      applicationName: 'Auto Parts Import Facility',

      beneficiary: 'Everest Marine Lines',

      currency: 'EUR',

      amount: '€34,100',

      outstandingAmount: '€34,100',

      expiryType: 'Fixed',

      expiryDate: '27/10/2025',

      inputUser: 'user_sg08',

      controlUser: 'ctrl_sg08',

      tab: 'Pending Approval',
    },

    {
      channelRef: 'CH-25030000100009',

      customerRef: 'CUST-9009',

      bankRef: 'SG-BK-09',

      issueDate: '06/03/2025',

      event: 'Awaiting Bank Release',

      applicationName: 'Chemical Import Finance',

      beneficiary: 'Swift Cargo Lines',

      currency: 'USD',

      amount: '$12,500.00',

      outstandingAmount: '$12,500.00',

      expiryType: 'Fixed',

      expiryDate: '06/09/2025',

      inputUser: 'user_sg09',

      controlUser: 'ctrl_sg09',

      tab: 'Pending at Bank',
    },

    {
      channelRef: 'CH-25020000100010',

      customerRef: 'CUST-9010',

      bankRef: 'SG-BK-10',

      issueDate: '14/02/2025',

      event: 'Bank Review In Progress',

      applicationName: 'Steel Import LC',

      beneficiary: 'Trinity Cargo Services',

      currency: 'INR',

      amount: '₹13,75,000',

      outstandingAmount: '₹13,75,000',

      expiryType: 'Open ended',

      expiryDate: '-',

      inputUser: 'user_sg10',

      controlUser: 'ctrl_sg10',

      tab: 'Pending at Bank',
    },

    {
      channelRef: 'CH-25010000100011',

      customerRef: 'CUST-9011',

      bankRef: 'SG-BK-11',

      issueDate: '25/01/2025',

      event: 'Guarantee Live',

      applicationName: 'Textile Imports Live',

      beneficiary: 'Vantage Shipping Co.',

      currency: 'USD',

      amount: '$5,900.00',

      outstandingAmount: '$3,000.00',

      expiryType: 'Fixed',

      expiryDate: '25/07/2025',

      inputUser: 'user_sg11',

      controlUser: 'ctrl_sg11',

      tab: 'Live',
    },

    {
      channelRef: 'CH-24120000100012',

      customerRef: 'CUST-9012',

      bankRef: 'SG-BK-12',

      issueDate: '12/12/2024',

      event: 'Guarantee Closed',

      applicationName: 'Maritime Import Line',

      beneficiary: 'Global Maritime Services',

      currency: 'GBP',

      amount: '£18,500',

      outstandingAmount: '£0.00',

      expiryType: 'Fixed',

      expiryDate: '12/06/2025',

      inputUser: 'user_sg12',

      controlUser: 'ctrl_sg12',

      tab: 'Closed',
    },

    {
      channelRef: 'CH-24110000100013',

      customerRef: 'CUST-9013',

      bankRef: 'SG-BK-13',

      issueDate: '03/11/2024',

      event: 'Rejected by Bank – Docs',

      applicationName: 'Commodity Import Facility',

      beneficiary: 'Regal Commodities',

      currency: 'USD',

      amount: '$23,400.00',

      outstandingAmount: '$23,400.00',

      expiryType: 'Fixed',

      expiryDate: '03/05/2025',

      inputUser: 'user_sg13',

      controlUser: 'ctrl_sg13',

      tab: 'Rejected',
    },
  ];

  ngOnInit(): void {
    this.buildTabsFromData();
  }

  private buildTabsFromData(): void {
    const tabNames: TabName[] = [
      'Draft',

      'Action',

      'Pending Approval',

      'Pending at Bank',

      'Live',

      'Closed',

      'Rejected',
    ];

    const counts: Record<TabName, number> = {
      Draft: 0,

      Action: 0,

      'Pending Approval': 0,

      'Pending at Bank': 0,

      Live: 0,

      Closed: 0,

      Rejected: 0,
    };

    for (const row of this.guarantees) {
      counts[row.tab] = (counts[row.tab] || 0) + 1;
    }

    this.tabs = tabNames.map((name) => ({
      name,

      count: counts[name],
    }));

    if (!this.tabs.find((t) => t.name === this.activeTab)) {
      this.activeTab = 'Draft';
    }
  }

  get filteredGuarantees(): ShippingGuarantee[] {
    return this.guarantees.filter((g) => g.tab === this.activeTab);
  }

  // onRowEdited(event: any) {
  //   const { oldRow, newRow } = event;

  //   const index = this.guarantees.indexOf(oldRow);

  //   if (index !== -1) {
  //     this.guarantees[index] = newRow;
  //   }
  // }

  onRowView(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'view',

        title: 'Record Details',

        subtitle: 'View record in read-only mode',
      },
    });
  }

  onRowEdit(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'edit',

        title: 'Edit Record',

        subtitle: 'Update the selected record',
      },
    });
  }

  onRowDeleted(row: ShippingGuarantee) {
    this.guarantees = this.guarantees.filter((g) => g !== row);

    this.buildTabsFromData();

    const currentTabCount = this.tabs.find(
      (t) => t.name === this.activeTab
    )?.count;

    if (!currentTabCount) {
      const firstNonEmpty = this.tabs.find((t) => t.count > 0);

      if (firstNonEmpty) {
        this.activeTab = firstNonEmpty.name;
      }
    }
  }

  requestShippingGuarantee() {
    this.router.navigate(['/guarantee/shipping-guarantee/request']);
  }

  openTemplates() {
    this.router.navigate(['/guarantee/shipping-guarantee/templates']);
  }
}
