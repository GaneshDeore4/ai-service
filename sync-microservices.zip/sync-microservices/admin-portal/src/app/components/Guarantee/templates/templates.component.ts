import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { TableComponent } from '../../table/table.component';

import { HeaderComponent } from '../../header/header.component';

import { TabsComponent } from '../../tabs/tabs.component';

interface Template {
  templateName: string;

  entityName: string;

  description: string;

  usageCount: number;

  tab: 'Recently Updated' | 'Frequently Used'; // logical group
}

@Component({
  selector: 'app-templates',

  standalone: true,

  imports: [TableComponent, HeaderComponent, TabsComponent],

  templateUrl: './templates.component.html',

  styleUrls: ['../../../common css/inward-letter-of-credit.component.css'],
})
export class TemplatesComponent implements OnInit {
  constructor(private router: Router) {}

  activeTab: 'Recently Updated' | 'Frequently Used' | 'All' =
    'Recently Updated';

  // tabs will be generated from data in ngOnInit

  tabs: { name: string; count: number }[] = [];

  columns = [
    { id: 'templateName', label: 'Template Name', visible: true },

    {
      id: 'entityName',

      label: 'Entity / Application Name',

      visible: true,
    },

    { id: 'description', label: 'Description', visible: true },

    { id: 'usageCount', label: 'Usage Count', visible: true },
  ];

  // Expanded templates dataset with tab grouping

  data: Template[] = [
    {
      templateName: 'Outward LC Request - Standard',

      entityName: 'Trade Finance',

      description: 'Used for standard outward LC request creation.',

      usageCount: 24,

      tab: 'Frequently Used',
    },

    {
      templateName: 'Inward LC Notification',

      entityName: 'Operations',

      description: 'Notifies clients about incoming LC documents.',

      usageCount: 38,

      tab: 'Frequently Used',
    },

    {
      templateName: 'LC Amendment Request',

      entityName: 'Corporate Banking',

      description: 'For requesting LC amendments and revisions.',

      usageCount: 12,

      tab: 'Recently Updated',
    },

    {
      templateName: 'Export LC Advice',

      entityName: 'Export Department',

      description: 'Advising clients about export LC confirmations.',

      usageCount: 16,

      tab: 'Recently Updated',
    },

    {
      templateName: 'Reimbursement Claim Format',

      entityName: 'Reimbursement Unit',

      description: 'Used to request reimbursement from banks.',

      usageCount: 8,

      tab: 'Recently Updated',
    },

    {
      templateName: 'LC Closure Confirmation',

      entityName: 'Trade Settlements',

      description: 'Confirms closure and settlement of LC.',

      usageCount: 10,

      tab: 'Recently Updated',
    },

    // extra templates to "increase the data"

    {
      templateName: 'Standby LC Issuance',

      entityName: 'Trade Finance',

      description: 'Template for issuing standby letters of credit.',

      usageCount: 30,

      tab: 'Frequently Used',
    },

    {
      templateName: 'Performance LC Template',

      entityName: 'Corporate Banking',

      description: 'Standard performance LC format for large corporates.',

      usageCount: 19,

      tab: 'Frequently Used',
    },

    {
      templateName: 'Import LC Margin Call',

      entityName: 'Risk Management',

      description: 'Used to notify clients of required LC margins.',

      usageCount: 7,

      tab: 'Recently Updated',
    },

    {
      templateName: 'LC Discrepancy Notice',

      entityName: 'Operations',

      description: 'Advises customers of discrepancies in LC documents.',

      usageCount: 14,

      tab: 'Recently Updated',
    },

    {
      templateName: 'Transferable LC Advice',

      entityName: 'Trade Finance',

      description: 'Used where LC is transferable to secondary beneficiaries.',

      usageCount: 21,

      tab: 'Frequently Used',
    },

    {
      templateName: 'Back-to-Back LC Template',

      entityName: 'Structured Trade',

      description: 'Base template for back-to-back LC arrangements.',

      usageCount: 5,

      tab: 'Recently Updated',
    },
  ];

  ngOnInit(): void {
    this.buildTabsFromData();
  }

  private buildTabsFromData() {
    const counts: Record<'Recently Updated' | 'Frequently Used', number> = {
      'Recently Updated': 0,

      'Frequently Used': 0,
    };

    for (const row of this.data) {
      counts[row.tab] = (counts[row.tab] || 0) + 1;
    }

    const total = this.data.length;

    this.tabs = [
      { name: 'Recently Updated', count: counts['Recently Updated'] },

      { name: 'Frequently Used', count: counts['Frequently Used'] },

      { name: 'All', count: total },
    ];

    if (!this.tabs.find((t) => t.name === this.activeTab) && this.tabs.length) {
      this.activeTab = this.tabs[0].name as any;
    }
  }

  get filteredData(): Template[] {
    if (this.activeTab === 'All') {
      return this.data;
    }

    return this.data.filter((row) => row.tab === this.activeTab);
  }

  createTemplate() {
    this.router.navigate(['lc/outward/templates/create-template']);

    console.log('Create Template clicked');
  }

  // onRowEdited(event: any) {
  //   const { oldRow, newRow } = event;

  //   const idx = this.data.indexOf(oldRow);

  //   if (idx !== -1) {
  //     this.data[idx] = newRow;

  //     this.buildTabsFromData();
  //   }
  // }

  onRowView(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'view',

        title: 'Record Details',

        subtitle: 'View record in read-only mode',
      },
    });
  }

  onRowEdit(row: any) {
    this.router.navigate(['/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'edit',

        title: 'Edit Record',

        subtitle: 'Update the selected record',
      },
    });
  }

  onRowDeleted(row: Template) {
    this.data = this.data.filter((r) => r !== row);

    this.buildTabsFromData();

    if (this.activeTab !== 'All') {
      const stillHasData = this.data.some((r) => r.tab === this.activeTab);

      if (!stillHasData) {
        const firstNonEmpty = this.tabs.find(
          (t) => t.name !== 'All' && t.count > 0
        );

        this.activeTab = (firstNonEmpty?.name || 'All') as any;
      }
    }
  }
}
