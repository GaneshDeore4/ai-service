import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../commom/page-title/page-title.component";
import { TableComponent } from "../../../commom/table/table.component";
import { FormsModule } from '@angular/forms';
import { SessionService } from '../../../service/sessionService/session.service';
import { Router } from '@angular/router';
import { DataTransferService } from '../../../service/dataTransferService/data-transfer.service';

@Component({
  selector: 'app-pending-entities',
  imports: [PageTitleComponent, TableComponent, FormsModule],
  templateUrl: './pending-entities.component.html',
  styleUrl: './pending-entities.component.css'
})
export class PendingEntitiesComponent {

  constructor(private router: Router, private dataTranseferService:DataTransferService) {
  }

  searchEntityid = '';
  seachEntityName = '';
  entityHeaders = ['Entity ID', 'Entity Name', 'Legal ID No', 'Status', 'Maker User', 'Action'];
  entityData: any[] = [
    {
      "personalCheckbox": false,
      "selectedLegalIDType": "ROB",
      "Legal ID No": "LID12345",
      "country": "India",
      "Entity ID": "ENT001",
      "Entity Name": "ABC Corporation",
      "chargeAccAddress": "123 Finance Street",
      "streetName": "Finance Street",
      "town": "Mumbai",
      "countrySubdiv": "Maharashtra",
      "postCode": "400001",
      "alternateAdd": "Alternate Address",
      "countryCode": "IN",
      "BEISWIFT": "ABCINBBXXX",
      "email": "abc@example.com",
      "contactNumber": "+91-9876543210",
      "contactPerson": "John Doe",
      "authOwnTran": true,
      "bulkAuthLimitPay": false,
      "autoFrData": true,
      "checkFileHash": false,
      "checkDupFile": true,
      "checkDupCr": false,
      "FileUploadEncMethod": "AES256",
      "nonAmendableFileType": "PDF",
      "mergeDeleteAllowed": true,
      "amendableFileTypes": "CSV, XLSX",
      "Status": "Active",
      "Maker User": "AdminUser",
      "remarks": "Test entity data",
      "addEntityRoles": true
    },
    {
      "personalCheckbox": true,
      "selectedLegalIDType": "ROS",
      "Legal ID No": "LID67890",
      "country": "USA",
      "Entity ID": "ENT002",
      "Entity Name": "XYZ Ltd",
      "chargeAccAddress": "456 Wall Street",
      "streetName": "Wall Street",
      "town": "New York",
      "countrySubdiv": "NY",
      "postCode": "10005",
      "alternateAdd": "Alternate Address 2",
      "countryCode": "US",
      "BEISWIFT": "XYZUSBBXXX",
      "email": "xyz@example.com",
      "contactNumber": "+1-1234567890",
      "contactPerson": "Jane Smith",
      "authOwnTran": false,
      "bulkAuthLimitPay": true,
      "autoFrData": false,
      "checkFileHash": true,
      "checkDupFile": false,
      "checkDupCr": true,
      "FileUploadEncMethod": "RSA2048",
      "nonAmendableFileType": "DOCX",
      "mergeDeleteAllowed": false,
      "amendableFileTypes": "TXT, XLS",
      "Status": "Inactive",
      "Maker User": "SystemUser",
      "remarks": "Second entity data",
      "addEntityRoles": false
    }
  ];
  ogEntityData = [...this.entityData];
  searchEntity(): void {
    const filtered = this.ogEntityData.filter(item => {
      const matchsearchEntityid = this.searchEntityid
        ? item['Entity ID']?.toLowerCase().includes(this.searchEntityid.toLowerCase())
        : true;

      const matchseachEntityName = this.seachEntityName
        ? item['Entity Name']?.toLowerCase().includes(this.seachEntityName.toLowerCase())
        : true;

      return matchsearchEntityid && matchseachEntityName;
    });

    // ✅ Update reference so child detects change
    this.entityData = [...filtered];
  }
  viewEntityf(row:any,index:number){
    this.dataTranseferService.setData(row)
    this.router.navigate(['/content/cm-entities'],{queryParams:{'action':'checker'}});
  }
}
