import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

import { ActivatedRoute, Router } from '@angular/router';

import { Location } from '@angular/common';

interface GenericField {
  key: string;

  label: string;
}

interface DetailSection {
  title: string;

  fields: GenericField[];
}

@Component({
  selector: 'app-row-details',

  standalone: true,

  imports: [CommonModule, ReactiveFormsModule],

  templateUrl: './detail.component.html',

  styleUrls: ['./detail.component.css'], // keep using this css file
})
export class RowDetailsComponent implements OnInit {
  form!: FormGroup;

  sections: DetailSection[] = []; // 🔹 grouped fields with headings

  mode: 'view' | 'edit' = 'view';

  title = 'Details';

  subtitle = 'View or edit details.';

  originalRow: any;

  constructor(
    private fb: FormBuilder,

    private route: ActivatedRoute,

    private router: Router,
    private location: Location
  ) {
    this.route.queryParams.subscribe((params) => {
      let row: any | null = null;

      // Try to read "row" as JSON from query params

      if (params['row']) {
        try {
          row = JSON.parse(params['row']);

          console.table(row);
        } catch {
          row = params['row'];
        }
      }

      // Fallback: if row is not an object, use all params except known keys

      if (!row || typeof row !== 'object') {
        row = { ...params };

        delete row['mode'];

        delete row['title'];

        delete row['subtitle'];
      }

      this.originalRow = row;

      this.mode = params['mode'] === 'edit' ? 'edit' : 'view';

      if (params['title']) {
        this.title = params['title'];
      }

      if (params['subtitle']) {
        this.subtitle = params['subtitle'];
      }

      this.buildFormAndSections(row);

      // 🔒 Disable all fields in view mode

      if (this.mode === 'view') {
        this.form.disable({ emitEvent: false });
      }
    });
  }

  ngOnInit(): void {}

  /**

* Build a flat form and then group fields into generic sections

*/

  private buildFormAndSections(row: any): void {
    const group: { [key: string]: any } = {};

    const allFields: GenericField[] = [];

    Object.keys(row || {}).forEach((key) => {
      // skip special keys if they somehow leak in

      if (key === 'mode' || key === 'title' || key === 'subtitle') {
        return;
      }

      const value = row[key];

      group[key] = this.fb.control(
        value,

        this.mode === 'edit' ? Validators.required : []
      );

      allFields.push({
        key,

        label: this.labelize(key), // 🔹 human-friendly label
      });
    });

    this.form = this.fb.group(group);

    // 🔹 Now group fields into sections

    this.sections = this.buildSections(allFields);
  }

  /**

* Turn "channelRef" -> "Channel Ref", "bank_ref" -> "Bank ref"

*/

  private labelize(key: string): string {
    return key

      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')

      .replace(/_/g, ' ')

      .replace(/\s+/g, ' ')

      .trim()

      .replace(/^./, (c) => c.toUpperCase());
  }

  /**

* Create generic sections with headings and assign fields into them.

* Works for ANY data shape.

*/

  private buildSections(fields: GenericField[]): DetailSection[] {
    const titles = [
      'General Details',

      'Application Details',

      'Additional Details',

      'Other Details',

      'More Details',
    ];

    const sections: DetailSection[] = [];

    // how many fields per section (so each has multiple rows of 2 cols)

    const chunkSize = 6; // 6 fields ≈ 3 rows of 2

    for (let i = 0; i < fields.length; i += chunkSize) {
      const chunk = fields.slice(i, i + chunkSize);

      if (!chunk.length) continue;

      const title =
        titles[sections.length] || `Details Group ${sections.length + 1}`;

      sections.push({
        title,

        fields: chunk,
      });
    }

    return sections;
  }

  onExit(): void {
    this.location.back();
  }

  onSave(): void {
    if (this.mode === 'view') return;

    if (this.form.invalid) {
      this.form.markAllAsTouched();

      return;
    }

    const updated = {
      ...this.originalRow,

      ...this.form.getRawValue(),
    };

    console.log('Updated row:', updated);

    this.router

      .navigate(['/lc/outward'], {
        state: { updatedRow: updated },
      })

      .catch(() => {});
  }
}
