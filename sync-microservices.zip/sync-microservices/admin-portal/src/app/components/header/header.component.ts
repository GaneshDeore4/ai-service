import { NgIf } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header',

  standalone: true,

  imports:[NgIf],

  templateUrl: './header.component.html',

  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {
  @Input() title = '';

  @Input() subtitle?: string; // optional
}
