import { SharedService } from './../../service/sharedService/shared.service';
import { Component } from '@angular/core';
import { HeaderComponent } from "../../commom/header/header.component";
import { AsideComponent } from "../../commom/aside/aside.component";
import { FooterComponent } from "../../commom/footer/footer.component";
import { RouterOutlet } from '@angular/router';
import { NgClass } from '@angular/common';
import { SessionExpiryComponent } from '../session-expiry/session-expiry.component';

@Component({
  selector: 'app-layout',
  imports: [HeaderComponent, AsideComponent, RouterOutlet, NgClass, SessionExpiryComponent],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css'
})
export class LayoutComponent {
  asideFull: Boolean = true;
  constructor(private sharedService:SharedService){
    this.sharedService.asideFull$.subscribe(value => this.asideFull = value);
  }
}
