import { Component, OnInit, OnDestroy } from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

import { Router } from '@angular/router';

import { Subscription } from 'rxjs';

import { HeaderComponent } from '../../header/header.component';

interface TemplateSection {
  id: string;

  title: string;

  attention?: boolean;

  disabled?: boolean;
}

@Component({
  selector: 'app-create-template',

  standalone: true,

  imports: [CommonModule, ReactiveFormsModule, HeaderComponent],

  templateUrl: './create-template.component.html',

  styleUrls: ['../../../common css/request-loc.component.css'],
})
export class CreateTemplateComponent implements OnInit, OnDestroy {
  sections: TemplateSection[] = [
    { id: 'basic', title: 'Basic Details' },

    { id: 'layout', title: 'Layout & Fields' },

    { id: 'rules', title: 'Validation & Rules' },

    { id: 'visibility', title: 'Visibility & Sharing' },
  ];

  readonly windowSize = 5;

  visibleStart = 0;

  form: FormGroup;

  activeIndex = 0;

  private subs: Subscription[] = [];

  constructor(private fb: FormBuilder, private router: Router) {
    this.form = this.fb.group({
      basic: this.fb.group({
        templateName: ['', Validators.required],

        entityName: ['', Validators.required],

        description: [''],
      }),

      layout: this.fb.group({
        baseProduct: ['', Validators.required],

        numberOfSections: [1, [Validators.required, Validators.min(1)]],

        hasAmountField: [true],

        hasCurrencyField: [true],
      }),

      rules: this.fb.group({
        requireApproval: [false],

        maxAmount: [''],

        enforceLimits: [false],
      }),

      visibility: this.fb.group({
        isGlobal: [false],

        allowedRoles: [''],

        isActive: [true],
      }),
    });
  }

  ngOnInit(): void {


    for (const s of this.sections) {
      const sub = this.getFormGroup(s.id).statusChanges?.subscribe(() => {
        if (this.getFormGroup(s.id).valid) {
          s.attention = false;
        }
      });

      if (sub) this.subs.push(sub);
    }

    this.ensureActiveVisible();
  }

  ngOnDestroy(): void {
    this.subs.forEach((s) => s.unsubscribe());
  }


  get visibleSections(): TemplateSection[] {
    return this.sections.slice(
      this.visibleStart,
      this.visibleStart + this.windowSize
    );
  }

  get hiddenLeftCount(): number {
    return this.visibleStart;
  }

  get hiddenRightCount(): number {
    return Math.max(
      0,
      this.sections.length - (this.visibleStart + this.windowSize)
    );
  }

  private ensureActiveVisible() {
    if (this.activeIndex < this.visibleStart) {
      this.visibleStart = this.activeIndex;
    } else if (this.activeIndex >= this.visibleStart + this.windowSize) {
      this.visibleStart = this.activeIndex - this.windowSize + 1;
    }

    if (this.visibleStart < 0) this.visibleStart = 0;

    const maxStart = Math.max(0, this.sections.length - this.windowSize);

    if (this.visibleStart > maxStart) {
      this.visibleStart = maxStart;
    }
  }

  scrollTabs(direction: 'left' | 'right') {
    const step = this.windowSize;

    const maxStart = Math.max(0, this.sections.length - this.windowSize);

    if (direction === 'left') {
      this.visibleStart = Math.max(0, this.visibleStart - step);
    } else {
      this.visibleStart = Math.min(maxStart, this.visibleStart + step);
    }
  }


  getFormGroup(id: string): FormGroup {
    return this.form.get(id) as FormGroup;
  }

  get currentSection(): TemplateSection {
    return this.sections[this.activeIndex] ?? this.sections[0];
  }


  isCompleted(i: number): boolean {
    const id = this.sections[i]?.id;

    if (!id) return false;

    const group = this.getFormGroup(id);

    return !!group && group.valid;
  }

  isAttention(i: number): boolean {
    return !!this.sections[i]?.attention;
  }


  get progressPercent(): number {
    const done = this.sections.filter(
      (s) => this.getFormGroup(s.id).valid
    ).length;

    return Math.round((done / this.sections.length) * 100);
  }


  selectSection(index: number) {
    if (index === this.activeIndex) return;


    this.sections.forEach((s, idx) => {
      if (idx < index && !this.getFormGroup(s.id).valid) {
        s.attention = true;
      }
    });

    this.activeIndex = index;

    this.ensureActiveVisible();
  }

  nextSection() {
    const current = this.currentSection;

    const group = this.getFormGroup(current.id);

    group.markAllAsTouched();

    if (group.valid) {
      if (this.activeIndex < this.sections.length - 1) {
        this.sections[this.activeIndex + 1].attention = false;

        this.activeIndex++;

        this.ensureActiveVisible();
      }
    } else {
      this.sections[this.activeIndex].attention = true;

      this.sections.forEach((s, idx) => {
        if (idx < this.activeIndex && !this.getFormGroup(s.id).valid) {
          s.attention = true;
        }
      });
    }
  }

  prevSection() {
    if (this.activeIndex > 0) {
      this.activeIndex--;

      this.ensureActiveVisible();
    }
  }

  exit() {
    this.router.navigate(['lc/outward/templates']);
  }

  importTemplate() {
    this.form.markAllAsTouched();

    if (this.form.valid) {
      const payload = this.form.value;

      console.log('IMPORT TEMPLATE PAYLOAD', payload);
    } else {

      this.sections.forEach((s) => {
        s.attention = !this.getFormGroup(s.id).valid;
      });

      const idx = this.sections.findIndex(
        (s) => !this.getFormGroup(s.id).valid
      );

      if (idx >= 0) {
        this.activeIndex = idx;

        this.ensureActiveVisible();
      }
    }
  }
}
