import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InwardLetterOfCreditComponent } from './inward-letter-of-credit.component';

describe('InwardLetterOfCreditComponent', () => {
  let component: InwardLetterOfCreditComponent;
  let fixture: ComponentFixture<InwardLetterOfCreditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InwardLetterOfCreditComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InwardLetterOfCreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
