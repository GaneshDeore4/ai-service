import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PageTitleComponent } from '../../../commom/page-title/page-title.component';
import { MIDDLE_OFFICE_COUNT } from '../../../constants/api_endpoints';
import { ApiService } from '../../../service/apiService/api.service';
import { LoaderComponent } from '../../../commom/loader/loader.component';

@Component({
  selector: 'app-mo-landing',
  imports: [
    PageTitleComponent,
    CommonModule,
    FormsModule,
    RouterModule,
    LoaderComponent,
  ],
  templateUrl: './mo-landing.component.html',
  styleUrl: './mo-landing.component.css',
})
export class MoLandingComponent implements OnInit {
  searchProduct: string = '';
  products: any[] = [];
  isLoading = false;
  ngOnInit() {
    console.log('In OnInit');
    this.getMiddleOfficeCounts();
  }
  getMiddleOfficeCounts() {
    this.isLoading = true;
    console.log('Inside The fuction');
    this.apiService.getData(MIDDLE_OFFICE_COUNT, {}).subscribe({
      next: (res: any) => {
          const data = res.payload ?? res ?? [];
          this.products = data.map((item: any) => ({
            name: item.product,
            pendingAtBank: item.pendingAtBank ?? 0,
            pendingAtClient: item.pendingAtClient ?? 0,
            processedByBank: item.processedByBank ?? 0,
            processedByClient: item.processedByClient ?? 0,
          }));
      },
      error: (err) => {
        console.error('MO Count Error:', err);
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  constructor(private apiService: ApiService) {}

  get filteredProducts() {
    if (!this.searchProduct) return this.products;
    const filtered = this.products.filter((p) =>
      p.name.toLowerCase().includes(this.searchProduct.toLowerCase())
    );
    // 👉 If nothing matches, return original instead of empty
    return filtered.length ? filtered : this.products;
  }
}
