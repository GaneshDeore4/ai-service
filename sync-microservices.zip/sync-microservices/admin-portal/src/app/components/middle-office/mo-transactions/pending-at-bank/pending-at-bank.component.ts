import { map } from 'rxjs';
import { IN_APPROVAL, MID_OFFICE_REJECTED, PENDING_AT_MID_OFFICE, REJECTED } from './../../../../constants/Constants';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { Location, NgClass, NgIf } from '@angular/common';
import { ApiService } from '../../../../service/apiService/api.service';
import { GET_FD_BY_STATUS } from '../../../../constants/api_endpoints';
import { PAGE_SIZE } from '../../../../constants/Constants';
import { INSPECT_MAX_BYTES } from 'node:buffer';
import { MoFdTableData } from '../../../../model/MoFd';
import { TblComponent } from "../../../../commom/tbl/tbl.component";


@Component({
  selector: 'app-pending-at-bank',
  imports: [PageTitleComponent, NgIf, NgClass, TblComponent],
  templateUrl: './pending-at-bank.component.html',
  styleUrl: './pending-at-bank.component.css'
})
export class PendingAtBankComponent {
  constructor(private router: Router,private apiService: ApiService, private location: Location) {}
  toastVisible = false;
  toastHiding = false;
  toastMessage = '';
  toastTitle = '';
  toastType: 'success' | 'error' | 'info' | 'warning' = 'success';
  isLoading=false;
  actionList=['view'];

  headers:{ key: string; value: string }[]=[
    { key: 'accountNumber', value: 'Account Number'},
    { key: 'currency', value: 'Currency'},
    { key: 'amount', value: 'Amount'},
    { key: 'tenure', value: 'Tenure'},
    { key: 'interestRate', value: 'Interest Rate'},
    { key: 'maturityAmount', value: 'Maturity Amount'},
    { key: 'maturityDate', value: 'Maturity Date'},
    { key: 'Action', value: 'Action'}
  ]


  ngOnInit(): void {
    this.getTableData();
    }

   toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

 pageNumber: number = 1;
    pageSize: number = PAGE_SIZE;
    totalElements: number = 0;
    tableId: string = 'MOPendingAtBankTable';
    data:MoFdTableData[]=[];
    ogData:MoFdTableData[]=[];

    toMoLangingPage(){
      this.location.back();
    }

  getTableData() {
    this.isLoading = true;
    const payload={
      "status":[PENDING_AT_MID_OFFICE]
    }
    this.apiService
      .sendData(
        GET_FD_BY_STATUS +'?page=' +(this.pageNumber - 1) +'&size=' +this.pageSize,
        payload
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.ogData = res['payload']['content'].map((ele:MoFdTableData)=>{
              return {
                ...ele,
                tenure: ele.tenureYears + ' Years ' + ele.tenureMonths + ' Months ' + ele.tenureDays + ' Days'
              };
            });
            this.data = [...this.ogData];
            if (res.payload) {
              this.totalElements = res.payload.totalElements;
            }
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }


  viewProfilef(row: any, index: number) {
    this.router.navigate(['/content/details'], {
      queryParams: {
        row: JSON.stringify(row),
        mode: 'view',
        title: 'FD Details',
        subtitle: 'View record in read-only mode',
      },
    });
  }

    onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'MOPendingAtBankTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    }
  }

    auditFnc(row: any) {
    //   const url = `${GET_ALL_TEMP_COMPANY_BY_ID}?companyId=${row.companyId}`;
  
    //   this.apiService.getData(url, {}).subscribe({
    //     next: (res: any) => {
    //       console.log('Company Audit Response:', res);
  
    //       if (res?.status === 'SUCCESS' && res?.payload) {
    //         this.auditCards = this.createAuditCards(res.payload);
    //       }
  
    //       this.isAuditOpen = true;
    //     },
    //     error: (err) => {
    //       console.error('Audit API Error:', err);
    //     },
    //   });
     }
}
