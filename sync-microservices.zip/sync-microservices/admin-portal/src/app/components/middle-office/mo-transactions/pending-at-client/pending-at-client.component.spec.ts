import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingAtClientComponent } from './pending-at-client.component';

describe('PendingAtClientComponent', () => {
  let component: PendingAtClientComponent;
  let fixture: ComponentFixture<PendingAtClientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PendingAtClientComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PendingAtClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
