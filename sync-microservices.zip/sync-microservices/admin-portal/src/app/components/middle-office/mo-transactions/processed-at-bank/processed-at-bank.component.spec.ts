import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessedAtBankComponent } from './processed-at-bank.component';

describe('ProcessedAtBankComponent', () => {
  let component: ProcessedAtBankComponent;
  let fixture: ComponentFixture<ProcessedAtBankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProcessedAtBankComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProcessedAtBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
