import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { MoTblComponent } from "../../../../commom/mo-tbl/mo-tbl.component";
import { NgClass, NgIf } from '@angular/common';
interface InwardRemittanceDisposal {
  channelRef: string;
  customerRef: string;
  bankRef: string;
  beneficiaryName: string;
  remitterName: string;
  currency: string;
  amount: string;
  lastModifiedDate: string;
  status: string;
  transactionRefNo: string;
  remittanceDate: string;
  tab: string;
}
@Component({
  selector: 'app-tran-inquiry',
  imports: [PageTitleComponent, MoTblComponent,NgIf,NgClass],
  templateUrl: './tran-inquiry.component.html',
  styleUrl: './tran-inquiry.component.css'
})
export class TranInquiryComponent {
  constructor(private router: Router) {}
  toastVisible = false;

  toastHiding = false;

  toastMessage = '';
  toastTitle = '';
  toastType: 'success' | 'error' | 'info' | 'warning' = 'success';

  activeTab = 'Disposal Instructions';

  selectedContext:
    | 'disposalInstructions'
    | 'draft'
    | 'pendingApproval'
    | 'pendingAtBank'
    | 'processedByBank'
    | 'rejected'
    | 'all' = 'disposalInstructions';

  columns = [
    { id: 'channelRef', label: 'Channel Reference', visible: true },
    { id: 'customerRef', label: 'Customer Reference', visible: false },
    { id: 'bankRef', label: 'Bank Reference', visible: true },
    { id: 'beneficiaryName', label: 'Beneficiary Name', visible: true },
    { id: 'remitterName', label: 'Remitter Name', visible: true },
    { id: 'currency', label: 'Currency', visible: false },
    { id: 'amount', label: 'Amount', visible: true },
    { id: 'lastModifiedDate', label: 'Last Modified Date', visible: false },
    { id: 'status', label: 'Status', visible: true },
    { id: 'transactionRefNo', label: 'Transaction Ref No', visible: false },
    { id: 'remittanceDate', label: 'Date of Remittance', visible: true },
  ];

  tabs: { name: string; count: number }[] = [];

  disposals: InwardRemittanceDisposal[] = [
    // ---------------- DISPOSAL INSTRUCTIONS ----------------
    {
      channelRef: 'RD250100001',
      customerRef: 'CUST-201',
      bankRef: 'BB-101',
      beneficiaryName: 'ABC Exports',
      remitterName: 'XYZ Imports',
      currency: 'USD',
      amount: '$5,000.00',
      lastModifiedDate: '12/01/2025',
      status: 'Pending Credit',
      transactionRefNo: 'TXN-9001',
      remittanceDate: '11/01/2025',
      tab: 'Disposal Instructions',
    },
    {
      channelRef: 'RD250100002',
      customerRef: 'CUST-202',
      bankRef: 'BB-102',
      beneficiaryName: 'Delta Traders',
      remitterName: 'Omega Corp',
      currency: 'INR',
      amount: '₹1,80,000',
      lastModifiedDate: '13/01/2025',
      status: 'Pending Credit',
      transactionRefNo: 'TXN-9002',
      remittanceDate: '12/01/2025',
      tab: 'Disposal Instructions',
    },
  
    // ---------------- DRAFT ----------------
    {
      channelRef: 'RD250100003',
      customerRef: 'CUST-203',
      bankRef: 'BB-103',
      beneficiaryName: 'Sigma Ltd',
      remitterName: 'Lambda LLC',
      currency: 'USD',
      amount: '$2,200.00',
      lastModifiedDate: '10/01/2025',
      status: 'Draft',
      transactionRefNo: 'TXN-9003',
      remittanceDate: '09/01/2025',
      tab: 'Draft',
    },
    {
      channelRef: 'RD250100004',
      customerRef: 'CUST-204',
      bankRef: 'BB-104',
      beneficiaryName: 'Nova Exim',
      remitterName: 'Zenith Corp',
      currency: 'EUR',
      amount: '€3,400.00',
      lastModifiedDate: '09/01/2025',
      status: 'Draft',
      transactionRefNo: 'TXN-9004',
      remittanceDate: '08/01/2025',
      tab: 'Draft',
    },
  
    // ---------------- PENDING APPROVAL ----------------
    {
      channelRef: 'RD250100005',
      customerRef: 'CUST-205',
      bankRef: 'BB-105',
      beneficiaryName: 'Apex Traders',
      remitterName: 'Vertex Ltd',
      currency: 'USD',
      amount: '$7,500.00',
      lastModifiedDate: '08/01/2025',
      status: 'Pending',
      transactionRefNo: 'TXN-9005',
      remittanceDate: '07/01/2025',
      tab: 'Pending Approval',
    },
    {
      channelRef: 'RD250100006',
      customerRef: 'CUST-206',
      bankRef: 'BB-106',
      beneficiaryName: 'Orbit Global',
      remitterName: 'Stellar Inc',
      currency: 'INR',
      amount: '₹3,20,000',
      lastModifiedDate: '08/01/2025',
      status: 'Pending',
      transactionRefNo: 'TXN-9006',
      remittanceDate: '07/01/2025',
      tab: 'Pending Approval',
    },
  
    // ---------------- PENDING AT BANK ----------------
    {
      channelRef: 'RD250100007',
      customerRef: 'CUST-207',
      bankRef: 'BB-107',
      beneficiaryName: 'Horizon Exports',
      remitterName: 'Atlas Imports',
      currency: 'USD',
      amount: '$4,800.00',
      lastModifiedDate: '06/01/2025',
      status: 'Sent to Bank',
      transactionRefNo: 'TXN-9007',
      remittanceDate: '05/01/2025',
      tab: 'Pending at Bank',
    },
    {
      channelRef: 'RD250100008',
      customerRef: 'CUST-208',
      bankRef: 'BB-108',
      beneficiaryName: 'Polaris Ltd',
      remitterName: 'North Star LLC',
      currency: 'GBP',
      amount: '£2,100',
      lastModifiedDate: '06/01/2025',
      status: 'Sent to Bank',
      transactionRefNo: 'TXN-9008',
      remittanceDate: '05/01/2025',
      tab: 'Pending at Bank',
    },
  
    // ---------------- PROCESSED BY BANK ----------------
    {
      channelRef: 'RD250100009',
      customerRef: 'CUST-209',
      bankRef: 'BB-109',
      beneficiaryName: 'Prime Logistics',
      remitterName: 'Core Systems',
      currency: 'USD',
      amount: '$9,000.00',
      lastModifiedDate: '04/01/2025',
      status: 'Processed',
      transactionRefNo: 'TXN-9009',
      remittanceDate: '03/01/2025',
      tab: 'Processed by Bank',
    },
    {
      channelRef: 'RD250100010',
      customerRef: 'CUST-210',
      bankRef: 'BB-110',
      beneficiaryName: 'Fusion Trade',
      remitterName: 'Matrix Corp',
      currency: 'INR',
      amount: '₹6,50,000',
      lastModifiedDate: '04/01/2025',
      status: 'Processed',
      transactionRefNo: 'TXN-9010',
      remittanceDate: '03/01/2025',
      tab: 'Processed by Bank',
    },
  
    // ---------------- REJECTED ----------------
    {
      channelRef: 'RD250100011',
      customerRef: 'CUST-211',
      bankRef: 'BB-111',
      beneficiaryName: 'Zen Exports',
      remitterName: 'Alpha Traders',
      currency: 'USD',
      amount: '$1,200.00',
      lastModifiedDate: '02/01/2025',
      status: 'Rejected',
      transactionRefNo: 'TXN-9011',
      remittanceDate: '01/01/2025',
      tab: 'Rejected',
    },
    {
      channelRef: 'RD250100012',
      customerRef: 'CUST-212',
      bankRef: 'BB-112',
      beneficiaryName: 'Vertex Exim',
      remitterName: 'Pioneer Ltd',
      currency: 'EUR',
      amount: '€950.00',
      lastModifiedDate: '02/01/2025',
      status: 'Rejected',
      transactionRefNo: 'TXN-9012',
      remittanceDate: '01/01/2025',
      tab: 'Rejected',
    },
  ];

  ngOnInit(): void {
    let lcCreated = false;
    const nav = this.router.getCurrentNavigation();

    if (
      nav &&
      nav.extras &&
      nav.extras.state &&
      nav.extras.state['lcCreated']
    ) {
      lcCreated = true;
    }
    const state = window.history.state;

    if (!lcCreated && state && state['lcCreated']) {
      lcCreated = true;
    }

    if (lcCreated) {
      this.showToast('LC created successfully', 'success');

      const cleaned = { ...window.history.state };

      delete cleaned['lcCreated'];

      window.history.replaceState(cleaned, '');
    }

    this.generateTabs();
  }

  showToast(
    message: string,

    type: 'success' | 'error' | 'warning' | 'info',

    duration = 2000
  ) {
    this.toastMessage = message;

    this.toastType = type;

    this.toastVisible = true;

    this.toastHiding = false;
    if (type === 'error' && message.includes('deleted')) {
      this.toastTitle = 'Action completed';
    } else if (type === 'success') {
      this.toastTitle = 'Action completed';
    } else if (type === 'warning') {
      this.toastTitle = 'warning';
    }

    setTimeout(() => {
      this.toastHiding = true;

      setTimeout(() => {
        this.toastVisible = false;

        this.toastHiding = false;
      }, 220);
    }, duration);
  }

  hideToast() {
    this.toastHiding = true;

    setTimeout(() => {
      this.toastVisible = false;
      this.toastHiding = false;
    }, 250);
  }

  onTabChange(activeTab: string) {
    const key = activeTab.toLowerCase().replace(/\s+/g, '');

    switch (key) {
      case 'disposalinstructions':
        this.selectedContext = 'disposalInstructions';
        break;
      case 'draft':
        this.selectedContext = 'draft';
        break;
      case 'pendingapproval':
        this.selectedContext = 'pendingApproval';
        break;
      case 'pendingatbank':
        this.selectedContext = 'pendingAtBank';
        break;
      case 'processedbybank':
        this.selectedContext = 'processedByBank';
        break;
      case 'rejected':
        this.selectedContext = 'rejected';
        break;
      default:
        this.selectedContext = 'all';
    }
  }

  private generateTabs() {
    const counts: Record<string, number> = {};

    for (const row of this.disposals) {
      if (!row.tab) continue;
      counts[row.tab] = (counts[row.tab] || 0) + 1;
    }

    const order = [
      'Disposal Instructions',
      'Draft',
      'Pending Approval',
      'Pending at Bank',
      'Processed by Bank',
      'Rejected',
    ];

    this.tabs = order
      .filter((name) => counts[name] !== undefined)
      .map((name) => ({ name, count: counts[name] }));

    if (!this.tabs.find((t) => t.name === this.activeTab) && this.tabs.length) {
      this.activeTab = this.tabs[0].name;
    }
  }

  get filteredDisposals(): InwardRemittanceDisposal[] {
    if (!this.activeTab) return this.disposals;
    return this.disposals.filter((row) => row.tab === this.activeTab);
  }

  onRowView(row: any) {
    this.router.navigate(['/content/details'], {
      queryParams: {
        row: JSON.stringify(row),
        mode: 'view',
        title: 'Remittance Disposal Details',
        subtitle: 'View record in read-only mode',
      },
    });
  }

  onRowEdit(row: any) {
    this.router.navigate(['/content/details'], {
      queryParams: {
        row: JSON.stringify(row),
        mode: 'edit',
        title: 'Edit Remittance Disposal',
        subtitle: 'Update the selected record',
      },
    });
  }

  onRowDeleted(row: InwardRemittanceDisposal) {
    this.disposals = this.disposals.filter((r) => r !== row);
    this.generateTabs();
  }
  onRowDetails(row: any) {
    this.router.navigate(['/content/details'], {
      queryParams: {
        row: JSON.stringify(row),

        mode: 'view',

        title: 'Record Details',

        subtitle: 'View record in read-only mode',
      },
    });
  }
  onRowCorrespondence(row: any) {
    this.router.navigate(['/content/foreignRemittance/inward/disposal-instructions'], { state: { data: row } });
  }
}
