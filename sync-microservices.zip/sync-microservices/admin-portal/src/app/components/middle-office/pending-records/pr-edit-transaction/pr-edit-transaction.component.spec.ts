import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrEditTransactionComponent } from './pr-edit-transaction.component';

describe('PrEditTransactionComponent', () => {
  let component: PrEditTransactionComponent;
  let fixture: ComponentFixture<PrEditTransactionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PrEditTransactionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrEditTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
