import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgClass, NgFor, NgIf, NgStyle } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../../commom/table/table.component";
import { PopupComponent } from "../../../../commom/popup/popup.component";

@Component({
  selector: 'app-pr-edit-transaction',
  imports: [PageTitleComponent, NgIf, NgFor, FormsModule, TableComponent, NgClass, NgStyle, PopupComponent],
  templateUrl: './pr-edit-transaction.component.html',
  styleUrl: './pr-edit-transaction.component.css'
})
export class PrEditTransactionComponent {

  // main page vars
  searchChannelRef = '';
  searchCompany = '';
  searchProductList = ['Export Collection', 'Import Colloection', 'Invoice'];
  selectedProduct = '';
  searchUsername = '';

  header = ['Channel Reference', 'Company', 'Currency', 'Amount', 'Username', 'Input Date', 'Action'];
  data: any[] = [
    {
      "Channel Reference": "CH001",
      "Company": "Big4U",
      "Currency": "USD",
      "Amount": "100000",
      "Username": "Abhinay",
      "Input Date": "2023-01-01",
    },
    {
      "Channel Reference": "CH002",
      "Company": "Big4UP",
      "Currency": "INR",
      "Amount": "100000",
      "Username": "Abhinay",
      "Input Date": "2023-01-02",
    },
  ];
  userHeaders = ['Full Name', 'Date and Time', 'Description'];
  userData: any[] = [
    {
      "Full Name": "Dummy User1",
      "Date and Time": "Feb 4, 2025 12:07:05 PM IST",
      "Description": "Dummy description"
    },
    {
      "Full Name": "Dummy User2",
      "Date and Time": "Feb 4, 2025 12:07:05 PM IST",
      "Description": "Dummy description2"
    }
  ];

  ogData = [...this.data];
  editingIndex: number = -1;
  editingRow: any = null;

  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchChannelRef = this.searchChannelRef
        ? item['Channel Reference']?.toLowerCase().includes(this.searchChannelRef.toLowerCase())
        : true;

      const matchCompany = this.searchCompany
        ? item['Company']?.toLowerCase().includes(this.searchCompany.toLowerCase())
        : true;

      const matchProduct = this.selectedProduct
        ? item['Product'] === this.selectedProduct
        : true;

      const matchUsername = this.searchUsername
        ? item['Username'] === this.searchUsername
        : true;


      return matchChannelRef && matchCompany && matchProduct && matchUsername;
    });

    // ✅ Update reference so child detects change
    this.data = [...filtered];
  }

  editTransactionf(row: any, index: any) {
    this.editingIndex = index;
    this.editingRow = row;
    this.showTranRecord = true;
  }
  showUserPopup = false;
  closeUserPopup() {
    this.showUserPopup = false;
  }
  viewUsers(row: any){
    this.showUserPopup=true;
  }

  //fill transaction page
  showTranRecord = false;

  companyName='Test domain';
  productCode='Secure Email';
  channelRef='SE25010000095851';
  tranType='New';
  releaseDate='Thursday, January 30, 2025 2:15:29 PM IST';

  transactionStatusList=['Approve','Rejected'];
  selectedTranStatus='';
  bankRef='SE25010000095851';
  comment='Test';

  bank='IndusInd Bank Limited-2';
  applicationDate='22/12/2025';
  bankName='IndusInd Bank LTD';
  fileType = 'Cheque Description';

  freeFormatMsg='';

  // start of charge vars
  showChargePopup=false;
  chargeHeaders=['Charge','Description','currency','Amount','Status','Settlement Date', 'Action'];
  chargeData:any=[];
  chargeList=['Commission','Issuance Fee', 'Others'];
  selectedCharge='';
  chargeDescription='';
  chargeCurrency='';
  chargeAmount='';
  chargeStatusList=['Settled','Waived','Deferred','Other'];
  selectedChargeStatus='';  
  chargeSettlementDate='';

  chargeError=false;
  chargeDescriptionError=false;
  chargeCurrencyError=false;
  chargeAmountError=false;
  chargeStatusError=false;
  chargeSettlementDateError=false;
  editingChargeIndex = -1;

  showChargePopupf(){
    this.showChargePopup=true;
  }


  validateCharge(): boolean {
    let isValid = true;
    this.chargeError = false;
    this.chargeDescriptionError = false;
    this.chargeCurrencyError = false;
    this.chargeAmountError = false;
    this.chargeStatusError = false;
    this.chargeSettlementDateError=false;

    if (!this.selectedCharge) {
      this.chargeError = true;
      isValid = false;
    }
    if (!this.chargeDescription.trim()) {
      this.chargeDescriptionError = true;
      isValid = false;
    }
    if (!this.chargeCurrency.trim()) {
      this.chargeCurrencyError = true;
      isValid = false;
    }
    if (!this.chargeAmount || isNaN(Number(this.chargeAmount))) {
      this.chargeAmountError = true;
      isValid = false;
    }
    if (!this.selectedChargeStatus) {
      this.chargeStatusError = true;
      isValid = false;
    }
    if(this.selectedCharge=='Settled' && !this.chargeSettlementDate){
      this.chargeSettlementDateError=true;
      isValid=false;
    }
    return isValid;
  }

  addCharge(): void {
    if (this.validateCharge()) {
      const charge = {
        Charge: this.selectedCharge,
        Description: this.chargeDescription,
        currency: this.chargeCurrency,
        Amount: this.chargeAmount,
        Status: this.selectedChargeStatus,
        'Settlement Date': this.chargeSettlementDate // Assuming settlement date is not set yet
      };
      if (this.editingChargeIndex >= 0) {
        this.chargeData[this.editingChargeIndex] = charge;
        this.editingChargeIndex = -1;
      } else {
        this.chargeData.push(charge);
      }
      this.resetChargeFields();
    }
  }

  editCharge(index: number): void {
    const charge = this.chargeData[index];
    this.selectedCharge = charge.Charge;
    this.chargeDescription = charge.Description;
    this.chargeCurrency = charge.currency;
    this.chargeAmount = charge.Amount;
    this.selectedChargeStatus = charge.Status;
    this.chargeSettlementDate = charge['Settlement Date']
    this.editingChargeIndex = index;
    this.showChargePopupf();
  }

  deleteCharge(index: number): void {
    this.chargeData.splice(index, 1);
    if (this.editingChargeIndex === index) {
      this.editingChargeIndex = -1;
      this.resetChargeFields();
    }
  }

  resetChargeFields(): void {
    this.showChargePopup=false;
    this.selectedCharge = '';
    this.chargeDescription = '';
    this.chargeCurrency = '';
    this.chargeAmount = '';
    this.selectedChargeStatus = '';
    this.chargeSettlementDate='';
  }
    // end of charge vars

  

  tranStatusError=false;

  saveForm(): void {
    // Validate transaction status
    this.tranStatusError = !this.selectedTranStatus;

    if (!this.tranStatusError) {
      // Save logic here (e.g., call service to save data)
      console.log('Saving transaction data:', {
        selectedTranStatus: this.selectedTranStatus,
        bankRef: this.bankRef,
        comment: this.comment,
        chargeData: this.chargeData,
        freeFormatMsg: this.freeFormatMsg
      });

      // Add non-static data to ogData
      console.log("edit index: " + this.editingIndex);
      if (this.editingIndex >= 0) {
        this.ogData[this.editingIndex] = {
          ...this.ogData[this.editingIndex],
          selectedTranStatus: this.selectedTranStatus,
          bankRef: this.bankRef,
          comment: this.comment,
          chargeData: [...this.chargeData],
          freeFormatMsg: this.freeFormatMsg
        };
      }

      // Make data same as ogData
      this.data = [...this.ogData];

      // Reset all error fields
      this.tranStatusError = false;
      this.chargeError = false;
      this.chargeDescriptionError = false;
      this.chargeCurrencyError = false;
      this.chargeAmountError = false;
      this.chargeStatusError = false;
      this.chargeSettlementDateError = false;

      // Reset editing variables
      this.editingIndex = -1;
      this.editingRow = null;

      // Go back to list
      this.popupText='Transaction details saved';
      this.popupVisible=true;
      this.showTranRecord = false;
    }
  }

  backToList(): void {
    this.showTranRecord = false;
  }


  popupVisible=false;
  popupText='';
  hidePopup(){
    this.popupText='';
    this.popupVisible=false;
  }
}
