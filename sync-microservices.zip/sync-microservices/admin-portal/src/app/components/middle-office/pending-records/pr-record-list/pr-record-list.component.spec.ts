import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrRecordListComponent } from './pr-record-list.component';

describe('PrRecordListComponent', () => {
  let component: PrRecordListComponent;
  let fixture: ComponentFixture<PrRecordListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PrRecordListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrRecordListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
