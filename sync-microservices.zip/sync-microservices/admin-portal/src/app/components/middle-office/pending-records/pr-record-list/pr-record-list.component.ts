import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { TableComponent } from "../../../../commom/table/table.component";
import { FormsModule } from '@angular/forms';
import { NgClass, NgFor, NgIf, NgStyle } from '@angular/common';
import { PopupComponent } from "../../../../commom/popup/popup.component";

@Component({
  selector: 'app-pr-record-list',
  imports: [PageTitleComponent, TableComponent, FormsModule, NgFor, NgIf, NgClass, NgStyle, PopupComponent],
  templateUrl: './pr-record-list.component.html',
  styleUrl: './pr-record-list.component.css'
})
export class PrRecordListComponent {


  // main page vars
  searchChannelRef = '';
  searchCompany = '';
  searchProductList = ['Export Collection', 'Import Colloection', 'Invoice'];
  selectedProduct = '';
  searchProductTypeList = ['Standby', 'Invoice Payment'];
  selectedProductType = '';
  fromDate = '';
  toDate = '';

  header = ['Channel Reference', 'Company', 'Type', 'CCY', 'Amount', 'Release', 'Action'];
  data: any[] = [
    {
      "Channel Reference": "CH001",
      "Company": "Big4U",
      "Type": "Trade",
      "CCY": "USD",
      "Amount": "100000",
      "Release": "2023-01-01",
    },
    {
      "Channel Reference": "CH002",
      "Company": "Test Corp",
      "Type": "Settlement",
      "CCY": "EUR",
      "Amount": "50000",
      "Release": "2023-01-01"
    },
  ];
  ogData=[...this.data];
  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchChannelRef = this.searchChannelRef
        ? item['Channel Reference']?.toLowerCase().includes(this.searchChannelRef.toLowerCase())
        : true;

      const matchCompany = this.searchCompany
        ? item['Company']?.toLowerCase().includes(this.searchCompany.toLowerCase())
        : true;

      const matchProduct = this.selectedProduct
        ? item['Type'] === this.selectedProduct
        : true;

      const matchProductType = this.selectedProductType
        ? item['CCY'] === this.selectedProductType
        : true;

      const matchFromDate = this.fromDate
        ? new Date(item['Release']) >= new Date(this.fromDate)
        : true;

      const matchToDate = this.toDate
        ? new Date(item['Release']) <= new Date(this.toDate)
        : true;

      return matchChannelRef && matchCompany && matchProduct && matchProductType && matchFromDate && matchToDate;
    });

    // ✅ Update reference so child detects change
    this.data = [...filtered];
  }

  viewTransactionf(row:any,index:any){
    this.showTranRecord=true;
  }


  //fill transaction page
  showTranRecord=false;
  companyName='BONAFIDE EXPORTS';
  productCode='Pre-shipment Finance';
  channelRef='TF25120000168668';
  custRef='CUSTREFTF25120000168668';
  tranType='New';
  release='Wednesday, December 17, 2025 4:57:33 PM IST';

  tranStatusList=['Approved', 'Rejected'];
  selectedTranStatus='';
  bankRef='';
  comment='';
  actionRequiredList=['Customer Instruction', 'Consent Response', 'Amendment Response', 'Cancel Response', 'Awaiting Disposal Instruction'];
  selectedAction='';

  chargeList=['Issuance Fee', 'Commission', 'Other'];
  selectedCharge='';
  chargeDescription='';
  chargeCurreny='';
  chargeAmount=''
  chargeStatusList=['Settled', 'Waived', 'Deferred', 'Other'];
  selectedChargeStatus='';
  chargeSettlementDate='';
  // temp charge data 
  chargeHeader=['Charge', 'Description', 'CCY', 'Amount', 'Status', 'Settlement Date', 'Action'];
  chargeData:any[] = []

  bank='IndusInd Bank Limited-2';
  productType='Internal Fund Transfer (Trade)';
  applicationDate='22/12/2025';

  address='temp addd';
  orderingAccount=' USD 201025414298';

  tranferAccount= 'USD 201032711551';

  amount='USD 5.00';
  transferDate='22/12/2025';

  issuerRef='0001 OPERA HOUSE';



  tranStatusError=false;
  chargeError=false;
  chargeDescriptionError=false;
  chargeCurrencyError=false;
  chargeAmountError=false;
  chargeStatusError=false;
  chargeDateError=false;



  showAddCharge=false;
  showChargeAddPopupF(){
    this.showAddCharge=true;
  }
  editChargeRow(index:number){

  }
  deleteChargeRow(index:number){}
  saveCharge(){
    this.showAddCharge=false;
  }
  closeChargePopup(){
    this.showAddCharge=false;
  }

  savePendingTran(){
    this.popupText='Transaction Saved';
    this.popupVisible=true;
    this.showTranRecord=false;
  }
  closePendingTran(){
    this.showTranRecord=false;
  }


  popupText='';
  popupVisible=false;
  hidePopup(){
    this.popupVisible=false;
    this.popupText='';
  }


}
