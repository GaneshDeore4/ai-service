import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrReleaseRejectTransactionComponent } from './pr-release-reject-transaction.component';

describe('PrReleaseRejectTransactionComponent', () => {
  let component: PrReleaseRejectTransactionComponent;
  let fixture: ComponentFixture<PrReleaseRejectTransactionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PrReleaseRejectTransactionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrReleaseRejectTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
