import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgClass, NgFor, NgIf, NgStyle } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../../commom/table/table.component";
import { PopupComponent } from "../../../../commom/popup/popup.component";

@Component({
  selector: 'app-pr-release-reject-transaction',
  imports: [PageTitleComponent, NgIf, NgFor, FormsModule, TableComponent, NgClass, NgStyle, PopupComponent],
  templateUrl: './pr-release-reject-transaction.component.html',
  styleUrl: './pr-release-reject-transaction.component.css'
})
export class PrReleaseRejectTransactionComponent {

  // main page vars
  searchChannelRef = '';
  searchCompany = '';
  searchProductList = ['Export Collection', 'Import Colloection', 'Invoice'];
  selectedProduct = '';

    header = ['Channel Reference', 'Company', 'Type', 'Currency', 'Amount', 'Release', 'Action'];
    data: any[] = [
    // {
    //   "Channel Reference": "CH001",
    //   "Company": "Big4U",
    //   "Currency": "USD",
    //   "Amount": "100000",
    //   "Type": "New",
    //   "Release": "2023-01-01",
    // },
    {
      "Channel Reference": "CH002",
      "Company": "Sch",
      "Currency": "INR",
      "Amount": "100000",
      "Type": "New",
      "Release": "2026-02-02",
    },
  ];

  ogData = [...this.data];

    searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchChannelRef = this.searchChannelRef
        ? item['Channel Reference']?.toLowerCase().includes(this.searchChannelRef.toLowerCase())
        : true;

      const matchCompany = this.searchCompany
        ? item['Company']?.toLowerCase().includes(this.searchCompany.toLowerCase())
        : true;

      const matchProduct = this.selectedProduct
        ? item['Product'] === this.selectedProduct
        : true;

      return matchChannelRef && matchCompany && matchProduct;
    });

    // ✅ Update reference so child detects change
    this.data = [...filtered];
  }
  downloadData(){}



  showTranRecord = false;
  viewTransactionf() {
    this.showTranRecord = true;
  }


  // second page vars
  companyName='BONAFIDE EXPORTS';
  productCode='Outward Remittance';
  channelRef='FT25110000167062';
  custRef='ASD567';
  tranType='New';
  releaseDateTime='Monday, November 17, 2025 7:23:22 PM IST';

  newTranStatusList=['Release','Reject'];
  selectedNewTranStatus='';

  // general details
  bankName='IndusInd Bank Limited-2';
  productType='Outgoing Fund Transfer (Trade)';
  applicationDate='14/11/2025';
  applicantAddress='test Address';
  orderingAccount='201025414298';

  contactName='Pankaj Minde';
  contactAddress='abc111, abc222, abc333';
  contactCurrency='USD';
  contactAccount = ' 12234556666';

  chargeOption='BEN - All charges to be paid by beneficiary';

  tranCurrency='USD';
  tranAmount='100';
  transferDate='17/11/2025';
  beneRef='ASD234';

  issuerRef='0001 OPERA HOUSE';
  swiftCode='IRVTUS3NXXX';
  affBankName='THE BANK OF NEWYORK MELLON';
  affBankAddress='240 GREENWICH STREET,NEW YORK 10286,NEW YORK, NY3';

  newTranStatusError=false;



  // charge fields:
  showChargePopup=false;
  chargeHeaders=['Charge','Description','currency','Amount','Status','Settlement Date', 'Action'];
  chargeData:any=[];
  chargeList=['Commission','Issuance Fee', 'Others'];
  selectedCharge='';
  chargeDescription='';
  chargeCurrency='';
  chargeAmount='';
  chargeStatusList=['Settled','Waived','Deferred','Other'];
  selectedChargeStatus='';  
  chargeSettlementDate='';

  chargeError=false;
  chargeDescriptionError=false;
  chargeCurrencyError=false;
  chargeAmountError=false;
  chargeStatusError=false;
  chargeSettlementDateError=false;
  editingChargeIndex = -1;
    showChargePopupf(){
    this.showChargePopup=true;
  }


  validateCharge(): boolean {
    let isValid = true;
    this.chargeError = false;
    this.chargeDescriptionError = false;
    this.chargeCurrencyError = false;
    this.chargeAmountError = false;
    this.chargeStatusError = false;
    this.chargeSettlementDateError=false;

    if (!this.selectedCharge) {
      this.chargeError = true;
      isValid = false;
    }
    if (!this.chargeDescription.trim()) {
      this.chargeDescriptionError = true;
      isValid = false;
    }
    if (!this.chargeCurrency.trim()) {
      this.chargeCurrencyError = true;
      isValid = false;
    }
    if (!this.chargeAmount || isNaN(Number(this.chargeAmount))) {
      this.chargeAmountError = true;
      isValid = false;
    }
    if (!this.selectedChargeStatus) {
      this.chargeStatusError = true;
      isValid = false;
    }
    if(this.selectedCharge=='Settled' && !this.chargeSettlementDate){
      this.chargeSettlementDateError=true;
      isValid=false;
    }
    return isValid;
  }

  addCharge(): void {
    if (this.validateCharge()) {
      const charge = {
        Charge: this.selectedCharge,
        Description: this.chargeDescription,
        currency: this.chargeCurrency,
        Amount: this.chargeAmount,
        Status: this.selectedChargeStatus,
        'Settlement Date': this.chargeSettlementDate // Assuming settlement date is not set yet
      };
      if (this.editingChargeIndex >= 0) {
        this.chargeData[this.editingChargeIndex] = charge;
        this.editingChargeIndex = -1;
      } else {
        this.chargeData.push(charge);
      }
      this.resetChargeFields();
    }
  }

  editCharge(index: number): void {
    const charge = this.chargeData[index];
    this.selectedCharge = charge.Charge;
    this.chargeDescription = charge.Description;
    this.chargeCurrency = charge.currency;
    this.chargeAmount = charge.Amount;
    this.selectedChargeStatus = charge.Status;
    this.chargeSettlementDate = charge['Settlement Date']
    this.editingChargeIndex = index;
    this.showChargePopupf();
  }

  deleteCharge(index: number): void {
    this.chargeData.splice(index, 1);
    if (this.editingChargeIndex === index) {
      this.editingChargeIndex = -1;
      this.resetChargeFields();
    }
  }

  resetChargeFields(): void {
    this.showChargePopup=false;
    this.selectedCharge = '';
    this.chargeDescription = '';
    this.chargeCurrency = '';
    this.chargeAmount = '';
    this.selectedChargeStatus = '';
    this.chargeSettlementDate='';
  }

  // charge field code end



  // file upload code start    TODO
  // file upload code end

  popupText='';
  popupVisible=false;
  hidePopup(){
    this.popupVisible=false;
    this.popupText='';
  }
  // SAVE LOGIC
  submit(){
    if(!this.isValid())
        return;
    this.popupText='Transaction Details Saved';
    this.popupVisible=true;
    this.backToList();
  }
  isValid():boolean{
    this.newTranStatusError=false;
    if(this.selectedNewTranStatus==''){
      this.newTranStatusError=true;
      return false;
    }
    return true;
  }
  backToList(){
    this.showTranRecord=false;
    this.newTranStatusError=false;
    this.chargeError = false;
    this.chargeDescriptionError = false;
    this.chargeCurrencyError = false;
    this.chargeAmountError = false;
    this.chargeStatusError = false;
    this.chargeSettlementDateError=false;

    //nullfy vars
    this.resetChargeFields();
  this.companyName='';
  this.productCode='';
  this.channelRef='';
  this.custRef='';
  this.tranType='';
  this.releaseDateTime='';
  this.selectedNewTranStatus='';

  // general details
  this.bankName='';
  this.productType='';
  this.applicationDate='';
  this.applicantAddress='';
  this.orderingAccount='';

  this.contactName='';
  this.contactAddress='';
  this.contactCurrency='';
  this.contactAccount = '';

  this.chargeOption='';
  this.tranCurrency='';
  this.tranAmount='';
  this.transferDate='';
  this.beneRef='';
  this.issuerRef='';
  this.swiftCode='';
  this.affBankName='';
  this.affBankAddress='';

  }
}
