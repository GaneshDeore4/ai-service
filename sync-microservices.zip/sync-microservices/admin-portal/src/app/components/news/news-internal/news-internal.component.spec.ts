import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsInternalComponent } from './news-internal.component';

describe('NewsInternalComponent', () => {
  let component: NewsInternalComponent;
  let fixture: ComponentFixture<NewsInternalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NewsInternalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewsInternalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
