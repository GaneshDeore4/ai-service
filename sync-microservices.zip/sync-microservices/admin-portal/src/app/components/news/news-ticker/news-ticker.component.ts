import { NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ToastComponent } from '../../../commom/toast/toast.component';
import { TableComponent } from '../../../commom/table/table.component';
import { ApiService } from '../../../service/apiService/api.service';
import {
  GET_ALL_GUIDELINES,
  ADD_GUIDELINES,
  Delete_GUIDELINES,
} from '../../../constants/api_endpoints';
import { GET_GUIDELINES_BY_ID } from '../../../constants/api_endpoints';
import { TblComponent } from '../../../commom/tbl/tbl.component';
import { SessionService } from '../../../service/sessionService/session.service';
import {
  SUPERADMIN,
  BANKSUPERADMINMAKER,
  BANKSUPERADMINCHECKER,
  BANKSETUPMAKER,
  BANKSETUPCHECKER,
  COMPANY_CATERGORY_ID,
} from '../../../constants/Constants';
import { CommonModule } from '@angular/common';
import {
  APPROVE_GUIDELINES,
  REJECT_GUIDELINES,
  TOGGLE_GUIDELINES,
} from '../../../constants/api_endpoints';
import {
  AuditCard,
  UserAuditComponent,
} from '../../../commom/user-audit/user-audit.component';
@Component({
  selector: 'app-news-ticker',
  imports: [
    ToastComponent,
    FormsModule,
    TblComponent,
    NgIf,
    CommonModule,
    UserAuditComponent,
  ],
  templateUrl: './news-ticker.component.html',
  styleUrl: './news-ticker.component.css',
})
export class NewsTickerComponent implements OnInit {
  // VIEW CONTROL
  addForm = false;
  editMode = false;
  viewMode: boolean = false;
  validTill: string = '';
  validTillError = false;
  role = '';
  actionList: string[] = [];
  // FORM DATA
  title = '';
  desc = '';
  selectedId: number | null = null;
  selectedStatus: string = '';
  currentDate = new Date().toISOString().split('T')[0];

  // TABLE
  // headers = ['Title', 'Description', 'Action'];
  headers: { key: string; value: string }[] = [
    { key: 'title', value: 'Title' },
    { key: 'description', value: 'Description' },
    { key: 'validTill', value: 'Valid Till' }, // ✅ NEW
    { key: 'status', value: 'Status' }, // ✅ NEW
    { key: 'active', value: 'Active' }, // ✅ NEW
    { key: 'Action', value: 'Action' },
    //{ key: 'Audit', value: 'Audit-trail' },
  ];
  isAuditOpen = false;
  channelRef = 'CH123456';

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }
  auditCards: AuditCard[] = [
    {
      label: 'Maker',
      name: 'ABC',
      datetime: '10 Apr 2026, 10:00 AM',
      status: 'completed',
    },
    {
      label: 'Checker',
      name: 'XYZ',
      datetime: '10 Apr 2026, 11:00 AM',
      status: 'completed',
    },
  ];
  columnWidths = ['40%', '50%', '10%'];
  data: any[] = [];
  originalData: any[] = [];

  // SEARCH
  searchText = '';

  // TOAST
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };

  constructor(
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.role = this.sessionService.getRole();
    this.role = this.sessionService.getRole() || '';
    if (
      this.role == BANKSUPERADMINMAKER ||
      this.role == BANKSETUPMAKER ||
      this.role == SUPERADMIN
    ) {
      this.actionList = ['edit', 'delete', 'audit'];
    } else if (this.role == BANKSUPERADMINCHECKER) {
      this.actionList = ['view', 'audit'];
    }
  }

  approveGuideline() {
    if (!this.selectedId) return;

    const url = `${APPROVE_GUIDELINES}?guidelineId=${this.selectedId}`;

    this.apiService
      .sendData(url, {}, { 'X-ACTION-ROLE': 'APPROVE' })
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Approved', 'Guideline Approved');
            this.getGuidelines();
            this.backToList();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Approval failed');
        },
      });
  }

  rejectGuideline() {
    if (!this.selectedId) return;

    const url = `${REJECT_GUIDELINES}?guidelineId=${this.selectedId}`;

    this.apiService.sendData(url, {}, { 'X-ACTION-ROLE': 'REJECT' }).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.showToast('error', 'Rejected', 'Guideline Rejected');
          this.getGuidelines();
          this.backToList();
        } else {
          this.showToast('error', 'Error', res.description);
        }
      },
      error: () => {
        this.showToast('error', 'Error', 'Rejection failed');
      },
    });
  }

  onActiveChange(event: any) {
    const id = event.row.id;
    const isActive = event.value;

    const url = `${TOGGLE_GUIDELINES}?guidelineId=${id}`;

    const payload = {
      isActive: isActive,
    };

    this.apiService.sendData(url, payload).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.showToast(
            'success',
            'Success',
            `Guideline ${isActive ? 'Enabled' : 'Disabled'}`
          );
        } else {
          this.showToast('error', 'Error', res.description);
          event.row.active = !isActive;
        }
      },
      error: () => {
        this.showToast('error', 'Error', 'Toggle failed');
        event.row.active = !isActive;
      },
    });
  }

  viewGuideline(row: any) {
    this.addForm = true;
    this.viewMode = true;

    this.selectedId = row.id;
    this.title = row.title;
    this.desc = row.description;

    this.validTill = this.convertToInputDate(row.validTill); // ✅ fix date
    this.selectedStatus = row.status; // ✅ IMPORTANT
  }
  convertToInputDate(dateStr: string): string {
    if (!dateStr) return '';

    // expects: dd-mm-yyyy HH:mm
    const [datePart, timePart] = dateStr.split(' ');
    const [day, month, year] = datePart.split('-');

    return `${day}-${month}-${year}`; // for <input type="date">
  }
  formatToDdMmYyyyHHmm(value: string | Date): string {
    const date = typeof value === 'string' ? new Date(value) : value;

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();

    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  editGuideline(row: any) {
    this.addForm = true;
    this.editMode = true;

    this.selectedId = row.id;
    this.title = row.title;
    this.desc = row.description;

    this.validTill = this.convertToInputDate(row.validTill); // ✅
  }

  addBtnAllowed(): boolean {
    if (
      this.role == SUPERADMIN ||
      this.role == BANKSUPERADMINMAKER ||
      this.role == BANKSETUPMAKER
    )
      return true;
    else return false;
  }
  approveRejectAvailable(): boolean {
    return (
      this.role === SUPERADMIN ||
      this.role === BANKSUPERADMINCHECKER ||
      this.role === BANKSETUPCHECKER
    );
  }

  ngOnInit() {
    this.getGuidelines();
  }

  // =========================
  // 📥 GET ALL GUIDELINES
  // =========================
  getGuidelines() {
    this.apiService.getData(GET_ALL_GUIDELINES, {}).subscribe({
      next: (res: any) => {
        if (res?.status === 'SUCCESS' && res?.payload?.content) {
          this.data = res.payload.content.map((item: any) => ({
            id: item.guidelineId,
            title: item.guidelineTitle,
            description: item.guidelineDesc,

            validTill: item.validUpto || '', // ✅ NEW
            status: item.status || 'Pending', // ✅ NEW
            active: item.isActive ?? false, // ✅ NEW
          }));

          this.originalData = [...this.data];
        } else {
          this.data = [];
          this.originalData = [];
          this.showToast('error', 'Error', res?.description || 'No data');
        }
      },
      error: () => {
        this.showToast('error', 'Error', 'Failed to fetch guidelines');
      },
    });
  }

  // =========================
  // 🔍 SEARCH
  // =========================
  onSearch() {
    const term = this.searchText.trim().toLowerCase();

    if (!term) {
      this.data = [...this.originalData];
      return;
    }

    this.data = this.originalData.filter(
      (item) =>
        item.title.toLowerCase().includes(term) ||
        item.description.toLowerCase().includes(term)
    );
  }

  // =========================
  // ➕ ADD BUTTON
  // =========================
  openAddForm() {
    this.addForm = true;
    this.editMode = false;
    this.selectedId = null;
  }

  // =========================
  // ✏️ EDIT
  // =========================

  // =========================
  // ❌ DELETE (ID IN PARAMS)
  // =========================
  deleteGuideline(row: any) {
    const url = `${Delete_GUIDELINES}?guidelineId=${row.id}`;

    this.apiService.sendData(url, {}).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.getGuidelines();
          this.showToast('success', 'Success', 'Deleted Successfully');
        } else {
          this.showToast('error', 'Error', res.description);
        }
      },
      error: () => {
        this.showToast('error', 'Error', 'Delete failed');
      },
    });
  }
  // =========================
  // 💾 SAVE (ADD + EDIT)
  // =========================
  saveForm() {
    if (!this.title) return;

    this.validTillError = false;

    if (!this.title) return;

    if (!this.validTill) {
      this.validTillError = true;
      return;
    }

    const payload = {
      guidelineId: this.editMode ? this.selectedId : null,
      guidelineTitle: this.title,
      guidelineDesc: this.desc,
      validUpto: this.formatToDdMmYyyyHHmm(this.validTill), // ✅ FIXED
      isUpdate: this.editMode,
    };

    const actionRole = this.editMode ? 'EDIT' : 'CREATE';

    this.apiService
      .sendData(ADD_GUIDELINES, payload, { 'X-ACTION-ROLE': actionRole })
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.getGuidelines();

            this.showToast(
              'success',
              'Success',
              this.editMode ? 'Updated Successfully' : 'Added Successfully'
            );

            this.backToList();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Save failed');
        },
      });
  }

  // =========================
  // 🔙 BACK
  // =========================
  backToList() {
    this.title = '';
    this.desc = '';
    this.validTill = '';

    this.addForm = false;
    this.editMode = false;
    this.viewMode = false;

    this.selectedId = null;
  }

  // =========================
  // 🔔 TOAST
  // =========================
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };

    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }

  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  createAuditCards(payload: any): AuditCard[] {
    const cards: AuditCard[] = [];

    // 🟢 Maker
    if (payload.makerName && payload.createdAt) {
      cards.push({
        label: 'Maker',
        name: payload.makerName,
        datetime: this.formatAuditDate(payload.createdAt),
        status: 'completed',
      });
    }

    // 🟡 Editor
    if (payload.editorName && payload.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: payload.editorName,
        datetime: this.formatAuditDate(payload.editedAt),
        status: 'completed',
      });
    }

    // 🔴 Rejected (PRIORITY)
    if (payload.rejectedBy && payload.rejectedAt) {
      cards.push({
        label: 'Last Rejected By',
        name: payload.rejectedBy,
        datetime: this.formatAuditDate(payload.rejectedAt),
        status: 'completed',
      });

      return cards;
    }

    // 🟢 Approved
    if (payload.checkerName && payload.approvedAt) {
      cards.push({
        label: 'Last Approved By',
        name: payload.checkerName,
        datetime: this.formatAuditDate(payload.approvedAt),
        status: 'completed',
      });
    }

    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);

    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  auditFnc(row: any) {
    const url = `${GET_GUIDELINES_BY_ID}?guidelineId=${row.id}`;

    this.apiService.getData(url, {}).subscribe({
      next: (res: any) => {
        console.log('Guideline Audit Response:', res);

        if (res?.status === 'SUCCESS' && res?.payload) {
          this.auditCards = this.createAuditCards(res.payload);
        }

        this.isAuditOpen = true;
      },
      error: (err) => {
        console.error('Audit API Error:', err);
      },
    });
  }
}
