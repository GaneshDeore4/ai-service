import { Component } from '@angular/core';

@Component({
  selector: 'app-alert-maintenance',
  imports: [],
  templateUrl: './alert-maintenance.component.html',
  styleUrl: './alert-maintenance.component.css'
})
export class AlertMaintenanceComponent {

}
