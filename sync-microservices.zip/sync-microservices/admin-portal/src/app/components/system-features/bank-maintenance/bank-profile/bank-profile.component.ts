import { GTPCustomerReferenceTnxDto } from './../../../../model/CustomerReference';
import { LegalInfoDto } from './../../../../model/LegalInfoDto';
import { SessionService } from './../../../../service/sessionService/session.service';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { CommonModule, NgClass, NgFor, NgIf } from '@angular/common';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableComponent } from '../../../../commom/table/table.component';
import { map, Observable, startWith } from 'rxjs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { EntityService } from '../../../../service/entityService/entity.service';
import { ActivatedRoute } from '@angular/router';
import { TabsModule } from 'primeng/tabs';
// import { TabsModule, TabPanel, TabList } from 'primeng/tabs';
import { ApiService } from '../../../../service/apiService/api.service';
import {
  APPROVE_BANK,
  AUTHORIZE_COMPANY,
  CREATE_COMPANY,
  GET_ALL_MASTER_ROLE,
  GET_ALL_ROLE,
  GET_ALL_TEMP_BANK,
  GET_ALL_TXN_COMPANIES,
  GET_TEMP_BANK_BY_ID,
  REJECT_BANK,
  SAVE_BANK_PROFILE,
  SEND_OTP,
  VALIDATE_OTP,
} from '../../../../constants/api_endpoints';
import { GTPCompanyTnxDto } from '../../../../model/CompanyProfile';
import { GTPAccountTnxDto } from '../../../../model/Account';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { GTPRoleDto } from '../../../../model/Role';
import { FloatLabel, FloatLabelModule } from 'primeng/floatlabel';
import { MultiSelectModule } from 'primeng/multiselect';
import { ProductEntity } from '../../jurisdiction-maintenance/product-master/product-master.component';
import COUNTRIES_DATA from '../../../../constants/Countries';
import { SelectModule } from 'primeng/select';
import { BankProfileBaseDto } from '../../../../model/BankProfile';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  BANKSETUPCHECKER,
  BANKSETUPMAKER,
  BANKSUPERADMINCHECKER,
  BANKSUPERADMINMAKER,
  PAGE_SIZE,
  SUPERADMIN,
} from '../../../../constants/Constants';
import {
  AuditCard,
  UserAuditComponent,
} from '../../../../commom/user-audit/user-audit.component';
import { OtpComponent } from "../../../../commom/otp/otp.component";
export interface RoleMasterEntity {
  roleId?: number;
  roleName?: string;
}
interface SubProduct {
  name: string;
  selected: boolean;
}

interface Product {
  name: string;
  selected: boolean;
  subProducts: SubProduct[];
}
@Component({
  selector: 'app-bank-profile',
  imports: [
    PageTitleComponent,
    NgIf,
    NgFor,
    FormsModule,
    NgClass,
    CommonModule,
    MultiSelectModule,
    FloatLabelModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    SelectModule,
    ToastComponent,
    TabsModule,
    TblComponent,
    LoaderComponent,
    UserAuditComponent,
    OtpComponent
],
  templateUrl: './bank-profile.component.html',
  styleUrl: './bank-profile.component.css',
})
export class BankProfileComponent implements OnInit {
  isLoading = false;
  queryParam = '';
  role = '';
  countryData = COUNTRIES_DATA;
  actionList: string[] = [];
  bankEntity: BankProfileBaseDto = new BankProfileBaseDto();

  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'bankProfileTable';

  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  constructor(
    private entityService: EntityService,
    private cdr: ChangeDetectorRef,
    private activatedRoute: ActivatedRoute,
    private sessionService: SessionService,
    private apiService: ApiService
  ) {
    this.role = sessionService.getRole();
  }

  ngOnInit() {
    if (
      this.role == BANKSUPERADMINMAKER ||
      this.role == BANKSETUPMAKER ||
      this.role == SUPERADMIN
    ) {
      this.actionList = ['view', 'edit'];

      // } else if (this.role == SUPERADMIN) {
      //   this.actionList = ['view', 'edit', 'replicate'];
    } else if (
      this.role == BANKSUPERADMINCHECKER ||
      this.role == BANKSETUPCHECKER
    )
      this.actionList = ['view'];
    this.getTableData();
    this.activatedRoute.queryParamMap.subscribe((params) => {
      this.queryParam = params.get('status') || '';
      if (this.queryParam == 'dashboard') {
        this.selectedStatus = 'Awaiting for Approval(N)';
        // console.log('queryParam :', this.queryParam);
        this.searchData();
      }
    });
  }
  approveRejectAvailable(): boolean {
    if (
      this.role == SUPERADMIN ||
      this.role == BANKSUPERADMINCHECKER ||
      this.role == BANKSETUPCHECKER
    )
      return true;
    else return false;
  }
  addBtnAllowed(): boolean {
    if (
      this.role == SUPERADMIN ||
      this.role == BANKSUPERADMINMAKER ||
      this.role == BANKSETUPMAKER
    )
      return true;
    else return false;
  }

  //search vars
  searchAbbreviatedName = '';
  searchName = '';
  statusList: string[] = ['ALL', 'PENDING', 'APPROVED', 'REJECTED', 'UPDATE-REJECTED'];
  selectedStatus = '';

  searchData(): void {
    const filtered = this.ogData.filter((item) => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['abbvName']
            ?.toLowerCase()
            .includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['name']
            ?.toLowerCase()
            .includes(this.searchName.toLowerCase())
        : true;

      const matchStatus = this.selectedStatus && this.selectedStatus !== 'ALL'
        ? item['status'] === this.selectedStatus
        : true;

      return matchAbbreviated && matchName && matchStatus;
    });

    // ✅ Update reference so child detects change
    this.data = [...filtered];
    this.cdr.detectChanges();
  }

  // main details
  languageList: string[] = ['English(UK)', 'English(USA)', 'French', 'Arabic'];
  timeZoneList = ['Asia/Calcutta', 'America/Havana'];
  // table config and data
  header: { key: string; value: string }[] = [
    { key: 'abbvName', value: 'Bank ID' },
    { key: 'name', value: 'Name' },
    { key: 'status', value: 'Status' },
    // { key: 'makerId', value: 'Maker ID' },
    // { key: 'Action', value: 'Action' },
    // { key: 'Audit', value: 'Audit-trail' },
  ];
  isAuditOpen = false;
  channelRef = 'CH123456';

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }
  auditCards: AuditCard[] = [
    {
      label: 'Maker',
      name: 'ABC',
      datetime: '10 Apr 2026, 10:00 AM',
      status: 'completed',
    },
    {
      label: 'Checker',
      name: 'XYZ',
      datetime: '10 Apr 2026, 11:00 AM',
      status: 'completed',
    },
  ];
  createAuditCards(payload: any): AuditCard[] {
    const cards: AuditCard[] = [];
    // 🟢 Maker
    if (payload.makerName && payload.createdAt) {
      cards.push({
        label: 'Maker',
        name: payload.makerName,
        datetime: this.formatAuditDate(payload.createdAt),
        status: 'completed',
      });
    }
    // 🟡 Editor
    if (payload.editorName && payload.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: payload.editorName,
        datetime: this.formatAuditDate(payload.editedAt),
        status: 'completed',
      });
    }
    // 🔴 Rejected (priority)
    if (payload.rejectedBy && payload.rejectedAt) {
      cards.push({
        label: 'Last Rejected By',
        name: payload.rejectedBy,
        datetime: this.formatAuditDate(payload.rejectedAt),
        status: 'completed',
      });
      return cards;
    }
    // 🟢 Approved
    if (payload.checkerName && payload.approvedAt) {
      cards.push({
        label: 'Last Approved By',
        name: payload.checkerName,
        datetime: this.formatAuditDate(payload.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }
  formatAuditDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
  auditFnc(row: any) {
    const url = `${GET_TEMP_BANK_BY_ID}?bankProfileId=${row.bankProfileId}`;
    this.apiService.getData(url, {}).subscribe({
      next: (res: any) => {
        // console.log('Bank Audit Response:', res);
        if (res?.status === 'SUCCESS' && res?.payload) {
          this.auditCards = this.createAuditCards(res.payload);
        }
        this.isAuditOpen = true;
      },
      error: (err) => {
        console.error('Audit API Error:', err);
      },
    });
  }

  columnWidths = ['25%', '30%', '10%', '25%', '10%'];

  data: any[] = [];
  ogData: any[] = [];

  getTableData() {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_ALL_TEMP_BANK +
          '?page=' +
          (this.pageNumber - 1) +
          '&size=' +
          this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.data = res['payload']['content'];
            this.ogData = [...this.data];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  getBankById(id: number) {
    this.isLoading = true;
    this.apiService
      .getData(GET_TEMP_BANK_BY_ID + '?bankProfileId=' + id, {})
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.bankEntity = new BankProfileBaseDto(res.payload);
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  // table operations:
  editProfile = false;
  editProfileIndex = -1;
  popupVisible = false;
  popupText = '';
  addProfile = false;
  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }
  addProfilef() {
    this.bankEntity = new BankProfileBaseDto();
    this.addProfile = true;
  }

  validateProfileForm(): boolean {
    this.clearMainFormError();
    let errorCount = 0;

    if (!this.bankEntity.abbvName) {
      this.abbreviatedNameErrorMsg = 'Abbreviated name cannot be empty.';
      this.abbreviatedNameError = true;
      errorCount++;
    }

    if (!this.bankEntity.name) {
      this.nameErrorMsg = 'Name cannot be empty.';
      this.nameError = true;
      errorCount++;
    }

    // if (!this.bankEntity.swiftAddress?.countryCode) {
    //   this.countryCodeErrorMsg = 'Please select a country code';
    //   this.countryCodeError = true;
    //   errorCount++;
    // }
    return errorCount === 0;
  }

  clearMainFormError() {
    this.abbreviatedNameErrorMsg = '';
    this.nameErrorMsg = '';
    this.countryCodeErrorMsg = '';
    this.statusErrorMsg = '';
    this.languageErrorMsg = '';
    this.currencyErrorMsg = '';
    this.emailErrorMsg = '';
    this.ieCodeErrorMsg = '';
    this.timeZoneErrorMsg = '';
    this.contactNameErrorMsg = '';
    this.contactNumberErrorMsg = '';
    this.contactNumberError = false;
    this.contactNameError = false;
    this.timeZoneError = false;
    this.abbreviatedNameError = false;
    this.nameError = false;
    this.countryCodeError = false;
    this.statusError = false;
    this.languageError = false;
    this.currencyError = false;
    this.emailError = false;
    this.ieCodeError = false;
  }

  // TODO
  saveForm(action: string) {
    if (!this.validateProfileForm()) {
      console.log('inside validate');
      return; // Stop if validation fails
    }

    this.isLoading = true;
    const actionRole = this.editProfileIndex === -1 ? 'CREATE' : 'EDIT';

    this.apiService
      .sendData(
        SAVE_BANK_PROFILE,
        BankProfileBaseDto.objectToJson(this.bankEntity),
        {
          'X-ACTION-ROLE': actionRole,
        }
      )
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              this.editProfileIndex == -1
                ? 'Bank Profile created successfully'
                : 'Bank Profile updated successfully'
            );
            this.backToList();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  // TODO
  approveRejectForm(action: string) {
    let url =
      action == 'approve'
        ? APPROVE_BANK + '?bankProfileId=' + this.bankEntity.bankProfileId
        : REJECT_BANK + '?bankProfileId=' + this.bankEntity.bankProfileId;

    const actionRole = action === 'approve' ? 'APPROVE' : 'REJECT';

    this.isLoading = true;

    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': actionRole,
        }
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              action === 'approve'
                ? 'Bank Profile Approved'
                : 'Bank Profile Rejected'
            );
            this.backToList();
            this.checkerAction='';
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  backToList() {
    // console.log('back to list in bank profile');
    this.bankEntity = new BankProfileBaseDto();
    this.clearMainFormError();
    this.editProfileIndex = -1;
    this.addProfile = false;
    this.editProfile = false;
    this.viewProfile = false;
    this.getTableData();
  }
  viewProfile = false;
  viewProfilef(row: BankProfileBaseDto, index: number) {
    this.viewProfile = true;
    this.addProfilef();
    if (row.bankProfileId) this.getBankById(row.bankProfileId);
  }

  editProfilef(row: BankProfileBaseDto, index: number) {
    this.editProfile = true;
    this.addProfilef();
    this.editProfileIndex = index;
    if (row.bankProfileId) this.getBankById(row.bankProfileId);
  }

  deleteProfilef(row: any, index: number) {
    if (index >= 0 && index < this.data.length) {
      this.data.splice(index, 1);
      this.data = [...this.data];
      this.cdr.detectChanges();
    }
  }

  // field validations
  abbreviatedNameError = false;
  nameError = false;
  countryCodeError = false;
  statusError = false;
  languageError = false;
  currencyError = false;
  emailError = false;
  ieCodeError = false;
  timeZoneError = false;
  contactNameError = false;
  contactNumberError = false;
  contactNumberErrorMsg = '';
  timeZoneErrorMsg = '';
  contactNameErrorMsg = '';
  abbreviatedNameErrorMsg = '';
  nameErrorMsg = '';
  countryCodeErrorMsg = '';
  statusErrorMsg = '';
  languageErrorMsg = '';
  currencyErrorMsg = '';
  emailErrorMsg = '';
  ieCodeErrorMsg = '';

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'bankProfileTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }

  
      // OTP FUNCTIONS
      isOtpOpen = false;
      otpReference: string = '';
      tempReceivedOtp = '';
      checkerAction: string = '';
      sendOtp(action: string) {
        this.checkerAction=action;
        this.isOtpOpen = true;
        const payload = {
          loginId: this.sessionService.getLoginId(),
          bankAbbvName: this.sessionService.getCompanyName()
        }
        this.apiService.sendData(SEND_OTP, payload).subscribe({
          next: (res) => {
            if (res.status == 'SUCCESS') {
              //TODO:store opt reference over here
              this.otpReference = res.payload.otpReference;
              this.tempReceivedOtp = res.payload.enteredOtp;
            } else {
              console.log('OTP SEND FAILED');
            }
          },
          error: (err) => {
            console.error(err);
          }
        });
      }
    
      onOtpResend() {
        const payload = {
          loginId: this.sessionService.getLoginId(),
          bankAbbvName: this.sessionService.getCompanyName(),
          otpReference: this.otpReference
        }
        this.apiService.sendData(SEND_OTP, payload).subscribe({
          next: (res) => {
            if (res.status) {
              //TODO:store opt reference over here
              this.otpReference = res.payload.otpReference;
              this.tempReceivedOtp = res.payload.enteredOtp;
            } else {
              console.log('OTP SEND FAILED');
            }
          },
          error: (err) => {
            console.error(err);
          }
        });
      }
    
      validateOtp(otp: string) {
        const payload = {
          otpReference: this.otpReference,
          enteredOtp: this.tempReceivedOtp,  //REPLACE THIS AFTERWARD WITH otp varaible
          loginId: this.sessionService.getLoginId(),
          bankAbbvName: this.sessionService.getCompanyName()
        }
        this.apiService.sendData(VALIDATE_OTP, payload).subscribe({
          next: (res) => {
            if (res.status == 'SUCCESS') {
              // TODO: if the otp is validate call onOtpVerify
              this.isOtpOpen = false;
              this.approveRejectForm(this.checkerAction);
            } else {
              console.log('OTP SEND FAILED');
            }
          },
          error: (err) => {
            console.error(err);
          }
        });
      }
    
      closeOtpPopup(){
        this.isOtpOpen=false;
        this.otpReference='';
        this.tempReceivedOtp=''
      }
}
