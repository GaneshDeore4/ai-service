import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PopupComponent } from '../../../../commom/popup/popup.component';
import { SelectModule } from 'primeng/select';
import { FloatLabelModule } from 'primeng/floatlabel';
import COUNTRIES_DATA from '../../../../constants/Countries';
import {
  ADD_AUTH_MATRIX,
  AUTH_MATRIX_APPROVE,
  AUTH_MATRIX_REJECT,
  GET_ALL_AUTH_MATRIX,
  GET_ALL_MASTER_PRODUCT,
  GET_ALL_SUBPRO_BY_PRO_LIST,
  GET_AUTH_MATRIX_BY_ID,
  GET_AUTH_GROUPS,
  GET_ALL_TXN_COMPANIES,
  GET_ALL_TEMP_COMPANIES,
  GET_GROUPED_AUTH_MATRIX,
  APPROVE_GROUPED_MATRIX,
  GET_SUBPRODUCTS_BY_PRODUCT_ID,
  GET_PRODUCTS_BY_CATEGORY_ID,
  GET_ALL_BANK,
} from '../../../../constants/api_endpoints';
import { ApiService } from '../../../../service/apiService/api.service';
import { SessionService } from '../../../../service/sessionService/session.service';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { TableComponent } from '../../../../commom/table/table.component';
import { TabList, TabPanel, TabsModule } from 'primeng/tabs';
import { BANK_CATERGORY_ID, BANK_CATERGORY_NAME } from '../../../../constants/Constants';
import { LoaderComponent } from "../../../../commom/loader/loader.component";

export interface SubproductEntity {
  subProductId?: number;
  // productName?:string,
  // productId?:number,
  // categoryId?:number,
  // categoryList?:string,
  subProductName?: string;
}
interface ProductEntity {
  productId?: number;
  productName?: string;
  categoryId?: number;
  categoryName?: string;
}

@Component({
  selector: 'app-bm-user-authentication',
  imports: [
    PageTitleComponent,
    NgIf,
    NgFor,
    NgClass,
    FormsModule,
    TblComponent,
    PopupComponent,
    SelectModule,
    FloatLabelModule,
    TableComponent,
    TabPanel,
    TabList,
    TabsModule,
    LoaderComponent
  ],
  templateUrl: './bm-user-authentication.component.html',
  styleUrl: './bm-user-authentication.component.css'
})
export class BmUserAuthenticationComponent {
  productData: ProductEntity[] = [];
  subProductData: SubproductEntity[] = [];

  //main page vars--------------------------
  searchAbbreviatedName = '';
  searchName = '';
  countryData = COUNTRIES_DATA;
  currentAuthMatId: number | null = null;
  showButtons: boolean | null = null;
  role = '';
  loginCompanyId = 1;
  isLoading = false;
  searchData(): void {
    const filtered = this.ogData.filter((item) => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']
          ?.toLowerCase()
          .includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']
          ?.toLowerCase()
          .includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  showAuthorisation = false;
  companyHeader = ['abbvName', 'name', 'Action'];
  customerData: any[] = [];
  ogData: any[] = [];
  customerColumnWidth = ['40%', '50%', '10%'];
  currentCustomer = {};
  currentCustomerName: string = '';
  currentName: string = '';
  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentCustomerName = row['abbvName'] || row['Abbreviated Name'] || '';
    this.currentName = row['companyId'] || row['Company Name'] || '';
    this.loginCompanyId = row.companyId;
    this.showAuthorisation = true;
    this.getIndiAuthMatrix();
  }
  constructor(
    private apiService: ApiService,
    private sessionService: SessionService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.role = this.sessionService.getRole() || '';
    this.getCompanyList();
    this.getAuthGroups();

  }

  getCompanyList() {
    this.isLoading = true;
    const data = {
      page: 0,
      size: 1000,
      sort: ['string'],
    };
    this.apiService.getData(GET_ALL_BANK, data).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          this.customerData = res['payload']['content'];
          this.ogData = [...this.customerData];
        }
      },
      error: (err: any) => {
        console.error('Failed to load companies', err);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  getAuthGroups() {
    this.apiService.getData(GET_AUTH_GROUPS, {}).subscribe({
      next: (res: any) => {
        if (res && res.payload) {
          this.authGroupMap = res.payload;
          this.authLevelDropdown = res.payload.map(
            (group: any) => group.authGroup
          );
        }
      },
      error: (err: any) => console.error('ERROR fetching AuthGroups', err),
    });
  }

  //customer auth page vars----------------------------
  searchTypeList = ['New', 'Amend', 'Message'];
  selectedSearchType = '';
  searchProductList = ['Export Collection', 'Import Colloection', 'Remittance'];
  selectedSearchProduct = '';
  searchSubProductList = ['ALL'];
  selectedSubSearchProduct = '';
  existingAuthGroupIds: number[] = [];
  searchStatusList: string[] = [
    'Awaiting for Approval(D)',
    'Awaiting for Approval(M)',
    'Awaiting for Approval(N)',
    'Checker Returned(D)',
    'Checker Returned(M)',
    'Checker Returned(N)',
    'Draft(M)',
    'Draft(N)',
  ];
  selectedSearchStatus = '';
  addAuthForm = false;
  viewAuth = false;
  editAuth = false;
  editIndex = 0;
  // authHeaders = [
  //   'Type',
  //   'Product',
  //   'Product Type',
  //   'Subproduct Type',
  //   'Tenor',
  //   'Account',
  //   'Verify',
  //   'Auth Levels',
  //   'Send',
  //   'CCY',
  //   'Amount',
  //   'Status',
  //   'Maker',
  //   'Action',
  // ];

  authHeaders = [
    { key: 'isVerifier', value: 'Verifier' },
    { key: 'isReleaser', value: 'Releaser' },
    { key: 'eventType', value: 'Event Type' },
    { key: 'currencyType', value: 'Currency' },
    { key: 'amount', value: 'Amount' },
    { key: 'authGroupsFormatted', value: 'authGroup' },
    { key: 'status', value: 'Status' },
    { key: 'createdBy', value: 'Maker' },
    { key: 'Action', value: 'Action' },
  ];

  authColWidth = [
    '8%',
    '6%',
    '6%',
    '8%',
    '12%',
    '8%',
    '8%',
    '8%',
    '8%',
    '8%',
    '8%',
    '6%',
    '6%',
  ];
  authData: any[] = [
    // {
    //   Type: 'Amend',
    //   'Subproduct Type': 'Inward Remittance',
    //   Product: 'Remittance',
    //   'Product Type': 'Customs',
    //   Tenor: 'upto 1 year',
    //   Account: 'ACC123456',
    //   Verify: 'Yes',
    //   'Auth Levels': ['A', 'B'],
    //   Send: 'Completed',
    //   CCY: 'USD',
    //   Amount: '5000',
    //   Status: 'Draft(M)',
    //   Maker: 'JohnDoe',
    //   sequential: false,
    //   verifier: true,
    //   releaser: true,
    // },
    // {
    //   Type: 'New',
    //   'Subproduct Type': 'Outward Remittance',
    //   Product: 'Remittance',
    //   'Product Type': 'Customs',
    //   Tenor: 'upto 1 year',
    //   Account: 'ACC123456',
    //   Verify: 'Yes',
    //   'Auth Levels': ['C', 'B'],
    //   Send: 'Completed',
    //   CCY: 'USD',
    //   Amount: '10000',
    //   Status: 'Draft(N)',
    //   Maker: 'Abhinay',
    //   sequential: true,
    //   verifier: false,
    //   releaser: true,
    // },
  ];
  ogAuthData = this.authData;
  selectedProduct: number | null = null;
  selectedSubProduct: number | null = null;
  subProductDisable = false;
  onProductBlur() {
    this.selectedSubProduct = -1
    if (this.selectedProduct == -1) {
      this.subProductDisable = true;
    }
    else {
      this.subProductDisable = false;
      this.getAllSubproByProList();
    }
  }
  getAllSubproByProList() {
    if (!this.selectedProduct)
      return;
    this.apiService
      .getData(GET_SUBPRODUCTS_BY_PRODUCT_ID + '?productId=' + this.selectedProduct, {})
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.subProductData = [];
            this.subProductData = res['payload'];
          }
        },
        error: (err: any) => { },
      });
  }

  getAllProducts() {
    this.apiService.getData(GET_PRODUCTS_BY_CATEGORY_ID + '?categoryId=' + BANK_CATERGORY_ID, {}).subscribe({
      next: (res: any) => {
        //remember to bring the user object to pass to other screen
        // console.log("product list " + JSON.stringify(res, null, 2));
        if (res.status == 'SUCCESS') {
          this.productData = res['payload'];
          this.productData.unshift({
            productId: -1,
            productName: 'ALL',
          });

        }
      },
      error: (err: any) => {
        console.log(err);
      },
      complete: () => {
        console.log('Data was fetched');
      },
    });
    // this.productData.push({productId:1,productName:'Remittance'});
  }

  extractGroups(authGroup: any[]): string[] {
    if (!authGroup) return [];

    return authGroup.map((g: any) => {
      const key = Object.keys(g)[0];
      return key.split('-')[1];
    });
  }


  activeTab: string = '0';
  onTabChange(tabValue: string | number) {
    this.activeTab = tabValue.toString();
    if (tabValue === '0') {
      // Call the API for "ALL"
      this.getIndiAuthMatrix();
    } else if (tabValue === '1') {
      // Call the API for "Individual"
      this.getGroupedAuthMatrix();
    }
  }
  getGroupedAuthMatrix() {
    this.isLoading = true;
    const data = {
      "page": 0,
      "size": 10,
    }
    this.apiService.getData(GET_GROUPED_AUTH_MATRIX + '?category=' + BANK_CATERGORY_NAME, data).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.authData = [];
          const data = res.payload?.content || [];
          this.authData = data.map((item: any) => {
            const groups = item.authGroup
              ? item.authGroup.map((g: any) => {
                const key = Object.keys(g)[0]; // "1-A"
                return key.split('-')[1]; // "A"
              })
              : [];
            return {
              createdBy: item.createdBy,
              eventType: item.eventType,
              allProductFlag: item.allProductFlag,
              type: item.type,
              currencyType: item.currencyType,
              amount: item.amount,
              authGroup: item.authGroup,
              authGroupsFormatted: groups.join(', '), // A, B
              status: item.status || 'PENDING',
              authMatId: item.authMatId,
              productId: item.productId,
              subProductId: item.subProductId,
              isVerifier: item.isVerifier,
              isReleaser: item.isReleaser,
              isSequential: item.isSequential,
              ids: item.ids
            };
          });
          this.authData = [...this.authData];
          console.log("grouped auth data: " + JSON.stringify(this.authData, null, 2));
        }
      },
      error: (err: any) => {
        console.error('Error fetching auth matrix', err);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }
  getIndiAuthMatrix() {
    this.isLoading = true;
    const data = {
      "page": 0,
      "size": 10,
    }
    this.apiService.getData(GET_ALL_AUTH_MATRIX + '?category=' + BANK_CATERGORY_NAME, data).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.authData = [];
          const data = res.payload?.content || [];
          this.authData = data.map((item: any) => {
            const groups = item.authGroup
              ? item.authGroup.map((g: any) => {
                const key = Object.keys(g)[0]; // "1-A"
                return key.split('-')[1]; // "A"
              })
              : [];
            return {
              createdBy: item.createdBy,
              allProductFlag: item.allProductFlag,
              eventType: item.eventType,
              type: item.type,
              currencyType: item.currencyType,
              amount: item.amount,
              authGroupsFormatted: groups.join(', '), // A, B
              status: item.status || 'PENDING',
              authMatId: item.authMatId,
              productId: item.productId,
              subProductId: item.subProductId,
              isVerifier: item.isVerifier,
              isReleaser: item.isReleaser,
            };
          });
          this.authData = [...this.authData];
          console.log("INDI auth data: " + JSON.stringify(this.authData, null, 2));
        }
      },
      error: (err: any) => {
        console.error('Error fetching auth matrix', err);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  getAuthMatrixById(id: number, mode: 'view' | 'edit') {
    this.isLoading = true;
    this.apiService.getData(GET_AUTH_MATRIX_BY_ID + '?id=' + id + '&category=' + BANK_CATERGORY_NAME, {}).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          const data = res.payload;
          // store id for edit
          this.editIndex = data.authMatId;

          // open form
          this.showAuthorisation = false;
          this.addAuthForm = true;

          this.viewAuth = mode === 'view';
          this.editAuth = mode === 'edit';

          // populate form
          // this.SelectedAuthType = data.type
          //   ? data.type.charAt(0).toUpperCase() +
          //   data.type.slice(1).toLowerCase()
          //   : '';

          this.SelectedAuthType = data.eventType.length > 1 ? 'ALL' : data.eventType[0];
          console.log("selected auth type: " + this.SelectedAuthType);

          this.selectedProduct = data.productId || 0;

          this.addCurrency = data.currencyType || null;
          this.addAmount = data.amount || '';
          this.oldAmount = data.amount || '';

          this.isSequential = data.isSequential;
          this.isVerifier = data.isVerifier;
          this.isReleaser = data.isReleaser;

          this.existingAuthGroupIds = data.authGroup
            ? data.authGroup.map((g: any) => {
              const key = Object.keys(g)[0]; // "1-A"
              return Number(key.split('-')[0]); // 1
            })
            : [];
          this.authLevelList = data.authGroup
            ? data.authGroup.map((g: any) => {
              const key = Object.keys(g)[0]; // "1-A"
              return key.split('-')[1]; // "A"
            })
            : [];

          // this.authLevelList = data.authGroup
          //   ? data.authGroup.map((g: any) => Object.keys(g)[0])
          //   : [];

          // load dropdowns
          this.getAllProducts();

          // load sub products AFTER product set
          this.getAllSubproByProList();

          // set sub product
          this.selectedSubProduct = data.subProductId || 0;
        }
      },

      error: (err: any) => {
        console.error('Error fetching auth matrix', err);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }
  searchAuth(): void {
    const filtered = this.ogAuthData.filter((item) => {
      const matchType = this.selectedSearchType
        ? item['Type']
          ?.toLowerCase()
          .includes(this.selectedSearchType.toLowerCase())
        : true;

      const matchProduct = this.selectedSearchProduct
        ? item['Product']
          ?.toLowerCase()
          .includes(this.selectedSearchProduct.toLowerCase())
        : true;

      const matchSubProduct = this.selectedSubSearchProduct
        ? item['Subproduct Type']
          ?.toLowerCase()
          .includes(this.selectedSubSearchProduct.toLowerCase())
        : true;

      const matchStatus = this.selectedSearchStatus
        ? item['Status']
          ?.toLowerCase()
          .includes(this.selectedSearchStatus.toLowerCase())
        : true;

      return matchType && matchProduct && matchSubProduct && matchStatus;
    });

    this.authData = [...filtered]; // ✅ Update reference for change detection
  }
  addAuthF() {
    this.editIndex = -1;
    this.getAllProducts();
    this.addCurrency = null;
    this.showAuthorisation = false;
    this.addAuthForm = true;
  }


  viewAuthF(row: any) {
    this.viewAuth = true;
    this.currentAuthMatId = row.authMatId;
    console.log(row)
    this.showButtons = row.status == 'PENDING' ? true : false
    // if (!row?.authMatId) return;
    if (this.activeTab == '0') //if it is indivisual tab then get auth by id
      this.getAuthMatrixById(row.authMatId, 'view');
    else {//else map the current row in the page
      console.log("grouped row from view auth: " + JSON.stringify(row, null, 2));
      this.assignAddPageData(row);
    }
    this.addAuthForm = true;

  }
  editAuthF(row: any) {
    this.currentAuthMatId = row.authMatId;
    if (this.activeTab == '0') //if it is indivisual tab then get auth by id
      this.getAuthMatrixById(row.authMatId, 'edit');
    else {//else map the current row in the page
      console.log("grouped row from view auth: " + JSON.stringify(row, null, 2));
      this.assignAddPageData(row);
    }
    this.addAuthForm = true;
  }

  approveAuth() {
    let id: any = null;
    let url: string = '';
    let data: any = {};
    if (this.activeTab == '0') {
      id = this.currentAuthMatId;
      url = AUTH_MATRIX_APPROVE + '?id=' + this.currentAuthMatId;
    }
    else {
      url = APPROVE_GROUPED_MATRIX
      data['authMatrixIds'] = this.groupedRowIds;
    }
    this.isLoading = true;
    this.apiService
      .sendData(url, data)
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.popupText = 'Authorisation Approved';
            this.isPopupVisible = true;
            if (this.activeTab == '0')
              this.getIndiAuthMatrix();
            else
              this.getGroupedAuthMatrix();
            this.closeAddAuthf();
          }
          else {
            this.popupText = res.description;
            this.isPopupVisible = true;
          }
        },
        error: (err: any) => {
          this.popupText = 'Something Went wrong';
          this.isPopupVisible = true;
          console.error('Approve error', err);
        },
        complete: () => {
          this.isLoading = false;
        }
      });
  }
  rejectAuth() {
    let id: any = null;
    let url: string = '';
    let data: any = {};
    if (this.activeTab == '0') {
      id = this.currentAuthMatId;
      url = AUTH_MATRIX_APPROVE + '?id=' + this.currentAuthMatId;
    }
    else {
      url = APPROVE_GROUPED_MATRIX
      data['authMatrixIds'] = this.groupedRowIds;
    }
    this.isLoading = true;
    this.apiService
      .sendData(url, data)
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.popupText = 'Authorisation Rejected';
            this.isPopupVisible = true;
            if (this.activeTab == '0')
              this.getIndiAuthMatrix();
            else
              this.getGroupedAuthMatrix();
            this.closeAddAuthf();
          }
          else {
            this.popupText = res.description;
            this.isPopupVisible = true;
          }
        },
        error: (err: any) => {
          this.popupText = 'Something Went Wrong';;
          this.isPopupVisible = true;
          console.error('Reject error', err);
        },
        complete: () => {
          this.isLoading = false;
        }
      });
  }

  authMatId: number | null = null;
  groupedRowIds: number[] = [];
  assignAddPageData(row: any) {
    this.subProductDisable = true;
    this.productData.unshift({
      productId: -1,
      productName: 'ALL',
    });//PRODUCTS DATA IS EMPTY AND WE NEED NO PRODUCTS HERE.
    console.log("product data: " + JSON.stringify(this.productData, null, 2));
    this.groupedRowIds = row.ids.split(",").map((id: string) => Number(id));
    console.log(this.groupedRowIds);
    this.addAmount = row.amount;
    this.oldAmount = row.amount;
    this.authMatId = row.authMatId;//this is undefined because not recieved from api
    this.addCurrency = row.currencyType;
    this.SelectedAuthType = row.eventType.length > 1 ? 'ALL' : row.eventType[0];
    this.isReleaser = row.isReleaser;
    this.isVerifier = row.isVerifier;
    this.isSequential = row.isSequential;
    this.selectedProduct = -1; //this will be always -1 bcoz we are coming from all products list
    this.selectedSubProduct = -1;
    this.cdr.detectChanges();
    this.selectedSubProduct = row.subProductId;
    this.existingAuthGroupIds = row.authGroup
      ? row.authGroup.map((g: any) => {
        const key = Object.keys(g)[0]; // "1-A"
        return Number(key.split('-')[0]); // 1
      })
      : [];
    this.authLevelList = row.authGroup
      ? row.authGroup.map((g: any) => {
        const key = Object.keys(g)[0]; // "1-A"
        return key.split('-')[1]; // "A"
      })
      : [];
  }

  deleteAuthF(index: number): void {
    if (index >= 0 && index < this.authData.length) {
      this.authData.splice(index, 1);
      this.authData = [...this.authData]; // ✅ Update reference for change detection
    }
  }

  // addAuth form vars
  authTypeList: string[] = ['ALL', 'AMEND', 'CLOSE', 'NEW', 'PAYMENT'];
  SelectedAuthType: string = '';
  authProdList = ['Bankers Guarantee Received', 'Remittance'];
  selectedAuthProd = '';
  get authSubprodTypeList(): string[] {
    return this.showDependents()
      ? ['Demand Guarantee', 'Dependent Undertaking', 'Standby']
      : ['Inward Remittance', 'Outward Remittance'];
  }
  selectedAuthSubprodType = '';
  authProdTypeList = ['Customs', 'Judicial', 'Direct Pay'];
  selectedProdType = '';
  authTenorList = ['upto 1 year', 'upto 3 years', 'upto 5 years'];
  selectedTenor = '';
  addCurrency: string | null = null;
  addAmount = '';
  oldAmount = '';
  isSequential = false;
  isVerifier = false;
  isReleaser = false;

  typeError = false;
  productError = false;
  productTypeError = false;
  subProductTypeError = false;
  tenorError = false;
  currencyError = false;
  amountError = false;

  showDependents(): Boolean {
    //this funtion is used to show prod type and tenor based on product selection
    return this.selectedAuthProd == 'Bankers Guarantee Received' ? true : false;
  }

  authLevelHeaders: string[] = ['Authorisation Level', 'Action'];
  authLevelColumnWidths = ['50%', '50%'];
  authLevelList: string[] = [];
  authLevelDropdown: string[] = [];
  authGroupMap: any[] = [];
  selectedAuthLevelDropdown = '';
  authLevelSelectorError = false;
  openAuthLevel = false;
  editAuthLevel = false;
  authLevelIndex: number = -1;

  //functions for popup
  addAuthLevelf() {
    this.openAuthLevel = true;
  }
  editAuthLevelf(index: number) {
    this.authLevelIndex = index;
    this.editAuthLevel = true;
    this.selectedAuthLevelDropdown = this.authLevelList[index];
    this.addAuthLevelf();
  }
  deleteAuthLevelf(index: number) {
    this.authLevelList = this.authLevelList.filter((_, i) => i !== index);
  }

  saveAuthLevelf() {
    if (this.selectedAuthLevelDropdown == '') {
      this.authLevelSelectorError = true;
      return;
    }
    if (this.authLevelIndex > -1) {
      this.authLevelList.splice(
        this.authLevelIndex,
        1,
        this.selectedAuthLevelDropdown
      );
    } else {
      this.authLevelList.push(this.selectedAuthLevelDropdown);
    }
    this.closeAuthLevelPopup();
  }
  closeAuthLevelPopup() {
    this.openAuthLevel = false;
    this.editAuthLevel = false;
    this.authLevelIndex = -1;
    this.authLevelSelectorError = false;
    this.selectedAuthLevelDropdown = '';

  }

  saveAuthf() {
    if (!this.validateAuth()) return;
    this.isLoading = true;
    const authGroupIds = this.authLevelList
      .map((level) => {
        const match = this.authGroupMap.find((g: any) => g.authGroup === level);
        return match ? match.id : null;
      })
      .filter((id) => id !== null);
    const payload = {
      isUpdate: this.editIndex == -1 ? false : true,
      allProductFlag: this.selectedProduct == -1 ? true : false,
      authMatId: this.editAuth ? this.editIndex : null,
      companyId: this.loginCompanyId,
      productId: this.selectedProduct == -1 ? null : this.selectedProduct,
      subProductId: this.selectedSubProduct || null,
      authType: this.SelectedAuthType,
      isSequential: this.isSequential,
      isVerifier: this.isVerifier,
      isReleaser: this.isReleaser,
      currencyType: this.addCurrency,
      amount: Number(this.addAmount),
      oldAmount: Number(this.oldAmount),
      authGroupIds: authGroupIds,
      eventType: this.SelectedAuthType,
      category: BANK_CATERGORY_NAME
    };
    console.log(JSON.stringify(payload, null, 2));
    this.apiService.sendData(ADD_AUTH_MATRIX, payload).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          this.popupText = this.editIndex == -1 ? 'Authorisation Added' : 'Authorisation Updated';
          this.isPopupVisible = true;
          if (this.activeTab == '0')
            this.getIndiAuthMatrix();
          else
            this.getGroupedAuthMatrix();
          this.closeAddAuthf();
        }
        else {
          this.popupText = res.description;
          this.isPopupVisible = true;
        }
      },
      error: (err: any) => {
        if (err.status == 400) {
          this.popupText = err.error.message;
        }
        else
          this.popupText = 'Something Went Wrong...';
        this.isPopupVisible = true;
        console.error('ERROR', err);
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }


  toBankList() {
    this.getCompanyList();
    this.showAuthorisation = false;
  }
  closeAddAuthf() {
    // this.activeTab = '0';
    this.groupedRowIds = [];
    this.productData = [];
    this.subProductData = [];
    this.currentAuthMatId = null;
    this.showButtons = false;
    this.selectedProduct = null;
    this.selectedSubProduct = null;
    this.SelectedAuthType = '';
    this.subProductDisable = false;
    this.editIndex = -1;
    this.addAuthForm = false;
    this.showAuthorisation = true;
    this.viewAuth = false;
    this.editAuth = false;
    this.authLevelList = [];
    this.addCurrency = null;
    this.addAmount = '';
    this.oldAmount = '';
    this.isSequential = false;
    this.isVerifier = false;
    this.isReleaser = false;
  }

  validateAuth(): boolean {
    let errorCount = 0;

    // Reset all error flags
    this.typeError = false;
    this.productError = false;
    this.productTypeError = false;
    this.subProductTypeError = false;
    this.tenorError = false;
    this.currencyError = false;
    this.amountError = false;

    // Validate each field
    if (!this.SelectedAuthType || this.SelectedAuthType.trim() === '') {
      this.typeError = true;
      errorCount++;
    }

    if (!this.selectedProduct || this.selectedProduct === 0) {
      this.productError = true;
      errorCount++;
    }

    if (this.selectedProduct !== -1 && (!this.selectedSubProduct || this.selectedSubProduct === 0)) {
      this.subProductTypeError = true;
      errorCount++;
    }

    if (!this.addCurrency || this.addCurrency.trim() === '') {
      this.currencyError = true;
      errorCount++;
    }

    if (!this.addAmount || this.addAmount === '') {
      this.amountError = true;
      errorCount++;
    }

    return errorCount === 0; // true if no errors
  }

  isPopupVisible = false;
  popupText = '';
  hidePopup() {
    this.isPopupVisible = false;
    this.popupText = '';
  }
}
