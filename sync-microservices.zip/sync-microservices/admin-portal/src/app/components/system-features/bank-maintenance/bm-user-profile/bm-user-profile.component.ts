import {
  APPROVE_BANK_USER,
  FETCH_PRE_EXISTING_BANK_USER_BY_LOGIN_ID,
  GET_ALL_BANK,
  GET_ALL_COMPANIES,
  GET_ALL_DEPARTMENTS,
  GET_ALL_TEMP_BANK_USERS,
  GET_ALL_TEMP_BANK_USERS_BY_BANK_ID,
  GET_CATEGORY_BY_CATEGORY_NAME,
  GET_CATEGORY_BY_ID,
  GET_PRO_SUBPRO_MAP_BY_COMPANY_ID,
  GET_TEMP_BANK_USER_BY_ID,
  GET_USER_TYPE_BY_CATEGORY,
  REJECT_BANK_USER,
  RELID_APPROVE,
  SAVE_BANK_USERS,
  SEND_OTP,
  VALIDATE_OTP,
} from './../../../../constants/api_endpoints';
import {
  ChangeDetectorRef,
  Component,
  inject,
  OnInit,
  ɵsetUnknownElementStrictMode,
} from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from '../../../../commom/table/table.component';
import { ProductEntity } from '../../jurisdiction-maintenance/product-master/product-master.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { FloatLabelModule } from 'primeng/floatlabel';
import { TreeSelect } from 'primeng/treeselect';
import { TreeNode } from 'primeng/api';
import { LegalInfoDto } from '../../../../model/LegalInfoDto';
import { SelectModule } from 'primeng/select';
import COUNTRIES_DATA from '../../../../constants/Countries';
import { CompanyUser } from '../../../../model/CompanyUser';
import { ApiService } from '../../../../service/apiService/api.service';
import { SessionService } from './../../../../service/sessionService/session.service';

import {
  APPROVE_USER,
  CREATE_COMPANY_USER,
  GET_PRODUCTS_BY_COMPANY_ID,
  GET_TEMP_USER_BY_COMPANY_ID,
  GET_TEMP_USER_BY_ID,
  REJECT_USER,
  GET_USER_TYPE_BY_CATEGORY_ID,
  GET_AUTH_GROUPS,
  GET_ALL_TXN_COMPANIES,
  GET_ALL_TEMP_COMPANIES,
} from '../../../../constants/api_endpoints';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import {
  BANK_CATERGORY_ID,
  BANKSETUPCHECKER,
  BANKSETUPMAKER,
  BANKSUPERADMINCHECKER,
  BANKSUPERADMINMAKER,
  COMPANY_CATERGORY_ID,
  PAGE_SIZE,
  SUPERADMIN,
} from '../../../../constants/Constants';
import { BankUserDto } from '../../../../model/BankUser';
import { OfficeAddressDto } from '../../../../model/OfficeAddress';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  AuditCard,
  UserAuditComponent,
} from '../../../../commom/user-audit/user-audit.component';
import { OtpComponent } from '../../../../commom/otp/otp.component';

interface Role {
  userTypeId: number;
  userTypeName: string;
  userTypeNameLabel: string;
}

interface Department {
  id: number;
  departmentName: string;
  userTypes: Role[];
  departmentNameLabel: string;
}

@Component({
  selector: 'app-bm-user-profile',
  standalone: true,
  imports: [
    PageTitleComponent,
    NgIf,
    NgFor,
    NgClass,
    FormsModule,
    MultiSelectModule,
    FloatLabelModule,
    SelectModule,
    TblComponent,
    LoaderComponent,
    ToastComponent,
    UserAuditComponent,
    OtpComponent,
  ],
  templateUrl: './bm-user-profile.component.html',
  styleUrl: './bm-user-profile.component.css',
})
export class BmUserProfileComponent implements OnInit {
  isRelIdPopupOpen = false;
  relIdMessage = 'Waiting for RELID approval...';
  relIdPollingInterval: any;
  loginCompanyId: number | null = null;
  loginCompanyName = '';
  loginUserRole = '';
  loginUserName = '';
  loginUserId: number | null = null;
  role = '';
  roleList: Role[] = [];
  ogRoleList: Role[] = [];
  actionList: string[] = [];
  userId: number | null = null;
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  countryCodeList = [
    { label: 'India (+91)', value: '+91' },
    { label: 'USA (+1)', value: '+1' },
    { label: 'UK (+44)', value: '+44' },
    { label: 'UAE (+971)', value: '+971' },
    { label: 'Singapore (+65)', value: '+65' },
  ];

  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  private sessionService = inject(SessionService);

  constructor(private apiService: ApiService, private cdr: ChangeDetectorRef) {
    this.loginCompanyId = this.sessionService.getCompanyId() || null;
    this.loginUserRole = this.sessionService.getRole() || '';
    this.loginUserName = this.sessionService.getUsername() || '';
    this.loginUserId = this.sessionService.getUserId() || null;
    this.loginCompanyName = this.sessionService.getCompanyName() || '';
  }

  ngOnInit() {
    this.userEntity.contactNoCountryCode = '+91';
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER ||
      this.loginUserRole == BANKSETUPMAKER
    ) {
      this.actionList = ['view', 'edit', 'replicate', 'delete', 'audit'];
    } else if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINCHECKER ||
      this.loginUserRole == BANKSETUPCHECKER
    ) {
      this.actionList = ['view'];
    } else this.actionList = ['view'];
    this.getCategory();
    this.getDepartments();
    // this.getCompanyList();
    this.getTableData(); // Show user list directly
  }

  approveRejectAvailable(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINCHECKER ||
      this.loginUserRole == BANKSETUPCHECKER
    )
      return true;
    else return false;
  }
  addBtnAllowed(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER ||
      this.loginUserRole == BANKSETUPMAKER
    )
      return true;
    else return false;
  }

  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'BankProfileTable';

  getCompanyList() {
    // this.isLoading = true;
    // this.apiService
    //   .getData(
    //     GET_ALL_BANK +
    //     '?page=' +
    //     (this.pageNumber - 1) +
    //     '&size=' +
    //     this.pageSize,
    //     {}
    //   )
    //   .subscribe({
    //     next: (res: any) => {
    //       if (res.status == 'SUCCESS') {
    //         const companies = res['payload']['content'] || [];
    //         if (res.payload.page) {
    //           this.totalElements = res.payload.page.totalElements;
    //         }
    //         // Fetch all temp bank users to identify which banks have pending users
    //         this.apiService.getData(GET_ALL_TEMP_BANK_USERS, {}).subscribe({
    //           next: (userRes: any) => {
    //             let pendingBankIds = new Set<number>();
    //             if (userRes.status === 'SUCCESS') {
    //               const tempUsers = userRes.payload?.content || userRes.payload || [];
    //               tempUsers.forEach((u: any) => {
    //                 // Check for any pending status
    //                 if (u.status && (u.status === 'PENDING' || u.status.includes('Awaiting'))) {
    //                   pendingBankIds.add(u.bankId);
    //                 }
    //               });
    //             }
    //             this.customerData = companies.map((company: any) => {
    //               const hasPending = pendingBankIds.has(company.bankProfileId);
    //               return {
    //                 ...company,
    //                 status: hasPending ? 'PENDING' : (company.status || 'ACTIVE')
    //               };
    //             });
    //             this.ogData = [...this.customerData];
    //             this.isLoading = false;
    //           },
    //           error: (err: any) => {
    //             console.error('Failed to load temp users', err);
    //             this.customerData = companies.map((company: any) => ({
    //               ...company,
    //               status: company.status || 'ACTIVE'
    //             }));
    //             this.ogData = [...this.customerData];
    //             this.isLoading = false;
    //           }
    //         });
    //       } else {
    //         this.isLoading = false;
    //       }
    //     },
    //     error: (err: any) => {
    //       console.error('Failed to load companies', err);
    //       this.isLoading = false;
    //     }
    //   });
  }

  categoryId: number | null = null;
  getCategory() {
    this.apiService
      .getData(GET_CATEGORY_BY_ID + '?categoryId=' + BANK_CATERGORY_ID, {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.categoryId = res['payload']['categoryId'];
            // this.getUserType();
          } else {
            console.log(res.description);
          }
        },
        error: (err) => {
          console.log('Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  //main page vars
  searchAbbreviatedName = '';
  searchName = '';
  countryData = COUNTRIES_DATA;
  isLoading = false;
  searchData(): void {
    /*
    const filtered = this.ogData.filter((item) => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']
          ?.toLowerCase()
          .includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']
          ?.toLowerCase()
          .includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });
    */

    const filtered = this.ogData.filter((item) => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['abbvName']
            ?.toLowerCase()
            .includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['name']?.toLowerCase().includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated || matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  showUsers = false;
  // companyHeader = ['companyId', 'name', 'Action'];
  companyHeader: { key: string; value: string }[] = [
    { key: 'abbvName', value: 'Bank ID' },
    { key: 'name', value: 'Bank Name' },
    { key: 'status', value: 'status' },
    // { key: 'makerId', value: 'Maker' },
    { key: 'Action', value: 'Action' },
  ];

  customerData: any[] = [];
  ogData: any[] = [];
  currentCustomer = {};
  currentCustomerName: string = '';
  currentName: string = '';
  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    // this.bankId=row.bankProfileId;
    this.currentCustomerName = row['abbvName'] || '';
    // this.currentName = row['companyId'] || row['Company Name'] || '';
    this.loginCompanyId = row.bankProfileId;
    this.showUsers = true;
    this.pageNumber = 1;
    this.totalElements = 0;
    this.tableId = 'BankUserTable';
    this.getTableData();
  }

  searchLastName = '';
  searchFirstName = '';
  searchLoginId = '';
  searchSelectedProfileStatus = '';
  searchStatusList: string[] = [
    'Awaiting for Approval(D)',
    'Awaiting for Approval(M)',
    'Awaiting for Approval(N)',
    'Checker Returned(D)',
    'Checker Returned(M)',
    'Checker Returned(N)',
    'Draft(M)',
    'Draft(N)',
  ];
  searchSelectedStatus = '';

  userForm = false;
  editUser = false;
  viewUser = false;
  editUserIndex = -1;

  // userHeaders = ['First Name', 'Last Name', 'Status', 'Maker', 'Action'];
  userHeaders: { key: string; value: string }[] = [
    { key: 'loginId', value: 'User ID' },
    { key: 'firstName', value: 'First Name' },
    { key: 'lastName', value: 'Last Name' },
    { key: 'status', value: 'Status' },
    // { key: 'maker', value: 'Maker' },
    { key: 'Action', value: 'Action' },
    // { key: 'Audit', value: 'Audit-trail' },
  ];
  isAuditOpen = false;
  auditCards: any[] = [];
  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }

  auditFnc(row: any) {
    this.auditCards = this.createAuditCards(row);
    this.isAuditOpen = true;
  }
  createAuditCards(row: any) {
    const cards: any[] = [];
    if (row.makerName && row.createdAt) {
      cards.push({
        label: 'Maker',
        name: row.makerName,
        datetime: this.formatAuditDate(row.createdAt),
        status: 'completed',
      });
    }
    if (row.editorName && row.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: row.editorName,
        datetime: this.formatAuditDate(row.editedAt),
        status: 'completed',
      });
    }
    if (row.rejectedBy && row.rejectedAt) {
      cards.push({
        label: 'Rejected By',
        name: row.rejectedBy,
        datetime: this.formatAuditDate(row.rejectedAt),
        status: 'completed',
      });
      return cards; // stop here
    }
    if (row.checkerName && row.approvedAt) {
      cards.push({
        label: 'Approved By',
        name: row.checkerName,
        datetime: this.formatAuditDate(row.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  userOgData: any[] = [];
  userData = [...this.userOgData];

  searchUserf(): void {
    const filtered = this.userOgData.filter((item) => {
      const matchLastName = this.searchLastName
        ? item['Last Name']
            ?.toLowerCase()
            .includes(this.searchLastName.toLowerCase())
        : true;

      const matchFirstName = this.searchFirstName
        ? item['First Name']
            ?.toLowerCase()
            .includes(this.searchFirstName.toLowerCase())
        : true;

      const matchLoginId = this.searchLoginId
        ? item['LoginID']
            ?.toLowerCase()
            .includes(this.searchLoginId.toLowerCase())
        : true;

      const matchProfileStatus = this.searchSelectedProfileStatus
        ? item['Profile Status']
            ?.toLowerCase()
            .includes(this.searchSelectedProfileStatus.toLowerCase())
        : true;

      const matchStatus = this.searchSelectedStatus
        ? item['Status']
            ?.toLowerCase()
            .includes(this.searchSelectedStatus.toLowerCase())
        : true;

      return (
        matchLastName &&
        matchFirstName &&
        matchLoginId &&
        matchProfileStatus &&
        matchStatus
      );
    });

    this.userData = [...filtered];
  }
  userEntity: BankUserDto = new BankUserDto();
  addUserf() {
    // this.getDepartments();
    // this.onDepartmentChange();
    this.userEntity = new BankUserDto();
    this.userEntity.officeAddress = new OfficeAddressDto();
    this.userForm = true;
  }
  editUserf(row: BankUserDto, index: number) {
    // this.getDepartments();
    // this.onDepartmentChange();
    this.isLoading = true;
    this.userEntity = new BankUserDto();
    this.userEntity.officeAddress = new OfficeAddressDto();
    this.editUser = true;
    this.editUserIndex = index;
    this.userForm = true;
    if (row.bankUserId) this.getUserById(row.bankUserId);
    this.isLoading = false;
  }
  viewUserf(row: BankUserDto, index: number) {
    // this.isLoading=true;
    // this.getDepartments();
    // this.onDepartmentChange();
    console.log('row for view/edit:' + JSON.stringify(row, null, 2));
    this.userEntity = new BankUserDto();
    this.userEntity.officeAddress = new OfficeAddressDto();
    this.viewUser = true;
    this.userForm = true;
    this.editUserIndex = -1;
    if (row.bankUserId) this.getUserById(row.bankUserId);
    this.isLoading = false;
  }
  deleteUserf(row: any, index: number) {
    if (index >= 0 && index < this.userOgData.length) {
      this.userOgData.splice(index, 1);
    }
    this.userData = [...this.userOgData];
  }
  repliUser = false;
  replicateUser(row: any) {
    // this.getDepartments();
    console.log('row for replicate: ' + JSON.stringify(row, null, 2));
    this.isLoading = true;
    this.repliUser = true;
    this.userEntity = new BankUserDto();
    this.userEntity.officeAddress = new OfficeAddressDto();
    if (row.bankUserId) this.getUserById(row.bankUserId);
    this.isLoading = false;
  }
  assignReplicateValues() {
    let tempUser = new BankUserDto();
    tempUser.department = this.userEntity.department;
    tempUser.otherDept = this.userEntity.otherDept;
    tempUser.userTypeId = this.userEntity.userTypeId;
    tempUser.timeZone = this.userEntity.timeZone;
    tempUser.corrLanguage = this.userEntity.corrLanguage;
    tempUser.baseCurr = this.userEntity.baseCurr;
    tempUser.solId = this.userEntity.solId;
    tempUser.branchName = this.userEntity.branchName;
    tempUser.bankUserStatus = this.userEntity.bankUserStatus;
    tempUser.firstName = this.userEntity.firstName;
    tempUser.lastName = this.userEntity.lastName;
    tempUser.contactNo = this.userEntity.contactNo;
    tempUser.contactNoCountryCode = this.userEntity.contactNoCountryCode;
    tempUser.groupEmail = this.userEntity.groupEmail;
    tempUser.email = this.userEntity.email;
    console.log('temp user: ' + JSON.stringify(tempUser, null, 2));
    console.log('userEntity: ' + JSON.stringify(this.userEntity, null, 2));
    this.userEntity = new BankUserDto();
    this.userEntity = tempUser;
    this.userEntity.officeAddress = new OfficeAddressDto();
    this.userForm = true;
    this.repliUser = false; //now that the work is done reseting it
  }
  // addUserPage
  profileStatusList = ['Active', 'Inactive', 'Lock'];
  timeZoneList = ['Asia/Calcutta', 'America/Havana'];
  langaugeList: string[] = ['English(UK)', 'English(USA)', 'French', 'Arabic'];
  departmentList: Department[] = [];
  otherDepartmentValue: string = '';

  loginIDError = false;
  firstNameError = false;
  lastNameError = false;
  employeeNumberError = false;
  departmentError = false;
  otherDepartmentError = false;
  userTypeError = false;
  profileStatusError = false;
  timeZoneError = false;
  languageError = false;
  baseCurrencyError = false;
  solIdError = false;
  branchNameError = false;
  emailError = false;
  transactionNotificationError = false;

  popupText = '';
  popupVisible = false;
  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }

  otherDepartment = false;
  onDepartmentChange() {
    const selectedDept = this.departmentList.find((element: Department) => {
      return element.departmentName == this.userEntity.department;
    });
    this.roleList = selectedDept ? [...selectedDept.userTypes] : [];
    if (!this.editUser && !this.viewUser && !this.repliUser)
      this.userEntity.userTypeId = null;
  }
  getUserById(userId: number) {
    this.apiService
      .getData(GET_TEMP_BANK_USER_BY_ID + '?id=' + userId, {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            let tempUser = BankUserDto.jsonToObject(res.payload);
            if (
              !this.departmentList.some(
                (d) => d.departmentName === tempUser.department
              )
            ) {
              this.otherDepartment = true;
              tempUser.otherDept = tempUser.department;
              tempUser.department = 'Other';
            }
            this.userEntity.officeAddress = new OfficeAddressDto();
            this.userEntity = tempUser;
            this.onDepartmentChange();
            if (this.repliUser) this.assignReplicateValues();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getTableData() {
    this.isLoading = true;
    let url = '';
    if (this.loginCompanyId) {
      url =
        GET_ALL_TEMP_BANK_USERS_BY_BANK_ID +
        '?bankProfileId=' +
        this.loginCompanyId;
    } else {
      url = GET_ALL_TEMP_BANK_USERS;
    }

    this.apiService
      .getData(
        url +
          (url.includes('?') ? '&' : '?') +
          'page=' +
          (this.pageNumber - 1) +
          '&size=' +
          this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            const rawData = res['payload']['content'] || [];
            this.userData = rawData.map((user: any) => ({
              ...user,
              'First Name': user.firstName,
              'Last Name': user.lastName,
              'Profile Status': user.profileStatus,
              Status: user.status || 'Draft(N)',
              Maker: user.maker || '',
              LoginID: user.loginId,
            }));
            this.userOgData = [...this.userData];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  saveUser() {
    console.log('Inside SaveUser');
    if (!this.validateUser()) return;
    this.isLoading = true;
    if (this.editUserIndex == -1) {
      this.userEntity.isUpdate = false;
      this.userEntity.bankUserId = null; // Ensure ID is null for new users so backend generates it
    } else {
      this.userEntity.isUpdate = true;
    }
    this.userEntity.bankId = this.loginCompanyId;
    // this.userEntity.bankUserId = this.loginCompanyId; // REMOVED: bankUserId should not be set to bankProfileId
    // this.userEntity.userTypeId = 23; // REMOVED: Should use value from dropdown

    // console.log(
    //   'bankUser payload: ' + JSON.stringify(this.userEntity, null, 2)
    // );
    const actionRole = this.editUserIndex === -1 ? 'CREATE' : 'EDIT';

    this.apiService
      .sendData(SAVE_BANK_USERS, BankUserDto.objectToJson(this.userEntity), {
        'X-ACTION-ROLE': actionRole,
      })
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              this.editUserIndex == -1
                ? 'User created successfully'
                : 'User updated successfully'
            );
            this.getTableData();
            this.toUsersPage();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err: any) => {
          console.error('API ERROR:', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  approveRejectForm(action: string) {
    this.isLoading = true;
    const url = action === 'approve' ? APPROVE_BANK_USER : REJECT_BANK_USER;
    const actionRole = action === 'approve' ? 'APPROVE' : 'REJECT';
    this.apiService
      .sendData(
        url + '?bankUserId=' + this.userEntity.bankUserId,
        {},
        {
          'X-ACTION-ROLE': actionRole,
        }
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.getTableData();
            this.toUsersPage();
            this.showToast(
              'success',
              'Success',
              action === 'approve'
                ? 'User Profile Approved'
                : 'User Profile Rejected'
            );
            this.checkerAction = '';
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  startRelIdApproval(action: string) {
    this.checkerAction = action;

    this.isRelIdPopupOpen = true;
    this.relIdMessage = 'Waiting for RELID approval...';

    this.pollRelIdStatus();
  }
  // startRelIdApproval(action: string) {
  //   this.checkerAction = action;
  //   // Open popup
  //   this.isRelIdPopupOpen = true;
  //   this.relIdMessage = `Waiting for RELID ${action} approval...`;
  //   // Simulate API waiting time
  //   setTimeout(() => {
  //     // Close popup after 3 sec
  //     this.isRelIdPopupOpen = false;
  //     // Continue actual process
  //     this.approveRejectForm(this.checkerAction);
  //   }, 3000);
  // }

  pollRelIdStatus() {
    // this.approveRejectForm(this.checkerAction);
    this.apiService
      .sendData(RELID_APPROVE + '?ecn=' + this.loginUserId, {})
      .subscribe({
        next: (res) => {
          console.log(res);
          if (res.payload === 'success') {
            this.approveRejectForm(this.checkerAction);
            this.isRelIdPopupOpen = false;
          }
        },
        error: (err) => {
          console.error(err);
          this.isRelIdPopupOpen = false;
        },
      });
    // this.relIdPollingInterval = setInterval(() => {
    // this.apiService
    //   .getData(RELID_STATUS_API + '?companyId=' + this.company.companyId, {})
    //   .subscribe({
    //     next: (res: any) => {
    //       if (res.status === 'SUCCESS') {
    //         clearInterval(this.relIdPollingInterval);

    //         this.isRelIdPopupOpen = false;

    //         // Continue approval process
    //         this.approveRejectForm(this.checkerAction);
    //       } else if (res.status === 'REJECTED') {
    //         clearInterval(this.relIdPollingInterval);

    //         this.isRelIdPopupOpen = false;

    //         this.showToast(
    //           'error',
    //           'RELID Rejected',
    //           res.description || 'RELID approval rejected'
    //         );
    //       }

    //       // If pending → do nothing and continue polling
    //     },
    //     error: () => {
    //       clearInterval(this.relIdPollingInterval);

    //       this.isRelIdPopupOpen = false;

    //       this.showToast('error', 'Error', 'Failed to verify RELID approval');
    //     },
    //   });
    // }, 3000); // every 3 sec
  }

  toBankList() {
    this.pageNumber = 1;
    this.totalElements = 0;
    this.tableId = 'BankProfileTable';
    this.getCompanyList();
    this.showUsers = true;
  }
  toUsersPage() {
    this.userEntity = new BankUserDto();
    this.userForm = false;
    this.showUsers = false;
    this.editUser = false;
    this.viewUser = false;
    this.editUserIndex = -1;

    this.loginIDError = false;
    this.firstNameError = false;
    this.lastNameError = false;
    this.employeeNumberError = false;
    this.departmentError = false;
    this.otherDepartmentError = false;
    this.userTypeError = false;
    this.profileStatusError = false;
    this.timeZoneError = false;
    this.languageError = false;
    this.baseCurrencyError = false;
    this.solIdError = false;
    this.branchNameError = false;
    this.emailError = false;
    this.transactionNotificationError = false;
  }

  validateUser(): Boolean {
    console.log('Inside validateUser');
    let errorCount = 0;
    if (!this.userEntity.loginId) {
      console.log('validationfailed for loginId');
      this.loginIDError = true;
      errorCount++;
    }
    if (!this.userEntity.firstName) {
      console.log('validationfailed for firstName');
      this.firstNameError = true;
      errorCount++;
    }
    if (!this.userEntity.lastName) {
      console.log('validationfailed for lastName');
      this.lastNameError = true;
      errorCount++;
    }
    if (!this.userEntity.bankUserStatus) {
      console.log('validationfailed for bankUserStatus');
      this.profileStatusError = true;
      errorCount++;
    }
    // if (!this.userEntity.timeZone) {
    //   console.log('validationfailed for timeZone');
    //   this.timeZoneError = true;
    //   errorCount++;
    // }

    // if (!this.userEntity.corrLanguage) {
    //   console.log('validationfailed for corrLanguage');
    //   this.languageError = true;
    //   errorCount++;
    // }

    // if (!this.userEntity.baseCurr) {
    //   console.log('validationfailed for baseCurr');
    //   this.baseCurrencyError = true;
    //   errorCount++;
    // }

    if (!this.userEntity.department) {
      console.log('validationfailed for department');
      this.departmentError = true;
      errorCount++;
    }
    if (this.userEntity.department == 'Other' && !this.userEntity.otherDept) {
      console.log('validationfailed for otherDepartmentValue');
      this.otherDepartmentError = true;
      errorCount++;
    }

    if (!this.userEntity.userTypeId) {
      console.log('validationfailed for userType');
      this.userTypeError = true;
      errorCount++;
    }

    if (!this.userEntity.email) {
      console.log('validationfailed for email');
      this.emailError = true;
      errorCount++;
    }
    if (errorCount > 0) return false;
    return true;
  }

  // department user type functions
  getDepartments() {
    this.apiService.getData(GET_ALL_DEPARTMENTS, {}).subscribe({
      next: (res) => {
        if (res.status === 'SUCCESS') {
          this.departmentList = res.payload;
        }
      },
    });
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'BankProfileTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getCompanyList();
    } else if (event.tableId === 'BankUserTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    }
  }

  // OTP FUNCTIONS
  isOtpOpen = false;
  otpReference: string = '';
  tempReceivedOtp = '';
  checkerAction: string = '';
  sendOtp(action: string) {
    this.checkerAction = action;
    this.isOtpOpen = true;
    const payload = {
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
    };
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      },
    });
  }

  onOtpResend() {
    const payload = {
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
      otpReference: this.otpReference,
    };
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status) {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      },
    });
  }

  validateOtp(otp: string) {
    const payload = {
      otpReference: this.otpReference,
      enteredOtp: this.tempReceivedOtp, //REPLACE THIS AFTERWARD WITH otp varaible
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
    };
    this.apiService.sendData(VALIDATE_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          // TODO: if the otp is validate call onOtpVerify
          // this.isOtpOpen = false;
          // this.approveRejectForm(this.checkerAction);
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      },
    });
    this.approveRejectForm(this.checkerAction);
    this.isOtpOpen = false;
  }

  closeOtpPopup() {
    this.isOtpOpen = false;
    this.otpReference = '';
    this.tempReceivedOtp = '';
  }

  // FETCH PREEXISITNG COMPANY DEATAIS USING CIF
  fetchPreExistingDetailsByPulseId() {
    this.isLoading = true;
    this.apiService
      .getData(
        FETCH_PRE_EXISTING_BANK_USER_BY_LOGIN_ID +
          '?pulseId=' +
          this.userEntity.loginId,
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.userEntity = res.payload;
            this.userEntity.bankUserStatus = res.payload.status;
            this.userEntity.department = res.payload.employeeDepartment;
            this.userEntity.contactNoCountryCode = '+91';
            this.onDepartmentChange();
          } else {
            this.showToast('error', 'Error', res.message);
            this.isLoading = false;
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
          this.isLoading = false;
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
}
