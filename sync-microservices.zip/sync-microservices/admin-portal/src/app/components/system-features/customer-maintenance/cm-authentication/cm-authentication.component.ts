import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgFor, NgIf, NgStyle } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../../commom/table/table.component";
@Component({
  selector: 'app-cm-authentication',
  imports: [PageTitleComponent, NgIf, NgFor, FormsModule, TableComponent],
  templateUrl: './cm-authentication.component.html',
  styleUrl: './cm-authentication.component.css'
})
export class CmAuthenticationComponent {

  //main page vars--------------------------
  searchAbbreviatedName = '';
  searchName = '';

  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']?.toLowerCase().includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']?.toLowerCase().includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  
  showAuthentication = false;
  customerHeader = ['Abbreviated Name', 'Company Name', 'Action'];
  customerData: any[] = [
    {
      "Abbreviated Name": "10937234",
      "Company Name": "Big4U"
    },
    {
      "Abbreviated Name": "10943234",
      "Company Name": "Test Name"
    },
    {
      "Abbreviated Name": "10918234",
      "Company Name": "Tushar"
    },
  ];

  ogData = this.customerData;
  
  customerColumnWidth = ['40%', '50%', '10%'];
  currentCustomer = {};
  currentCustomerName: string = '';
  currentName: string = '';
  loginName: string = '';
  fullName: string = '';

  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentCustomerName = row['Abbreviated Name'] || '';
    this.currentName = row['Company Name'] || '';
    this.loginName = row['Login'] || '';
    this.fullName = row['First Name'] + row['Last Name'] || '';
    this.showAuthentication = true;
  }


  //customer auth page vars----------------------------
  searchFirstName = '';
  searchLastName = '';
  searchLogin = '';

  searchStatusList: string[] = ['Awaiting for Approval(D)', 'Awaiting for Approval(M)', 'Awaiting for Approval(N)', 'Awaiting for Approval(User Authentication Modified', 'Checker Returned(D)', 'Checker Returned(M)', 'Checker Returned(N)', 'Draft(M)', 'Draft(N)'];
  selectedSearchStatus = '';
  searchProfileStatusList: string[] = ['Active', 'Inactive', 'Lock'];
  selectedSearchProfileStatus = '';

  addAuthenForm = false;
  viewAuthen = false;
  editAuthen = false;
  editIndex = -1;

  authHeaders = ['First Name', 'Last Name', 'Login', 'Profile Status', 'Status', 'Maker User', 'Action']

  authColWidth = [
    '8%',
    '6%',
    '6%',
    '8%',
    '12%',
    '8%',
    '8%',
    '8%',
    '8%',
    '8%',
    '8%',
    '6%',
    '6%'
  ];

  authData: any[] = [
    {
      "First Name": "ABC",
      "Last Name": "Company",
      "Login": "TEST",
      "Profile Status": "Active",
      "Status": "Draft(M)",
      "Maker User": "JohnDoe",
    },
    {
      "First Name": "Meta",
      "Last Name": "Company",
      "Login": "TEST 1",
      "Profile Status": "Active",
      "Status": "Draft(M)",
      "Maker User": "Tushar",
    },
    {
      "First Name": "Apple",
      "Last Name": "Tech",
      "Login": "TEST 2",
      "Profile Status": "Inactive",
      "Status": "Draft(M)",
      "Maker User": "Tushar M",
    }
  ]
  ogAuthData = this.authData;


  searchAuth(): void {
    const filtered = this.ogAuthData.filter(item => {

      const matchFirstName = this.searchFirstName
        ? item['First Name']?.toLowerCase().includes(this.searchFirstName.toLowerCase())
        : true;

      const matchLastName = this.searchLastName
        ? item['Last Name']?.toLowerCase().includes(this.searchLastName.toLowerCase())
        : true;

      const matchLogin = this.searchLogin
        ? item['Login']?.toLowerCase().includes(this.searchLogin.toLowerCase())
        : true;

      const matchStatus = this.selectedSearchStatus
        ? item['Status']?.toLowerCase().includes(this.selectedSearchStatus.toLowerCase())
        : true;

      const matchProfileStatus = this.selectedSearchProfileStatus
        ? item['Profile Status']?.toLowerCase().trim() == this.selectedSearchProfileStatus.toLowerCase().trim()
        : true;

      return matchFirstName && matchLastName && matchLogin && matchStatus && matchProfileStatus;
    });

    this.authData = [...filtered]; // ✅ Update reference for change detection
  }

  // addAuthF() {
  //   // this.showAuthorisation = false;
  //   this.showAuthentication = false;
  //   this.addAuthenForm = true;
  // }

  viewAuthF(row: any, index: number) {
    this.viewAuthen = true;
    this.editAuthen = false;
    this.assignAddPageData(row);
  }

  editAuthF(row: any, index: number) {
    this.editAuthen = true;
    this.viewAuthen = true;
    this.assignAddPageData(row);
    this.editIndex = index;
  }

  assignAddPageData(row: any) {
    this.currentName = row['Company Name'] || '';
    this.loginName = row['Login'] || '';
    this.fullName = row['First Name'] + " " + row['Last Name'] || '';
  }

  deleteAuthF(index: number): void {
    if (index >= 0 && index < this.authData.length) {
      this.authData.splice(index, 1);
      this.authData = [...this.authData]; // ✅ Update reference for change detection
    }
  }

  // addAuth form vars
  loginError = false;
  fullNameError = false;
  isPopupVisible = false;

  saveAuthen(): void {
    if (!this.validateAuth())
      return;
    this.showAuthentication = true;
    this.editAuthen = false;
    this.viewAuthen = false;

    // Prepare the values to persist
    const first = (this.fullName ?? '').trim().split(' ')[0] ?? '';
    const last = (this.fullName ?? '').trim().split(' ').slice(1).join(' ') ?? '';

    const authDataNew: { [key: string]: any } = {
      'Login': this.loginName ?? "",
      'First Name': first,
      'Last Name': last,
    };
 
 // Merge into the existing row
  const existingRow = this.authData[this.editIndex];
  this.authData=[...this.authData];
  const updatedRow = { ...existingRow, ...authDataNew };

  // Immutably update array to trigger change detection
  this.authData = this.authData.map((row, i) => (i === this.editIndex ? updatedRow : row));

  // Exit edit mode
  this.editIndex = 0;
  this.isPopupVisible = true; 

  }

  toAuthenPage() {
    this.editAuthen = false;
    this.viewAuthen = false;
    this.showAuthentication = true;
    this.clearEditAuthenPage();
  }

  clearEditAuthenPage() {
    this.fullName = "";
    this.loginName = "";
  }
  
  validateAuth(): boolean {
    let errorCount = 0;

    // Reset all error flags
    this.loginError = false;
    this.fullNameError = false;

   // Validate each field
    if (!this.loginName || this.loginName.trim() === '') {
      this.loginError = true;
      errorCount++;
    }

    if (!this.fullName || this.fullName.trim() === '') {
      this.fullNameError = true;
      errorCount++;
    }

    return errorCount === 0; // true if no errors
  }

  hidePopup() {
    this.isPopupVisible = false;
  }

}
