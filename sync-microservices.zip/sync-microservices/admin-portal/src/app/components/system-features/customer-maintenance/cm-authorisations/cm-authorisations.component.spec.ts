import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmAuthorisationsComponent } from './cm-authorisations.component';

describe('CmAuthorisationsComponent', () => {
  let component: CmAuthorisationsComponent;
  let fixture: ComponentFixture<CmAuthorisationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CmAuthorisationsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmAuthorisationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
