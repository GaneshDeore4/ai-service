import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmEntitiesComponent } from './cm-entities.component';

describe('CmEntitiesComponent', () => {
  let component: CmEntitiesComponent;
  let fixture: ComponentFixture<CmEntitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CmEntitiesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmEntitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
