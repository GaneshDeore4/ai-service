import { Component, OnInit } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgClass, NgFor, NgIf } from '@angular/common';
import { TableComponent } from "../../../../commom/table/table.component";
import { FormsModule } from '@angular/forms';
import { PopupComponent } from "../../../../commom/popup/popup.component";
import { ActivatedRoute, Router } from '@angular/router';
import { SessionService } from '../../../../service/sessionService/session.service';
import { DataTransferService } from '../../../../service/dataTransferService/data-transfer.service';

@Component({
  selector: 'app-cm-entities',
  imports: [PageTitleComponent, NgIf, NgFor, TableComponent, FormsModule, NgClass, PopupComponent],
  templateUrl: './cm-entities.component.html',
  styleUrl: './cm-entities.component.css'
})
export class CmEntitiesComponent implements OnInit {

  role='';
  queryParam='';
  constructor(private activatedRoute:ActivatedRoute,private sessionService:SessionService, private dataTranferService:DataTransferService,private router:Router){
    this.role = sessionService.getRole();
  }

  ngOnInit(){
        //this is getting received from pendingEntites page
        this.activatedRoute.queryParamMap.subscribe(params => {
        this.queryParam=params.get('action') || '';
        if(this.queryParam=='checker'){
          this.viewEntityf(this.dataTranferService.getData(),0);
      }
      });
  }


  //main page vars
  searchAbbreviatedName = '';
  searchName = '';
  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']?.toLowerCase().includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']?.toLowerCase().includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  showEntities = false;
  customerHeader = ['Abbreviated Name', 'Company Name', 'Action'];
  customerData: any[] = [
    {
      "Abbreviated Name": "10937234",
      "Company Name": "Big4U"
    },
    {
      "Abbreviated Name": "10943234",
      "Company Name": "Test Name"
    },
  ];
  ogData = this.customerData;
  customerColumnWidth = ['40%', '50%', '10%'];
  currentCustomer = {};
  currentCustomerName: string = '';
  currentName: string = '';
  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentCustomerName = row['Abbreviated Name'] || '';
    this.currentName = row['Company Name'] || '';
    this.showEntities = true;
  }



  // entity page vars
  searchEntityid = '';
  seachEntityName = '';
  statusList: string[] = ['Awaiting for Approval(D)', 'Awaiting for Approval(M)', 'Awaiting for Approval(N)', 'Checker Returned(D)', 'Checker Returned(M)', 'Checker Returned(N)', 'Draft(M)', 'Draft(N)'];
  selectedStatus = '';
  entityHeaders = ['Entity ID', 'Entity Name', 'Legal ID No', 'Status', 'Maker User', 'Action'];
  entityColumnWidth = ['10%', '20%', '20%', '20%', '20%', '10%'];
  entityData: any[] = [
    {
      "personalCheckbox": false,
      "selectedLegalIDType": "ROB",
      "Legal ID No": "LID12345",
      "country": "India",
      "Entity ID": "ENT001",
      "Entity Name": "ABC Corporation",
      "chargeAccAddress": "123 Finance Street",
      "streetName": "Finance Street",
      "town": "Mumbai",
      "countrySubdiv": "Maharashtra",
      "postCode": "400001",
      "alternateAdd": "Alternate Address",
      "countryCode": "IN",
      "BEISWIFT": "ABCINBBXXX",
      "email": "abc@example.com",
      "contactNumber": "+91-9876543210",
      "contactPerson": "John Doe",
      "authOwnTran": true,
      "bulkAuthLimitPay": false,
      "autoFrData": true,
      "checkFileHash": false,
      "checkDupFile": true,
      "checkDupCr": false,
      "FileUploadEncMethod": "AES256",
      "nonAmendableFileType": "PDF",
      "mergeDeleteAllowed": true,
      "amendableFileTypes": "CSV, XLSX",
      "Status": "Active",
      "Maker User": "AdminUser",
      "remarks": "Test entity data",
      "addEntityRoles": true
    },
    {
      "personalCheckbox": true,
      "selectedLegalIDType": "ROS",
      "Legal ID No": "LID67890",
      "country": "USA",
      "Entity ID": "ENT002",
      "Entity Name": "XYZ Ltd",
      "chargeAccAddress": "456 Wall Street",
      "streetName": "Wall Street",
      "town": "New York",
      "countrySubdiv": "NY",
      "postCode": "10005",
      "alternateAdd": "Alternate Address 2",
      "countryCode": "US",
      "BEISWIFT": "XYZUSBBXXX",
      "email": "xyz@example.com",
      "contactNumber": "+1-1234567890",
      "contactPerson": "Jane Smith",
      "authOwnTran": false,
      "bulkAuthLimitPay": true,
      "autoFrData": false,
      "checkFileHash": true,
      "checkDupFile": false,
      "checkDupCr": true,
      "FileUploadEncMethod": "RSA2048",
      "nonAmendableFileType": "DOCX",
      "mergeDeleteAllowed": false,
      "amendableFileTypes": "TXT, XLS",
      "Status": "Inactive",
      "Maker User": "SystemUser",
      "remarks": "Second entity data",
      "addEntityRoles": false
    }
  ];
  ogEntityData = [...this.entityData];
  searchEntity(): void {
    const filtered = this.ogEntityData.filter(item => {
      const matchsearchEntityid = this.searchEntityid
        ? item['Entity ID']?.toLowerCase().includes(this.searchEntityid.toLowerCase())
        : true;

      const matchseachEntityName = this.seachEntityName
        ? item['Entity Name']?.toLowerCase().includes(this.seachEntityName.toLowerCase())
        : true;

      const matchselectedStatus = this.selectedStatus
        ? item['Status']?.toLowerCase().includes(this.selectedStatus.toLowerCase())
        : true;

      return matchsearchEntityid && matchseachEntityName && matchselectedStatus;
    });

    // ✅ Update reference so child detects change
    this.entityData = [...filtered];
  }
  addEntityPage = false;
  editEntityIndex = -1;
  editEntity = false;
  viewEntity = false;
  addEntityf() {
    this.addEntityPage = true;
    this.editEntityIndex = -1;
    this.saveEntity();
  }
  viewEntityf(row: any, index: number) {
    this.assignEntityData(row);
    this.viewEntity = true;
    this.addEntityPage = true;

  }
  editEntityf(row: any, index: number) {
    this.editEntityIndex = index;
    this.assignEntityData(row);
    this.addEntityPage = true;
    this.editEntity = true;
  }
  deleteEntityf(index: number) {
    if (index >= 0 && index < this.entityData.length) {
      this.entityData.splice(index, 1);
      this.entityData = [...this.entityData];
    }
  }
  approveRejectEntityf(action:string){
    if(action=='approve'){
      this.popupText='Costumer Entity Approved';
    }
    else if(action=='return'){
      this.popupText='Costumer Entity Returned';
    }
    else{
      this.popupText='Costumer Entity Rejected';
    }
    this.popupVisible=true;
  }


  validateEntity(): boolean {
    let errorCount = 0;

    // Reset all error flags before validation
    this.entityIDError = false;
    this.entityNameError = false;
    this.chargeAccAddressError = false;
    this.countryCodeError = false;
    this.contactPersonError = false;

    if (this.entityID === '') {
      this.entityIDError = true;
      errorCount++;
    }

    if (this.entityName === '') {
      this.entityNameError = true;
      errorCount++;
    }

    if (this.chargeAccAddress === '') {
      this.chargeAccAddressError = true;
      errorCount++;
    }

    if (this.countryCode === '') {
      this.countryCodeError = true;
      errorCount++;
    }

    if (this.contactPerson === '') {
      this.contactPersonError = true;
      errorCount++;
    }

    return errorCount === 0;
  }

  popupVisible = false;
  popupText='';
  hidePopup() {
    this.popupVisible = false;
    this.popupText='';
    this.toEntityPage();
  }
  saveEntity(): void {
    if (!this.validateEntity())
      return;
    this.popupVisible = true;
    this.popupText='Customer Entity Saved';

    const entity = {
      "personalCheckbox": this.personalCheckbox,
      "selectedLegalIDType": this.selectedLegalIDType,
      "Legal ID No": this.legalIDNo,
      "country": this.country,
      "Entity ID": this.entityID,
      "Entity Name": this.entityName,
      "chargeAccAddress": this.chargeAccAddress,
      "streetName": this.streetName,
      "town": this.town,
      "countrySubdiv": this.countrySubdiv,
      "postCode": this.postCode,
      "alternateAdd": this.alternateAdd,
      "countryCode": this.countryCode,
      "BEISWIFT": this.BEISWIFT,
      "email": this.email,
      "contactNumber": this.contactNumber,
      "contactPerson": this.contactPerson,
      "authOwnTran": this.authOwnTran,
      "bulkAuthLimitPay": this.bulkAuthLimitPay,
      "autoFrData": this.autoFrData,
      "checkFileHash": this.checkFileHash,
      "checkDupFile": this.checkDupFile,
      "checkDupCr": this.checkDupCr,
      "FileUploadEncMethod": this.FileUploadEncMethod,
      "nonAmendableFileType": this.nonAmendableFileType,
      "mergeDeleteAllowed": this.mergeDeleteAllowed,
      "amendableFileTypes": this.amendableFileTypes,
      "Status": this.formStatus,
      "Maker User": this.maker,
      "remarks": this.remarks,
      "addEntityRoles": this.addEntityRoles
    };

    if (this.editEntityIndex === -1) {
      // ✅ Add new entity
      this.entityData = [...this.entityData, entity];
    } else {
      // ✅ Edit existing entity
      this.entityData[this.editEntityIndex] = entity;
      this.entityData = [...this.entityData]; // Update reference for Angular change detection
      this.editEntityIndex = -1; // Reset edit mode
    }
   this.toEntityPage();
  }



  assignEntityData(row: any): void {
    this.personalCheckbox = row['personalCheckbox'] || false;
    this.selectedLegalIDType = row['selectedLegalIDType'] || '';
    this.legalIDNo = row['Legal ID No'] || '';
    this.country = row['country'] || '';
    this.entityID = row['Entity ID'] || '';
    this.entityName = row['Entity Name'] || '';
    this.chargeAccAddress = row['chargeAccAddress'] || '';
    this.streetName = row['streetName'] || '';
    this.town = row['town'] || '';
    this.countrySubdiv = row['countrySubdiv'] || '';
    this.postCode = row['postCode'] || '';
    this.alternateAdd = row['alternateAdd'] || '';
    this.countryCode = row['countryCode'] || '';
    this.BEISWIFT = row['BEISWIFT'] || '';
    this.email = row['email'] || '';
    this.contactNumber = row['contactNumber'] || '';
    this.contactPerson = row['contactPerson'] || '';
    this.authOwnTran = row['authOwnTran'] || false;
    this.bulkAuthLimitPay = row['bulkAuthLimitPay'] || false;
    this.autoFrData = row['autoFrData'] || false;
    this.checkFileHash = row['checkFileHash'] || false;
    this.checkDupFile = row['checkDupFile'] || true;
    this.checkDupCr = row['checkDupCr'] || false;
    this.FileUploadEncMethod = row['FileUploadEncMethod'] || '';
    this.nonAmendableFileType = row['nonAmendableFileType'] || '';
    this.mergeDeleteAllowed = row['mergeDeleteAllowed'] || false;
    this.amendableFileTypes = row['amendableFileTypes'] || '';
    this.formStatus = row['Status'] || '';
    this.maker = row['Maker User'] || '';
    this.remarks = row['remarks'] || '';
    this.addEntityRoles = row['addEntityRoles'] || false;
  }



  // add entity page vars
  personalCheckbox = false;
  legalIDTypeList = ['ROB', 'ROS', 'ROC'];
  selectedLegalIDType = '';
  legalIDNo = '';
  country = '';
  entityID = '';
  entityName = '';
  chargeAccAddress = '';
  streetName = '';
  town = '';
  countrySubdiv = '';
  postCode = '';
  alternateAdd = '';
  countryCode = '';
  BEISWIFT = '';
  email = '';
  contactNumber = '';
  contactPerson = '';
  authOwnTran = false;
  bulkAuthLimitPay = false;
  autoFrData = false;
  checkFileHash = false;
  checkDupFile = true;
  checkDupCr = false;
  FileUploadEncMethod = '';
  nonAmendableFileType = '';
  mergeDeleteAllowed = false;
  amendableFileTypes = '';
  formStatus = '';
  maker = '';
  remarks = '';
  addEntityRoles = false;//logic and vars for this is at the bottom for this is

  entityIDError = false;
  entityNameError = false;
  chargeAccAddressError = false;
  countryCodeError = false;
  contactPersonError = false;

  toEntityPage() {
    this.clearAddEntityPage();
    if(this.queryParam=='checker'){
      this.dataTranferService.setData({});
      this.router.navigate(['/content/pending-entities']);
    }
    else{
      this.addEntityPage = false;
    } 
  }
  clearAddEntityPage() {
    this.personalCheckbox = false;
    this.legalIDTypeList = ['ROB', 'ROS', 'ROC'];
    this.selectedLegalIDType = '';
    this.legalIDNo = '';
    this.country = '';
    this.entityID = '';
    this.entityName = '';
    this.chargeAccAddress = '';
    this.streetName = '';
    this.town = '';
    this.countrySubdiv = '';
    this.postCode = '';
    this.alternateAdd = '';
    this.countryCode = '';
    this.BEISWIFT = '';
    this.email = '';
    this.contactNumber = '';
    this.contactPerson = '';
    this.authOwnTran = false;
    this.bulkAuthLimitPay = false;
    this.autoFrData = false;
    this.checkFileHash = false;
    this.checkDupFile = true;
    this.checkDupCr = false;
    this.FileUploadEncMethod = '';
    this.nonAmendableFileType = '';
    this.mergeDeleteAllowed = false;
    this.amendableFileTypes = '';
    this.formStatus = '';
    this.maker = '';
    this.remarks = '';
    this.addEntityRoles = false; // logic and vars for this is at the bottom for this is

    this.entityIDError = false;
    this.entityNameError = false;
    this.chargeAccAddressError = false;
    this.countryCodeError = false;
    this.contactPersonError = false;
    this.selectedList1E = [];
    this.selectedList2E = [];
    this.editEntityIndex = -1;
    this.editEntity = false;
    this.viewEntity = false;
  }


  // transfer logic for entity roles:
  list1E: string[] = [
    'Bulk File Upload',
    'Bulk Manual Collection',
    'Bulk Manual Payment - Sender',
    'Bulk Manual Payment - Receiver',
    'Entity Profile Management',
    'Entity Role Assignment',
    'Entity Access Control',
    'Bulk Transaction Approval',
    'Bulk Transaction Reversal',
    'Entity Audit and Compliance'
  ];


  list2E: string[] = [];

  selectedList1E: string[] = [];
  selectedList2E: string[] = [];

  toggleSelectionE(item: string, list: 'list1E' | 'list2E') {
    if (list === 'list1E') {
      this.selectedList1E.includes(item)
        ? this.selectedList1E = this.selectedList1E.filter(i => i !== item)
        : this.selectedList1E.push(item);
    } else {
      this.selectedList2E.includes(item)
        ? this.selectedList2E = this.selectedList2E.filter(i => i !== item)
        : this.selectedList2E.push(item);
    }
  }

  addItemsE() {
    this.list2E.push(...this.selectedList1E);
    this.list1E = this.list1E.filter(item => !this.selectedList1E.includes(item));
    this.selectedList1E = [];
  }

  removeItemsE() {
    this.list1E.push(...this.selectedList2E);
    this.list2E = this.list2E.filter(item => !this.selectedList2E.includes(item));
    this.selectedList2E = [];
  }

  defaultItemsE() {
    this.list2E.push(...this.list1E);
    this.list1E = [];
    this.selectedList1E = [];
  }
}
