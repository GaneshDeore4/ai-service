import { Component, NgModule, ViewChild, ElementRef } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { PopupComponent } from '../../../../commom/popup/popup.component';
import { TableComponent } from '../../../../commom/table/table.component';
import { FormsModule } from '@angular/forms';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';


@Component({
  selector: 'app-cm-file-upload',
  imports: [PageTitleComponent, PopupComponent, TableComponent, NgClass, NgIf, NgFor, FormsModule, MatDatepickerModule, MatFormFieldModule, MatInputModule, MatNativeDateModule],
  templateUrl: './cm-file-upload.component.html',
  styleUrl: './cm-file-upload.component.css'
})
export class CmFileUploadComponent {

  //main page vars--------------------------
  searchAbbreviatedName = '';
  searchName = '';
  value3 = '';

  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']?.toLowerCase().includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']?.toLowerCase().includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }

  showUpload = false;
  customerHeader = ['Abbreviated Name', 'Company Name', 'Action'];
  customerData: any[] = [
    {
      "Abbreviated Name": "10937234",
      "Company Name": "Big4U"
    },
    {
      "Abbreviated Name": "10943234",
      "Company Name": "Test Name"
    },
    {
      "Abbreviated Name": "10918234",
      "Company Name": "Tushar"
    },
  ];

  ogData = this.customerData;

  customerColumnWidth = ['40%', '50%', '10%'];
  currentCustomer = {};
  currentCustomerName: string = '';
  currentName: string = '';
  loginName: string = '';
  fullName: string = '';

  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentCustomerName = row['Abbreviated Name'] || '';
    this.currentName = row['Company Name'] || '';
    this.loginName = row['Login'] || '';
    this.fullName = row['First Name'] + row['Last Name'] || '';
    this.showUpload = true;
  }

  //customer auth page vars----------------------------
  searchFirstName = '';
  searchLastName = '';
  searchLogin = '';


  dateFrom = "";
  dateTo = "";

  // Add these fields in your component class
  startDate: Date | null = null;
  endDate: Date | null = null;

  // --- Helper to parse dd/MM/yyyy strings to Date ---
  private parseDDMMYYYY(dateStr: string): Date | null {
    if (!dateStr) return null;
    const [dd, mm, yyyy] = dateStr.split('/').map(Number);
    if (!dd || !mm || !yyyy) return null;
    // JS Date months are 0-based
    const d = new Date(yyyy, mm - 1, dd);
    // Basic validity check (e.g., 31/02/2025 should be invalid)
    return d && d.getMonth() === mm - 1 ? d : null;
  }


  searchProfileTypeList: string[] = ['*', 'BOE', 'Third Party Transfer'];
  selectedProfileType = '';
  searchFileStatusList: string[] = ['*', 'Pending', 'In Process', 'Successful', 'Failed', 'Successful (P)'];
  selectedSearchProfileStatus = '';
  searchStatusList: string[] = ['*', 'Awaiting for Approval (Deleted)', 'Awaiting for Approval (New)', 'Checker Returned (Deleted)', 'Checker Returned (New)'];
  selectedSearchStatus = '';

  uploadFile = false;
  addAuthenForm = false;
  viewUpload = false;
  editUpload = false;
  editIndex = -1;

  authHeaders = ['Date', 'Product Type', 'Description', 'File Status', 'Status', 'Maker User', 'Action']

  authColWidth = [
    '8%',
    '6%',
    '6%',
    '8%',
    '12%',
    '8%',
    '8%',
    '8%',
    '8%',
    '8%',
    '8%',
    '6%',
    '6%'
  ];

  authData: any[] = [
    {
      "Date": "11/12/2025",
      "Product Type": "Third Party Transfer",
      "Description": "test",
      "File Status": "Pending",
      "Status": "Awaiting for Approval (New)",
      "Maker User": "Admin2",
    },
    {
      "Date": "12/12/2025",
      "Product Type": "Third Party Transfer",
      "Description": "test2",
      "File Status": "Failed",
      "Status": "Awaiting for Approval (Deleted)",
      "Maker User": "JohnDoe",
    },
    {
      "Date": "11/12/2025",
      "Product Type": "BOE",
      "Description": "test3 and test new",
      "File Status": "In Process",
      "Status": "Checker Returned (Deleted)",
      "Maker User": "Tushar",
    },
    {
      "Date": "11/12/2025",
      "Product Type": "BOE",
      "Description": "test4",
      "File Status": "Successful",
      "Status": "Checker Returned (New)",
      "Maker User": "Tushar M",
    }
  ]
  ogAuthData = this.authData;


  private isAll(val: string | null | undefined): boolean {
    return !val || val.trim() === '*' || val.trim() === '';
  }


  searchAuth(): void {
    const filtered = this.ogAuthData.filter(item => {


      // Normalize item fields for safe comparison
      const productType = (item['Product Type'] || '').toLowerCase().trim();
      const fileStatus = (item['File Status'] || '').toLowerCase().trim();
      const status = (item['Status'] || '').toLowerCase().trim();


      const selectedProductType = (this.selectedProfileType || '').toLowerCase().trim();
      const selectedFileStatus = (this.selectedSearchProfileStatus || '').toLowerCase().trim();
      const selectedStatus = (this.selectedSearchStatus || '').toLowerCase().trim();


      const matchProductType = this.isAll(this.selectedProfileType)
        ? true
        : productType.includes(selectedProductType); // or === if exact match

      const matchFileStatus = this.isAll(this.selectedSearchProfileStatus)
        ? true
        : fileStatus.includes(selectedFileStatus); // or === if exact match

      const matchStatusField = this.isAll(this.selectedSearchStatus)
        ? true
        : status.includes(selectedStatus); // or === if exact match


      return matchProductType && matchFileStatus && matchStatusField;

    });

    this.authData = [...filtered]; // ✅ Update reference for change detection
  }


  viewUploadF(row: any, index: number) {
    this.viewUpload = true;
    this.editUpload = false;
    this.assignAddPageData(row);
  }

  editUploadF(row: any, index: number) {
    this.editUpload = true;
    this.viewUpload = true;
    this.assignAddPageData(row);
    this.editIndex = index;
  }

  assignAddPageData(row: any) {
    this.currentName = row['Company Name'] || '';
    this.loginName = row['Login'] || '';
    this.fullName = row['First Name'] + " " + row['Last Name'] || '';
  }

  deleteUploadF(index: number): void {
    if (index >= 0 && index < this.authData.length) {
      this.authData.splice(index, 1);
      this.authData = [...this.authData]; // ✅ Update reference for change detection
    }
  }

  // File Upload Page
  fileUpload() {
    this.uploadFile = true;
    this.showUpload = false;
    this.editUpload = false;
    this.viewUpload = false;
  }

  productTypeError = false;
  productTypeList = ['BOE', 'Third Party Transfer'];
  selectedProductType = '';

  // Add a File
  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;
  addFile = false;
  selectedFile: File | null = null;
  errorMsg: string | null = null;


  // Optional: set allowed types (e.g., images/pdf). Leave empty string for any.
  acceptedTypes = ''; // e.g., 'image/*,application/pdf'

  private readonly MAX_SIZE_BYTES = 1 * 1024 * 1024; // 1 MB

  fileAdd(): void {
    // Trigger the hidden file input
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: Event): void {
    this.errorMsg = null;

    const input = event.target as HTMLInputElement;
    const file = input.files && input.files[0] ? input.files[0] : null;

    if (!file) {
      // No selection (e.g., user canceled)
      this.selectedFile = null;
      return;
    }

    // Validate size (<= 1 MB)
    if (file.size > this.MAX_SIZE_BYTES) {
      this.selectedFile = null;
      this.errorMsg = 'File is too large. Maximum allowed size is 1 MB.';
      // Clear the input so the same file can be chosen again after resizing
      this.fileInput.nativeElement.value = '';
      return;
    }

    this.selectedFile = file;
  }


  clearFile(): void {
    this.selectedFile = null;
    this.errorMsg = null;
    this.fileInput.nativeElement.value = '';
  }


  // PopUp
  popupVisible = false;

  hidePopup() {
    this.popupVisible = false;
  }

  submitUpload() {

  }

  customersPage() {
    this.showUpload = true;
    this.editUpload = false;
    this.viewUpload = false;
    this.uploadFile = false;
  }


  isAnimating = false;

  animateAndClear(): void {
    // trigger animation
    this.isAnimating = true;

    // let the animation play before clearing
    setTimeout(() => {
      this.clearFile();        // your existing clear logic
      this.isAnimating = false;
    }, 600); // match the CSS animation duration
  }


}
