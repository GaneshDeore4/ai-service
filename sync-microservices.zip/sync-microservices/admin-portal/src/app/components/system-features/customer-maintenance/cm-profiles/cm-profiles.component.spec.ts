import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmProfilesComponent } from './cm-profiles.component';

describe('CmProfilesComponent', () => {
  let component: CmProfilesComponent;
  let fixture: ComponentFixture<CmProfilesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CmProfilesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmProfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
