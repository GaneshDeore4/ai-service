import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmUserAccountComponent } from './cm-user-account.component';

describe('CmUserAccountComponent', () => {
  let component: CmUserAccountComponent;
  let fixture: ComponentFixture<CmUserAccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CmUserAccountComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmUserAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
