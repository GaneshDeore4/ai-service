import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgFor, NgIf, NgStyle } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../../commom/table/table.component";
import { PopupComponent } from "../../../../commom/popup/popup.component";

interface Account {
  "Account Number": string;
  "Account Type": string;
  "Currency": string;
  "PAB": boolean;
  "View Statement": boolean;
  "Products": string[];
  "Active": boolean
}

@Component({
  selector: 'app-cm-user-account',
  imports: [PageTitleComponent, NgIf, NgFor, FormsModule, TableComponent, PopupComponent, NgStyle],
  templateUrl: './cm-user-account.component.html',
  styleUrl: './cm-user-account.component.css'
})
export class CmUserAccountComponent {

  //main page vars
  searchAbbreviatedName = '';
  searchName = '';
  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']?.toLowerCase().includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']?.toLowerCase().includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  showUsers = false;
  customerHeader = ['Abbreviated Name', 'Company Name', 'Action'];
  customerData: any[] = [
    {
      "Abbreviated Name": "10937234",
      "Company Name": "Big4U"
    },
    {
      "Abbreviated Name": "10943234",
      "Company Name": "Test Name"
    },
  ];
  ogData = this.customerData;
  currentCustomer = {};
  currentCustomerName: string = 'ABB';
  currentName: string = '';
  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentCustomerName = row['Abbreviated Name'] || '';
    this.currentName = row['Company Name'] || '';
    this.showUsers = true;
  }

  //list of users page.
  searchLastName = '';
  searchFirstName = '';
  searchLoginId = '';
  searchSelectedProfileStatus = '';
  searchStatusList: string[] = ['Awaiting for Approval(D)', 'Awaiting for Approval(M)', 'Awaiting for Approval(N)', 'Checker Returned(D)', 'Checker Returned(M)', 'Checker Returned(N)', 'Draft(M)', 'Draft(N)'];
  searchSelectedStatus = '';

  userForm = false;
  editUser = false;
  viewUser = false;
  editUserIndex = -1;

  userHeaders = ['First Name', 'Last Name', 'LoginID', 'Profile Status', 'Status', 'Maker', 'Action'];
  userOgData: any[] = [
    {
      "First Name": "John",
      "Last Name": "Doe",
      "LoginID": "johndoe",
      "Employee Number": "12345",
      "Department": "IT",
      "Address": "123 Main St",
      "Postal Code": "12345",
      "Auth Mode": "Password",
      "Time Zone": "Asia/Calcutta",
      "Language": "English(UK)",
      "Base Currency": "USD",
      "Contact Number": "123-456-7890",
      "Fax": "123-456-7891",
      "email": "dummy@gmail.com",
      "Pending Tran Notification": true,
      "Auth Level": "A",
      "Limit Amount Currency": "USD",
      "Limit Amount": "1000",
      "Profile Status": "Active",
      "Status": "Awaiting for Approval(D)",
      "Maker": "John Doe"
    },
    {
      "First Name": "Jane",
      "Last Name": "Smith",
      "LoginID": "janesmith",
      "Employee Number": "54321",
      "Department": "HR",
      "Address": "456 Oak Ave",
      "Postal Code": "54321",
      "Auth Mode": "OTP Password",
      "Time Zone": "America/Havana",
      "Language": "French",
      "Base Currency": "EUR",
      "Contact Number": "098-765-4321",
      "Fax": "098-765-4322",
      "email": "jane.smith@example.com",
      "Pending Tran Notification": false,
      "Auth Level": "B",
      "Limit Amount Currency": "EUR",
      "Limit Amount": "5000",
      "Profile Status": "Inactive",
      "Status": "Checker Returned(M)",
      "Maker": "Jane Smith",
      "Account": []
    },
    {
      "First Name": "Peter",
      "Last Name": "Jones",
      "LoginID": "peterjones",
      "Employee Number": "67890",
      "Department": "Finance",
      "Address": "789 Pine Ln",
      "Postal Code": "67890",
      "Auth Mode": "No Re-Autehntication",
      "Time Zone": "Asia/Calcutta",
      "Language": "Arabic",
      "Base Currency": "GBP",
      "Contact Number": "111-222-3333",
      "Fax": "111-222-3334",
      "email": "peter.jones@example.com",
      "Pending Tran Notification": true,
      "Auth Level": "C",
      "Limit Amount Currency": "GBP",
      "Limit Amount": "10000",
      "Profile Status": "Lock",
      "Status": "Draft(N)",
      "Maker": "Peter Jones",
      "Account": [
        {
          "Account Number": "6789789",
          "Account Type": "Saving Account",
          "Currency": "INR",
          "PAB": false,
          "View Statement": false,
          "Products": ['Advices and Notification', 'Bankers Guarantee', 'Export Collection'],
          "Active": false
        },
        {
          "Account Number": "6780000",
          "Account Type": "Current Account",
          "Currency": "USD",
          "PAB": false,
          "View Statement": false,
          "Products": ['Advices and Notification', 'Bankers Guarantee', 'Export Collection', 'Issue Standby LC'],
          "Active": true
        }
      ]
    }
  ];
  userData = [...this.userOgData];

  searchUserf(): void {
    const filtered = this.userOgData.filter(item => {
      const matchLastName = this.searchLastName
        ? item['Last Name']?.toLowerCase().includes(this.searchLastName.toLowerCase())
        : true;

      const matchFirstName = this.searchFirstName
        ? item['First Name']?.toLowerCase().includes(this.searchFirstName.toLowerCase())
        : true;

      const matchLoginId = this.searchLoginId
        ? item['LoginID']?.toLowerCase().includes(this.searchLoginId.toLowerCase())
        : true;

      const matchProfileStatus = this.searchSelectedProfileStatus
        ? item['Profile Status']?.toLowerCase().includes(this.searchSelectedProfileStatus.toLowerCase())
        : true;

      const matchStatus = this.searchSelectedStatus
        ? item['Status']?.toLowerCase().includes(this.searchSelectedStatus.toLowerCase())
        : true;

      return matchLastName && matchFirstName && matchLoginId && matchProfileStatus && matchStatus;
    });

    this.userData = [...filtered];
  }
  currentUser: any = null;
  currentUserIndex = -1;
  addUserf(row: any, index: number) {
    this.currentUser = row;
    this.currentUserIndex = index;
    this.userForm = true;
  }
  editUserf(row: any, index: number) {
    this.assignValues(row);
    this.editUser = true;
    this.editUserIndex = index;
    this.addUserf(row, index);
  }
  viewUserf(row: any, index: number) {
    this.assignValues(row);
    this.viewUser = true;
    this.addUserf(row, index);
    this.editUserIndex = -1;
  }
  assignValues(row: any) {
    this.loginID = row['LoginID'] || '';
    this.firstName = row['First Name'] || '';
    this.lastName = row['Last Name'] || '';
    this.userAccounts = row['Account'] || [];
  }


  //account form page
  loginID = '';
  firstName = '';
  lastName = '';
  profileStatusList = ['Active', 'Inactive', 'Lock'];
  userAccounts: Account[] = [];
  accountHeaders = ['Account Number', 'Account Type', 'Currency', 'PAB', 'View Statement', 'Products'];
  checkAll = false;

  saveAccount() {
    if (this.currentUser) {
      this.currentUser['Account'] = [...this.userAccounts];
      this.userOgData[this.currentUserIndex] = this.currentUser;
      this.userData = [...this.userOgData];
    }

    this.popupVisible = true;
    this.goToUserPage();
  }
  goToUserPage() {
    this.loginID = '';
    this.firstName = '';
    this.lastName = '';
    this.userAccounts = [];
    this.editUser = false;
    this.viewUser = false;
    this.userForm = false;
    this.editUserIndex = -1;
    this.currentUser = null;
    this.currentUserIndex = -1;
  }
  validateAccount() { }
  popupVisible = false;
  hidePopup() {
    this.popupVisible = false;
  }


  // transfer list vars
  showTransferList = false;
  currentAccountRowIndex = -1;
  openTransferList(existingProducts: string[], index: number) {
    const initList = [
      'Advice and Notification',
      'Alert Maintenance',
      'Airway Bill Tracking System',
      'Inventory Management',
      'Shipment Scheduling',
      'Customer Support',
      'Compliance Monitoring',
      'Risk Assessment',
      'Performance Analytics',
      'Data Security Management'
    ];
    //remove all the items from the list1 which exist in exisitng list
    this.list1 = initList.filter(item => !existingProducts.includes(item));
    this.list2 = existingProducts;
    this.showTransferList = true;
    this.currentAccountRowIndex = index;
  }
  closeTranferList() {
    //replace products list with list2 at index currentAccountRowIndex of userAccounts
    if (this.currentAccountRowIndex !== -1) {
      this.userAccounts[this.currentAccountRowIndex]["Products"] = [...this.list2];
    }
    this.currentAccountRowIndex = -1;
    this.showTransferList = false;
    this.list1 = [];
    this.list2 = [];
    this.selectedList1 = [];
    this.selectedList2 = [];
  }
  // TRANSFER LIST LOGIC
  list1: string[] = [];
  list2: string[] = [];
  selectedList1: string[] = [];
  selectedList2: string[] = [];

  toggleSelection(item: string, list: 'list1' | 'list2') {
    if (list === 'list1') {
      this.selectedList1.includes(item)
        ? this.selectedList1 = this.selectedList1.filter(i => i !== item)
        : this.selectedList1.push(item);
    } else {
      this.selectedList2.includes(item)
        ? this.selectedList2 = this.selectedList2.filter(i => i !== item)
        : this.selectedList2.push(item);
    }
  }

  addItems() {
    this.list2.push(...this.selectedList1);
    this.list1 = this.list1.filter(item => !this.selectedList1.includes(item));
    this.selectedList1 = [];
  }

  removeItems() {
    this.list1.push(...this.selectedList2);
    this.list2 = this.list2.filter(item => !this.selectedList2.includes(item));
    this.selectedList2 = [];
  }

  defaultItems() {
    this.list2.push(...this.list1);
    this.list1 = [];
    this.selectedList1 = [];
  }


  // checkBox functions
  onRowCheckChange(row: Account, intdex: number) {
    if (row['Active']) {
      row['PAB'] = true;
      row['View Statement'] = true;
    }
    else {
      row['PAB'] = false;
      row['View Statement'] = false;
    }
  }
  onCheckAll() {
    this.userAccounts.forEach(row => {
      if (this.checkAll) {
        row['Active'] = true;
        row['PAB'] = true;
        row['View Statement'] = true;
      } else {
        row['Active'] = false;
        row['PAB'] = false;
        row['View Statement'] = false;
      }
    });
  }
}
