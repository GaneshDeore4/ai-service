import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmUserProfileComponent } from './cm-user-profile.component';

describe('CmUserProfileComponent', () => {
  let component: CmUserProfileComponent;
  let fixture: ComponentFixture<CmUserProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CmUserProfileComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CmUserProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
