import {
  GET_ALL_COMPANIES,
  GET_CATEGORY_BY_CATEGORY_NAME,
  GET_CATEGORY_BY_ID,
  GET_PRO_SUBPRO_MAP_BY_COMPANY_ID,
  GET_USER_BY_COMPANY_ID,
  GET_USER_TYPE_BY_CATEGORY,
  SEND_OTP,
  VALIDATE_OTP,
  GET_ALL_TEMP_USERS,
  RELID_APPROVE,
} from './../../../../constants/api_endpoints';
import {
  ChangeDetectorRef,
  Component,
  inject,
  OnInit,
  ɵsetUnknownElementStrictMode,
} from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from '../../../../commom/table/table.component';
import { ProductEntity } from '../../jurisdiction-maintenance/product-master/product-master.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { FloatLabelModule } from 'primeng/floatlabel';
import { TreeSelect } from 'primeng/treeselect';
import { TreeNode } from 'primeng/api';
import { LegalInfoDto } from '../../../../model/LegalInfoDto';
import { SelectModule } from 'primeng/select';
import COUNTRIES_DATA from '../../../../constants/Countries';
import { CompanyUser } from '../../../../model/CompanyUser';
import { ApiService } from '../../../../service/apiService/api.service';
import { SessionService } from './../../../../service/sessionService/session.service';

import {
  APPROVE_USER,
  CREATE_COMPANY_USER,
  GET_PRODUCTS_BY_COMPANY_ID,
  GET_TEMP_USER_BY_COMPANY_ID,
  GET_TEMP_USER_BY_ID,
  REJECT_USER,
  GET_USER_TYPE_BY_CATEGORY_ID,
  GET_AUTH_GROUPS,
  GET_ALL_TXN_COMPANIES,
  GET_ALL_TEMP_COMPANIES,
} from '../../../../constants/api_endpoints';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import {
  SUPERADMIN,
  COMPANY_CATERGORY_ID,
  BANKSUPERADMINCHECKER,
  BANKSETUPCHECKER,
  BANKSETUPMAKER,
  BANKSUPERADMINMAKER,
  PAGE_SIZE,
  CLIENTMC,
  CLIENTMAKER,
  CLIENTCHECKER,
} from '../../../../constants/Constants';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  AuditCard,
  UserAuditComponent,
} from '../../../../commom/user-audit/user-audit.component';
import { OtpComponent } from '../../../../commom/otp/otp.component';

interface SubProduct {
  subProductId: number;
  name: string;
  selected: boolean;
}

interface Product {
  productId: number;
  name: string;
  selected: boolean;
  subProducts: SubProduct[];
}
interface Role {
  userTypeId: number;
  userTypeName: string;
}
interface AuthLevel {
  authLevelId: number;
  authLevelName: string;
}
interface SubproductApiItem {
  subProductId: number;
  subProductName: string;
  categoryId: number;
  categoryName: string;
  productId: number;
  productName: string;
}
@Component({
  selector: 'app-cm-user-profile',
  imports: [
    PageTitleComponent,
    NgIf,
    NgFor,
    NgClass,
    FormsModule,
    ToastComponent,
    MultiSelectModule,
    FloatLabelModule,
    SelectModule,
    TblComponent,
    LoaderComponent,
    UserAuditComponent,
    OtpComponent,
  ],
  templateUrl: './cm-user-profile.component.html',
  styleUrl: './cm-user-profile.component.css',
})
export class CmUserProfileComponent implements OnInit {
  loginCompanyId: number | null = null;
  loginUserRole = '';
  loggedInLoginId: string = '';
  role = '';
  roleList: Role[] = [];
  actionList: string[] = [];
  isRelIdPopupOpen = false;
  relIdMessage = 'Waiting for RELID approval...';
  relIdPollingInterval: any;
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'CMProfileTable';
  loginUserId: string = ''
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  private sessionService = inject(SessionService);

  constructor(private apiService: ApiService, private cdr: ChangeDetectorRef) {
    this.loginUserRole = this.sessionService.getRole() || '';
    this.loggedInLoginId = this.sessionService.getLoginId() || '';
    this.loginUserId = this.sessionService.getLoginId();
  }

  startRelIdApproval(action: string) {
    this.checkerAction = action;

    this.isRelIdPopupOpen = true;
    this.relIdMessage = 'Waiting for RELID approval...';

    this.pollRelIdStatus();
  }
  pollRelIdStatus() {
    // this.approveRejectForm(this.checkerAction);
    this.apiService
      .sendData(RELID_APPROVE + '?ecn=' + this.loginUserId, {})
      .subscribe({
        next: (res) => {
          console.log(res);
          if (res.payload === 'success') {
            this.approveRejectForm(this.checkerAction);
            this.isRelIdPopupOpen = false;
          }
        },
        error: (err) => {
          console.error(err);
          this.isRelIdPopupOpen = false;
        },
      });
    // this.relIdPollingInterval = setInterval(() => {
    // this.apiService
    //   .getData(RELID_STATUS_API + '?companyId=' + this.company.companyId, {})
    //   .subscribe({
    //     next: (res: any) => {
    //       if (res.status === 'SUCCESS') {
    //         clearInterval(this.relIdPollingInterval);

    //         this.isRelIdPopupOpen = false;

    //         // Continue approval process
    //         this.approveRejectForm(this.checkerAction);
    //       } else if (res.status === 'REJECTED') {
    //         clearInterval(this.relIdPollingInterval);

    //         this.isRelIdPopupOpen = false;

    //         this.showToast(
    //           'error',
    //           'RELID Rejected',
    //           res.description || 'RELID approval rejected'
    //         );
    //       }

    //       // If pending → do nothing and continue polling
    //     },
    //     error: () => {
    //       clearInterval(this.relIdPollingInterval);

    //       this.isRelIdPopupOpen = false;

    //       this.showToast('error', 'Error', 'Failed to verify RELID approval');
    //     },
    //   });
    // }, 3000); // every 3 sec
  }

  ngOnInit() {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER ||
      this.loginUserRole == BANKSETUPMAKER
    ) {
      this.actionList = ['view', 'edit', 'replicate', 'delete', 'audit'];
    } else if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINCHECKER ||
      this.loginUserRole == BANKSETUPCHECKER
    ) {
      this.actionList = ['view'];
    } else this.actionList = ['view'];
    this.getCategory();
    this.getCompanyList();
  }

  approveRejectAvailable(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINCHECKER ||
      this.loginUserRole == BANKSETUPCHECKER
    )
      return true;
    else return false;
  }
  addBtnAllowed(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER ||
      this.loginUserRole == BANKSETUPMAKER
    )
      return true;
    else return false;
  }

  getCompanyList() {
    /*
    this.isLoading = true;
    this.apiService
      .getData(
        GET_ALL_COMPANIES +
        '?page=' +
        (this.pageNumber - 1) +
        '&size=' +
        this.pageSize,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.customerData = res['payload']['content'];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
            this.ogData = [...this.customerData];
          }
        },
        error: (err: any) => {
          console.error('Failed to load companies', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
    */

    this.isLoading = true;
    this.apiService
      .getData(
        GET_ALL_COMPANIES +
          '?page=' +
          (this.pageNumber - 1) +
          '&size=' +
          this.pageSize,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            const companies = res['payload']['content'] || [];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }

            // Check for pending users to update company status
            this.apiService.getData(GET_ALL_TEMP_USERS, {}).subscribe({
              next: (userRes: any) => {
                let pendingCompanyIds = new Set<number>();
                if (userRes.status === 'SUCCESS') {
                  const tempUsers =
                    userRes.payload?.content || userRes.payload || [];
                  tempUsers.forEach((u: any) => {
                    if (u.status === 'PENDING') {
                      pendingCompanyIds.add(u.companyId);
                    }
                  });
                }

                this.customerData = companies.map((company: any) => {
                  const hasPending = pendingCompanyIds.has(company.companyId);
                  return {
                    ...company,
                    status: hasPending ? 'PENDING' : company.status || 'ACTIVE',
                  };
                });

                this.ogData = [...this.customerData];
                this.isLoading = false;
              },
              error: (err: any) => {
                this.customerData = companies.map((company: any) => ({
                  ...company,
                  status: company.status || 'ACTIVE',
                }));
                this.ogData = [...this.customerData];
                this.isLoading = false;
              },
            });
          } else {
            this.isLoading = false;
          }
        },
        error: (err: any) => {
          this.isLoading = false;
        },
      });
  }

  categoryId: number | null = null;
  getCategory() {
    this.apiService
      .getData(GET_CATEGORY_BY_ID + '?categoryId=' + COMPANY_CATERGORY_ID, {})
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.categoryId = res['payload']['categoryId'];
          } else {
            console.log(res.description);
          }
        },
        error: (err) => {
          console.log('Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  getUserType() {
    this.apiService
      .getData(
        GET_USER_TYPE_BY_CATEGORY_ID + '?categoryId=' + this.categoryId,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.roleList = res.payload;
          }
          this.cdr.detectChanges();
        },
        error: (err: any) => {
          console.error('Failed to load roles for category', err);
        },
      });
  }

  getAuthLevels() {
    this.apiService.getData(GET_AUTH_GROUPS, {}).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.authLevelList = res.payload.map((item: any) => ({
            authLevelId: item.id,
            authLevelName: item.authGroup,
          }));
          this.cdr.detectChanges();
        }
      },
      error: (err: any) => {
        console.error('Failed to load auth groups', err);
      },
    });
  }

  //main page vars
  searchAbbreviatedName = '';
  searchName = '';
  countryData = COUNTRIES_DATA;
  isLoading = false;
  searchData(): void {
    const filtered = this.ogData.filter((item) => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['abbvName']
            ?.toLowerCase()
            .includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchAbbreviatedName
        ? item['name']
            ?.toLowerCase()
            .includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      return matchAbbreviated || matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  showUsers = false;
  // companyHeader = ['companyId', 'name', 'Action'];

  companyHeader: { key: string; value: string }[] = [
    { key: 'abbvName', value: 'Customer ID' },
    { key: 'name', value: 'Name' },
    { key: 'status', value: 'Status' },
    // { key: 'createdBy', value: 'Maker' },
    { key: 'Action', value: 'Action' },
  ];

  countryCodeList = [
    { label: 'India (+91)', value: '+91' },
    { label: 'USA (+1)', value: '+1' },
    { label: 'UK (+44)', value: '+44' },
    { label: 'UAE (+971)', value: '+971' },
    { label: 'Singapore (+65)', value: '+65' },
  ];

  customerData: any[] = [];
  ogData: any[] = [];
  currentCustomer = {};
  currentCustomerName: string = '';
  currentBaseCurrency: string = '';
  currentName: string = '';
  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentBaseCurrency = row['baseCurrency'];
    this.currentCustomerName = row['abbvName'] || row['Abbreviated Name'] || '';
    this.currentName = row['companyId'] || row['Company Name'] || '';
    this.loginCompanyId = row.companyId;
    this.showUsers = true;
    this.pageNumber = 1;
    this.totalElements = 0;
    this.tableId = 'CMUserTable';
    this.getTableData();
  }

  isRoleSelected(expectedRole: string): boolean {
    if (!this.userEntity.userTypeId) return false;
    let currentRoleName = String(this.userEntity.userTypeId);
    const matchedRole = this.roleList.find(
      (r) => String(r.userTypeId) === String(this.userEntity.userTypeId)
    );
    if (matchedRole) {
      currentRoleName = matchedRole.userTypeName;
    }
    if (expectedRole == 'checker') {
      return currentRoleName === CLIENTCHECKER || currentRoleName === CLIENTMC;
    }
    // if(expectedRole=='m=c'){
    //   this.userEntity.ccy = this.currentBaseCurrency;
    //   return currentRoleName===CLIENTMC;
    // }
    return false;
  }

  searchLastName = '';
  searchFirstName = '';
  searchLoginId = '';
  searchSelectedProfileStatus = '';
  searchStatusList: string[] = [
    'Awaiting for Approval(D)',
    'Awaiting for Approval(M)',
    'Awaiting for Approval(N)',
    'Checker Returned(D)',
    'Checker Returned(M)',
    'Checker Returned(N)',
    'Draft(M)',
    'Draft(N)',
  ];
  searchSelectedStatus = '';

  userForm = false;
  editUser = false;
  viewUser = false;
  editUserIndex = -1;

  // userHeaders = ['First Name', 'Last Name', 'Status', 'Maker', 'Action'];
  userHeaders: { key: string; value: string }[] = [
    { key: 'firstName', value: 'First Name' },
    { key: 'lastName', value: 'Last Name' },
    { key: 'status', value: 'Status' },
    // { key: 'maker', value: 'Maker' },
    { key: 'Action', value: 'Action' },
    // { key: 'Audit', value: 'Audit-trail' },
  ];
  isAuditOpen = false;
  channelRef = 'CH123456';

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }
  auditCards: AuditCard[] = [
    {
      label: 'Maker',
      name: 'ABC',
      datetime: '10 Apr 2026, 10:00 AM',
      status: 'completed',
    },
    {
      label: 'Checker',
      name: 'XYZ',
      datetime: '10 Apr 2026, 11:00 AM',
      status: 'completed',
    },
  ];

  userOgData: any[] = [];
  userData = [...this.userOgData];

  searchUserf(): void {
    const filtered = this.userOgData.filter((item) => {
      const matchLastName = this.searchFirstName
        ? item['lastName']
            ?.toLowerCase()
            .includes(this.searchFirstName.toLowerCase())
        : true;

      const matchFirstName = this.searchFirstName
        ? item['firstName']
            ?.toLowerCase()
            .includes(this.searchFirstName.toLowerCase())
        : true;

      const matchLoginId = this.searchFirstName
        ? item['loginId']
            ?.toLowerCase()
            .includes(this.searchFirstName.toLowerCase())
        : true;

      // const matchProfileStatus = this.searchSelectedProfileStatus
      //   ? item['Profile Status']
      //       ?.toLowerCase()
      //       .includes(this.searchSelectedProfileStatus.toLowerCase())
      //   : true;

      // const matchStatus = this.searchSelectedStatus
      //   ? item['Status']
      //       ?.toLowerCase()
      //       .includes(this.searchSelectedStatus.toLowerCase())
      //   : true;

      return matchLastName || matchFirstName || matchLoginId;
    });

    this.userData = [...filtered];
  }
  userEntity: CompanyUser = new CompanyUser();

  addUserf() {
    this.getCompanyProducts();
    this.getUserType();
    this.getAuthLevels();
    this.userEntity = new CompanyUser();
    this.userEntity.contactNoCountryCode = '+91';
    this.userForm = true;
  }

  editUserf(row: CompanyUser, index: number) {
    this.isLoading = true;
    this.getCompanyProducts();
    this.getUserType();
    this.getAuthLevels();
    this.userEntity = new CompanyUser();
    this.editUser = true;
    this.editUserIndex = index;
    this.userForm = true;
    if (row.userId) this.getUserById(row.userId);
    this.isLoading = false;
  }
  viewUserf(row: any, index: number) {
    this.isLoading = true;
    this.getCompanyProducts();
    this.getUserType();
    this.getAuthLevels();
    this.userEntity = new CompanyUser();
    this.viewUser = true;
    this.userForm = true;
    this.editUserIndex = -1;
    if (row.userId) this.getUserById(row.userId);
    this.isLoading = false;
  }
  deleteUserf(row: any, index: number) {
    if (index >= 0 && index < this.userOgData.length) {
      this.userOgData.splice(index, 1);
    }
    this.userData = [...this.userOgData];
  }
  repliUser = false;
  replicateUser(row: any) {
    this.isLoading = true;
    this.getCompanyProducts();
    this.getUserType();
    this.getAuthLevels();
    this.repliUser = true;
    this.userEntity = new CompanyUser();
    this.getUserById(row.userId);
  }
  assignReplicateValues() {
    let tempUser = new CompanyUser();
    tempUser.addressLine1 = this.userEntity.addressLine1;
    tempUser.addressLine2 = this.userEntity.addressLine2;
    tempUser.addressLine3 = this.userEntity.addressLine3;
    tempUser.addressLine4 = this.userEntity.addressLine4;
    tempUser.addressLine5 = this.userEntity.addressLine5;
    tempUser.postalCode = this.userEntity.postalCode;
    tempUser.corrLanguage = this.userEntity.corrLanguage;
    tempUser.timeZone = this.userEntity.timeZone;
    tempUser.employeeDepartment = this.userEntity.employeeDepartment;
    tempUser.userTypeId = this.userEntity.userTypeId;
    tempUser.limitAmount = this.userEntity.limitAmount;
    tempUser.authLevel = this.userEntity.authLevel;
    tempUser.email = this.userEntity.email;
    tempUser.contactNo = this.userEntity.contactNo;
    tempUser.contactNoCountryCode = this.userEntity.contactNoCountryCode; // ✅ ADD
    tempUser.firstName = this.userEntity.firstName;
    tempUser.lastName = this.userEntity.lastName;
    tempUser.userStatus = this.userEntity.userStatus;
    tempUser.authMode = this.userEntity.authMode;
    tempUser.lastName = this.userEntity.lastName;

    this.userEntity = new CompanyUser();
    this.userEntity = tempUser;
    this.userForm = true;
    this.repliUser = false; //now that the work is done reseting it
  }
  // addUserPage
  profileStatusList = ['Active', 'Inactive', 'Lock'];
  authModeList = ['No Re-Autehntication', 'OTP Password'];
  timeZoneList = ['Asia/Calcutta', 'America/Havana'];
  langaugeList: string[] = ['English(UK)', 'English(USA)', 'French', 'Arabic'];
  authLevelList: AuthLevel[] = [];

  loginIDError = false;
  firstNameError = false;
  lastNameError = false;
  profileStatusError = false;
  authModeError = false;
  timeZoneError = false;
  languageError = false;
  baseCurrencyError = false;
  contactNumberError = false;
  emailError = false;

  popupText = '';
  popupVisible = false;
  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }
  showTranNotification(): boolean {
    if ('OTP Password' == this.userEntity.authMode) return true;
    return false;
  }
  getUserById(userId: number) {
    this.isLoading = true;
    this.apiService
      .getData(GET_TEMP_USER_BY_ID + '?userId=' + userId, {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            // A single user returns the object directly in 'payload', not 'payload.content'
            this.userEntity = CompanyUser.fromJson(res.payload);
            this.applySelectionsFromRelationMapMutating(
              this.products,
              res.payload.productSubProdMap
            );
            this.products = [...this.products];
            this.cdr.detectChanges();
            console.log(
              'marked products after call:' +
                JSON.stringify(this.products, null, 2)
            );

            // Apply legal info lists
            this.legalInfoList = this.userEntity.legalIdDetailsDtoList || [];

            if (this.repliUser) this.assignReplicateValues();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getTableData() {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_TEMP_USER_BY_COMPANY_ID +
          '?companyId=' +
          this.loginCompanyId +
          '&page=' +
          (this.pageNumber - 1) +
          '&size=' +
          this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            const rawData = res['payload']['content'] || [];
            this.userData = rawData.map((user: any) => ({
              ...user,
              'First Name': user.firstName,
              'Last Name': user.lastName,
              'Profile Status': user.profileStatus,
              Status: user.status || 'Draft(N)',
              Maker: user.maker || '',
              LoginID: user.loginId,
            }));
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
            this.userOgData = [...this.userData];
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  saveUser() {
    // this.isLoading = true;
    if (!this.validateUser()) return;

    // Sync the local legalInfo array to the payload
    this.userEntity.legalIdDetailsDtoList = this.legalInfoList;
    this.userEntity.legalIdDetailsDtoList.forEach((item) => {
      item.id = null;
    });

    // Populate missing payload fields manually
    if (this.editUserIndex != -1) this.userEntity.isUpdate = true;
    else this.userEntity.isUpdate = false;
    this.userEntity.companyId = this.loginCompanyId;

    // Map standalone HTML string bindings to userEntity when userEntity is empty
    this.userEntity.createdBy = this.loggedInLoginId;

    // Build productSubProdMap based on checkbox selections
    this.userEntity.productSubProdRespMap = this.productsToApiRecord(
      this.products
    );
    console.log(
      'productSubProdRespMap: ' +
        JSON.stringify(this.userEntity.productSubProdRespMap, null, 2)
    );
    console.log('user for save: ' + JSON.stringify(this.userEntity, null, 2));
    this.isLoading = true;
    const actionRole = this.editUserIndex === -1 ? 'CREATE' : 'EDIT';

    this.apiService
      .sendData(CREATE_COMPANY_USER, this.userEntity.toJson(), {
        'X-ACTION-ROLE': actionRole,
      })
      .subscribe({
        next: (res: any) => {
          if (res.status == 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              this.editUserIndex == -1
                ? 'User created successfully'
                : 'User updated successfully'
            );

            this.getTableData();
            this.toUsersPage();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err: any) => {
          console.error('API ERROR:', err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  approveRejectForm(action: string) {
    this.isLoading = true;
    const url = action === 'approve' ? APPROVE_USER : REJECT_USER;
    const actionRole = action === 'approve' ? 'APPROVE' : 'REJECT';
    this.apiService
      .sendData(
        url + '?userId=' + this.userEntity.userId,
        {},
        {
          'X-ACTION-ROLE': actionRole,
        }
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              action === 'approve'
                ? 'User Profile Approved'
                : 'User Profile Rejected'
            );
            this.getTableData();
            this.toUsersPage();
            this.checkerAction = '';
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  toBankList() {
    this.pageNumber = 1;
    this.totalElements = 0;
    this.tableId = 'CMProfileTable';
    this.getCompanyList();
    this.showUsers = false;
  }
  toUsersPage() {
    this.userEntity = new CompanyUser();
    this.userForm = false;
    this.editUser = false;
    this.viewUser = false;
    this.editUserIndex = -1;
    this.legalInfoList = [];
    this.products = [];

    this.loginIDError = false;
    this.firstNameError = false;
    this.lastNameError = false;
    this.profileStatusError = false;
    this.authModeError = false;
    this.timeZoneError = false;
    this.languageError = false;
    this.baseCurrencyError = false;
    this.contactNumberError = false;
    this.emailError = false;
  }

  validateUser(): Boolean {
    let errorCount = 0;
    if (!this.userEntity.loginId) {
      this.loginIDError = true;
      errorCount++;
    }
    if (!this.userEntity.firstName) {
      this.firstNameError = true;
      errorCount++;
    }
    if (!this.userEntity.lastName) {
      this.lastNameError = true;
      errorCount++;
    }
    if (!this.userEntity.userStatus) {
      this.profileStatusError = true;
      errorCount++;
    }
    if (!this.userEntity.authMode) {
      this.authModeError = true;
      errorCount++;
    }
    // if (!this.userEntity.timeZone) {
    //   this.timeZoneError = true;
    //   errorCount++;
    // }
    // if (!this.userEntity.corrLanguage) {
    //   this.languageError = true;
    //   errorCount++;
    // }
    // if (!this.userEntity.baseCurr) {
    //   this.baseCurrencyError = true;
    //   errorCount++;
    // }
    if (!this.userEntity.contactNo) {
      this.contactNumberError = true;
      errorCount++;
    }
    if (!this.userEntity.email) {
      this.emailError = true;
      errorCount++;
    }
    if (errorCount > 0) return false;
    return true;
  }

  // LEGAL INFO POPUP START--------------------------------------------------------
  legalInfoList: LegalInfoDto[] = [];
  legalInfoEntity: LegalInfoDto = new LegalInfoDto();
  showLegalInfoPopup = false;
  legalIdTypeList = [
    'PAN',
    'PASSPORT',
    'AADHAAR',
    'IE CODE',
    'UDYAM No.',
    'OTHER',
  ];
  legalIdTypeError = false;
  legalIdNoError = false;
  legalcountryCodeError = false;
  legalInfoheader = ['Legal Id Type', 'Legal Id No', 'Country Code', 'Action'];
  legalInfoHeaderMap: { [key: string]: string } = {
    'Legal Id Type': 'legalIdType',
    'Legal Id No': 'legalIdNo',
    'Country Code': 'legalIdIssuingAuthority',
  };
  legalInfoColumnWidth = ['25%', '25%', '25%', '25%'];
  deleteLegalInfoDataRow(rowIndex: number) {
    if (this.legalInfoList) {
      const updatedData = [...this.legalInfoList];
      updatedData.splice(rowIndex, 1);
      this.legalInfoList = updatedData;
    }
  }
  editLegalInfoIndex = -1;
  editLegalInfoDataRow(rowIndex: number) {
    if (this.legalInfoList) {
      this.openLegalInfoPopup();
      const selectedRow = this.legalInfoList[rowIndex];
      if (selectedRow) {
        this.legalInfoEntity = new LegalInfoDto(selectedRow);
      }
      // Optionally store index for update later
      this.editLegalInfoIndex = rowIndex;
    }
  }
  saveLegalInfo() {
    let isValid = this.validateLegalInfoForm();
    if (!isValid) return;

    const newRef = new LegalInfoDto(this.legalInfoEntity);
    const currentRefs = this.legalInfoList ?? [];

    if (this.editLegalInfoIndex === -1) {
      this.legalInfoList = [...currentRefs, newRef];
    } else {
      const updatedRefs = [...currentRefs];
      updatedRefs[this.editLegalInfoIndex] = newRef;
      this.legalInfoList = updatedRefs;
      this.editLegalInfoIndex = -1;
    }
    this.closeLegalInfoPopup();
  }
  openLegalInfoPopup() {
    this.legalInfoEntity = new LegalInfoDto();
    this.showLegalInfoPopup = true;
  }
  closeLegalInfoPopup() {
    this.showLegalInfoPopup = false;
    this.cleanLegalInfoData();
  }
  cleanLegalInfoData() {
    this.legalIdNoError = false;
    this.legalIdTypeError = false;
    this.legalcountryCodeError = false;
  }
  validateLegalInfoForm(): Boolean {
    this.cleanLegalInfoData();
    let errorCount = 0;
    if (!this.legalInfoEntity.legalIdType) {
      this.legalIdTypeError = true;
      errorCount++;
    }
    if (!this.legalInfoEntity.legalIdNo) {
      this.legalIdNoError = true;
      errorCount++;
    } else if (this.legalInfoEntity.legalIdType === 'PAN') {
      const alphanumericRegex = /^[a-zA-Z0-9]+$/;
      if (!alphanumericRegex.test(this.legalInfoEntity.legalIdNo)) {
        this.legalIdNoError = true;
        errorCount++;
      }
    }

    if (!this.legalInfoEntity.legalIdIssuingAuthority) {
      this.legalcountryCodeError = true;
      errorCount++;
    }
    if (errorCount > 0) return false;
    return true;
  }
  // Helper method to get property value from row object
  getPropertyValue(
    row: any,
    header: string,
    headerMap: { [key: string]: string }
  ): any {
    const propertyName = headerMap[header];
    return propertyName ? row?.[propertyName] : '';
  }

  // PRODUCT SUBPRODUCT SELECTION---------------------------------------------
  products: Product[] = [];
  getCompanyProducts() {
    this.apiService
      .getData(
        GET_PRO_SUBPRO_MAP_BY_COMPANY_ID + '?companyId=' + this.loginCompanyId,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS' && res.payload) {
            console.log(
              'company products:' + JSON.stringify(res.payload, null, 2)
            );
            this.products = this.mapApiToProducts(res.payload);
            this.cdr.detectChanges();
            console.log(
              'products map for ui:' + JSON.stringify(this.products, null, 2)
            );
          }
        },
        error: (err: any) => {
          console.error('Failed to load company products', err);
        },
      });
  }

  parseIdName(input: string): { id: number; name: string } | null {
    if (typeof input !== 'string') return null;

    const dash = input.indexOf('-');
    if (dash <= 0 || dash === input.length - 1) return null;

    const idPart = input.slice(0, dash).trim();
    const namePart = input.slice(dash + 1).trim();

    const id = Number(idPart);
    if (!Number.isFinite(id) || namePart.length === 0) return null;

    return { id, name: namePart };
  }

  mapApiToProducts(
    payload: Record<string, string[]>,
    options?: {
      sort?: boolean;
      onWarn?: (msg: string) => void;
    }
  ): Product[] {
    const warn = options?.onWarn ?? (() => {});
    const shouldSort = options?.sort ?? true;

    if (!payload || typeof payload !== 'object') return [];

    const products: Product[] = [];

    for (const [productKey, rawSubList] of Object.entries(payload)) {
      const parsedProduct = this.parseIdName(productKey);
      if (!parsedProduct) {
        warn(`Skipping product with invalid format: "${productKey}"`);
        continue;
      }

      const subProducts: SubProduct[] = [];

      (rawSubList ?? []).forEach((raw, idx) => {
        const parsedSub = this.parseIdName(raw);
        if (!parsedSub) {
          warn(
            `Skipping subProduct[${idx}] for "${productKey}" due to invalid format: "${raw}"`
          );
          return;
        }
        subProducts.push({
          subProductId: parsedSub.id,
          name: parsedSub.name,
          selected: false,
        });
      });

      products.push({
        productId: parsedProduct.id,
        name: parsedProduct.name,
        selected: false,
        subProducts,
      });
    }

    if (shouldSort) {
      products.sort((a, b) => a.name.localeCompare(b.name));
      products.forEach((p) =>
        p.subProducts.sort((a, b) => a.name.localeCompare(b.name))
      );
    }

    return products;
  }

  productsToApiRecord(
    products: Product[],
    options?: {
      includeProductIf?: 'productOnly' | 'subOnly' | 'either';
      includeEmptySubList?: boolean;
    }
  ): Record<string, Number[]> {
    const includePolicy = options?.includeProductIf ?? 'either';
    const includeEmpty = options?.includeEmptySubList ?? false;

    const result: Record<string, Number[]> = {};

    if (!Array.isArray(products)) return result;

    for (const p of products) {
      if (!p || typeof p.productId !== 'number' || typeof p.name !== 'string') {
        continue;
      }

      const productKey = `${p.productId}`;

      const selectedSubs = (p.subProducts ?? [])
        .filter(
          (sp) =>
            sp?.selected === true &&
            typeof sp.subProductId === 'number' &&
            typeof sp.name === 'string'
        )
        .map((sp) => sp.subProductId);

      const hasSelectedProduct = p.selected === true;
      const hasSelectedSubs = selectedSubs.length > 0;

      let includeThisProduct = false;

      switch (includePolicy) {
        case 'productOnly':
          includeThisProduct = hasSelectedProduct;
          break;
        case 'subOnly':
          includeThisProduct = hasSelectedSubs;
          break;
        case 'either':
        default:
          includeThisProduct = hasSelectedProduct || hasSelectedSubs;
          break;
      }

      if (includeThisProduct) {
        if (hasSelectedSubs || includeEmpty) {
          result[productKey] = selectedSubs;
        }
      }
    }

    return result;
  }

  applySelectionsFromRelationMapMutating(
    products: Product[],
    relationMap: Record<string, string[]>
  ): void {
    const productById = new Map<number, Product>();
    const productByName = new Map<string, Product>();
    products.forEach((p) => {
      productById.set(p.productId, p);
      productByName.set(p.name.trim().toLowerCase(), p);
    });

    for (const [productKey, subProductKeys] of Object.entries(
      relationMap ?? {}
    )) {
      const { id: pId, name: pName } = this.parseKey(productKey);

      let product: Product | undefined;
      if (pId !== undefined) product = productById.get(pId);
      if (!product && pName)
        product = productByName.get(pName.trim().toLowerCase());
      if (!product) continue;

      product.selected = true;

      const spById = new Map<number, SubProduct>();
      const spByName = new Map<string, SubProduct>();
      product.subProducts.forEach((sp) => {
        spById.set(sp.subProductId, sp);
        spByName.set(sp.name.trim().toLowerCase(), sp);
      });

      for (const spKey of subProductKeys ?? []) {
        const { id: spId, name: spName } = this.parseKey(spKey);

        let sp: SubProduct | undefined;
        if (spId !== undefined) sp = spById.get(spId);
        if (!sp && spName) sp = spByName.get(spName.trim().toLowerCase());
        if (!sp) continue;

        sp.selected = true;
      }
    }
  }
  parseKey(key: string): { id?: number; name?: string } {
    // Splits "1-p1" or "2-p1s2" → { id: 1, name: "p1" / "p1s2" }
    const idx = key.indexOf('-');
    if (idx === -1) {
      const maybeId = Number(key);
      return Number.isFinite(maybeId) ? { id: maybeId } : { name: key.trim() };
    }
    const idPart = key.slice(0, idx).trim();
    const namePart = key.slice(idx + 1).trim();
    const idNum = Number(idPart);
    const id = Number.isFinite(idNum) ? idNum : undefined;
    const name = namePart || undefined;
    return { id, name };
  }

  eqCI(a?: string, b?: string): boolean {
    return !!a && !!b && a.trim().toLowerCase() === b.trim().toLowerCase();
  }

  // When parent checkbox changes
  onProductChange(product: Product): void {
    product.subProducts.forEach((sub) => {
      sub.selected = product.selected;
    });
  }

  // When sub product checkbox changes
  onSubProductChange(product: Product): void {
    product.selected = false;
    const allSelected = product.subProducts.every((sub) => sub.selected);
    product.subProducts.forEach((p) => {
      if (p.selected) {
        product.selected = true;
        return;
      }
    });
    // this.cdr.detectChanges();
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'CMProfileTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getCompanyList();
    } else if (event.tableId === 'CMUserTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    }
  }
  auditFnc(row: any) {
    const url = `${GET_TEMP_USER_BY_ID}?userId=${row.userId}`;

    this.apiService.getData(url, {}).subscribe({
      next: (res: any) => {
        console.log('CM User Audit Response:', res);

        if (res?.status === 'SUCCESS' && res?.payload) {
          this.auditCards = this.createAuditCards(res.payload);
        }

        this.isAuditOpen = true;
      },
      error: (err) => {
        console.error('Audit API Error:', err);
      },
    });
  }

  createAuditCards(payload: any): AuditCard[] {
    const cards: AuditCard[] = [];

    // 🟢 Maker
    if (payload.makerName && payload.createdAt) {
      cards.push({
        label: 'Maker',
        name: payload.makerName,
        datetime: this.formatAuditDate(payload.createdAt),
        status: 'completed',
      });
    }

    // 🟡 Last Modified
    if (payload.editorName && payload.editedAt) {
      cards.push({
        label: 'Last Modified By',
        name: payload.editorName,
        datetime: this.formatAuditDate(payload.editedAt),
        status: 'completed',
      });
    }

    // 🔴 Rejected
    if (payload.rejectedBy && payload.rejectedAt) {
      cards.push({
        label: 'Last Rejected By',
        name: payload.rejectedBy,
        datetime: this.formatAuditDate(payload.rejectedAt),
        status: 'completed',
      });

      return cards; // 🚨 stop if rejected
    }

    // 🟢 Approved
    if (payload.checkerName && payload.approvedAt) {
      cards.push({
        label: 'Last Approved By',
        name: payload.checkerName,
        datetime: this.formatAuditDate(payload.approvedAt),
        status: 'completed',
      });
    }

    return cards;
  }

  formatAuditDate(dateStr: string): string {
    if (!dateStr) return '';
    try {
      let date: Date;
      // ✅ Case 1: ISO format (2026-04-16T13:09:42)
      if (dateStr.includes('T')) {
        date = new Date(dateStr);
      }
      // ✅ Case 2: Custom format (16-04-2026 01:03:33 pm)
      else {
        const parts = dateStr.trim().split(' ');
        if (parts.length < 2) return dateStr;
        const [datePart, timePart, meridian] = parts;
        const [day, month, year] = datePart.split('-').map(Number);
        let [hours, minutes, seconds] = timePart.split(':').map(Number);
        if (meridian?.toLowerCase() === 'pm' && hours < 12) hours += 12;
        if (meridian?.toLowerCase() === 'am' && hours === 12) hours = 0;
        date = new Date(year, month - 1, day, hours, minutes, seconds);
      }
      if (isNaN(date.getTime())) return dateStr;
      return date.toLocaleString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch (e) {
      console.error('Date parse error:', e);
      return dateStr;
    }
  }

  // OTP FUNCTIONS
  isOtpOpen = false;
  otpReference: string = '';
  tempReceivedOtp = '';
  checkerAction: string = '';
  sendOtp(action: string) {
    this.checkerAction = action;
    this.isOtpOpen = true;
    const payload = {
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
    };
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      },
    });
  }

  onOtpResend() {
    const payload = {
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
      otpReference: this.otpReference,
    };
    this.apiService.sendData(SEND_OTP, payload).subscribe({
      next: (res) => {
        if (res.status) {
          //TODO:store opt reference over here
          this.otpReference = res.payload.otpReference;
          this.tempReceivedOtp = res.payload.enteredOtp;
        } else {
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        console.error(err);
      },
    });
  }

  validateOtp(otp: string) {
    const payload = {
      otpReference: this.otpReference,
      enteredOtp: this.tempReceivedOtp, //REPLACE THIS AFTERWARD WITH otp varaible
      loginId: this.sessionService.getLoginId(),
      bankAbbvName: this.sessionService.getCompanyName(),
    };
    this.apiService.sendData(VALIDATE_OTP, payload).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          // TODO: if the otp is validate call onOtpVerify
          this.isOtpOpen = false;
          this.approveRejectForm(this.checkerAction);
        } else {
          this.isOtpOpen = false;
          this.approveRejectForm(this.checkerAction);
          console.log('OTP SEND FAILED');
        }
      },
      error: (err) => {
        this.isOtpOpen = false;
        this.approveRejectForm(this.checkerAction);
        console.error(err);
      },
    });
  }

  closeOtpPopup() {
    this.isOtpOpen = false;
    this.otpReference = '';
    this.tempReceivedOtp = '';
  }
}
