import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from "../../../../commom/table/table.component";
import { PopupComponent } from "../../../../commom/popup/popup.component";

@Component({
  selector: 'app-external-accounts',
  imports: [PageTitleComponent, NgIf, FormsModule, TableComponent, PopupComponent, NgClass, NgFor],
  templateUrl: './external-accounts.component.html',
  styleUrl: './external-accounts.component.css'
})
export class ExternalAccountsComponent {



  //main page vars
  searchAbbreviatedName = '';
  searchName = '';
  searchData(): void {
    const filtered = this.ogData.filter(item => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']?.toLowerCase().includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']?.toLowerCase().includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });

    // ✅ Update reference so child detects change
    this.customerData = [...filtered];
  }
  showEA = false;
  customerHeader = ['Abbreviated Name', 'Company Name', 'Action'];
  customerData: any[] = [
    {
      "Abbreviated Name": "10937234",
      "Company Name": "Big4U"
    },
    {
      "Abbreviated Name": "10943234",
      "Company Name": "Test Name"
    },
  ];
  ogData = this.customerData;
  currentCustomer = {};
  currentCustomerName: string = '';
  currentName: string = '';
  viewCustomerf(row: any, index: number) {
    this.currentCustomer = row;
    this.currentCustomerName = row['Abbreviated Name'] || '';
    this.currentName = row['Company Name'] || '';
    this.showEA = true;
  }


  // accounts page
  searchAccountNumber = '';
  searchCurrency = '';
  searchDesc = '';
  searchStatusList: string[] = ['Awaiting for Approval(D)', 'Awaiting for Approval(M)', 'Awaiting for Approval(N)', 'Checker Returned(D)', 'Checker Returned(M)', 'Checker Returned(N)', 'Draft(M)', 'Draft(N)'];
  searchSelectedStatus = '';

  AccountHeaders = ['Account Number', 'Currency', 'Account Name', 'Description', 'Status', 'Maker', 'Action'];
  AccountData: any[] = [
    {
      "Account Number": "12345678",
      "Currency": "INR",
      "Account Name": "Abhinay",
      "Description": "this is test description for the account description field",
      "Status": "Draft(N)",
      "Maker": "Test User 1",
      "Customer Ref": "0001 OPERA HOUSE",
      "Account Format": "IBAN",
      "Alt Account Number": "ALT12345678",
      "Routing Code": "ROUT123",
      "SWIFT/BIC Code": "SWIFT123",
      "Bank Name": "Test Bank",
      "Bank Address": "Test Address",
      "Country Code": "IN",
      "Active Flag": true,
    },
    {
      "Account Number": "12345123",
      "Currency": "INR",
      "Account Name": "Abhinaya",
      "Description": "this is test description 2 for the account description field",
      "Status": "Draft(N)",
      "Maker": "Test User 1",
      "Customer Ref": "0001 OPERA HOUSE",
      "Account Format": "IBAN",
      "Alt Account Number": "ALT12345123",
      "Routing Code": "ROUT456",
      "SWIFT/BIC Code": "SWIFT456",
      "Bank Name": "Test Bank 2",
      "Bank Address": "Test Address 2",
      "Country Code": "IN",
      "Active Flag": true,
    }
  ];
  ogAccountData = [...this.AccountData];

  searchAccount() {
    const filtered = this.ogAccountData.filter(item => {
      const matchSearchAccount = this.searchAccountNumber
        ? item['Account Number']?.toLowerCase().includes(this.searchAccountNumber.toLowerCase())
        : true;

      const matchSearchCurrency = this.searchCurrency
        ? item['Currency']?.toLowerCase().includes(this.searchCurrency.toLowerCase())
        : true;

      const matchDesc = this.searchDesc
        ? item['Description']?.toLowerCase().includes(this.searchDesc.toLowerCase())
        : true;

      const matchStatus = this.searchSelectedStatus
        ? item['Status']?.toLowerCase().includes(this.searchSelectedStatus.toLowerCase())
        : true;

      return matchSearchAccount && matchSearchCurrency && matchDesc && matchStatus;
    });

    this.AccountData = [...filtered];
  }

  // Popup flags
  addAccountPopup = false;
  viewAccountPopup = false;
  editAccountPopup = false;
  editAccountIndex = -1;

  addAccount() {
    this.addAccountPopup = true;
    this.selectedCustRef = this.currentCustomerName;
  }
  viewAccount(row: any, index: number) {
    this.viewAccountPopup = true;
    this.assignvalues(row);
    this.addAccountPopup = true;
  }
  editAccount(row: any, index: number) {
    this.editAccountPopup = true;
    this.editAccountIndex = index;
    this.assignvalues(row);
    this.addAccountPopup = true;
  }
  deleteAccount(index: number) {
    if (index >= 0 && index < this.AccountData.length) {
      this.AccountData.splice(index, 1);
      this.AccountData = [...this.AccountData];
    }
  }



  // addEdit page detail
  custRefList = ['0001 OPERA HOUSE'];
  selectedCustRef = '';

  accountFormatList = ['IBAN', 'Other'];
  selectedAccountFormat = '';
  accountName = '';
  accountNumber = '';
  altAccountNumber = '';
  currency = '';
  desc = '';
  routingCode = '';
  swiftBICCode = '';
  bankName = '';
  bankAddress = '';
  countryCode = '';
  activeFlag = false;


  custRefError = false;
  accountFormatError = false;
  accountNameError = false;
  accountNumberError = false;
  currencyError = false;
  swiftBICCodeError = false;

  popupText = '';
  popupVisible = false;
  hidePopup() {
    this.popupVisible = false;
  }

  assignvalues(row: any) {
    this.selectedCustRef = row['Customer Ref'] || '';
    this.selectedAccountFormat = row['Account Format'] || '';
    this.accountName = row['Account Name'] || '';
    this.accountNumber = row['Account Number'] || '';
    this.altAccountNumber = row['Alt Account Number'] || '';
    this.currency = row['Currency'] || '';
    this.desc = row['Description'] || '';
    this.routingCode = row['Routing Code'] || '';
    this.swiftBICCode = row['SWIFT/BIC Code'] || '';
    this.bankName = row['Bank Name'] || '';
    this.bankAddress = row['Bank Address'] || '';
    this.countryCode = row['Country Code'] || '';
    this.activeFlag = row['Active Flag'] || false;
  }
  saveAccount() {
    if (!this.isValidAccount())
      return;
    const newData = {
      "Customer Ref": this.selectedCustRef,
      "Account Format": this.selectedAccountFormat,
      "Account Name": this.accountName,
      "Account Number": this.accountNumber,
      "Alt Account Number": this.altAccountNumber,
      "Currency": this.currency,
      "Description": this.desc,
      "Routing Code": this.routingCode,
      "SWIFT/BIC Code": this.swiftBICCode,
      "Bank Name": this.bankName,
      "Bank Address": this.bankAddress,
      "Country Code": this.countryCode,
      "Active Flag": this.activeFlag,
      "Status": "Draft(N)",
      "Maker": "Test User 1"
    }
    if (this.editAccountIndex != -1) {
      this.AccountData.splice(this.editAccountIndex, 1, newData);
    }
    else {
      this.AccountData.push(newData);
    }
    this.AccountData = [...this.AccountData];
    this.popupText = 'Account Details Saved';
    this.popupVisible = true;
    this.clearAccountDetails();
  }
  isValidAccount(): boolean {
    let errorCount = 0;

    // Reset all error flags
    this.custRefError = false;
    this.accountFormatError = false;
    this.accountNameError = false;
    this.accountNumberError = false;
    this.currencyError = false;
    this.swiftBICCodeError = false;

    // Validate each field
    if (!this.selectedCustRef || this.selectedCustRef.trim() === '') {
      this.custRefError = true;
      errorCount++;
    }

    if (!this.selectedAccountFormat || this.selectedAccountFormat.trim() === '') {
      this.accountFormatError = true;
      errorCount++;
    }

    if (!this.accountName || this.accountName.trim() === '') {
      this.accountNameError = true;
      errorCount++;
    }

    if (!this.accountNumber || this.accountNumber.trim() === '') {
      this.accountNumberError = true;
      errorCount++;
    }

    if (!this.currency || this.currency.trim() === '') {
      this.currencyError = true;
      errorCount++;
    }

    if (!this.swiftBICCode || this.swiftBICCode.trim() === '') {
      this.swiftBICCodeError = true;
      errorCount++;
    }

    return errorCount === 0; // true if no errors
  }
  clearAccountDetails() {
    this.addAccountPopup = false;
    this.viewAccountPopup = false;
    this.editAccountPopup = false;
    this.editAccountIndex = -1;

    this.custRefError = false;
    this.accountFormatError = false;
    this.accountNameError = false;
    this.accountNumberError = false;
    this.currencyError = false;
    this.swiftBICCodeError = false;

    this.selectedCustRef = '';
    this.selectedAccountFormat = '';
    this.accountName = '';
    this.accountNumber = '';
    this.altAccountNumber = '';
    this.currency = '';
    this.desc = '';
    this.routingCode = '';
    this.swiftBICCode = '';
    this.bankName = '';
    this.bankAddress = '';
    this.countryCode = '';
    this.activeFlag = false;
  }

}
