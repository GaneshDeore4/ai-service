import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAccountMappingComponent } from './user-account-mapping.component';

describe('UserAccountMappingComponent', () => {
  let component: UserAccountMappingComponent;
  let fixture: ComponentFixture<UserAccountMappingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserAccountMappingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserAccountMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
