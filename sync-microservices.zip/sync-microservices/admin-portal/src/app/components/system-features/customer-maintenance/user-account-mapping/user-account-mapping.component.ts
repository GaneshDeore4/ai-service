import { ChangeDetectorRef, Component, inject } from '@angular/core';
import {
  SUPERADMIN,
  PAGE_SIZE,
} from '../../../../constants/Constants';
import { SessionService } from '../../../../service/sessionService/session.service';
import { ApiService } from '../../../../service/apiService/api.service';
import {
  GET_ACCOUNT_BY_CIF,
  GET_ALL_ACCOUNT_BY_CIF,
  GET_ALL_COMPANIES,
  GET_USER_BY_COMPANY_ID,
  SAVE_USER_ACCOUNT_MAPPING,
  SYNC_API,
} from '../../../../constants/api_endpoints';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { ToastComponent } from '../../../../commom/toast/toast.component';

interface User {
  userId: number;
  firstName: string;
  lastName: string;
  loginId: string;
  account: Account[];
  [key: string]: any;
}
interface Account {
  id: string;
  accountNumber: string;
  currency: string;
  schemeDescription: string;
  schemeType: string;
}
@Component({
  selector: 'app-user-account-mapping',
  imports: [
    NgIf,
    NgFor,
    FormsModule,
    TblComponent,
    ToastComponent,
    LoaderComponent,
  ],
  templateUrl: './user-account-mapping.component.html',
  styleUrl: './user-account-mapping.component.css',
})
export class UserAccountMappingComponent {
  private sessionService = inject(SessionService);
  loginCompanyId: number | null = null;
  loginCompanyName = '';
  loginUserRole = '';
  loginUserName = '';
  loginUserId: number | null = null;
  userId: number | null = null;
  showUsers = false;
  isLoading = false;
  popupText = '';
  popupVisible = false;

  showAccountPopup = false;
  selectedUserIndex: number | null = null;
  linkColumns = ['account'];
  tempSelectedAccountIds: Set<string> = new Set();
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'CMProfileTable';
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  constructor(private apiService: ApiService, private cdr: ChangeDetectorRef) {
    this.loginCompanyId = this.sessionService.getCompanyId() || null;
    this.loginUserRole = this.sessionService.getRole() || '';
    this.loginUserName = this.sessionService.getUsername() || '';
    this.loginUserId = this.sessionService.getUserId() || null;
    this.loginCompanyName = this.sessionService.getCompanyName() || '';
  }

  ngOnInit() {
    this.getCompanyList();
  }

  //main page vars
  searchAbbreviatedName = '';
  searchName = '';
  searchData(): void {
    const filtered = this.ogData.filter((item) => {
      const matchAbbreviated = this.searchAbbreviatedName
        ? item['Abbreviated Name']
          ?.toLowerCase()
          .includes(this.searchAbbreviatedName.toLowerCase())
        : true;

      const matchName = this.searchName
        ? item['Company Name']
          ?.toLowerCase()
          .includes(this.searchName.toLowerCase())
        : true;

      return matchAbbreviated && matchName;
    });
    this.customerData = [...filtered];
  }

  companyHeader: { key: string; value: string }[] = [
    { key: 'abbvName', value: 'Customer ID' },
    { key: 'name', value: 'Customer Name' },
    // { key: 'status', value: 'Status' },
    // { key: 'createdBy', value: 'Maker' },
    { key: 'Action', value: 'Action' },
  ];

  customerData: any[] = [];
  ogData: any[] = [];
  currentCustomer = {};
  currenctCif: string = '';
  currentCustomerName: string = '';
  currentName: string = '';
  viewCustomerf(row: any, index: number) {
    //console.log("row to be checked: " + JSON.stringify(row, null, 2));
    this.currentCustomer = row;
    this.currenctCif = row['cifId'] || row['cif'] || row['cifID'] || '';
    this.currentCustomerName = row['abbvName'] || row['Abbreviated Name'] || '';
    this.currentName = row['companyId'] || row['Company Name'] || '';
    this.loginCompanyId = row.companyId;
    this.showUsers = true;
    this.pageNumber = 1;
    this.totalElements = 0;
    this.tableId = 'AccountMappingTable';
    this.getTableData();
    // this.getAllAccounts();
  }

  getCompanyList() {
    this.isLoading = true;
    this.apiService.getData(GET_ALL_COMPANIES + "?page=" + (this.pageNumber - 1) + "&size=" + this.pageSize, {}).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          this.customerData = res['payload']['content'];
          this.ogData = [...this.customerData];
          if (res.payload.page) {
            this.totalElements = res.payload.page.totalElements;
          }
        }
      },
      error: (err: any) => {
        //console.error('Failed to load companies', err);
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  searchLastName = '';
  searchFirstName = '';
  searchLoginId = '';
  searchSelectedProfileStatus = '';
  searchStatusList: string[] = [
    'Awaiting for Approval(D)',
    'Awaiting for Approval(M)',
    'Awaiting for Approval(N)',
    'Checker Returned(D)',
    'Checker Returned(M)',
    'Checker Returned(N)',
    'Draft(M)',
    'Draft(N)',
  ];
  searchSelectedStatus = '';
  saveBtnVisible = false;
  userHeaders: { key: string; value: string }[] = [
    { key: 'firstName', value: 'First Name' },
    { key: 'lastName', value: 'Last Name' },
    { key: 'loginId', value: 'Login ID' },
    { key: 'account', value: 'Mapped Accounts' },
  ];
  userOgData: User[] = [];
  userData: User[] = [...this.userOgData];

  getTableData() {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_USER_BY_COMPANY_ID + '?companyId=' + this.loginCompanyId + "&page=" + (this.pageNumber - 1) + "&size=" + this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.userData = res.payload.content;
            this.userData;
            this.userOgData = [...this.userData];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  searchUserf(): void {
    const filtered = this.userOgData.filter((item) => {
      const matchLastName = this.searchLastName
        ? item.lastName
          ?.toLowerCase()
          .includes(this.searchLastName.toLowerCase())
        : true;

      const matchFirstName = this.searchFirstName
        ? item.firstName
          ?.toLowerCase()
          .includes(this.searchFirstName.toLowerCase())
        : true;

      const matchLoginId = this.searchLoginId
        ? item.loginId?.toLowerCase().includes(this.searchLoginId.toLowerCase())
        : true;

      return matchLastName && matchFirstName && matchLoginId;
    });

    this.userData = [...filtered];
  }

  accountList: Account[] = [];
  syncApi(cifId: string, callback?: () => void) {
    this.isLoading = true;
    const data = {
      page: 0,
      size: 1000,
    };
    this.apiService.getData(GET_ACCOUNT_BY_CIF + '/' + cifId, data).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          this.accountList = res.payload;
          if (callback) callback();
        }
      },
      error: (err) => {
        this.showToast('error', 'Error', 'Failed to sync accounts');
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  selectedRow: User | null = null;
  selectedUserId: number | null = null;
  onLinkClick(event: { row: User; key: string; index: number }) {
    if (event.key === 'account') {
      this.selectedUserIndex = event.index;
      this.selectedUserId = event.row.userId;
      this.selectedRow = event.row;
      const user = event.row;

      if (!this.currenctCif) {
        this.showToast('error', 'Error', 'Customer ID is missing for this customer');
        return;
      }

      this.isLoading = true;
      console.log("Syncing accounts for CIF: " + this.currenctCif);

      this.apiService.sendData(SYNC_API + '/' + this.currenctCif, {}).subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.syncApi(this.currenctCif, () => {
              // Initialize temporary selection with current user's mapped account IDs
              this.tempSelectedAccountIds = new Set(
                (user.account || []).map((acc) => acc.id?.toString())
              );
              this.showAccountPopup = true;
              this.isLoading = false;
            });
          } else {
            this.isLoading = false;
            this.showToast('error', 'Sync Failed', res.description || 'Failed to sync accounts from host');
          }
        },
        error: (err) => {
          this.isLoading = false;
          console.error('SYNC_API error:', err);
          this.showToast('error', 'Error', 'Network error while syncing accounts');
        }
      });
    }
  }


  isAccountSelected(accountId: any): boolean {
    return this.tempSelectedAccountIds.has(accountId?.toString());
  }

  toggleAccountSelection(account: Account) {
    const id = account.id?.toString();
    if (this.tempSelectedAccountIds.has(id)) {
      this.tempSelectedAccountIds.delete(id);
    } else {
      this.tempSelectedAccountIds.add(id);
    }
  }

  saveAccountSelection() {
    if (this.selectedUserId !== null) {
      const userIndex = this.userData.findIndex(u => u.userId === this.selectedUserId);
      if (userIndex === -1) return;

      const selectedAccounts = this.accountList.filter((acc) =>
        this.tempSelectedAccountIds.has(acc.id?.toString())
      );
      const updatedUser = {
        ...this.userData[userIndex],
        account: [...selectedAccounts],
      };
      this.userData[userIndex] = updatedUser;
      this.userData = [...this.userData]; // Trigger re-render in app-tbl

      // Call the save API for ONLY the selected user as requested
      this.saveMapping(updatedUser);
    }
  }

  closeAccountPopup() {
    this.showAccountPopup = false;
    this.selectedUserIndex = null;
    this.tempSelectedAccountIds.clear();
  }

  saveMapping(singleUser?: User) {
    this.isLoading = true;

    // Determine which users to send (single user or all)
    const targetUsers = singleUser ? [singleUser] : this.userData;

    let mappingRequest: any[] = targetUsers.map((user: User) => ({
      userId: user.userId,
      accountId: (user.account || []).map(
        (account: Account) => account.accountNumber
      ),
    }));
    const data = {
      mappingRequest: mappingRequest,
    };
    this.apiService.sendData(SAVE_USER_ACCOUNT_MAPPING, data).subscribe({
      next: (res) => {
        if (res.status == 'SUCCESS') {
          this.showToast('success', 'Success', 'Mapping saved successfully');
          this.closeAccountPopup(); // Close modal on success
        } else {
          this.showToast('error', 'Error', res.description);
        }
      },
      error: (err) => {
        this.showToast('error', 'Error', 'Something went wrong');
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }
  toBankList() {
    this.pageNumber = 1;
    this.totalElements = 0;
    this.tableId = 'CMProfileTable';
    this.currenctCif = '';
    this.currentCustomerName = '';
    this.currentName = '';
    this.currentCustomer = {};
    this.getCompanyList();
    this.showUsers = false;
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'CMProfileTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getCompanyList();
    } else if (event.tableId === 'AccountMappingTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    }
  }
}
