import {
  GET_ACTION_BY_PRODUCT_ID,
  GET_ACTION_MAPPING,
  GET_ALL_USER_TYPE_MAPPING,
  GET_SUBPRODUCTS_BY_PRODUCT_ID,
  GET_TABS_BY_SUBPRODUCT_ID,
  GET_ACTION_BY_PRODUCT_ID_OR_SUB_PRODUCT_ID,
} from './../../../../constants/api_endpoints';
import { Component } from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  ADD_ACTION_MAPPING,
  GET_ALL_MASTER_TAB,
  GET_ALL_CATEGORY,
  GET_ALL_MASTER_PRODUCT,
  GET_ALL_SUB_PRODUCTS,
  GET_ALL_USERTYPE,
  GET_PRODUCTS_CATEGORY_ID,
  GET_USER_TYPE_BY_CATEGORY_ID,
  GET_MY_ACCESS,
  GET_ALL_MASTER_ACTION,
} from '../../../../constants/api_endpoints';
import { ApiService } from '../../../../service/apiService/api.service';
import { JurisdictionService } from '../../../../service/jurisdiction/jurisdiction.service';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { ToastComponent } from '../../../../commom/toast/toast.component';

interface Subproduct {
  subProductId: number;
  subProductName: string;
  categoryId: number;
  categoryName: string;
  productId: number;
  productName: string;
  productNameLabel: string;
  subProductLabel: string;
}
interface Tab {
  tabId: number;
  tabName: string;
}
interface Action {
  actionNameLabel: undefined;
  actionId?: number;
  actionName?: string;
  id?: number;
  name?: string;
  actionCode?:string
}

interface MultiUserTypePreExistingEntry {
  userTypeId: number;
  userTypeName: string;
  tabMappings: PreExistingEntry[];
}
interface PreExistingEntry {
  productId: number;
  subProductId: number;
  userTypeId: number;
  userTypeName: string;
  tabId: number;
  tabName: string;
  actions: {
    id?: number;
    name?: string;
    actionId?: number;
    actionNameLabel?: string;
    actionCode?:string
  }[];
}

interface ActionCell {
  actionId: number;
  actionNameLabel?: string;
  checked: boolean; // <— whether the action is enabled for that tab
  actionCode?:string
}
interface TabRow {
  tabId: number;
  tabName: string;
  cell: ActionCell[];
}

interface UserTypeRow {
  userTypeId: number;
  userTypeName: string;
  tabRow: TabRow[];
}

@Component({
  selector: 'app-action-mapping-master',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    NgIf,
    NgFor,
    LoaderComponent,
    ToastComponent,
  ],
  templateUrl: './action-mapping-master.component.html',
  styleUrl: './action-mapping-master.component.css',
})
export class ActionMappingMasterComponent {
  constructor(
    private jurisdictionService: JurisdictionService,
    private apiService: ApiService
  ) {}

  popupMsg = '';
  popupVisible = false;
  hidePopup() {
    this.popupMsg = '';
    this.popupVisible = false;
  }

  // Hierarchy Lists
  categoryList: any[] = [];
  userTypeList: any[] = [];
  productList: any[] = [];
  subProductList: Subproduct[] = [];

  // Selections
  selectedCategoryId: number | undefined;
  selectedUserTypeId: number | undefined;
  selectedUserTypeName: string = '';
  selectedProductId: number | undefined;
  selectedSubProductId: number | undefined;

  // Matrix Data
  // Rows: Tabs, Cols: Actions
  actions: Action[] = []; // Dynamic actions from API
  tabs: Tab[] = []; // Dynamic tabs from API

  isLoading = false;
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  isFirstTimeOnPage = false;
  ngOnInit() {
    this.isFirstTimeOnPage = true;
    this.getCategoryList();
  }

  //STEP 1: GET ALL CATEGORIES
  getCategoryList() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe((res: any) => {
        if (res.status === 'SUCCESS') {
          this.categoryList = [...res.payload.content];
          if (this.isFirstTimeOnPage && this.categoryList.length > 0) {
            this.selectedCategoryId = this.categoryList[0].categoryId;
            console.log('selected category: ' + this.selectedCategoryId);
            this.onCategoryChange();
          }
        }
      });
  }

  //STEP 2: GET ALL PRODUCTS FOR THAT CATEGORY
  onCategoryChange() {
    this.clearMatrix();
    if (this.selectedCategoryId) {
      if (this.jurisdictionService) {
        const cat = this.categoryList.find(
          (c) => c.categoryId == this.selectedCategoryId
        );
        this.jurisdictionService.setCategory(cat);
      }
      // Fetch Products
      this.apiService
        .getData(
          `${GET_PRODUCTS_CATEGORY_ID}?categoryId=${
            this.selectedCategoryId + '&page=0&size=1000'
          }`,
          {}
        )
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.productList = Array.isArray(res.payload)
              ? res.payload
              : res.payload.content || [];
            if (this.isFirstTimeOnPage && this.productList.length > 0) {
              this.selectedProductId = this.productList[0].productId;
              console.log('selected product: ' + this.selectedProductId);
              this.onProductChange();
            }
          }
        });
    }
  }

  //STEP 3 : GET ALL SUB PRODUCTS
  onProductChange() {
    if (this.selectedProductId) {
      this.subProductList = [];
      this.selectedSubProductId = undefined;
      this.clearMatrix();

      this.apiService
        .getData(
          GET_SUBPRODUCTS_BY_PRODUCT_ID +
            '?productId=' +
            this.selectedProductId +
            '&page=0&size=1000',
          {}
        )
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.subProductList = [...res.payload];
            if (this.isFirstTimeOnPage && this.subProductList.length > 0) {
              this.selectedSubProductId = this.subProductList[0].subProductId;
              this.onSubProductChange();
              console.log('selected sub pro: ' + this.selectedSubProductId);
            }
          }
        });
    }
  }

  //STEP 4 : GET ALL TABS ON SUBPRODUCTID
  onSubProductChange() {
    this.clearMatrix();
    console.log(this.selectedSubProductId);
    if (this.selectedSubProductId === null) {
      this.apiService
        .getData(
          GET_TABS_BY_SUBPRODUCT_ID + '?productId=' + this.selectedProductId,
          {}
        )
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.tabs = [...res.payload];
            this.getActionsList();
            // if (this.isFirstTimeOnPage && this.tabs.length > 0) {
            this.getAllUserTypes();
            // }
          }
        });
    } else {
      this.apiService
        .getData(
          GET_TABS_BY_SUBPRODUCT_ID +
            '?subProductId=' +
            this.selectedSubProductId +
            '&productId=' +
            this.selectedProductId,
          {}
        )
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.tabs = [...res.payload];
            this.getActionsList();
            // if (this.isFirstTimeOnPage && this.tabs.length > 0) {
            this.getAllUserTypes();
            // }
          }
        });
    }
  }

  //STEP 5 : GET ALL ACTIONS USING PRODUCTID
  getActionsList() {
    this.actions = [];
    if (this.selectedSubProductId === null) {
      this.apiService
        .getData(
          GET_ACTION_BY_PRODUCT_ID_OR_SUB_PRODUCT_ID 
            +'?productId=' +
            this.selectedProductId,
          {}
        )
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.actions = [...res.payload];
          }
        });
    } else {
      this.apiService
        .getData(
          GET_ACTION_BY_PRODUCT_ID_OR_SUB_PRODUCT_ID +
          '?subProductId=' +
          this.selectedSubProductId +
          '&productId=' +
          this.selectedProductId,
          {}
        )
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.actions = [...res.payload];
          }
        });
    }
  }

  //STEP 6 : GET ALL USER TYPES
  getAllUserTypes() {
    this.selectedUserTypeId = undefined;
    this.selectedUserTypeName = '';
    this.apiService
      .getData(
        `${GET_USER_TYPE_BY_CATEGORY_ID}?categoryId=${
          this.selectedCategoryId + '&page=0&size=1000'
        }`,
        {}
      )
      .subscribe((res: any) => {
        if (res.status === 'SUCCESS') {
          this.userTypeList = Array.isArray(res.payload)
            ? res.payload
            : res.payload.content || [];
          console.log(this.userTypeList);
          if (this.userTypeList.length > 0) {
            this.userTypeList.unshift({
              userTypeId: -1,
              userTypeName: 'All',
              categoryId: 1,
              categoryName: 'Client',
              createdAt: null,
              userTypeNameLabel: 'All',
              tabActionMapping: null,
            });
          }
          // if (this.isFirstTimeOnPage && this.userTypeList.length > 0) {
          this.selectedUserTypeId = this.userTypeList[0].userTypeId;
          this.selectedUserTypeName = this.userTypeList[0].userTypeNameLabel;
          this.onUserTypeChange();
          console.log('selected user: ' + this.selectedUserTypeId);
          // }
        }
      });
  }

  //STEP 7 : GET THE EXISTING MAPPING BASED ON SELECTED USER TYPE
  onUserTypeChange() {
    if (this.selectedUserTypeId) {
      this.tableRow = [];
      this.exisitingMapping = [];
      this.existingMultiUserTypeMapping = [];
      //FUNCTION TO FIND USERTYPENAME FROM USERTYPELIST FOR THE SELECTED USERTYPEID
      this.selectedUserTypeName =
        this.userTypeList.find(
          (userType) =>
            Number(userType.userTypeId) === Number(this.selectedUserTypeId)
        )?.userTypeName || '';

      console.log('user type id test: ' + this.selectedUserTypeId);
      console.log('user type name test: ' + this.selectedUserTypeName);

      this.isLoading = true;
      this.isFirstTimeOnPage = false;
      this.getExistingMapping();
    }
  }

  exisitingMapping: PreExistingEntry[] = [];
  existingMultiUserTypeMapping: MultiUserTypePreExistingEntry[] = [];
  getExistingMapping() {
    const req = {
      userTypeId: this.selectedUserTypeId, //THIS IS NOT NEEDED IN GET_ALL_USERTYPE_MAPPING API, SO IT WILL GO AS -1
      productId: this.selectedProductId,
      categoryId: this.selectedCategoryId,
      subProductId: this.selectedSubProductId,
      tabIds: this.tabs.map((tab) => tab.tabId),
    };
    if (Number(this.selectedUserTypeId) === -1) {
      //THIS REQUEST IS FOR GETTING RESPONSE WITH ALL USERTYPES
      this.apiService
        .sendData(GET_ALL_USER_TYPE_MAPPING, req)
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.existingMultiUserTypeMapping = [...res.payload];
            console.log(
              'exisitng tab actions : ' +
                JSON.stringify(this.existingMultiUserTypeMapping, null, 2)
            );
            this.loadMatrix();
          }
        });
    } else {
      //THIS REQUEST IS FOR GETTING RESPONSE WITH SINGLE SELECTED USERTYPE
      this.apiService
        .sendData(GET_ACTION_MAPPING, req)
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.exisitingMapping = [...res.payload];
            console.log(
              'exisitng tab actions : ' +
                JSON.stringify(this.exisitingMapping, null, 2)
            );
            this.loadMatrix();
          }
        });
    }
  }

  //STEP 8 : BUILD MATRIX
  // --- Matrix Logic ---
  tableRow: UserTypeRow[] = [];
  loadMatrix() {
    // THIS LOGIC CROSS MULTIPLIES ALL TABS FOR ALL ACTIONS
    this.tableRow = [];
    let rows: TabRow[] = [];
    rows = this.tabs.map((tab) => ({
      tabId: tab.tabId,
      tabName: tab.tabName,
      cell: this.actions.map((h) => ({
        actionId: (h.actionId !== undefined ? h.actionId : h.id) as number,
        actionNameLabel: (h.actionNameLabel !== undefined
          ? h.actionNameLabel
          : h.name) as string,
          actionCode: (h.actionCode !== undefined
          ? h.actionCode
          : h.name) as string,
        checked: false,
      })),
    }));

    //THIS LOGICS ADDS THE ABOVE MADE MATRIX TO SELECTED USERTYPE (BE IT ALL OR ONE)
    if (Number(this.selectedUserTypeId) === -1) {
      //IF ALL USERTYPE SELECTED
      for (let i = 1; i < this.userTypeList.length; i++) {
        this.tableRow.push({
          userTypeId: this.userTypeList[i].userTypeId,
          userTypeName: this.userTypeList[i].userTypeNameLabel,
          tabRow: JSON.parse(JSON.stringify(rows)),
        });
      }
    } else {
      if (this.selectedUserTypeId) {
        this.tableRow.push({
          userTypeId: this.selectedUserTypeId,
          userTypeName: this.selectedUserTypeName,
          tabRow: JSON.parse(JSON.stringify(rows)),
        });
      }
    }
    this.mapExistingMapping();
  }

  //STEP 9 : FILL THE BUILT MATRIX WITH PRE-EXISTING ENTRIES
  mapExistingMapping() {
    this.tableRow.forEach((userRow) => {
      let mappingsToUse: PreExistingEntry[] = [];

      // Determine which source of mappings to use for this specific UserType
      if (Number(this.selectedUserTypeId) === -1) {
        const userMapping = this.existingMultiUserTypeMapping.find(
          (m) => Number(m.userTypeId) === Number(userRow.userTypeId)
        );
        mappingsToUse = userMapping ? userMapping.tabMappings : [];
      } else {
        mappingsToUse = this.exisitingMapping;
      }

      // Iterate over the tabs and assign the checked value to the cells
      userRow.tabRow.forEach((tab) => {
        const tabMapping = mappingsToUse.find(
          (t) => Number(t.tabId) === Number(tab.tabId)
        );

        if (tabMapping && tabMapping.actions) {
          tab.cell.forEach((cell) => {
            cell.checked = tabMapping.actions.some((a) => {
              // const aId = a.actionId !== undefined ? a.actionId : a.id;
              const aId = a.actionId !== undefined ? a.actionId : a.name;
              return (
                aId !== undefined &&
                cell.actionId !== undefined &&
                Number(aId) === Number(cell.actionId)
              );
            });
          });
        }
      });
    });

    this.isLoading = false;
  }

  noMappingText = false;
  saveMatrix() {
    if (
      !this.selectedProductId ||
      !this.selectedUserTypeId 
    ) {
      this.showToast(
        'warning',
        'Validation',
        'Please select Product, and User Type first'
      );
      return;
    }
    this.isLoading = true;
    const userTypeTabActionMappingReqDtos = this.tableRow.map((userRow) => {
      const tabActionMappingReqDtoList = userRow.tabRow.map((tab) => {
        const selectedActionIds = tab.cell
          .filter((c) => c.checked)
          .map((c) => c.actionId);
        return {
          tabId: tab.tabId,
          actionIdList: selectedActionIds,
        };
      });

      return {
        userTypeId: userRow.userTypeId,
        tabActionMappingReqDtoList: tabActionMappingReqDtoList,
      };
    });

    const payload = {
      productId: this.selectedProductId,
      subProductId: this.selectedSubProductId,
      userTypeTabActionMappingReqDtos: userTypeTabActionMappingReqDtos,
    };

    this.apiService.sendData(ADD_ACTION_MAPPING, payload).subscribe({
      next: (res: any) => {
        if (res.status === 'SUCCESS') {
          this.showToast(
            'success',
            'Success',
            'Action Mapping Saved Successfully'
          );
          // this.clearMatrix();
          this.isFirstTimeOnPage = false;
        } else {
          this.showToast(
            'error',
            'Error',
            res.description || 'Failed to save mapping'
          );
        }
      },
      error: () => {
        this.showToast(
          'error',
          'Error',
          'Something went wrong saving the mapping'
        );
        this.isLoading = false;
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  clearMatrix() {
    // this.noMappingText = false;
    // this.selectedProductId = undefined;
    // this.selectedUserTypeId = undefined;
    // this.selectedSubProductId = undefined;
    // this.selectedCategoryId = undefined;
    // this.productList = [];
    // this.subProductList = [];
    // this.userTypeList = [];
    this.tabs = [];
    this.actions = [];
    this.exisitingMapping = [];
    this.existingMultiUserTypeMapping = [];
    this.tableRow = [];
  }

  togglePermission(cell: ActionCell) {
    cell.checked = !cell.checked;
  }
}
