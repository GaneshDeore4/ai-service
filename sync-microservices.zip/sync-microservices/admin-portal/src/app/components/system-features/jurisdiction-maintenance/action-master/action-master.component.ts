import {
  CREATE_MASTER_ACTION,
  EDIT_MASTER_ACTION,
  GET_ALL_CATEGORY,
  GET_ALL_MASTER_ACTION,
  GET_ALL_SUBPRO_BY_PRO_LIST,
  GET_ALL_TEMP_ACTION,
  GET_SUBPRODUCTS_BY_PRODUCT_ID,
  REJECT_ACTION,
  APPROVE_ACTION,
} from './../../../../constants/api_endpoints';
import { Component, OnInit } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { FormsModule } from '@angular/forms';
import { NgClass, NgFor, NgForOf, NgIf } from '@angular/common';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { ApiService } from '../../../../service/apiService/api.service';
import { GET_ALL_MASTER_PRODUCT } from '../../../../constants/api_endpoints';
import { MultiSelectModule } from 'primeng/multiselect';
import { FloatLabelModule } from 'primeng/floatlabel';
import { SessionService } from '../../../../service/sessionService/session.service';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  BANKSUPERADMINCHECKER,
  BANKSUPERADMINMAKER,
  PAGE_SIZE,
  SUPERADMIN,
} from '../../../../constants/Constants';
import { SelectModule } from 'primeng/select';
import { UserAuditComponent } from '../../../../commom/user-audit/user-audit.component';
export interface ActionEntity {
  actionId?: number;

  categoryId?: number;
  productId?: number; // multi-select
  subProductId?: number;

  actionCode?: string; // 🔥 renamed
  actionDescription?: string; // 🔥 new

  createdDate?: string;
  createdBy?: string;
  updatedDate?: string;
  updatedBy?: string;

  products?: { [key: string]: string };
  productCount?: number;
  status?: string;
}
interface ProductEntity {
  productId?: number;
  productName?: string;
  productNameLabel?: string;
}
@Component({
  selector: 'app-action-master',
  imports: [
    FormsModule,
    NgIf,
    NgFor,
    NgForOf,
    TblComponent,
    LoaderComponent,
    NgClass,
    MultiSelectModule,
    FloatLabelModule,
    ToastComponent,
    SelectModule,
    UserAuditComponent,
  ],
  templateUrl: './action-master.component.html',
  styleUrl: './../master-setup.css',
})
export class ActionMasterComponent {
  loggedInRole = '';
  loggedInLoginid = '';
  constructor(
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.loginUserRole = sessionService.getRole();
  }
  ngOnInit() {
    this.loggedInRole = this.sessionService.getRole();
    this.loggedInLoginid = this.sessionService.getLoginId();
    this.getTableData();
  }
  mode: 'add' | 'edit' | 'view' = 'add';
  isAuditOpen = false;
  auditCards: any[] = [];
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }

  auditFnc(row: any) {
    this.auditCards = this.createAuditCards(row);
    this.isAuditOpen = true;
  }

  createAuditCards(row: any) {
    const cards: any[] = [];
    // Maker
    if (row.makerName && row.createdAt) {
      cards.push({
        label: 'Created By',
        name: row.makerName,
        datetime: this.formatAuditDate(row.createdAt),
        status: 'completed',
      });
    }
    // Editor
    if (row.editorName && row.editedAt) {
      cards.push({
        label: 'Last Edited By',
        name: row.editorName,
        datetime: this.formatAuditDate(row.editedAt),
        status: 'completed',
      });
    }
    // Rejected (priority)
    if (row.rejectedBy && row.rejectedAt) {
      cards.push({
        label: 'Rejected By',
        name: row.rejectedBy,
        datetime: this.formatAuditDate(row.rejectedAt),
        status: 'completed',
      });
      return cards; // stop here if rejected
    }
    // Approved
    if (row.checkerName && row.approvedAt) {
      cards.push({
        label: 'Approved By',
        name: row.checkerName,
        datetime: this.formatAuditDate(row.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  loginUserRole: string = '';
  totalElements: number = 0;
  tableId: string = 'actionTable';
  categoryData: any[] = [];
  subProductData: any[] = [];
  searchProduct = '';
  header: { key: string; value: string }[] = [
    { key: 'categoryName', value: 'Category' },
    { key: 'productName', value: 'Product Name' },
    { key: 'subProductName', value: 'Sub-Product Name' },
    { key: 'actionCode', value: 'Action Name' }, // 👈 your requirement
    { key: 'status', value: 'Status' },
    { key: 'Action', value: 'Action' },
  ];
  data: ActionEntity[] = [];
  ogData: ActionEntity[] = [];
  actionEntity: ActionEntity = {};
  popupText = '';
  popupVisible = false;
  actionPopup = false;
  isLoading = false;
  actions: string | undefined = '';
  editIndex = -1;
  productData: ProductEntity[] = [];
  selectedProducts: number = -1;

  onProductChange() {
    this.actionEntity.subProductId = undefined;

    if (!this.actionEntity.productId) return;

    this.apiService
      .getData(
        GET_SUBPRODUCTS_BY_PRODUCT_ID +
          '?productId=' +
          this.actionEntity.productId,
        {}
      )
      .subscribe((res: any) => {
        if (res.status === 'SUCCESS') {
          this.subProductData = res.payload;
        }
      });
  }

  getActions(): string[] {
    if (this.loginUserRole === BANKSUPERADMINCHECKER) {
      return ['view', 'audit']; // 👈 only view for checker
    }

    if (
      this.loginUserRole === SUPERADMIN ||
      this.loginUserRole === BANKSUPERADMINMAKER
    ) {
      return ['edit', 'audit']; // 👈 makers
    }

    return ['audit']; // fallback
  }

  search() {
    if (!this.searchProduct || this.searchProduct.trim() === '') {
      this.data = [...this.ogData];
      return;
    }
    const searchTerm = this.searchProduct.toLowerCase();
    this.data = this.ogData.filter(
      (item) =>
        item.actionCode && item.actionCode.toLowerCase().includes(searchTerm)
    );
  }

  getProductList() {
    this.apiService
      .getData(GET_ALL_MASTER_PRODUCT + '?page=0&size=1000', {})
      .subscribe({
        next: (res) => {
          console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.productData = [];
            this.productData = res.payload.content.map((item: any) => ({
              productName: item.productName,
              productId: item.productId,
              productNameLabel: item.productNameLabel,
            }));
            console.log('getProductList :', this.productData);
          } else {
            this.showToast('error', 'Error', res.description);
          }
          console.log('data res : ' + this.productData);
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  getTableData() {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_ALL_TEMP_ACTION +
          '?page=' +
          (this.pageNumber - 1) +
          '&size=' +
          this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.data = (res?.payload?.content ?? []).map((item: any) => ({
              actionId: item.actionId,
              // UI fields
              categoryName: item.categoryName || item.product?.categoryName,
              productName:
                item.product?.productNameLabel || item.product?.productName,
              subProductName:
                item.subProduct?.subProductLabel ||
                item.subProduct?.subProductName,
              actionCode: item.actionCode,
              status: item.status,
              // IDs (for edit)
              categoryId: item.product?.categoryId,
              productId: item.product?.productId,
              subProductId: item.subProduct?.subProductId,
              actionDescription: item.actionNameLabel,
              // 🔥 ADD THESE FOR AUDIT
              makerName: item.makerName,
              checkerName: item.checkerName,
              createdAt: item.createdAt,
              approvedAt: item.approvedAt,
              editorName: item.editorName,
              editedAt: item.editedAt,
              rejectedBy: item.rejectedBy,
              rejectedAt: item.rejectedAt,
            }));
            this.data = [...this.data];
            this.ogData = [...this.data];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
            console.log('get all actions res : ' + res);
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getAllCategories() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe((res: any) => {
        if (res.status === 'SUCCESS') {
          this.categoryData = res.payload.content;
        }
        console.log(this.categoryData);
      });
  }

  getSubProductsByProduct(productIds: number[]) {
    this.apiService
      .sendData(GET_ALL_SUBPRO_BY_PRO_LIST, productIds)
      .subscribe((res: any) => {
        if (res.status === 'SUCCESS') {
          this.subProductData = res.payload;
        }
      });
  }

  addActionf() {
    this.mode = 'add';

    this.editIndex = -1;

    this.actionEntity = {
      categoryId: undefined,
      productId: undefined,
      subProductId: undefined,
      actionCode: '',
      actionDescription: '',
    };

    // clear dropdown data
    this.subProductData = [];

    this.getAllCategories();
    this.getProductList();

    this.actionPopup = true;
  }
  viewAction = false;
  viewActionsf(row: ActionEntity, index: number) {
    this.mode = 'view';
    this.actionPopup = true;

    this.getAllCategories();
    this.getProductList();

    this.actionEntity = {
      ...row,
      categoryId: row.categoryId,
      productId: row.productId,
    };

    if (row.productId) {
      this.onProductChange();

      setTimeout(() => {
        this.actionEntity.subProductId = row.subProductId;
      }, 300);
    }
  }
  editAction = false;

  editActionsf(row: ActionEntity, index: number) {
    this.editIndex = index;
    this.mode = 'edit';

    this.actionPopup = true;

    // STEP 1: Load categories
    this.getAllCategories();

    // STEP 2: Load products
    this.getProductList();

    // STEP 3: assign base values
    this.actionEntity = {
      ...row,
      categoryId: row.categoryId,
      productId: row.productId,
      subProductId: undefined, // temp reset
    };

    // STEP 4: Load sub products AFTER product set
    if (row.productId) {
      this.apiService
        .getData(
          GET_SUBPRODUCTS_BY_PRODUCT_ID + '?productId=' + row.productId,
          {}
        )
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.subProductData = res.payload;

            // ✅ IMPORTANT: assign AFTER options loaded
            this.actionEntity.subProductId = row.subProductId;
          }
        });
    }
  }
  onCategoryChange() {
    this.actionEntity.productId = undefined;
    this.actionEntity.subProductId = undefined;

    this.getProductList(); // ideally pass categoryId if API supports
  }
  deleteActionsf(row: any, index: number) {
    this.data.splice(index, 1);
    this.data = [...this.data];
  }
  saveAction() {
    if (!this.validateRole()) return;
    this.isLoading = true;
    const isEdit = this.editIndex !== -1;
    const payload = {
      actionId: isEdit ? this.actionEntity.actionId : null,
      categoryId: this.actionEntity.categoryId,
      productId: this.actionEntity.productId,
      subProductId: this.actionEntity.subProductId || null,
      actionCode: this.actionEntity.actionCode,
      // 🔥 IMPORTANT MAPPING
      actionNameLabel: this.actionEntity.actionDescription,
      isUpdate: isEdit,
    };
    console.log('FINAL PAYLOAD:', payload);
    this.apiService
      .sendData(CREATE_MASTER_ACTION, payload, {
        'X-ACTION-ROLE': isEdit ? 'EDIT' : 'CREATE',
      })
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              isEdit
                ? 'Action Updated Successfully'
                : 'Action Created Successfully'
            );
            this.getTableData();
            this.closeActionForm();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          const msg = err?.error?.description || err?.error?.message || '';
          if (
            msg.toLowerCase().includes('duplicate') ||
            msg.toLowerCase().includes('already exists')
          ) {
            this.showToast('error', 'Duplicate', 'Action already exists');
            this.isLoading = false;
          } else {
            this.showToast('error', 'Error', 'Something went wrong');
          }
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  errorCount = 0;
  productError = false;
  productErrorMsg = '';
  actionError = false;
  actionErrorMsg = '';
  validateRole(): boolean {
    this.errorCount = 0;
    this.productError = false;
    this.productErrorMsg = '';
    this.actionError = false;
    this.actionErrorMsg = '';
    if (!this.actionEntity.categoryId) {
      this.errorCount++;
      this.showToast('error', 'Error', 'Category required');
    }

    if (!this.actionEntity.productId) {
      this.errorCount++;
      this.showToast('error', 'Error', 'Select product');
    }

    if (!this.actionEntity.actionCode) {
      this.errorCount++;
      this.showToast('error', 'Error', 'Action Code required');
    }
    return this.errorCount == 0 ? true : false;
  }
  closeActionForm() {
    this.actionPopup = false;
    this.actionEntity = {
      categoryId: undefined,
      productId: undefined,
      subProductId: undefined,
      actionCode: '',
      actionDescription: '',
    };
    this.subProductData = [];
    this.productData = [];
    this.editIndex = -1;
    this.mode = 'add';
  }

  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'actionTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }

  approve() {
    if (!this.actionEntity.actionId) return;

    this.isLoading = true;

    this.apiService
      .sendData(
        APPROVE_ACTION + `?actionId=${this.actionEntity.actionId.toString()}`,
        {},
        {
          'X-ACTION-ROLE': 'APPROVE',
        }
      )
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Approved', 'Action approved');
            this.getTableData();
            this.closeActionForm();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Approval failed');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  reject() {
    if (!this.actionEntity.actionId) return;

    this.isLoading = true;

    this.apiService
      .sendData(
        REJECT_ACTION + `?actionId=${this.actionEntity.actionId.toString()}`,
        {},
        {
          'X-ACTION-ROLE': 'REJECT',
        }
      )
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Rejected', 'Action rejected');
            this.getTableData();
            this.closeActionForm();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Rejection failed');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
}
