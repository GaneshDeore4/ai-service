import { ChangeDetectorRef, Component } from '@angular/core';
import { NgClass, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { ApiService } from '../../../../service/apiService/api.service';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import { CREATE_MASTER_CATEGORY, EDIT_MASTER_CATEGORY, GET_ALL_CATEGORY } from '../../../../constants/api_endpoints';
import { LoaderComponent } from "../../../../commom/loader/loader.component";
import { PAGE_SIZE } from '../../../../constants/Constants';

export interface Category {
  categoryId?: number;
  categoryName?: string;
  createdAt?: string;
}
@Component({
  selector: 'app-category-master',
  imports: [
    NgIf,
    FormsModule,
    TblComponent,
    NgClass,
    LoaderComponent,
    ToastComponent,
  ],
  templateUrl: './category-master.component.html',
  styleUrl: './../master-setup.css',
})
export class CategoryMasterComponent {
  constructor(private apiService: ApiService) {}
  ngOnInit() {
    this.getTableData();
  }
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };

      // Pagination state
    pageNumber: number = 1;
    pageSize: number = PAGE_SIZE;
    totalElements: number = 0;
    tableId:string='categoryTable';

  popupMsg = '';
  popupVisible = false;
  popupText = '';
  addCategory = false;
  isLoading = false;
  searchCategory = '';
  editCategory: boolean = false;
  editIndex = -1;
  categoryEntity: Category = {};
  headers: { key: string; value: string }[] = [
    { key: 'categoryName', value: 'Category Name' },
    { key: 'Action', value: 'Action' },
  ];
  // temp data
  data: Category[] = [];

  categoryNameError = false;

  getTableData() {
    this.isLoading = true;
    this.apiService.getData(GET_ALL_CATEGORY+"?page="+(this.pageNumber-1)+"&size="+this.pageSize, {}).subscribe({
      next: (res: any) => {
        if (res.status == 'SUCCESS') {
          this.data = res.payload.content;
          if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
          }
        }
        else {
          this.popupText = res.description;
          this.popupVisible = true;
        }
      },
      error: (err: any) => {
        this.popupText = 'Someting went wrong';
        this.popupVisible = true;
      },
      complete: () => {
        this.isLoading = false;
      },
    });
  }

  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }

  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  hidePopup() {
    this.popupMsg = '';
    this.popupVisible = false;
  }
  addCategoryf() {
    this.categoryEntity = {};
    this.addCategory = true;
  }
  editCategoryf(row: Category, index: number) {
    console.log('edit row:' + JSON.stringify(row, null, 2));
    this.categoryEntity = row;
    this.editIndex = index;
    this.addCategory = true;
    this.editCategory = true;
  }
  deleteCategory(row: Category, index: number) {
    this.data.splice(index, 1);
    this.data = [...this.data];
  }
  saveCategory() {
    if (!this.validateCategory()) return;
    else {
      let data = {};
      if (this.editCategory) {
        data = {
          categoryId: this.categoryEntity.categoryId,
          categoryName: this.categoryEntity.categoryName,
        };
      } else {
        data = {
          categoryName: this.categoryEntity.categoryName,
        };
      }
      this.isLoading = true;
      this.apiService
        .sendData(
          this.editCategory ? EDIT_MASTER_CATEGORY : CREATE_MASTER_CATEGORY,
          data
        )
        .subscribe({
          next: (res) => {
            if (res.status == 'SUCCESS') {
              console.log('category data' + JSON.stringify(res, null, 2));
              this.getTableData();
              this.showToast(
                'success',
                'Success',
                this.editCategory
                  ? 'Category Edited Successfully'
                  : 'Category Saved Successfully'
              );

              this.closeFormPopup();
            } else {
              this.showToast('error', 'Error', res.description);
            }
          },
          error: (err) => {
            this.showToast('error', 'Error', 'Something went wrong');
          },
          complete: () => {
            this.isLoading = false;
          },
        });
    }
  }

  errorCount = 0;
  validateCategory(): boolean {
    if (!this.categoryEntity.categoryName) {
      this.errorCount++;
      this.categoryNameError = true;
    }
    return this.errorCount == 0 ? true : false;
  }
  closeFormPopup() {
    this.errorCount = 0;
    this.addCategory = false;
    this.editIndex = -1;
    this.editCategory = false;
    this.categoryNameError = false;
  }

    onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if(event.tableId!==this.tableId){
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId??'';
    }
    if (event.tableId === 'categoryTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData(); 
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }
}
