import { Component } from '@angular/core';
import { NgClass, NgIf } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import { NgFor } from '@angular/common';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import {
  BANKSUPERADMINCHECKER,
  BANKSUPERADMINMAKER,
  PAGE_SIZE,
  SUPERADMIN,
} from '../../../../constants/Constants';
import { ApiService } from '../../../../service/apiService/api.service';
import {
  GET_ALL_DEPARTMENTS,
  ADD_DEPARTMENTS,
  GET_ALL_CATEGORY,
  GET_ALL_TEMP_DEPARTMENTS,
  APPROVE_DEPARTMENT,
  REJECT_DEPARTMENT,
} from '../../../../constants/api_endpoints';
import { SessionService } from '../../../../service/sessionService/session.service';
import { UserAuditComponent } from '../../../../commom/user-audit/user-audit.component';
export interface Department {
  departmentId?: number;
  departmentName?: string;
  departmentNameLabel?: string; // 🔥 optional (future safe)
  categoryId?: number;
  categoryName?: string;
  createdAt?: string;
  status?: string;
}

export interface CategoryMap {
  categoryId?: number;
  categoryName?: string;
}
@Component({
  selector: 'app-department-master',
  imports: [
    NgIf,
    FormsModule,
    TblComponent,
    NgClass,
    LoaderComponent,
    ToastComponent,
    UserAuditComponent,
    NgFor,
  ],
  templateUrl: './departments.component.html',
  styleUrl: './../master-setup.css',
})
export class DepartmentsComponent {
  loginUserRole: string = '';
  constructor(
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.loginUserRole = sessionService.getRole();
  }
  // 🔔 TOAST
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  categoryError = false;
  isAuditOpen = false;
  auditCards: any[] = [];
  categoryList: CategoryMap[] = [];
  originalDepartmentName: string | undefined = '';
  // UI STATE
  addDepartment = false;
  editDepartment: boolean = false;
  editIndex = -1;
  isLoading = false;
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'categoryTable';
  departmentEntity: Department = {};

  // TABLE
  headers = [
    { key: 'categoryName', value: 'Category' },
    { key: 'departmentNameLabel', value: 'Department Name' },
    { key: 'status', value: 'Status' },
    { key: 'Action', value: 'Action' },
  ];

  data: Department[] = [
    { departmentId: 1, departmentName: 'Finance' },
    { departmentId: 2, departmentName: 'HR' },
    { departmentId: 3, departmentName: 'IT' },
  ];

  // VALIDATION
  departmentNameError = false;
  isViewMode: boolean = false;
  statuses = ['All', 'PENDING APPROVAL', 'APPROVED', 'RETURNED'];

  selectedCategory: string = 'All';
  selectedStatus: string = 'All';
  searchDepartment = '';
  fullData: any[] = [];
  isFilterMode: boolean = false;

  addBtnAllowed(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER
    )
      return true;
    else return false;
  }

  // ➕ ADD
  addDepartmentf() {
    // this.departmentEntity = {
    //   departmentName: '',
    //   departmentNameLabel: '', // ✅ ADD THIS
    // };

    this.departmentEntity = {
      departmentName: '',
      departmentNameLabel: '', // ✅ ADD THIS
      categoryId: 2, // Default to Bank Category (ID 2)
    };

    this.categoryError = false;
    this.departmentNameError = false;

    this.addDepartment = true;
    this.editDepartment = false;
  }

  // 🗑 DELETE
  deleteDepartment(row: Department, index: number) {
    this.data.splice(index, 1);
    this.data = [...this.data];

    this.showToast('success', 'Success', 'Department deleted');
  }

  // ✅ VALIDATION
  validateDepartment(): boolean {
    this.departmentNameError = false;
    this.categoryError = false;

    if (!this.departmentEntity.categoryId) {
      this.categoryError = true;
      return false;
    }

    if (!this.departmentEntity.departmentNameLabel) {
      this.departmentNameError = true;
      return false;
    }

    return true;
  }
  viewDepartment(row: Department) {
    this.isViewMode = true;

    this.departmentEntity = {
      ...row,
      departmentNameLabel: row?.departmentNameLabel,
    };

    this.originalDepartmentName = row?.departmentName;

    this.addDepartment = true;
  }

  approveDepartment() {
    if (!this.departmentEntity.departmentId) return;

    this.isLoading = true;

    this.apiService
      .sendData(
        APPROVE_DEPARTMENT +
        '?departmentId=' +
        this.departmentEntity.departmentId,
        {},
        {
          'X-ACTION-ROLE': 'APPROVE', // ✅ important if backend expects
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Success', 'Department Approved');
            this.getDepartments();
            this.closeFormPopup();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Approve failed');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  rejectDepartment() {
    if (!this.departmentEntity.departmentId) return;

    this.isLoading = true;

    this.apiService
      .sendData(
        REJECT_DEPARTMENT +
        '?departmentId=' +
        this.departmentEntity.departmentId,
        {},
        {
          'X-ACTION-ROLE': 'REJECT', // ✅ important
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Success', 'Department Rejected');
            this.getDepartments();
            this.closeFormPopup();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Reject failed');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getActions(): string[] {
    if (this.loginUserRole === BANKSUPERADMINCHECKER || this.loginUserRole === SUPERADMIN) {
      return ['view', 'audit'];
    }

    if (
      this.loginUserRole === SUPERADMIN ||
      this.loginUserRole === BANKSUPERADMINMAKER
    ) {
      return ['edit', 'audit'];
    }

    return ['audit'];
  }

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }

  auditFnc(row: any) {
    console.log(row);
    this.auditCards = this.createAuditCards(row);
    this.isAuditOpen = true;
  }
  createAuditCards(row: any) {
    const cards: any[] = [];
    if (row.makerName && row.createdAt) {
      cards.push({
        label: 'Maker',
        name: row.makerName,
        datetime: this.formatAuditDate(row.createdAt),
        status: 'completed',
      });
    }
    if (row.editorName && row.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: row.editorName,
        datetime: this.formatAuditDate(row.editedAt),
        status: 'completed',
      });
    }
    if (row.rejectedBy && row.rejectedAt) {
      cards.push({
        label: 'Rejected By',
        name: row.rejectedBy,
        datetime: this.formatAuditDate(row.rejectedAt),
        status: 'completed',
      });
      return cards; // stop here
    }
    if (row.checkerName && row.approvedAt) {
      cards.push({
        label: 'Approved By',
        name: row.checkerName,
        datetime: this.formatAuditDate(row.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  getCategoryList() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.categoryList = res.payload.content.map((item: any) => ({
              categoryId: item.categoryId,
              categoryName: item.categoryName,
            }));
          }
          console.log(this.categoryList);
        },
      });
  }

  // ❌ CLOSE POPUP
  // closeFormPopup() {
  //   this.addDepartment = false;
  //   this.editDepartment = false;
  //   this.editIndex = -1;

  //   this.categoryError = false; // ✅ RESET
  //   this.departmentNameError = false;
  // }

  // 🔔 TOAST METHODS
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };

    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }

  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }
  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'categoryTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getDepartments();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }
  // saveDepartment() {
  //   if (!this.validateDepartment()) return;
  //   const payload = {
  //     id: this.editDepartment ? this.departmentEntity.departmentId : null,
  //     departmentName: this.departmentEntity.departmentName,
  //     categoryId: this.departmentEntity.categoryId, // 🔥 ADD THIS
  //   };
  //   this.isLoading = true;
  //   this.apiService.sendData(ADD_DEPARTMENTS, payload).subscribe({
  //     next: (res: any) => {
  //       if (res.status === 'SUCCESS') {
  //         this.getDepartments(); // 🔥 refresh list
  //         this.showToast(
  //           'success',
  //           'Success',
  //           this.editDepartment
  //             ? 'Department updated successfully'
  //             : 'Department added successfully'
  //         );
  //         this.closeFormPopup();
  //       } else {
  //         this.showToast('error', 'Error', res.description);
  //       }
  //     },
  //     error: () => {
  //       this.showToast('error', 'Error', 'Failed to save department');
  //     },
  //     complete: () => {
  //       this.isLoading = false;
  //     },
  //   });
  // }
  saveDepartment() {
    if (!this.validateDepartment()) return;

    const isEdit = this.editDepartment;

    const payload = {
      id: isEdit ? this.departmentEntity.departmentId : null,

      // OLD NAME (only for edit)
      departmentName: isEdit
        ? this.originalDepartmentName
        : this.departmentEntity.departmentNameLabel,

      // NEW NAME
      departmentNameLabel: this.departmentEntity.departmentNameLabel,
      categoryId: this.departmentEntity.categoryId,

      // FLAG
      isUpdate: isEdit,
    };

    this.isLoading = true;

    this.apiService
      .sendData(ADD_DEPARTMENTS, payload, {
        'X-ACTION-ROLE': isEdit ? 'EDIT' : 'CREATE',
      })
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.getDepartments();

            this.showToast(
              'success',
              'Success',
              isEdit
                ? 'Department updated successfully'
                : 'Department added successfully'
            );

            this.closeFormPopup();
          } else {
            this.showToast(
              'error',
              'Error',
              res.message || res.description || 'Failed to save department'
            );
          }

          this.isLoading = false;
        },

        error: (err) => {
          this.isLoading = false;

          const backendMessage =
            err?.error?.message || 'Failed to save department';

          // ✅ DUPLICATE HANDLING
          if (err?.error?.errorCode === 'DUPLICATE') {
            this.departmentNameError = true;

            this.showToast('error', 'Duplicate Error', backendMessage);
            this.closeFormPopup();
          } else {
            this.showToast('error', 'Error', backendMessage);
            this.closeFormPopup();
          }
        },
      });
  }

  // editDepartmentf(row: Department, index: number) {
  //   this.departmentEntity = { ...row };
  //   this.editIndex = index;
  //   this.addDepartment = true;
  //   this.editDepartment = true;
  // }

  editDepartmentf(row: Department, index: number) {
    this.departmentEntity = {
      ...row,
      departmentNameLabel: row.departmentNameLabel,
    };

    this.originalDepartmentName = row?.departmentName;

    this.editIndex = index;
    this.addDepartment = true;
    this.editDepartment = true;
  }
  getDepartments() {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_ALL_TEMP_DEPARTMENTS +
        '?page=' +
        (this.pageNumber - 1) +
        '&size=' +
        this.pageSize,
        {}
      )
      .subscribe({
        next: (res: any) => {
          if (res?.status === 'SUCCESS' && res?.payload) {
            // ✅ Only map what you need
            this.data = res.payload.content.map((item: any) => ({
              departmentId: item.id,

              // ✅ Correct logic
              departmentName: item.departmentName,

              categoryId: item.categoryId,
              categoryName: item.categoryName,
              status: item.status,

              // ✅ KEEP ORIGINAL SAFE (VERY IMPORTANT FOR EDIT)
              departmentNameLabel: item.departmentNameLabel,

              ...item,
            }));
            this.totalElements = res.payload.page.totalElements;
          } else {
            this.data = [];
            this.showToast('error', 'Error', res?.description || 'No data');
          }
        },
        error: () => {
          this.data = [];
          this.showToast('error', 'Error', 'Failed to fetch departments');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  ngOnInit() {
    this.getDepartments();
    this.getCategoryList();
  }

  getAllData() {
    this.apiService
      .getData(GET_ALL_TEMP_DEPARTMENTS, {})
      .subscribe((res: any) => {
        if (res.status === 'SUCCESS') {
          this.fullData = res.payload.content.map((item: any) => ({
            ...item,
            departmentId: item.id,
            departmentName: item.departmentName,
            departmentNameLabel: item.departmentNameLabel,
            categoryName: item.categoryName,
            status: item.status,
          }));
        }
      });
  }
  applyAllFilters() {
    const searchTerm = this.searchDepartment?.toLowerCase() || '';
    this.data = this.fullData.filter((item: any) => {
      const categoryMatch =
        this.selectedCategory === 'All' ||
        item.categoryName === this.selectedCategory;
      const statusMatch =
        this.selectedStatus === 'All' || item.status === this.selectedStatus;
      const searchMatch =
        !searchTerm ||
        item.departmentNameLabel?.toLowerCase().includes(searchTerm) ||
        item.departmentName?.toLowerCase().includes(searchTerm) ||
        item.categoryName?.toLowerCase().includes(searchTerm);
      return categoryMatch && statusMatch && searchMatch;
    });
    this.totalElements = this.data.length; // ✅ FIX: update count for pagination
  }
  applyGlobalFilter() {
    if (
      this.selectedCategory === 'All' &&
      this.selectedStatus === 'All' &&
      !this.searchDepartment
    ) {
      this.resetToDefault();
      return;
    }
    this.isFilterMode = true;
    if (!this.fullData.length) {
      this.getAllData();
      setTimeout(() => this.applyAllFilters(), 300);
    } else {
      this.applyAllFilters();
    }
  }
  search() {
    this.applyGlobalFilter();
  }
  resetToDefault() {
    this.isFilterMode = false;
    this.selectedCategory = 'All';
    this.selectedStatus = 'All';
    this.fullData = [];
    this.getDepartments();
  }
  closeFormPopup() {
    this.addDepartment = false;
    this.editDepartment = false;
    this.originalDepartmentName = '';
    this.editIndex = -1;
    this.isViewMode = false; // 🔥 IMPORTANT
    this.categoryError = false;
    this.departmentNameError = false;
  }
}
