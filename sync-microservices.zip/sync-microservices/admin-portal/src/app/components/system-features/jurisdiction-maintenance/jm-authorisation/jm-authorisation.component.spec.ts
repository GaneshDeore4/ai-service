import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JmAuthorisationComponent } from './jm-authorisation.component';

describe('JmAuthorisationComponent', () => {
  let component: JmAuthorisationComponent;
  let fixture: ComponentFixture<JmAuthorisationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JmAuthorisationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JmAuthorisationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
