import { Component } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgFor, NgIf, NgStyle } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableComponent } from '../../../../commom/table/table.component';
import { PopupComponent } from '../../../../commom/popup/popup.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { FloatLabelModule } from 'primeng/floatlabel';
import { GET_ALL_MASTER_PRODUCT, GET_ALL_SUBPRO_BY_PRO_LIST } from '../../../../constants/api_endpoints';
import { ApiService } from '../../../../service/apiService/api.service';


export interface SubproductEntity{
  subproductId?:number,
  productName?:string,
  productId?:number,
  categoryId?:number,
  categoryList?:string,
  subproductName?:string
}
interface ProductEntity {
  productId?: number;
  productName?: string;
  categoryId?: number;
  categoryName?: string;
}
@Component({
  selector: 'app-jm-authorisation',
  imports: [
    PageTitleComponent,
    NgIf,
    NgFor,
    FormsModule,
    TableComponent,
    NgClass,
    NgStyle,
    PopupComponent,
    MultiSelectModule,
    FloatLabelModule,
  ],
  templateUrl: './jm-authorisation.component.html',
  styleUrl: './../master-setup.css',
})
export class JmAuthorisationComponent {
  productData: ProductEntity[] = [];
  subProductData: SubproductEntity[] = [];
  searchProductList = [
    'Bankers Guarantee Recieved',
    'Bulk Order',
    'Credit Note',
    'Credit Note CR',
  ];
  searchSubProductList = [
    'BG Recieved - Trade',
    'Bulk Order - Trade',
    'Credit Note - Trade',
    'Credit Note CR - Trade',
  ];
  searchStatusList = [
    'Awaiting Approval(D)',
    'Awaiting Approval(M)',
    'Awaiting Approval(N)',
    'Checker Returned(D)',
    'Checker Returned(M)',
    'Checker Returned(N)',
    'Draft(M)',
    'Draft(N)',
  ];
  selectedProduct: number = 0;
  selectedSubProduct: string = '';
  selectedStatus: string = '';

  // addAuth vars
  authTypeList: string[] = ['Amend', 'Close', 'New', 'Payment'];
  SelectedAuthType: string = '';
  addCurrency = '';
  addAmount = '';
  typeError = false;
  productError = false;
  subProductError = false;
  currencyError = false;
  amountError = false;

  viewAuth: boolean = false;
  editAuth: boolean = false;
  addAuth: boolean = false;

  //table config
  headers: string[] = [
    'Type',
    'Product',
    'Sub Product Type',
    'Product Type',
    'Tenor Type',
    'Authorisation Level(s)',
    'CCY',
    'Amount',
    'Status',
    'Maker User',
    'Action',
  ];
  data: any[] = [
    {
      Type: 'Single',
      Product: 'Bankers Guarantee Recieved',
      'Sub Product Type': 'BG Recieved - Trade',
      'Product Type': 'Trade',
      'Tenor Type': 'Short Term',
      'Authorisation Level(s)': 'Level 1',
      CCY: 'USD',
      Amount: '1000.00',
      Status: 'Awaiting Approval(D)',
      'Maker User': 'john doe',
      Sequential: 'Yes',
    },
  ];
  columnWidths = [
    '5%',
    '10%',
    '10%',
    '10%',
    '10%',
    '10%',
    '5%',
    '10%',
    '10%',
    '10%',
    '10%',
  ];

  authLevelHeaders: string[] = ['Authorisation Level', 'Action'];
  authLevelColumnWidths = ['50%', '50%'];
  authLevelList: string[] = [];
  authLevelDropdown = ['A', 'B', 'C', 'D'];
  selectedAuthLevelDropdown = '';
  authLevelSelectorError = false;
  addAuthLevel = false;
  rowIndex: number = -1;

  constructor(private apiService: ApiService) {}
  addAuthLevelf(rowIndex: number) {
    if (rowIndex > -1) {
      this.rowIndex = rowIndex;
      this.selectedAuthLevelDropdown = this.authLevelList[rowIndex];
    }
    this.addAuthLevel = true;
  }
  saveAuthLevel() {
    if (this.selectedAuthLevelDropdown === '') {
      this.authLevelSelectorError = true;
      return;
    }
    if (this.rowIndex > -1) {
      this.authLevelList.splice(
        this.rowIndex,
        1,
        this.selectedAuthLevelDropdown
      );
    } else {
      this.authLevelList.push(this.selectedAuthLevelDropdown);
    }

    console.log(this.authLevelList);
    this.closeAuthLevelPopup();
  }
  closeAuthLevelPopup() {
    this.selectedAuthLevelDropdown = '';
    this.authLevelSelectorError = false;
    this.addAuthLevel = false;
    this.rowIndex = -1;
  }
  deleteAuthLevelRow(index: number) {
    //reomve item from array
    this.authLevelList.splice(index, 1);
    console.log(this.authLevelList);
  }

  addAuthf() {
    this.getAllProducts();
    this.addAuth = true;
  }
  viewAuthf() {
    this.viewAuth = true;
  }
  closeViewAuthf() {
    this.viewAuth = false;
  }
  editIndex: number = -1;
  editAuthf(row: any, index: number) {
    this.getAllProducts();
    console.log(index);
    this.editIndex = index;
    this.addAuth = true;
    //populate fields
    this.SelectedAuthType = row['Type'];
    this.selectedProduct = row['Product'];
    this.selectedSubProduct = row['Sub Product Type'];
    this.addCurrency = row['CCY'];
    this.addAmount = row['Amount'];
    this.authLevelList = row['Authorisation Level(s)'].split(', ');
  }
  saveAuthf() {
    //validations
    const isValid = this.addAuthValidation();
    if (!isValid) {
      return;
    }
    if (this.editIndex > -1) {
      //edit mode
      const editedData = {
        Type: this.SelectedAuthType,
        Product: this.selectedProduct,
        'Sub Product Type': this.selectedSubProduct,
        'Product Type': 'Trade',
        'Tenor Type': 'Short Term',
        'Authorisation Level(s)': this.authLevelList.join(', '),
        CCY: this.addCurrency,
        Amount: this.addAmount,
        Status: 'Draft(M)',
        'Maker User': 'john doe',
        Sequential: 'Yes',
      };
      console.log(JSON.stringify(this.data, null, 2));
      console.log('rowIndex: ' + this.rowIndex);
      console.log('---------------------------------');
      this.data.splice(this.editIndex, 1, editedData);
      console.log(JSON.stringify(this.data, null, 2));
      this.editIndex = -1;
      this.showPopup('Authorisation added successfully!');
    } else {
      this.showPopup('Authorisation added successfully!');
      this.data.push({
        Type: this.SelectedAuthType,
        Product: this.selectedProduct,
        'Sub Product Type': this.selectedSubProduct,
        'Product Type': 'Trade',
        'Tenor Type': 'Short Term',
        'Authorisation Level(s)': this.authLevelList.join(', '),
        CCY: this.addCurrency,
        Amount: this.addAmount,
        Status: 'Draft(M)',
        'Maker User': 'john doe',
      });
    }
    this.closeAddAuthf();
  }
  onProductBlur() {
    this.getAllSubproByProList();
  }
  getAllSubproByProList() {
    let productIDList: number[]=[]
    productIDList.push(this.selectedProduct)
    this.apiService
      .sendData(GET_ALL_SUBPRO_BY_PRO_LIST, productIDList)
      .subscribe({
        next: (res:any) => {
          //remember to bring the user object to pass to other screen
          // console.log("sub list " + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.subProductData = [];
            this.subProductData = res['payload'];
            // console.log("grouped subPro" + JSON.stringify(this.groupedSubProducts, null, 2));
          }
        },
        error: (err:any) => {},
      });
  }
  deleteAuthf(event: number) {
    console.log('delete row index: ' + event);
    this.data = [...this.data.splice(event, 1)];
  }
  closeAddAuthf() {
    this.addAuth = false;
    this.typeError = false;
    this.productError = false;
    this.subProductError = false;
    this.currencyError = false;
    this.amountError = false;
    this.SelectedAuthType = '';
    this.selectedProduct = 0;
    this.selectedSubProduct = '';
    this.addCurrency = '';
    this.addAmount = '';
  }

  getAllProducts() {
    this.apiService.getData(GET_ALL_MASTER_PRODUCT, null).subscribe({
      next: (res: any) => {
        //remember to bring the user object to pass to other screen
        // console.log("product list " + JSON.stringify(res, null, 2));
        if (res.status == 'SUCCESS') {
          this.productData = res['payload'];
        }
      },
      error: (err: any) => {
        console.log(err);
      },
      complete: () => {
        console.log('Data was fetched');
      },
    });
    // this.productData.push({productId:1,productName:'Remittance'});
  }

  addAuthValidation(): boolean {
    let isValid = true;

    if (this.SelectedAuthType === '') {
      this.typeError = true;
      isValid = false;
    } else {
      this.typeError = false;
    }
    if (this.selectedProduct === 0) {
      this.productError = true;
      isValid = false;
    } else {
      this.productError = false;
    }
    if (this.selectedSubProduct === '') {
      this.subProductError = true;
      isValid = false;
    } else {
      this.subProductError = false;
    }
    if (this.addCurrency === '') {
      this.currencyError = true;
      isValid = false;
    } else {
      this.currencyError = false;
    }
    if (this.addAmount === '') {
      this.amountError = true;
      isValid = false;
    } else {
      this.amountError = false;
    }

    return isValid;
  }

  // POPUP VARAIBLES AND METHODS
  popupVisible: boolean = false;
  popupMsg: string = '';
  showPopup(message: string) {
    this.popupMsg = message;
    this.popupVisible = true;
  }
  hidePopup() {
    this.popupVisible = false;
    this.popupMsg = '';
  }
}
