import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JmRolesComponent } from './jm-roles.component';

describe('JmRolesComponent', () => {
  let component: JmRolesComponent;
  let fixture: ComponentFixture<JmRolesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JmRolesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JmRolesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
