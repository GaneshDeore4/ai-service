import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { NgFor, NgIf } from '@angular/common';
import { TableComponent } from "../../../../commom/table/table.component";
import { FormsModule } from '@angular/forms';
import { PopupComponent } from "../../../../commom/popup/popup.component";

@Component({
  selector: 'app-jm-roles',
  imports: [PageTitleComponent, NgIf, NgFor, TableComponent, FormsModule, PopupComponent],
  templateUrl: './jm-roles.component.html',
  styleUrl: './../master-setup.css'
})
export class JmRolesComponent {

  popupMsg = '';
  popupVisible = false;

  viewRole: boolean = false;
  editRole: boolean = false;
  roleCode = '';
  roleDesc = '';
  roleDestination = '';
  roleType = '';

  statusList: string[] = ['Awaiting Approval', 'Checker Returned','Draft'];
  selectedStatus: string = '';


  // table config
  headers = [
    'Reference',
    'Description',
    'Destination',
    'Status',
    'Maker User',
    'Action'
  ];
  data = [
    {
      'Reference': 'Role-001',
      'Description': 'Administrator Role',
      'Destination': 'System',
      'Status': '',
      'Maker User': ''
    },
  ];
  columnWidths = [
    '25%',
    '25%',
    '10%',
    '15%',
    '15%',
    '10%',

  ];

  hidePopup() {
    this.popupVisible = false;
  }

  editRolef() {
    this.editRole = true;
    this.roleCode = this.data[0]['Reference'];
    this.roleDesc = this.data[0]['Description'];
  }
  viewRolef() {
    this.viewRole = true;
    this.roleCode = this.data[0]['Reference'];
    this.roleDesc = this.data[0]['Description'];
    this.roleDestination = this.data[0]['Destination'];
    this.roleType = 'Authorization Level';
  }

  saveRole() {
    this.data[0]['Reference'] = this.roleCode;
    this.data[0]['Description'] = this.roleDesc;
    this.editRole = false;
    this.popupMsg = 'Role details saved successfully.';
    this.popupVisible = true;
  }
  closeEditRole() {
    this.editRole = false;
    this.viewRole=false;
  }
}
