import { Component } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { ApiService } from '../../../../service/apiService/api.service';
import {
  CREATE_MASTER_PRODUCT,
  DELETE_MASTER_PRODUCT,
  EDIT_MASTER_PRODUCT,
  GET_ALL_CATEGORY,
  GET_ALL_MASTER_PRODUCT,
  GET_ALL_TEMP_MASTER_PRODUCT,
  APPROVE_PRODUCT,
  REJECT_PRODUCT,
} from '../../../../constants/api_endpoints';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { PopupComponent } from '../../../../commom/popup/popup.component';
import {
  BANKSUPERADMINMAKER,
  PAGE_SIZE,
  SUPERADMIN,
  BANKSUPERADMINCHECKER,
} from '../../../../constants/Constants';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  CategoryFilterEntity,
} from '../../../../commom/filter-btn/filter-btn.component';
import { SessionService } from '../../../../service/sessionService/session.service';
import { UserAuditComponent } from '../../../../commom/user-audit/user-audit.component';

export interface ProductEntity {
  productId?: number;
  productName?: string;
  categoryId?: number;
  categoryName?: string;
  productNameLabel?: string;
  status?: string;
}

export interface CategoryMap {
  categoryId?: number;
  categoryName?: string;
}

@Component({
  selector: 'app-product-master',
  imports: [
    NgIf,
    NgFor,
    FormsModule,
    TblComponent,
    NgClass,
    LoaderComponent,
    ToastComponent,
    UserAuditComponent,
  ],

  templateUrl: './product-master.component.html',
  styleUrl: './../master-setup.css',
})
export class ProductMasterComponent {
  constructor(
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.loginUserRole = sessionService.getRole();
  }
  ngOnInit() {
    this.getTableData();
    this.getCategoryList();
  }

  loginUserRole: string = '';

  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'productTable';
  fullData: ProductEntity[] = []; // 🔥 global data
  selectedCategory: string = 'All';
  selectedStatus: string = 'All';
  isFilterMode: boolean = false;

  statuses = ['PENDING APPROVAL', 'APPROVED', 'RETURNED'];

  header: { key: string; value: string }[] = [
    { key: 'categoryName', value: 'Category' },
    { key: 'productNameLabel', value: 'Product Name' },
    { key: 'status', value: 'Status' },
    { key: 'Action', value: 'Action' },
  ];
  categoryList: CategoryMap[] = [];
  productEntity: ProductEntity = {};
  isLoading = false;
  role = '';
  userId = '';
  addEditPopup = false;
  data: ProductEntity[] = [];
  ogData: ProductEntity[] = [];
  popupVisible = false;
  popupText = '';
  searchProduct = '';
  viewProduct = false;
  showProductForm = false;
  editIndex = -1;
  originalProductName: string | undefined = '';

  // error variables
  errorCount = 0;
  productNameError = false;
  productNameErrorMsg = '';

  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  isAuditOpen = false;
  auditCards: any[] = [];
  isViewMode: boolean = false;

  viewProductF(row: ProductEntity) {
    this.isViewMode = true;

    this.productEntity = {
      ...row,
      productNameLabel: row.productNameLabel || row.productName,
    };

    this.originalProductName = row?.productName;
    this.addEditPopup = true;
  }

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }

  auditFnc(row: any) {
    this.auditCards = this.createAuditCards(row);
    this.isAuditOpen = true;
  }
  createAuditCards(row: any) {
    const cards: any[] = [];
    if (row.makerName && row.createdAt) {
      cards.push({
        label: 'Maker',
        name: row.makerName,
        datetime: this.formatAuditDate(row.createdAt),
        status: 'completed',
      });
    }
    if (row.editorName && row.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: row.editorName,
        datetime: this.formatAuditDate(row.editedAt),
        status: 'completed',
      });
    }
    if (row.rejectedBy && row.rejectedAt) {
      cards.push({
        label: 'Rejected By',
        name: row.rejectedBy,
        datetime: this.formatAuditDate(row.rejectedAt),
        status: 'completed',
      });
      return cards; // stop here
    }
    if (row.checkerName && row.approvedAt) {
      cards.push({
        label: 'Approved By',
        name: row.checkerName,
        datetime: this.formatAuditDate(row.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  filterCategory(filterCategory: CategoryFilterEntity) {
    console.log('filterCategory:' + JSON.stringify(filterCategory, null, 2));
    if (filterCategory.categoryName == 'All') {
      this.data = [...this.ogData];
      return;
    }
    this.data = this.ogData.filter(
      (item) =>
        item.categoryName &&
        item.categoryName
          .toLowerCase()
          .includes(filterCategory.categoryName?.toLowerCase() ?? '')
    );
  }
  addBtnAllowed(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER
    )
      return true;
    else return false;
  }
  getActions(): string[] {
    if (this.loginUserRole === BANKSUPERADMINCHECKER) {
      return ['view', 'audit']; // 👈 only view for checker
    }

    if (
      this.loginUserRole === SUPERADMIN ||
      this.loginUserRole === BANKSUPERADMINMAKER
    ) {
      return ['edit', 'audit']; // 👈 makers
    }

    return ['audit']; // fallback
  }
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }

  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  search() {
    this.isFilterMode = true;

    if (!this.fullData.length) {
      this.getAllData();
      setTimeout(() => this.applyAllFilters(), 300);
    } else {
      this.applyAllFilters();
    }
  }

  getTableData() {
    this.isLoading = true;

    this.apiService
      .getData(
        GET_ALL_TEMP_MASTER_PRODUCT +
        '?page=' +
        (this.pageNumber - 1) +
        '&size=' +
        this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.data = res['payload']['content'].map((item: any) => ({
              ...item,
              productNameLabel: item.productNameLabel || item.productName, // 🔥 fallback
            }));
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
            this.ogData = [...this.data];
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getCategoryList() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            console.log('res :' + JSON.stringify(res, null, 2));
            this.categoryList = res.payload.content.map((item: any) => ({
              categoryId: item.categoryId,
              categoryName: item.categoryName,
            }));
            console.log(
              'category list' + JSON.stringify(this.categoryList, null, 2)
            );
          } else {
            console.log('inside get else');
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  addRoleF() {
    this.addEditPopup = true;
  }
  editRoleF(row: any, index: number) {
    this.isViewMode = false;

    this.productEntity = {
      ...row,
      productNameLabel: row.productNameLabel || row.productName,
    };

    this.originalProductName = row.productName;
    this.editIndex = index;
    this.addEditPopup = true;
  }

  closeRoleForm() {
    this.productEntity = {};
    this.originalProductName = ''; // ✅ reset
    this.editIndex = -1;
    this.showProductForm = false;
    this.viewProduct = false;
    this.addEditPopup = false;
    this.clearProductForm();
  }
  saveProduct() {
    if (!this.validateRole()) return;

    this.isLoading = true;

    const req = {
      isUpdate: false,
      productName: this.productEntity.productNameLabel,
      productNameLabel: this.productEntity.productNameLabel,
      categoryId: Number(this.productEntity.categoryId),
    };

    console.log('CREATE PAYLOAD:', req);

    this.apiService
      .sendData(CREATE_MASTER_PRODUCT, req, {
        'X-ACTION-ROLE': 'CREATE',
      })
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              this.editIndex === -1
                ? 'Product Saved Successfully'
                : 'Product Updated Successfully'
            );
            this.getTableData();
            this.closeRoleForm();
          } else {
            this.showToast(
              'error',
              'Error',
              res.message || res.description || 'Something went wrong'
            );
          }
          this.isLoading = false;
        },
        error: (err) => {
          const errorMessage =
            err?.error?.message ||
            err?.error?.description ||
            'Something went wrong';
          this.showToast('error', 'Error', errorMessage);
          this.isLoading = false;
        },
      });

    this.closeRoleForm();
  }

  // saveProduct() {
  //   if (!this.validateRole()) return;
  //   this.isLoading = true;
  //   const req = {
  //     productName: this.productEntity.productName,
  //     categoryId: this.productEntity.categoryId,
  //     productNameLabel: this.productEntity.productNameLabel,
  //   };
  //   console.log('req : ' + JSON.stringify(req, null, 2));
  //   // this.apiService.sendData(CREATE_MASTER_PRODUCT, req)
  //   this.apiService
  //     .sendData(CREATE_MASTER_PRODUCT, req, { 'X-ACTION-ROLE': 'CREATE' })
  //     .subscribe({
  //       next: (res) => {
  //         //remember to bring the user object to pass to other screen
  //         console.log('login res : ' + JSON.stringify(res, null, 2));
  //         if (res.status == 'SUCCESS') {
  //           this.showToast('success', 'Success', 'Product Saved Successfully');
  //           this.getTableData();
  //         } else {
  //           this.showToast('error', 'Error', res.description);
  //         }
  //       },
  //       error: (err) => {
  //         this.showToast('error', 'Error', 'Something went wrong');
  //       },
  //       complete: () => {
  //         this.isLoading = false;
  //       },
  //     });
  //   this.closeRoleForm();
  // }
  deleteRole(row: any, index: number) {
    this.data.splice(index, 1);
    this.data = [...this.data];
  }

  // updateaProduct() {
  //   if (!this.validateRole()) return;
  //   this.isLoading = true;
  //   const req = {
  //     productName: this.productEntity.productName,
  //     categoryId: this.productEntity.categoryId,
  //     productId: this.productEntity.productId,
  //   };
  //   console.log('req : ' + JSON.stringify(req, null, 2));
  //   // this.apiService.sendData(EDIT_MASTER_PRODUCT, req)
  //   this.apiService
  //     .sendData(EDIT_MASTER_PRODUCT, req, { 'X-ACTION-ROLE': 'EDIT' })
  //     .subscribe({
  //       next: (res) => {
  //         //remember to bring the user object to pass to other screen
  //         console.log('login res : ' + JSON.stringify(res, null, 2));
  //         if (res.status == 'SUCCESS') {
  //           this.showToast(
  //             'success',
  //             'Success',
  //             'Product Updated Successfully'
  //           );
  //           this.getTableData();
  //         } else {
  //           this.showToast('error', 'Error', res.description);
  //         }
  //       },
  //       error: (err) => {
  //         this.showToast('error', 'Error', 'Something went wrong');
  //       },
  //       complete: () => {
  //         this.isLoading = false;
  //       },
  //     });
  //   this.closeRoleForm();
  // }
  updateaProduct() {
    if (!this.validateRole()) return;

    this.isLoading = true;

    const req = {
      productId: this.productEntity.productId,
      isUpdate: true,

      // ✅ OLD VALUE
      productName: this.originalProductName, // OLD
      productNameLabel: this.productEntity.productNameLabel, // NEW

      categoryId: Number(this.productEntity.categoryId),
    };

    console.log('EDIT PAYLOAD:', req);

    this.apiService
      .sendData(CREATE_MASTER_PRODUCT, req, {
        'X-ACTION-ROLE': 'EDIT',
      })
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              'Product Updated Successfully'
            );
            this.getTableData();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });

    this.closeRoleForm();
  }

  validateRole(): boolean {
    if (!this.productEntity.productNameLabel) {
      this.errorCount++;
      this.productNameError = true;
      this.productNameErrorMsg = 'Product Name cannot be Empty';
    }
    return this.errorCount == 0 ? true : false;
  }
  clearProductForm() {
    this.errorCount = 0;
    this.productNameError = false;
    this.productNameErrorMsg = '';
    this.productEntity = {};
  }

  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'productTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }
  approveProduct() {
    const url = APPROVE_PRODUCT + `?productId=${this.productEntity.productId}`;

    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': 'APPROVE',
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Approved', 'Product Approved');
            this.getTableData();
            this.closeRoleForm();
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Approval failed');
        },
      });
  }

  rejectProduct() {
    const url = REJECT_PRODUCT + `?productId=${this.productEntity.productId}`;

    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': 'REJECT',
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('error', 'Rejected', 'Product Rejected');
            this.getTableData();
            this.closeRoleForm();
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Rejection failed');
        },
      });
  }

  getAllData() {
    this.isLoading = true;

    this.apiService
      .getData(GET_ALL_TEMP_MASTER_PRODUCT + '?page=0&size=10000', {})
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.fullData = res.payload.content.map((item: any) => ({
              ...item,
              productNameLabel: item.productNameLabel || item.productName,
            }));
          }
        },
        complete: () => (this.isLoading = false),
      });
  }

  applyAllFilters() {
    const searchTerm = this.searchProduct?.toLowerCase() || '';

    this.data = this.fullData.filter((item: any) => {
      const categoryMatch =
        this.selectedCategory === 'All' ||
        item.categoryName === this.selectedCategory;

      const statusMatch =
        this.selectedStatus === 'All' || item.status === this.selectedStatus;

      const searchMatch =
        !searchTerm ||
        item.productNameLabel?.toLowerCase().includes(searchTerm) ||
        item.categoryName?.toLowerCase().includes(searchTerm);

      return categoryMatch && statusMatch && searchMatch;
    });
    this.totalElements = this.data.length;
  }

  applyGlobalFilter() {
    if (
      this.selectedCategory === 'All' &&
      this.selectedStatus === 'All' &&
      !this.searchProduct
    ) {
      this.resetToDefault();
      return;
    }

    this.isFilterMode = true;

    if (!this.fullData.length) {
      this.getAllData();
      setTimeout(() => this.applyAllFilters(), 300);
    } else {
      this.applyAllFilters();
    }
  }

  resetToDefault() {
    this.isFilterMode = false;
    this.selectedCategory = 'All';
    this.selectedStatus = 'All';
    this.fullData = [];

    this.getTableData(); // 🔥 back to API pagination
  }
}
