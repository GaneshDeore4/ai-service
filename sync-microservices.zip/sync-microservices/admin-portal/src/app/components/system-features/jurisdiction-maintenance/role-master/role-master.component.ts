import { error } from 'console';
import {
  AUTHORISE_ROLE,
  CREATE_MASTER_ROLE,
  CREATE_MASTER_TAB,
  CREATE_MASTER_USERTYPE,
  CREATE_ROLE,
  DELETE_MASTER_ROLE,
  GET_ALL_CATEGORY,
  GET_ALL_MASTER_PRODUCT,
  GET_ALL_MASTER_ROLE,
  GET_ALL_MASTER_TAB,
  GET_ALL_SUBPRO_BY_PRO_LIST,
  GET_ALL_TEMP_TAB,
  GET_ALL_TXN_COMPANIES,
  GET_ALL_TXN_ROLE,
  GET_PRODUCTS_CATEGORY_ID,
  GET_SUBPRODUCTS_BY_PRODUCT_ID,
  APPROVE_TAB,
  REJECT_TAB,
} from '../../../../constants/api_endpoints';
import { GTPRoleDto } from '../../../../model/Role';
import { ApiService } from '../../../../service/apiService/api.service';
import { PopupComponent } from '../../../../commom/popup/popup.component';
import { Component, OnInit } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { Category } from '../category-master/category-master.component';
import { ProductEntity } from '../product-master/product-master.component';
import { SubproductEntity } from '../sub-product-master/sub-product-master.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import {
  MatSelectModule,
  MatSelect,
  MatOption,
} from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input'; // optional, but usually needed
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MultiSelectModule } from 'primeng/multiselect';
import { FloatLabelModule } from 'primeng/floatlabel';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  BANKSUPERADMINCHECKER,
  BANKSUPERADMINMAKER,
  PAGE_SIZE,
  SUPERADMIN,
} from '../../../../constants/Constants';
import {
  CategoryFilterEntity,
  FilterBtnComponent,
} from '../../../../commom/filter-btn/filter-btn.component';
import { SessionService } from '../../../../service/sessionService/session.service';
import { UserAuditComponent } from '../../../../commom/user-audit/user-audit.component';
import { SelectModule } from 'primeng/select';

interface permission {
  tabId?: number;
  tabName?: string;
  tabLabel?:string;
  products?: proEntity[];
  productIds?: number[];
  subProductIds?: number[];
  productId?: number;
  subProductId?: number;
  categoryId?: number;
  categoryName?: string;
  productCount?: number;
  subProductCount?: number;
  productLabel?: string; // 👈 add this
  subProductLabel?: string; // 👈 add this
  status?: string; // 👈 for table
  makerName?: string;
  createdAt?: string;

  checkerName?: string;
  approvedAt?: string;

  editorName?: string;
  editedAt?: string;

  rejectedBy?: string;
  rejectedAt?: string;
}

interface proEntity {
  productName?: string;
  productId?: number;
  subProducts?: subproEntity[];
}
interface subproEntity {
  subProductId?: number;
  subProductName?: string;
}

@Component({
  selector: 'app-role-master',
  imports: [
    NgIf,
    FormsModule,
    TblComponent,
    NgClass,
    LoaderComponent,
    NgFor,
    MatFormFieldModule,
    MultiSelectModule,
    FloatLabelModule,
    ToastComponent,
    FilterBtnComponent,
    UserAuditComponent,
    SelectModule,
  ],
  templateUrl: './role-master.component.html',
  styleUrl: './../master-setup.css',
})
export class RoleMasterComponent implements OnInit {
  constructor(
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.loginUserRole = sessionService.getRole();
  }
  ngOnInit() {
    this.getTableData();
  }

  loginUserRole: string = '';
  pageHeader: string = 'Sub-Features';

  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'permissionTable';

  header: { key: string; value: string }[] = [
    { key: 'categoryName', value: 'Category ' },
    { key: 'productLabel', value: 'Product Name' },
    { key: 'subProductLabel', value: 'Sub-Product Name' },
    { key: 'tabLabel', value: 'Permission' },
    { key: 'status', value: 'Status' },
    // { key: 'productCount', value: 'Products' },
    // { key: 'subProductCount', value: 'SubProducts' },
    { key: 'Action', value: 'Action' },
  ];
  originalTabName: string = '';
  roleEntity: permission = { productIds: [], products: [] };
  isLoading = false;
  role = '';
  userId = '';
  data: permission[] = [];
  ogData: permission[] = [];
  categoryData: Category[] = [];
  selectedCategoryName: String = '';
  productData: ProductEntity[] = [];
  selectedProductList: number[] = [];
  subProductData: SubproductEntity[] = [];
  selectedSubProducts: number[] = [];
  editIndex = -1;
  groupedSubProducts: any[] = [];
  popupVisible = false;
  popupText = '';
  searchRole = '';
  viewRole = false;
  showRoleForm = false;

  // error variables
  errorCount = 0;
  roleNameError = false;
  roleNameErrorMsg = '';
  productError = false;
  productErrorMsg = '';
  subProductError = false;
  subProductErrorMsg = '';
  categoryError = false;
  categoryErrorMsg = '';
  isAuditOpen = false;
  auditCards: any[] = [];
  mode: 'add' | 'edit' | 'view' = 'add';
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };

  filterCategory(filterCategory: CategoryFilterEntity) {
    console.log('filterCategory:' + JSON.stringify(filterCategory, null, 2));
    if (filterCategory.categoryName == 'All') {
      this.data = [...this.ogData];
      return;
    }
    this.data = this.ogData.filter(
      (item) =>
        item.categoryName &&
        item.categoryName
          .toLowerCase()
          .includes(filterCategory.categoryName?.toLowerCase() ?? '')
    );
  }
  addBtnAllowed(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER
    )
      return true;
    else return false;
  }
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }
  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  search() {
    if (!this.searchRole || this.searchRole.trim() === '') {
      this.data = [...this.ogData];
      return;
    }
    const searchTerm = this.searchRole.toLowerCase();
    this.data = this.ogData.filter(
      (item) =>
        (item.tabName && item.tabName.toLowerCase().includes(searchTerm)) ||
        (item.categoryName &&
          item.categoryName.toLowerCase().includes(searchTerm))
    );
  }
  onCategoryBlur() {
    this.getAllProducts();
  }
  getAllCategories() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log("category list " + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.categoryData = res['payload']['content'];
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {},
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  onProductBlur() {
    this.getAllSubproByProList();
  }

  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }

  auditFnc(row: any) {
    console.log(row);
    this.auditCards = this.createAuditCards(row);
    this.isAuditOpen = true;
  }
  createAuditCards(row: any) {
    const cards: any[] = [];
    if (row.makerName && row.createdAt) {
      cards.push({
        label: 'Maker',
        name: row.makerName,
        datetime: this.formatAuditDate(row.createdAt),
        status: 'completed',
      });
    }
    if (row.editorName && row.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: row.editorName,
        datetime: this.formatAuditDate(row.editedAt),
        status: 'completed',
      });
    }
    if (row.rejectedBy && row.rejectedAt) {
      cards.push({
        label: 'Rejected By',
        name: row.rejectedBy,
        datetime: this.formatAuditDate(row.rejectedAt),
        status: 'completed',
      });
      return cards; // stop here
    }
    if (row.checkerName && row.approvedAt) {
      cards.push({
        label: 'Approved By',
        name: row.checkerName,
        datetime: this.formatAuditDate(row.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  getActions(): string[] {
    if (this.loginUserRole === BANKSUPERADMINCHECKER) {
      return ['view', 'audit']; // 👈 only view for checker
    }

    if (
      this.loginUserRole === SUPERADMIN ||
      this.loginUserRole === BANKSUPERADMINMAKER
    ) {
      return ['edit', 'audit']; // 👈 makers
    }

    return ['audit']; // fallback
  }
  getAllProducts() {
    this.apiService
      .getData(
        GET_PRODUCTS_CATEGORY_ID +
          '?categoryId=' +
          this.roleEntity.categoryId +
          '&page=0&size=1000',
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.productData = res['payload'];
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          console.log(err);
        },
        complete: () => {
          this.isLoading = false;
        },
      });
    // this.productData.push({productId:1,productName:'Remittance'});
  }
  getAllSubproByProList() {
    console.log('productId list: ' + this.roleEntity.productIds);
    this.apiService
      .sendData(GET_ALL_SUBPRO_BY_PRO_LIST, this.roleEntity.productIds)
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log("sub list " + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.subProductData = [];
            this.subProductData = res['payload'];
            // console.log(JSON.stringify(this.subProductData, null, 2));
            this.mapGroupedSubProducts(this.subProductData);
            // console.log("grouped subPro" + JSON.stringify(this.groupedSubProducts, null, 2));
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {},
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  onProductChange() {
    this.roleEntity.subProductId = undefined;

    if (!this.roleEntity.productId) return;

    this.apiService
      .getData(
        GET_SUBPRODUCTS_BY_PRODUCT_ID +
          '?productId=' +
          this.roleEntity.productId +
          '&page=0&size=1000',
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.subProductData = res.payload;

            // ✅ IMPORTANT: re-assign AFTER options load
            if (this.editIndex !== -1) {
              this.roleEntity.subProductId = this.roleEntity.subProductIds?.[0];
            }
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Failed to load sub-products');
        },
      });
  }

  mapGroupedSubProducts(incoming: any[]) {
    this.groupedSubProducts = [];
    if (!Array.isArray(incoming)) return;
    this.groupedSubProducts = incoming.map((p: any) => ({
      label: p.productNameLabel,
      value: p.productId,
      items: (p.subProductMasterDtoList || []).map((s: any) => ({
        label: s.subProductLabel,
        value: s.subProductId,
      })),
    }));
    this.groupedSubProducts = [...this.groupedSubProducts];
  }

  mapApiToPermissions(api: any): permission[] {
    if (!api || !Array.isArray(api.payload.content)) return [];
    return api.payload.content.map((item: any) => {
      let categoryId: number | undefined;
      let categoryName: string | undefined;
      if (item.categoryMap) {
        const entry = Object.entries(item.categoryMap)[0];
        if (entry) {
          categoryId = Number(entry[0]);
          categoryName = String(entry[1]);
        }
      }
      return {
        tabId: item.tabId,
        tabName: item.tabName,
        categoryId,
        categoryName,
        // ✅ IMPORTANT
        productId: item.productId,
        subProductId: item.subProductId,
        productIds: [item.productId],
        subProductIds: [item.subProductId],
        // 👇 THESE ARE FOR TABLE
        productLabel: item.productLabel,
        subProductLabel: item.subProductLabel,
        tabLabel: item.tabLabel,
        status: item.status, // optional if not coming from API
        makerName: item.makerName,
        createdAt: item.createdAt,

        checkerName: item.checkerName,
        approvedAt: item.approvedAt,

        editorName: item.editorName,
        editedAt: item.editedAt,

        rejectedBy: item.rejectedBy,
        rejectedAt: item.rejectedAt,
      };
    });
  }

  getTableData() {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_ALL_TEMP_TAB +
          '?page=' +
          (this.pageNumber - 1) +
          '&size=' +
          this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          // console.log("login res : " + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            console.log('getTable res:' + JSON.stringify(res, null, 2));
            this.data = this.mapApiToPermissions(res);
            this.ogData = [...this.data];
            console.log('getTable data:' + JSON.stringify(this.data, null, 2));
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  onProductsChange(ids: number[]) {}
  addRoleF() {
    this.mode = 'add';
    this.getAllCategories();
    this.showRoleForm = true;
  }
  viewRoleF(row: any, index: number) {
    this.mode = 'view';

    this.roleEntity = {
      ...row,
      productId: row.productIds?.[0],
      subProductId: row.subProductIds?.[0],
      tabName: row.tabLabel,
      status: row.status,
    };

    this.showRoleForm = true;

    this.getAllCategories();
    this.getAllProducts();

    if (this.roleEntity.productId) {
      this.onProductChange();
    }
  }
  // editRoleF(row: permission, index: number) {
  //   this.roleEntity = { ...row };
  //   this.originalTabName = row.tabName || '';
  //   console.log('roleEntity:' + JSON.stringify(this.roleEntity, null, 2));
  //   if (this.roleEntity.productId) {
  //     this.onProductChange();
  //   }
  //   this.getAllCategories();
  //   this.getAllProducts();
  //   this.getAllSubproByProList();
  //   this.showRoleForm = true;
  //   this.editIndex = index;
  // }
  editRoleF(row: permission, index: number) {
    this.mode = 'edit';
    this.editIndex = index;
    this.originalTabName = row.tabName || '';

    this.roleEntity = {
      ...row,
      productId: row.productIds?.[0],
      tabName: row.tabLabel
    };

    this.showRoleForm = true;

    this.getAllCategories();
    this.getAllProducts();

    if (this.roleEntity.productId) {
      this.onProductChange();
    }
  }

  closeRoleForm() {
    this.showRoleForm = false;
    this.viewRole = false;
    this.clearRoleForm();
  }
  deleteRole(row: any, index: number) {
    this.data.splice(index, 1);
    this.data = [...this.data];
  }
  saveRole() {
    if (!this.validateTab()) return;
    const isEdit = this.editIndex !== -1;
    // ✅ Get selected product object
    const selectedProduct = this.productData.find(
      (p) => p.productId === this.roleEntity.productId
    );
    const payload = {
      tabId: isEdit ? this.roleEntity.tabId : null,
      // ✅ IMPORTANT LOGIC
      tabName: isEdit
        ? this.originalTabName // 🔥 old name
        : this.roleEntity.tabName,
      tabLabel: this.roleEntity.tabName, // 🔥 new name
      categoryId: this.roleEntity.categoryId,
      productId: this.roleEntity.productId,
      subProductId: this.roleEntity.subProductId || null,
      isUpdate: isEdit,
    };
    const actionRole = isEdit ? 'EDIT' : 'CREATE';
    this.isLoading = true;
    console.log(payload);
    this.isLoading = false;

    this.apiService
      .sendData(CREATE_MASTER_TAB, payload, {
        'X-ACTION-ROLE': actionRole,
      })
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              isEdit ? 'Updated Successfully' : 'Saved Successfully'
            );
            this.getTableData();
            this.closeRoleForm();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          const msg = err?.error?.description || err?.error?.message || '';

          if (
            msg.toLowerCase().includes('already exists') ||
            msg.toLowerCase().includes('duplicate')
          ) {
            this.showToast('error', 'Duplicate', 'Permission already exists');
          } else {
            this.showToast('error', 'Error', 'Something went wrong');
          }
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  validateTab(): boolean {
    this.errorCount = 0;
    this.roleNameError = false;
    this.roleNameErrorMsg = '';
    this.productError = false;
    this.productErrorMsg = '';
    this.subProductError = false;
    this.subProductErrorMsg = '';
    this.categoryError = false;
    this.categoryErrorMsg = '';
    if (!this.roleEntity.tabName) {
      this.errorCount++;
      this.roleNameError = true;
      this.roleNameErrorMsg = 'Role Name cannot be Empty';
    }
    if (!this.roleEntity.productId) {
      this.errorCount++;
      this.productError = true;
      this.productErrorMsg = 'Product cannot be Empty';
    }
    if (!this.roleEntity.categoryId) {
      this.errorCount++;
      this.categoryError = true;
      this.categoryErrorMsg = 'Category cannot be Empty';
    }
    return this.errorCount == 0 ? true : false;
  }
  clearRoleForm() {
    this.errorCount = 0;
    this.roleNameError = false;
    this.roleNameErrorMsg = '';
    this.productError = false;
    this.productErrorMsg = '';
    this.subProductError = false;
    this.subProductErrorMsg = '';
    this.categoryError = false;
    this.categoryErrorMsg = '';
    this.roleEntity = { productIds: [], products: [] };
    this.editIndex = -1;
    this.categoryData = [];
    this.productData = [];
    this.subProductData = [];
    this.groupedSubProducts = [];
  }

  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'permissionTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }

  approve() {
    if (!this.roleEntity.tabId) return;
    this.isLoading = true;
    this.apiService
      .sendData(
        APPROVE_TAB + `?tabId=${this.roleEntity.tabId}`,
        {},
        { 'X-ACTION-ROLE': 'APPROVE' } // ✅ HEADER ADDED
      )
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Approved', 'Permission approved');
            this.getTableData();
            this.closeRoleForm();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Approval failed');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  reject() {
    if (!this.roleEntity.tabId) return;
    this.isLoading = true;
    this.apiService
      .sendData(
        REJECT_TAB + `?tabId=${this.roleEntity.tabId}`,
        {},
        { 'X-ACTION-ROLE': 'REJECT' } // ✅ HEADER ADDED
      )
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Rejected', 'Permission rejected');
            this.getTableData();
            this.closeRoleForm();
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Rejection failed');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
}
