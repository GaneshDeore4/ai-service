import { map } from 'rxjs';
import {
  CREATE_MASTER_SUBPRODUCT,
  EDIT_MASTER_SUBPRODUCT,
  DELETE_MASTER_SUBPRODUCT,
  GET_ALL_CATEGORY,
  GET_ALL_MASTER_PRODUCT,
  GET_ALL_MASTER_SUBPRODUCT,
  GET_PRODUCTS_BY_CATEGORY_ID,
  GET_SUBPRODUCTS_BY_PRODUCT_ID,
  GET_SUBPRODUCT_BY_ID,
  GET_ALL_TEMP_SUBPRODUCT,
  REJECT_SUBPRODUCT,
  APPROVE_SUBPRODUCT,
} from './../../../../constants/api_endpoints';
import { Component } from '@angular/core';
import { ApiService } from '../../../../service/apiService/api.service';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { NgClass, NgIf, NgFor } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PopupComponent } from '../../../../commom/popup/popup.component';
import { CategoryMap } from '../user-master/user-master.component';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  BANKSUPERADMINCHECKER,
  BANKSUPERADMINMAKER,
  PAGE_SIZE,
  SUPERADMIN,
} from '../../../../constants/Constants';
import {
  CategoryFilterEntity,
} from '../../../../commom/filter-btn/filter-btn.component';
import { SessionService } from '../../../../service/sessionService/session.service';
import { UserAuditComponent } from '../../../../commom/user-audit/user-audit.component';

export interface SubproductEntity {
  subproductId?: number;
  productName?: string;
  productId?: number;
  categoryId?: number;
  categoryList?: string;
  subproductName?: string;
  status?: string;
  subProductLabel?: string;
  productNameLabel?: string
}
export interface ProductEntity {
  productId?: number;
  productName?: string;
  productNameLabel?: string;
}
export interface SubProductRow {
  productName?: string;
  subProductName?: string;
}

@Component({
  selector: 'app-sub-product-master',
  imports: [
    TblComponent,
    LoaderComponent,
    NgIf,
    FormsModule,
    NgClass,
    NgFor,
    ToastComponent,
    UserAuditComponent,
  ],
  templateUrl: './sub-product-master.component.html',
  styleUrl: './../master-setup.css',
})
export class SubProductMasterComponent {
  constructor(
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.loginUserRole = sessionService.getRole();
  }
  ngOnInit() {
    this.getTableData();
    this.getCategoryList();
    // this.getProductList();
  }

  loginUserRole = '';

  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'subproductTable';
  fullData: SubproductEntity[] = [];

  selectedCategory: string = 'All';
  selectedProduct: string = 'All';
  selectedStatus: string = 'All';

  isFilterMode: boolean = false;

  statuses = ['PENDING APPROVAL', 'APPROVED', 'RETURNED'];
  header: { key: string; value: string }[] = [
    { key: 'categoryName', value: 'Category' },
    { key: 'productNameLabel', value: 'Product Name' },
    { key: 'subProductLabel', value: 'Sub-Product Name' },
    { key: 'status', value: 'Status' },
    { key: 'Action', value: 'Action' },
  ];

  subproductEntity: SubproductEntity = {};
  isLoading = false;
  role = '';
  userId = '';
  // data: SubproductEntity[] = [
  // ];
  category = 'Bank';
  data: SubproductEntity[] = [];
  ogData: SubproductEntity[] = [];
  subProductRows = [];
  productData: ProductEntity[] = [];
  categoryList: CategoryMap[] = [];
  popupVisible = false;
  popupText = '';
  searchProduct = '';
  viewProduct = false;
  showProductForm = false;
  editIndex = -1;
  productList: ProductEntity[] = [];

  // error variables
  errorCount = 0;
  categoryError = false;
  categoryErrorMsg = '';
  productNameError = false;
  productNameErrorMsg = '';
  subproductNameError = false;
  subproductNameErrorMsg = '';
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  isViewMode: boolean = false;
  isAuditOpen = false;
  auditCards: any[] = [];
  originalSubProductName: string | undefined = '';
  openAudit() {
    this.isAuditOpen = true;
  }

  closeAudit() {
    this.isAuditOpen = false;
  }

  auditFnc(row: any) {
    this.auditCards = this.createAuditCards(row);
    this.isAuditOpen = true;
  }
  createAuditCards(row: any) {
    const cards: any[] = [];
    if (row.makerName && row.createdAt) {
      cards.push({
        label: 'Maker',
        name: row.makerName,
        datetime: this.formatAuditDate(row.createdAt),
        status: 'completed',
      });
    }
    if (row.editorName && row.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: row.editorName,
        datetime: this.formatAuditDate(row.editedAt),
        status: 'completed',
      });
    }
    if (row.rejectedBy && row.rejectedAt) {
      cards.push({
        label: 'Rejected By',
        name: row.rejectedBy,
        datetime: this.formatAuditDate(row.rejectedAt),
        status: 'completed',
      });
      return cards; // stop here
    }
    if (row.checkerName && row.approvedAt) {
      cards.push({
        label: 'Approved By',
        name: row.checkerName,
        datetime: this.formatAuditDate(row.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(date: string): string {
    return new Date(date).toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  viewSubProduct(row: SubproductEntity) {
    this.isViewMode = true;

    this.subproductEntity = {
      ...row,
      subProductLabel: row.subProductLabel || row.subproductName,
    };

    this.originalSubProductName = row.subproductName;
    this.showProductForm = true;
  }

  getActions(): string[] {
    if (this.loginUserRole === BANKSUPERADMINCHECKER) {
      return ['view', 'audit']; // checker
    }

    if (
      this.loginUserRole === SUPERADMIN ||
      this.loginUserRole === BANKSUPERADMINMAKER
    ) {
      return ['edit', 'audit']; // maker
    }

    return ['audit'];
  }

  filterCategory(filterCategory: CategoryFilterEntity) {
    console.log('filterCategory:' + JSON.stringify(filterCategory, null, 2));
    if (filterCategory.categoryName == 'All') {
      this.data = [...this.ogData];
      return;
    }
    this.data = this.ogData.filter(
      (item) =>
        item.categoryList &&
        item.categoryList
          .toLowerCase()
          .includes(filterCategory.categoryName?.toLowerCase() ?? '')
    );
  }
  addBtnAllowed(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER
    )
      return true;
    else return false;
  }

  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }

  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  // search() {
  //   if (!this.searchProduct || this.searchProduct.trim() === '') {
  //     this.data = [...this.ogData];
  //     return;
  //   }
  //   const searchTerm = this.searchProduct.toLowerCase();
  //   this.data = this.ogData.filter(
  //     (item) =>
  //       (item.productName &&
  //         item.productName.toLowerCase().includes(searchTerm)) ||
  //       (item.subproductName &&
  //         item.subproductName.toLowerCase().includes(searchTerm)) ||
  //       (item.categoryList &&
  //         item.categoryList.toLowerCase().includes(searchTerm))
  //   );
  // }
  getCategoryList() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            console.log('res :' + JSON.stringify(res, null, 2));
            this.categoryList = res.payload.content.map((item: any) => ({
              categoryId: item.categoryId,
              categoryName: item.categoryName,
            }));
            console.log(
              'category list' + JSON.stringify(this.categoryList, null, 2)
            );
          } else {
            console.log('inside get else');
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  onCategoryBlur() {
    this.subproductEntity.productId = undefined;
    this.getProductList();
  }
  getProductList() {
    this.apiService
      .getData(
        GET_PRODUCTS_BY_CATEGORY_ID +
        '?categoryId=' +
        this.subproductEntity.categoryId +
        '&page=0&size=1000',
        {}
      )
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          console.log('login res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.productData = res.payload;
            console.log('getProductList :', this.productData);
          } else {
            this.showToast('error', 'Error', res.description);
          }
          console.log('data res : ' + this.productData);
        },
        error: (err) => {
          this.showToast('error', 'Error', 'something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  getTableData() {
    this.isLoading = true;
    this.apiService
      .getData(
        GET_ALL_TEMP_SUBPRODUCT +
        '?page=' +
        (this.pageNumber - 1) +
        '&size=' +
        this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          //remember to bring the user object to pass to other screen
          console.log('subproduct res : ' + JSON.stringify(res, null, 2));
          if (res.status == 'SUCCESS') {
            this.data = res.payload.content.map((item: any) => ({
              ...item,
              categoryName: item.categoryName,
              subproductId: item.subProductId,

              subproductName: item.subProductName, // original

              // 🔥 ALWAYS USE LABEL
              subProductLabel: item.subProductLabel || item.subProductName,

              categoryId: item.categoryId,
              categoryList: item.categoryName,
              productId: item.productId,
              productName: item.productName,
              productNameLabel: item.productLabel,
              status: item.status,
            }));
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
            this.ogData = [...this.data];
            console.log('subProductList :', this.data);
          } else {
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  addRoleF() {
    this.clearProductForm(); // 🔥 add this
    this.showProductForm = true; // or addEditPopup for product
  }
  editRoleF(row: any, index: number) {
    this.isViewMode = false;

    this.subproductEntity = {
      ...row,
      subProductLabel: row.subProductLabel || row.subproductName,
    };

    this.originalSubProductName = row.subproductName;
    this.editIndex = index;

    this.getProductListAndOpen();
  }
  getProductListAndOpen() {
    this.apiService
      .getData(
        GET_PRODUCTS_BY_CATEGORY_ID +
        '?categoryId=' +
        this.subproductEntity.categoryId +
        '&page=0&size=1000',
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.productData = res.payload;

            // 🔥 NOW open popup AFTER data is ready
            this.showProductForm = true;
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Failed to load products');
        },
      });
  }
  // closeRoleForm() {
  //   this.showProductForm = false;
  //   this.viewProduct = false;
  //   this.clearProductForm();
  // }
  closeRoleForm() {
    this.showProductForm = false;
    this.viewProduct = false;
    this.isViewMode = false;

    this.originalSubProductName = ''; // ✅ reset

    this.clearProductForm();
  }

  deleteRole(row: SubproductEntity, index: number) {
    this.data.splice(index, 1);
    this.data = [...this.data];
  }
  // saveRole() {
  //   if (!this.validateRole()) return;
  //   this.isLoading = true;
  //   let data = {};
  //   if (this.editIndex == -1) {
  //     data = {
  //       productId: this.subproductEntity.productId,
  //       categoryId: this.subproductEntity.categoryId,
  //       subProductName: this.subproductEntity.subproductName,
  //     };
  //   } else {
  //     data = {
  //       productId: this.subproductEntity.productId,
  //       categoryId: this.subproductEntity.categoryId,
  //       subProductName: this.subproductEntity.subproductName,
  //       subProductId: this.subproductEntity.subproductId,
  //     };
  //   }

  //   console.log('sub prod send: ' + JSON.stringify(data, null, 2));
  //   // this.apiService
  //   //   .sendData(
  //   //     this.editIndex == -1
  //   //       ? CREATE_MASTER_SUBPRODUCT
  //   //       : EDIT_MASTER_SUBPRODUCT,
  //   //     data
  //   //   )
  //   const actionRole = this.editIndex == -1 ? 'CREATE' : 'EDIT';

  //   this.apiService
  //     .sendData(
  //       this.editIndex == -1
  //         ? CREATE_MASTER_SUBPRODUCT
  //         : EDIT_MASTER_SUBPRODUCT,
  //       data,
  //       {
  //         'X-ACTION-ROLE': actionRole,
  //       }
  //     )
  //     .subscribe({
  //       next: (res) => {
  //         //remember to bring the user object to pass to other screen
  //         console.log('login res : ' + JSON.stringify(res, null, 2));
  //         if (res.status == 'SUCCESS') {
  //           this.showToast(
  //             'success',
  //             'Success',
  //             this.editIndex == -1
  //               ? 'Sub-Product Saved Successfully'
  //               : 'Sub-Product Updated Successfully'
  //           );
  //           this.getTableData();
  //         } else {
  //           this.showToast('error', 'Error', res.description);
  //         }
  //       },
  //       error: (err) => {
  //         this.showToast('error', 'Error', 'Something went wrong');
  //       },
  //       complete: () => {
  //         this.isLoading = false;
  //       },
  //     });

  //   this.closeRoleForm();
  // }
  saveRole() {
    if (!this.validateRole()) return;

    this.isLoading = true;

    const isEdit = this.editIndex !== -1;

    const payload = {
      subProductId: isEdit ? this.subproductEntity.subproductId : null,
      isUpdate: isEdit,

      categoryId: this.subproductEntity.categoryId,
      productId: this.subproductEntity.productId,

      // 🔥 MAIN FIX
      subProductName: isEdit
        ? this.originalSubProductName // KEEP OLD
        : this.subproductEntity.subProductLabel, // CREATE

      subProductLabel: this.subproductEntity.subProductLabel,
    };

    const actionRole = isEdit ? 'EDIT' : 'CREATE';

    this.apiService
      .sendData(CREATE_MASTER_SUBPRODUCT, payload, {
        'X-ACTION-ROLE': actionRole,
      })
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              isEdit
                ? 'Sub-Product Updated Successfully'
                : 'Sub-Product Saved Successfully'
            );
            this.getTableData();
            this.closeRoleForm();
          } else {
            // 🔥 HANDLE DUPLICATE OR OTHER BACKEND MESSAGE
            this.showToast(
              'error',
              'Error',
              res.message || res.description || 'Something went wrong'
            );
          }
          this.isLoading = false; // ✅ IMPORTANT
        },
        error: (err) => {
          console.log('API ERROR:', err);
          // 🔥 EXTRACT DUPLICATE MESSAGE SAFELY
          const errorMessage =
            err?.error?.message ||
            err?.error?.description ||
            'Something went wrong';
          this.showToast('error', 'Error', errorMessage);
          this.isLoading = false; // ✅ IMPORTANT
        },
      });

    this.closeRoleForm();
  }

  validateRole(): boolean {
    this.errorCount = 0;

    this.categoryError = false;
    this.productNameError = false;
    this.subproductNameError = false;

    if (!this.subproductEntity.categoryId) {
      this.errorCount++;
      this.categoryError = true;
    }

    if (!this.subproductEntity.productId) {
      this.errorCount++;
      this.productNameError = true;
    }

    // ✅ FIX HERE
    if (
      !this.subproductEntity.subProductLabel ||
      this.subproductEntity.subProductLabel.trim() === ''
    ) {
      this.errorCount++;
      this.subproductNameError = true;
    }

    return this.errorCount === 0;
  }
  clearProductForm() {
    this.errorCount = 0;
    this.categoryError = false;
    this.categoryErrorMsg = '';
    this.productNameError = false;
    this.productNameErrorMsg = '';
    this.subproductNameError = false;
    this.subproductNameErrorMsg = '';
    this.subproductEntity = {};
    this.editIndex = -1;
  }

  hidePopup() {
    this.popupVisible = false;
    this.popupText = '';
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'subproductTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }
  approveSubProduct() {
    const url =
      APPROVE_SUBPRODUCT + `?subProdId=${this.subproductEntity.subproductId}`;

    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': 'APPROVE',
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Approved', 'Sub-Product Approved');
            this.getTableData();
            this.closeRoleForm();
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Approval failed');
        },
      });
  }

  rejectSubProduct() {
    const url =
      REJECT_SUBPRODUCT + `?subProdId=${this.subproductEntity.subproductId}`;

    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': 'REJECT',
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('error', 'Rejected', 'Sub-Product Rejected');
            this.getTableData();
            this.closeRoleForm();
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Rejection failed');
        },
      });
  }

  onCategoryChange() {
    this.selectedProduct = 'All';
    const selected = this.categoryList.find(
      (c) => c.categoryName === this.selectedCategory
    );
    if (selected?.categoryId) {
      this.apiService
        .getData(
          GET_PRODUCTS_BY_CATEGORY_ID +
          `?categoryId=${selected.categoryId}&page=0&size=1000`,
          {}
        )
        .subscribe((res: any) => {
          if (res.status === 'SUCCESS') {
            this.productData = res.payload;
          }
        });
    }
    this.applyGlobalFilter();
  }
  getAllData() {
    this.isLoading = true;
    this.apiService
      .getData(GET_ALL_TEMP_SUBPRODUCT + '?page=0&size=10000', {})
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.fullData = res.payload.content.map((item: any) => ({
              ...item,
              subProductLabel: item.subProductLabel || item.subProductName,
              productNameLabel: item.productLabel,
              categoryName: item.categoryName,
            }));
          }
        },
        complete: () => (this.isLoading = false),
      });
  }
  applyAllFilters() {
    const searchTerm = this.searchProduct?.toLowerCase() || '';
    this.data = this.fullData.filter((item: any) => {
      const categoryMatch =
        this.selectedCategory === 'All' ||
        item.categoryName === this.selectedCategory;
      const productMatch =
        this.selectedProduct === 'All' ||
        item.productName === this.selectedProduct;
      const statusMatch =
        this.selectedStatus === 'All' || item.status === this.selectedStatus;
      const searchMatch =
        !searchTerm ||
        item.subProductLabel?.toLowerCase().includes(searchTerm) ||
        item.productName?.toLowerCase().includes(searchTerm) ||
        item.categoryName?.toLowerCase().includes(searchTerm);
      return categoryMatch && productMatch && statusMatch && searchMatch;
    });
    this.totalElements = this.data.length;
  }
  applyGlobalFilter() {
    if (
      this.selectedCategory === 'All' &&
      this.selectedProduct === 'All' &&
      this.selectedStatus === 'All' &&
      !this.searchProduct
    ) {
      this.resetToDefault();
      return;
    }
    this.isFilterMode = true;
    if (!this.fullData.length) {
      this.getAllData();
      setTimeout(() => this.applyAllFilters(), 300);
    } else {
      this.applyAllFilters();
    }
  }
  search() {
    this.isFilterMode = true;
    if (!this.fullData.length) {
      this.getAllData();
      setTimeout(() => this.applyAllFilters(), 300);
    } else {
      this.applyAllFilters();
    }
  }
  resetToDefault() {
    this.isFilterMode = false;
    this.selectedCategory = 'All';
    this.selectedProduct = 'All';
    this.selectedStatus = 'All';
    this.fullData = [];
    this.getTableData();
  }
}
