import { Component, ViewChild } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { ApiService } from '../../../../service/apiService/api.service';

import {
  CREATE_MASTER_USERTYPE,
  EDIT_MASTER_USERTYPE,
  GET_ALL_CATEGORY,
  GET_ALL_USERTYPE,
  GET_USERTYPE_BY_ID,
  CREATE_All_TEMP_USERTYPE,
  APPROVE_USER_TYPE,
  REJECT_USER_TYPE,
} from '../../../../constants/api_endpoints';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import {
  BANKSETUPMAKER,
  BANKSUPERADMINMAKER,
  PAGE_SIZE,
  SUPERADMIN,
  BANKSUPERADMINCHECKER,
} from '../../../../constants/Constants';
import {
  CategoryFilterEntity,
} from '../../../../commom/filter-btn/filter-btn.component';
import { SessionService } from '../../../../service/sessionService/session.service';
import { UserAuditComponent } from '../../../../commom/user-audit/user-audit.component';

export interface User {
  userTypeId?: number;
  userTypeName?: string;
  userTypeNameLabel?: string; // ✅ ADD THIS
  categoryId?: number;
  categoryName?: string;
  status?: string;
}

export interface CategoryMap {
  categoryId?: number;
  categoryName?: string;
}

@Component({
  selector: 'app-user-master',
  imports: [
    NgIf,
    NgFor,
    FormsModule,
    TblComponent,
    NgClass,
    LoaderComponent,
    ToastComponent,
    UserAuditComponent,
  ],
  templateUrl: './user-master.component.html',
  styleUrls: ['./../master-setup.css', './user-master.component.css'],
})
export class UserMasterComponent {
  constructor(
    private apiService: ApiService,
    private sessionService: SessionService
  ) {
    this.loginUserRole = sessionService.getRole();
  }
  ngOnInit() {
    this.getTableData();
    this.getCategoryList();
  }

  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  fullData = []; // 🔥 ALL DATA (for filtering/search)
  // Pagination state
  pageNumber: number = 1;
  pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'userTypeTable';
  pageHeader: string = 'User Role Master';
  originalUserTypeName: string | undefined = '';
  loginUserRole: string = '';
  popupText = '';
  popupVisible = false;
  addEditPopup = false;
  isLoading = false;
  addUserType = false;
  searchUserType = '';
  editUserType: boolean = false;
  editIndex = -1;
  userTypeEntity: User = { categoryName: '', userTypeName: '' };
  categoryList: CategoryMap[] = [];
  headers: { key: string; value: string }[] = [
    { key: 'categoryName', value: 'Category' },
    { key: 'userTypeNameLabel', value: 'User Type' },
    { key: 'status', value: 'Status' },
    { key: 'Action', value: 'Action' },
  ];
  // temp data
  data: User[] = [];
  ogData: User[] = [];
  isViewMode: boolean = false;
  isAuditOpen = false;
  auditCards: any[] = [];
  selectedCategory: string = 'All';
  selectedStatus: string = 'All';
  isFilterMode: boolean = false;
  statuses = ['PENDING APPROVAL', 'APPROVED', 'RETURNED'];

  openAudit() {
    this.isAuditOpen = true;
  }
  closeAudit() {
    this.isAuditOpen = false;
  }
  auditFnc(row: any) {
    this.auditCards = this.createAuditCards(row);
    this.isAuditOpen = true;
  }
  createAuditCards(row: any) {
    const cards: any[] = [];
    if (row.makerName && row.createdAt) {
      cards.push({
        label: 'Maker',
        name: row.makerName,
        datetime: this.formatAuditDate(row.createdAt),
        status: 'completed',
      });
    }
    if (row.editorName && row.editedAt) {
      cards.push({
        label: 'Last Editor',
        name: row.editorName,
        datetime: this.formatAuditDate(row.editedAt),
        status: 'completed',
      });
    }
    if (row.rejectedBy && row.rejectedAt) {
      cards.push({
        label: 'Rejected By',
        name: row.rejectedBy,
        datetime: this.formatAuditDate(row.rejectedAt),
        status: 'completed',
      });
      return cards; // stop here
    }
    if (row.checkerName && row.approvedAt) {
      cards.push({
        label: 'Approved By',
        name: row.checkerName,
        datetime: this.formatAuditDate(row.approvedAt),
        status: 'completed',
      });
    }
    return cards;
  }

  formatAuditDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  viewUserType(row: User) {
    this.isViewMode = true;

    this.userTypeEntity = {
      ...row,
      userTypeNameLabel: row.userTypeNameLabel || row.userTypeName,
    };

    this.originalUserTypeName = row.userTypeName;
    this.addEditPopup = true;
  }

  filterCategory(filterCategory: CategoryFilterEntity) {
    console.log('filterCategory:' + JSON.stringify(filterCategory, null, 2));
    if (filterCategory.categoryName == 'All') {
      this.data = [...this.ogData];
      return;
    }
    this.data = this.ogData.filter(
      (item) =>
        item.categoryName &&
        item.categoryName
          .toLowerCase()
          .includes(filterCategory.categoryName?.toLowerCase() ?? '')
    );
  }
  addBtnAllowed(): boolean {
    if (
      this.loginUserRole == SUPERADMIN ||
      this.loginUserRole == BANKSUPERADMINMAKER
    )
      return true;
    else return false;
  }
  search() {
    this.isFilterMode = true;

    // 🔥 Load full data if not already
    if (!this.fullData.length) {
      this.getAllData();
      setTimeout(() => this.applyAllFilters(), 300);
    } else {
      this.applyAllFilters();
    }
  }
  getActions(): string[] {
    if (this.loginUserRole === BANKSUPERADMINCHECKER) {
      return ['view', 'audit']; // 👈 only view for checker
    }

    if (
      this.loginUserRole === SUPERADMIN ||
      this.loginUserRole === BANKSUPERADMINMAKER
    ) {
      return ['edit', 'audit']; // 👈 makers
    }

    return ['audit']; // fallback
  }
  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }

  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  getTableData() {
    this.isLoading = true;
    this.apiService
      .getData(
        CREATE_All_TEMP_USERTYPE +
        '?page=' +
        (this.pageNumber - 1) +
        '&size=' +
        this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.data = res.payload.content.map((item: any) => ({
              ...item,
              userTypeNameLabel: item.userTypeNameLabel || item.userTypeName,
            }));
            this.ogData = [...this.data];
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements;
            }
          } else {
            console.log('inside get else');
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'userTypeTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }

  getCategoryList() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            console.log('res :' + JSON.stringify(res, null, 2));
            this.categoryList = res.payload.content.map((item: any) => ({
              categoryId: item.categoryId,
              categoryName: item.categoryName,
            }));
            console.log(
              'category list' + JSON.stringify(this.categoryList, null, 2)
            );
          } else {
            console.log('inside get else');
            this.showToast('error', 'Error', res.description);
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Someting went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }

  userTypeNameError = false;
  userTypeCategoryError = false;
  hidePopup() {
    this.popupText = '';
    this.popupVisible = false;
  }
  addUserTypef() {
    this.userTypeEntity = {};
    this.addEditPopup = true;
  }
  editUserTypeF(row: User, index: number) {
    this.isViewMode = false;

    this.userTypeEntity = {
      ...row,
      userTypeNameLabel: row.userTypeNameLabel || row.userTypeName,
    };

    this.originalUserTypeName = row.userTypeName; // 🔥 store original
    this.editIndex = index;
    this.addEditPopup = true;
    this.editUserType = true;
  }
  fetchedUserRow: any = {};
  getUserById(userId: number | undefined) {
    this.isLoading = true;
    this.apiService
      .sendData(GET_USERTYPE_BY_ID + '?userTypeId=' + userId, {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.fetchedUserRow = res.payload;
            console.log(
              'fetchedUserRow: ' + JSON.stringify(this.fetchedUserRow, null, 2)
            );
          } else {
            this.popupText = res.description;
            this.popupVisible = true;
          }
        },
        error: (err) => {
          this.popupText = 'Someting went wrong';
          this.popupVisible = true;
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  deleteUserType(row: User, index: number) {
    console.log('inside delete');
    this.data.splice(index, 1);
    this.data = [...this.data];
  }

  saveUserType() {
    if (!this.validateUserType()) return;

    this.isLoading = true;
    const isEdit = this.editUserType;

    const req = {
      userTypeId: isEdit ? this.userTypeEntity.userTypeId : null,
      isUpdate: isEdit,

      // 🔥 CORE LOGIC
      userTypeName: isEdit
        ? this.originalUserTypeName // OLD
        : this.userTypeEntity.userTypeNameLabel, // NEW (CREATE)

      userTypeNameLabel: this.userTypeEntity.userTypeNameLabel,

      categoryId: this.userTypeEntity.categoryId,
    };

    const actionRole = isEdit ? 'EDIT' : 'CREATE';

    this.apiService
      .sendData(isEdit ? EDIT_MASTER_USERTYPE : CREATE_MASTER_USERTYPE, req, {
        'X-ACTION-ROLE': actionRole,
      })
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.showToast(
              'success',
              'Success',
              isEdit
                ? 'User Type Updated Successfully'
                : 'User Type Created Successfully'
            );
            this.getTableData();
            this.closeFormPopup();
          } else {
            // 🔥 Backend returned error in success response
            this.showToast(
              'error',
              'Error',
              res.message || res.description || 'Something went wrong'
            );
          }
          this.isLoading = false; // ✅ IMPORTANT
        },
        error: (err) => {
          console.log('API ERROR:', err);
          // 🔥 Extract backend message safely
          const errorMessage =
            err?.error?.message ||
            err?.error?.description ||
            'Something went wrong';
          this.showToast('error', 'Error', errorMessage);
          this.isLoading = false; // ✅ IMPORTANT
        },
      });

    this.closeFormPopup();
  }

  // saveUserType() {
  //   if (!this.validateUserType()) return;
  //   else {
  //     this.isLoading = true;
  //     let req = {};
  //     if (this.editUserType) {
  //       this.fetchedUserRow['userTypeName'] = this.userTypeEntity.userTypeName;
  //       this.fetchedUserRow['categoryId'] = this.userTypeEntity.categoryId;
  //       req = this.fetchedUserRow;
  //     } else {
  //       req = {
  //         categoryId: this.userTypeEntity.categoryId,
  //         userTypeName: this.userTypeEntity.userTypeName,
  //       };
  //     }

  //     console.log('req data' + JSON.stringify(req, null, 2));
  //     // this.apiService
  //     //   .sendData(
  //     //     this.editUserType ? EDIT_MASTER_USERTYPE : CREATE_MASTER_USERTYPE,
  //     //     req
  //     //   )
  //     const actionRole = this.editUserType ? 'EDIT' : 'CREATE';
  //     this.apiService
  //       .sendData(
  //         this.editUserType ? EDIT_MASTER_USERTYPE : CREATE_MASTER_USERTYPE,
  //         req,
  //         {
  //           'X-ACTION-ROLE': actionRole,
  //         }
  //       )
  //       .subscribe({
  //         next: (res) => {
  //           if (res.status == 'SUCCESS') {
  //             console.log('usertype data' + JSON.stringify(res, null, 2));
  //             this.showToast(
  //               'success',
  //               'Success',
  //               this.editUserType
  //                 ? 'Role Updated Successfully'
  //                 : 'Role Created Successfully'
  //             );
  //             this.getTableData();
  //           } else {
  //             this.showToast('error', 'Error', res.description);
  //             this.isLoading = false;
  //           }
  //         },
  //         error: (err) => {
  //           this.showToast('error', 'Error', 'Someting went wrong');
  //           this.isLoading = false;
  //         },
  //         complete: () => {
  //           this.isLoading = false;
  //         },
  //       });
  //   }
  //   this.closeFormPopup();
  // }

  // }

  //-----------edit user type---------------

  errorCount = 0;
  validateUserType(): boolean {
    this.errorCount = 0;
    if (!this.userTypeEntity.userTypeNameLabel) {
      this.errorCount++;
      this.userTypeNameError = true;
    }
    if (!this.userTypeEntity.categoryId) {
      this.errorCount++;
      this.userTypeCategoryError = true;
    }
    return this.errorCount == 0 ? true : false;
  }
  // closeFormPopup() {
  //   this.editIndex = -1;
  //   this.errorCount = 0;
  //   this.addEditPopup = false;
  //   this.userTypeNameError = false;
  //   this.userTypeCategoryError = false;
  // }

  // approveUserType() {
  //   console.log('Approved:', this.userTypeEntity);

  //   // 👉 call API here
  //   this.showToast('success', 'Approved', 'User Type Approved');

  //   this.closeFormPopup();
  // }

  // rejectUserType() {
  //   console.log('Rejected:', this.userTypeEntity);

  //   // 👉 call API here
  //   this.showToast('error', 'Rejected', 'User Type Rejected');

  //   this.closeFormPopup();
  // }

  closeFormPopup() {
    this.editIndex = -1;
    this.errorCount = 0;
    this.addEditPopup = false;
    this.userTypeNameError = false;
    this.userTypeCategoryError = false;

    this.isViewMode = false; // 🔥 IMPORTANT
  }
  approveUserType() {
    const url =
      APPROVE_USER_TYPE + `?userTypeId=${this.userTypeEntity.userTypeId}`;
    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': 'APPROVE',
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('success', 'Approved', 'User Type Approved');
            this.getTableData();
            this.closeFormPopup();
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Approval failed');
        },
      });
  }

  rejectUserType() {
    const url =
      REJECT_USER_TYPE + `?userTypeId=${this.userTypeEntity.userTypeId}`;
    this.apiService
      .sendData(
        url,
        {},
        {
          'X-ACTION-ROLE': 'REJECT',
        }
      )
      .subscribe({
        next: (res: any) => {
          if (res.status === 'SUCCESS') {
            this.showToast('error', 'Rejected', 'User Type Rejected');
            this.getTableData();
            this.closeFormPopup();
          }
        },
        error: () => {
          this.showToast('error', 'Error', 'Rejection failed');
        },
      });
  }

  getAllData() {
    this.isLoading = true;

    this.apiService
      .getData(CREATE_All_TEMP_USERTYPE + '?page=0&size=10000', {})
      .subscribe({
        next: (res) => {
          if (res.status === 'SUCCESS') {
            this.fullData = res.payload.content.map((item: any) => ({
              ...item,
              userTypeNameLabel: item.userTypeNameLabel || item.userTypeName,
            }));
          }
        },
        complete: () => (this.isLoading = false),
      });
  }

  // applyGlobalFilter() {
  //   // 🔥 RESET CONDITION (IMPORTANT)
  //   if (this.selectedCategory === 'All' && this.selectedStatus === 'All') {
  //     this.resetToDefault();
  //     return;
  //   }

  //   this.isFilterMode = true;

  //   // 🔥 Load full data if not already
  //   if (!this.fullData.length) {
  //     this.getAllData();

  //     setTimeout(() => this.filterData(), 300); // small delay
  //   } else {
  //     this.filterData();
  //   }
  // }

  filterData() {
    this.data = this.fullData.filter((item: any) => {
      const categoryMatch =
        this.selectedCategory === 'All' ||
        item.categoryName === this.selectedCategory;

      const statusMatch =
        this.selectedStatus === 'All' || item.status === this.selectedStatus;

      return categoryMatch && statusMatch;
    });
  }

  resetToDefault() {
    this.isFilterMode = false;
    this.selectedCategory = 'All';
    this.selectedStatus = 'All';
    this.fullData = [];

    this.getTableData(); // 🔥 back to API pagination
  }

  applyAllFilters() {
    const searchTerm = this.searchUserType?.toLowerCase() || '';
    this.data = this.fullData.filter((item: any) => {
      const categoryMatch =
        this.selectedCategory === 'All' ||
        item.categoryName === this.selectedCategory;
      const statusMatch =
        this.selectedStatus === 'All' || item.status === this.selectedStatus;
      const searchMatch =
        !searchTerm ||
        item.userTypeNameLabel?.toLowerCase().includes(searchTerm) ||
        item.categoryName?.toLowerCase().includes(searchTerm);
      return categoryMatch && statusMatch && searchMatch;
    });
    this.totalElements = this.data.length; // ✅ FIX: update count for pagination
  }
  applyGlobalFilter() {
    if (
      this.selectedCategory === 'All' &&
      this.selectedStatus === 'All' &&
      !this.searchUserType
    ) {
      this.resetToDefault();
      return;
    }
    this.isFilterMode = true;
    if (!this.fullData.length) {
      this.getAllData();
      setTimeout(() => this.applyAllFilters(), 300);
    } else {
      this.applyAllFilters();
    }
  }
}
