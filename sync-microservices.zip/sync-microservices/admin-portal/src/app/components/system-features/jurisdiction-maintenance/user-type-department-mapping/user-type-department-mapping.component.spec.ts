import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTypeDepartmentMappingComponent } from './user-type-department-mapping.component';

describe('UserTypeDepartmentMappingComponent', () => {
  let component: UserTypeDepartmentMappingComponent;
  let fixture: ComponentFixture<UserTypeDepartmentMappingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserTypeDepartmentMappingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserTypeDepartmentMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
