// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-user-type-department-mapping',
//   imports: [],
//   templateUrl: './user-type-department-mapping.component.html',
//   styleUrl: './user-type-department-mapping.component.css'
// })
// export class UserTypeDepartmentMappingComponent {

// }

import { Component } from '@angular/core';
import { PageTitleComponent } from '../../../../commom/page-title/page-title.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TblComponent } from '../../../../commom/tbl/tbl.component';
import { ApiService } from '../../../../service/apiService/api.service';
import {
  CREATE_MASTER_USERTYPE,
  EDIT_MASTER_USERTYPE,
  GET_ALL_CATEGORY,
  GET_ALL_USERTYPE,
  GET_USERTYPE_BY_ID,
  CREATE_All_TEMP_USERTYPE, // ✅ added to show pending roles
} from '../../../../constants/api_endpoints';
import { LoaderComponent } from '../../../../commom/loader/loader.component';
import { ToastComponent } from '../../../../commom/toast/toast.component';
import { PAGE_SIZE } from '../../../../constants/Constants';
import { GET_ALL_DEPARTMENTS, GET_DEPARTMENTS_BY_CATEGORY_ID } from '../../../../constants/api_endpoints';
import { MAP_USER_TYPE } from '../../../../constants/api_endpoints';
export interface User {
  userTypeId?: number;
  userTypeName?: string;
  categoryId?: number;
  categoryName?: string;
}

export interface CategoryMap {
  categoryId?: number;
  categoryName?: string;
}

@Component({
  selector: 'app-user-master',
  imports: [
    NgIf,
    NgFor,
    FormsModule,
    TblComponent,
    NgClass,
    LoaderComponent,
    ToastComponent,
  ],
  templateUrl: './user-type-department-mapping.component.html',
  styleUrl: './user-type-department-mapping.component.css',
})
export class UserTypeDepartmentMappingComponent {
  constructor(private apiService: ApiService) { }
  ngOnInit() {
    this.getTableData() // ✅ first
    this.getDepartments();
  }
  toast = {
    type: '',
    title: '',
    message: '',
    visible: false,
    hiding: true,
  };
  // Pagination state
  pageNumber: number = 1;
  pageSize: number = 10000; // ✅ Increased to ensure all Bank mappings are visible
  // pageSize: number = PAGE_SIZE;
  totalElements: number = 0;
  tableId: string = 'userTypeTable';

  popupText = '';
  popupVisible = false;
  addEditPopup = false;
  isLoading = false;
  addUserType = false;
  searchUserType = '';
  editUserType: boolean = false;
  editIndex = -1;
  userTypeEntity: User = { categoryName: '', userTypeName: '' };
  categoryList: CategoryMap[] = [];
  headers: { key: string; value: string }[] = [
    { key: 'userTypeNameLabel', value: 'User Type' },
    { key: 'categoryId', value: 'Department' }, // we'll render dropdown
  ];
  dropdownColumn = 'categoryId';
  dropdownDisplayKey = 'categoryName';
  dropdownOptions = [
    { categoryId: 1, categoryName: 'HR' },
    { categoryId: 2, categoryName: 'Finance' },
    { categoryId: 3, categoryName: 'Operations' },
    { categoryId: 4, categoryName: 'IT' },
  ];
  userTypeDeptMap: { [key: number]: any } = {};
  // temp data
  data: User[] = [];

  getCategoryList() {
    this.apiService
      .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.categoryList = res.payload.content;
            // 🔥 IMPORTANT: assign to dropdownOptions
          }
        },
      });
  }
  showSaveButton = false;
  changedMappings: any[] = [];
  onDropdownChange(event: any) {
    const { row, newValue } = event;
    const selected = newValue?.[0];
    if (!selected) return;
    this.changedMappings.push({
      userTypeId: row.userTypeId,
      categoryId: selected.categoryId,
    });
    this.showSaveButton = true;
  }

  // getDepartments() {
  //   this.apiService.getData(GET_ALL_DEPARTMENTS, {}).subscribe({
  //     next: (res) => {
  //       if (res.status === 'SUCCESS') {
  //         // 🔥 map API → table format
  //         this.dropdownOptions = res.payload.map((item: any) => ({
  //           categoryId: item.id,
  //           categoryName: item.departmentName,
  //         }));
  //         console.log('Departments:', this.dropdownOptions);
  //         // AFTER departments → load table
  //         this.getTableData();
  //       }
  //     },
  //     error: () => {
  //       this.showToast('error', 'Error', 'Failed to load departments');
  //     },
  //   });
  // }


  // getDepartments() {
  //   this.apiService.getData(GET_DEPARTMENTS_BY_CATEGORY_ID + `?categoryId=2`, {}).subscribe({
  //     next: (res) => {
  //       if (res.status === 'SUCCESS') {
  //         // dropdown options
  //         this.dropdownOptions = res.payload.map((item: any) => ({
  //           categoryId: item.id,
  //           categoryName: item.departmentNameLabel,
  //         }));
  //         // 🔥 CREATE LOOKUP MAP
  //         this.userTypeDeptMap = {};
  //         res.payload.forEach((dept: any) => {
  //           dept.userTypes.forEach((ut: any) => {
  //             // this.userTypeDeptMap[ut.userTypeId] = {
  //             //   categoryId: dept.id,
  //             //   categoryName: dept.departmentName,
  //             // };
  //             if (!this.userTypeDeptMap[ut.userTypeId]) {
  //               this.userTypeDeptMap[ut.userTypeId] = [];
  //             }
  //             this.userTypeDeptMap[ut.userTypeId].push({
  //               categoryId: dept.id,
  //               categoryName: dept.departmentName,
  //             });
  //           });
  //         });
  //         console.log('Mapping:', this.userTypeDeptMap);
  //         this.getTableData(); // after mapping
  //       }
  //     },
  //   });
  // }

  getDepartments() {
    this.apiService.getData(GET_ALL_DEPARTMENTS, {}).subscribe({
      next: (res) => {
        if (res.status === 'SUCCESS') {
          // dropdown options
          this.dropdownOptions = res.payload.map((item: any) => ({
            categoryId: item.id,
            categoryName: item.departmentName,
          }));
          // 🔥 CREATE LOOKUP MAP
          this.userTypeDeptMap = {};
          res.payload.forEach((dept: any) => {
            dept.userTypes.forEach((ut: any) => {
              // this.userTypeDeptMap[ut.userTypeId] = {
              //   categoryId: dept.id,
              //   categoryName: dept.departmentName,
              // };
              if (!this.userTypeDeptMap[ut.userTypeId]) {
                this.userTypeDeptMap[ut.userTypeId] = [];
              }
              this.userTypeDeptMap[ut.userTypeId].push({
                categoryId: dept.id,
                categoryName: dept.departmentName,
              });
            });
          });
          console.log('Mapping:', this.userTypeDeptMap);
          this.getTableData(); // after mapping
        }
      },
    });
  }

  saveMappings() {
    const deptMap: { [key: number]: number[] } = {};

    this.data.forEach((row: any) => {
      const selectedList = row.categoryId || [];

      selectedList.forEach((dept: any) => {
        const deptId = dept.categoryId;
        const userTypeId = row.userTypeId;

        if (!deptMap[deptId]) {
          deptMap[deptId] = [];
        }

        // جلوگیری duplicates (optional but good)
        if (!deptMap[deptId].includes(userTypeId)) {
          deptMap[deptId].push(userTypeId);
        }
      });
    });

    const payload = {
      mapping: Object.keys(deptMap).map((deptIdStr) => ({
        deptId: Number(deptIdStr),
        userTypeIds: deptMap[Number(deptIdStr)],
      })),
    };

    console.log('FINAL PAYLOAD:', JSON.stringify(payload, null, 2));

    this.apiService.sendData(MAP_USER_TYPE, payload).subscribe({
      next: (res) => {
        if (res.status === 'SUCCESS') {
          this.showToast('success', 'Success', 'Mapping saved successfully');
          this.showSaveButton = false;
        } else {
          this.showToast('error', 'Error', res.description);
        }
      },
      error: () => {
        this.showToast('error', 'Error', 'Failed to save mapping');
      },
    });
  }

  showToast(type: string, title: string, message: string) {
    this.toast = {
      type,
      title,
      message,
      visible: true,
      hiding: false,
    };
    setTimeout(() => {
      this.toast.hiding = true;
      setTimeout(() => {
        this.toast.visible = false;
      }, 300);
    }, 3000);
  }

  hideToast() {
    this.toast.hiding = true;
    setTimeout(() => {
      this.toast.visible = false;
    }, 300);
  }

  getTableData() {
    this.isLoading = true;
    this.apiService
      .getData(
        // GET_ALL_USERTYPE +
        CREATE_All_TEMP_USERTYPE +
        '?page=' +
        (this.pageNumber - 1) +
        '&size=' +
        this.pageSize,
        {}
      )
      .subscribe({
        next: (res) => {
          console.log(res);
          if (res.status == 'SUCCESS') {
            this.data = res.payload.content
              // .filter((row: any) => row.categoryName === 'Bank')
              .filter((row: any) => row.categoryId === 2 || row.categoryName === 'Bank' || row.categoryName === 'Bank Category')
              .map((row: any) => {
                const mappedDept = this.userTypeDeptMap[row.userTypeId] || [];

                // 🔥 VERY IMPORTANT FIX
                const normalized = mappedDept
                  .map((dept: any) =>
                    this.dropdownOptions.find(
                      (opt) => opt.categoryId === dept.categoryId
                    )
                  )
                  .filter(Boolean); // remove undefined

                return {
                  ...row,
                  categoryId: normalized, // ✅ correct reference
                };
              });
            console.log(
              'FINAL TABLE DATA:',
              JSON.stringify(this.data, null, 2)
            );

            /*
            if (res.payload.page) {
              this.totalElements = res.payload.page.totalElements; // since filtered
            }
            */
            this.totalElements = this.data.length; // ✅ FIX: update count for pagination after local filtering
          }
        },
        error: (err) => {
          this.showToast('error', 'Error', 'Something went wrong');
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }


  onPageChange(event: { page: number; pageSize: number; tableId?: string }) {
    if (event.tableId !== this.tableId) {
      this.pageNumber = 1;
      this.pageSize = PAGE_SIZE;
      this.totalElements = 0;
      this.tableId = event.tableId ?? '';
    }
    if (event.tableId === 'userTypeTable') {
      this.pageNumber = event.page;
      this.pageSize = event.pageSize;
      this.getTableData();
    } else if (event.tableId === 'anotherTable') {
      // Call the API function for the second table if you add one later
      // this.getTableData(event.tableId);
    }
  }

  // getCategoryList() {
  //   this.apiService
  //     .getData(GET_ALL_CATEGORY + '?page=0&size=1000', {})
  //     .subscribe({
  //       next: (res) => {
  //         if (res.status == 'SUCCESS') {
  //           console.log('res :' + JSON.stringify(res, null, 2));
  //           this.categoryList = res.payload.content.map((item: any) => ({
  //             categoryId: item.categoryId,
  //             categoryName: item.categoryName,
  //           }));
  //           console.log(
  //             'category list' + JSON.stringify(this.categoryList, null, 2)
  //           );
  //         } else {
  //           console.log('inside get else');
  //           this.showToast('error', 'Error', res.description);
  //         }
  //       },
  //       error: (err) => {
  //         this.showToast('error', 'Error', 'Someting went wrong');
  //       },
  //       complete: () => {
  //         this.isLoading = false;
  //       },
  //     });
  // }

  userTypeNameError = false;
  userTypeCategoryError = false;
  hidePopup() {
    this.popupText = '';
    this.popupVisible = false;
  }
  addUserTypef() {
    this.userTypeEntity = {};
    this.addEditPopup = true;
  }
  editUserTypeF(row: User, index: number) {
    console.log('edit row: ' + JSON.stringify(row, null, 2));
    this.userTypeEntity = row;
    this.getUserById(row.userTypeId);
    this.editIndex = index;
    this.addEditPopup = true;
    this.editUserType = true;
  }
  fetchedUserRow: any = {};
  getUserById(userId: number | undefined) {
    this.isLoading = true;
    this.apiService
      .sendData(GET_USERTYPE_BY_ID + '?userTypeId=' + userId, {})
      .subscribe({
        next: (res) => {
          if (res.status == 'SUCCESS') {
            this.fetchedUserRow = res.payload;
            console.log(
              'fetchedUserRow: ' + JSON.stringify(this.fetchedUserRow, null, 2)
            );
          } else {
            this.popupText = res.description;
            this.popupVisible = true;
          }
        },
        error: (err) => {
          this.popupText = 'Someting went wrong';
          this.popupVisible = true;
        },
        complete: () => {
          this.isLoading = false;
        },
      });
  }
  deleteUserType(row: User, index: number) {
    console.log('inside delete');
    this.data.splice(index, 1);
    this.data = [...this.data];
  }

  saveUserType() {
    if (!this.validateUserType()) return;
    else {
      this.isLoading = true;
      let req = {};
      if (this.editUserType) {
        this.fetchedUserRow['userTypeName'] = this.userTypeEntity.userTypeName;
        this.fetchedUserRow['categoryId'] = this.userTypeEntity.categoryId;
        req = this.fetchedUserRow;
      } else {
        req = {
          categoryId: this.userTypeEntity.categoryId,
          userTypeName: this.userTypeEntity.userTypeName,
        };
      }

      console.log('req data' + JSON.stringify(req, null, 2));
      this.apiService
        .sendData(
          this.editUserType ? EDIT_MASTER_USERTYPE : CREATE_MASTER_USERTYPE,
          req
        )
        .subscribe({
          next: (res) => {
            if (res.status == 'SUCCESS') {
              console.log('usertype data' + JSON.stringify(res, null, 2));
              this.showToast(
                'success',
                'Success',
                this.editUserType
                  ? 'Role Updated Successfully'
                  : 'Role Created Successfully'
              );
              this.getTableData();
            } else {
              this.showToast('error', 'Error', res.description);
              this.isLoading = false;
            }
          },
          error: (err) => {
            this.showToast('error', 'Error', 'Someting went wrong');
            this.isLoading = false;
          },
          complete: () => {
            this.isLoading = false;
          },
        });
    }
    this.closeFormPopup();
  }

  // }

  //-----------edit user type---------------

  errorCount = 0;
  validateUserType(): boolean {
    this.errorCount = 0;
    if (!this.userTypeEntity.userTypeName) {
      this.errorCount++;
      this.userTypeNameError = true;
    }
    if (!this.userTypeEntity.categoryId) {
      this.errorCount++;
      this.userTypeCategoryError = true;
    }
    return this.errorCount == 0 ? true : false;
  }
  closeFormPopup() {
    this.editIndex = -1;
    this.errorCount = 0;
    this.addEditPopup = false;
    this.userTypeNameError = false;
    this.userTypeCategoryError = false;
  }
}
