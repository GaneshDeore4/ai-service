import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RateMaintenanceComponent } from './rate-maintenance.component';

describe('RateMaintenanceComponent', () => {
  let component: RateMaintenanceComponent;
  let fixture: ComponentFixture<RateMaintenanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RateMaintenanceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RateMaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
