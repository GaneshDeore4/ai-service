import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../commom/page-title/page-title.component";
import { FormsModule } from '@angular/forms';
import { NgFor } from '@angular/common';
import { TableComponent } from "../../../commom/table/table.component";

@Component({
  selector: 'app-rate-maintenance',
  imports: [PageTitleComponent, FormsModule, NgFor, TableComponent],
  templateUrl: './rate-maintenance.component.html',
  styleUrl: './rate-maintenance.component.css'
})
export class RateMaintenanceComponent {

  searchFromCurrency='';
  searchToCurrency='';
  searchFromCurrencyName='';
  searchToCurrencyName='';
  searchStatusList:string[]=['Awaiting Approval(M)','Checker Returned(M)','Draft(M)'];
  selectedSearchStatus:string='';



  //table config
  headers:string[] = [
    'From Currency',
    'From Currency Name',
    'To Currency',
    'To Currency Name',
    'Buy Rate',
    'Mid Rate',
    'Sell Rate',
    'Status',
    'Maker User',
    'Action'
  ];
  columnWidths:string[]=[
    '10%',
    '15%',
    '10%',
    '15%',
    '5%',
    '5%',
    '5%',
    '12.5%',
    '12.5%',
    '10%'
  ];
  data:any[] = [
    {
      'From Currency': 'USD',
      'From Currency Name': 'US Dollar',
      'To Currency': 'INR',
      'To Currency Name': 'Indian Rupee',
      'Buy Rate': '82.50',
      'Mid Rate': '83.00',
      'Sell Rate': '83.50',
      'Status': 'Draft(M)',
      'Maker User': 'john doe',
    },
    {
      'From Currency': 'EUR',
      'From Currency Name': 'Euro',
      'To Currency': 'INR',
      'To Currency Name': 'Indian Rupee',
      'Buy Rate': '88.50',
      'Mid Rate': '89.00',
      'Sell Rate': '89.50',
      'Status': 'Awaiting Approval(M)',
      'Maker User': 'jane smith',
    }
  ];

}
