import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfChangeProfileComponent } from './sf-change-profile.component';

describe('SfChangeProfileComponent', () => {
  let component: SfChangeProfileComponent;
  let fixture: ComponentFixture<SfChangeProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SfChangeProfileComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SfChangeProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
