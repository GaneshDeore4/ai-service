import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../commom/page-title/page-title.component";
import { FormsModule } from '@angular/forms';
import { PopupComponent } from "../../../commom/popup/popup.component";
import { NgClass, NgFor } from '@angular/common';

@Component({
  selector: 'app-sf-change-profile',
  imports: [PageTitleComponent, FormsModule, PopupComponent, NgClass, NgFor],
  templateUrl: './sf-change-profile.component.html',
  styleUrl: './sf-change-profile.component.css'
})
export class SfChangeProfileComponent {


  popupMsg = '';
  popupVisible = false;

  company:string='IndusInd';
  loginId:string='indus123';
  name:string='John Doe';
  langaugeList:string[]=['English(UK)','English(USA)','French','Arabic'];
  selectedLanguage:string='English(UK)';
  changePassword:boolean=false;
  oldPassword:string='';
  newPassword:string='';
  confirmPassword:string='';

  // error
  languageError:boolean=false;


    hidePopup() {
    this.popupVisible = false;
  }

  closePopup() {
    // this.showAddTopicPopup = false;
  }

  saveProfile(){
    this.popupMsg = 'Profile changes saved successfully.';
    this.popupVisible = true;
  }
}
