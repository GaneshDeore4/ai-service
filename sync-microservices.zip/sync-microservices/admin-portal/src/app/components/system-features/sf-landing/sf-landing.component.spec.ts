import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfLandingComponent } from './sf-landing.component';

describe('SfLandingComponent', () => {
  let component: SfLandingComponent;
  let fixture: ComponentFixture<SfLandingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SfLandingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SfLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
