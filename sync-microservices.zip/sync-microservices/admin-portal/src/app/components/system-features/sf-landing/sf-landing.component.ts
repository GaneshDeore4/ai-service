import { Component } from '@angular/core';
import { PageTitleComponent } from "../../../commom/page-title/page-title.component";

@Component({
  selector: 'app-sf-landing',
  imports: [PageTitleComponent],
  templateUrl: './sf-landing.component.html',
  styleUrl: './sf-landing.component.css'
})
export class SfLandingComponent {

}
