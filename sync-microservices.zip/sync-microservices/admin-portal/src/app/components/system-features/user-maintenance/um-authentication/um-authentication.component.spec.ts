import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UmAuthenticationComponent } from './um-authentication.component';

describe('UmAuthenticationComponent', () => {
  let component: UmAuthenticationComponent;
  let fixture: ComponentFixture<UmAuthenticationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UmAuthenticationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UmAuthenticationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
