import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TableComponent } from '../../../../commom/table/table.component';
import { PageTitleComponent } from "../../../../commom/page-title/page-title.component";
import { PopupComponent } from "../../../../commom/popup/popup.component";

@Component({
  selector: 'app-um-authentication',
  imports: [NgIf, FormsModule, TableComponent, NgFor, PageTitleComponent, PopupComponent],
  templateUrl: './um-authentication.component.html',
  styleUrl: './um-authentication.component.css'
})
export class UmAuthenticationComponent {

  // main page vars
  searchLastName='';
  searchFirstName='';
  searchLoginId='';
  searchSelectedProfileStatus='';
  searchProfileStatusList: string[] = ['Active', 'Inactive', 'Lock'];
  searchStatusList: string[] = ['Awaiting for Approval(D)', 'Awaiting for Approval(M)', 'Awaiting for Approval(N)', 'Checker Returned(D)', 'Checker Returned(M)', 'Checker Returned(N)', 'Draft(M)', 'Draft(N)'];
  searchSelectedStatus = '';

  authForm=false;

  userHeaders=['First Name', 'Last Name', 'LoginID', 'Profile Status', 'Status', 'Maker', 'Action'];
  userOgData: any[] = [
    {
      "First Name": "John",
      "Last Name": "Doe",
      "LoginID": "johndoe",
      "Employee Number": "12345",
      "Department": "IT",
      "Address": "123 Main St",
      "Postal Code": "12345",
      "Auth Mode": "Password",
      "Time Zone": "Asia/Calcutta",
      "Language": "English(UK)",
      "Base Currency": "USD",
      "Contact Number": "123-456-7890",
      "Fax": "123-456-7891",
      "email":"dummy@gmail.com",
      "Pending Tran Notification": true,
      "Auth Level":"A",
      "Limit Amount Currency":"USD",
      "Limit Amount":"1000",
      "Profile Status": "Active",
      "Status": "Awaiting for Approval(D)",
      "Maker": "John Doe"
    },
    {
      "First Name": "Jane",
      "Last Name": "Smith",
      "LoginID": "janesmith",
      "Employee Number": "54321",
      "Department": "HR",
      "Address": "456 Oak Ave",
      "Postal Code": "54321",
      "Auth Mode": "OTP Password",
      "Time Zone": "America/Havana",
      "Language": "French",
      "Base Currency": "EUR",
      "Contact Number": "098-765-4321",
      "Fax": "098-765-4322",
      "email":"jane.smith@example.com",
      "Pending Tran Notification": false,
      "Auth Level":"B",
      "Limit Amount Currency":"EUR",
      "Limit Amount":"5000",
      "Profile Status": "Inactive",
      "Status": "Checker Returned(M)",
      "Maker": "Jane Smith"
    },
    {
      "First Name": "Peter",
      "Last Name": "Jones",
      "LoginID": "peterjones",
      "Employee Number": "67890",
      "Department": "Finance",
      "Address": "789 Pine Ln",
      "Postal Code": "67890",
      "Auth Mode": "No Re-Autehntication",
      "Time Zone": "Asia/Calcutta",
      "Language": "Arabic",
      "Base Currency": "GBP",
      "Contact Number": "111-222-3333",
      "Fax": "111-222-3334",
      "email":"peter.jones@example.com",
      "Pending Tran Notification": true,
      "Auth Level":"C",
      "Limit Amount Currency":"GBP",
      "Limit Amount":"10000",
      "Profile Status": "Lock",
      "Status": "Draft(N)",
      "Maker": "Peter Jones"
    }
  ];
  userData = [...this.userOgData];
    searchUserf(): void {
    const filtered = this.userOgData.filter(item => {
      const matchLastName = this.searchLastName
        ? item['Last Name']?.toLowerCase().includes(this.searchLastName.toLowerCase())
        : true;

      const matchFirstName = this.searchFirstName
        ? item['First Name']?.toLowerCase().includes(this.searchFirstName.toLowerCase())
        : true;

      const matchLoginId = this.searchLoginId
        ? item['LoginID']?.toLowerCase().includes(this.searchLoginId.toLowerCase())
        : true;

      const matchProfileStatus = this.searchSelectedProfileStatus
        ? item['Profile Status']?.toLowerCase().includes(this.searchSelectedProfileStatus.toLowerCase())
        : true;

      const matchStatus = this.searchSelectedStatus
        ? item['Status']?.toLowerCase().includes(this.searchSelectedStatus.toLowerCase())
        : true;

      return matchLastName && matchFirstName && matchLoginId && matchProfileStatus && matchStatus;
    });

    this.userData = [...filtered];
  }

  editAuthf(row:any,index:number){
    this.authForm=true;
  }


  // details page
  viewUser=true;
  company='Indusind';
  loginId='testLogin@indusind.com';
  name='test user';

  popupText='';
  popupVisible=false;
  hidePopup(){
    this.popupVisible=false;
    this.popupText='';
  }
  saveAuth(){
    this.popupText='Authentication details saved.';
    this.popupVisible=true;
    this.toUsersPage();
  }
  toUsersPage(){
    this.authForm=false;
  }
}
