import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UmProfileComponent } from './um-profile.component';

describe('UmProfileComponent', () => {
  let component: UmProfileComponent;
  let fixture: ComponentFixture<UmProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UmProfileComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UmProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
