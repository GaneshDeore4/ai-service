import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CompanyUser } from '../../../../model/CompanyUser';
import { ApiService } from '../../../../service/apiService/api.service';
import { AUTHORIZE_COMPANY_USER, CREATE_COMPANY_USER } from '../../../../constants/api_endpoints';

@Component({
  selector: 'app-um-profile',
  imports: [FormsModule],
  templateUrl: './um-profile.component.html',
  styleUrl: './um-profile.component.css'
})
export class UmProfileComponent {

  // isLoading = false;
  // role = 'Maker';
  // userModel = new CompanyUser({});

  // constructor(private apiService: ApiService) { }

  // //SEARCH VARAIBLES
  // searchLastName = '';
  // searchFirstName = '';
  // searchLoginId = '';
  // searchSelectedProfileStatus = '';
  // searchProfileStatusList: string[] = ['Active', 'Inactive', 'Lock'];
  // searchStatusList: string[] = ['Awaiting for Approval(D)', 'Awaiting for Approval(M)', 'Awaiting for Approval(N)', 'Checker Returned(D)', 'Checker Returned(M)', 'Checker Returned(N)', 'Draft(M)', 'Draft(N)'];
  // searchSelectedStatus = '';

  // // TABLE TO FORM MAINTENANCE VARAIBLES
  // userForm = false;
  // editUser = false;
  // viewUser = false;
  // editUserIndex = -1;

  // userHeaders = ['First Name', 'Last Name', 'LoginID', 'Profile Status', 'Status', 'Maker', 'Action'];
  // userOgData: any[] = [
  //   {
  //     "First Name": "John",
  //     "Last Name": "Doe",
  //     "LoginID": "johndoe",
  //     "Employee Number": "12345",
  //     "Department": "IT",
  //     "Address": "123 Main St",
  //     "Postal Code": "12345",
  //     "Auth Mode": "Password",
  //     "Time Zone": "Asia/Calcutta",
  //     "Language": "English(UK)",
  //     "Base Currency": "USD",
  //     "Contact Number": "123-456-7890",
  //     "Fax": "123-456-7891",
  //     "email": "dummy@gmail.com",
  //     "Pending Tran Notification": true,
  //     "Auth Level": "A",
  //     "Limit Amount Currency": "USD",
  //     "Limit Amount": "1000",
  //     "Profile Status": "Active",
  //     "Status": "Awaiting for Approval(D)",
  //     "Maker": "John Doe"
  //   },
  //   {
  //     "First Name": "Jane",
  //     "Last Name": "Smith",
  //     "LoginID": "janesmith",
  //     "Employee Number": "54321",
  //     "Department": "HR",
  //     "Address": "456 Oak Ave",
  //     "Postal Code": "54321",
  //     "Auth Mode": "OTP Password",
  //     "Time Zone": "America/Havana",
  //     "Language": "French",
  //     "Base Currency": "EUR",
  //     "Contact Number": "098-765-4321",
  //     "Fax": "098-765-4322",
  //     "email": "jane.smith@example.com",
  //     "Pending Tran Notification": false,
  //     "Auth Level": "B",
  //     "Limit Amount Currency": "EUR",
  //     "Limit Amount": "5000",
  //     "Profile Status": "Inactive",
  //     "Status": "Checker Returned(M)",
  //     "Maker": "Jane Smith"
  //   },
  //   {
  //     "First Name": "Peter",
  //     "Last Name": "Jones",
  //     "LoginID": "peterjones",
  //     "Employee Number": "67890",
  //     "Department": "Finance",
  //     "Address": "789 Pine Ln",
  //     "Postal Code": "67890",
  //     "Auth Mode": "No Re-Autehntication",
  //     "Time Zone": "Asia/Calcutta",
  //     "Language": "Arabic",
  //     "Base Currency": "GBP",
  //     "Contact Number": "111-222-3333",
  //     "Fax": "111-222-3334",
  //     "email": "peter.jones@example.com",
  //     "Pending Tran Notification": true,
  //     "Auth Level": "C",
  //     "Limit Amount Currency": "GBP",
  //     "Limit Amount": "10000",
  //     "Profile Status": "Lock",
  //     "Status": "Draft(N)",
  //     "Maker": "Peter Jones"
  //   }
  // ];
  // userData = [...this.userOgData];
  // searchUserf(): void {
  //   const filtered = this.userOgData.filter(item => {
  //     const matchLastName = this.searchLastName
  //       ? item['Last Name']?.toLowerCase().includes(this.searchLastName.toLowerCase())
  //       : true;

  //     const matchFirstName = this.searchFirstName
  //       ? item['First Name']?.toLowerCase().includes(this.searchFirstName.toLowerCase())
  //       : true;

  //     const matchLoginId = this.searchLoginId
  //       ? item['LoginID']?.toLowerCase().includes(this.searchLoginId.toLowerCase())
  //       : true;

  //     const matchProfileStatus = this.searchSelectedProfileStatus
  //       ? item['Profile Status']?.toLowerCase().includes(this.searchSelectedProfileStatus.toLowerCase())
  //       : true;

  //     const matchStatus = this.searchSelectedStatus
  //       ? item['Status']?.toLowerCase().includes(this.searchSelectedStatus.toLowerCase())
  //       : true;

  //     return matchLastName && matchFirstName && matchLoginId && matchProfileStatus && matchStatus;
  //   });

  //   this.userData = [...filtered];
  // }


  // addUserf() {
  //   // new user model is already formed when exiting used form or opening for 1st time
  //   this.userModel.language='EN';
  //   this.userModel.actvFlag='A';
  //   this.userModel.companyAbbvName='Indusind'; //TODO : how to bring dynamic value? flow?
  //   this.userForm = true;
  // }
  // editUserf(row: any, index: number) {
  //   this.assignValues(row);
  //   this.editUser = true;
  //   this.editUserIndex = index;
  //   this.userForm = true;
  // }
  // viewUserf(row: any, index: number) {
  //   this.assignValues(row);
  //   this.viewUser = true;
  //   this.userForm = true;
  //   this.editUserIndex = -1;
  // }
  // deleteUserf(index: number) {
  //   if (index >= 0 && index < this.userOgData.length) {
  //     this.userOgData.splice(index, 1);
  //   }
  //   this.userData = [...this.userOgData];
  // }
  // replicateUser(row: any) {
  //   this.AuthLevel = row['Auth Level'] || '';
  //   const allRoles = [
  //     'Advice and Notification',
  //     'Alert Maintenance',
  //     'Airway Bill Tracking System',
  //     'Inventory Management',
  //     'Shipment Scheduling',
  //     'Customer Support',
  //     'Compliance Monitoring',
  //     'Risk Assessment',
  //     'Performance Analytics',
  //     'Data Security Management'
  //   ];
  //   this.list2 = row['Roles'] || [];
  //   this.list1 = allRoles.filter(item => !this.list2.includes(item));
  //   this.userForm = true;

  // }
  // assignValues(row: any) {
  //   // this.loginID = row['LoginID'] || '';
  //   // this.firstName = row['First Name'] || '';
  //   // this.lastName = row['Last Name'] || '';
  //   // this.employeeNo = row['Employee Number'] || '';
  //   // this.deparment = row['Department'] || '';
  //   // this.address = row['Address'] || '';
  //   // this.postalCode = row['Postal Code'] || '';
  //   // this.selectedProfileStatus = row['Profile Status'] || 'Active';
  //   // this.selectedTimeZone = row['Time Zone'] || '';
  //   // this.selectedLanguage = row['Language'] || 'English(UK)';
  //   // this.baseCurrency = row['Base Currency'] || '';
  //   // this.contactNumber = row['Contact Number'] || '';
  //   // this.fax = row['Fax'] || '';
  //   // this.email = row['email'] || '';
  //   // this.AuthLevel = row['Auth Level'] || '';

  //   const allRoles = [
  //     'Advice and Notification',
  //     'Alert Maintenance',
  //     'Airway Bill Tracking System',
  //     'Inventory Management',
  //     'Shipment Scheduling',
  //     'Customer Support',
  //     'Compliance Monitoring',
  //     'Risk Assessment',
  //     'Performance Analytics',
  //     'Data Security Management'
  //   ];
  //   this.list2 = row['Roles'] || [];
  //   this.list1 = allRoles.filter(item => !this.list2.includes(item));
  // }


  // // FORM VARAIBLES
  // profileStatusList: { key: String, value: string }[] = [{ key: 'A', value: 'Active' }, { key: 'I', value: 'Inactive' }, { key: 'L', value: 'Lock' }];
  // timeZoneList = ['Asia/Calcutta', 'America/Havana'];
  // langaugeList: { key: string, value: string }[] = [{ key: 'EN', value: 'English(UK)' }, { key: 'ENUSA', value: 'English(USA)' }, { key: 'FR', value: 'French' }, { key: 'AR', value: 'Arabic' }];
  // // TODO : BELOW ARE TAMP VARAIBLES COZ NOT FOUND IN MODEL(INCLUDE ROLE LIST ALSO)
  // authLevelList = ['A', 'B', 'C', 'D'];
  // AuthLevel = '';
  // postalCode='';
  // baseCurrency='';

  // loginIDError = false;
  // firstNameError = false;
  // lastNameError = false;
  // profileStatusError = false;
  // authModeError = false;
  // timeZoneError = false;
  // languageError = false;
  // baseCurrencyError = false;
  // contactNumberError = false;
  // emailError = false;

  // loginIDErrorMsg = '';
  // firstNameErrorMsg = '';
  // lastNameErrorMsg = '';
  // profileStatusErrorMsg = '';
  // authModeErrorMsg = '';
  // timeZoneErrorMsg = '';
  // languageErrorMsg = '';
  // baseCurrencyErrorMsg = '';
  // contactNumberErrorMsg = '';
  // emailErrorMsg = '';

  // // TRANSFER LIST LOGIC (roles list) 
  // list1: string[] = [
  //   'Advice and Notification',
  //   'Alert Maintenance',
  //   'Airway Bill Tracking System',
  //   'Inventory Management',
  //   'Shipment Scheduling',
  //   'Customer Support',
  //   'Compliance Monitoring',
  //   'Risk Assessment',
  //   'Performance Analytics',
  //   'Data Security Management'
  // ];
  // list2: string[] = [];
  // selectedList1: string[] = [];
  // selectedList2: string[] = [];
  // toggleSelection(item: string, list: 'list1' | 'list2') {
  //   if (list === 'list1') {
  //     this.selectedList1.includes(item)
  //       ? this.selectedList1 = this.selectedList1.filter(i => i !== item)
  //       : this.selectedList1.push(item);
  //   } else {
  //     this.selectedList2.includes(item)
  //       ? this.selectedList2 = this.selectedList2.filter(i => i !== item)
  //       : this.selectedList2.push(item);
  //   }
  // }
  // addItems() {
  //   this.list2.push(...this.selectedList1);
  //   this.list1 = this.list1.filter(item => !this.selectedList1.includes(item));
  //   this.selectedList1 = [];
  // }
  // removeItems() {
  //   this.list1.push(...this.selectedList2);
  //   this.list2 = this.list2.filter(item => !this.selectedList2.includes(item));
  //   this.selectedList2 = [];
  // }
  // defaultItems() {
  //   this.list2.push(...this.list1);
  //   this.list1 = [];
  //   this.selectedList1 = [];
  // }



  // saveUser() {
  //   if (!this.validateUser())
  //     return;

  //   this.isLoading = true;
  //   console.log("user data :" + JSON.stringify(this.userModel, null, 2))
  //   this.apiService.sendData(CREATE_COMPANY_USER, this.userModel.toJson()).subscribe({
  //     next: (res) => {
  //       //remember to bring the user object to pass to other screen
  //       console.log("login res : " + JSON.stringify(res, null, 2));
  //       if (res.status == "SUCCESS") {
  //         this.popupText = 'User created successfully';
  //         this.popupVisible = true;
  //         this.toUsersPage();
  //       }
  //       else {
  //         this.popupText = res.description;
  //         this.popupVisible = true;
  //       }

  //     },
  //     error: (err) => {
  //       this.popupText = 'Someting went wrong';
  //       this.popupVisible = true;
  //     },
  //     complete: () => {
  //       this.isLoading = false;
  //     }
  //   });

  //   if (this.editUserIndex === -1) {
  //     // TODO
  //   }


  // }
  // authAction(action: string) {
  //   const data = {
  //     "userId": this.userModel.userId,
  //     "tnxId": this.userModel.tnxId,
  //     "checkerId": "Temp", //TODO WHEN LOGIN IS DONE
  //     "action": action
  //   }
  //   this.isLoading = true;
  //   console.log("user AUTH data :" + JSON.stringify(data, null, 2))
  //   this.apiService.sendData(AUTHORIZE_COMPANY_USER, data).subscribe({
  //     next: (res) => {
  //       if (res.status == "SUCCESS") {
  //         this.popupText = 'User ' + action == 'Approve' ? 'Approved' : action == 'Reject' ? 'Rejected' : 'Returned';
  //         this.popupVisible = true;
  //         this.toUsersPage();
  //       }
  //       else {
  //         this.popupText = res.description;
  //         this.popupVisible = true;
  //       }

  //     },
  //     error: (err) => {
  //       this.popupText = 'Someting went wrong';
  //       this.popupVisible = true;
  //     },
  //     complete: () => {
  //       this.isLoading = false;
  //     }
  //   });

  // }

  // toUsersPage() {
  //   this.userForm = false;
  //   this.editUser = false;
  //   this.viewUser = false;
  //   this.editUserIndex = -1;
  //   this.clearForm();
  // }

  // clearForm(){
  //   this.AuthLevel = '';
  //   this.postalCode='';
  //   this.baseCurrency='';
  //   this.selectedList1 = [];
  //   this.selectedList2=[];
  //   this.list1 = [
  //     'Advice and Notification',
  //     'Alert Maintenance',
  //     'Airway Bill Tracking System',
  //     'Inventory Management',
  //     'Shipment Scheduling',
  //     'Customer Support',
  //     'Compliance Monitoring',
  //     'Risk Assessment',
  //     'Performance Analytics',
  //     'Data Security Management'
  //   ];
  //   this.list2=[];
  //   this.clearError();
  //   this.userModel = new CompanyUser();
  // }
  // clearError(){
  //   this.loginIDError = false;
  //   this.firstNameError = false;
  //   this.lastNameError = false;
  //   this.profileStatusError = false;
  //   this.authModeError = false;
  //   this.timeZoneError = false;
  //   this.languageError = false;
  //   this.baseCurrencyError = false;
  //   this.contactNumberError = false;
  //   this.emailError = false;
  //   this.loginIDErrorMsg = '';
  //   this.firstNameErrorMsg = '';
  //   this.lastNameErrorMsg = '';
  //   this.profileStatusErrorMsg = '';
  //   this.authModeErrorMsg = '';
  //   this.timeZoneErrorMsg = '';
  //   this.languageErrorMsg = '';
  //   this.baseCurrencyErrorMsg = '';
  //   this.contactNumberErrorMsg = '';
  //   this.emailErrorMsg = '';
  // }
  // validateUser(): Boolean {
  //   this.clearError();
  //   let errorCount = 0;
  //   if (!this.userModel.loginId) {
  //     this.loginIDErrorMsg = 'Login id cannot be empty.';
  //     this.loginIDError = true;
  //     errorCount++;
  //   }
  //   if (!this.userModel.firstName) {
  //     this.firstNameErrorMsg = 'First Name cannot be empty.';
  //     this.firstNameError = true;
  //     errorCount++;
  //   }
  //   if (!this.userModel.lastName) {
  //     this.lastNameErrorMsg = 'Last Name cannot be empty.';
  //     this.lastNameError = true;
  //     errorCount++;
  //   }
  //   if (!this.userModel.actvFlag) {
  //     this.profileStatusErrorMsg = 'Please Select a status';
  //     this.profileStatusError = true;
  //     errorCount++;
  //   }
  //   if (!this.userModel.timeZone) {
  //     this.timeZoneErrorMsg = 'Please Select a time zone';
  //     this.timeZoneError = true;
  //     errorCount++;
  //   }
  //   if (!this.userModel.language) {
  //     this.languageErrorMsg = 'Please Select a language';
  //     this.languageError = true;
  //     errorCount++;
  //   }
  //   if (!this.userModel.curCode) {
  //     this.baseCurrencyErrorMsg = 'Please Select a Currency';
  //     this.baseCurrencyError = true;
  //     errorCount++;
  //   }
  //   if (!this.userModel.telephoneNumber) {
  //     this.contactNumberErrorMsg = 'Telephone Number cannot be empty.';
  //     this.contactNumberError = true;
  //     errorCount++;
  //   }
  //   else if (this.userModel.telephoneNumber?.length != 10) {
  //     this.contactNumberErrorMsg = 'Please Enter a valid Contact nunmber';
  //     this.contactNumberError = true;
  //     errorCount++;
  //   }

  //   const STRICT_EMAIL_REGEX =
  //     /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@(?:A-Za-z0-9?\.)+[A-Za-z]{2,63}$/;
  //   if (!this.userModel.email) {
  //     this.emailErrorMsg = 'Email cannot be empty';
  //     this.emailError = true;
  //     errorCount++;
  //   }
  //   else if (!STRICT_EMAIL_REGEX.test(this.userModel.email)) {
  //     this.emailErrorMsg = 'Invalid Email';
  //     this.emailError = true;
  //     errorCount++;
  //   }
  //   if (errorCount > 0)
  //     return false;
  //   return true;
  // }

  // // POPUP VARIABLES
  // popupVisible = false;
  // popupText = '';
  // hidePopup() {
  //   this.popupVisible = false;
  //   this.popupText = '';
  // }

}
