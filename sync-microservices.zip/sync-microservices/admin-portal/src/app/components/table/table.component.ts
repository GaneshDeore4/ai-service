import { Component, Input, Output, EventEmitter } from '@angular/core';

import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';

export type Column = { id: string; label: string; visible: boolean };

interface ViewPair {
  label1: string;

  value1: any;

  label2?: string;

  value2?: any;
}

interface EditPair {
  key1: string;

  label1: string;

  key2?: string;

  label2?: string;
}

type ToastType = 'success' | 'error';

@Component({
  selector: 'app-data-table',

  standalone: true,

  imports: [CommonModule, FormsModule],

  templateUrl: './table.component.html',

  styleUrls: ['./table.component.css'],
})
export class TableComponent {
  @Input() data: any[] = [];

  @Input() columns: Column[] | null = null;

  @Output() rowDeleted = new EventEmitter<any>();

  @Output() rowEdited = new EventEmitter<any>();

  @Output() rowView = new EventEmitter<any>()

  defaultColumns: Column[] = [
    { id: 'channelRef', label: 'Channel Reference', visible: true },

    { id: 'customerRef', label: 'Customer Reference', visible: true },

    { id: 'bankRef', label: 'Bank Reference', visible: true },

    { id: 'status', label: 'Status', visible: true },

    { id: 'issueDate', label: 'Issue Date', visible: true },

    { id: 'applicantName', label: 'Applicant Name', visible: true },

    { id: 'currency', label: 'Currency', visible: true },

    { id: 'amount', label: 'Amount', visible: true },

    { id: 'outstandingAmount', label: 'Outstanding Amount', visible: true },
  ];

  // UI state

  searchQuery = '';

  downloadDropdownOpen = false;

  // columns modal

  showColumnsModal = false;

  modalColumns: Column[] = [];

  draggingIndex: number | null = null;

  // pagination

  rowsPerPageOptions = [5, 10, 25, 50];

  rowsPerPage = 10;

  currentPage = 1;

  // removal animation

  removingRows = new Set<string>();

  removalAnimationMs = 600;

  // delete confirm modal

  confirmVisible = false;

  pendingDeleteKey: string | null = null;

  pendingDeleteLabel: string | null = null;

  pendingDeleteRow: any = null;

  // toast

  toastVisible = false;

  toastHiding = false;

  toastMessage = '';

  toastType: ToastType = 'error'; // default red

  // VIEW modal

  showViewModal = false;

  viewRowData: any | null = null;

  viewFieldPairs: ViewPair[] = [];

  // EDIT modal

  showEditModal = false;

  editModel: any = null;

  editFieldPairs: EditPair[] = [];

  editingOriginalRow: any = null; // <— store original reference

  get activeColumns(): Column[] {
    return this.columns && this.columns.length
      ? this.columns
      : this.defaultColumns;
  }

  get visibleCount(): number {
    return this.activeColumns.filter((c) => c.visible).length;
  }

  getCell(row: any, colId: string): string | number | undefined {
    return row ? row[colId] : undefined;
  }

  get filteredData(): any[] {
    if (!this.searchQuery || !this.searchQuery.trim()) return this.data || [];

    const q = this.searchQuery.toLowerCase().trim();

    const visibleCols = this.activeColumns

      .filter((c) => c.visible)

      .map((c) => c.id);

    return (this.data || []).filter((row) =>
      visibleCols.some((colId) => {
        const v = row[colId];

        return (
          v !== null && v !== undefined && String(v).toLowerCase().includes(q)
        );
      })
    );
  }

  get totalItems(): number {
    return this.filteredData.length;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalItems / this.rowsPerPage));
  }

  get pagedData(): any[] {
    if (this.currentPage > this.totalPages) this.currentPage = this.totalPages;

    if (this.currentPage < 1) this.currentPage = 1;

    const start = (this.currentPage - 1) * this.rowsPerPage;

    return this.filteredData.slice(start, start + this.rowsPerPage);
  }

  get startItem(): number {
    if (this.totalItems === 0) return 0;

    return (this.currentPage - 1) * this.rowsPerPage + 1;
  }

  get endItem(): number {
    return Math.min(this.currentPage * this.rowsPerPage, this.totalItems);
  }

  onSearchChange() {
    this.currentPage = 1;
  }

  onRowsPerPageChange(newVal: number) {
    this.rowsPerPage = Number(newVal) || 10;

    this.currentPage = 1;
  }

  setPage(n: number) {
    if (n < 1) n = 1;

    if (n > this.totalPages) n = this.totalPages;

    this.currentPage = n;
  }

  nextPage() {
    this.setPage(this.currentPage + 1);
  }

  prevPage() {
    this.setPage(this.currentPage - 1);
  }

  firstPage() {
    this.setPage(1);
  }

  lastPage() {
    this.setPage(this.totalPages);
  }

  get pageRange(): number[] {
    const total = this.totalPages;

    const current = this.currentPage;

    const window = 5;

    const half = Math.floor(window / 2);

    let start = Math.max(1, current - half);

    let end = Math.min(total, current + half);

    if (end - start + 1 < window) {
      if (start === 1) end = Math.min(total, start + window - 1);
      else if (end === total) start = Math.max(1, end - window + 1);
    }

    const pages: number[] = [];

    for (let i = start; i <= end; i++) pages.push(i);

    return pages;
  }

  /* Columns modal */

  openColumnsModal() {
    this.modalColumns = this.activeColumns.map((c) => ({ ...c }));

    this.showColumnsModal = true;
  }

  applyColumnsChanges() {
    if (this.columns && this.columns.length) {
      this.columns = this.modalColumns.map((c) => ({ ...c }));
    } else {
      this.defaultColumns = this.modalColumns.map((c) => ({ ...c }));
    }

    this.showColumnsModal = false;
  }

  cancelColumnsChanges() {
    this.modalColumns = [];

    this.showColumnsModal = false;
  }

  onDragStart(event: DragEvent, index: number) {
    this.draggingIndex = index;

    if (event.dataTransfer) {
      event.dataTransfer.setData('text/plain', String(index));

      event.dataTransfer.effectAllowed = 'move';
    }
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();

    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  }

  onDrop(event: DragEvent, dropIndex: number) {
    event.preventDefault();

    const fromIndexStr = event.dataTransfer
      ? event.dataTransfer.getData('text/plain')
      : null;

    const fromIndex = fromIndexStr ? Number(fromIndexStr) : this.draggingIndex;

    if (fromIndex == null || isNaN(fromIndex)) return;

    if (fromIndex === dropIndex) return;

    const cols = [...this.modalColumns];

    const [moved] = cols.splice(fromIndex, 1);

    cols.splice(dropIndex, 0, moved);

    this.modalColumns = cols;

    this.draggingIndex = null;
  }

  /* Download */

  toggleDownloadDropdown() {
    this.downloadDropdownOpen = !this.downloadDropdownOpen;
  }

  onDownload(format: 'pdf' | 'excel' | 'csv') {
    this.downloadDropdownOpen = false;

    alert(`Download ${format.toUpperCase()} (demo)`);
  }

  /* VIEW */

  // viewRow(row: any) {
  //   if (!row) return;

  //   this.viewRowData = row;

  //   const visibleCols = this.activeColumns.filter((c) => c.visible);

  //   const pairs: ViewPair[] = [];

  //   for (let i = 0; i < visibleCols.length; i += 2) {
  //     const c1 = visibleCols[i];

  //     const c2 = visibleCols[i + 1];

  //     const pair: ViewPair = {
  //       label1: c1.label,

  //       value1: row[c1.id],
  //     };

  //     if (c2) {
  //       pair.label2 = c2.label;

  //       pair.value2 = row[c2.id];
  //     }

  //     pairs.push(pair);
  //   }

  //   this.viewFieldPairs = pairs;

  //   this.showViewModal = true;
  // }

  closeViewModal() {
    this.showViewModal = false;

    this.viewRowData = null;

    this.viewFieldPairs = [];
  }

  /* EDIT */

  // editRow(row: any) {
  //   if (!row) return;

  //   this.editingOriginalRow = row; // keep reference to the original

  //   this.editModel = { ...row }; // editable copy

  //   const visibleCols = this.activeColumns.filter((c) => c.visible);

  //   const pairs: EditPair[] = [];

  //   for (let i = 0; i < visibleCols.length; i += 2) {
  //     const c1 = visibleCols[i];

  //     const c2 = visibleCols[i + 1];

  //     const pair: EditPair = {
  //       key1: c1.id,

  //       label1: c1.label,
  //     };

  //     if (c2) {
  //       pair.key2 = c2.id;

  //       pair.label2 = c2.label;
  //     }

  //     pairs.push(pair);
  //   }

  //   this.editFieldPairs = pairs;

  //   this.showEditModal = true;
  // }


  editRow(row: any){
    this.rowEdited.emit(row)
  }
  viewRow(row: any){
    this.rowView.emit(row)
  }

  cancelEdit() {
    this.showEditModal = false;

    this.editModel = null;

    this.editFieldPairs = [];

    this.editingOriginalRow = null;
  }

  saveEdit() {
    if (!this.editModel || !this.data) return;

    // update local table data

    this.data = this.data.map((r) =>
      r === this.editingOriginalRow ? { ...this.editModel } : r
    );

    // emit updated row to parent

    this.rowEdited.emit({
      oldRow: this.editingOriginalRow,

      newRow: { ...this.editModel },
    });

    this.showToast('Row updated', 'success');

    this.cancelEdit();
  }

  /* Row key helper (still used for delete) */

  getRowKey(row: any): string {
    return (
      row?.channelRef ??
      row?.channelReference ??
      row?.customerRef ??
      JSON.stringify(row)
    ).toString();
  }

  /* Removing animation helper */

  isRemoving(row: any): boolean {
    return this.removingRows.has(this.getRowKey(row));
  }

  /* Delete flow */

  requestDelete(row: any) {
    this.pendingDeleteKey = this.getRowKey(row);

    const visibleCols = this.activeColumns.filter((c) => c.visible);

    const firstKey = visibleCols.length ? visibleCols[0].id : null;

    this.pendingDeleteLabel =
      firstKey && row[firstKey] ? row[firstKey] : this.getRowKey(row);

    this.pendingDeleteRow = row;

    this.confirmVisible = true;
  }

  cancelDelete() {
    this.pendingDeleteKey = null;

    this.pendingDeleteLabel = null;

    this.pendingDeleteRow = null;

    this.confirmVisible = false;
  }

  confirmDelete() {
    if (!this.pendingDeleteKey) {
      this.confirmVisible = false;

      return;
    }

    const key = this.pendingDeleteKey;

    const rowToDelete = this.pendingDeleteRow;

    this.pendingDeleteKey = null;

    this.pendingDeleteLabel = null;

    this.pendingDeleteRow = null;

    this.confirmVisible = false;

    this.removingRows.add(key);

    setTimeout(() => {
      this.data = (this.data || []).filter((r) => this.getRowKey(r) !== key);

      this.removingRows.delete(key);

      if (rowToDelete) {
        this.rowDeleted.emit(rowToDelete);
      }

      this.showToast('Deleted', 'error'); // red toast

      if (this.currentPage > this.totalPages) {
        this.currentPage = this.totalPages;
      }
    }, this.removalAnimationMs);
  }

  /* Toast */

  showToast(message: string, type: ToastType = 'error', duration = 2000) {
    this.toastMessage = message;

    this.toastType = type;

    this.toastVisible = true;

    this.toastHiding = false;

    setTimeout(() => {
      this.toastHiding = true;

      setTimeout(() => {
        this.toastVisible = false;

        this.toastHiding = false;
      }, 220);
    }, duration);
  }

  deleteRow(row: any) {
    this.requestDelete(row);
  }
}
