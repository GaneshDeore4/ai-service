import { Component, EventEmitter, Input, Output } from '@angular/core';

import { NgFor } from '@angular/common';

export interface LcTab {
  name: string;

  count: number;
}

@Component({
  selector: 'app-lc-tabs',

  standalone: true,

  imports: [NgFor],

  templateUrl: './tabs.component.html',

  styleUrls: ['./tabs.component.css'],
})
export class TabsComponent {
  @Input() tabs: LcTab[] = [];

  @Input() activeTab: string = '';
  @Output() activeTabChange = new EventEmitter<string>();

  onTabClick(tabName: string) {
    this.activeTab = tabName;

    this.activeTabChange.emit(tabName);
  }
}
