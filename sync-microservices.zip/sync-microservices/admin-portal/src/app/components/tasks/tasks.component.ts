import { Component, EventEmitter, Input, Output } from '@angular/core';

import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';

interface TaskModel {
  title: string;

  description: string;

  notifyIssuer: boolean;

  assignee: string;

  notifyAssignee: boolean;

  assignToBank: boolean;

  createdAt?: Date;

  type?: 'self' | 'public' | 'assign';
}

@Component({
  selector: 'app-lc-tasks',

  standalone: true,

  imports: [CommonModule, FormsModule],

  templateUrl: './tasks.component.html',

  styleUrls: ['./tasks.component.css'],
})
export class TasksComponent {
  @Input() showTasks = true;

  @Output() hideTasks = new EventEmitter<void>();

  tasks: TaskModel[] = [];

  showTaskModal = false;

  taskType: 'self' | 'public' | 'assign' = 'self';

  taskModel: TaskModel = {
    title: '',

    description: '',

    notifyIssuer: false,

    assignee: '',

    notifyAssignee: false,

    assignToBank: false,
  };

  editingTaskIndex: number | null = null;

  openCreateTask() {
    this.taskType = 'self';

    this.editingTaskIndex = null;

    this.taskModel = {
      title: '',

      description: '',

      notifyIssuer: false,

      assignee: '',

      notifyAssignee: false,

      assignToBank: false,
    };

    this.showTaskModal = true;
  }

  editTask(index: number) {
    const t = this.tasks[index];

    this.editingTaskIndex = index;

    this.taskType = (t.type as any) || 'self';

    this.taskModel = {
      title: t.title,

      description: t.description,

      notifyIssuer: t.notifyIssuer,

      assignee: t.assignee,

      notifyAssignee: t.notifyAssignee,

      assignToBank: t.assignToBank,

      createdAt: t.createdAt,

      type: this.taskType,
    };

    this.showTaskModal = true;
  }

  cancelTask() {
    this.showTaskModal = false;
  }

  saveTask() {
    if (!this.taskModel.title || !this.taskModel.description) {
      return;
    }

    if (this.editingTaskIndex !== null) {
      const existing = this.tasks[this.editingTaskIndex];

      this.tasks[this.editingTaskIndex] = {
        ...existing,

        ...this.taskModel,

        type: this.taskType,

        createdAt: existing.createdAt || new Date(),
      };
    } else {
      const payload: TaskModel = {
        type: this.taskType,

        ...this.taskModel,

        createdAt: new Date(),
      };

      this.tasks.push(payload);
    }

    this.showTaskModal = false;
  }

  onCloseSidebar() {
    this.hideTasks.emit();
  }
}
