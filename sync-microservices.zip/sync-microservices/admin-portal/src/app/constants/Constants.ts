export const COMPANY_CATERGORY_ID = 1;
export const BANK_CATERGORY_ID = 2;
export const COMPANY_CATERGORY_NAME = 'Client';
export const BANK_CATERGORY_NAME = 'Bank';

// ROLES
export const SUPERADMIN = 'Super Admin';
export const MIDOFFICE = 'MIDOFFICE';

export const CLIENTMC = "Client (M=C)";
export const CLIENTMAKER = "Client Maker";
export const CLIENTCHECKER = "Client Checker";
export const CLIENTVERIFIER = "Client Verifier";
export const CLIENTRELEASER = "Client Releaser";
export const CLIENTVIEW = "Client View";
export const BANKSUPERADMINMAKER = "Bank Super Admin Maker";
export const BANKSUPERADMINCHECKER = "Bank Super Admin Checker";
export const BANKSETUPMAKER = "Bank Setup Maker";
export const BANKSETUPCHECKER = "Bank Setup Checker";
export const BANKVIEWONLY = "Bank View Only";
export const BANKBRANCHVERIFIER = "Bank Branch Verifier";

// pagination variable
export const PAGE_SIZE = 10;


// FD AND MIDOFFICE FD STATUSES
export const PENDING_AT_MID_OFFICE = 'PENDING_AT_MID_OFFICE';
export const IN_APPROVAL = 'IN_APPROVAL';
export const REJECTED = 'REJECTED';
export const MID_OFFICE_REJECTED = 'MID_OFFICE_REJECTED';
export const MID_OFFICE_APPROVED = 'MID_OFFICE_APPROVED';
export const APPROVED = 'APPROVED';
// Session Configurations (in milliseconds)
export const SESSION_TIMEOUT = 5 * 60 * 1000;  // 5 Minutes
export const WARNING_DURATION = 2 * 60 * 1000; // 2 Minutes (Grace Period)
