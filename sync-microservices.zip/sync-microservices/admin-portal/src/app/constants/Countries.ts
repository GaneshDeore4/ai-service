

export interface CountryInfo {
  countryName: string;
  currencyCode: string; // ISO 4217 (may be empty for territories without a legal tender)
  flagCode: string;     // ISO 3166-1 alpha-2, lowercase (for flagcdn)
  countryCode: string;  // ISO 3166-1 alpha-2, uppercase
  currencyName:string;
}

export const COUNTRIES_DATA: CountryInfo[] = [

  { countryName: 'Australia', currencyCode: 'AUD', flagCode: 'au', countryCode: 'AU' , currencyName:'Australian Dollar'},
  { countryName: 'Canada', currencyCode: 'CAD', flagCode: 'ca', countryCode: 'CA', currencyName:'Canadian Dollar'},
  { countryName: 'China (Offshore)', currencyCode: 'CNH', flagCode: 'cn', countryCode: 'CN' , currencyName:'Chinese Yuan Offshore Renminbi'},
  { countryName: 'Denmark', currencyCode: 'DKK', flagCode: 'dk', countryCode: 'DK',currencyName:'Danish Krone'},
  { countryName: 'Hong Kong', currencyCode: 'HKD', flagCode: 'hk', countryCode: 'HK', currencyName:'Hong Kong Dollar'},
  { countryName: 'Japan', currencyCode: 'JPY', flagCode: 'jp', countryCode: 'JP', currencyName:'Japanese Yen'},
  { countryName: 'Eurozone / European Union', currencyCode: 'EUR', flagCode: 'lu', countryCode: 'GBP',currencyName:'Euro' },
  { countryName: 'New Zealand', currencyCode: 'NZD', flagCode: 'nz', countryCode: 'NZ', currencyName:'New Zealand Dollar'},
  { countryName: 'Norway', currencyCode: 'NOK', flagCode: 'no', countryCode: 'NO', currencyName:'Norwegian Krone'},
  { countryName: 'Qatar', currencyCode: 'QAR', flagCode: 'qa', countryCode: 'QA', currencyName:'Qatari Riyal' },
  { countryName: 'Saudi Arabia', currencyCode: 'SAR', flagCode: 'sa', countryCode: 'SA', currencyName:'Saudi Riyal'},
  { countryName: 'Singapore', currencyCode: 'SGD', flagCode: 'sg', countryCode: 'SG', currencyName:'Singapore Dollar' },
  { countryName: 'Sweden', currencyCode: 'SEK', flagCode: 'se', countryCode: 'SE',currencyName:'Swedish Krona' },
  { countryName: 'Switzerland', currencyCode: 'CHF', flagCode: 'ch', countryCode: 'CH', currencyName:'Swiss Franc'},
  { countryName: 'United Arab Emirates', currencyCode: 'AED', flagCode: 'ae', countryCode: 'AE' , currencyName:'UAE Dirham'},
  { countryName: 'United Kingdom', currencyCode: 'GBP', flagCode: 'gb', countryCode: 'GB',currencyName:'Pound Sterling'},
  { countryName: 'United States', currencyCode: 'USD', flagCode: 'us', countryCode: 'US', currencyName:'US Dollar'},
  {countryName:'South Africa', currencyCode:'ZAR', flagCode:'za', countryCode:'ZA', currencyName:'South African Rand'}

]

export default COUNTRIES_DATA;
