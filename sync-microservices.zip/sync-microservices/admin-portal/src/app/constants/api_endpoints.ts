// Backend URL is injected at container start by nginx-env-entrypoint.sh into
// `/env.js` (loaded by index.html before this bundle). Override per environment
// via Helm: `env.API_URL` in values.yaml. Falls back to the dev gateway when
// running with `ng serve` locally (no env.js loaded).

// const API_URL: string =
//   (typeof window !== 'undefined' && (window as any).API_URL) ||
//   'http://13.234.138.233/';

const BASE_URL_AUTH = 'http://localhost:8080/';
const BASE_URL = 'http://localhost:8080/';

// const API_URL: string =
//   (typeof window !== 'undefined' && (window as any).API_URL) ||
//   'https://api-giftcity-dev.trusthub.in';

// const BASE_URL_AUTH = API_URL.replace(/\/?$/, '/');
// const BASE_URL = BASE_URL_AUTH;



// LOGIN/LOGOUT URL
export const LOGIN_URL = BASE_URL_AUTH + 'api/auth/bank/bankLogin';
export const FORCE_LOGOUT = BASE_URL_AUTH + 'api/auth/logout/force';
export const FORGOT_PASSWORD =
  BASE_URL_AUTH + 'api/auth/bank/resetBankUserPassword';
export const MIDDLE_OFFICE_COUNT =
  BASE_URL_AUTH + 'api/mid-office/dashboard';
export const RELID_APPROVE =
  BASE_URL_AUTH + 'api/auth/bank/relid';



// COMPANY USER
export const CREATE_COMPANY_USER = BASE_URL + 'api/user/submitUser';
export const AUTHORIZE_COMPANY_USER = BASE_URL + 'api/user/authoriseUser';
export const GET_USER_BY_COMPANY_ID = BASE_URL + 'api/user/getUsersByCompanyId';
export const GET_TEMP_USER_BY_COMPANY_ID =
  BASE_URL + 'api/user/getTempUsersByCompanyId';
export const GET_ALL_TEMP_USERS =
  BASE_URL + 'api/user/getAllTempUsers';
export const APPROVE_USER = BASE_URL + 'api/user/approveUser';
export const REJECT_USER = BASE_URL + 'api/user/rejectUser';
export const GET_TEMP_USER_BY_ID = BASE_URL + 'api/user/getTempUserById';
export const GET_PRO_SUBPRO_MAP_BY_COMPANY_ID =
  BASE_URL + 'api/company/getProdSubProdMapByCompanyTemp';

// COMPANY
export const CREATE_COMPANY = BASE_URL + 'api/company/saveCompanyDetails';
export const AUTHORIZE_COMPANY = BASE_URL + 'api/company/authoriseCompany';
export const GET_ALL_TEMP_COMPANIES =
  BASE_URL + 'api/company/getAllTempCompanies';
export const GET_ALL_COMPANIES = BASE_URL + 'api/company/getAllCompanies';
export const GET_ALL_TEMP_COMPANY_BY_ID =
  BASE_URL + 'api/company/getCompanyTempById';
export const GET_ALL_TXN_COMPANIES =
  BASE_URL + 'api/company/getAllTnxCompanies';
export const APPROVE_COMPANY = BASE_URL + 'api/company/approveCompany';
export const REJECT_COMPANY = BASE_URL + 'api/company/rejectCompany';
export const GET_PRODUCTS_BY_COMPANY_ID =
  BASE_URL + 'api/company/getProductsByCompanyId';
export const PRE_EXISTING_COMPANY_DETAILS_BY_CIF =
  BASE_URL + 'api/company/fetchCompanyByCif';

// ROLE
export const GET_ALL_TXN_ROLE = BASE_URL + 'api/role/getTempRoleList';
export const GET_ALL_ROLE = BASE_URL + 'api/role/getRoleList';
export const CREATE_ROLE = BASE_URL + 'api/role/saveOrSubmitRoleTemp';
export const EDIT_ROLE = BASE_URL + 'api/role/editRole';
export const AUTHORISE_ROLE = BASE_URL + '/api/company/authoriseCompany';

// ROLE MASTER
export const GET_ALL_MASTER_ROLE = BASE_URL + 'api/role/getTempRoleList';
export const CREATE_MASTER_ROLE = BASE_URL + 'api/role/saveOrSubmitRoleTemp';
export const EDIT_MASTER_ROLE = BASE_URL + 'api/role/editRole';
export const DELETE_MASTER_ROLE = BASE_URL + 'api/company/authoriseCompany';

//CATEGORY MASTER
export const GET_ALL_CATEGORY = BASE_URL + 'api/category/getAllCategories';
export const CREATE_MASTER_CATEGORY = BASE_URL + 'api/category/saveCategory';
export const EDIT_MASTER_CATEGORY = BASE_URL + 'api/category/updateCategory';
export const DELETE_MASTER_CATEGORY = BASE_URL + 'api/category/deleteCategory';
export const GET_PRODUCTS_CATEGORY_ID =
  BASE_URL + 'api/category/getProductsByCategoryId';
export const GET_PRODUCTS_BY_CATEGORY_ID =
  BASE_URL + 'api/category/getProductsByCategoryId';
export const GET_CATEGORY_BY_CATEGORY_NAME =
  BASE_URL + 'api/category/getCategoryByName';

//USER TYPE MASTER
export const GET_ALL_USERTYPE = BASE_URL + 'api/userType/getAllUserTypes';
export const GET_USERTYPE_BY_ID = BASE_URL + 'api/userType/getUserType';
export const CREATE_MASTER_USERTYPE = BASE_URL + 'api/userType/saveUserType';
export const CREATE_All_TEMP_USERTYPE = BASE_URL + 'api/userType/getAllTempUserTypes';
export const EDIT_MASTER_USERTYPE = BASE_URL + 'api/userType/updateUserType';
export const DELETE_MASTER_USERTYPE = BASE_URL + 'api/userType/deleteUserType';
export const APPROVE_USER_TYPE = BASE_URL + 'api/userType/approveUserType';
export const REJECT_USER_TYPE = BASE_URL + 'api/userType/rejectUserType';
export const GET_USER_TYPE_BY_CATEGORY_ID =
  BASE_URL + 'api/category/getUserTypeByCategoryId';
export const GET_USER_TYPE_BY_CATEGORY =
  BASE_URL + 'api/category/getUserTypeByCategory';
export const GET_CATEGORY_BY_ID = BASE_URL + 'api/category/getCategory';

// PRODUCT MASTER
export const GET_ALL_MASTER_PRODUCT = BASE_URL + 'api/product/getAllProducts';
export const GET_ALL_TEMP_MASTER_PRODUCT = BASE_URL + 'api/product/getAllTempProducts';
export const CREATE_MASTER_PRODUCT = BASE_URL + 'api/product/saveProduct';
export const EDIT_MASTER_PRODUCT = BASE_URL + 'api/product/updateProduct';
export const DELETE_MASTER_PRODUCT = BASE_URL + 'api/product/deleteProduct';
export const GET_PRO_SUBPRO_MAP_BY_CATEGORY_ID =
  BASE_URL + 'api/product/getProdSubProdMapByCategoryId';
export const APPROVE_PRODUCT =
  BASE_URL + 'api/product/approveProduct';
export const REJECT_PRODUCT =
  BASE_URL + 'api/product/rejectProduct';

// SUB PRODUCT MASTER
export const GET_ALL_MASTER_SUBPRODUCT =
  BASE_URL + 'api/subproduct/getAllSubProducts';
export const GET_ALL_TEMP_SUBPRODUCT =
  BASE_URL + 'api/subproduct/getAllSubProductsTemp';
export const CREATE_MASTER_SUBPRODUCT =
  BASE_URL + 'api/subproduct/saveSubProduct';
export const EDIT_MASTER_SUBPRODUCT =
  BASE_URL + 'api/subproduct/updateSubProduct';
export const DELETE_MASTER_SUBPRODUCT =
  BASE_URL + 'api/subproduct/deleteSubProduct';
export const GET_ALL_SUBPRO_BY_PRO_LIST =
  BASE_URL + 'api/product/getSubProductsByProductList';
export const GET_ALL_SUB_PRODUCTS =
  BASE_URL + 'api/subproduct/getAllSubProducts/all';
export const GET_SUBPRODUCTS_BY_PRODUCT_ID =
  BASE_URL + 'api/product/getSubProductsByProductId';
export const GET_SUBPRODUCT_BY_ID =
  BASE_URL + 'api/subproduct/getSubProduct';
export const REJECT_SUBPRODUCT =
  BASE_URL + 'api/subproduct/reject';
export const APPROVE_SUBPRODUCT =
  BASE_URL + 'api/subproduct/approve';


// ACTION MASTER
export const GET_ALL_MASTER_ACTION = BASE_URL + 'api/action/getAllActions';
export const GET_ALL_TEMP_ACTION = BASE_URL + 'api/action/getAllTempActions';
export const CREATE_MASTER_ACTION = BASE_URL + 'api/action/saveAction';
export const EDIT_MASTER_ACTION = BASE_URL + 'api/action/updateAction';
export const GET_ACTION_BY_PRODUCT_ID =
  BASE_URL + 'api/product/getActionsByProductId';
export const GET_ACTION_BY_PRODUCT_ID_OR_SUB_PRODUCT_ID =
  BASE_URL + 'api/action/getActionsByProdIdOrSubProdId';
export const REJECT_ACTION =
  BASE_URL + 'api/action/reject';
export const APPROVE_ACTION =
  BASE_URL + 'api/action/approve';

// TAB MASTER
export const GET_ALL_MASTER_TAB = BASE_URL + 'api/master/getAllTabs';
export const GET_ALL_TEMP_TAB = BASE_URL + 'api/master/getAllTabsTemp';
export const APPROVE_TAB = BASE_URL + 'api/master/approveTab';
export const REJECT_TAB = BASE_URL + 'api/master/rejectTab';
export const CREATE_MASTER_TAB = BASE_URL + 'api/master/addTab';
export const EDIT_MASTER_TAB = BASE_URL + 'api/master/updateTab';
export const GET_TABS_BY_SUBPRODUCT_ID =
  BASE_URL + 'api/subproduct/getTabsBySubProductId';

// ACTION MAPPING MASTER
export const GET_MY_ACCESS = BASE_URL + 'api/usertype-tab-action/myaccess';
export const ADD_ACTION_MAPPING =
  BASE_URL + 'api/usertype-tab-action/addMapping';
export const GET_ACTION_MAPPING =
  BASE_URL + 'api/usertype-tab-action/getMappingByTabIds';
export const GET_ALL_USER_TYPE_MAPPING = BASE_URL + 'api/usertype-tab-action/getAllUserTypeMapping';

//AuthGroup
export const GET_AUTH_GROUPS = BASE_URL + 'api/authGroup/getAuthGroups';

//AuthMatrix
export const ADD_AUTH_MATRIX = BASE_URL + 'api/authMatrix/addAuthMatrix';
export const GET_GROUPED_AUTH_MATRIX =
  BASE_URL + 'api/authMatrix/getAllGroupedAuthMatrixTemp';
export const APPROVE_GROUPED_MATRIX =
  BASE_URL + 'api/authMatrix/approveGroupedAuthMatrix';
export const REJECT_GROUPED_MATRIX =
  BASE_URL + 'api/authMatrix/rejectGroupedAuthMatrix';
export const GET_ALL_AUTH_MATRIX =
  BASE_URL + 'api/authMatrix/getAllAuthMatrixTemp';
export const GET_AUTH_MATRIX_BY_ID =
  BASE_URL + 'api/authMatrix/getAuthMatrixTempById';
export const AUTH_MATRIX_APPROVE =
  BASE_URL + 'api/authMatrix/approveAuthMatrix';
export const AUTH_MATRIX_REJECT = BASE_URL + 'api/authMatrix/rejectAuthMatrix';

export const GET_ALL_DEPARTMENTS =
  BASE_URL + 'api/department/getAllDepartments';
export const GET_DEPARTMENTS_BY_CATEGORY_ID =
  BASE_URL + 'api/department/getDepartmentsByCategoryId';
export const GET_ALL_TEMP_DEPARTMENTS =
  BASE_URL + 'api/department/getAllTempDepartment';
export const ADD_DEPARTMENTS = BASE_URL + 'api/department/createDepartment';
export const APPROVE_DEPARTMENT = BASE_URL + 'api/department/approveDepartment';
export const REJECT_DEPARTMENT = BASE_URL + 'api/department/rejectDepartment';
export const MAP_USER_TYPE = BASE_URL + 'api/department/mapUserType';
export const GET_ALL_NOTIFICATIONS =
  BASE_URL + 'api/notification/getAllNotifications';
export const ADD_NOTIFICATION = BASE_URL + 'api/notification/addNotification';
export const Delete_NOTIFICATION =
  BASE_URL + 'api/notification/deleteNotificationById';
export const APPROVE_NOTIFICATION =
  BASE_URL + 'api/notification/approveNotification';
export const REJECT_NOTIFICATION =
  BASE_URL + 'api/notification/rejectNotification';
export const TOGGLE_NOTIFICATION =
  BASE_URL + 'api/notification/toggleNotification';
export const GET_NOTIFICATION_BY_ID =
  BASE_URL + 'api/notification/getNotificationById';
export const GET_ALL_GUIDELINES = BASE_URL + 'api/guideline/getAllGuidelines';
export const ADD_GUIDELINES = BASE_URL + 'api/guideline/addGuideline';
export const Delete_GUIDELINES = BASE_URL + 'api/guideline/deleteGuidelineById';
export const GET_GUIDELINES_BY_ID = BASE_URL + 'api/guideline/getGuidelineById';
export const APPROVE_GUIDELINES = BASE_URL + 'api/guideline/approveGuideline';
export const REJECT_GUIDELINES = BASE_URL + 'api/guideline/rejectGuideline';
export const TOGGLE_GUIDELINES = BASE_URL + 'api/guideline/toggleGuideline';

// BANK
export const GET_ALL_TEMP_BANK = BASE_URL + 'api/bankprofile/getAllTempBanks';
export const GET_ALL_BANK = BASE_URL + 'api/bankprofile/getAllBanks';
export const GET_TEMP_BANK_BY_ID = BASE_URL + 'api/bankprofile/getBankTempById';
export const SAVE_BANK_PROFILE = BASE_URL + 'api/bankprofile/saveBankProfile';
export const APPROVE_BANK = BASE_URL + 'api/bankprofile/approveBankProfile';
export const REJECT_BANK = BASE_URL + 'api/bankprofile/rejectBankProfile';

//BANK USERS
export const GET_ALL_TEMP_BANK_USERS_BY_BANK_ID =
  BASE_URL + 'api/bankuser/getTempBankUsersByBankProfileId';
export const GET_ALL_TEMP_BANK_USERS =
  BASE_URL + 'api/bankuser/getAllTempBankUsers';
export const GET_TEMP_BANK_USER_BY_ID =
  BASE_URL + 'api/bankuser/getBankUserTempById';
export const SAVE_BANK_USERS = BASE_URL + 'api/bankuser/saveBankUser';
export const APPROVE_BANK_USER = BASE_URL + 'api/bankuser/approveBankUser';
export const REJECT_BANK_USER = BASE_URL + 'api/bankuser/rejectBankUser';
export const GET_BANK_USER_BY_ID = BASE_URL + 'api/bankuser/getBankUserById';
// export const FETCH_PRE_EXISTING_BANK_USER_BY_LOGIN_ID =
//   BASE_URL + 'api/user/getPulseDetailsByPulseId';
export const FETCH_PRE_EXISTING_BANK_USER_BY_LOGIN_ID =
  BASE_URL + 'api/bankuser/getPulseDetailsByPulseId';

// USER ACCOUNT MAPPING
export const GET_ALL_ACCOUNT_BY_CIF =
  BASE_URL + 'api/account_mapping/account-details-cif';
export const SYNC_API = BASE_URL + 'api/accounts/sync';
export const GET_ACCOUNT_BY_CIF = BASE_URL + 'api/accounts/cif';
export const SAVE_USER_ACCOUNT_MAPPING =
  BASE_URL + 'api/account_mapping/user-account-mapping-grouped';

// PRODUCT INTEGRATION
export const SAVE_MID_OFFICE_ACCESS =
  BASE_URL + 'api/product/mapProductToMidOffice';
export const GET_ALL_PRODUCTS_BY_CATEGORY_ID =
  BASE_URL + 'api/product/getAllProductsByCategoryId';



//MID OFFICE 
export const GET_FD_BY_STATUS = BASE_URL + 'api/fd/v2/getFDByStatus';
export const APPROVE_MO_FD = BASE_URL + 'api/fd/v2/approveFdMidOffice';
export const REJECT_MO_FD = BASE_URL + 'api/fd/v2/rejectFdMidOffice';


// OTP
export const SEND_OTP = BASE_URL + 'api/communication/sendBankUserOtp';
export const RESEND_OTP = BASE_URL + 'api/communication/resendBankUserOtp';
export const VALIDATE_OTP = BASE_URL + 'api/communication/confirmBankUserOtp';
export const DASHBOARD_STATS = BASE_URL + 'api/dashboard/stats';
