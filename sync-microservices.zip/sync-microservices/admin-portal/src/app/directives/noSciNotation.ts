import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appNoSciNotation]'
})
export class NoSciNotationDirective {
  private blocked = new Set(['e', 'E', '+', '-']);

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (this.blocked.has(event.key)) {
      event.preventDefault();
    }
  }
}
