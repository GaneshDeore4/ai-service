
export class AddressDto {
  streetName: string | null = null;
  townName: string | null = null;
  countrySubDiv: string | null = null;
  postCode: string | null = null;

  constructor(init?: Partial<AddressDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof AddressDto)[];
    for (const k of keys) {
      if (this[k] === undefined) this[k] = null as any;
    }
  }

  /** Create a DTO from an incoming JSON payload, guaranteeing all keys exist (undefined -> null). */
  static jsonToObject(json: any): AddressDto | null {
    if (!json) return null;
    const dto = new AddressDto();
    dto.streetName = valueOrNull<string>(json?.streetName);
    dto.townName = valueOrNull<string>(json?.townName);
    dto.countrySubDiv = valueOrNull<string>(json?.countrySubDiv);
    dto.postCode = valueOrNull<string>(json?.postCode);
    dto.normalizeNulls();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: AddressDto | null | undefined): Record<string, any> | null {
    if (!dto) return null;
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);
    return {
      streetName: n(dto.streetName),
      townName: n(dto.townName),
      countrySubDiv: n(dto.countrySubDiv),
      postCode: n(dto.postCode),
    };
  }
}

function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}
 function arrayOrNull<T = any>(v: any): (T | null)[] | null {
  if (v === undefined || v === null) return null;
  if (Array.isArray(v)) return v as (T | null)[];
  return null;
}
 function objectOrNull<T = any>(v: any): T | null {
  if (v === undefined || v === null) return null;
  if (typeof v === 'object') return v as T;
  return null;
}