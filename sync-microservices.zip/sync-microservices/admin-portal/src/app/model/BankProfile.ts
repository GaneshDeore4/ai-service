// bank-profile-base.dto.ts

import { AddressDto } from "./Address";
import { SwiftAddressDto } from "./SwiftAddress";


export class BankProfileBaseDto {
  bankProfileId:number| null = null;
  abbvName: string | null = null;
  name: string | null = null;
  addressDto: AddressDto;
  swiftAddress: SwiftAddressDto;
  timeZone: string | null = null;
  corrLanguage: string | null = null;
  baseCurrency: string | null = null;
  contactName: string | null = null;
  contactNumber: string | null = null;
  email: string | null = null;
  status:string | null = null;

  constructor(init?: Partial<BankProfileBaseDto>) {
    if (init) {
      // Destructure to handle nested objects separately
      const { addressDto, swiftAddress, ...rest } = init;
      Object.assign(this, rest);

      // Ensure nested DTOs are always instances, even if the payload has them as null
      this.addressDto = new AddressDto(addressDto);
      this.swiftAddress = new SwiftAddressDto(swiftAddress);
    } else {
      this.addressDto = new AddressDto();
      this.swiftAddress = new SwiftAddressDto();
    }
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  // private normalizeNulls(): void {
  //   const keys = Object.keys(this) as (keyof BankProfileBaseDto)[];
  //   for (const k of keys) {
  //     if (this[k] === undefined) this[k] = null as any;
  //   }
  // }

  /** Create a DTO from an incoming JSON payload, guaranteeing all keys exist (undefined -> null). */
  static jsonToObject(json: any): BankProfileBaseDto {
    const dto = new BankProfileBaseDto();

    dto.bankProfileId = valueOrNull<number>(json?.bankProfileId);
    dto.abbvName = valueOrNull<string>(json?.abbvName);
    dto.name = valueOrNull<string>(json?.name);

    // Nested DTOs
    dto.addressDto = AddressDto.jsonToObject(objectOrNull(json?.addressDto)) ?? new AddressDto();
    dto.swiftAddress = SwiftAddressDto.jsonToObject(objectOrNull(json?.swiftAddress)) ?? new SwiftAddressDto();

    dto.timeZone = valueOrNull<string>(json?.timeZone);
    dto.corrLanguage = valueOrNull<string>(json?.corrLanguage);
    dto.baseCurrency = valueOrNull<string>(json?.baseCurrency);
    dto.contactName = valueOrNull<string>(json?.contactName);
    dto.contactNumber = valueOrNull<string>(json?.contactNumber);
    dto.email = valueOrNull<string>(json?.email);
    dto.status = valueOrNull<string>(json?.status);


    // dto.normalizeNulls();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: BankProfileBaseDto): Record<string, any> {
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);

    return {
      bankProfileId: n(dto.bankProfileId),
      abbvName: n(dto.abbvName),
      name: n(dto.name),
      addressDto: AddressDto.objectToJson(dto.addressDto),
      swiftAddress: SwiftAddressDto.objectToJson(dto.swiftAddress),
      timeZone: n(dto.timeZone),
      corrLanguage: n(dto.corrLanguage),
      baseCurrency: n(dto.baseCurrency),
      contactName: n(dto.contactName),
      contactNumber: n(dto.contactNumber),
      email: n(dto.email),
      status: n(dto.status),
    };
  }
}

function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}
 function arrayOrNull<T = any>(v: any): (T | null)[] | null {
  if (v === undefined || v === null) return null;
  if (Array.isArray(v)) return v as (T | null)[];
  return null;
}
 function objectOrNull<T = any>(v: any): T | null {
  if (v === undefined || v === null) return null;
  if (typeof v === 'object') return v as T;
  return null;
}