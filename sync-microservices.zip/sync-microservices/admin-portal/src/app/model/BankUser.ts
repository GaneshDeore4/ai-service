// bank-user-base.dto.ts

import { OfficeAddressDto } from "./OfficeAddress";

// user-type.enum.ts
export enum UserType {
  ADMIN = 'ADMIN',
  MAKER = 'MAKER',
  CHECKER = 'CHECKER',
  VIEWER = 'VIEWER',
}

export class BankUserDto {
  isUpdate: boolean | null = false;
  bankUserId:number|null=null;
  bankId:number|null=null;
  company: string | null = null;
  loginId: string | null = null;
  firstName: string | null = null;
  lastName: string | null = null;
  employeeNo: string | null = null;
  department: string | null = null;
  otherDept: string | null = null;
  userTypeId:number|null=null;
  officeAddress: OfficeAddressDto | null = null;
  bankUserStatus: string | null = null;
  status: string | null = null;
  timeZone: string | null = null;
  corrLanguage: string | null = null;
  baseCurr: string | null = null; // mirrors Java field name
  solId: string | null = null;
  branchName: string | null = null;
  contactNo: string | null = null;
  email: string | null = null;
  groupEmail: string | null = null;
  contactNoCountryCode: string | null = null
  /**
   * transNotify:
   * - jsonToObject accepts 'Y'/'N', true/false, 'enabled'/'disabled' (any case)
   * - stored as boolean | null for easier UI handling
   * - objectToJson emits 'Y' | 'N' | null to align with Java's String field
   */
  transNotify: boolean | null = null;

  constructor(init?: Partial<BankUserDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof BankUserDto)[];
    for (const k of keys) {
      if (this[k] === undefined) this[k] = null as any;
    }
  }

  /** Create a DTO from an incoming JSON payload, guaranteeing all keys exist (undefined -> null). */
  static jsonToObject(json: any): BankUserDto {
    const dto = new BankUserDto();

    dto.isUpdate=valueOrNull<boolean>(json?.isUpdate);
    dto.bankUserId = valueOrNull<number>(json?.bankUserId);
    dto.bankId = valueOrNull<number>(json?.bankId);
    dto.company = valueOrNull<string>(json?.company);
    dto.loginId = valueOrNull<string>(json?.loginId ?? json?.loginID ?? json?.userLoginId);
    dto.firstName = valueOrNull<string>(json?.firstName);
    dto.lastName = valueOrNull<string>(json?.lastName);
    dto.employeeNo = valueOrNull<string>(json?.employeeNo ?? json?.employeeNumber);
    dto.department = valueOrNull<string>(json?.department);
    dto.otherDept = valueOrNull<string>(json?.otherDept);
    dto.userTypeId = valueOrNull<number>(json?.userTypeId);

    // nested address
    dto.officeAddress = OfficeAddressDto.jsonToObject(objectOrNull(json?.officeAddress));
    dto.status = valueOrNull<string>(json?.status);
    dto.bankUserStatus = valueOrNull<string>(json?.bankUserStatus ?? json?.status);
    dto.timeZone = valueOrNull<string>(json?.timeZone);
    dto.corrLanguage = valueOrNull<string>(json?.corrLanguage ?? json?.correspondenceLanguage);
    dto.baseCurr = valueOrNull<string>(json?.baseCurr ?? json?.baseCurrency ?? json?.baseCurCode);
    dto.solId = valueOrNull<string>(json?.solId ?? json?.solID);
    dto.branchName = valueOrNull<string>(json?.branchName);
    dto.contactNo = valueOrNull<string>(json?.contactNo ?? json?.contactNumber ?? json?.phone);
    dto.contactNoCountryCode = valueOrNull<string>(json?.contactNoCountryCode);
    dto.email = valueOrNull<string>(json?.email);
    dto.groupEmail = valueOrNull<string>(json?.groupEmail ?? json?.groupEmailId ?? json?.groupEmailID);

    dto.transNotify = normalizeToBoolean(json?.transNotify);

    dto.normalizeNulls();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: BankUserDto): Record<string, any> {
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);

    return {
      isUpdate: n(dto.isUpdate),
      bankUserId: n(dto.bankUserId),
      bankId: n(dto.bankId),
      company: n(dto.company),
      loginId: n(dto.loginId),
      firstName: n(dto.firstName),
      lastName: n(dto.lastName),
      employeeNo: n(dto.employeeNo),
      department: n(dto.department),
      otherDept: n(dto.otherDept),
      userTypeId: n(dto.userTypeId),
      officeAddress: OfficeAddressDto.objectToJson(dto.officeAddress),
      status: n(dto.status),
      bankUserStatus: n(dto.bankUserStatus),
      timeZone: n(dto.timeZone),
      corrLanguage: n(dto.corrLanguage),
      baseCurr: n(dto.baseCurr),
      solId: n(dto.solId),
      branchName: n(dto.branchName),
      contactNo: n(dto.contactNo),
      contactNoCountryCode: n(dto.contactNoCountryCode),
      email: n(dto.email),
      groupEmail: n(dto.groupEmail),
      transNotify: n(dto.transNotify)
    };
  }
}

/** Accepts 'Y'/'N', true/false, 'enabled'/'disabled' (any case); otherwise returns null. */
function normalizeToBoolean(v: any): boolean | null {
  if (v === undefined || v === null) return null;
  if (typeof v === 'boolean') return v;
  if (typeof v === 'string') {
    const s = v.trim().toLowerCase();
    if (s === 'y' || s === 'yes' || s === 'true' || s === 'enabled') return true;
    if (s === 'n' || s === 'no' || s === 'false' || s === 'disabled') return false;
  }
  return null;
}

/** Helpers: normalize possibly-undefined values to null with a generic type guard */
export function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}
export function objectOrNull<T = any>(v: any): T | null {
  if (v === undefined || v === null) return null;
  if (typeof v === 'object') return v as T;
  return null;
}