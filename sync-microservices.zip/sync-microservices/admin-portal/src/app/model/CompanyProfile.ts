
import { GTPAccountTnxDto } from "./Account";
import { GTPCompanyObjectTnxDto } from "./CompanyObject";
import { GTPCustomerReferenceTnxDto } from "./CustomerReference";
import { LegalInfoDto } from "./LegalInfoDto";
import { GTPRoleDto } from "./Role";



export type LocalDateTimeString = string | null; // Expect "dd-MM-yyyy hh:mm:ss a" or null
export interface prodLimits{
  productId:number;
  limitAmt:string;
  midOfficeFlag:boolean;
}

export class GTPCompanyTnxDto {
  categoryId?: number | null = null;
  companyId: number | null = null;
  cifId: number | null = null;
  tnxId: string | null = null;
  companyGroup: number | null = null;
  abbvName: string | null = null;
  name: string | null = null;

  // fields for swift start
  addressLine1: string | null = null;
  addressLine2: string | null = null;
  addressLine3: string | null = null;
  isoCode: string | null = null;
  reference: string | null = null;
  strtName: string | null = null;
  buildingNumber: String | null = null;
  buildingName: String | null = null;
  floor: String | null = null;
  room: String | null = null;
  districtName: String | null = null;
  countrySubdivision: string | null = null;
  department: string | null = null;
  subDepartment: string | null = null;
  postalCode: number | null = null;
  swiftTownName: string | null = null
  // fields for swift end
  clientSegment: string | null = null;
  dom: string | null = null;
  country: string | null = null;
  contactName: string | null = null;
  phone: string | null = null;
  fax: string | null = null;
  telex: string | null = null;
  email: string | null = null;
  webAddress: string | null = null;
  timeZone: string | null = null;
  type: string | null = null;
  ownerId: number | null = null;
  language: string | null = null;
  actvFlag: string | null = null;
  baseCurCode: string | null = null;
  makerId: number | null = null;
  checkerId: number | null = null;
  tnxTypeCode: string | null = null;
  tnxStatCode: string | null = null;

  /** Strings expected to be in "dd-MM-yyyy hh:mm:ss a" format or null */
  makerDttm: LocalDateTimeString = null;
  checkerDttm: LocalDateTimeString = null;

  returnComments: string | null = null;
  chargeAccountAddressLine1: string | null = null;
  chargeAccountAddressLine2: string | null = null;
  chargeAccountAddressLine3: string | null = null;
  chargeAccountAddressLine4: string | null = null;
  chargeAccount: string | null = null;
  dualControl: string | null = null;
  passwordExpiry: number | null = null;
  attachmentMaxUploadSize: number | null = null;
  retentionPeriod: number | null = null;
  bei: string | null = null;
  streetName: string | null = null;
  postCode: string | null = null;
  townName: string | null = null;
  countrySubDiv: string | null = null;
  crmEmail: string | null = null;
  legalIdType: string | null = null;
  legalIdNo: string | null = null;
  countryLegalId: string | null = null;
  authorizeOwnTransaction: boolean | null = null;
  bulkAuthorizeLimit: string | null = null;
  autoFwdDate: string | null = null;
  checkFileHashValue: string | null = null;
  checkDuplicateFile: string | null = null;
  checkDuplicateCustRef: string | null = null;
  fileEncryptionMethod: string | null = null;
  rejectFileOnError: string | null = null;
  mergeDemergeAllowed: string | null = null;
  bulkDraftOnError: string | null = null;
  county: string | null = null;
  countryName: string | null = null;
  treasuryBranchReference: string | null = null;

  /** String date-time with same format or null */
  created: LocalDateTimeString = null;

  psmlTemplate: string | null = null;
  liquidityFrequency: string | null = null;
  liquidityBalanceType: string | null = null;
  liquidityCcyCurCode: string | null = null;
  internalChannel: number | null = null;
  rmgroup: string | null = null;
  liquidityBranchReference: string | null = null;
  dashboardScreenType: string | null = null;
  sgi: string | null = null;
  bban: string | null = null;
  selfAdminUserProf: string | null = null;
  selfAdminUserAuthorisation: string | null = null;
  postBox: string | null = null;
  townLocationName: string | null = null;
  leiCode: string | null = null;
  ops: string | null = null;
  isInitialAdminCreateFlag: boolean | null = null;
  customerRefBankName: string | null = null;
  creatorUser: string | null = null;
  prodSubProdMapping: Record<string, string[]> | null = null;
  /** Now using the real AccountDto class type */
  gtpAccountTnxDto: (GTPAccountTnxDto | null)[] | null = null;
  prodLimits: prodLimits[] = [];
  gtpCustomerReferenceTnxDto: (GTPCustomerReferenceTnxDto | null)[] | null = null;
  legalInfoDto: (LegalInfoDto | null)[] | null = null;
  gtpCompanyObjectTnxDto: GTPCompanyObjectTnxDto | null = null;
  roles: (GTPRoleDto | null)[] | null = null;

  constructor(init?: Partial<GTPCompanyTnxDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof GTPCompanyTnxDto)[];
    for (const k of keys) {
      if ((this as any)[k] === undefined) (this as any)[k] = null;
    }
  }

  /** Create a DTO from an incoming JSON payload, guaranteeing all keys exist (undefined -> null). */
  static jsonToObject(json: any): GTPCompanyTnxDto {
    const dto = new GTPCompanyTnxDto();

    dto.companyId = valueOrNull<number>(json?.companyId);
    dto.categoryId = valueOrNull<number>(json?.categoryId);
    dto.cifId = valueOrNull<number>(json?.cifId);
    dto.tnxId = valueOrNull<string>(json?.tnxId);
    dto.companyGroup = valueOrNull<number>(json?.companyGroup);
    dto.abbvName = valueOrNull<string>(json?.abbvName);
    dto.name = valueOrNull<string>(json?.name);
    dto.addressLine1 = valueOrNull<string>(json?.swiftAddress?.addressLine1);
    dto.addressLine2 = valueOrNull<string>(json?.swiftAddress?.addressLine2);
    dto.addressLine3 = valueOrNull<string>(json?.swiftAddress?.addressLine3);
    dto.strtName = valueOrNull<string>(json?.swiftAddress?.streetName);
    dto.buildingNumber = valueOrNull<string>(json?.swiftAddress?.buildingNumber);
    dto.buildingName = valueOrNull<string>(json?.swiftAddress?.buildingName);
    dto.floor = valueOrNull<string>(json?.swiftAddress?.floor);
    dto.room = valueOrNull<string>(json?.swiftAddress?.room);
    dto.districtName = valueOrNull<string>(json?.swiftAddress?.districtName);
    dto.countrySubdivision = valueOrNull<string>(json?.swiftAddress?.countrySubdivision);
    dto.department = valueOrNull<string>(json?.swiftAddress?.department);
    dto.subDepartment = valueOrNull<string>(json?.swiftAddress?.subDepartment);
    dto.postalCode = valueOrNull<number>(json?.swiftAddress?.department);
    dto.swiftTownName = valueOrNull<string>(json?.swiftAddress?.swiftTownName);
    dto.swiftTownName = valueOrNull<string>(json?.swiftAddress?.swiftTownName);
    dto.clientSegment = valueOrNull<string>(json?.clientSegment);
    dto.dom = valueOrNull<string>(json?.dom);
    dto.country = valueOrNull<string>(json?.country);
    dto.contactName = valueOrNull<string>(json?.contactName);
    dto.phone = valueOrNull<string>(json?.phone);
    dto.fax = valueOrNull<string>(json?.fax);
    dto.telex = valueOrNull<string>(json?.telex);
    dto.isoCode = valueOrNull<string>(json?.swiftAddress?.countryCode);
    dto.reference = valueOrNull<string>(json?.swiftAddress?.contactReference);
    dto.email = valueOrNull<string>(json?.email);
    dto.webAddress = valueOrNull<string>(json?.webAddress);
    dto.timeZone = valueOrNull<string>(json?.timeZone);
    dto.type = valueOrNull<string>(json?.type);
    dto.ownerId = valueOrNull<number>(json?.ownerId);
    dto.language = valueOrNull<string>(json?.language);
    dto.actvFlag = json?.controlStatus === 'ACTIVE' ? 'Active' : 'Inactive';
    dto.baseCurCode = valueOrNull<string>(json?.baseCurrency);
    dto.makerId = valueOrNull<number>(json?.makerId);
    dto.checkerId = valueOrNull<number>(json?.checkerId);
    dto.tnxTypeCode = valueOrNull<string>(json?.tnxTypeCode);
    dto.tnxStatCode = valueOrNull<string>(json?.status);

    dto.makerDttm = valueOrNull<string>(json?.makerDttm);
    dto.checkerDttm = valueOrNull<string>(json?.checkerDttm);

    dto.returnComments = valueOrNull<string>(json?.returnComments);
    dto.chargeAccountAddressLine1 = valueOrNull<string>(json?.chargeAccountAddressLine1);
    dto.chargeAccountAddressLine2 = valueOrNull<string>(json?.chargeAccountAddressLine2);
    dto.chargeAccountAddressLine3 = valueOrNull<string>(json?.chargeAccountAddressLine3);
    dto.chargeAccountAddressLine4 = valueOrNull<string>(json?.chargeAccountAddressLine4);
    dto.chargeAccount = valueOrNull<string>(json?.chargeAccount);
    dto.dualControl = json?.dualControl === 'Y' ? 'enabled' : 'disabled';
    dto.passwordExpiry = valueOrNull<number>(json?.passwordExpiry);
    dto.attachmentMaxUploadSize = valueOrNull<number>(json?.attachmentMaxUploadSize);
    dto.retentionPeriod = valueOrNull<number>(json?.retentionPeriod);
    dto.bei = valueOrNull<string>(json?.bei);
    dto.streetName = valueOrNull<string>(json?.addressDto?.streetName);
    dto.postCode = valueOrNull<string>(json?.addressDto?.postCode);
    dto.townName = valueOrNull<string>(json?.addressDto?.townName);
    dto.countrySubDiv = valueOrNull<string>(json?.addressDto?.countrySubDiv);
    dto.crmEmail = valueOrNull<string>(json?.crmEmail);
    dto.legalIdType = valueOrNull<string>(json?.legalIdType);
    dto.legalIdNo = valueOrNull<string>(json?.legalIdNo);
    dto.countryLegalId = valueOrNull<string>(json?.countryLegalId);
    dto.authorizeOwnTransaction = json?.authOwnTransaction === 'Y';
    dto.bulkAuthorizeLimit = valueOrNull<string>(json?.bulkAuthorizeLimit);
    dto.autoFwdDate = valueOrNull<string>(json?.autoFwdDate);
    dto.checkFileHashValue = valueOrNull<string>(json?.checkFileHashValue);
    dto.checkDuplicateFile = valueOrNull<string>(json?.checkDuplicateFile);
    dto.checkDuplicateCustRef = valueOrNull<string>(json?.checkDuplicateCustRef);
    dto.fileEncryptionMethod = valueOrNull<string>(json?.fileEncryptionMethod);
    dto.rejectFileOnError = valueOrNull<string>(json?.rejectFileOnError);
    dto.mergeDemergeAllowed = valueOrNull<string>(json?.mergeDemergeAllowed);
    dto.bulkDraftOnError = valueOrNull<string>(json?.bulkDraftOnError);
    dto.county = valueOrNull<string>(json?.county);
    dto.countryName = valueOrNull<string>(json?.countryName);
    dto.treasuryBranchReference = valueOrNull<string>(json?.treasuryBranchReference);

    dto.created = valueOrNull<string>(json?.created);

    dto.psmlTemplate = valueOrNull<string>(json?.psmlTemplate);
    dto.liquidityFrequency = valueOrNull<string>(json?.liquidityFrequency);
    dto.liquidityBalanceType = valueOrNull<string>(json?.liquidityBalanceType);
    dto.liquidityCcyCurCode = valueOrNull<string>(json?.liquidityCcyCurCode);
    dto.internalChannel = valueOrNull<number>(json?.internalChannel);
    dto.rmgroup = valueOrNull<string>(json?.rmgroup);
    dto.liquidityBranchReference = valueOrNull<string>(json?.liquidityBranchReference);
    dto.dashboardScreenType = valueOrNull<string>(json?.dashboardScreenType);
    dto.sgi = valueOrNull<string>(json?.sgi);
    dto.bban = valueOrNull<string>(json?.bban);
    dto.selfAdminUserProf = valueOrNull<string>(json?.selfAdminUserProf);
    dto.selfAdminUserAuthorisation = valueOrNull<string>(json?.selfAdminUserAuthorisation);
    dto.department = valueOrNull<string>(json?.department);
    dto.subDepartment = valueOrNull<string>(json?.subDepartment);
    dto.buildingNumber = valueOrNull<string>(json?.buildingNumber);
    dto.buildingName = valueOrNull<string>(json?.buildingName);
    dto.floor = valueOrNull<string>(json?.floor);
    dto.postBox = valueOrNull<string>(json?.postBox);
    dto.room = valueOrNull<string>(json?.room);
    dto.townLocationName = valueOrNull<string>(json?.townLocationName);
    dto.districtName = valueOrNull<string>(json?.districtName);
    dto.leiCode = valueOrNull<string>(json?.leiCode);
    dto.ops = valueOrNull<string>(json?.ops);
    dto.isInitialAdminCreateFlag = json?.initialAdmin === 'Y';
    dto.customerRefBankName = valueOrNull<string>(json?.customerRefBankName);
    dto.creatorUser = valueOrNull<string>(json?.creatorUser);
    dto.prodSubProdMapping = valueOrNull<Record<string, string[]>>(json?.prodSubProdMapping);

    // Use the imported AccountDto for array mapping
    dto.gtpAccountTnxDto = Array.isArray(json?.accountDtoList)
      ? (json.accountDtoList.map((x: any) =>
        x ? GTPAccountTnxDto.jsonToObject(x) : null
      ) as (GTPAccountTnxDto | null)[])
      : null;
    
    dto.prodLimits = Array.isArray(json?.prodLimits)
      ? (json.prodLimits.map((x: any) =>
        x ? {
          productId: x.productId,
          limitAmt: x.limitAmt,
          midOfficeFlag: x.midOfficeFlag
        } : null) as prodLimits[])
      : [];




    dto.gtpCustomerReferenceTnxDto = Array.isArray(json?.customerReferenceDtoList)
      ? json.customerReferenceDtoList.map((x: any) => x ? GTPCustomerReferenceTnxDto.jsonToObject(x) : null)
      : null;
    dto.legalInfoDto = Array.isArray(json?.legalIdDetailsDtoList)
      ? json.legalIdDetailsDtoList.map((x: any) => x ? LegalInfoDto.jsonToObject(x) : null)
      : null;
    dto.gtpCompanyObjectTnxDto = objectOrNull<GTPCompanyObjectTnxDto>(json?.gtpCompanyObjectTnxDto);
    dto.roles = arrayOrNull<GTPRoleDto>(json?.roles);

    dto.normalizeNulls();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: GTPCompanyTnxDto): Record<string, any> {
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);

    return {
      companyId: n(dto.companyId),
      categoryId: n(dto.categoryId),
      cifId: n(dto.cifId),
      tnxId: n(dto.tnxId),
      companyGroup: n(dto.companyGroup),
      abbvName: n(dto.abbvName),
      name: n(dto.name),
      addressLine1: n(dto.addressLine1),
      addressLine2: n(dto.addressLine2),
      addressLine3: n(dto.addressLine3),
      strtName: n(dto.strtName),
      buildingNumber: n(dto.buildingNumber),
      buildingName: n(dto.buildingName),
      floor: n(dto.floor),
      room: n(dto.room),
      districtName: n(dto.districtName),
      countrySubdivision: n(dto.countrySubdivision),
      department: n(dto.department),
      subDepartment: n(dto.subDepartment),
      postalCode: n(dto.postalCode),
      swiftTownName: n(dto.swiftTownName),
      clientSegment: n(dto.clientSegment),
      dom: n(dto.dom),
      country: n(dto.country),
      contactName: n(dto.contactName),
      phone: n(dto.phone),
      fax: n(dto.fax),
      telex: n(dto.telex),
      isoCode: n(dto.isoCode),
      reference: n(dto.reference),
      email: n(dto.email),
      webAddress: n(dto.webAddress),
      timeZone: n(dto.timeZone),
      type: n(dto.type),
      ownerId: n(dto.ownerId),
      language: n(dto.language),
      actvFlag: n(dto.actvFlag),
      baseCurCode: n(dto.baseCurCode),
      makerId: n(dto.makerId),
      checkerId: n(dto.checkerId),
      tnxTypeCode: n(dto.tnxTypeCode),
      tnxStatCode: n(dto.tnxStatCode),

      makerDttm: n(dto.makerDttm),
      checkerDttm: n(dto.checkerDttm),

      returnComments: n(dto.returnComments),
      chargeAccountAddressLine1: n(dto.chargeAccountAddressLine1),
      chargeAccountAddressLine2: n(dto.chargeAccountAddressLine2),
      chargeAccountAddressLine3: n(dto.chargeAccountAddressLine3),
      chargeAccountAddressLine4: n(dto.chargeAccountAddressLine4),
      chargeAccount: n(dto.chargeAccount),
      dualControl: n(dto.dualControl),
      passwordExpiry: n(dto.passwordExpiry),
      attachmentMaxUploadSize: n(dto.attachmentMaxUploadSize),
      retentionPeriod: n(dto.retentionPeriod),
      bei: n(dto.bei),
      streetName: n(dto.streetName),
      postCode: n(dto.postCode),
      townName: n(dto.townName),
      countrySubDiv: n(dto.countrySubDiv),
      crmEmail: n(dto.crmEmail),
      legalIdType: n(dto.legalIdType),
      legalIdNo: n(dto.legalIdNo),
      countryLegalId: n(dto.countryLegalId),
      authorizeOwnTransaction:
        dto.authorizeOwnTransaction === true ? 'Y' : dto.authorizeOwnTransaction === false ? 'N' : null,
      bulkAuthorizeLimit: n(dto.bulkAuthorizeLimit),
      autoFwdDate: n(dto.autoFwdDate),
      checkFileHashValue: n(dto.checkFileHashValue),
      checkDuplicateFile: n(dto.checkDuplicateFile),
      checkDuplicateCustRef: n(dto.checkDuplicateCustRef),
      fileEncryptionMethod: n(dto.fileEncryptionMethod),
      rejectFileOnError: n(dto.rejectFileOnError),
      mergeDemergeAllowed: n(dto.mergeDemergeAllowed),
      bulkDraftOnError: n(dto.bulkDraftOnError),
      county: n(dto.county),
      countryName: n(dto.countryName),
      treasuryBranchReference: n(dto.treasuryBranchReference),

      created: n(dto.created),

      psmlTemplate: n(dto.psmlTemplate),
      liquidityFrequency: n(dto.liquidityFrequency),
      liquidityBalanceType: n(dto.liquidityBalanceType),
      liquidityCcyCurCode: n(dto.liquidityCcyCurCode),
      internalChannel: n(dto.internalChannel),
      rmgroup: n(dto.rmgroup),
      liquidityBranchReference: n(dto.liquidityBranchReference),
      dashboardScreenType: n(dto.dashboardScreenType),
      sgi: n(dto.sgi),
      bban: n(dto.bban),
      selfAdminUserProf: n(dto.selfAdminUserProf),
      selfAdminUserAuthorisation: n(dto.selfAdminUserAuthorisation),
      postBox: n(dto.postBox),
      townLocationName: n(dto.townLocationName),
      leiCode: n(dto.leiCode),
      ops: n(dto.ops),
      isInitialAdminCreateFlag: n(dto.isInitialAdminCreateFlag),
      customerRefBankName: n(dto.customerRefBankName),
      creatorUser: n(dto.creatorUser),

      // Map the array of AccountDto to plain JSON using AccountDto.objectToJson
      gtpAccountTnxDto:
        dto.gtpAccountTnxDto === undefined
          ? null
          : (dto.gtpAccountTnxDto
            ? dto.gtpAccountTnxDto.map(a => (a ? GTPAccountTnxDto.objectToJson(a) : null))
            : null),
      prodLimits:
        dto.prodLimits === undefined
          ? null
          : (dto.prodLimits
            ? dto.prodLimits.map(a => (a ? {
                productId: n(a.productId),
                limitAmt: n(a.limitAmt),
                midOfficeFlag: n(a.midOfficeFlag)
              } : null))
            : null),
      gtpCustomerReferenceTnxDto: dto.gtpCustomerReferenceTnxDto === undefined ? null : dto.gtpCustomerReferenceTnxDto,
      legalInfoDto: dto.legalInfoDto === undefined ? null : dto.legalInfoDto,
      gtpCompanyObjectTnxDto: dto.gtpCompanyObjectTnxDto === undefined ? null : dto.gtpCompanyObjectTnxDto,
      roles: dto.roles === undefined ? null : dto.roles
    };
  }
}

/** Helpers: normalize possibly-undefined values to null with a generic type guard */
function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}
function arrayOrNull<T = any>(v: any): (T | null)[] | null {
  if (v === undefined || v === null) return null;
  if (Array.isArray(v)) return v as (T | null)[];
  return null;
}
function objectOrNull<T = any>(v: any): T | null {
  if (v === undefined || v === null) return null;
  if (typeof v === 'object') return v as T;
  return null;
}