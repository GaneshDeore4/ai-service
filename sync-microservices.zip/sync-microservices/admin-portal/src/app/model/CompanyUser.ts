// company-user.model.ts

import { LegalInfoDto } from "./LegalInfoDto";

/**
 * Nested DTO for LegalIdDetails (adjust fields as per your actual LegalIdDetailsDto).
 * This is a minimal scaffold; extend it to match your backend contract.
 */
// export class LegalIdDetailsDto {
//   id?: number | null;
//   legalIdType?: string | null;
//   legalIdNo?: string | null;
//   userId?: number | null;
//   companyId?: number | null;

//   constructor(init?: Partial<LegalIdDetailsDto>) {
//     this.id = init?.id ?? null;
//     this.legalIdType = init?.legalIdType ?? null;
//     this.legalIdNo = init?.legalIdNo ?? null;
//     this.userId = init?.userId ?? null;
//     this.companyId = init?.companyId ?? null;
//   }

//   static fromJson(json: any): LegalIdDetailsDto {
//     if (!json || typeof json !== 'object') {
//       return new LegalIdDetailsDto();
//     }
//     return new LegalIdDetailsDto({
//       id: json.id ?? json.legalIdDetailsId ?? null,
//       legalIdType: json.legalIdType ?? null,
//       legalIdNo: json.legalIdNo ?? null,
//       userId: json.userId ?? null,
//       companyId: json.companyId ?? null,
//     });
//   }

//   toJson(): any {
//     return {
//       id: this.id ?? null,
//       legalIdType: this.legalIdType ?? null,
//       legalIdNo: this.legalIdNo ?? null,
//       userId: this.userId ?? null,
//       companyId: this.companyId ?? null,
//     };
//   }
// }

/**
 * Main model that mirrors your UserDTO.
 * Name: CompanyUser
 */
export class CompanyUser {
  isUpdate?:boolean=false;
  userId?: number | null;
  companyId?: number | null;
  loginId?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  employeeDepartment?: string | null;
  userStatus?: string | null;//Active, Inactive, Lock
  employeeNo?: string | null;
  addressLine1?: string | null;
  addressLine2?: string | null;
  addressLine3?: string | null;
  addressLine4?: string | null;
  addressLine5?: string | null;
  postalCode?: string | null;
  status?: string | null;
  authMode?: string | null;
  timeZone?: string | null;
  corrLanguage?: string | null;
  baseCurr?: string | null;
  contactNo?: string | null;
  email?: string | null;
  pendingTransNotify?: string | null;
  authLevel?: number | null;
  ccy?: string | null;
  limitAmount?: string | null;
  contactNoCountryCode?: string | null;
  /**
   * Map of productId -> list of subProductIds
   */
  productSubProdMap?: Record<string, string[]>;
  productSubProdRespMap?:Record<string, Number[]>;


  userTypeId?: number | null;

  /**
   * Keep date strings as-is to match backend format: 'dd-MM-yyyy hh:mm:ss a'
   * If you prefer Date objects, we can add safe parsers/formatters later.
   */
  createdAt?: string | null;
  createdBy?: string | null;
  modifiedAt?: string | null;
  deletedAt?: string | null;

  legalIdDetailsDtoList: LegalInfoDto[];

  constructor(init?: Partial<CompanyUser>) {
    this.userId = init?.userId ?? null;
    this.companyId = init?.companyId ?? null;
    this.loginId = init?.loginId ?? null;
    this.firstName = init?.firstName ?? null;
    this.lastName = init?.lastName ?? null;
    this.employeeDepartment = init?.employeeDepartment ?? null;
    this.userStatus = init?.userStatus ?? null;
    this.employeeNo = init?.employeeNo ?? null;
    this.addressLine1 = init?.addressLine1 ?? null;
    this.addressLine2 = init?.addressLine2 ?? null;
    this.addressLine3 = init?.addressLine3 ?? null;
    this.addressLine4 = init?.addressLine4 ?? null;
    this.addressLine5 = init?.addressLine5 ?? null;
    this.postalCode = init?.postalCode ?? null;
    this.status = init?.status ?? null;
    this.authMode = init?.authMode ?? null;
    this.timeZone = init?.timeZone ?? null;
    this.corrLanguage = init?.corrLanguage ?? null;
    this.baseCurr = init?.baseCurr ?? null;
    this.contactNo = init?.contactNo ?? null;
    this.email = init?.email ?? null;
    this.pendingTransNotify = init?.pendingTransNotify ?? null;
    this.authLevel = init?.authLevel ?? null;
    this.ccy = init?.ccy ?? null;
    this.limitAmount = init?.limitAmount ?? null;
    this.contactNoCountryCode = init?.contactNoCountryCode ?? null;

    // Ensure a safe empty map by default
    this.productSubProdMap = init?.productSubProdMap ?? {};
    this.productSubProdRespMap = init?.productSubProdRespMap ?? {};

    this.userTypeId = init?.userTypeId ?? null;

    this.createdAt = init?.createdAt ?? null;
    this.createdBy = init?.createdBy ?? null;
    this.modifiedAt = init?.modifiedAt ?? null;
    this.deletedAt = init?.deletedAt ?? null;

    // Always default to [] to avoid undefined issues in templates
    this.legalIdDetailsDtoList = Array.isArray(init?.legalIdDetailsDtoList)
      ? init!.legalIdDetailsDtoList!
      : [];
  }

  /**
   * JSON -> CompanyUser
   */
  static fromJson(json: any): CompanyUser {
    if (!json || typeof json !== 'object') {
      return new CompanyUser();
    }

    // Normalize productSubProdMap: keys might be strings coming from JSON
    const normalizedMap: Record<string, string[]> = {};
    if (json.productSubProdMap && typeof json.productSubProdMap === 'object') {
      Object.keys(json.productSubProdMap).forEach((k) => {
        const keyNum = k;
        const arr = json.productSubProdMap[k];
        normalizedMap[keyNum] = Array.isArray(arr)
          ? arr.map((v: any) => String(v)).filter((v: string) => !String(v))
          : [];
      });
    }

    return new CompanyUser({
      userId: this._num(json.userId),
      isUpdate:false,
      companyId: this._num(json.companyId),
      loginId: this._str(json.loginId),
      firstName: this._str(json.firstName),
      lastName: this._str(json.lastName),
      employeeDepartment: this._str(json.employeeDepartment),
      userStatus: this._str(json.userStatus),
      employeeNo: this._str(json.employeeNo),
      addressLine1: this._str(json.addressLine1),
      addressLine2: this._str(json.addressLine2),
      addressLine3: this._str(json.addressLine3),
      addressLine4: this._str(json.addressLine4),
      addressLine5: this._str(json.addressLine5),
      postalCode: this._str(json.postalCode),
      status: this._str(json.status),
      authMode: this._str(json.authMode),
      timeZone: this._str(json.timeZone),
      corrLanguage: this._str(json.corrLanguage),
      baseCurr: this._str(json.baseCurr),
      contactNo: this._str(json.contactNo),
      email: this._str(json.email),
      pendingTransNotify: this._str(json.pendingTransNotify),
      authLevel: this._num(json.authLevel),
      ccy: this._str(json.ccy),
      contactNoCountryCode: this._str(json.contactNoCountryCode),
      limitAmount: this._str(json.limitAmount),
      productSubProdMap: normalizedMap,
      userTypeId: this._num(json.userTypeId),
      createdAt: this._strOrNull(json.createdAt),
      createdBy: this._strOrNull(json.createdBy),
      modifiedAt: this._strOrNull(json.modifiedAt),
      deletedAt: this._strOrNull(json.deletedAt),
      legalIdDetailsDtoList: Array.isArray(json.legalIdDetailsDtoList)
        ? json.legalIdDetailsDtoList.map((x: any) => LegalInfoDto.jsonToObject(x))
        : [],
    });
  }

  /**
   * CompanyUser -> JSON matching backend DTO
   */
  toJson(): any {
    // Ensure keys are strings in JSON maps (typical JSON serialization)
    const jsonMap: Record<string, Number[]> = {};
    Object.keys(this.productSubProdRespMap ?? {}).forEach((k) => {
      const key = Number(k);
      // Cast through unknown to allow type conversion from string[] to Number[]
      const val = (this.productSubProdRespMap as unknown as Record<string, Number[]>)[k as any] ?? [];
      jsonMap[key] = Array.isArray(val) ? val : [];
    });

    return {
      userId: this.userId ?? null,
      isUpdate:this.isUpdate ?? false,
      companyId: this.companyId ?? null,
      loginId: this.loginId ?? null,
      firstName: this.firstName ?? null,
      lastName: this.lastName ?? null,
      employeeDepartment: this.employeeDepartment ?? null,
      userStatus: this.userStatus ?? null,
      employeeNo: this.employeeNo ?? null,
      addressLine1: this.addressLine1 ?? null,
      addressLine2: this.addressLine2 ?? null,
      addressLine3: this.addressLine3 ?? null,
      addressLine4: this.addressLine4 ?? null,
      addressLine5: this.addressLine5 ?? null,
      postalCode: this.postalCode ?? null,
      status: this.status ?? null,
      authMode: this.authMode ?? null,
      timeZone: this.timeZone ?? null,
      corrLanguage: this.corrLanguage ?? null,
      baseCurr: this.baseCurr ?? null,
      contactNo: this.contactNo ?? null,
      email: this.email ?? null,
      pendingTransNotify: this.pendingTransNotify ?? null,
      authLevel: this.authLevel ?? null,
      ccy: this.ccy ?? null,
      contactNoCountryCode: this.contactNoCountryCode ?? null,
      limitAmount: this.limitAmount ?? null,
      productSubProdRespMap: jsonMap,
      userTypeId: this.userTypeId ?? null,
      createdAt: this.createdAt ?? null,   // keep string as-is
      createdBy: this.createdBy ?? null,   // keep string as-is
      modifiedAt: this.modifiedAt ?? null, // keep string as-is
      deletedAt: this.deletedAt ?? null,   // keep string as-is
      legalIdDetailsDtoList: (this.legalIdDetailsDtoList ?? []).map((x) => LegalInfoDto.objectToJson(x)),
    };
  }

  // ---------- private helpers (type guards / normalizers) ----------
  private static _str(v: any): string | null {
    return v === undefined || v === null ? null : String(v);
    // Keeping empty string if backend allows; else use `|| null`
  }
  private static _strOrNull(v: any): string | null {
    return v === undefined || v === null ? null : String(v);
  }
  private static _num(v: any): number | null {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
}