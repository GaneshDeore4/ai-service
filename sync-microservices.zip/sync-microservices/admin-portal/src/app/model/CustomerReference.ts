/* gtp-customer-reference-tnx.dto.ts
 * Angular DTO matching the backend GTPCustomerReferenceTnxDto.
 * - All properties explicitly exist and default to null (so empty UI fields get sent as null).
 * - jsonToObject(): API JSON -> class instance (ensures undefined -> null).
 * - objectToJson(): class instance -> JSON payload (ensures undefined -> null).
 */

export type LocalDateTimeString = string | null; // Expect "dd-MM-yyyy hh:mm:ss a" or null

export class GTPCustomerReferenceTnxDto {
  customerReferenceId: number | null = null;
  zone: string | null = null;
  solid:number | null=null;
  solDesc: string | null = null;
  customerReference: string | null = null;
  customerDesc:string | null = null;
  reference: string | null = null;
  bankId: number | null = null;
  customerId: number | null = null;
  tnxId: string | null = null;
  brchCode: string | null = null;
  customerAbbvName: string | null = null;
  description: string | null = null;

  backOffice1: string | null = null;
  backOffice2: string | null = null;
  backOffice3: string | null = null;
  backOffice4: string | null = null;
  backOffice5: string | null = null;
  backOffice6: string | null = null;
  backOffice7: string | null = null;
  backOffice8: string | null = null;
  backOffice9: string | null = null;

  makerId: number | null = null;
  checkerId: number | null = null;
  tnxTypeCode: string | null = null;
  tnxStatCode: string | null = null;

  /** Strings expected to be in "dd-MM-yyyy hh:mm:ss a" format or null */
  makerDttm: LocalDateTimeString = null;
  checkerDttm: LocalDateTimeString = null;

  bankAbbvName: string | null = null;
  defaultReference: string | null = null;

  constructor(init?: Partial<GTPCustomerReferenceTnxDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof GTPCustomerReferenceTnxDto)[];
    for (const k of keys) {
      if (this[k] === undefined) this[k] = null;
    }
  }

  /** Build DTO from incoming JSON (ensures missing fields are set to null). */
  static jsonToObject(json: any): GTPCustomerReferenceTnxDto {
    const dto = new GTPCustomerReferenceTnxDto();

    dto.customerReferenceId = valueOrNull<number>(json?.customerReferenceId);
    dto.reference = valueOrNull<string>(json?.customerReference);
    dto.zone = valueOrNull<string>(json?.tradeProZone);
    dto.solid = valueOrNull<number>(json?.solId);
    dto.solDesc = valueOrNull<string>(json?.solDescription);
    dto.customerReference = valueOrNull<string>(json?.customerReference);
    dto.customerDesc = valueOrNull<string>(json?.customerreferenceDesc);
    const bankIdNum = Number(json?.solId);
    dto.bankId = Number.isFinite(bankIdNum) ? bankIdNum : null;
    dto.customerId = valueOrNull<number>(json?.customerId);
    dto.tnxId = valueOrNull<string>(json?.tnxId);
    dto.brchCode = valueOrNull<string>(json?.brchCode);
    dto.customerAbbvName = valueOrNull<string>(json?.customerAbbvName);
    dto.description = valueOrNull<string>(json?.customerReferenceDescription);

    dto.backOffice1 = valueOrNull<string>(json?.backOffice1);
    dto.backOffice2 = valueOrNull<string>(json?.backOffice2);
    dto.backOffice3 = valueOrNull<string>(json?.backOffice3);
    dto.backOffice4 = valueOrNull<string>(json?.backOffice4);
    dto.backOffice5 = valueOrNull<string>(json?.backOffice5);
    dto.backOffice6 = valueOrNull<string>(json?.backOffice6);
    dto.backOffice7 = valueOrNull<string>(json?.backOffice7);
    dto.backOffice8 = valueOrNull<string>(json?.backOffice8);
    dto.backOffice9 = valueOrNull<string>(json?.backOffice9);

    dto.makerId = valueOrNull<number>(json?.makerId);
    dto.checkerId = valueOrNull<number>(json?.checkerId);
    dto.tnxTypeCode = valueOrNull<string>(json?.tnxTypeCode);
    dto.tnxStatCode = valueOrNull<string>(json?.tnxStatCode);

    dto.makerDttm = valueOrNull<string>(json?.makerDttm);
    dto.checkerDttm = valueOrNull<string>(json?.checkerDttm);

    dto.bankAbbvName = valueOrNull<string>(json?.bankAbbvName);
    dto.defaultReference = valueOrNull<string>(json?.defaultReference);

    dto.normalizeNulls();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: GTPCustomerReferenceTnxDto): Record<string, any> {
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);

    return {
      customerReferenceId: n(dto.customerReferenceId),
      reference: n(dto.reference),
      zone: n(dto.zone),
      solid: n(dto.solid),
      solDesc: n(dto.solDesc),
      customerReference: n(dto.customerReference),
      customerDesc: n(dto.customerDesc),
      bankId: n(dto.bankId),
      customerId: n(dto.customerId),
      tnxId: n(dto.tnxId),
      brchCode: n(dto.brchCode),
      customerAbbvName: n(dto.customerAbbvName),
      description: n(dto.description),

      backOffice1: n(dto.backOffice1),
      backOffice2: n(dto.backOffice2),
      backOffice3: n(dto.backOffice3),
      backOffice4: n(dto.backOffice4),
      backOffice5: n(dto.backOffice5),
      backOffice6: n(dto.backOffice6),
      backOffice7: n(dto.backOffice7),
      backOffice8: n(dto.backOffice8),
      backOffice9: n(dto.backOffice9),

      makerId: n(dto.makerId),
      checkerId: n(dto.checkerId),
      tnxTypeCode: n(dto.tnxTypeCode),
      tnxStatCode: n(dto.tnxStatCode),

      makerDttm: n(dto.makerDttm),
      checkerDttm: n(dto.checkerDttm),

      bankAbbvName: n(dto.bankAbbvName),
      defaultReference: n(dto.defaultReference),
    };
  }
}

/** Helper: normalize possibly-undefined values to null */
function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}