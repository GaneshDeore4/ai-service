export interface MoFdTableData {
  id: number;
  cifId: string;
  accountNumber: string;
  amount: number;
  currency: string;
  tenureYears: number;
  tenureMonths: number;
  tenureDays: number;
  interestRate: number;
  userId: string;
  userBaseCurrency: string | null;
  loginId: string;
  termsAccepted: boolean;
  interestFrequency: string;
  maturityInstruction: string;
  maturityAmount: number;
  maturityDate: string;
  interestAmount: number;
  status: string;
  stateId: number | null;
  createdAt: string;
  updatedAt: string;
  authMatrixId: number | null;
  currentLevel: number;
  rejectReason: string | null;
  makerId: string | null;
  productId: number | null;
  subProductId: number | null;
  version: number;
  tenure: string; //this is only for frontend purpose
}