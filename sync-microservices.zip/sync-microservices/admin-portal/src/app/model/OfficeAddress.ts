

export class OfficeAddressDto {
  addressLine1: string | null = null;
  addressLine2: string | null = null;
  addressLine3: string | null = null;
  addressLine4: string | null = null;
  addressLine5: string | null = null;

  constructor(init?: Partial<OfficeAddressDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof OfficeAddressDto)[];
    for (const k of keys) {
      if (this[k] === undefined) this[k] = null as any;
    }
  }

  /** Converts incoming JSON to a strongly typed DTO, normalizing undefined -> null. */
  static jsonToObject(json: any): OfficeAddressDto {
    const dto = new OfficeAddressDto();

    dto.addressLine1 = valueOrNull<string>(json?.addressLine1);
    dto.addressLine2 = valueOrNull<string>(json?.addressLine2);
    dto.addressLine3 = valueOrNull<string>(json?.addressLine3);
    dto.addressLine4 = valueOrNull<string>(json?.addressLine4);
    dto.addressLine5 = valueOrNull<string>(json?.addressLine5);

    dto.normalizeNulls();
    return dto;
  }

  /** Converts DTO into plain JSON for API calls, ensuring no undefined values. */
  static objectToJson(dto: OfficeAddressDto | null | undefined): Record<string, any> | null {
    if (!dto) return null;
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);

    return {
      addressLine1: n(dto.addressLine1),
      addressLine2: n(dto.addressLine2),
      addressLine3: n(dto.addressLine3),
      addressLine4: n(dto.addressLine4),
      addressLine5: n(dto.addressLine5),
    };
  }
}
/** Helpers: normalize possibly-undefined values to null with a generic type guard */
export function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}
export function objectOrNull<T = any>(v: any): T | null {
  if (v === undefined || v === null) return null;
  if (typeof v === 'object') return v as T;
  return null;
}
``