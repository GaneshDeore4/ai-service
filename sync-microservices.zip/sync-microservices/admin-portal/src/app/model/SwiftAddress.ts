// swift-address.dto.ts

export class SwiftAddressDto {
  addressLine1: string | null = null;
  addressLine2: string | null = null;
  addressLine3: string | null = null;
  countryCode: string | null = null;
  contactReference: string | null = null;

  constructor(init?: Partial<SwiftAddressDto>) {
    if (init) Object.assign(this, init);
    this.normalizeNulls();
  }

  /** Ensures every property is present and never undefined (converts undefined -> null). */
  private normalizeNulls(): void {
    const keys = Object.keys(this) as (keyof SwiftAddressDto)[];
    for (const k of keys) {
      if (this[k] === undefined) this[k] = null as any;
    }
  }

  /** Create a DTO from an incoming JSON payload, guaranteeing all keys exist (undefined -> null). */
  static jsonToObject(json: any): SwiftAddressDto | null {
    if (!json) return null;
    const dto = new SwiftAddressDto();
    dto.addressLine1 = valueOrNull<string>(json?.addressLine1);
    dto.addressLine2 = valueOrNull<string>(json?.addressLine2);
    dto.addressLine3 = valueOrNull<string>(json?.addressLine3);
    dto.countryCode = valueOrNull<string>(json?.countryCode);
    dto.contactReference = valueOrNull<string>(json?.contactReference);
    dto.normalizeNulls();
    return dto;
  }

  /** Produce a plain JSON object for API calls, with every key present (undefined -> null). */
  static objectToJson(dto: SwiftAddressDto | null | undefined): Record<string, any> | null {
    if (!dto) return null;
    const n = <T>(v: T | undefined | null) => (v === undefined ? null : v);
    return {
      addressLine1: n(dto.addressLine1),
      addressLine2: n(dto.addressLine2),
      addressLine3: n(dto.addressLine3),
      countryCode: n(dto.countryCode),
      contactReference: n(dto.contactReference),
    };
  }
}

function valueOrNull<T>(v: any): T | null {
  return v === undefined ? null : (v as T);
}
 function arrayOrNull<T = any>(v: any): (T | null)[] | null {
  if (v === undefined || v === null) return null;
  if (Array.isArray(v)) return v as (T | null)[];
  return null;
}
 function objectOrNull<T = any>(v: any): T | null {
  if (v === undefined || v === null) return null;
  if (typeof v === 'object') return v as T;
  return null;
}