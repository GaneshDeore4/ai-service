export interface UserAccessProfile {
  userId: number;
  username: string;
  userType: string;
  products: Product[];
}

export interface Product {
  productId: number;
  productName: string;
  subProducts: SubProduct[];
}

export interface SubProduct {
  subProductId: number;
  subProductName: string;
  tabActionMapping: TabActionMapping[];
}

export interface TabActionMapping {
  tabId: number;
  tabName: string;
}
