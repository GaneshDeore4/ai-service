import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  constructor(private http: HttpClient) { }

  getData(url: string, data: any): Observable<any> {
    return this.http.get<any>(url.toString(), data);
  }

  getRequestWBody(url: string, data: any): Observable<any> {
    return this.http.request<any>('GET', url, { body: data });
  }


  getDataWithParam(url: string, params: any) {
    return this.http.get<any>(url.toString(), { params });
  }

  // sendData(url:string,data:any):Observable<any>{
  //   return this.http.post<any>(url.toString(),data);
  // }
  //   sendData(url: string, body: any, headers?: any):Observable<any> {
  //   return this.http.post(url, body, { headers });
  // }

  sendData(url: string, body: any, headers?: any): Observable<any> {
    let httpHeaders = new HttpHeaders();
    // ✅ Case 1: If string passed → treat as action role
    if (typeof headers === 'string') {
      httpHeaders = httpHeaders.set('X-ACTION-ROLE', headers);
    }
    // ✅ Case 2: If proper headers object passed → use it
    else if (headers instanceof HttpHeaders) {
      httpHeaders = headers;
    }
    // ✅ Case 3: If plain object passed → convert
    else if (headers && typeof headers === 'object') {
      Object.keys(headers).forEach((key) => {
        httpHeaders = httpHeaders.set(key, headers[key]);
      });
    }
    return this.http.post(url, body, { headers: httpHeaders });
  }
}
