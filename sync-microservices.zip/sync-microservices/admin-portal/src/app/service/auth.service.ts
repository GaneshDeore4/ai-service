import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { SessionService } from './sessionService/session.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class AuthService {

    constructor(private http: HttpClient, private router: Router, private sessionService: SessionService) { }

    login(url: any, data: any): Observable<any> {
        return this.http.post<any>(url.toString(), data);
    }

    forceLogout(url: any, data: any) {
        return this.http.post<any>(url.toString(), data);
    }

    logout(): void {
        this.sessionService.clearSession();
        this.router.navigate(['/login']);
    }

    isLoggedIn() {
        let token = this.sessionService.getToken();
        if (token == undefined || token === '' || token == null) {
            return false;
        } else {
            return true;
        }
    }

}
