import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataTransferService {

  private data:any;
  constructor() { 
  }

  setData(receivedData:any):void{
    this.data=receivedData;
  }
  getData():any{
    return this.data;
  }
}
