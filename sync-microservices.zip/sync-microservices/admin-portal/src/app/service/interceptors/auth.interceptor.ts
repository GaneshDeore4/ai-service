import { HttpErrorResponse, HttpEvent, HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { SessionService } from '../sessionService/session.service';
import { catchError, tap, throwError } from 'rxjs';
import { Router } from '@angular/router';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
    const sessionService = inject(SessionService);
    const router = inject(Router);
    const token = sessionService.getToken();

    let clonedRequest = req;
    if (token) {
        clonedRequest = req.clone({
            setHeaders: {
                Authorization: `Bearer ${token}`,
                'X-USERNAME': sessionService.getUsername(),
                // 'X-ACTION-ROLE': 'MAKER'
            }
        });
    }

    return next(clonedRequest).pipe(
        tap((event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
                const authError = event.headers.get('x-auth-error');
                if (authError === 'SESSION_EXPIRED') {
                    sessionService.clearSession();
                    localStorage.clear();
                    router.navigate(['/login']);
                }
            }
        }),
        catchError((error: HttpErrorResponse) => {
            const authError = error.headers.get('x-auth-error');
            if (authError === 'SESSION_EXPIRED') {
                sessionService.clearSession();
                localStorage.clear();
                router.navigate(['/login']);
            }
            return throwError(() => error);
        })
    );
};
