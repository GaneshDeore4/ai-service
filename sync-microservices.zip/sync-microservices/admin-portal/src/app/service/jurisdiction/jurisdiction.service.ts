import { Injectable, signal, computed } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Category {
    categoryId?: number;
    categoryName?: string;
}

export interface UserType {
    userTypeId?: number;
    userTypeName?: string;
    categoryId?: number;
}

export interface Product {
    productId?: number;
    productName?: string;
    categoryId?: number;
}

export interface SubProduct {
    subproductId?: number;
    subproductName?: string;
    productId?: number;
}

@Injectable({
    providedIn: 'root'
})
export class JurisdictionService {

    // Signals for holding master data (optional, or just hold validation state)
    // We will mostly use this for inter-component communication

    // Selection State
    private selectedCategorySubject = new BehaviorSubject<Category | null>(null);
    selectedCategory$ = this.selectedCategorySubject.asObservable();

    private selectedUserTypeSubject = new BehaviorSubject<UserType | null>(null);
    selectedUserType$ = this.selectedUserTypeSubject.asObservable();

    private selectedProductSubject = new BehaviorSubject<Product | null>(null);
    selectedProduct$ = this.selectedProductSubject.asObservable();

    private selectedSubProductSubject = new BehaviorSubject<SubProduct | null>(null);
    selectedSubProduct$ = this.selectedSubProductSubject.asObservable();

    constructor() { }

    // Setters
    setCategory(category: Category | null) {
        this.selectedCategorySubject.next(category);
        // Cascadng Reset
        this.selectedUserTypeSubject.next(null);
        this.selectedProductSubject.next(null);
        this.selectedSubProductSubject.next(null);
    }

    setUserType(userType: UserType | null) {
        this.selectedUserTypeSubject.next(userType);
    }

    setProduct(product: Product | null) {
        this.selectedProductSubject.next(product);
        // Cascade Reset
        this.selectedSubProductSubject.next(null);
    }

    setSubProduct(subProduct: SubProduct | null) {
        this.selectedSubProductSubject.next(subProduct);
    }

    // Getters (Current Value)
    get currentCategory() { return this.selectedCategorySubject.value; }
    get currentUserType() { return this.selectedUserTypeSubject.value; }
    get currentProduct() { return this.selectedProductSubject.value; }
    get currentSubProduct() { return this.selectedSubProductSubject.value; }
}
