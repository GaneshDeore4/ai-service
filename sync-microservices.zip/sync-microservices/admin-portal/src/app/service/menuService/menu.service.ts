import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { UserAccessProfile } from '../../model/profile.models';
import { GET_MY_ACCESS } from '../../constants/api_endpoints';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private accessProfileSubject = new BehaviorSubject<UserAccessProfile | null>(null);
  public accessProfile$ = this.accessProfileSubject.asObservable();

  // private readonly API_IP = (typeof window !== 'undefined' && (window as any).API_IP) || '13.232.47.252';
  private readonly API_IP = 'localhost';
  private readonly ACCESS_API = `http://${this.API_IP}:8080/api/user/myaccess`;

  constructor(
    private http: HttpClient,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {
    if (isPlatformBrowser(this.platformId)) {
      const storedAccess = sessionStorage.getItem('userAccess');
      if (storedAccess) {
        this.accessProfileSubject.next(JSON.parse(storedAccess));
      }
    }
  }

  fetchUserAccess(userId: number): Observable<any> {
    return this.http.get<any>(`${this.ACCESS_API}?userId=${userId}`).pipe(
      tap(response => {
        if (response.status === 'SUCCESS' && response.payload) {
          if (isPlatformBrowser(this.platformId)) {
            sessionStorage.setItem('userAccess', JSON.stringify(response.payload));
          }
          this.accessProfileSubject.next(response.payload);
        }
      })
    );
  }

  get currentAccessValue(): UserAccessProfile | null {
    return this.accessProfileSubject.value;
  }
}
