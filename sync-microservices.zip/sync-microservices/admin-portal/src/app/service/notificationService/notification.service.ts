import { Injectable, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { SessionTimeoutDialogComponent } from '../../components/dialogs/session-timeout-dialog/session-timeout-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private dialog = inject(MatDialog);

  constructor() { }

  /**
   * Generic display method for notifications. Fallback to alert.
   */
  show(message: string, icon: 'error' | 'warning' | 'info' | 'success' = 'error') {
    alert(`${icon.toUpperCase()}: ${message}`);
    return Promise.resolve({ isConfirmed: true });
  }

  /**
   * Displays a Material Dialog for session extension confirmation.
   */
  showSessionExtensionConfirm(secondsLeft: number) {
    return this.dialog.open(SessionTimeoutDialogComponent, {
      width: '400px',
      disableClose: true,
      panelClass: 'indus-session-dialog-container', // Add this line for custom styling
      data: { secondsLeft: secondsLeft }
    }).afterClosed();
  }

  /**
   * Displays a centered loading modal.
   */
  showLoading(message: string) {
    console.log(`Loading: ${message}`);
  }

  close() {
    this.dialog.closeAll();
  }

  /**
   * Specifically for Login API Failures.
   */
  handleApiError(moduleName: string = 'Authentication') {
    alert(`Service Unavailable: Our ${moduleName} servers are currently not responding.`);
    return Promise.resolve({ isConfirmed: true });
  }

  /**
   * For User Module Confirmation.
   */
  confirmUserDeactivation(userName: string) {
    const confirmed = confirm(`Are you sure you want to deactivate ${userName}?`);
    return Promise.resolve({ isConfirmed: confirmed });
  }

  showSuccessToast(message: string) {
    console.log('Success Toast:', message);
  }

  showErrorToast(message: string) {
    alert('Error: ' + message);
  }
}
