import { inject, PLATFORM_ID } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { isPlatformBrowser } from '@angular/common';
import { SessionTimeoutService } from '../../service/sessionService/session-timeout.service';
import { NotificationService } from '../../service/notificationService/notification.service';
import { SessionService } from '../../service/sessionService/session.service';

/**
 * AuthGuard to protect routes from unauthenticated or expired sessions.
 * Modern Functional Guard implementation for Angular 19.
 */
export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const sessionService = inject(SessionTimeoutService);
  const dataService = inject(SessionService);
  const notificationService = inject(NotificationService);
  const platformId = inject(PLATFORM_ID);

  // 1. SSR Check: Guards run on the server during pre-rendering.
  // Storage is only available in the browser.
  if (!isPlatformBrowser(platformId)) {
    return true; 
  }

  const authToken = dataService.getToken(); // Standardized to SessionService

  // 2. Check if user is logged in
  if (!authToken) {
    router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }

  // 3. Check if session is marked as expired in the service
  if (sessionService.isSessionExpired()) {
    notificationService.showErrorToast('Session Expired. Please login again.');
    sessionService.clearSession();
    router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }

  return true;
};