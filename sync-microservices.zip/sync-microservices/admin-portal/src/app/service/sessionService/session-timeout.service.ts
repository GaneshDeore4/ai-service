import { Injectable, NgZone, inject, PLATFORM_ID, OnDestroy, signal } from '@angular/core';
import { isPlatformBrowser, DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';
import { SessionService } from '../../service/sessionService/session.service';
import { fromEvent, merge, Subscription, throttleTime, Subject, switchMap, timer, takeUntil } from 'rxjs';
import { AuthService } from '../../service/auth.service';
import * as Constants from '../../constants/Constants';

@Injectable({
  providedIn: 'root'
})
export class SessionTimeoutService implements OnDestroy {
  private mainTimeoutId: ReturnType<typeof setTimeout> | null = null;
  private warningTimeoutId: ReturnType<typeof setTimeout> | null = null;
  private countdownInterval: any;
  private eventSubscription?: Subscription;
  private destroy$ = new Subject<void>();

  // UI State Signals
  sessionStatus = signal<'active' | 'warning' | 'expired'>('active');
  countdown = signal<number>(120);
  readonly totalTime = 120; // Seconds

  // Configuration (Aligned with session-service: 5m idle, 2m grace)
  private readonly SESSION_TIMEOUT = Constants.SESSION_TIMEOUT;
  private readonly WARNING_DURATION = Constants.WARNING_DURATION;

  private router = inject(Router);
  private ngZone = inject(NgZone);
  private platformId = inject(PLATFORM_ID);
  private document = inject(DOCUMENT);
  private sessionService = inject(SessionService);

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      this.initListener();
    }
  }

  resetTimer() {
    if (!isPlatformBrowser(this.platformId)) return;
    if (!this.sessionService.getToken()) return;

    this.clearAllTimers();
    this.sessionStatus.set('active');

    // Start Warning Timer
    this.warningTimeoutId = setTimeout(() => {
      this.ngZone.run(() => this.showSessionWarning());
    }, this.SESSION_TIMEOUT - this.WARNING_DURATION);
  }

  private initListener() {
    this.ngZone.runOutsideAngular(() => {
      const events = ['click', 'keydown', 'touchstart'];
      const eventStreams = events.map(ev => fromEvent(this.document, ev));

      this.eventSubscription = merge(...eventStreams)
        .pipe(
          throttleTime(1000), // Only reset at most once per second
          takeUntil(this.destroy$)
        )
        .subscribe(() => {
          this.ngZone.run(() => this.resetTimer());
        });
    });
  }

  showSessionWarning() {
    this.sessionStatus.set('warning');
    this.countdown.set(this.WARNING_DURATION / 1000);

    this.countdownInterval = setInterval(() => {
      this.countdown.update(val => val - 1);
      if (this.countdown() <= 0) {
        this.expireSession();
      }
    }, 1000);
  }

  private authService = inject(AuthService);

  expireSession() {
    this.clearAllTimers();
    this.sessionStatus.set('expired');

    const performFinalLogout = () => {
      this.authService.logout();
      this.sessionStatus.set('active');
    };

    // Force logout in backend if we have a user
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser') || '{}');
    if (currentUser && currentUser.loginId) {
      import('../../constants/api_endpoints').then(m => {
        this.authService.forceLogout(m.FORCE_LOGOUT, { loginId: currentUser.loginId }).subscribe({
          next: () => {
            console.log('Backend session terminated');
            performFinalLogout();
          },
          error: (err) => {
            console.error('Failed to terminate backend session', err);
            performFinalLogout();
          }
        });
      });
      return;
    }

    performFinalLogout();
  }

  redirectToLogin() {
    this.clearAllTimers();
    this.sessionStatus.set('active');
    this.router.navigate(['/login']);
  }

  private clearAllTimers() {
    if (this.mainTimeoutId) clearTimeout(this.mainTimeoutId);
    if (this.warningTimeoutId) clearTimeout(this.warningTimeoutId);
    if (this.countdownInterval) clearInterval(this.countdownInterval);
    this.mainTimeoutId = null;
    this.warningTimeoutId = null;
    this.countdownInterval = null;
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.clearAllTimers();
  }
}
