import { isPlatformBrowser } from '@angular/common';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SessionService {

  constructor(@Inject(PLATFORM_ID) private platformId: Object) { }

  setRole(role: string): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('role', role);
    }
  }

  getRole(): string {
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('role') ?? '';
    }
    return '';
  }

    setUsername(username: string): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('username', username);
    }
  }

  getUsername(): string {
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('username') ?? '';
    }
    return '';
  }
    setEmail(email: string): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('email', email);
    }
  }

  getEmail(): string {
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('email') ?? '';
    }
    return '';
  }
  
// user id is db id
  setUserId(userId: number | null): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('userId', String(userId));
    }
  }

  getUserId(): number | null {
    if (isPlatformBrowser(this.platformId)) {
      const v = sessionStorage.getItem('userId');
      if (v === null) return null;
      const n = Number(v);
      return Number.isNaN(n) ? null : n;
    }
    return null;
  }

  // login id is set by user in the form
    setLoginId(loginId: any | null): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('loginId', String(loginId));
    }
  }

  getLoginId(): any | null {
    if (isPlatformBrowser(this.platformId)) {
      const v = sessionStorage.getItem('loginId');
      if (v === null) return null;
      return v;
    }
    return null;
  }

    setCompanyId(companyId: number | null): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('companyId', String(companyId));
    }
  }
    setLastLogin(lastLogin: number | null): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('lastLgoin', String(lastLogin));
    }
  }
    getCompanyId(): number | null {
    if (isPlatformBrowser(this.platformId)) {
      const v = sessionStorage.getItem('companyId');
      if (v === null) return null;
      const n = Number(v);
      return Number.isNaN(n) ? null : n;
    }
    return null;
  }
    getLastLogin(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      const v = sessionStorage.getItem('lastLgoin');
      if (v === null) return null;
      
      return v;
    }
    return null;
  }

      setCompanyName(companyName: string): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('companyName', companyName);
    }
  }

  getCompanyName(): string {
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('companyName') ?? '';
    }
    return '';
  }

  setToken(token: string): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('authToken', token);
    }
  }

  getToken(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('authToken');
    }
    return null;
  }

  setIsFirstLoginFlag(flag: boolean):void{
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.setItem('isFirstLogin', String(flag));
    }
  }
  getIsFirstLoginFlag():boolean{
    if (isPlatformBrowser(this.platformId)) {
      return sessionStorage.getItem('isFirstLogin') === 'true';
    }
    return false;
  }


  clearSession(): void {
    if (isPlatformBrowser(this.platformId)) {
      sessionStorage.clear();
    }
  }

}
