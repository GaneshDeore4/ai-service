import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { SUPERADMIN } from '../../constants/Constants';

interface MenuItem {
  title: string;
  link: string;
  icon?: string;
  isActive: boolean;
  subMenu: MenuItem[];
  isDropdownOpen: boolean;
  hasDropdown: boolean;
  isSubMenu: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  // ---------------------------default menu items list-------------------
  defaultMenuItems: MenuItem[] = [
    {
      title: 'Notifications',
      link: '/content/news-landing',
      isActive: false,
      icon: 'pi pi-book',
      subMenu: [],
      isDropdownOpen: false,
      hasDropdown: false,
      isSubMenu: false
    },
    {
      title: 'Setup',
      link: '/content/sf-landing',
      icon: 'pi pi-th-large',
      isActive: false,
      subMenu: [],
      isDropdownOpen: false,
      hasDropdown: false,
      isSubMenu: false
    },
    {
      title: 'Middle Office',
      link: '/content/mo-landing',
      icon: 'pi pi-briefcase',
      isActive: false,
      subMenu: [],
      isDropdownOpen: false,
      hasDropdown: false,
      isSubMenu: false
    },
    {
      title: 'Audit Trail',
      link: '/content/dashboard',
      icon: 'pi pi-history',
      isActive: false,
      subMenu: [],
      isDropdownOpen: false,
      hasDropdown: false,
      isSubMenu: false
    },
    // {
    //   title: 'Resend Fail Transaction',
    //   link: '/content/dashboard',
    //   icon: 'pi pi-sync',
    //   isActive: false,
    //   subMenu: [],
    //   isDropdownOpen: false,
    //   hasDropdown: false,
    //   isSubMenu: false
    // },
  ];

  // news menuitems
  newsMenuItems: MenuItem[] = [
    {
      title: 'Notifications',
      link: '/content/news-landing',
      icon: 'pi pi-book',
      isActive: false,
      subMenu: [
        {
          title: 'Bank Notifications',
          link: '/content/news-internal',
          icon: 'pi pi-bell',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        },
        {
          title: 'Bank Guidelines',
          link: '/content/news-ticker',
          icon: 'pi pi-megaphone',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        }
      ],
      isDropdownOpen: false,
      hasDropdown: true,
      isSubMenu: false
    }
  ];

  // system features menuitems
  systemFeaturesMenuForSA: MenuItem[] = [
    // {
    //   title: 'Change Profile',
    //   link: '/content/sf-change-profile',
    //   icon: 'pi pi-user-edit',
    //   isActive: false,
    //   subMenu: [],
    //   isDropdownOpen: false,
    //   hasDropdown: false,
    //   isSubMenu: false
    // },
    {
      title: 'Master Maintenance',
      link: '/content/sf-landing',
      icon: 'pi pi-map-marker',
      isActive: false,
      subMenu: [
        {
          title: 'Category',
          link: '/content/category-master',
          icon: 'pi pi-user',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'User Role',
          link: '/content/user-type-master',
          icon: 'pi pi-users',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'Department',
          link: '/content/departments',
          icon: 'pi pi-building',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'Product',
          link: '/content/product-master',
          icon: 'pi pi-bars',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'Sub-Product',
          link: '/content/sub-product-master',
          icon: 'pi pi-list',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'Sub-Product Features',
          link: '/content/role-master',
          icon: 'pi pi-cog',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'Sub-product Action',
          link: '/content/action-master',
          icon: 'pi pi-cog',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'User Role Permissions',
          link: '/content/action-mapping-master',
          icon: 'pi pi-cog',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'User Role/Department Mapping',
          link: '/content/user-type-department-mapping',
          icon: 'pi pi-sitemap',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
        {
          title: 'Mid-office Integration',
          link: '/content/product-integration',
          icon: 'pi pi-cog',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: false
        },
      ],
      isDropdownOpen: false,
      hasDropdown: true,
      isSubMenu: false
    },
    // {
    //   title: 'Rates Maintenance',
    //   link: '/content/rate-maintenance',
    //   icon: 'pi pi-chart-line',
    //   isActive: false,
    //   subMenu: [],
    //   isDropdownOpen: false,
    //   hasDropdown: false,
    //   isSubMenu: false
    // },
    {
      title: 'Bank Setup',
      link: '/content/sf-landing',
      icon: 'pi pi-building-columns',
      isActive: false,
      subMenu: [
        // {
        //   title: 'Bank Profile',
        //   link: '/content/bank-profile',
        //   icon: 'pi pi-building-columns',
        //   isActive: false,
        //   subMenu: [],
        //   isDropdownOpen: false,
        //   hasDropdown: false,
        //   isSubMenu: true
        // },
        {
          title: 'User Setup',
          link: '/content/bm-user-profile',
          icon: 'pi pi-user',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        }
        // {
        //   title: 'User Authentication',
        //   link: '/content/bm-user-authentication',
        //   icon: 'pi pi-verified',
        //   isActive: false,
        //   subMenu: [],
        //   isDropdownOpen: false,
        //   hasDropdown: false,
        //   isSubMenu: true
        // }
      ],
      isDropdownOpen: false,
      hasDropdown: true,
      isSubMenu: false
    },
    // {
    //   title: 'User Maintenance',
    //   link: '/content/sf-landing',
    //   icon: 'pi pi-users',
    //   isActive: false,
    //   subMenu: [
    //     {
    //       title: 'Profiles',
    //       link: '/content/um-profile',
    //       icon: 'pi pi-users',
    //       isActive: false,
    //       subMenu: [],
    //       isDropdownOpen: false,
    //       hasDropdown: false,
    //       isSubMenu: true
    //     },
    //     {
    //       title: 'Authentication',
    //       link: '/content/um-authentication',
    //       icon: 'pi pi-unlock',
    //       isActive: false,
    //       subMenu: [],
    //       isDropdownOpen: false,
    //       hasDropdown: false,
    //       isSubMenu: true
    //     }
    //   ],
    //   isDropdownOpen: false,
    //   hasDropdown: true,
    //   isSubMenu: false
    // },
    // {
    //   title: 'Alerts Maintenance',
    //   link: '/content/alert-maintenance',
    //   icon: 'pi pi-bell',
    //   isActive: false,
    //   subMenu: [],
    //   isDropdownOpen: false,
    //   hasDropdown: false,
    //   isSubMenu: false
    // },
  ];

  systemFeaturesMenuWOSA: MenuItem[] = [
    // {
    //   title: 'Change Profile',
    //   link: '/content/sf-change-profile',
    //   icon: 'pi pi-user-edit',
    //   isActive: false,
    //   subMenu: [],
    //   isDropdownOpen: false,
    //   hasDropdown: false,
    //   isSubMenu: false
    // },
    // {
    //   title: 'Rates Maintenance',
    //   link: '/content/rate-maintenance',
    //   icon: 'pi pi-chart-line',
    //   isActive: false,
    //   subMenu: [],
    //   isDropdownOpen: false,
    //   hasDropdown: false,
    //   isSubMenu: false
    // },
    {
      title: 'Customer Setup',
      link: '/content/sf-landing',
      icon: 'pi pi-building',
      isActive: false,
      subMenu: [
        {
          title: 'Customer Profile',
          link: '/content/cm-profiles',
          icon: 'pi pi-id-card',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        },
        {
          title: 'User Setup',
          link: '/content/cm-user-profile',
          icon: 'pi pi-users',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        },
        {
          title: 'Authorisation Matrix',
          link: '/content/cm-authorisation',
          icon: 'pi pi-unlock',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        },
        {
          title: 'User Accounts',
          link: '/content/user-account-mapping',
          icon: 'pi pi-users',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        },
      ],
      isDropdownOpen: false,
      hasDropdown: true,
      isSubMenu: false
    },
    // {
    //   title: 'User Maintenance',
    //   link: '/content/sf-landing',
    //   icon: 'pi pi-users',
    //   isActive: false,
    //   subMenu: [
    //     {
    //       title: 'Profiles',
    //       link: '/content/um-profile',
    //       icon: 'pi pi-users',
    //       isActive: false,
    //       subMenu: [],
    //       isDropdownOpen: false,
    //       hasDropdown: false,
    //       isSubMenu: true
    //     },
    //     {
    //       title: 'Authentication',
    //       link: '/content/um-authentication',
    //       icon: 'pi pi-unlock',
    //       isActive: false,
    //       subMenu: [],
    //       isDropdownOpen: false,
    //       hasDropdown: false,
    //       isSubMenu: true
    //     }
    //   ],
    //   isDropdownOpen: false,
    //   hasDropdown: true,
    //   isSubMenu: false
    // },
    // {
    //   title: 'Alerts Maintenance',
    //   link: '/content/alert-maintenance',
    //   icon: 'pi pi-bell',
    //   isActive: false,
    //   subMenu: [],
    //   isDropdownOpen: false,
    //   hasDropdown: false,
    //   isSubMenu: false
    // },
  ];

  middleOfficeMenu: MenuItem[] = [
    {
      title: 'Transaction Inquiry',
      link: '/content/mo-landing',
      icon: 'pi pi-list',
      isActive: false,
      subMenu: [
        // {
        //   title: 'Transaction Inquiry',
        //   link: '/content/trans-inquiry',
        //   icon: 'pi pi-hourglass',
        //   isActive: false,
        //   subMenu: [],
        //   isDropdownOpen: false,
        //   hasDropdown: false,
        //   isSubMenu: true
        // },
        {
          title: 'Pending At Client',
          link: '/content/pending-at-client',
          icon: '',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        },
        {
          title: 'Pending at Bank',
          link: '/content/pending-at-bank',
          // icon: 'pi pi-hourglass',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        },
        {
          title: 'Processed by Bank At Client',
          link: '/content/processed-by-bank',
          // icon: 'pi pi-hourglass',
          isActive: false,
          subMenu: [],
          isDropdownOpen: false,
          hasDropdown: false,
          isSubMenu: true
        },
      ],
      isDropdownOpen: false,
      hasDropdown: true,
      isSubMenu: false
    },
  ];

  constructor() {
  }

  private asideFull = new BehaviorSubject<Boolean>(true);
  asideFull$ = this.asideFull.asObservable();
  toggleNavFull() {
    this.asideFull.next(!this.asideFull.value);
  }

  private menuItems = new BehaviorSubject<any>(this.defaultMenuItems);
  menuItems$ = this.menuItems.asObservable();
  setMenuItems(newMenuItems: MenuItem[]) {
    this.menuItems.next(newMenuItems);
  }
  setDefaultMenuItems() {
    this.menuItems.next(this.defaultMenuItems);
  }

}
