import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StatusService {

  constructor() { }

  getStatus(txnStatCode:string,txnTypeCode:string):string{
    console.log(txnTypeCode + " " + txnStatCode);
    if(txnTypeCode=='01' && txnStatCode=='01')
        return 'Draft(New)';
    if(txnTypeCode=='01' && txnStatCode=='02')
        return 'Waiting for approval(checker)';
    if(txnTypeCode=='01' && txnStatCode=='54')
        return 'Checker Returned (New)';
    else  
      return 'Draft(New)';
  }
}
