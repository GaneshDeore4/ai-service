import { inject, Injectable } from '@angular/core';
import { ApiService } from '../apiService/api.service';
import {
  SAVE_USER_ACCOUNT_MAPPING,
  GET_ALL_ACCOUNT_BY_CIF,
  SYNC_API,
  GET_ACCOUNT_BY_CIF,
} from '../../constants/api_endpoints';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserAccountService {
  private apiService = inject(ApiService);

  constructor() {}

  saveMapping(payload: any, actionRole: string): Observable<any> {
    return this.apiService.sendData(SAVE_USER_ACCOUNT_MAPPING, payload, {
      'X-ACTION-ROLE': actionRole,
    });
  }

  syncAccounts(cifId: string): Observable<any> {
    return this.apiService.sendData(`${SYNC_API}/${cifId}`, {});
  }

  getAccountsByCif(cifId: string): Observable<any> {
    return this.apiService.getData(`${GET_ACCOUNT_BY_CIF}/${cifId}`, {});
  }

  // Placeholder for maker-checker endpoints if they differ
  approveMapping(mappingId: any): Observable<any> {
    // Assuming a similar pattern for approval
    return this.apiService.sendData(`api/account_mapping/approve?id=${mappingId}`, {}, {
      'X-ACTION-ROLE': 'APPROVE',
    });
  }

  rejectMapping(mappingId: any): Observable<any> {
    return this.apiService.sendData(`api/account_mapping/reject?id=${mappingId}`, {}, {
      'X-ACTION-ROLE': 'REJECT',
    });
  }
}
