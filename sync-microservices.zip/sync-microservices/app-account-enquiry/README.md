# AccountService Microservice

The AccountService is a Spring Boot 3 microservice designed to integrate with Core Banking systems (Finacle) to fetch and persist Account and Balance details.

## 🚀 Key Features
- **Adapter Pattern**: Supports both **SOAP (XML)** and **JSON** protocols. No code changes are required to switch; only configuration.
- **Resilient Execution**: Integrated with Feign, Resilience4j, and standardized error handling from `trade-common`.
- **Database Sync**: Uses PostgreSQL to cache account details, preventing redundant hits to core systems and allowing fast local queries.

## 🛠 Tech Stack
- **Java 17**
- **Spring Boot 3.1.x**
- **Spring Cloud OpenFeign**
- **PostgreSQL**
- **Lombok**

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/accounts/sync/{cifId}` | Syncs all accounts for a CIF from Bank to Database. |
| GET | `/api/accounts/cif/{cifId}` | Retrieves saved accounts for a CIF from local DB. |
| POST | `/api/accounts/sync-balance/{accNum}` | Forces a balance sync for a specific account. |
| GET | `/api/accounts/balance/{accNum}` | Gets the latest balance from local DB. |

---

## ⚙️ Configuration & Switching (SOAP vs JSON)

You can alternate between protocols via `src/main/resources/application.yml`.

### Switch to SOAP (Finacle)
```yaml
app:
  bank:
    adapter:
      type: soap # Default
```

### Switch to JSON
```yaml
app:
  bank:
    adapter:
      type: json
```



## 🧪 Testing with Dummy Data

The service is currently set up for **Testing Mode** by default.

### If Core Bank API is unavailable:
In `SoapAdapter.java` or `BankJsonAdapter.java`, the code is configured to return mocked data if the real Feign client call is commented out.

**To move to Production:**
1. Open `SoapAdapter.java`.
2. Uncomment `soapResponse = finacleSoapFeignClient.executeFinacleScript(soapRequest);`.
3. Comment out the `getDummySoapResponse(cifId);` line.

### Swagger Documentation
You can test endpoints interactively at:
`http://localhost:8085/swagger-ui/index.html`

---

## 💾 Database Schema
The service automatically creates/updates the `account_details` table:
- `account_number` (Unique Index)
- `cif_id`
- `effective_avail_balance`
- `currency`
- `scheme_description`
- `scheme_type`
- `insert_date` (Audit field)

### 📝 Audit Logging
All changes to account details are tracked in `account_audits` table:
- `cif_id`: The CIF associated with the change.
- `account_number`: The specific account being updated.
- `field_name`: The field that changed (e.g., balance, currency).
- `old_value` / `new_value`: History of the data.
- `updated_at`: Timestamp of the change.

**How to disable Auditing:**
If you don't need audit logs, you can comment out the `/* --- AUDIT LOGGING START --- */` blocks in `AccountServiceImpl.java`.
