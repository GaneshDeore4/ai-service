package com.indusind.trade.account.adapter;

import com.indusind.trade.account.dto.AccountDTO;
import java.util.List;

public interface AccountAdapter {
    List<AccountDTO> fetchAccountsByCif(String cifId);
}
