package com.indusind.trade.account.adapter;

import com.indusind.trade.account.dto.response.AccountDetailsResponseDTO;

public interface AccountDetailsAdapter {

    AccountDetailsResponseDTO getAccountDetails(String accountNo) throws Exception;
}
