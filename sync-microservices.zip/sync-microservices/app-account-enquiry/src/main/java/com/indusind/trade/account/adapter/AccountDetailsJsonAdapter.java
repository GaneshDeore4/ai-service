package com.indusind.trade.account.adapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import com.indusind.app.jose.constant.InputType;
import com.indusind.app.jose.operations.JoseHelper;
import com.indusind.app.jose.operations.JoseUtility;
import com.indusind.trade.account.client.SingleAccountDetailsFeignClient;
import com.indusind.trade.account.dto.json.AccountDetailsJSONRequest;
import com.indusind.trade.account.dto.response.AccountDetailsResponseDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.acc.adapter.type", havingValue = "json", matchIfMissing = true)
@RequiredArgsConstructor
public class AccountDetailsJsonAdapter implements AccountDetailsAdapter {

    private final SingleAccountDetailsFeignClient singleAccountDetailsFeignClient;
    private final ObjectMapper objectMapper;
    private final JoseHelper joseHelper;

    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    @Override
    public AccountDetailsResponseDTO getAccountDetails(String accountNo) {

        AccountDetailsJSONRequest request = AccountDetailsJSONRequest.builder()
                .accountNumber(accountNo)
                .build();

        // Fresh per-request JoseUtility — holds the symmetric key needed for response decryption.
        JoseUtility ju = joseHelper.getJoseUtility();

        try {
            String requestJson = objectMapper.writeValueAsString(request);
            log.info("Plain account details request: {}", requestJson);

            String encryptedEnvelope = ju.createIblGatewayRequestString(null, requestJson, InputType.STRING);
            log.debug("Encrypted account details envelope: {}", encryptedEnvelope);

            IBLGatewayResponse encryptedResponse =
                    singleAccountDetailsFeignClient.getAccountDetails(clientId, clientSecret, encryptedEnvelope);

            if (encryptedResponse == null || encryptedResponse.getData() == null) {
                throw new RuntimeException("Empty encrypted response from bank");
            }

            // Decrypt using the same JoseUtility instance — it still holds the AES key from encrypt step.
            return ju.getPayloadFromResponseObject(
                    null, encryptedResponse.getData(), AccountDetailsResponseDTO.class, InputType.STRING);

        } catch (Exception e) {
            log.error("Error calling account details API: {}", e.getMessage(), e);
            throw new RuntimeException("Account details API error", e);
        }
    }
}
