package com.indusind.trade.account.adapter;

import com.indusind.trade.account.dto.BalanceDTO;

public interface BalanceAdapter {
    BalanceDTO fetchBalanceByAccount(String accountNumber);
}
