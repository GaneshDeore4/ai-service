package com.indusind.trade.account.adapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import com.indusind.app.jose.constant.InputType;
import com.indusind.app.jose.operations.JoseHelper;
import com.indusind.app.jose.operations.JoseUtility;
import com.indusind.trade.account.client.BalanceEnquiryFeignClient;
import com.indusind.trade.account.client.BankAccountJsonFeignClient;
import com.indusind.trade.account.client.BankJsonFeignClient;
import com.indusind.trade.account.dto.AccountDTO;
import com.indusind.trade.account.dto.BalanceDTO;
import com.indusind.trade.account.dto.SyncAccountRequestDto;
import com.indusind.trade.account.dto.json.BalanceEnquiryRequest;
import com.indusind.trade.account.dto.json.BalanceEnquiryResponse;
import com.indusind.trade.account.dto.json.SyncAccountJson;
import com.indusind.trade.account.dto.json.SyncAccountJsonResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.bank.adapter.type", havingValue = "json")
@RequiredArgsConstructor
public class BankJsonAdapter implements AccountAdapter, BalanceAdapter {

    private final BankJsonFeignClient bankJsonFeignClient;
    private final BankAccountJsonFeignClient bankAccountJsonFeignClient;
    private final BalanceEnquiryFeignClient balanceEnquiryClient;
    private final ObjectMapper objectMapper;
    private final JoseHelper joseHelper;
    private static final List<String> OPERATIVE_ACCOUNT_SCHEME_TYPES = Arrays.asList("SBA", "CAA", "CCA");
    private static final String FD_ACCOUNT_SCHEME_TYPE = "TDA";


    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    @Value("${ibl.env:UAT}")
    private String iblEnv;

    @Override
    public List<AccountDTO> fetchAccountsByCif(String cifId) {
        log.info("Fetching accounts from JSON API for CIF: {}", cifId);
        SyncAccountRequestDto syncAccountRequestDto = SyncAccountRequestDto.builder().cifId(cifId).build();

        JoseUtility ju = joseHelper.getJoseUtility();

        try {
            String requestJson = objectMapper.writeValueAsString(syncAccountRequestDto);
            log.info("Plain getcustomeraccounts request: {}", requestJson);

            String encryptedEnvelope = ju.createIblGatewayRequestString(null, requestJson, InputType.STRING);
            log.debug("Encrypted getcustomeraccounts envelope: {}", encryptedEnvelope);

            IBLGatewayResponse encryptedResponse =
                    bankAccountJsonFeignClient.fetchAccountsByCifId(clientId, clientSecret, encryptedEnvelope);

            if (encryptedResponse == null || encryptedResponse.getData() == null) {
                throw new RuntimeException("Empty encrypted response from bank");
            }

            SyncAccountJsonResponse jsonResponses = ju.getPayloadFromResponseObject(
                    null, encryptedResponse.getData(), SyncAccountJsonResponse.class, InputType.STRING);
            System.out.println("Returned Output" +mapJsonToDto(jsonResponses));
            return mapJsonToDto(jsonResponses);

        } catch (Exception e) {
            log.error("Error calling Bank JSON API: {}", e.getMessage(), e);
            throw new RuntimeException("Bank JSON API Error", e);
        }
    }

    private List<AccountDTO> mapJsonToDto(SyncAccountJsonResponse jsonResponses) {
        System.out.println("mapJsonToDto");
        System.out.println("JSON Response=" +jsonResponses);
        if (jsonResponses == null || jsonResponses.getAccounts() == null) return List.of();
        return jsonResponses.getAccounts().stream().map(resp -> AccountDTO.builder()
                .cifId(resp.getCifId())
                .accountNumber(resp.getAccountNumber())
                .currency(resp.getCurrency())
                .schemeDescription(resp.getSchemeDesc())
                .schemeType(resp.getSchemeType())
                .effectiveAvailBalance(OPERATIVE_ACCOUNT_SCHEME_TYPES.contains(resp.getSchemeType()) ?
                        toBigDecimal(resp.getAccountBalance()) :
                        FD_ACCOUNT_SCHEME_TYPE.equals(resp.getSchemeType()) ? toBigDecimal(resp.getDepositAmount()) : BigDecimal.ZERO)
                .build()).collect(Collectors.toList());
    }

    private static BigDecimal toBigDecimal(String val) {
        if (val == null || val.trim().isEmpty()) return BigDecimal.ZERO;
        try {
            return new BigDecimal(val.trim());
        } catch (NumberFormatException e) {
            return BigDecimal.ZERO;
        }
    }

    @Override
    public BalanceDTO fetchBalanceByAccount(String accountNumber) {
        log.info("Fetching balance from JSON API for Account: {}", accountNumber);

        BalanceEnquiryRequest request = BalanceEnquiryRequest.builder()
                .requestUUID(UUID.randomUUID().toString())
                .channelID("GCT")
                .accountNo(accountNumber)
                .build();

        JoseUtility ju = joseHelper.getJoseUtility();

        try {
            String requestJson = objectMapper.writeValueAsString(request);
            log.info("Plain balance enquiry request: {}", requestJson);

            String encryptedEnvelope = ju.createIblGatewayRequestString(null, requestJson, InputType.STRING);
            log.debug("Encrypted balance enquiry request envelope: {}", encryptedEnvelope);

            IBLGatewayResponse encryptedResponse = balanceEnquiryClient.fetchBalance(clientId, clientSecret, encryptedEnvelope);

            log.debug("Encrypted balance enquiry Response envelope: {}", encryptedResponse);
            
            if (encryptedResponse == null || encryptedResponse.getData() == null) {
                throw new RuntimeException("Empty encrypted response from bank");
            }

            BalanceEnquiryResponse response = ju.getPayloadFromResponseObject(
                    null, encryptedResponse.getData(), BalanceEnquiryResponse.class, InputType.STRING);

            if (response != null) {
                log.info("Received balance for account {}: {}", accountNumber, response.getEffAvailableBalance());
                return BalanceDTO.builder()
                        .accountNumber(response.getAccountId())
                        .effectiveAvailBalance(response.getEffAvailableBalance())
                        .currency(response.getCurrency())
                        .build();
            }
        } catch (Exception e) {
            log.error("Error fetching balance for account {}: {}", accountNumber, e.getMessage());
            throw new RuntimeException("Bank Balance API Error", e);
        }
        
        return BalanceDTO.builder()
                .accountNumber(accountNumber)
                .effectiveAvailBalance(BigDecimal.ZERO)
                .currency("USD")
                .build();
    }
}
