//package com.indusind.trade.account.adapter;
//
//import com.indusind.trade.account.dto.AccountDTO;
//import com.indusind.trade.account.dto.BalanceDTO;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.stereotype.Component;
//
//import java.math.BigDecimal;
//import java.util.Arrays;
//import java.util.List;
//
//@Slf4j
//@Component
//public class FinacleMockAdapter implements AccountAdapter, BalanceAdapter {
//
//    @Override
//    public List<AccountDTO> fetchAccountsByCif(String cifId) {
//        log.info("Mock API call to fetch accounts for CIF: {}", cifId);
//        // Using the user-provided dummy data
//        return Arrays.asList(
//            AccountDTO.builder()
//                .cifId(cifId)
//                .accountNumber("201025414298")
//                .currency("USD")
//                .schemeDescription("CURRENT ACCOUNT - EEFC (CG)")
//                .schemeType("CAA")
//                .effectiveAvailBalance(new BigDecimal("20000005.60"))
//                .build(),
//            AccountDTO.builder()
//                .cifId(cifId)
//                .accountNumber("201032711551")
//                .currency("INR")
//                .schemeDescription("CURRENT ACCOUNT INDUS EXIM")
//                .schemeType("CAA")
//                .effectiveAvailBalance(new BigDecimal("1288.78"))
//                .build(),
//            AccountDTO.builder()
//                .cifId(cifId)
//                .accountNumber("259314713034")
//                .currency("INR")
//                .schemeDescription("CASH CREDIT ACCOUNT")
//                .schemeType("CAA")
//                .effectiveAvailBalance(new BigDecimal("625849111.97"))
//                .build()
//        );
//    }
//
//    @Override
//    public BalanceDTO fetchBalanceByAccount(String accountNumber) {
//        log.info("Mock API call to fetch balance for Account: {}", accountNumber);
//        // Using a hardcoded update to demonstrate Balance update sync capability
//        return BalanceDTO.builder()
//            .accountNumber(accountNumber)
//            .effectiveAvailBalance(new BigDecimal("9999999.99")) // Mock updated balance
//            .currency("INR")
//            .build();
//    }
//}
