package com.indusind.trade.account.adapter;

import com.indusind.trade.account.client.SoapFeignClient;
import com.indusind.trade.account.dto.AccountDTO;
import com.indusind.trade.account.dto.BalanceDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Slf4j
@Component
@Primary
@ConditionalOnProperty(name = "app.bank.adapter.type", havingValue = "soap", matchIfMissing = true)
@RequiredArgsConstructor
public class SoapAdapter implements AccountAdapter, BalanceAdapter {

    private final SoapFeignClient finacleSoapFeignClient;

    @Override
    public List<AccountDTO> fetchAccountsByCif(String cifId) {
        log.info("Fetching accounts from Finacle SOAP API for CIF: {}", cifId);

        String correlationId = "Req_" + UUID.randomUUID().toString().substring(0, 8);
        String soapRequest = buildSoapRequest(cifId, correlationId);

        String soapResponse;
        try {
            soapResponse = finacleSoapFeignClient.executeFinacleScript(soapRequest);
            log.info("Successfully received SOAP response from Finacle for CIF: {}", cifId);
        } catch (Exception e) {
            log.warn("⚠️ Finacle API Error: {}. FALLING BACK TO DUMMY DATA.", e.getMessage());
            soapResponse = getDummySoapResponse(cifId);
        }
        return mapXmlToDto(soapResponse, cifId);
    }

    @Override
    public BalanceDTO fetchBalanceByAccount(String accountNumber) {
        log.info("Fetching balance from Finacle SOAP API for Account: {}", accountNumber);
        // Similar to Account Inquiry, build a balance inquiry request, call Feign,
        // parse XML.
        // For demonstration of the adapter structure, returning static mocked DTO here.
        return BalanceDTO.builder()
                .accountNumber(accountNumber)
                .effectiveAvailBalance(new BigDecimal("5000.00")) // Dummy SOAP balance
                .currency("INR")
                .build();
    }

    private String buildSoapRequest(String cifId, String reqId) {
        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">\n"
                +
                " <soapenv:Header/>\n" +
                " <soapenv:Body>\n" +
                "  <web:executeService>\n" +
                "   <arg_0_0><![CDATA[\n" +
                "   " + reqId + " executeFinacleScript 10.2 COR 2025-07-010T10:42:00.420 IBL0210CIFINQ.scr " + cifId
                + "\n" +
                "   ]]>\n" +
                "   </arg_0_0>\n" +
                "  </web:executeService>\n" +
                " </soapenv:Body>\n" +
                "</soapenv:Envelope>";
    }

    private List<AccountDTO> mapXmlToDto(String xmlResponse, String expectedCif) {
        List<AccountDTO> accounts = new ArrayList<>();
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(xmlResponse)));

            // Extract <AccountDetails> nodes
            NodeList accountNodes = doc.getElementsByTagName("AccountDetails");
            for (int i = 0; i < accountNodes.getLength(); i++) {
                Element accountElement = (Element) accountNodes.item(i);

                String accNum = getTagValue("AccountNumber", accountElement);
                String ccy = getTagValue("Currency", accountElement);
                String schemeDesc = getTagValue("SchemeDescription", accountElement);
                String schemeType = getTagValue("SchemeType", accountElement);
                String balanceStr = getTagValue("EffectiveAvailBalance", accountElement);

                accounts.add(AccountDTO.builder()
                        .cifId(expectedCif)
                        .accountNumber(accNum)
                        .currency(ccy)
                        .schemeDescription(schemeDesc)
                        .schemeType(schemeType)
                        .effectiveAvailBalance(balanceStr != null ? new BigDecimal(balanceStr) : BigDecimal.ZERO)
                        .build());
            }

        } catch (Exception e) {
            log.error("Failed to parse Finacle SOAP response", e);
            throw new RuntimeException("Failed to parse Finacle SOAP response: " + e.getMessage(), e);
        }
        return accounts;
    }

    private String getTagValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag);
        if (nodeList != null && nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        }
        return null;
    }

    private String getDummySoapResponse(String cifId) {
        StringBuilder accountsBuilder = new StringBuilder();
        for (int i = 1; i <= 5; i++) {
            String acctNum ="";
            if(cifId.length()>4){
                acctNum = cifId.substring(0,4);
            } else{
                acctNum = cifId;
            }
            accountsBuilder.append("<AccountDetails>")
                    .append("<AccountNumber>").append(acctNum).append("2541429").append(i).append("</AccountNumber>")
                    .append("<Currency>USD</Currency>")
                    .append("<SchemeDescription>TEST ACCOUNT ").append(i).append("</SchemeDescription>")
                    .append("<SchemeType>CAA</SchemeType>")
                    .append("<EffectiveAvailBalance>").append(1000 * i).append(".50</EffectiveAvailBalance>")
                    .append("</AccountDetails>");
        }

        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">"
                +
                "<soapenv:Body>" +
                "<dlwmin:executeServiceResponse xmlns:dlwmin=\"http://endpoint.fip.infosys.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                +
                "<FIXML xmlns=\"http://www.finacle.com/fixml\"><Body><executeFinacleScriptResponse><executeFinacleScript_CustomData>"
                +
                "<CifDetails><CIF_ID>" + cifId + "</CIF_ID></CifDetails>" +
                accountsBuilder.toString() +
                "</executeFinacleScript_CustomData></executeFinacleScriptResponse></Body></FIXML>" +
                "</dlwmin:executeServiceResponse>" +
                "</soapenv:Body></soapenv:Envelope>";
    }
}
