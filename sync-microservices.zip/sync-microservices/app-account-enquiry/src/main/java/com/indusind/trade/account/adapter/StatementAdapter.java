package com.indusind.trade.account.adapter;

import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;

import java.time.LocalDate;

public interface StatementAdapter {
	
    AccountStatementResponse fetchStatement(String accountNumber, String fromDate, String toDate);

    AccountStatementResponse fetchFullStatement(AccountStatementRequestDto requestDto, String continueToken);
}
