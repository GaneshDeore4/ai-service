package com.indusind.trade.account.adapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import com.indusind.app.jose.constant.InputType;
import com.indusind.app.jose.operations.JoseHelper;
import com.indusind.app.jose.operations.JoseUtility;
import com.indusind.trade.account.client.StatementFeignClient;
import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import com.indusind.trade.account.dto.request.IndusFullStatementRequest;
import com.indusind.trade.account.dto.request.IndusMiniStatementRequest;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.acc.adapter.type", havingValue = "json", matchIfMissing = true)
@RequiredArgsConstructor
public class StatementJsonAdapter implements StatementAdapter {

    private final StatementFeignClient statementFeignClient;
    private final ObjectMapper objectMapper;
    private final JoseHelper joseHelper;

    @org.springframework.beans.factory.annotation.Value("${ibl.client.id}")
    private String clientId;

    @org.springframework.beans.factory.annotation.Value("${ibl.client.secret}")
    private String clientSecret;

    @Override
    public AccountStatementResponse fetchStatement(String accountNumber, String fromDate, String toDate) {
        log.info("Fetching encrypted mini statement for Account: {} from {} to {}", accountNumber, fromDate, toDate);

        IndusMiniStatementRequest request = IndusMiniStatementRequest.builder()
                .requestUUID(java.util.UUID.randomUUID().toString())
                .channelID("COR") // Default value as seen in user trace
                .accountNo(accountNumber)
                .fromDate(fromDate)
                .toDate(toDate)
                .limit(10)
                .build();

        return callEncrypted("mini statement", request, statementFeignClient::fetchMiniStatement);
    }

    @Override
    public AccountStatementResponse fetchFullStatement(AccountStatementRequestDto requestDto, String continueToken) {
        log.info("Fetching encrypted full statement for Account: {} from {} to {}",
                requestDto.getAccountNo(), requestDto.getFromDate(), requestDto.getToDate());

        IndusFullStatementRequest request = IndusFullStatementRequest.builder()
                .requestUUID(requestDto.getRequestUUID())
                .channelID(requestDto.getChannelId() != null ? requestDto.getChannelId() : "COR")
                .accountNo(requestDto.getAccountNo())
                .fromDate(requestDto.getFromDate())
                .toDate(requestDto.getToDate())
                .build();

        return callEncrypted("full statement", request, statementFeignClient::fetchFullStatement);
    }

    private AccountStatementResponse callEncrypted(
            String label,
            Object plainRequest,
            EncryptedCall feignCall) {

        JoseUtility ju = joseHelper.getJoseUtility();

        try {
            String requestJson = objectMapper.writeValueAsString(plainRequest);
            log.info("Plain {} request: {}", label, requestJson);

            String encryptedEnvelope = ju.createIblGatewayRequestString(null, requestJson, InputType.STRING);
            log.debug("Encrypted {} envelope: {}", label, encryptedEnvelope);

            IBLGatewayResponse encryptedResponse = feignCall.call(clientId, clientSecret, encryptedEnvelope);

            if (encryptedResponse == null || encryptedResponse.getData() == null) {
                log.error("Empty encrypted response from bank for {}", label);
                return AccountStatementResponse.builder()
                        .successFlag(false)
                        .errorMessage("Empty response from bank")
                        .errorCode("EMPTY_RESPONSE")
                        .build();
            }

            return ju.getPayloadFromResponseObject(
                    null, encryptedResponse.getData(), AccountStatementResponse.class, InputType.STRING);

        } catch (FeignException e) {
            String errorBody = e.contentUTF8();
            log.error("Feign error calling encrypted {}. Status: {}, Body: {}", label, e.status(), errorBody);

            if (errorBody != null && !errorBody.trim().isEmpty()) {
                try {
                    IBLGatewayResponse errEnvelope = objectMapper.readValue(errorBody, IBLGatewayResponse.class);
                    if (errEnvelope.getData() != null) {
                        AccountStatementResponse errResp = ju.getPayloadFromResponseObject(
                                null, errEnvelope.getData(), AccountStatementResponse.class, InputType.STRING);
                        log.info("Decrypted {} error response: {}", label, errResp);
                        return errResp;
                    }
                    return objectMapper.readValue(errorBody, AccountStatementResponse.class);
                } catch (Exception parseEx) {
                    log.error("Failed to parse encrypted {} error body: {}", label, parseEx.getMessage());
                }
            }

            return AccountStatementResponse.builder()
                    .successFlag(false)
                    .errorMessage("Bank API error status " + e.status())
                    .errorCode(String.valueOf(e.status()))
                    .build();
        } catch (Exception ex) {
            log.error("Error in encrypted {} flow", label, ex);
            return AccountStatementResponse.builder()
                    .successFlag(false)
                    .errorMessage("Encryption/decryption failure: " + ex.getMessage())
                    .errorCode("ENC_FAIL")
                    .build();
        }
    }

    @FunctionalInterface
    private interface EncryptedCall {
        IBLGatewayResponse call(String clientId, String clientSecret, String encryptedEnvelope);
    }
}
