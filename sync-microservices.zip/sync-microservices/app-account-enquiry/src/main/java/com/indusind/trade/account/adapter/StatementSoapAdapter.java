package com.indusind.trade.account.adapter;

import com.indusind.trade.account.client.StatementFeignClient;
import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@Primary
@ConditionalOnProperty(name = "app.acc.adapter.type", havingValue = "soap")
@RequiredArgsConstructor
public class StatementSoapAdapter implements StatementAdapter {

    private final StatementFeignClient statementFeignClient;

    @Override
    public AccountStatementResponse fetchStatement(String accountNumber, String fromDate, String toDate) {
      
    	log.info("Fetching statement from SOAP API for Account: {} from {} to {}", accountNumber, fromDate, toDate);

//        try {
//            return statementFeignClient.fetchStatement(accountNumber, fromDate.toString(), toDate.toString(), true);
//        } catch (Exception e) {
//            log.error("Error calling actual SOAP statement API, falling back to mock data: {}", e.getMessage());
//        }

        return null;
    }

    @Override
    public AccountStatementResponse fetchFullStatement(AccountStatementRequestDto requestDto, String continueToken) {
        log.info("Fetching full statement from SOAP API (Not implemented)");
        return null;
    }

    private AccountStatementDTO getMockStatement(String accountNumber, LocalDate fromDate, LocalDate toDate) {
        List<AccountTransactionDTO> transactions = new ArrayList<>();
        
        // Generate 5 mock transactions spread between fromDate and toDate
        long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(fromDate, toDate);
        if (daysBetween < 0) daysBetween = 0;

        for (int i = 0; i < 5; i++) {
            LocalDate tranDate = fromDate.plusDays(i % (daysBetween + 1));
            transactions.add(AccountTransactionDTO.builder()
                    .tranDate(tranDate.toString())
                    .valueDate(tranDate.toString())
                    .postingTime(tranDate.atStartOfDay().toString())
                    .tranId("TXN-SOAP-" + (2000 + i))
                    .debitOrCredit(i % 3 == 0 ? "D" : "C")
                    .particulars("SOAP Mock Transaction " + i)
                    .remarks("SOAP Test remark for " + accountNumber)
                    .currency("INR")
                    .amount(new BigDecimal(150 * (i + 1)))
                    .balance(new BigDecimal(60000 + (i % 3 == 0 ? -150 * (i + 1) : 150 * (i+1))))
                    .build());
        }

        return AccountStatementDTO.builder()
                .version("V1")
                .accountId(accountNumber)
                .currency("INR")
                .name("SOAP TEST USER")
                .ledgerBalance(new BigDecimal("60000.00"))
                .transactions(transactions)
                .build();
    }
}
