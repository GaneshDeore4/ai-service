package com.indusind.trade.account.client;

import com.indusind.trade.account.config.FeignConfig;
import com.indusind.trade.account.dto.json.SyncAccountJsonResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "bankJsonClient", url = "${app.feign.json-bank.url}", configuration = FeignConfig.class)
public interface BankJsonFeignClient {

    @GetMapping("/accountnumber/V5"
    		+ "Content-Type: application/json")
    List<SyncAccountJsonResponse> fetchAccounts(@RequestParam("cifId") String cifId);
}
