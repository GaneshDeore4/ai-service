package com.indusind.trade.account.client;

import com.indusind.app.jose.domain.response.IBLGatewayResponse;
import com.indusind.trade.account.config.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "singleAccountClient", url = "${app.feign.json-bank.url}", configuration = FeignConfig.class)
public interface SingleAccountDetailsFeignClient {

    @PostMapping(value = "/accountnumber/V5",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    IBLGatewayResponse getAccountDetails(@RequestHeader("IBL-Client-Id") String clientID,
                                    @RequestHeader("IBL-Client-Secret") String clientSecret,
                                    @RequestBody String encryptedEnvelope);
}
