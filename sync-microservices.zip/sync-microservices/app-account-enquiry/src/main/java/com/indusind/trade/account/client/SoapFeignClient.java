package com.indusind.trade.account.client;

import com.indusind.trade.account.config.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client for Finacle SOAP Integration.
 */
@FeignClient(name = "finacleSoapClient", url = "${app.feign.finacle.url}", configuration = FeignConfig.class)
public interface SoapFeignClient {

    @PostMapping(consumes = MediaType.TEXT_XML_VALUE, produces = MediaType.TEXT_XML_VALUE)
    String executeFinacleScript(@RequestBody String soapRequest);
}
