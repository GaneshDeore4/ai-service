package com.indusind.trade.account.controller;

import com.indusind.trade.account.dto.ApplicationResponse;
import com.indusind.trade.account.service.AccountService;
import com.indusind.trade.account.entity.AccountDetail;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
public class AccountController {

    private final AccountService accountService;

    @PostMapping("/sync/{cifId}")
    public ResponseEntity<ApplicationResponse> syncAccounts(@PathVariable String cifId) {
        log.info("REST request to sync accounts for CIF: {}", cifId);
        List<AccountDetail> syncedAccounts = accountService.syncAccounts(cifId);
        return ResponseEntity.ok(new ApplicationResponse("SUCCESS", syncedAccounts, "Accounts synced successfully"));
    }

    @GetMapping("/cif/{cifId}")
    public ResponseEntity<ApplicationResponse> getAccountsByCif(@PathVariable String cifId) {
        log.info("REST request to get local accounts for CIF: {}", cifId);
        List<AccountDetail> accounts = accountService.getAccountsByCif(cifId);
        return ResponseEntity.ok(new ApplicationResponse("SUCCESS", accounts, "Accounts fetched successfully"));
    }

    @PostMapping("/sync-balance/{accountNumber}")
    public ResponseEntity<ApplicationResponse> syncBalance(@PathVariable String accountNumber) {
        log.info("REST request to sync balance for Account: {}", accountNumber);
        AccountDetail syncedBalance = accountService.syncBalance(accountNumber);
        return ResponseEntity.ok(new ApplicationResponse("SUCCESS", syncedBalance, "Balance synced successfully"));
    }

    @GetMapping("/balance/{accountNumber}")
    public ResponseEntity<ApplicationResponse> getBalanceByAccount(@PathVariable String accountNumber) {
        log.info("REST request to get local balance for Account: {}", accountNumber);
        return accountService.getAccountByNumber(accountNumber)
                .map(acc -> ResponseEntity.ok(new ApplicationResponse("SUCCESS", acc, "Balance fetched successfully")))
                .orElse(ResponseEntity.notFound().build());
    }
}
