package com.indusind.trade.account.controller;


import com.indusind.trade.account.dto.request.AccountDetailsRequest;
import com.indusind.trade.account.dto.response.AccountDetailsResponseDTO;
import com.indusind.trade.account.service.AccountDetailService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/accounts")

public class AccountDetailsController {


    private final AccountDetailService accountDetailService;

    public AccountDetailsController(AccountDetailService accountDetailService) {
        this.accountDetailService = accountDetailService;
    }

    @PostMapping("/detail")
    public ResponseEntity<AccountDetailsResponseDTO> getAccountDetails(@RequestBody AccountDetailsRequest request) {
        AccountDetailsResponseDTO response = accountDetailService.getAccountDetails(request);
        return ResponseEntity.ok(response);
    }

}
