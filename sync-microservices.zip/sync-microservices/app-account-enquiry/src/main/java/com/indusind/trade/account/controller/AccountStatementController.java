package com.indusind.trade.account.controller;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.indusind.trade.account.dto.ApplicationResponse;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import com.indusind.trade.account.facade.AccountStatementEnqFacade;
import com.indusind.trade.account.service.StatementService;
import com.indusind.trade.account.entity.AccountTransaction;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/statements")
@RequiredArgsConstructor
public class AccountStatementController {

    private final StatementService statementService;
    private final AccountStatementEnqFacade accountStatementEnqFacade;

    @GetMapping("/sync/{accountNumber}")
    public ResponseEntity<ApplicationResponse> syncStatement(
            @PathVariable String accountNumber,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(required = false) String debitOrCredit,
            @RequestParam(required = false) String tranId)
    {
        log.info("REST request to sync statement for account: {} from {} to {}", accountNumber, fromDate, toDate);
        AccountStatementDTO syncResult = statementService.syncStatement(accountNumber, fromDate, toDate, debitOrCredit, tranId);

        if(syncResult.getErrorCode() != null){
            return ResponseEntity.ok(new ApplicationResponse("FAIL", syncResult, syncResult.getErrorMessage()));
        }
        return ResponseEntity.ok(new ApplicationResponse("SUCCESS", syncResult, "Statement synced successfully"));
    }

    @PostMapping("/fetchMiniStatement")
    public ResponseEntity<ApplicationResponse> fetchMiniStatement(@RequestBody AccountStatementRequestDto requestDto){
        log.info("REST request for mini statement:{}", requestDto);
        
        LocalDate fromDate = (requestDto.getFromDate() != null) ? LocalDate.parse(requestDto.getFromDate()) : null;
        LocalDate toDate   = (requestDto.getToDate() != null)   ? LocalDate.parse(requestDto.getToDate())   : null;
        
        AccountStatementDTO result = statementService.syncStatement(requestDto.getAccountNo(), fromDate, toDate, null, null);

        String status = (result.getErrorCode() != null) ? "FAIL" : "SUCCESS";
        return ResponseEntity.ok(new ApplicationResponse(status, result, status.equals("SUCCESS") ? "Fetched successfully" : result.getErrorMessage()));
    }

    @PostMapping("/fetchAccountStatement")
    public ResponseEntity<ApplicationResponse> fetchStatement(@RequestBody AccountStatementRequestDto requestDto, @RequestParam(required = false) String continueToken, @RequestParam(required = false) String debitOrCredit,
                                                              @RequestParam(required = false) String tranId){
        log.info("request:{}", requestDto);
        AccountStatementDTO syncResult = accountStatementEnqFacade.fetchStatement(requestDto, continueToken, debitOrCredit, tranId);
        String status = (syncResult.getErrorCode() != null) ? "FAIL" : "SUCCESS";
        return ResponseEntity.ok(new ApplicationResponse(status, syncResult, status.equals("SUCCESS") ? "Fetched successfully" : syncResult.getErrorMessage()));
    }


}
