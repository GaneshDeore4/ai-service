package com.indusind.trade.account.controller;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.service.PdfExportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

@Slf4j
@RestController
@RequestMapping("/api/statements/download")
@RequiredArgsConstructor
public class AccountStatementDownloadController {

    private final PdfExportService pdfService;

    @PostMapping("/pdf")
    public ResponseEntity<StreamingResponseBody> downloadPdf(@RequestBody AccountStatementDTO statement) {
        log.info("Request to download PDF statement for account: {}", statement.getAccountId());
        
        StreamingResponseBody responseBody = pdfService.generateStatement(statement);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", "Statement_" + statement.getAccountId() + ".pdf");
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        return ResponseEntity.ok()
                .headers(headers)
                .body(responseBody);
    }
}
