package com.indusind.trade.account.controller;


import com.indusind.trade.account.dto.ApplicationResponse;
import com.indusind.trade.account.dto.request.BalanceEnquiryRequestDto;
import com.indusind.trade.account.facade.BalanceEnquiryFacade;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
public class BalanceEnquiryController {

    private final BalanceEnquiryFacade balanceEnquiryFacade;

    @GetMapping("/balance-enquiry")
    public ResponseEntity<ApplicationResponse> getBalanceEnquiry(@RequestBody BalanceEnquiryRequestDto request) {
        ApplicationResponse response = balanceEnquiryFacade.getBalanceEnquiry(request);
        return ResponseEntity.ok().body(response);
    }

}
