package com.indusind.trade.account.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountDTO {
    private String cifId;
    private String accountNumber;
    private String currency;
    private String schemeDescription;
    private String schemeType;
    private BigDecimal effectiveAvailBalance;
    private Date insertDate;
}
