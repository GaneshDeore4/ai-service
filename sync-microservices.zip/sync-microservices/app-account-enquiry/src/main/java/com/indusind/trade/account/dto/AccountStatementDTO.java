package com.indusind.trade.account.dto;

import com.indusind.trade.account.dto.request.ContinueTokenDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountStatementDTO {
    private String version;
    private String accountId;
    private String acid;
    private String currency;
    private String name;
    private String shortName;
    private String schemeCode;
    private String schemeType;
    private String solId;
    private String cifId;
    private String sysBehaviorCode;
    private BigDecimal ledgerBalance;
    private BigDecimal availableBalance;
    private BigDecimal effAvailableBalance;
    private BigDecimal ffdBalance;
    private BigDecimal lienAmt;
    private BigDecimal clearBalance;
    private String freezeCode;
    private String activeStatus;
    private Integer nextTranSrlNum;
    private Long timeStampCount;
    private String lastChangeTime;
    private String lastCreditDate;
    private String lastDebitDate;
    private BigDecimal closingBalance;
    private List<AccountTransactionDTO> transactions;
    private ContinueTokenDTO continueToken;
    private String errorMessage;
    private String errorCode;
    private boolean successFlag = true;
}
