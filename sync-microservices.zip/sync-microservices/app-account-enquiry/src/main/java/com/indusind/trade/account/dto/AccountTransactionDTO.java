package com.indusind.trade.account.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountTransactionDTO {
    private String tranDate;
    private String valueDate;
    private String postingTime;
    private String tranId;
    private String tranSrlNum;
    private String tranType;
    private String reversalStatus;
    private String tranSubType;
    private String debitOrCredit;
    private String particulars;
    private String particulars2;
    private String particularCode;
    private String reportCode;
    private String remarks;
    private String moduleId;
    private String uadModuleId;
    private String uadModuleKey;
    private String currency;
    private BigDecimal amount;
    private BigDecimal balance;
}
