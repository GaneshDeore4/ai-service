package com.indusind.trade.account.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BalanceDTO {
    private String accountNumber;
    private BigDecimal effectiveAvailBalance;
    private String currency;
}
