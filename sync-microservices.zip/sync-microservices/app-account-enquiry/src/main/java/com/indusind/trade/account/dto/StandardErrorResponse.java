package com.indusind.trade.account.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StandardErrorResponse {
    private String timestamp;
    private String service;
    private String errorCode;
    private String message;
    private String correlationId;
}
