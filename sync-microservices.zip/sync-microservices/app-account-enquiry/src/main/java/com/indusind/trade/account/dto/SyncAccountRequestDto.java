package com.indusind.trade.account.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SyncAccountRequestDto {

    @JsonProperty("cifid")
    private String cifId;

}
