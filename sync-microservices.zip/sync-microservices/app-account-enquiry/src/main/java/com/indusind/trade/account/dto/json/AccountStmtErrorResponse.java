package com.indusind.trade.account.dto.json;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountStmtErrorResponse {

    private String version;
    private String accountId;
    private String errorMessage;
    private String errorCode;
}
