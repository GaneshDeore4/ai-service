package com.indusind.trade.account.dto.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountStmtTransResponse {
    private String tranDate;
    private String valueDate;
    private String postingTime;
    private String tranId;
    private String tranSrlNum;
    private String tranType;
    private String reversalStatus;
    private String tranSubType;
    private String debitOrCredit;
    private String particulars;
    private String particulars2;
    private String particularCode;
    private String reportCode;
    private String remarks;
    private String moduleId;
    private String uadModuleId;
    private String uadModuleKey;
    private String currency;
    private BigDecimal amount;
    private BigDecimal balance;
    private String glDate;
    private String instrumentNumber;
}
