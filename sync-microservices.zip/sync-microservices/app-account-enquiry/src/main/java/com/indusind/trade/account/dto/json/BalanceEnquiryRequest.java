package com.indusind.trade.account.dto.json;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BalanceEnquiryRequest {
    private String requestUUID;
    private String channelID;
    private String accountNo;
}
