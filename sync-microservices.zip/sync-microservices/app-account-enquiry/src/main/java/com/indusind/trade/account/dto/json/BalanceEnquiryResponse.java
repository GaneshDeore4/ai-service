package com.indusind.trade.account.dto.json;

import lombok.*;
import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BalanceEnquiryResponse {
    private String version;
    private String accountId;
    private String acid;
    private String currency;
    private String name;
    private String shortName;
    private String schemeCode;
    private String schemeType;
    private String solId;
    private String cifId;
    private String sysBehaviorCode;
    private BigDecimal ledgerBalance;
    private BigDecimal availableBalance;
    private BigDecimal effAvailableBalance;
    private BigDecimal ffdBalance;
    private BigDecimal lienAmt;
    private BigDecimal clearBalance;
    private String freezeCode;
    private String activeStatus;
    private Integer nextTranSrlNum;
    private Integer timeStampCount;
    private String lastChangeTime;
    private String lastCreditDate;
    private String lastDebitDate;
    private String acctOpnDate;
    private String acctClsFlg;
    private String businessDate;
}
