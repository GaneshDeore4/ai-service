package com.indusind.trade.account.dto.json;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JsonAccountResponse {
    private String cifId;
    private String acctId;
    private String crncy;
    private String schemeDesc;
    private String schemeType;
    private String balance;
}
