package com.indusind.trade.account.dto.json;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.indusind.trade.model.dtos.requestdtos.AccountDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SyncAccountJsonResponse {

        private String country;
        private String city;
        private String mobileNumber;
        private String ppExpiryDate;
        private String emailId;
        private String reqid;
        private String ppDocDesc;
        private String customerType;
        private String industryType;
        private String countryCode;
        private String segment;
        private String ppIssueDate;
        private String state;
        private String pan;
        private String landmark;
        private String cifId;
        private String ppRefNo;
        private String channelSource;
        private String pincode;
        private String ppDocTypeCode;

        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime DOBorDOI;

        private String gstIn;
        private String customerName;
        private String keyContactPerson;
        private String subsegment;
        private String addressline1;
        private String addressline2;
        private String addressline3;

        private List<SyncAccountJson> accounts;

        private String ppDocCode;
        private String primaryRMName;
        private String ppDocTypeDesc;
        private String statusCode;

}
