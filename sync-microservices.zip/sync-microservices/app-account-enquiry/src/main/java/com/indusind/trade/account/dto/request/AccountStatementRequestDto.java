package com.indusind.trade.account.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountStatementRequestDto {
    private String requestUUID;
    private String channelId;
    private String accountNo;
    private String fromDate;
    private String toDate;
    private String limit;
}
