package com.indusind.trade.account.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(setterPrefix = "set")
public class BalanceEnquiryRequestDto {

    @Builder.Default private String channelId = "COR";

    private String requestUUID;

    private String cifId;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    @Builder.Default
    private LocalDateTime messageDateTime = LocalDateTime.now();

}
