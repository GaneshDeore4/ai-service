package com.indusind.trade.account.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContinueTokenDTO {

    private String tranDate;
    private String pstdDate;
    private String tranId;
    private String partTranSrlNum;
    private String tableType;
    private String ledgBal;
    private String clrBalAmt;

}
