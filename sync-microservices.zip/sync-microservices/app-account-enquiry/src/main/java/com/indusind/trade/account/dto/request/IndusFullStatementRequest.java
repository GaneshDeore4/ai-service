package com.indusind.trade.account.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IndusFullStatementRequest {
    private String requestUUID;
    @JsonProperty("channelID")
    private String channelID;
    private String accountNo;
    private String fromDate;
    private String toDate;
    private Integer limit;
    private String continueToken;
}
