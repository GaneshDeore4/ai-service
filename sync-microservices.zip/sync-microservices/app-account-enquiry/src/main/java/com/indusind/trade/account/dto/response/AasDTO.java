package com.indusind.trade.account.dto.response;

import lombok.Data;

@Data
public class AasDTO {


    private String cifId;
    private String modeofOperation;

}
