package com.indusind.trade.account.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class AcctInfo {
    private String AvailableAmt;
    private String acctCrncyCode;
    private String schemeType;
    private String acctNum;
    private String acctName;
}
