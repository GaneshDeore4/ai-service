package com.indusind.trade.account.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Builder
@Getter
@Setter
public class BalanceEnquiryResponseDto {

    private List<AcctInfo> cifInfo;
    private Long numberOfAccounts;
    private String sucFaiFlag;
    private String message;
    private String errorCode;
    private String errorDesc;

}
