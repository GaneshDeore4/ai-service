package com.indusind.trade.account.entity;

import com.indusind.trade.account.entity.CryptoConverter;
import com.indusind.trade.model.entities.HashField;
import com.indusind.trade.account.entity.HashListener;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "account_transactions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EntityListeners(HashListener.class)
public class AccountTransaction {

    @Id
    @GeneratedValue
    @UuidGenerator
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @com.fasterxml.jackson.annotation.JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "statement_id")
    private AccountStatement statement;

    @Column(name = "account_number")
    @Convert(converter = CryptoConverter.class)
    @HashField
    private String accountNumber;

    @Column(name = "account_number_hash")
    private String accountNumberHash;

    @Column(name = "tran_date")
    private LocalDate tranDate;

    @Column(name = "value_date")
    private LocalDate valueDate;

    @Column(name = "posting_time")
    private LocalDateTime postingTime;

    @Column(name = "tran_id")
    private String tranId;

    @Column(name = "tran_type")
    private String tranType;

    @Column(name = "debit_or_credit")
    private String debitOrCredit;

    @Column(name = "particulars")
    private String particulars;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "currency")
    private String currency;

    @Column(name = "amount", precision = 19, scale = 4)
    private BigDecimal amount;

    @Column(name = "balance", precision = 19, scale = 4)
    private BigDecimal balance;
}
