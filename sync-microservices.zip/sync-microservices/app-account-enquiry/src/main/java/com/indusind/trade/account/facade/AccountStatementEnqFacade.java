package com.indusind.trade.account.facade;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;

public interface AccountStatementEnqFacade {

    AccountStatementDTO fetchStatement(AccountStatementRequestDto accountStatementRequestDto, String continueToken, String debitOrCredit, String tranId);
}
