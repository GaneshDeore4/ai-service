package com.indusind.trade.account.facade;

import com.indusind.trade.account.dto.ApplicationResponse;
import com.indusind.trade.account.dto.request.BalanceEnquiryRequestDto;

public interface BalanceEnquiryFacade {

    ApplicationResponse getBalanceEnquiry(BalanceEnquiryRequestDto request);

}
