package com.indusind.trade.account.facade.impl;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import com.indusind.trade.account.facade.AccountStatementEnqFacade;
import com.indusind.trade.account.service.StatementService;
import com.indusind.trade.account.util.AccountStatementMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class AccountStatementEnqFacadeImpl implements AccountStatementEnqFacade {

    private final StatementService statementService;
    private final AccountStatementMapper accountStatementMapper;

    @Override
    public AccountStatementDTO fetchStatement(
            AccountStatementRequestDto accountStatementRequestDto,
            String continueToken,
            String debitOrCredit,
            String tranId) {

        AccountStatementDTO accountStatementDTO =
                statementService.fetchFullStatement(accountStatementRequestDto, continueToken);

        if (!accountStatementDTO.isSuccessFlag()) {
            log.info("API Error: {}:{}", accountStatementDTO.getErrorCode(), accountStatementDTO.getErrorMessage());
            return accountStatementDTO;
        }

        if (debitOrCredit != null || tranId != null) {
            accountStatementDTO.setTransactions(
                    filterTransactionResponse(accountStatementDTO.getTransactions(), debitOrCredit, tranId));
        }

        return accountStatementDTO;
    }

    private List<AccountTransactionDTO> filterTransactionResponse(
            List<AccountTransactionDTO> transactions,
            String debitOrCredit,
            String tranId) {

        return transactions.stream()
                .filter(tran ->
                        (debitOrCredit == null || debitOrCredit.equalsIgnoreCase(tran.getDebitOrCredit().strip()))
                                && (tranId == null || tranId.equalsIgnoreCase(tran.getTranId().strip())))
                .toList();
    }
}
