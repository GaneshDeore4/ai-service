 package com.indusind.trade.account.facade.impl;

 import com.indusind.trade.account.dto.ApplicationResponse;
 import com.indusind.trade.account.dto.request.BalanceEnquiryRequestDto;
 import com.indusind.trade.account.dto.response.BalanceEnquiryResponseDto;
 import com.indusind.trade.account.facade.BalanceEnquiryFacade;
 import com.indusind.trade.account.service.BalanceEnquiryService;
 import com.indusind.trade.account.service.SoapTransformationService;
 import com.indusind.trade.model.exception.GTPAppException;
 import lombok.RequiredArgsConstructor;
 import lombok.extern.slf4j.Slf4j;
 import org.springframework.stereotype.Component;

 @Slf4j
 @Component
 @RequiredArgsConstructor
 public class SoapBalanceEnquiryFacadeImpl implements BalanceEnquiryFacade {

     private final SoapTransformationService soapTransformationService;
     private final BalanceEnquiryService balanceEnquiryService;

     @Override
     public ApplicationResponse getBalanceEnquiry(BalanceEnquiryRequestDto request) {
         try {

             String soapReq = soapTransformationService.convertBalanceEnqReqToSoapReq(request);

             String soapRes = balanceEnquiryService.getBalanceEnquiry(soapReq);

             log.info("api response: " + soapRes);

             BalanceEnquiryResponseDto response = soapTransformationService.convertSoapResToBalanceEnqRes(soapRes);

             return new ApplicationResponse("SUCCESS", response, "data fetched");

         } catch(Exception e) {
             throw new GTPAppException("Something went wrong: " + e, null);
         }
     }
 }
