package com.indusind.trade.account.repository;

import com.indusind.trade.account.entity.AccountAudit;
import com.indusind.trade.account.utils.HashUtils;import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountAuditRepository extends JpaRepository<AccountAudit, Long> {
    default List<AccountAudit> findByAccountNumber(String accountNumber) {
        return findByAccountNumberHash(HashUtils.HAMCMD5Hash(accountNumber));
    }
    List<AccountAudit> findByAccountNumberHash(String accountNumber);
    default List<AccountAudit> findByCifId(String cifId) {
        return findByCifIdHash(HashUtils.HAMCMD5Hash(cifId));
    }
    List<AccountAudit> findByCifIdHash(String cifId);
}
