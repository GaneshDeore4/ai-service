package com.indusind.trade.account.repository;

import com.indusind.trade.account.utils.HashUtils;import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.indusind.trade.account.entity.AccountDetail;

import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<AccountDetail, String> {

    default List<AccountDetail> findByCifId(String cifId) {
        return findByCifIdHash(HashUtils.HAMCMD5Hash(cifId));
    }

    List<AccountDetail> findByCifIdHash(String cifId);

    default Optional<AccountDetail> findByAccountNumber(String accountNumber) {
        return findByAccountNumberHash(HashUtils.HAMCMD5Hash(accountNumber));
    }

    Optional<AccountDetail> findByAccountNumberHash(String accountNumber);
}
