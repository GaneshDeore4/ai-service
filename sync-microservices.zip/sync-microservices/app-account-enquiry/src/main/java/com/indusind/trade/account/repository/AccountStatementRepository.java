package com.indusind.trade.account.repository;

import com.indusind.trade.account.entity.AccountStatement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AccountStatementRepository extends JpaRepository<AccountStatement, String> {
    Optional<AccountStatement> findByAccountId(String accountId);
}
