package com.indusind.trade.account.repository;

import com.indusind.trade.account.entity.AccountTransaction;
import com.indusind.trade.account.utils.HashUtils;import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountTransactionRepository extends JpaRepository<AccountTransaction, String>, JpaSpecificationExecutor<AccountTransaction> {
    default List<AccountTransaction> findByAccountNumber(String accountNumber) {
        return findByAccountNumberHash(HashUtils.HAMCMD5Hash(accountNumber));
    }

    List<AccountTransaction> findByAccountNumberHash(String accountNumber);
}
