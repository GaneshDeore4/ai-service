package com.indusind.trade.account.security;

import java.io.IOException;
import java.security.Key;
import java.util.Collections;

import org.slf4j.MDC;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JwtTokenValidatorFilter extends OncePerRequestFilter {

    private final String jwtSecret;

    public JwtTokenValidatorFilter(String jwtSecret) {
        this.jwtSecret = jwtSecret;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = header.substring(7);
        try {
            javax.crypto.SecretKey key = Keys.hmacShaKeyFor(io.jsonwebtoken.io.Decoders.BASE64.decode(jwtSecret));
            Claims claims = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            String loginId = claims.get("loginId", String.class);
            String role = claims.get("role", String.class);
            String sessionId = claims.get("sessionId", String.class);
            Object companyIdObj = claims.get("companyId");
            Long companyId = companyIdObj != null ? ((Number) companyIdObj).longValue() : null;

            if (loginId != null && role != null) {
                // Populate request attributes for audit tracking
                request.setAttribute("currentLoginId", loginId);
                request.setAttribute("currentRole", role);
                request.setAttribute("currentSessionId", sessionId);
                request.setAttribute("currentCompanyId", companyId);

                // Populate SLF4J MDC for logging
                MDC.put("loginId", loginId);
                MDC.put("role", role);
                MDC.put("sessionId", sessionId != null ? sessionId : "");

                String grantedRole = role.startsWith("ROLE_") ? role : "ROLE_" + role;

                // Create the common UserPrincipal instead of casting blindly
                UserPrincipal principal = new UserPrincipal(loginId, role);

                UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
                        principal, null, Collections.singletonList(new SimpleGrantedAuthority(grantedRole)));

                SecurityContextHolder.getContext().setAuthentication(auth);
            }
        } catch (Exception e) {
            System.err.println("JWT Token Validation Failed: " + e.getMessage());
            SecurityContextHolder.clearContext();
        }

        try {
            filterChain.doFilter(request, response);
        } finally {
            // Memory cleanup inside CorrelationIdFilter, so we don't clear MDC here.
        }
    }
}
