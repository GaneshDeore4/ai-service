package com.indusind.trade.account.service;

import com.indusind.trade.account.dto.request.AccountDetailsRequest;
import com.indusind.trade.account.dto.request.AccountDetailsRequest;
import com.indusind.trade.account.dto.response.AccountDetailsResponseDTO;

public interface AccountDetailService {


    AccountDetailsResponseDTO getAccountDetails(AccountDetailsRequest accountEnquiryRequestDTO) ;
}
