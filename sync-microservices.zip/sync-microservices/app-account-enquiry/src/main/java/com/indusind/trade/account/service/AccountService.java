package com.indusind.trade.account.service;


import com.indusind.trade.account.entity.AccountDetail;

import java.util.List;
import java.util.Optional;

public interface AccountService {
    
    List<AccountDetail> syncAccounts(String cifId);
    
    AccountDetail syncBalance(String accountNumber);
    
    List<AccountDetail> getAccountsByCif(String cifId);
    
    Optional<AccountDetail> getAccountByNumber(String accountNumber);
}
