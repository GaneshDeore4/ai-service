/* 
package com.indusind.trade.account.service;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.util.List;

@Service
public class AccountStatementPdfService {

    public byte[] generateStatement(AccountStatementDTO statement) {
        Document document = new Document(PageSize.A4);
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Fonts
            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, Color.RED);
            Font subHeaderFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, Color.BLACK);
            Font normalFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Color.BLACK);
            Font tableHeaderFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.WHITE);

            // Header - Bank Logo / Name
            Paragraph bankName = new Paragraph("IndusInd Bank", headerFont);
            bankName.setAlignment(Element.ALIGN_RIGHT);
            document.add(bankName);

            document.add(new Paragraph("Account Statement", subHeaderFont));
            document.add(Chunk.NEWLINE);

            // Account Details Information
            PdfPTable detailsTable = new PdfPTable(2);
            detailsTable.setWidthPercentage(100);
            detailsTable.setSpacingBefore(10f);
            detailsTable.setSpacingAfter(20f);

            addDetailCell(detailsTable, "Account Number:", statement.getAccountId(), normalFont);
            addDetailCell(detailsTable, "Account Holder:", statement.getName(), normalFont);
            addDetailCell(detailsTable, "Currency:", statement.getCurrency(), normalFont);
            addDetailCell(detailsTable, "Available Balance:", String.valueOf(statement.getAvailableBalance()), normalFont);

            document.add(detailsTable);

            // Transactions Table
            PdfPTable table = new PdfPTable(5); // 5 columns as requested
            table.setWidthPercentage(100);
            table.setWidths(new float[]{15f, 15f, 10f, 15f, 45f});

            // Table Headers
            String[] headers = {"Tran Date", "Tran ID", "Type", "Amount", "Remarks"};
            for (String header : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(header, tableHeaderFont));
                cell.setBackgroundColor(Color.DARK_GRAY);
                cell.setPadding(5);
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cell);
            }

            // Table Body
            List<AccountTransactionDTO> transactions = statement.getTransactions();
            if (transactions != null) {
                for (AccountTransactionDTO tran : transactions) {
                    table.addCell(createCell(tran.getTranDate(), normalFont));
                    table.addCell(createCell(tran.getTranId(), normalFont));
                    table.addCell(createCell(tran.getDebitOrCredit(), normalFont));
                    table.addCell(createCell(String.valueOf(tran.getAmount()), normalFont));
                    // Using particulars as Remarks as per mapping
                    table.addCell(createCell(tran.getParticulars(), normalFont));
                }
            }

            document.add(table);
            document.close();

        } catch (DocumentException e) {
            e.printStackTrace();
        }

        return out.toByteArray();
    }

    private void addDetailCell(PdfPTable table, String label, String value, Font font) {
        PdfPCell labelCell = new PdfPCell(new Phrase(label, font));
        labelCell.setBorder(Rectangle.NO_BORDER);
        table.addCell(labelCell);

        PdfPCell valueCell = new PdfPCell(new Phrase(value != null ? value : "N/A", font));
        valueCell.setBorder(Rectangle.NO_BORDER);
        table.addCell(valueCell);
    }

    private PdfPCell createCell(String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text != null ? text : "", font));
        cell.setPadding(5);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }
}
*/
