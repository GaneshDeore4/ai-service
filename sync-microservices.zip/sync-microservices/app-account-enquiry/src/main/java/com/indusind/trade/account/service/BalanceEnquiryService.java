package com.indusind.trade.account.service;

public interface BalanceEnquiryService {

    String getBalanceEnquiry(String request);

}
