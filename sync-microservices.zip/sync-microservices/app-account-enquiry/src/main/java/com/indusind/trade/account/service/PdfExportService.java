package com.indusind.trade.account.service;

import com.indusind.trade.account.dto.AccountStatementDTO;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

public interface PdfExportService {
    StreamingResponseBody generateStatement(AccountStatementDTO statement);
}
