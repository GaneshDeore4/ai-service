package com.indusind.trade.account.service;

import com.indusind.trade.account.dto.request.BalanceEnquiryRequestDto;
import com.indusind.trade.account.dto.response.BalanceEnquiryResponseDto;

public interface SoapTransformationService {

    String convertBalanceEnqReqToSoapReq(BalanceEnquiryRequestDto request);

    BalanceEnquiryResponseDto convertSoapResToBalanceEnqRes(String response);

}
