package com.indusind.trade.account.service;

import java.time.LocalDate;
import java.util.List;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import com.indusind.trade.account.entity.AccountTransaction;

public interface StatementService {
	
    AccountStatementDTO syncStatement(String accountNumber, LocalDate fromDate, LocalDate toDate, String debitOrCredit, String tranId);
    
    List<AccountTransaction> filterTransactions(String accountNumber,
                                              LocalDate startDate,
                                              LocalDate endDate,
                                              String refNumber,
                                              String tranType);

    AccountStatementDTO fetchFullStatement(AccountStatementRequestDto requestDto, String continueToken);
}
