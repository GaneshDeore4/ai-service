package com.indusind.trade.account.service;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;

public class TestStatements {

    private static void trustAllSSL() throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                }
        };

        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());

        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
    }

    public static void main(String[] args) {
        try {
            trustAllSSL();

            String urlStr = "https://coreuatj2ee2.ibl.com:50000/fiwebservice/services/FIPWebService";

            String soapRequest =
                    "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                            + "xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">"
                            + "<soapenv:Header/>"
                            + "<soapenv:Body>"
                            + "<web:executeService>"
                            + "<arg_0_0><![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                            + "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml modelDeposit.xsd\" "
                            + "xmlns=\"http://www.finacle.com/fixml\" "
                            + "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                            + "<Header>"
                            + "<RequestHeader>"
                            + "<MessageKey>"
                            + "<RequestUUID>Req_14300rr6rgr13</RequestUUID>"
                            + "<ServiceRequestId>modelDeposit</ServiceRequestId>"
                            + "<ServiceRequestVersion>10.2</ServiceRequestVersion>"
                            + "<ChannelId>COR</ChannelId>"
                            + "<LanguageId></LanguageId>"
                            + "</MessageKey>"
                            + "<RequestMessageInfo>"
                            + "<BankId></BankId>"
                            + "<TimeZone></TimeZone>"
                            + "<EntityId></EntityId>"
                            + "<EntityType></EntityType>"
                            + "<ArmCorrelationId></ArmCorrelationId>"
                            + "<MessageDateTime>2021-2-23T12:8:51.604</MessageDateTime>"
                            + "</RequestMessageInfo>"
                            + "<Security>"
                            + "<Token><PasswordToken><UserId></UserId><Password></Password></PasswordToken></Token>"
                            + "<FICertToken></FICertToken>"
                            + "<RealUserLoginSessionId></RealUserLoginSessionId>"
                            + "<RealUser></RealUser>"
                            + "<RealUserPwd></RealUserPwd>"
                            + "<SSOTransferToken></SSOTransferToken>"
                            + "</Security>"
                            + "</RequestHeader>"
                            + "</Header>"
                            + "<Body>"
                            + "<modelDepositRequest>"
                            + "<ModelDepMsg>"
                            + "<currencyCode>INR</currencyCode>"
                            + "<daysInAYear></daysInAYear>"
                            + "<depositAmount><amountValue>100000</amountValue><currencyCode>INR</currencyCode></depositAmount>"
                            + "<depositDate>2026-02-17T12:8:51.605</depositDate>"
                            + "<depositPeriod><days>0</days><months>12</months></depositPeriod>"
                            + "<depositType>T</depositType>"
                            + "<flowType>N</flowType>"
                            + "<interestCode><tableCode></tableCode></interestCode>"
                            + "<monthsInAYear></monthsInAYear>"
                            + "<pegFlag>Y</pegFlag>"
                            + "<schemeDetails><schmCode>TSFXM</schmCode><schmType></schmType></schemeDetails>"
                            + "</ModelDepMsg>"
                            + "</modelDepositRequest>"
                            + "</Body>"
                            + "</FIXML>]]></arg_0_0>"
                            + "</web:executeService>"
                            + "</soapenv:Body>"
                            + "</soapenv:Envelope>";

            URL url = new URL(urlStr);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
            conn.setDoOutput(true);

            OutputStream os = conn.getOutputStream();
            os.write(soapRequest.getBytes());
            os.flush();

            int status = conn.getResponseCode();
            System.out.println("HTTP Response Code: " + status);

            BufferedReader br = (status >= 200 && status < 300)
                    ? new BufferedReader(new InputStreamReader(conn.getInputStream()))
                    : new BufferedReader(new InputStreamReader(conn.getErrorStream()));

            System.out.println("\n--- SOAP RESPONSE START ---\n");
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
            System.out.println("\n--- SOAP RESPONSE END ---");

            conn.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
