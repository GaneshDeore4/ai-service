package com.indusind.trade.account.service.impl;

import com.indusind.trade.account.adapter.AccountDetailsAdapter;
import com.indusind.trade.account.client.BankJsonFeignClient;
import com.indusind.trade.account.dto.request.AccountDetailsRequest;
import com.indusind.trade.account.dto.request.AccountDetailsRequest;
import com.indusind.trade.account.dto.response.AccountDetailsResponseDTO;
import com.indusind.trade.account.service.AccountDetailService;
import org.springframework.stereotype.Service;

@Service
public class AccountDetailServiceImpl implements AccountDetailService {

    private final AccountDetailsAdapter accountDetailsAdapter;

    public AccountDetailServiceImpl(AccountDetailsAdapter accountDetailsAdapter) {
        this.accountDetailsAdapter = accountDetailsAdapter;
    }

    @Override
    public AccountDetailsResponseDTO getAccountDetails(AccountDetailsRequest accountEnquiryRequestDTO) {

        AccountDetailsResponseDTO response= new AccountDetailsResponseDTO();
        try {
             response = accountDetailsAdapter.getAccountDetails(accountEnquiryRequestDTO.getAccountNumber());
            System.out.println("API Response=" +response);

        }catch (Exception e){
            e.printStackTrace();
        }
        return response;
    }
}
