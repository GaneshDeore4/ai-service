package com.indusind.trade.account.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.indusind.trade.account.adapter.AccountAdapter;
import com.indusind.trade.account.adapter.BalanceAdapter;
import com.indusind.trade.account.dto.AccountDTO;
import com.indusind.trade.account.dto.BalanceDTO;
import com.indusind.trade.account.entity.AccountAudit;
import com.indusind.trade.account.entity.AccountDetail;
import com.indusind.trade.account.repository.AccountAuditRepository;
import com.indusind.trade.account.repository.AccountRepository;
import com.indusind.trade.account.service.AccountService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

    private final AccountAdapter accountAdapter;
    private final BalanceAdapter balanceAdapter;
    private final AccountRepository accountRepository;
    private final AccountAuditRepository accountAuditRepository;

    @Override
    @Transactional
    public List<AccountDetail> syncAccounts(String cifId) {
        
        log.info("Syncing accounts for CIF ID: {}", cifId);

        List<AccountDTO> accountDTOs = accountAdapter.fetchAccountsByCif(cifId);
        List<AccountDetail> updatedAccounts = new ArrayList<>();

        for (AccountDTO dto : accountDTOs) {
            Optional<AccountDetail> existingAccountOpt = accountRepository.findByAccountNumber(dto.getAccountNumber());

            AccountDetail accountDetail;
            if (existingAccountOpt.isPresent()) {
                accountDetail = existingAccountOpt.get();

                /* --- AUDIT LOGGING START --- */
                
//                 trackAndAuditChange(cifId, accountDetail.getAccountNumber(), "currency",
//                 accountDetail.getCurrency(), dto.getCurrency());
//                 trackAndAuditChange(cifId, accountDetail.getAccountNumber(),
//                 "scheme_description", accountDetail.getSchemeDescription(),
//                 dto.getSchemeDescription());
//                 trackAndAuditChange(cifId, accountDetail.getAccountNumber(), "scheme_type",
//                 accountDetail.getSchemeType(), dto.getSchemeType());
//                 trackAndAuditChange(cifId, accountDetail.getAccountNumber(),
//                 "effective_avail_balance",
//                 accountDetail.getEffectiveAvailBalance() != null ?
//                 accountDetail.getEffectiveAvailBalance().toString() : null,
//                 dto.getEffectiveAvailBalance() != null ?
//                 dto.getEffectiveAvailBalance().toString() : null);
                
                /* --- AUDIT LOGGING END --- */

                accountDetail.setCurrency(dto.getCurrency());
                accountDetail.setSchemeDescription(dto.getSchemeDescription());
                accountDetail.setSchemeType(dto.getSchemeType());
                accountDetail.setEffectiveAvailBalance(dto.getEffectiveAvailBalance());
                log.info("Updating existing account: {}", accountDetail.getAccountNumber());
            } else {
                accountDetail = AccountDetail.builder()
                        .cifId(dto.getCifId())
                        .accountNumber(dto.getAccountNumber())
                        .currency(dto.getCurrency())
                        .schemeDescription(dto.getSchemeDescription())
                        .schemeType(dto.getSchemeType())
                        .effectiveAvailBalance(dto.getEffectiveAvailBalance())
                        .build();
                log.info("Creating new account record: {}", accountDetail.getAccountNumber());

                // Optional: Audit account creation
                auditLog(cifId, accountDetail.getAccountNumber(), "ACTION", null, "ACCOUNT_CREATED", "SYSTEM");
            }
            updatedAccounts.add(accountRepository.save(accountDetail));
        }
        return updatedAccounts;
    }

    @Override
    @Transactional
    public AccountDetail syncBalance(String accountNumber) {
        log.info("Syncing balance for Account Number: {}", accountNumber);

        BalanceDTO balanceDTO = balanceAdapter.fetchBalanceByAccount(accountNumber);
        Optional<AccountDetail> existingAccountOpt = accountRepository.findByAccountNumber(accountNumber);

        if (existingAccountOpt.isPresent()) {
            AccountDetail accountDetail = existingAccountOpt.get();

            /* --- AUDIT LOGGING START --- */
            
//            trackAndAuditChange(accountDetail.getCifId(), accountDetail.getAccountNumber(), "effective_avail_balance",
//                    accountDetail.getEffectiveAvailBalance() != null
//                            ? accountDetail.getEffectiveAvailBalance().toString()
//                            : null,
//                    balanceDTO.getEffectiveAvailBalance() != null ? balanceDTO.getEffectiveAvailBalance().toString()
//                            : null);
            
            /* --- AUDIT LOGGING END --- */

            accountDetail.setEffectiveAvailBalance(balanceDTO.getEffectiveAvailBalance());
            accountDetail.setCurrency(balanceDTO.getCurrency());
            return accountRepository.save(accountDetail);
        } else {
            throw new IllegalArgumentException("Account not found in local DB. Sync accounts by CIF first.");
        }
    }

    private void trackAndAuditChange(String cifId, String accNum, String fieldName, String oldVal, String newVal) {
        if (oldVal == null && newVal == null)
            return;
        if (oldVal != null && oldVal.equals(newVal))
            return;

        auditLog(cifId, accNum, fieldName, oldVal, newVal, "SYSTEM");
    }

    private void auditLog(String cifId, String accNum, String fieldName, String oldVal, String newVal,
            String updatedBy) {
        log.debug("Auditing change for {}-{}: {} -> {}", cifId, accNum, oldVal, newVal);
        accountAuditRepository.save(AccountAudit.builder()
                .cifId(cifId)
                .accountNumber(accNum)
                .fieldName(fieldName)
                .oldValue(oldVal)
                .newValue(newVal)
                .updatedBy(updatedBy)
                .build());
    }

    @Override
    public List<AccountDetail> getAccountsByCif(String cifId) {
        log.info("Fetching accounts for CIF ID: {} from local DB", cifId);
        return accountRepository.findByCifId(cifId);
    }

    @Override
    public Optional<AccountDetail> getAccountByNumber(String accountNumber) {
        log.info("Fetching account: {} from local DB", accountNumber);
        return accountRepository.findByAccountNumber(accountNumber);
    }
}
