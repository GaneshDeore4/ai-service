package com.indusind.trade.account.service.impl;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.indusind.trade.account.service.PdfExportService;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.encoding.WinAnsiEncoding;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

@Slf4j
@Service
public class AccountStatementPdfServiceImpl implements PdfExportService {

    @Override
    public StreamingResponseBody generateStatement(AccountStatementDTO statement) {
        return (OutputStream out) -> {
            log.info("Starting PDF generation for account: {}", statement.getAccountId());
            try (PDDocument document = new PDDocument()) {
                PDPage page = new PDPage(PDRectangle.A4);
                document.addPage(page);

                float margin = 50;
                float yStart = page.getMediaBox().getHeight() - margin;
                float tableWidth = page.getMediaBox().getWidth() - 2 * margin;

                try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                    // Header - Bank Name
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);
                    contentStream.setNonStrokingColor(Color.RED);
                    float titleWidth = PDType1Font.HELVETICA_BOLD.getStringWidth("IndusInd Bank") / 1000 * 18;
                    contentStream.newLineAtOffset(page.getMediaBox().getWidth() - margin - titleWidth, yStart);
                    contentStream.showText("IndusInd Bank");
                    contentStream.endText();

                    yStart -= 30;

                    // Title
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_BOLD, 14);
                    contentStream.setNonStrokingColor(Color.BLACK);
                    contentStream.newLineAtOffset(margin, yStart);
                    contentStream.showText("Account Statement");
                    contentStream.endText();

                    yStart -= 40;

                    // Account Details
                    yStart = drawDetailsTable(contentStream, yStart, margin, statement);

                    yStart -= 20;

                    // Transactions Table
                    drawTransactionsTable(contentStream, yStart, margin, tableWidth, statement.getTransactions());
                }

                log.info("Saving PDF to output stream...");
                document.save(out);
                out.flush();
                log.info("PDF generation completed successfully.");
            } catch (Exception e) {
                log.error("Critical error during PDF generation", e);
                throw new RuntimeException("Error generating PDF statement: " + e.getMessage(), e);
            }
        };
    }

    private float drawDetailsTable(PDPageContentStream contentStream, float y, float margin, AccountStatementDTO statement) throws IOException {
        float rowHeight = 20;
        PDType1Font font = PDType1Font.HELVETICA;
        PDType1Font fontBold = PDType1Font.HELVETICA_BOLD;
        int fontSize = 10;

        String[][] details = {
            {"Account Number:", statement.getAccountId()},
            {"Account Holder:", statement.getName()},
            {"Currency:", statement.getCurrency()},
            {"Available Balance:", String.valueOf(statement.getAvailableBalance())}
        };

        contentStream.setNonStrokingColor(Color.BLACK);
        for (String[] detail : details) {
            contentStream.beginText();
            contentStream.setFont(fontBold, fontSize);
            contentStream.newLineAtOffset(margin, y);
            contentStream.showText(detail[0]);
            contentStream.endText();

            contentStream.beginText();
            contentStream.setFont(font, fontSize);
            contentStream.newLineAtOffset(margin + 120, y);
            safeShowText(contentStream, detail[1] != null ? detail[1] : "N/A", font, fontSize);
            contentStream.endText();

            y -= rowHeight;
        }
        return y;
    }

    private void drawTransactionsTable(PDPageContentStream contentStream, float y, float margin, float width, List<AccountTransactionDTO> transactions) throws IOException {
        float rowHeight = 25;
        float[] colWidths = {80, 80, 50, 80, 205};
        String[] headers = {"Tran Date", "Tran ID", "Type", "Amount", "Remarks"};

        // Header Background
        contentStream.setNonStrokingColor(Color.DARK_GRAY);
        contentStream.addRect(margin, y - rowHeight, width, rowHeight);
        contentStream.fill();

        // Header Text
        contentStream.setNonStrokingColor(Color.WHITE);
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
        float x = margin;
        for (int i = 0; i < headers.length; i++) {
            contentStream.beginText();
            contentStream.newLineAtOffset(x + 5, y - rowHeight + 7);
            contentStream.showText(headers[i]);
            contentStream.endText();
            x += colWidths[i];
        }

        y -= rowHeight;

        // Rows
        contentStream.setNonStrokingColor(Color.BLACK);
        contentStream.setFont(PDType1Font.HELVETICA, 9);

        if (transactions != null) {
            for (AccountTransactionDTO tran : transactions) {
                if (y < 50) break; // Simple page break check
                
                x = margin;
                String[] rowData = {
                    tran.getTranDate(),
                    tran.getTranId(),
                    tran.getDebitOrCredit(),
                    String.valueOf(tran.getAmount()),
                    tran.getParticulars()
                };

                for (int i = 0; i < rowData.length; i++) {
                    String text = rowData[i] != null ? rowData[i] : "";
                    contentStream.beginText();
                    contentStream.newLineAtOffset(x + 5, y - rowHeight + 7);
                    safeShowText(contentStream, truncate(text, colWidths[i] - 10), PDType1Font.HELVETICA, 9);
                    contentStream.endText();
                    
                    // Draw cell border
                    contentStream.setStrokingColor(Color.LIGHT_GRAY);
                    contentStream.setLineWidth(0.5f);
                    contentStream.addRect(x, y - rowHeight, colWidths[i], rowHeight);
                    contentStream.stroke();
                    
                    x += colWidths[i];
                }
                y -= rowHeight;
            }
        }
    }

    private void safeShowText(PDPageContentStream contentStream, String text, PDType1Font font, int fontSize) throws IOException {
        if (text == null) return;
        
        StringBuilder cleanText = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c == '₹') {
                cleanText.append("Rs.");
            } else {
                try {
                    font.encode(String.valueOf(c));
                    cleanText.append(c);
                } catch (IllegalArgumentException e) {
                    cleanText.append("?");
                }
            }
        }
        contentStream.showText(cleanText.toString());
    }

    private String truncate(String text, float maxWidth) throws IOException {
        if (text == null) return "";
        
        // Clean text first to avoid encoding errors in width calculation
        StringBuilder clean = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c == '₹') {
                clean.append("Rs.");
            } else {
                try {
                    PDType1Font.HELVETICA.encode(String.valueOf(c));
                    clean.append(c);
                } catch (IllegalArgumentException e) {
                    // Skip or replace
                }
            }
        }
        String cleanText = clean.toString();

        float width = PDType1Font.HELVETICA.getStringWidth(cleanText) / 1000 * 9;
        if (width <= maxWidth) return cleanText;
        
        while (width > maxWidth && cleanText.length() > 0) {
            cleanText = cleanText.substring(0, cleanText.length() - 1);
            width = PDType1Font.HELVETICA.getStringWidth(cleanText + "...") / 1000 * 9;
        }
        return cleanText + "...";
    }
}
