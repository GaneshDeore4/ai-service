package com.indusind.trade.account.service.impl;

import com.indusind.trade.account.client.SoapFeignClient;
import com.indusind.trade.account.service.BalanceEnquiryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class BalanceEnquiryServiceImpl implements BalanceEnquiryService {

    private final SoapFeignClient soapClient;

    @Override
    public String getBalanceEnquiry(String request) {
        try {
            return soapClient.executeFinacleScript(request);
        } catch(Exception e) {
            throw e;
        }
    }





}
