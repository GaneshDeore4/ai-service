 package com.indusind.trade.account.service.impl;
 import com.indusind.trade.account.dto.request.BalanceEnquiryRequestDto;
 import com.indusind.trade.account.dto.response.AcctInfo;
 import com.indusind.trade.account.dto.response.BalanceEnquiryResponseDto;
 import com.indusind.trade.account.service.SoapTransformationService;
 import com.indusind.trade.account.util.DateUtil;
 import com.indusind.trade.account.util.TemplateLoader;
 import lombok.RequiredArgsConstructor;
 import lombok.extern.slf4j.Slf4j;
 import org.springframework.stereotype.Service;
 import org.w3c.dom.Document;
 import org.w3c.dom.Element;
 import org.w3c.dom.Node;
 import org.w3c.dom.NodeList;
 import org.xml.sax.InputSource;
 import javax.xml.parsers.DocumentBuilderFactory;
 import javax.xml.xpath.XPath;
 import javax.xml.xpath.XPathConstants;
 import javax.xml.xpath.XPathFactory;
 import java.io.StringReader;
 import java.util.ArrayList;
 import java.util.HashMap;
 import java.util.List;
 import java.util.Map;
 @Slf4j
 @Service
 @RequiredArgsConstructor
 public class SoapTransformationServiceImpl implements SoapTransformationService {
     private final TemplateLoader loader;
     @Override
     public String convertBalanceEnqReqToSoapReq(BalanceEnquiryRequestDto request) {
         {
             String template = loader.load("templates/balanceEnquiry.xml");
             Map<String, String> map = new HashMap<>();
             map.put("requestUUID", String.valueOf(System.currentTimeMillis()));
             map.put("messageDateTime", DateUtil.now());
             map.put("cifId", val(request.getCifId()));
             // empty required fields
             map.put("userId", "");
             map.put("password", "");
             map.put("bankId", "");
             map.put("timeZone", "");
             map.put("entityId", "");
             map.put("entityType", "");
             map.put("armCorrelationId", "");
             map.put("fiCertToken", "");
             map.put("realUserLoginSessionId", "");
             map.put("realUser", "");
             map.put("realUserPwd", "");
             map.put("ssoTransferToken", "");
             map.put("languageId", "");
             map.put("tableCode", "");
             for (Map.Entry<String, String> e : map.entrySet()) {
                 template = template.replace("{{" + e.getKey() + "}}", escape(e.getValue()));
             }
             return template;
         }
     }
     @Override
     public BalanceEnquiryResponseDto convertSoapResToBalanceEnqRes(String xml) {
         try {
             Document doc = buildDocument(xml);
             XPath xpath = XPathFactory.newInstance().newXPath();
             checkSoapFault(doc, xpath);
             String numAccounts = get(xpath, doc, "//numOfAccounts");
             String flag = get(xpath, doc, "//sucFaiFlag");
             String message = get(xpath, doc, "//message");
             String status = get(xpath, doc, "//HostTransaction/Status");
             String errorCode = get(xpath, doc, "//ErrorCode");
             String errorDesc = get(xpath, doc, "//ErrorDesc");
             System.out.println("status: "   + status);
 //
 //            if(status != null && status.equalsIgnoreCase("FAILURE")) {
 //
 //            }
             NodeList nodes = (NodeList) xpath.evaluate(
                     "//cifInfo/acctInfo",
                     doc,
                     XPathConstants.NODESET
             );
             List<AcctInfo> accounts = new ArrayList<>(nodes.getLength());
             for (int i = 0; i < nodes.getLength(); i++) {
                 accounts.add(mapAccount(nodes.item(i)));
             }
             return BalanceEnquiryResponseDto.builder()
                     .cifInfo(accounts)
                     .numberOfAccounts(parseLong(numAccounts))
                     .sucFaiFlag(flag)
                     .message(message)
                     .errorCode(errorCode)
                     .errorDesc(errorDesc)
                     .build();
         } catch (Exception e) {
             log.error("Balance enquiry SOAP parsing failed", e);
             throw new RuntimeException("SOAP parsing failed", e);
         }
     }
     private Document buildDocument(String xml) throws Exception {
         DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         factory.setNamespaceAware(false); // Finacle safe mode
         return factory.newDocumentBuilder()
                 .parse(new InputSource(new StringReader(xml)));
     }
     private void checkSoapFault(Document doc, XPath xpath) throws Exception {
         String fault = xpath.evaluate("//Fault/faultstring", doc);
         if (fault != null && !fault.isEmpty()) {
             throw new RuntimeException("SOAP Fault: " + fault);
         }
     }
     private String get(XPath xpath, Document doc, String exp) {
         try {
             return xpath.evaluate(exp, doc);
         } catch (Exception e) {
             return null;
         }
     }
     private Long parseLong(String value) {
         try {
             return value != null && !value.isEmpty() ? Long.parseLong(value) : 0L;
         } catch (Exception e) {
             return 0L;
         }
     }
     private AcctInfo mapAccount(Node node) {
         Element element = (Element) node;
         return AcctInfo.builder()
                 .AvailableAmt(getTag(element, "AvailableAmt"))
                 .acctCrncyCode(getTag(element, "acctCrncyCode"))
                 .schemeType(getTag(element, "schemeType"))
                 .acctNum(getTag(element, "acctNum"))
                 .acctName(getTag(element, "acctName"))
                 .build();
     }
     private String getTag(Element element, String tag) {
         NodeList list = element.getElementsByTagName(tag);
         if (list.getLength() > 0) {
             return list.item(0).getTextContent();
         }
         return null;
     }
     private String val(String v) {
         return v == null ? "" : v;
     }
     private String escape(String v) {
         return v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
     }
 }
