package com.indusind.trade.account.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
// import com.indusind.api.integrator.IBLPayloadGenerator_j;
import com.indusind.trade.account.adapter.StatementAdapter;
import com.indusind.trade.account.client.StatementFeignClient;
import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.indusind.trade.account.dto.ApplicationResponse;
import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import com.indusind.trade.account.dto.request.ContinueTokenDTO;
import com.indusind.trade.account.entity.AccountStatement;
import com.indusind.trade.account.entity.AccountTransaction;
import com.indusind.trade.account.repository.AccountStatementRepository;
import com.indusind.trade.account.repository.AccountTransactionRepository;
import com.indusind.trade.account.service.StatementService;
import com.indusind.trade.account.util.AccountStatementMapper;
import feign.FeignException;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.indusind.trade.account.util.testResponse.HARDCODED_RESPONSE;

@Slf4j
@Service
@RequiredArgsConstructor
public class StatementServiceImpl implements StatementService {

    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    private final StatementAdapter statementAdapter;
    private final AccountStatementRepository statementRepository;
    private final AccountTransactionRepository transactionRepository;
    private final StatementFeignClient statementFeignClient;
    private final AccountStatementMapper accountStatementMapper;
    private final ObjectMapper objectMapper;

    @Override
    @Transactional
    public AccountStatementDTO syncStatement(String accountNumber, LocalDate fromDate, LocalDate toDate,
            String debitOrCredit, String tranId) {

        log.info("statement for account: {} from {} to {}", accountNumber, fromDate, toDate);

        String fromDateStr = (fromDate != null) ? fromDate.toString() : null;
        String toDateStr = (toDate != null) ? toDate.toString() : null;

        AccountStatementResponse response = statementAdapter.fetchStatement(accountNumber, fromDateStr, toDateStr);
        log.info("response before dto :" + response);

        AccountStatementDTO responseDto = accountStatementMapper.convertToDto(response);

        if (!responseDto.isSuccessFlag()) {
            log.info("API Error: {}:{}", responseDto.getErrorCode(), responseDto.getErrorMessage());
            return responseDto;
        }

        if (debitOrCredit != null || tranId != null) {
            responseDto
                    .setTransactions(filterTransactionResponse(responseDto.getTransactions(), debitOrCredit, tranId));
        }

        log.info("Statement fetched with {} transactions",
                responseDto.getTransactions() != null ? responseDto.getTransactions().size() : 0);

        return responseDto;
    }

    private List<AccountTransactionDTO> filterTransactionResponse(List<AccountTransactionDTO> transactions,
            String debitOrCredit, String tranId) {

        return transactions.stream().filter(
                tran -> (debitOrCredit == null || debitOrCredit.equalsIgnoreCase(tran.getDebitOrCredit().strip()))
                        && (tranId == null || tranId.equalsIgnoreCase(tran.getTranId().strip())))
                .toList();
    }

     @Override
     public AccountStatementDTO fetchFullStatement(AccountStatementRequestDto requestDto, String continueToken) {

//         IBLPayloadGenerator_j ipg = new IBLPayloadGenerator_j();
         try {
             String requestJson = objectMapper.writeValueAsString(requestDto);

//             String encryptedPayload = ipg.getIBLPayload(requestJson, "UAT");
//             log.info("encrypted payload is {}", encryptedPayload);

             AccountStatementResponse response = statementAdapter.fetchFullStatement(requestDto, continueToken);
            
             // ---------------UNCOMMENT LATER--------------//

             // String encryptedRes = statementFeignClient.fetchFullStatement(clientId,
             // clientSecret, continueToken, encryptedPayload);
             // String decryptedRes = ipg.decrypt(encryptedRes);

             // convert decrypted string to res object
             // AccountStatementResponse response = objectMapper.readValue(decryptedRes,
             // AccountStatementResponse.class);

             // ---------------UNCOMMENT LATER--------------//

             log.info("Client response : " + response);

             return accountStatementMapper.convertToDto(response);

         } catch (FeignException e) {
             log.error("Feign error calling account statement API: {}", e.getMessage());
             try {
                 if (e.contentUTF8() != null) {
//                     String decryptedError = ipg.decrypt(e.contentUTF8());
//                     AccountStatementResponse res = objectMapper.readValue(decryptedError,
//                             AccountStatementResponse.class);
//                     log.info("error response from API: {}", res);
//                     return accountStatementMapper.convertToDto(res);
                 }
             } catch (Exception ex) {
                 log.error("Error parsing feign error response", ex);
             }
             AccountStatementDTO dto = new AccountStatementDTO();
             dto.setErrorCode("FAIL");
             dto.setErrorMessage("External API failure");
             dto.setSuccessFlag(false);
             return dto;
         } catch (Exception ex) {
             throw new RuntimeException("Error processing statement API", ex);
         }
     }

    private void saveTransaction(AccountStatement statement, AccountTransactionDTO dto, String accountNumber) {
        AccountTransaction transaction = AccountTransaction.builder()
                .statement(statement)
                .accountNumber(accountNumber)
                .tranDate(LocalDate.parse(dto.getTranDate()))
                .valueDate(LocalDate.parse(dto.getValueDate()))
                .postingTime(LocalDateTime.parse(dto.getPostingTime()))
                .tranId(dto.getTranId())
                .tranType(dto.getTranType())
                .debitOrCredit(dto.getDebitOrCredit())
                .particulars(dto.getParticulars())
                .remarks(dto.getRemarks())
                .currency(dto.getCurrency())
                .amount(dto.getAmount())
                .balance(dto.getBalance())
                .build();

        try {
            transactionRepository.save(transaction);
        } catch (Exception e) {
            log.error("Error saving transaction {}: {}", dto.getTranId(), e.getMessage());
            throw e;
        }
    }

    @Override
    public List<AccountTransaction> filterTransactions(String accountNumber,
            LocalDate startDate,
            LocalDate endDate,
            String refNumber,
            String tranType) {
        log.info("Filtering transactions for account: {}, start: {}, end: {}, ref: {}, type: {}",
                accountNumber, startDate, endDate, refNumber, tranType);

        Specification<AccountTransaction> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (accountNumber != null && !accountNumber.isEmpty()) {
                predicates.add(cb.equal(root.get("accountNumber"), accountNumber));
            }

            if (startDate != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("tranDate"), startDate));
            }

            if (endDate != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("tranDate"), endDate));
            }

            if (refNumber != null && !refNumber.isEmpty()) {
                predicates.add(cb.equal(root.get("tranId"), refNumber));
            }

            if (tranType != null && !tranType.isEmpty()) {
                predicates.add(cb.equal(root.get("debitOrCredit"), tranType));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };

        List<AccountTransaction> results = transactionRepository.findAll(spec);
        log.info("Filtering returned {} results", results.size());
        return results;
    }

}
