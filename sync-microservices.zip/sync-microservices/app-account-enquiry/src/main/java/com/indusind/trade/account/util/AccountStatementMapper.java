package com.indusind.trade.account.util;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.json.AccountStmtTransResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@Slf4j
public class AccountStatementMapper {

    public AccountStatementDTO convertToDto(AccountStatementResponse response){

        AccountStatementDTO accountStatementDTO = new AccountStatementDTO();

        if(response.getErrorCode() != null || response.getErrorMessage() != null){
            log.info("inside errorCode {}", response.getErrorCode());
            accountStatementDTO.setErrorCode(response.getErrorCode());
            accountStatementDTO.setErrorMessage(response.getErrorMessage());
            accountStatementDTO.setSuccessFlag(false);
            return accountStatementDTO;
        }

        // ===== Statement-level fields =====
        accountStatementDTO.setVersion(response.getVersion());
        accountStatementDTO.setAccountId(response.getAccountId());
        accountStatementDTO.setAcid(response.getAcid());
        accountStatementDTO.setCurrency(response.getCurrency());
        accountStatementDTO.setName(response.getName());
        accountStatementDTO.setShortName(response.getShortName());
//        accountStatementDTO.setSchemeCode(response.getSchemeCode());
//        accountStatementDTO.setSchemeType(response.getSchemeType());
//        accountStatementDTO.setSolId(response.getSolId());
        accountStatementDTO.setCifId(response.getCifId());
        accountStatementDTO.setSysBehaviorCode(response.getSysBehaviorCode());

        accountStatementDTO.setLedgerBalance(response.getLedgerBalance());
        accountStatementDTO.setAvailableBalance(response.getAvailableBalance());
        accountStatementDTO.setEffAvailableBalance(response.getEffAvailableBalance());
        accountStatementDTO.setFfdBalance(response.getFfdBalance());
        accountStatementDTO.setLienAmt(response.getLienAmt());
        accountStatementDTO.setClearBalance(response.getClearBalance());

        accountStatementDTO.setFreezeCode(response.getFreezeCode());
        accountStatementDTO.setActiveStatus(response.getActiveStatus());
        accountStatementDTO.setNextTranSrlNum(response.getNextTranSrlNum());
        accountStatementDTO.setTimeStampCount(response.getTimeStampCount());

        accountStatementDTO.setLastChangeTime(response.getLastChangeTime());
        accountStatementDTO.setLastCreditDate(response.getLastCreditDate());
        accountStatementDTO.setLastDebitDate(response.getLastDebitDate());
        accountStatementDTO.setClosingBalance(response.getClosingBalance());
        accountStatementDTO.setContinueToken(response.getContinueToken());

        // ===== Transactions mapping =====
        if (response.getTransactions() != null) {
            accountStatementDTO.setTransactions(
                    response.getTransactions()
                            .stream()
                            .map(this::convertToTranDto)
                            .collect(Collectors.toList())
            );
        }

        return accountStatementDTO;

    }

    private AccountTransactionDTO convertToTranDto(AccountStmtTransResponse transResponse){

        AccountTransactionDTO accountTransactionDTO = new AccountTransactionDTO();

        accountTransactionDTO.setTranDate(transResponse.getTranDate());
        accountTransactionDTO.setValueDate(transResponse.getValueDate());
        accountTransactionDTO.setPostingTime(transResponse.getPostingTime());

        accountTransactionDTO.setTranId(transResponse.getTranId());
        accountTransactionDTO.setTranSrlNum(transResponse.getTranSrlNum());
        accountTransactionDTO.setTranType(transResponse.getTranType());
        accountTransactionDTO.setReversalStatus(transResponse.getReversalStatus());
        accountTransactionDTO.setTranSubType(transResponse.getTranSubType());
        accountTransactionDTO.setDebitOrCredit(transResponse.getDebitOrCredit());

        accountTransactionDTO.setParticulars(transResponse.getParticulars());
        accountTransactionDTO.setParticulars2(transResponse.getParticulars2());
        accountTransactionDTO.setParticularCode(transResponse.getParticularCode());
        accountTransactionDTO.setReportCode(transResponse.getReportCode());
        accountTransactionDTO.setRemarks(transResponse.getRemarks());

        accountTransactionDTO.setModuleId(transResponse.getModuleId());
        accountTransactionDTO.setUadModuleId(transResponse.getUadModuleId());
        accountTransactionDTO.setUadModuleKey(transResponse.getUadModuleKey());

        accountTransactionDTO.setCurrency(transResponse.getCurrency());
        accountTransactionDTO.setAmount(transResponse.getAmount());
        accountTransactionDTO.setBalance(transResponse.getBalance());

        return accountTransactionDTO;
    }

}
