package com.indusind.trade.account.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtil {

    public static final DateTimeFormatter FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    public static String now() {
        return LocalDateTime.now().format(FORMAT);
    }
    public static String format(LocalDateTime dt) {
        return dt.format(FORMAT);
    }
}
