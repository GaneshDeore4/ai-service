package com.indusind.trade.account.utils;

import com.indusind.trade.model.constants.CryptoConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

@Component
public class CryptoUtils {

    private static final Logger logger = LoggerFactory.getLogger(CryptoUtils.class);

    private static String AES_SECRET_KEY;

    @Value("${app.security.aes.secret}")
    public void setAesSecretKey(String secretKey) {
        CryptoUtils.AES_SECRET_KEY = secretKey;
    }

    public static String encrypt(String plainText) throws Exception {

//        String secretKey = CryptoConstants.AES_SECRET_KEY;
        String secretKey = AES_SECRET_KEY;
        byte[] iv = new byte[CryptoConstants.IV_LENGTH];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(iv);

        Cipher cipher = Cipher.getInstance(CryptoConstants.ALGORITHM);
        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "AES");
        GCMParameterSpec spec = new GCMParameterSpec(CryptoConstants.GCM_TAG_LENGTH * 8, iv);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, spec);

        byte[] encryptedData = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

        String ivEncoded = Base64.getEncoder().encodeToString(iv);
        String encryptedDataEncoded = Base64.getEncoder().encodeToString(encryptedData);

//	        return NEW_PREFIX + ivEncoded + ";" + encryptedDataEncoded;
        return ivEncoded + ";" + encryptedDataEncoded;
    }

    public static String enc(String plainText) throws Exception {

//        String secretKey = CryptoConstants.AES_SECRET_KEY;
        String secretKey = AES_SECRET_KEY;
        byte[] iv = new byte[CryptoConstants.IV_LENGTH];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(iv);

        Cipher cipher = Cipher.getInstance(CryptoConstants.ALGORITHM);
        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "AES");
        GCMParameterSpec spec = new GCMParameterSpec(CryptoConstants.GCM_TAG_LENGTH * 8, iv);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, spec);

        byte[] encryptedData = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

        String ivEncoded = Base64.getEncoder().encodeToString(iv);
        String encryptedDataEncoded = Base64.getEncoder().encodeToString(encryptedData);

        return CryptoConstants.NEW_PREFIX + ivEncoded + ";" + encryptedDataEncoded;
//	        return ivEncoded + ";" + encryptedDataEncoded;
    }

    public static String decrypt(String encryptedText) throws Exception {

//	        if (!encryptedText.startsWith("{AES3}")) {
//	            throw new IllegalArgumentException("Invalid encrypted text format.");
//	        }
//	        encryptedText = encryptedText.substring(6);
//        String secretKey = CryptoConstants.AES_SECRET_KEY;
        String secretKey = AES_SECRET_KEY;
        String[] parts = encryptedText.split(";");
        if (parts.length != 2) {
            throw new IllegalArgumentException("Invalid encrypted text format.");
        }

        byte[] iv = Base64.getDecoder().decode(parts[0]);
        byte[] encryptedData = Base64.getDecoder().decode(parts[1]);

        Cipher cipher = Cipher.getInstance(CryptoConstants.ALGORITHM);
        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "AES");

        GCMParameterSpec spec = new GCMParameterSpec(CryptoConstants.GCM_TAG_LENGTH * 8, iv);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, spec);

        byte[] decryptedData = cipher.doFinal(encryptedData);
        return new String(decryptedData, StandardCharsets.UTF_8);
    }

    public static String dec(String encryptedText) throws Exception {

        if (!encryptedText.startsWith("{AES3}")) {
            return encryptedText;
//	            throw new IllegalArgumentException("Invalid encrypted text format.");
        }
        encryptedText = encryptedText.substring(6);
//        String secretKey = CryptoConstants.AES_SECRET_KEY;
        String[] parts = encryptedText.split(";");
        String secretKey = AES_SECRET_KEY;
        if (parts.length != 2) {
            throw new IllegalArgumentException("Invalid encrypted text format.");
        }

        byte[] iv = Base64.getDecoder().decode(parts[0]);
        byte[] encryptedData = Base64.getDecoder().decode(parts[1]);

        Cipher cipher = Cipher.getInstance(CryptoConstants.ALGORITHM);
        SecretKeySpec keySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "AES");

        GCMParameterSpec spec = new GCMParameterSpec(CryptoConstants.GCM_TAG_LENGTH * 8, iv);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, spec);

        byte[] decryptedData = cipher.doFinal(encryptedData);
        return new String(decryptedData, StandardCharsets.UTF_8);
    }

    private static byte[] generateIV(int length) throws NoSuchAlgorithmException {
        byte[] iv = new byte[length];
        KeyGenerator.getInstance("AES").generateKey().getEncoded(); // Random IV
        return iv;
    }


    public static void main(String[] args) {
        try {
//            String secretKey = CryptoConstants.AES_SECRET_KEY;
            String secretKey = AES_SECRET_KEY;// 16-byte secret key
            String originalText = "0qr55tG7zIEbXN+j;3ji2vWOFtkdWSTnGldGm5oJW";
            String decryptedText = decrypt(originalText);
            logger.info("Decrypted Text: " + decryptedText);
        } catch (Exception e) {
            logger.error("Exception occurred: " +  e.getMessage());
        }
    }
}
