package com.indusind.trade.account.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;


@Slf4j
@Component
public class HashUtils {

    private static String HASH_SECRET_KEY;

    @Value("${app.hash.secret.key}")
    public void setHashSecretKey(String secretKey) {
        HashUtils.HASH_SECRET_KEY = secretKey;
    }


    public static final String HMAC_MD_5 = "HmacMD5";

    public static String HAMCMD5Hash(String input){
        try {
            SecretKeySpec secretKeySpec = new SecretKeySpec(HASH_SECRET_KEY.getBytes(), "HmacMD5");
            Mac mac = Mac.getInstance(HMAC_MD_5);
            try {
                mac.init(secretKeySpec);
            } catch (InvalidKeyException e) {
                log.error("Exception occurred: " +  e.getMessage());
            }
            byte[] hashBytes = mac.doFinal(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                hexString.append(String.format("%02x", b));
            }
            log.info(hexString.toString());
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            log.error("Exception occurred: " +  e.getMessage());
            return input;
        }
    }
}
