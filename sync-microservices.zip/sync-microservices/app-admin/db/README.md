# Admin Service — Database bootstrap

For prod/UAT deployments, the application's auto-seeder is **disabled by default**:
- `seed.enabled=false` → `DataSeeder.run()` exits early, no Java-driven seed runs.
- `spring.sql.init.mode=never` → `data.sql` and `schema.sql` are not executed.

The bank operator runs `bootstrap-mssql.sql` manually before first boot (or right after the first boot, since Hibernate creates the tables on startup via `ddl-auto=update`).

## Run order

1. Start `admin-service` once against an empty MSSQL database. Hibernate creates all tables (no data).
2. Stop the service.
3. Run the bootstrap script:
   ```bash
   sqlcmd -S <host> -U <user> -P <pass> -d GIFTCITY -i bootstrap-mssql.sql
   ```
4. Edit the bank profile / super-admin section of the script first (CIF, name, email, password). The script is idempotent — safe to re-run.
5. Restart the service.

## Local dev (auto-seed)

If you want the old Java-seeder behaviour locally, override the two flags:
```
--seed.enabled=true --spring.sql.init.mode=always
```

## Files

- `bootstrap-mssql.sql` — reference data (auth_groups, categories, user_types) + bank profile/super-admin template.
- Widget structure (products/sub-products/tabs/actions) is loaded from `src/main/resources/basewidget.yml`. For first bootstrap, the simplest path is to enable `seed.enabled=true` for one boot to populate it, then turn it off again.
