package com.indusind.trade.admin.audit;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * Audit event DTO — built by AuditAspect and passed to AuditService.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditEvent {

    // WHO
    private String performedBy;
    private String roleName;
    private String userType;
    private Long companyId;

    // WHAT
    private String action;
    private String resourceType;
    private String resourceId;
    private String module;

    // WHERE
    private String ipAddress;
    private String serviceName;
    private String hostname;

    // WHY
    private String outcome;
    private String reason;
    private String errorMessage;

    // CHANGE DATA
    private String oldValue; // JSON
    private String newValue; // JSON

    // CORRELATION
    private String sessionId;
    private String correlationId;

    // Set automatically
    private Instant timestamp;
}
