package com.indusind.trade.admin.config;

import com.indusind.trade.model.entities.master.ProductMasterTemp;
import com.indusind.trade.model.entities.master.SubProductMasterTemp;
import com.indusind.trade.model.repository.ProductMasterTempDao;
import com.indusind.trade.model.repository.SubProductMasterTempDao;
import com.indusind.trade.model.entities.bank.BankProfile;
import com.indusind.trade.model.entities.bank.BankProfileTemp;
import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.entities.bank.BankUserTemp;
import com.indusind.trade.model.entities.company.Company;
import com.indusind.trade.model.entities.company.CompanyTemp;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.entities.company.UserTemp;
import com.indusind.trade.model.entities.master.*;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.repository.*;
import com.indusind.trade.model.utility.HashUtils;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;


import java.time.LocalDateTime;

//@Component
//@RequiredArgsConstructor
//@Slf4j
//@PropertySource("classpath:dataseed.properties")
//public class DataSeeder implements CommandLineRunner {
//
//    private final CompanyDao companyDao;
//    private final CompanyTempDao companyTempDao;
//    private final UserDao userDao;
//    private final UserTempDao userTempDao;
//    private final BankProfileDao bankProfileDao;
//    private final BankProfileTempDao bankProfileTempDao;
//    private final BankUserDao bankUserDao;
//    private final BankUserTempDao bankUserTempDao;
//    private final EntityManager entityManager;
//    private final CategoryMasterService categoryMasterService;
//    private final  UserTypeDao userTypeDao;
//
//    @Value("${seed.enabled:false}")
//    private boolean seedEnabled;
//
////    @Value("${seed.company.cifId:}")
////    private String companyCifId;
////
////    @Value("${seed.company.abbvName:}")
////    private String companyAbbvName;
////
////    @Value("${seed.company.name:}")
////    private String companyName;
////
////    @Value("${seed.company.baseCurrency:INR}")
////    private String companyBaseCurrency;
////
////    @Value("${seed.company.email:}")
////    private String companyEmail;
////
////    @Value("${seed.user.loginId:}")
////    private String userLoginId;
////
////    @Value("${seed.user.firstName:}")
////    private String userFirstName;
////
////    @Value("${seed.user.lastName:}")
////    private String userLastName;
////
////    @Value("${seed.user.email:}")
////    private String userEmail;
////
////    @Value("${seed.user.password:}")
////    private String userPassword;
//
//    //for bank
//
//    @Value("${seed.bank.cifId:}")
//    private String bankCifId;
//    @Value("${seed.bank.abbvName:}")
//    private String bankAbbvName;
//    @Value("${seed.bank.name:}")
//    private String bankName;
//    @Value("${seed.bank.baseCurrency:}")
//    private String bankBaseCurr;
//    @Value("${seed.bank.email:}")
//    private String bankEmail;
//    @Value("${seed.bank.user.loginId:}")
//    private String bankUserLoginId;
//    @Value("${seed.bank.user.firstName:}")
//    private String bankUserFirstName;
//    @Value("${seed.bank.user.lastName:}")
//    private String bankUserLastName;
//    @Value("${seed.bank.user.email:}")
//    private String bankUserEmail;
//    @Value("${seed.bank.user.password:}")
//    private String bankUserPassword;
//
//
//    @Override
//    @Transactional
//    public void run(String... args) throws Exception {
//        if (!seedEnabled) {
//            log.info("InitialSystemDataSeeder is disabled.");
//            return;
//        }
//
////        Long count = entityManager.createQuery("SELECT count(c) FROM Company c WHERE c.cifId = :cifId", Long.class)
////                .setParameter("cifId", companyCifId)
////                .getSingleResult();
//
//        Long count = entityManager.createQuery("SELECT count(c) FROM BankProfile c WHERE c.cifId = :cifId", Long.class)
//                .setParameter("cifId", bankCifId)
//                .getSingleResult();
//
//        if (count > 0) {
//            log.info("System bank profile with CIF {} already exists. Skipping data seed.", bankCifId);
//            return;
//        }
//
//        log.info("Starting initial system data seed...");
//
//        // Create CompanyTemp first to get the generated ID
////        CompanyTemp companyTemp = new CompanyTemp();
////        companyTemp.setCifId(companyCifId);
////        companyTemp.setAbbvName(companyAbbvName);
////        companyTemp.setName(companyName);
////        companyTemp.setBaseCurrency(companyBaseCurrency);
////        companyTemp.setEmail(companyEmail);
////        companyTemp.setCreatedDate(LocalDateTime.now());
////        companyTemp.setCreatedBy("SYSTEM");
////        companyTemp.setStatus(Status.APPROVED.toString());
////
////        CompanyTemp savedCompanyTemp = companyTempDao.save(companyTemp);
//
//        // Create Company using the generated ID from CompanyTemp
////        Company company = new Company();
////        company.setCompanyId(savedCompanyTemp.getCompanyId());
////        company.setCifId(companyCifId);
////        company.setAbbvName(companyAbbvName);
////        company.setName(companyName);
////        company.setBaseCurrency(companyBaseCurrency);
////        company.setEmail(companyEmail);
////        company.setCreatedDate(LocalDateTime.now());
////        company.setCreatedBy("SYSTEM");
////
////        Company savedCompany = companyDao.save(company);
////        log.info("Company saved with ID: {}", savedCompany.getCompanyId());
//
//        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//        String encodedPassword = passwordEncoder.encode(bankUserPassword);
//
//        // Create UserTemp first to get the generated ID
////        UserTemp userTemp = new UserTemp();
////        userTemp.setLoginId(userLoginId);
////        userTemp.setFirstName(userFirstName);
////        userTemp.setLastName(userLastName);
////        userTemp.setEmail(userEmail);
////        userTemp.setCompany(savedCompany);
////        userTemp.setCreated(LocalDateTime.now());
////        userTemp.setMaker("SYSTEM");
////        userTemp.setUserStatus("Active");
////        userTemp.setStatus("APPROVED");
////        userTemp.setUserPassword(encodedPassword);
////
////        UserTemp savedUserTemp = userTempDao.save(userTemp);
//
//        // Create User using the generated ID from UserTemp
////        User user = new User();
////        user.setUserId(savedUserTemp.getUserId());
////        user.setLoginId(userLoginId);
////        user.setFirstName(userFirstName);
////        user.setLastName(userLastName);
////        user.setEmail(userEmail);
////        user.setCompany(savedCompany);
////        user.setCreated(LocalDateTime.now());
////        user.setMaker("SYSTEM");
////        user.setUserStatus("Active");
////        user.setUserPassword(encodedPassword);
////
////
////        User savedUser = userDao.save(user);
//
////        log.info("User {} saved with ID: {}", savedUser.getLoginId(), savedUser.getUserId());
////        log.info("Initial system data seed completed successfully.");
//
//        UserTypeTempService defaultUser = userTypeDao.findByUserTypeName(UsersType.SUPERADMIN.getDbValue());
//
//        // Create BankProfileTemp first to get the generated ID
//        BankProfile savedBankProfile = saveInitialAdminBankProfile();
//
//        // Create BankUserTemp first to get the generated ID
//        BankUser savedBankUser = saveAdminInitialBankUser(encodedPassword, savedBankProfile, defaultUser);
//
//        log.info("BankUser {} saved with ID: {}", savedBankUser.getLoginId(), savedBankUser.getBankUserId());
//        log.info("Initial system data seed completed successfully.");
//
//
//    }
//
//    private BankUser saveAdminInitialBankUser(String encodedPassword, BankProfile savedBankProfile, UserTypeTempService defaultUser) {
//        BankUserTemp bankUserTemp = new BankUserTemp();
//        bankUserTemp.setLoginId(bankUserLoginId);
//        bankUserTemp.setFirstName(bankUserFirstName);
//        bankUserTemp.setLastName(bankUserLastName);
//        bankUserTemp.setEmail(bankUserEmail);
//        bankUserTemp.setBankProfile(savedBankProfile);
//        bankUserTemp.setCreatedDate(LocalDateTime.now());
//        bankUserTemp.setCreatedBy("SYSTEM");
//        bankUserTemp.setBankUserStatus("Active");
//        bankUserTemp.setStatus("APPROVED");
//        bankUserTemp.setUserPassword(encodedPassword);
//        bankUserTemp.setUserType(defaultUser);
//
//        BankUserTemp savedBankUserTemp = bankUserTempDao.save(bankUserTemp);
//
//        // Create User using the generated ID from UserTemp
//        BankUser bankUser = new BankUser();
//        bankUser.setBankUserId(savedBankUserTemp.getBankUserId());
//        bankUser.setLoginId(bankUserLoginId);
//        bankUser.setFirstName(bankUserFirstName);
//        bankUser.setLastName(bankUserLastName);
//        bankUser.setEmail(bankUserEmail);
//        bankUser.setBankProfile(savedBankProfile);
//        bankUser.setCreatedDate(LocalDateTime.now());
//        bankUser.setCreatedBy("SYSTEM");
//        bankUser.setBankUserStatus("Active");
//        bankUser.setUserPassword(encodedPassword);
//        bankUser.setUserType(defaultUser);
//
//
//        BankUser savedBankUser = bankUserDao.save(bankUser);
//        return savedBankUser;
//    }
//
//    private BankProfile saveInitialAdminBankProfile() {
//        BankProfileTemp bankProfileTemp = new BankProfileTemp();
//        bankProfileTemp.setCifId(bankCifId);
//        bankProfileTemp.setAbbvName(bankAbbvName);
//        bankProfileTemp.setName(bankName);
//        bankProfileTemp.setBaseCurrency(bankBaseCurr);
//        bankProfileTemp.setEmail(bankEmail);
//        bankProfileTemp.setCreatedDate(LocalDateTime.now());
//        bankProfileTemp.setCreatedBy("SYSTEM");
//        bankProfileTemp.setStatus(Status.APPROVED.toString());
//
//        BankProfileTemp savedBankProfileTemp = bankProfileTempDao.save(bankProfileTemp);
//
//        // Create BankProfile using the generated ID from CompanyTemp
//        BankProfile bankProfile = new BankProfile();
//        bankProfile.setBankProfileId(savedBankProfileTemp.getBankProfileId());
//        bankProfile.setCifId(bankCifId);
//        bankProfile.setAbbvName(bankAbbvName);
//        bankProfile.setName(bankName);
//        bankProfile.setBaseCurrency(bankBaseCurr);
//        bankProfile.setEmail(bankEmail);
//        bankProfile.setCreatedDate(LocalDateTime.now());
//        bankProfile.setCreatedBy("SYSTEM");
//
//        BankProfile savedBankProfile = bankProfileDao.save(bankProfile);
//        log.info("Bank saved with ID: {}", savedBankProfile.getBankProfileId());
//        return savedBankProfile;
//    }
//}
@Component
@RequiredArgsConstructor
@Slf4j
//@PropertySource("classpath:dataseed.properties")
public class DataSeeder implements CommandLineRunner {

    private final BankProfileDao bankProfileDao;
    private final BankProfileTempDao bankProfileTempDao;
    private final BankUserDao bankUserDao;
    private final BankUserTempDao bankUserTempDao;
    private final CompanyDao companyDao;
    private final CompanyTempDao companyTempDao;
    private final UserDao userDao;
    private final UserTempDao userTempDao;
    private final UserTypeDao userTypeDao;
    private final EntityManager entityManager;
    private final BankSeedProperties bankSeedProperties;
    private final CompanySeedProperties companySeedProperties;
    private final ProductMasterDao productMasterDao;
    private final SubProductMasterDao subProductMasterDao;
    private final SubProductMasterTempDao subProductMasterTempDao;
    private final TabMasterDao tabMasterDao;
    private final BaseWidgetSeedProperties baseWidgetSeedProperties;
    private final CategoryMasterDao categoryMasterDao;
    private final ActionDao actionDao;
    private final ProductMasterTempDao productMasterTempDao;

    @Value("${seed.enabled:false}")
    private boolean seedEnabled;

    @Override
    @Transactional
    public void run(String... args) {

        if (!seedEnabled) {
            log.info("Seed Disabled");
            return;
        }

        // Seed reference data (auth groups, categories, user types) BEFORE
        // bank profile/user creation. Previously this ran via data.sql, but
        // spring.sql.init.mode is silently overridden to 'never' on the
        // cluster, so data.sql doesn't execute. Seeding from Java is
        // resilient to that environment override.
        seedReferenceData();

        PasswordEncoder encoder = new BCryptPasswordEncoder();

        for (BankSeedProperties.BankProfileSeed profileSeed
                : bankSeedProperties.getProfile()) {

            Long bankExists = entityManager.createQuery(
                            "SELECT COUNT(b) FROM BankProfile b WHERE b.cifIdHash = :cif",
                            Long.class)
                    .setParameter("cif", HashUtils.HAMCMD5Hash(profileSeed.getCifId()))
                    .getSingleResult();

            if (bankExists > 0) {
                log.info("Bank {} exists → Skipping",
                        profileSeed.getCifId());
                continue;
            }

            BankProfile savedProfile =
                    saveBankProfile(profileSeed);

            for (BankSeedProperties.BankUserSeed userSeed
                    : bankSeedProperties.getUser()) {

                Long userExists = entityManager.createQuery(
                                "SELECT COUNT(u) FROM BankUser u WHERE u.loginId = :loginId",
                                Long.class)
                        .setParameter("loginId",
                                userSeed.getLoginId())
                        .getSingleResult();

                if (userExists > 0) {
                    log.info("User {} exists → Skipping",
                            userSeed.getLoginId());
                    continue;
                }

                UserType userType =
                        userTypeDao.findByUserTypeName(
                                userSeed.getUserType());

                saveBankUser(
                        userSeed,
                        savedProfile,
                        encoder.encode(
                                userSeed.getPassword()),
                        userType
                );


            }
        }

        seedWidgetData();

        log.info("Initial Bank Seed Completed");

//        for (CompanySeedProperties.CompanyProfileSeed profileSeed
//                : companySeedProperties.getProfile()) {
//
//            Long companyExists = entityManager.createQuery(
//                            "SELECT COUNT(c) FROM Company c WHERE c.cifId = :cif",
//                            Long.class)
//                    .setParameter("cif", profileSeed.getCifId())
//                    .getSingleResult();
//
//            if (companyExists > 0) {
//                log.info("Company {} exists → Skipping",
//                        profileSeed.getCifId());
//                continue;
//            }
//
//            Company savedCompany =
//                    saveCompanyProfile(profileSeed);
//
//            for (CompanySeedProperties.CompanyUserSeed userSeed
//                    : companySeedProperties.getUser()) {
//
//                Long userExists = entityManager.createQuery(
//                                "SELECT COUNT(u) FROM User u WHERE u.loginId = :loginId",
//                                Long.class)
//                        .setParameter("loginId",
//                                userSeed.getLoginId())
//                        .getSingleResult();
//
//                if (userExists > 0) {
//                    log.info("User {} exists → Skipping",
//                            userSeed.getLoginId());
//                    continue;
//                }
//
//                UserTypeTempService userType =
//                        userTypeDao.findByUserTypeName(
//                                userSeed.getUserType());
//
//                saveCompanyUser(
//                        userSeed,
//                        savedCompany,
//                        encoder.encode(
//                                userSeed.getPassword()),
//                        userType
//                );
//            }
//        }
//
//        log.info("Initial Company Seed Completed");
    }

    private BankProfile saveBankProfile(
            BankSeedProperties.BankProfileSeed seed) {

        BankProfileTemp temp = new BankProfileTemp();

        temp.setCifId(seed.getCifId());
        temp.setAbbvName(seed.getAbbvName());
        temp.setName(seed.getName());
        temp.setBaseCurrency(seed.getBaseCurrency());
        temp.setEmail(seed.getEmail());
        temp.setCreatedBy("SYSTEM");
        temp.setCreatedDate(LocalDateTime.now());
        temp.setStatus(Status.APPROVED.toString());

        BankProfileTemp savedTemp =
                bankProfileTempDao.save(temp);

        BankProfile bank = new BankProfile();

        bank.setBankProfileId(savedTemp.getBankProfileId());
        bank.setCifId(seed.getCifId());
        bank.setAbbvName(seed.getAbbvName());
        bank.setName(seed.getName());
        bank.setBaseCurrency(seed.getBaseCurrency());
        bank.setEmail(seed.getEmail());
        bank.setCreatedBy("SYSTEM");
        bank.setCreatedDate(LocalDateTime.now());

        BankProfile savedBank =
                bankProfileDao.save(bank);

        log.info("Bank created → {}",
                savedBank.getCifId());

        return savedBank;
    }

    private void saveBankUser(
            BankSeedProperties.BankUserSeed seed,
            BankProfile profile,
            String encodedPassword,
            UserType userType) {

        BankUserTemp temp = new BankUserTemp();

        temp.setLoginId(seed.getLoginId());
        temp.setFirstName(seed.getFirstName());
        temp.setLastName(seed.getLastName());
        temp.setEmail(seed.getEmail());
        temp.setBankProfile(profile);
        temp.setUserPassword(encodedPassword);
        temp.setUserType(userType);
        temp.setContactNo(seed.getContactNo());
        temp.setBankUserStatus("Active");
        temp.setStatus("APPROVED");
        temp.setCreatedBy("SYSTEM");
        temp.setCreatedDate(LocalDateTime.now());

        BankUserTemp savedTemp =
                bankUserTempDao.save(temp);

        BankUser user = new BankUser();

        user.setBankUserId(savedTemp.getBankUserId());
        user.setLoginId(seed.getLoginId());
        user.setFirstName(seed.getFirstName());
        user.setLastName(seed.getLastName());
        user.setEmail(seed.getEmail());
        user.setBankProfile(profile);
        user.setUserPassword(encodedPassword);
        user.setUserType(userType);
        user.setContactNo(seed.getContactNo());
        user.setBankUserStatus("Active");
        user.setCreatedBy("SYSTEM");
        user.setCreatedDate(LocalDateTime.now());

        bankUserDao.save(user);

        log.info("  ↳ User created → {}",
                seed.getLoginId());
    }

    private Company saveCompanyProfile(
            CompanySeedProperties.CompanyProfileSeed seed) {

        CompanyTemp temp = new CompanyTemp();

        temp.setCifId(seed.getCifId());
        temp.setAbbvName(seed.getAbbvName());
        temp.setName(seed.getName());
        temp.setBaseCurrency(seed.getBaseCurrency());
        temp.setEmail(seed.getEmail());
        temp.setCreatedBy("SYSTEM");
        temp.setCreatedDate(LocalDateTime.now());
        temp.setStatus(Status.APPROVED.toString());

        CompanyTemp savedTemp =
                companyTempDao.save(temp);

        Company company = new Company();

        company.setCompanyId(savedTemp.getCompanyId());
        company.setCifId(seed.getCifId());
        company.setAbbvName(seed.getAbbvName());
        company.setName(seed.getName());
        company.setBaseCurrency(seed.getBaseCurrency());
        company.setEmail(seed.getEmail());
        company.setCreatedBy("SYSTEM");
        company.setCreatedDate(LocalDateTime.now());

        Company savedCompany =
                companyDao.save(company);

        log.info("Company created → {}",
                savedCompany.getCifId());

        return savedCompany;
    }

    private void saveCompanyUser(
            CompanySeedProperties.CompanyUserSeed seed,
            Company company,
            String encodedPassword,
            UserType userType) {

        UserTemp temp = new UserTemp();

        temp.setLoginId(seed.getLoginId());
        temp.setFirstName(seed.getFirstName());
        temp.setLastName(seed.getLastName());
        temp.setEmail(seed.getEmail());
        temp.setCompany(company);
        temp.setUserPassword(encodedPassword);
        temp.setUserType(userType);
        temp.setUserStatus("Active");
        temp.setStatus("APPROVED");
        temp.setMaker("SYSTEM");
        temp.setCreated(LocalDateTime.now());

        UserTemp savedTemp =
                userTempDao.save(temp);

        User user = new User();

        user.setUserId(savedTemp.getUserId());
        user.setLoginId(seed.getLoginId());
        user.setFirstName(seed.getFirstName());
        user.setLastName(seed.getLastName());
        user.setEmail(seed.getEmail());
        user.setCompany(company);
        user.setUserPassword(encodedPassword);
        user.setUserType(userType);
        user.setUserStatus("Active");
        user.setMaker("SYSTEM");
        user.setCreated(LocalDateTime.now());

        userDao.save(user);

        log.info("  ↳ User created → {}",
                seed.getLoginId());
    }

    /**
     * Seeds reference data that previously lived in data.sql:
     *   - gtp_auth_group   (8 rows: A-H, ids 1-8)
     *   - gtp_category_master (Client=1, Bank=2)
     *   - gtp_user_type     (13 rows incl. Super Admin=20)
     *
     * Idempotent: every INSERT uses WHERE NOT EXISTS so re-running is safe.
     * Uses native SQL through EntityManager to allow explicit IDs on MSSQL's
     * IDENTITY columns (Hibernate's save() with a pre-set IDENTITY pk would be
     * ignored by the DB). MSSQL allows SELECT without a FROM clause, so the
     * FROM dual that Oracle required has been dropped.
     */
    private void seedReferenceData() {
        log.info("Seeding reference data (auth groups / categories / user types) ...");

        // gtp_auth_group: A-H, ids 1-8
        // MSSQL IDENTITY columns reject explicit values unless IDENTITY_INSERT is ON.
        setIdentityInsert("gtp_auth_group", true);
        try {
            char letter = 'A';
            for (long id = 1L; id <= 8L; id++, letter++) {
                entityManager.createNativeQuery(
                                "INSERT INTO gtp_auth_group (id, auth_group) "
                                        + "SELECT :id, :v "
                                        + "WHERE NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = :id)")
                        .setParameter("id", id)
                        .setParameter("v", String.valueOf(letter))
                        .executeUpdate();
            }
        } finally {
            setIdentityInsert("gtp_auth_group", false);
        }

        // gtp_category_master: Client=1, Bank=2 (explicit ids so basewidget.yml + user_type FK refs match)
        setIdentityInsert("gtp_category_master", true);
        try {
            upsertCategory(1L, "Client");
            upsertCategory(2L, "Bank");
        } finally {
            setIdentityInsert("gtp_category_master", false);
        }

        // gtp_user_type: 13 rows (FK -> gtp_category_master)
        setIdentityInsert("gtp_user_type", true);
        try {
            upsertUserType(20L, "Super Admin",              2L);
            upsertUserType(21L, "Bank Super Admin Maker",   2L);
            upsertUserType(22L, "Bank Super Admin Checker", 2L);
            upsertUserType(23L, "Bank Setup Maker",         2L);
            upsertUserType(24L, "Bank Setup Checker",       2L);
            upsertUserType(25L, "Bank View Only",           2L);
            upsertUserType(26L, "Bank Branch Verifier",     2L);
            upsertUserType(27L, "Client (M=C)",             1L);
            upsertUserType(28L, "Client Maker",             1L);
            upsertUserType(29L, "Client Checker",           1L);
            upsertUserType(30L, "Client Verifier",          1L);
            upsertUserType(31L, "Client Releaser",          1L);
            upsertUserType(32L, "Client View",              1L);
        } finally {
            setIdentityInsert("gtp_user_type", false);
        }

        // Flush so subsequent JPA reads (e.g. userTypeDao.findByUserTypeName)
        // see the inserted rows in the same transaction.
        entityManager.flush();

        log.info("Reference data seeded.");
    }

    /**
     * IDENTITY_INSERT must be issued via a plain JDBC Statement on the
     * transaction's Connection. EntityManager.createNativeQuery routes through
     * a PreparedStatement which the MSSQL driver may execute in a way that
     * doesn't persist the IDENTITY_INSERT setting for subsequent inserts.
     */

//    private void setIdentityInsert(String table, boolean on) {
//        org.hibernate.Session session = entityManager.unwrap(org.hibernate.Session.class);
//        final String sql = "SET IDENTITY_INSERT " + table + " " + (on ? "ON" : "OFF");
//        session.doWork(connection -> {
//            try (java.sql.Statement stmt = connection.createStatement()) {
//                stmt.execute(sql);
//            }
//        });
//    }

    private void setIdentityInsert(String table, boolean on) {
        org.hibernate.Session session = entityManager.unwrap(org.hibernate.Session.class);
        session.doWork(connection -> {
            String productName = connection.getMetaData().getDatabaseProductName();
            if (productName == null || !productName.toLowerCase().contains("microsoft sql server")) {
                return;
            }
            final String sql = "SET IDENTITY_INSERT " + table + " " + (on ? "ON" : "OFF");
            try (java.sql.Statement stmt = connection.createStatement()) {
                stmt.execute(sql);
            }
        });
    }

    private void upsertCategory(Long id, String name) {
        entityManager.createNativeQuery(
                        "INSERT INTO gtp_category_master (category_id, category_name) "
                                + "SELECT :id, :n "
                                + "WHERE NOT EXISTS (SELECT 1 FROM gtp_category_master WHERE category_id = :id)")
                .setParameter("id", id)
                .setParameter("n", name)
                .executeUpdate();
    }

    private void upsertUserType(Long id, String name, Long categoryId) {
        entityManager.createNativeQuery(
                        "INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) "
                                + "SELECT :id, :n, :c "
                                + "WHERE NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = :id)")
                .setParameter("id", id)
                .setParameter("n", name)
                .setParameter("c", categoryId)
                .executeUpdate();
    }

    private void seedWidgetData() {
        log.info("Starting Widget Seed...");
        for (BaseWidgetSeedProperties.ProductSeed pSeed : baseWidgetSeedProperties.getProducts()) {
            ProductMasterTemp productTemp = productMasterTempDao
                    .findByProductName(pSeed.getName())
                    .orElseGet(() -> {
                        CategoryMaster category = categoryMasterDao.findById(pSeed.getCategory()).orElseThrow();
                        ProductMasterTemp p = new ProductMasterTemp();
                        p.setProductName(pSeed.getName());
                        p.setProductNameLabel(pSeed.getName());
                        p.setCategory(category);
                        p.setSequenceId(pSeed.getSequenceId());
                        p.setStatus(Status.APPROVED);
                        return productMasterTempDao.save(p);
                    });
            log.info("Product processed → {}", productTemp.getProductName());
        //Check if product exists
            ProductMaster product = productMasterDao
                    .findByProductName(pSeed.getName())
                    .orElseGet(() -> {
                        CategoryMaster category = categoryMasterDao.findById(pSeed.getCategory()).orElse(null);
                        if (category == null) {
                            log.warn("Category id {} not found in DB → skipping product {}",
                                    pSeed.getCategory(), pSeed.getName());
                            return null;
                        }
                        ProductMaster p = new ProductMaster();
                        p.setProductId(productTemp.getProductId());
                        p.setProductName(pSeed.getName());
                        p.setProductNameLabel(pSeed.getName());
                        p.setCategory(category);
                        p.setSequenceId(pSeed.getSequenceId());
                        return productMasterDao.save(p);
                    });
            if (product == null) continue;
            log.info("Product processed → {}", product.getProductName());

//            if(pSeed.getActions() != null && !pSeed.getActions().isEmpty()){
//
//                for(String actionName : pSeed.getActions()){
//
//                    Action action = actionDao.findByActionCode(actionName)
//                            .orElseGet(() -> {
//                                Action a = new Action();
//                                a.setActionName(actionName);
//                                a.setActionNameLabel(actionName);
//                                return actionDao.save(a);
//                            });
//
//                    //Map action → product
////                    if (!action.getProductMaster().contains(product)) {
////                        action.getProductMaster().add(product);
////                    }
////
////                    //Optional bidirectional safety
////                    if (!product.getActions().contains(action)) {
////                        product.getActions().add(action);
////                    }
//
//                    actionDao.save(action);
//
//                    log.info(
//                            "Action mapped: {} → Product {}",
//                            action.getActionName(),
//                            product.getProductName()
//                    );
//                }
//
//            }

            //Handle subproducts
            if (pSeed.getSubProducts() == null || pSeed.getSubProducts().isEmpty()) {
                createSubProductAndTab(product, product.getProductName());
            } else {
                for (BaseWidgetSeedProperties.SubProductSeed spSeed : pSeed.getSubProducts()) {
                    SubProductMasterTemp subProductTemp = subProductMasterTempDao
                            .findBySubProductNameAndProductMaster(
                                    spSeed.getName(), product)
                            .orElseGet(() -> {
                                SubProductMasterTemp sp = new SubProductMasterTemp();
                                sp.setSubProductName(spSeed.getName());
                                sp.setProductMaster(product);
                                sp.setSubProductLabel(spSeed.getName());
                                sp.setSequenceId(spSeed.getSequenceId());
                                sp.setStatus(Status.APPROVED);
                                return subProductMasterTempDao.save(sp);
                            });
                    SubProductMaster subProduct = subProductMasterDao
                            .findBySubProductNameAndProductMaster(
                                    spSeed.getName(), product)
                            .orElseGet(() -> {
                                SubProductMaster sp = new SubProductMaster();
                                sp.setSubProductId(subProductTemp.getSubProductId());
                                sp.setSubProductName(spSeed.getName());
                                sp.setSubProductLabel(spSeed.getName());
                                sp.setProductMaster(product);
                                sp.setSequenceId(spSeed.getSequenceId());
                                return subProductMasterDao.save(sp);
                            });
                    log.info("SubProduct processed → {}", subProduct.getSubProductName());
                    //Tabs
                    if (spSeed.getTabs() == null || spSeed.getTabs().isEmpty()) {
//                        createTabForSubProduct(product, subProduct, subProduct.getSubProductName());
                    } else {
                        for (BaseWidgetSeedProperties.TabSeed tSeed : spSeed.getTabs()) {
//                            createTabForSubProduct(product, subProduct, tSeed.getName());
                        }
                    }
                }
            }
        }
        log.info("Widget Seed Completed");
    }

    private void createSubProductAndTab(ProductMaster product, String name) {

        SubProductMaster subProduct = subProductMasterDao
                .findBySubProductNameAndProductMaster(name, product)
                .orElseGet(() -> {
                    SubProductMaster sp = new SubProductMaster();
                    sp.setSubProductName(name);
                    sp.setProductMaster(product);
                    return subProductMasterDao.save(sp);
                });

//        createTabForSubProduct(product, subProduct, name);
    }

    private void createTabForSubProduct(ProductMaster product, SubProductMaster subProduct, String tabName) {

        TabMaster tab = tabMasterDao.findByTabName(tabName)
                .orElseGet(() -> {
                    TabMaster t = new TabMaster();
                    t.setTabName(tabName);
                    return tabMasterDao.save(t);
                });

//        // Avoid duplicate mapping
//        if(!tab.getProducts().contains(product)){
//            tab.getProducts().add(product);
//        }
//
//        if (!tab.getSubProducts().contains(subProduct)) {
//            tab.getSubProducts().add(subProduct);
//        }
//
//        if (!subProduct.getTabs().contains(tab)) {
//            subProduct.getTabs().add(tab);
//        }

        tabMasterDao.save(tab);
    }

    }
