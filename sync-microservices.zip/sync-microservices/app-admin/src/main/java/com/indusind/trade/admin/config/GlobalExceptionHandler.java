package com.indusind.trade.admin.config;

import com.indusind.trade.model.common.dto.StandardErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @Value("${spring.application.name:admin-service}")
    private String serviceName;

    private StandardErrorResponse buildErrorResponse(String errorCode, String message) {
        return StandardErrorResponse.builder()
                .timestamp(Instant.now().toString())
                .service(serviceName)
                .errorCode(errorCode)
                .message(message)
                .correlationId(MDC.get("correlationId"))
                .build();
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<StandardErrorResponse> handleMethodArgumentNotValid(MethodArgumentNotValidException e) {
        String errorMsg = e.getBindingResult().getFieldErrors().stream()
                .map(err -> err.getField() + ": " + err.getDefaultMessage())
                .collect(Collectors.joining(", "));

        log.error("Validation error: {}", errorMsg);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(buildErrorResponse("VALIDATION_ERROR", errorMsg));
    }

    // Fallback for Business/Generic Runtime exceptions
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<StandardErrorResponse> handleRuntimeException(RuntimeException e) {
        log.error("Runtime exception: ", e);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(buildErrorResponse("BUSINESS_ERROR", e.getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<StandardErrorResponse> handleAllExceptions(Exception e) {
        log.error("Unhandled exception: ", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(buildErrorResponse("INTERNAL_ERROR", "An unexpected error occurred"));
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<StandardErrorResponse> handleDataIntegrity(
            DataIntegrityViolationException ex) {

        String fieldMessage = "Duplicate value";
        String columns = "Unknown";

        Throwable rootCause = getRootCause(ex);
        String message = rootCause.getMessage();

//        if (rootCause instanceof org.postgresql.util.PSQLException psqle) {
//            String detail = psqle.getMessage();
//
//            // Extract columns from Postgres error
//            // Example:
//            // Key (user_type_name, category_id)=(Bank Super Admin Maker, 2) already exists.
//            if (detail != null && detail.contains("Key (")) {
//                columns = detail.substring(
//                        detail.indexOf("Key (") + 5,
//                        detail.indexOf(")=")
//                );
//                fieldMessage = "Duplicate entry for columns: " + columns;
//            }
//        }
        if (rootCause instanceof org.postgresql.util.PSQLException psqle) {
            // PostgreSQL
            String detail = psqle.getMessage();
            if (detail != null && detail.contains("Key (")) {
                columns = extractBetween(detail, "Key (", ")=");
                fieldMessage = "Duplicate entry for columns: " + columns;
            }

        } else if (message != null) {

            // Oracle
            // ORA-00001: unique constraint (SCHEMA.CONSTRAINT_NAME) violated
            if (message.contains("ORA-00001")) {
                columns = extractBetween(message, "(", ")");
                fieldMessage = "Duplicate entry (constraint violation): " + columns;
            }

            // SQL Server
            // Error 2627 or 2601: Violation of UNIQUE KEY constraint 'constraint_name'
            else if (message.contains("2627") || message.contains("2601")) {
                if (message.contains("constraint")) {
                    columns = extractBetween(message, "constraint '", "'");
                }
                fieldMessage = "Duplicate entry (unique constraint violation): " + columns;
            }
        }

        StandardErrorResponse response = buildErrorResponse("DUPLICATE", fieldMessage);

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
    }

//    private Throwable getRootCause(Throwable ex) {
//        Throwable cause = ex;
//        while (cause.getCause() != null && cause.getCause() != cause) {
//            cause = cause.getCause();
//        }
//        return cause;
//    }
    private Throwable getRootCause(Throwable ex) {
        Throwable cause = ex;
        while (cause.getCause() != null && cause.getCause() != cause) {
            cause = cause.getCause();
        }
        return cause;
    }

    private String extractBetween(String text, String start, String end) {
        try {
            int startIdx = text.indexOf(start);
            int endIdx = text.indexOf(end, startIdx + start.length());
            if (startIdx != -1 && endIdx != -1) {
                return text.substring(startIdx + start.length(), endIdx);
            }
        } catch (Exception ignored) {
        }
        return "Unknown";
    }
}
