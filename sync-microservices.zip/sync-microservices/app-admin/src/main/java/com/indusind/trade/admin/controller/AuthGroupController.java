package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.AuthGroupFacade;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/authGroup")
public class AuthGroupController {

    private final AuthGroupFacade authGroupFacade;

    @GetMapping("/getAuthGroups")
    public ResponseEntity<ApplicationResponse> getAuthGroups() {
        ApplicationResponse response = authGroupFacade.getAuthGroups();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
