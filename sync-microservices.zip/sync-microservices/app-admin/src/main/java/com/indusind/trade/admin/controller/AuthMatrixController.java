package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.AuthMatrixFacade;
import com.indusind.trade.model.dtos.requestdtos.AddAuthMatrixRequestDto;
import com.indusind.trade.model.dtos.requestdtos.ApproveRejectGroupedAuthMatrixRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/authMatrix")
public class AuthMatrixController {

    private final AuthMatrixFacade authMatrixFacade;

    @PostMapping("/addAuthMatrix")
    public ResponseEntity<ApplicationResponse> saveAuthMatrix(@RequestBody AddAuthMatrixRequestDto request) {
        ApplicationResponse response = authMatrixFacade.addAuthMatrix(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveAuthMatrix")
    public ResponseEntity<ApplicationResponse> approveAuthMatrix(@RequestParam Long id) {
        ApplicationResponse response = authMatrixFacade.approveAuthMatrix(id);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveGroupedAuthMatrix")
    public ResponseEntity<ApplicationResponse> approveGroupedAuthMatrix(@RequestBody ApproveRejectGroupedAuthMatrixRequestDto request) {
        ApplicationResponse response = authMatrixFacade.approveGroupedAuthMatrix(request.authMatrixIds());
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectGroupedAuthMatrix")
    public ResponseEntity<ApplicationResponse> rejectGroupedAuthMatrix(@RequestBody ApproveRejectGroupedAuthMatrixRequestDto request) {
        ApplicationResponse response = authMatrixFacade.rejectGroupedAuthMatrix(request.authMatrixIds());
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectAuthMatrix")
    public ResponseEntity<ApplicationResponse> rejectAuthMatrix(@RequestParam Long id) {
        ApplicationResponse response = authMatrixFacade.rejectAuthMatrix(id);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAuthMatrixById")
    public ResponseEntity<ApplicationResponse> getAuthMatrixById(@RequestParam Long id, @RequestParam String category) {
        ApplicationResponse response = authMatrixFacade.getAuthMatrixById(id, category);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAuthMatrixTempById")
    public ResponseEntity<ApplicationResponse> getAuthMatrixTempById(@RequestParam Long id, @RequestParam String category) {
        ApplicationResponse response = authMatrixFacade.getAuthMatrixTempById(id, category);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllAuthMatrix")
    public ResponseEntity<ApplicationResponse> getAllAuthMatrix(@PageableDefault(page = 0, size = 10) Pageable pageable, @RequestParam String category,@RequestParam(required = false) Long companyId) {
        ApplicationResponse response = authMatrixFacade.getAllAuthMatrix(pageable, category,companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllAuthMatrixTemp")
    public ResponseEntity<ApplicationResponse> getAllAuthMatrixTemp(
            @PageableDefault(page = 0, size = 10) Pageable pageable,
            @RequestParam String category,@RequestParam(required = false) Long companyId) {
        ApplicationResponse response = authMatrixFacade.getAllAuthMatrixTemp(pageable, category,companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllGroupedAuthMatrixTemp")
    public ResponseEntity<ApplicationResponse> getAllAuthMatrixTempAllMapping(
            @PageableDefault(page = 0, size = 10) Pageable pageable,
            @RequestParam String category,
            @RequestParam(required = false) Long companyId) {
        ApplicationResponse response = authMatrixFacade.getAllAuthMatrixTempAllMapping(
                pageable, category,companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllGroupedAuthMatrix")
    public ResponseEntity<ApplicationResponse> getAllAuthMatrixAllMapping(
            @PageableDefault(page = 0, size = 10) Pageable pageable,
            @RequestParam String category,
            @RequestParam(required = false) Long companyId) {
        ApplicationResponse response = authMatrixFacade.getAllAuthMatrixAllMapping(
                pageable, category,companyId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
