package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.CategoryMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.CategoryMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/category")
@RequiredArgsConstructor
public class CategoryMasterController {

    private final CategoryMasterFacade categoryMasterFacade;

    @PostMapping("/saveCategory")
    public ResponseEntity<ApplicationResponse> saveCategory(@RequestBody CategoryMasterDto CategoryMasterDto) {
        ApplicationResponse response = categoryMasterFacade.saveCategory(CategoryMasterDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/updateCategory")
    public ResponseEntity<ApplicationResponse> updateCategory(@RequestBody CategoryMasterDto CategoryMasterDto) {
        ApplicationResponse response = categoryMasterFacade.saveCategory(CategoryMasterDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllCategories")
    public ResponseEntity<ApplicationResponse> getAllCategories(@PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = categoryMasterFacade.getAllCategories(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllCategories/all")
    public ResponseEntity<ApplicationResponse> getAllCategories() {
        ApplicationResponse response = categoryMasterFacade.getAllCategories(null);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getCategory")
    public ResponseEntity<ApplicationResponse> getCategory(@RequestParam Long categoryId) {
        ApplicationResponse response = categoryMasterFacade.getCategoryById(categoryId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getCategoryByName")
    public ResponseEntity<ApplicationResponse> getCategoryByName(@RequestParam String categoryName) {
        ApplicationResponse response = categoryMasterFacade.getCategoryByName(categoryName);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getUserTypeByCategoryId")
    public ResponseEntity<ApplicationResponse> getUserTypeByCategoryId(@RequestParam Long categoryId) {
        ApplicationResponse response = categoryMasterFacade.getUserTypesByCategoryId(categoryId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getUserTypeByCategory")
    public ResponseEntity<ApplicationResponse> getUserTypeByCategory(@RequestParam String category) {
        ApplicationResponse response = categoryMasterFacade.getAllUserTypesByCategory(category);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProductsByCategoryId")
    public ResponseEntity<ApplicationResponse> getProductsByCategoryId(@RequestParam Long categoryId) {
        ApplicationResponse response = categoryMasterFacade.getProductsByCategoryId(categoryId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
