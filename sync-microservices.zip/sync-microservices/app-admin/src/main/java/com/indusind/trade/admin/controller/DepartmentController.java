package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.DepartmentFacade;
import com.indusind.trade.model.dtos.requestdtos.DepartmentRequestDto;
import com.indusind.trade.model.dtos.requestdtos.DepartmentToUserTypeMappingRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/department")
@RequiredArgsConstructor
public class DepartmentController {

    private final DepartmentFacade departmentFacade;

    @GetMapping("/getAllDepartments")
    public ResponseEntity<ApplicationResponse> getAllDepartments() {
        ApplicationResponse response = departmentFacade.getAllDepartments();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getDepartmentsByCategoryId")
    public ResponseEntity<ApplicationResponse> getDeptListByCategoryId(@RequestParam Long categoryId) {
        ApplicationResponse response = departmentFacade.getDeptByCategoryId(categoryId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/createDepartment")
    public ResponseEntity<ApplicationResponse> createDepartment(@RequestBody DepartmentRequestDto request) {
        ApplicationResponse response = departmentFacade.createDepartment(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveDepartment")
    public ResponseEntity<ApplicationResponse> approveDepartment(@RequestParam Long departmentId) {
        ApplicationResponse response = departmentFacade.approveDepartment(departmentId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectDepartment")
    public ResponseEntity<ApplicationResponse> rejectDepartment(@RequestParam Long departmentId){
        ApplicationResponse response = departmentFacade.rejectDepartment(departmentId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTempDepartment")
    public ResponseEntity<ApplicationResponse> getAllTempDepartment(
            @PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = departmentFacade.getAllTempDepartments(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/mapUserType")
    public ResponseEntity<ApplicationResponse> mapuserTypes(@RequestBody DepartmentToUserTypeMappingRequestDto request) {
        ApplicationResponse response = departmentFacade.mapUserTypesWithDepartment(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

}
