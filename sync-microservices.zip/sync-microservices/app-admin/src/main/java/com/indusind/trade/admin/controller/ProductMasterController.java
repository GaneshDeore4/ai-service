package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.ProductMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.ProductMasterDto;
import com.indusind.trade.model.dtos.requestdtos.ProductMidOfficeMappingRequestDto;
import com.indusind.trade.model.dtos.requestdtos.UserDTO;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/product")
@RequiredArgsConstructor
public class ProductMasterController {

    private final ProductMasterFacade productMasterFacade;

    @PostMapping("/saveProduct")
    public ResponseEntity<ApplicationResponse> saveProduct(@RequestBody ProductMasterDto productMasterDto) {
        ApplicationResponse response = productMasterFacade.saveProductTemp(productMasterDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveProduct")
    public ResponseEntity<ApplicationResponse> approveProduct(@RequestParam Long productId) {
        ApplicationResponse response = productMasterFacade.approveProduct(productId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectProduct")
    public ResponseEntity<ApplicationResponse> rejectProduct(@RequestParam Long productId){
        ApplicationResponse response = productMasterFacade.rejectProduct(productId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllProducts")
    public ResponseEntity<ApplicationResponse> getAllProducts(@PageableDefault(page = 0, size = 10, sort = "sequenceId") Pageable pageable) {
        ApplicationResponse response = productMasterFacade.getAllProducts(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTempProducts")
    public ResponseEntity<ApplicationResponse> getAllTempProducts(@PageableDefault(page = 0, size = 10, sort = "sequenceId") Pageable pageable) {
        ApplicationResponse response = productMasterFacade.getAllProductsTemp(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllProducts/all")
    public ResponseEntity<ApplicationResponse> getAllProducts() {
        ApplicationResponse response = productMasterFacade.getAllProducts(null);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllProductsTemp/all")
    public ResponseEntity<ApplicationResponse> getAllTempProducts() {
        ApplicationResponse response = productMasterFacade.getAllProductsTemp(null);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProduct")
    public ResponseEntity<ApplicationResponse> getProduct(@RequestParam Long productId) {
        ApplicationResponse response = productMasterFacade.getProductById(productId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProductTemp")
    public ResponseEntity<ApplicationResponse> getProductTemp(@RequestParam Long productId) {
        ApplicationResponse response = productMasterFacade.getProductById(productId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getSubProductsByProductId")
    public ResponseEntity<ApplicationResponse> getSubProductsByProductId(@RequestParam Long productId) {
        ApplicationResponse response = productMasterFacade.getSubProductsByProductId(productId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/getSubProductsByProductList")
    public ResponseEntity<ApplicationResponse> getSubProductsByProductList(@RequestBody List<Long> productIds) {
        ApplicationResponse response = productMasterFacade.getSubProductsByProductList(productIds);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTabsByProductId")
    public ResponseEntity<ApplicationResponse> getTabsByProductId(@RequestParam Long productId) {
        ApplicationResponse response = productMasterFacade.getTabsByProduct(productId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getActionsByProductId")
    public ResponseEntity<ApplicationResponse> getActionsByProductId(@RequestParam Long productId) {
        ApplicationResponse response = productMasterFacade.getActionsByProduct(productId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProdSubProdMapByCategoryId")
    public ResponseEntity<ApplicationResponse> getProdSubProdMapByCategoryId(@RequestParam Long categoryId) {
        ApplicationResponse response = productMasterFacade.getProdSubProdMapByCategoryId(categoryId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/mapProductToMidOffice")
    public ResponseEntity<ApplicationResponse> mapProductToMidOffice(@RequestBody ProductMidOfficeMappingRequestDto request) {
        ApplicationResponse response = productMasterFacade.mapProductToMidOffice(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllProductsByCategoryId")
    public ResponseEntity<ApplicationResponse> getAllProductsByCategoryId(@PageableDefault(page = 0, size = 10, sort = "productName") Pageable pageable, @RequestParam Long categoryId) {
        ApplicationResponse response = productMasterFacade.getAllProductsByCategoryId(pageable, categoryId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

}
