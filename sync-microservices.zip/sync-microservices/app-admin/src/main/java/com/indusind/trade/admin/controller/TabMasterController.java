package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.TabMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.TabMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/master")
public class TabMasterController {

    private final TabMasterFacade tabMasterFacade;

    @PostMapping("/addTab")
    public ResponseEntity<ApplicationResponse> addTabMaster(@Valid @RequestBody TabMasterDto tabMasterDto) {
        ApplicationResponse response = tabMasterFacade.saveTabTemp(tabMasterDto);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveTab")
    public ResponseEntity<ApplicationResponse> approveTab(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.approveTab(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectTab")
    public ResponseEntity<ApplicationResponse> rejectTab(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.rejectTab(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTabs")
    public ResponseEntity<ApplicationResponse> getAllTabMaster(@PageableDefault(page = 0, size = 10) Pageable pageable) {
        ApplicationResponse response = tabMasterFacade.getAllTabMaster(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTabsTemp")
    public ResponseEntity<ApplicationResponse> getAllTabsTemp(@PageableDefault(page = 0, size = 10) Pageable pageable) {
        ApplicationResponse response = tabMasterFacade.getAllTempTabMaster(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTabs/all")
    public ResponseEntity<ApplicationResponse> getAllTabMasterAll() {
        ApplicationResponse response = tabMasterFacade.getAllTabMaster(null);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTabsTemp/all")
    public ResponseEntity<ApplicationResponse> getAllTabsTempAll() {
        ApplicationResponse response = tabMasterFacade.getAllTempTabMaster(null);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTab")
    public ResponseEntity<ApplicationResponse> getTabById(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.getTabById(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTabTemp")
    public ResponseEntity<ApplicationResponse> getTabTempById(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.getTabTempById(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProdSubProdMappingForTab")
    public ResponseEntity<ApplicationResponse> getProdSubProdMappingForTab(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.getProdSubProdMappingForTab(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getProdSubProdMappingForTabTemp")
    public ResponseEntity<ApplicationResponse> getProdSubProdMappingForTabTemp(@RequestParam Long tabId) {
        ApplicationResponse response = tabMasterFacade.getProdSubProdMappingForTabTemp(tabId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getTabsByProdAndSubProd")
    public ResponseEntity<ApplicationResponse> getTabsByProdAndSubProd(@RequestParam Long productId, @RequestParam Long subProductId) {
        ApplicationResponse response = tabMasterFacade.getTabsByProdAndSubProd(productId,subProductId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }



}
