package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.UserAccountMappingFacade;
import com.indusind.trade.model.dtos.requestdtos.AddUserAccountMappingGroupedRequestDto;
import com.indusind.trade.model.dtos.requestdtos.AddUserAccountMappingRequestDto;
import com.indusind.trade.admin.dto.ApproveRejectUserAccountMappingRequestDto;
import com.indusind.trade.admin.dto.UserIdRequestDto; // Import the new DTO
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.admin.service.UserAccountMappingApprovalService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/account_mapping")
@RequiredArgsConstructor
public class UserAccountMappingController {

    private final UserAccountMappingFacade userAccountMappingFacade;
    private final UserAccountMappingApprovalService userAccountMappingApprovalService; // Inject new service

    @GetMapping("/account-details-cif")
    public ResponseEntity<ApplicationResponse> getAccountDetailsByCifId(@RequestParam String cifId) {
        ApplicationResponse response = userAccountMappingFacade.getAccountsByCifId(cifId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/user-account-mapping")
    public ResponseEntity<ApplicationResponse> addUserAccountMapping(
            @RequestBody AddUserAccountMappingRequestDto request
    ) {
        ApplicationResponse response = userAccountMappingFacade.addUserAccountMapping(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/user-account-mapping-grouped")
    public ResponseEntity<ApplicationResponse> addUserAccountMappingGrouped(
            @RequestBody AddUserAccountMappingGroupedRequestDto request
    ) {
        System.out.println("Inside addUserAccountMappingGrouped method");
        System.out.println("Request DTO" +request);
        ApplicationResponse response = userAccountMappingFacade.addBulkUserAccountMapping(request.getMappingRequest());
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/account-details-userId")
    public ResponseEntity<ApplicationResponse> getAccountDetailsByUserId(@RequestParam Long userId) {
        ApplicationResponse response = userAccountMappingFacade.getAccountsByUserId(userId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    // New endpoints for approval flow

    @PostMapping("/approve-user-account-mapping")
    public ResponseEntity<ApplicationResponse> approveUserAccountMapping(
            @RequestBody ApproveRejectUserAccountMappingRequestDto request
    ) {
        ApplicationResponse response = userAccountMappingApprovalService.approveUserAccountMapping(
                request.getUserId(), request.getAccountIds());
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/reject-user-account-mapping")
    public ResponseEntity<ApplicationResponse> rejectUserAccountMapping(
            @RequestBody ApproveRejectUserAccountMappingRequestDto request
    ) {
        ApplicationResponse response = userAccountMappingApprovalService.rejectUserAccountMapping(
                request.getUserId(), request.getAccountIds());
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/pending-user-account-mappings")
    public ResponseEntity<ApplicationResponse> getAllPendingUserAccountMappings() {
        ApplicationResponse response = userAccountMappingApprovalService.getAllPendingUserAccountMappings();
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/pending-user-account-mappings-by-user") // Changed to POST
    public ResponseEntity<ApplicationResponse> getPendingUserAccountMappingsByUserId(@RequestBody UserIdRequestDto request) { // Changed to @RequestBody
        ApplicationResponse response = userAccountMappingApprovalService.getPendingUserAccountMappingsByUserId(request.getUserId()); // Access userId from DTO
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
