package com.indusind.trade.admin.controller;

import com.indusind.trade.admin.facade.UserTypeFacade;
import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/userType")
public class UserTypeController {

    private final UserTypeFacade userTypeFacade;

    @PostMapping("/saveUserType")
    public ResponseEntity<ApplicationResponse> saveUserType(@RequestBody UserTypeDto request) {
        ApplicationResponse response = userTypeFacade.saveUserType(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/approveUserType")
    public ResponseEntity<ApplicationResponse> approveUserType(@RequestParam Long userTypeId){
        ApplicationResponse response = userTypeFacade.approveUserType(userTypeId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/rejectUserType")
    public ResponseEntity<ApplicationResponse> rejectUserType(@RequestParam Long userTypeId){
        ApplicationResponse response = userTypeFacade.rejectUserType(userTypeId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @PostMapping("/updateUserType")
    public ResponseEntity<ApplicationResponse> updateUserType(@RequestBody UserTypeDto request) {
        ApplicationResponse response = userTypeFacade.saveUserType(request);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllUserTypes")
    public ResponseEntity<ApplicationResponse> getAllUserTypes(
            @PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = userTypeFacade.getAllUserTypes(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/getAllTempUserTypes")
    public ResponseEntity<ApplicationResponse> getAllTempUserTypes(
            @PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        ApplicationResponse response = userTypeFacade.getAllTempUserType(pageable);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @RequestMapping(value = "/getUserType", method = { RequestMethod.GET, RequestMethod.POST })
    public ResponseEntity<ApplicationResponse> getUserType(
            @RequestParam(required = false) Long userTypeId,
            @RequestBody(required = false) UserTypeDto request) {
        Long id = userTypeId != null ? userTypeId : (request != null ? request.getUserTypeId() : null);
        if (id == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApplicationResponse("FAILURE", null,
                    "Required parameter 'userTypeId' is not present in request param or body"));
        }
        ApplicationResponse response = userTypeFacade.getUserTypeById(id);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping(value = "/getTempUserTypeById")
    public ResponseEntity<ApplicationResponse> getTempUserType(@RequestParam Long userTypeId) {
        //Long id = userTypeId != null ? userTypeId : (request != null ? request.getUserTypeId() : null);
        if (userTypeId == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApplicationResponse("FAILURE", null,
                    "Required parameter 'userTypeId' is not present in request param or body"));
        }
        ApplicationResponse response = userTypeFacade.getUserTypeTempById(userTypeId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping(value = "/getUserTypeByCategoryId")
    public ResponseEntity<ApplicationResponse> getUserTypeByCategory(@PageableDefault(page = 0, size = 10, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable, @RequestParam Long categoryId) {
        ApplicationResponse response = userTypeFacade.getUserTypePageByCategory(pageable, categoryId);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

}
