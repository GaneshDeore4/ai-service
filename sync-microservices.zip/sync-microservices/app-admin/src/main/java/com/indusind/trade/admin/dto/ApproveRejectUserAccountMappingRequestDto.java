package com.indusind.trade.admin.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApproveRejectUserAccountMappingRequestDto {
    private Long userId;
    private List<String> accountIds;
}
