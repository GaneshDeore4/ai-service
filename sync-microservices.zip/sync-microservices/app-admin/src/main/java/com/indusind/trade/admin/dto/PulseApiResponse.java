package com.indusind.trade.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class PulseApiResponse {

    @JsonProperty("Success")
    private String success;

    @JsonProperty("Message")
    private String message;

    @JsonProperty("Data")
    private PulseEmployeeResponseWrapper data;

}