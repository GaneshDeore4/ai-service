package com.indusind.trade.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PulseEmpRequestDto {

    @JsonProperty("Param")
    private String param;

    @JsonProperty("Apino")
    private String apiNo;
}
