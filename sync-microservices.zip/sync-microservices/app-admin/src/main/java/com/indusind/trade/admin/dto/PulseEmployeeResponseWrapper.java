package com.indusind.trade.admin.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.indusind.trade.model.dtos.response.dtos.PulseDetailsResponseDto;
import lombok.*;

import java.util.List;

@Getter
@Setter
public class PulseEmployeeResponseWrapper {

    @JsonProperty("Employee Basic API Data")
    private List<PulseDetailsResponseDto> pulseDetailsResponseDto;

}
