package com.indusind.trade.admin.entities;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "gtp_user_account_mapping_temp")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserAccountMappingTemp {

    @EmbeddedId
    private UserAccountMappingTempId id;

    @CreationTimestamp
    @Column(name = "create_time", updatable = false)
    private LocalDateTime createTime;

    @Column(name = "create_user")
    private String createUser; // Assuming this will store the user who initiated the request
}
