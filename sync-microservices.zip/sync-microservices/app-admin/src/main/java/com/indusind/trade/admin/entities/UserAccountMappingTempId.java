package com.indusind.trade.admin.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserAccountMappingTempId implements Serializable {

    @Column(name = "user_user_id")
    private Long userId;

    @Column(name = "account_mapping_id")
    private String accountId;
}
