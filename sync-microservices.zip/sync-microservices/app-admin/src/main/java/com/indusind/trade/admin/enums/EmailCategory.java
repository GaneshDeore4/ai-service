package com.indusind.trade.admin.enums;

public enum EmailCategory {
    WELCOME,
    PASSWORD_GENERATOR
}
