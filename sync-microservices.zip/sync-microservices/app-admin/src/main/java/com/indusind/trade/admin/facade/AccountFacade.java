package com.indusind.trade.admin.facade;

public interface AccountFacade {
//    List<AccountTemp> saveOrSubmit(List<GTPAccountTnxDto> gtpAccountDtoList, String ops);
//
//    ApplicationResponse getAccountTnx(Long accountId, String tnxId);
//
//    ApplicationResponse getAccount(Long accountId);
}
