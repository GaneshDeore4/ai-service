package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.ActionDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface ActionFacde {
    ApplicationResponse saveAction(ActionDto actionDto);

    ApplicationResponse approve(Long id);

    ApplicationResponse reject(Long id);

    ApplicationResponse getAllActions(Pageable pageable);

    ApplicationResponse getAllTempActions(Pageable pageable);

    ApplicationResponse getActionById(Long actionId);

    ApplicationResponse getTempActionById(Long actionId);

    ApplicationResponse getActionsByProductAndSubProduct(Long productId, Long subProductId);

    ApplicationResponse getActionsByProdOrSubProdId(Long productId, Long subProductId);
}
