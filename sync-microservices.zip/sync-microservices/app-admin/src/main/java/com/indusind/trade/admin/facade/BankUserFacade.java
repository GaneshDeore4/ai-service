package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.BankUserRequestDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface BankUserFacade {

    ApplicationResponse saveBankUserTemp(BankUserRequestDto bankUserRequestDto);
    ApplicationResponse approveBankUser(Long bankUserId);
    ApplicationResponse getBankUserTempById(Long bankUserId);
    ApplicationResponse getBankUserById(Long bankUserId);
    ApplicationResponse getAllTempBankUsers(Pageable pageable);
    ApplicationResponse getAllBankUsers(Pageable pageable);
    ApplicationResponse rejectBankUser(Long bankUserId);

    ApplicationResponse getTempBankUsersByBankId(Long bankId, Pageable pageable);
    ApplicationResponse getBankUsersByBankId(Long bankId, Pageable pageable);

    ApplicationResponse getPulseDetailsByPulseId(Long pulseId);
}
