package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;

public interface MyAccessFacade {
    ApplicationResponse getMyAccess(Long userId);
}
