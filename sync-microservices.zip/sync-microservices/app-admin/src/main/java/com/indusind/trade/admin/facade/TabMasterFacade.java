package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.TabMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Pageable;

public interface TabMasterFacade {

    //ApplicationResponse addTabMaster(TabMasterDto tabMasterDto);

    @Transactional
    ApplicationResponse saveTabTemp(TabMasterDto dto);

    @Transactional
    ApplicationResponse approveTab(Long tabId);

    @Transactional
    ApplicationResponse rejectTab(Long tabId);

    ApplicationResponse getAllTabMaster(Pageable pageable);

    ApplicationResponse getAllTempTabMaster(Pageable pageable);

    ApplicationResponse getTabById(Long roleId);

    ApplicationResponse getTabTempById(Long tabId);

    ApplicationResponse getProdSubProdMappingForTab(Long roleId);

    ApplicationResponse getProdSubProdMappingForTabTemp(Long tabId);

    ApplicationResponse getTabsByProdAndSubProd(Long productId, Long subProductId);
}
