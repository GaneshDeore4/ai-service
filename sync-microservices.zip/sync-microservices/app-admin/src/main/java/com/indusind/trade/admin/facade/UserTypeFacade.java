package com.indusind.trade.admin.facade;

import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import org.springframework.data.domain.Pageable;

public interface UserTypeFacade {

    ApplicationResponse saveUserType(UserTypeDto userTypeDto);

    ApplicationResponse approveUserType(Long userTypeId);

    ApplicationResponse rejectUserType(Long userTypeId);

    ApplicationResponse updateUserType(UserTypeDto userTypeDto);

    ApplicationResponse getAllUserTypes(Pageable pageable);

    ApplicationResponse getAllTempUserType(Pageable pageable);

    ApplicationResponse getUserTypeById(Long userTypeId);

    ApplicationResponse getUserTypeTempById(Long userTypeId);

    ApplicationResponse getUserTypeListByCategory(Long categoryId);

    ApplicationResponse getUserTypePageByCategory(Pageable pageable, Long categoryId);

}
