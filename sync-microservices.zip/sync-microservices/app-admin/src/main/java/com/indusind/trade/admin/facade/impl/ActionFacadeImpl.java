package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.ActionFacde;
import com.indusind.trade.model.dtos.requestdtos.ActionDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.ActionResponseDto;
import com.indusind.trade.model.entities.master.Action;
import com.indusind.trade.model.entities.master.ActionTemp;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.service.ActionService;
import com.indusind.trade.model.service.ActionServiceTemp;
import com.indusind.trade.model.service.ProductMasterService;
import com.indusind.trade.model.service.SubProductMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ActionFacadeImpl implements ActionFacde {

    private final ActionService actionService;

    private final ActionServiceTemp actionServiceTemp;

    private final ProductMasterService productMasterService;

    private final SubProductMasterService subProductMasterService;

    @Override
    @Transactional
    public ApplicationResponse saveAction(ActionDto actionDto) {
//        List<ProductMaster> productList = productMasterService.getProductsByIds(actionDto.getProductId());
//        Action action = ActionDto.convertToEntity(actionDto);
//        action.setProductMaster(productList);
//        Action savedAction = actionService.saveAction(action);

        ActionTemp temp;

        if(actionDto.getIsUpdate()) {
            //update flow
            temp = actionServiceTemp.getActionById(actionDto.getActionId());

        } else {
            temp = new ActionTemp();
            ProductMaster productMaster = productMasterService.getProductById(actionDto.getProductId());

            temp.setProduct(productMaster);

            if(null != actionDto.getSubProductId()) {
                SubProductMaster subProductMaster = subProductMasterService.getSubProductById(actionDto.getSubProductId());
                temp.setSubProduct(subProductMaster);
            }
        }

        temp.setActionCode(actionDto.getActionCode());
        temp.setActionNameLabel(actionDto.getActionNameLabel());
        temp.setStatus(Status.PENDING);

        ActionTemp savedActionTemp = actionServiceTemp.saveActionTemp(temp);


        return new ApplicationResponse("SUCCESS",ActionDto.convertTempToDto(savedActionTemp), "Action saved successfully.");
    }

    @Override
    @Transactional
    public ApplicationResponse approve(Long id) {
        ActionTemp temp = actionServiceTemp.getActionById(id);
        Action master;

        if(actionService.existsById(id)) {
            master = actionService.getActionById(id);
        } else {
            master = new Action();
            master.setActionId(temp.getActionId());
            master.setProduct(temp.getProduct());
            master.setSubProduct(temp.getSubProduct());
            master.setActionCode(temp.getActionCode());
        }

        master.setActionNameLabel(temp.getActionNameLabel());
        temp.setStatus(Status.APPROVED);

        actionService.saveAction(master);
        ActionTemp savedActionTemp = actionServiceTemp.saveActionTemp(temp);

        return new ApplicationResponse("SUCCESS", ActionDto.convertTempToDto(savedActionTemp), "Action approved");
    }

    @Override
    @Transactional
    public ApplicationResponse reject(Long id) {
        ActionTemp temp = actionServiceTemp.getActionById(id);
        Action master;
        if(actionService.existsById(id)) {
            master = actionService.getActionById(id);
            temp.setActionNameLabel(master.getActionNameLabel());
            temp.setStatus(Status.UPDATE_REJECTED);
        } else {
            temp.setStatus(Status.REJECTED);
        }
        ActionTemp savedActionTemp = actionServiceTemp.saveActionTemp(temp);
        return new ApplicationResponse("SUCCESS", ActionDto.convertTempToDto(savedActionTemp), "Action Rejected");
    }

    @Override
    public ApplicationResponse getAllActions(Pageable pageable) {
        if (Objects.nonNull(pageable)) {
            Page<Action> page = actionService.getAllActions(pageable);
            return new ApplicationResponse("SUCCESS", page.map(ActionResponseDto::convertToDto), "Actions fetched successfully.");
        } else {
            List<Action> actionList = actionService.getAllActions();
            List<ActionResponseDto> actionDtos = actionList.stream()
                    .map(ActionResponseDto::convertToDto)
                    .collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", actionDtos, "All Actions fetched successfully.");
        }
    }

    @Override
    public ApplicationResponse getAllTempActions(Pageable pageable) {
        if (Objects.nonNull(pageable)) {
            Page<ActionTemp> page = actionServiceTemp.getAllActions(pageable);
            return new ApplicationResponse("SUCCESS", page.map(ActionResponseDto::convertTempToDto), "Actions fetched successfully.");
        } else {
            List<ActionTemp> actionList = actionServiceTemp.getAllActions();
            List<ActionResponseDto> actionDtos = actionList.stream()
                    .map(ActionResponseDto::convertTempToDto)
                    .collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", actionDtos, "All Actions fetched successfully.");
        }
    }

    @Override
    public ApplicationResponse getActionById(Long actionId) {
        Action action = actionService.getActionById(actionId);
        return new ApplicationResponse("SUCCESS", ActionResponseDto.convertToDto(action), "Action fetched with id");

    }

    @Override
    public ApplicationResponse getTempActionById(Long actionId) {
        ActionTemp actionTemp = actionServiceTemp.getActionById(actionId);
        return new ApplicationResponse("SUCCESS", ActionResponseDto.convertTempToDto(actionTemp), "Action temp fetched");
    }

    @Override
    public ApplicationResponse getActionsByProductAndSubProduct(Long productId, Long subProductId) {
        List<Action> actionList = actionService.getByProductIdSubProductId(productId, subProductId);

        List<ActionResponseDto> responseList = actionList.stream()
                .map(ActionResponseDto :: convertToDto)
                .toList();
        return new ApplicationResponse("SUCCESS", responseList, "List fetched");
    }

    @Override
    public ApplicationResponse getActionsByProdOrSubProdId(Long productId, Long subProductId) {
        List<Action> actionList;

        if(Objects.nonNull(subProductId)){
            actionList = actionService.getByProductIdSubProductId(productId, subProductId);
        }else{
            actionList = actionService.getActionByProdIdAndSubProdNull(productId);
        }

        List<ActionResponseDto> actionResponseDtos = actionList.stream().map(ActionResponseDto :: convertToDto).toList();

        return new ApplicationResponse("SUCCESS", actionResponseDtos, "List fetched");
    }
}
