package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.CategoryMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.CategoryMasterDto;
import com.indusind.trade.model.dtos.requestdtos.ProductMasterDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.service.CategoryMasterService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


@Component
@RequiredArgsConstructor
public class CategoryMasterFacadeImpl implements CategoryMasterFacade {

    private final CategoryMasterService categoryMasterService;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public ApplicationResponse saveCategory(CategoryMasterDto categoryMasterDto) {
        CategoryMaster category = CategoryMasterDto.convertToEntity(categoryMasterDto);
        CategoryMaster savedCategory = categoryMasterService.saveCategory(category);
        return new ApplicationResponse("SUCCESS", savedCategory, "Category saved successfully.");

    }

    @Override
    public ApplicationResponse getAllCategories(Pageable pageable) {
        if (Objects.nonNull(pageable)) {
            Page<CategoryMaster> page = categoryMasterService.getAllCategories(pageable);
            return new ApplicationResponse("SUCCESS", page.map(CategoryMasterDto::convertToDto), "Categories fetched successfully.");
        } else {
            List<CategoryMaster> categoryMaster = categoryMasterService.getAllCategories();

            List<CategoryMasterDto> categoryMasterDtos = categoryMaster.stream()
                    .map(CategoryMasterDto::convertToDto)
                    .collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", categoryMasterDtos, "All Categories fetched successfully.");
        }
    }

    @Override
    public ApplicationResponse getCategoryById(Long categoryId) {
        CategoryMaster categoryMaster = categoryMasterService.getCategoryById(categoryId);
        return new ApplicationResponse("SUCCESS", CategoryMasterDto.convertToDto(categoryMaster), "Category fetched successfully.");
    }


    @Override
    public ApplicationResponse getProductsByCategoryId(Long categoryId) {
        List<ProductMaster> productMasterList = categoryMasterService.getProductsByCategoryId(categoryId);
        List<ProductMasterDto> dtoList = productMasterList.stream()
                .map(ProductMasterDto::convertToDto)
                .collect(Collectors.toList());
        return new ApplicationResponse("SUCCESS", dtoList, "Products for category fetched successfully.");
    }

    @Override
    public ApplicationResponse getUserTypesByCategoryId(Long categoryId) {
        List<UserType> userTypeList = categoryMasterService.getUserTypesByCategoryId(categoryId);
        List<UserTypeDto> dtoList = userTypeList.stream()
                .map(UserTypeDto::convertToDto)
                .collect(Collectors.toList());
        return new ApplicationResponse("SUCCESS", dtoList, "Products for category fetched successfully.");
    }

    @Override
    public ApplicationResponse getAllUserTypesByCategory(String category) {
        List<UserType> userTypeList = categoryMasterService.getUserTypesByCategoryName(category);
        List<UserTypeDto> dtoList = userTypeList.stream()
                .map(UserTypeDto::convertToDto)
                .collect(Collectors.toList());
        return new ApplicationResponse("SUCCESS", dtoList, "User types for category fetched successfully.");
    }

    @Override
    public ApplicationResponse getCategoryByName(String categoryName) {
        CategoryMaster categoryMaster = categoryMasterService.getCategoryByName(categoryName);
        return new ApplicationResponse("SUCCESS", CategoryMasterDto.convertToDto(categoryMaster), "Category fetched successfully.");
    }
}
