package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.model.entities.master.DepartmentTemp;
import com.indusind.trade.admin.facade.DepartmentFacade;
import com.indusind.trade.model.service.DepartmentTempService;
import com.indusind.trade.admin.utility.DepartmentUtil;
import com.indusind.trade.model.dtos.requestdtos.DepartmentRequestDto;
import com.indusind.trade.model.dtos.requestdtos.DepartmentToUserTypeMappingRequestDto;
import com.indusind.trade.model.dtos.requestdtos.DeptIdUserTypeIdDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.DepartmentDto;
import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.Department;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.service.CategoryMasterService;
import com.indusind.trade.model.service.DepartmentService;
import com.indusind.trade.model.service.UserTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
@RequiredArgsConstructor
public class DepartmentFacadeImpl implements DepartmentFacade {

    private final DepartmentService departmentService;
    private final UserTypeService userTypeService;
    private final DepartmentTempService departmentTempService;
    private final CategoryMasterService categoryMasterService;

    @Override
    public ApplicationResponse getAllDepartments() {
        List<Department> depts = departmentService.getAllDepartments();

        List<DepartmentDto> deptDtos = depts.stream()
                .map(d -> {
                    DepartmentDto dto = DepartmentDto.convertToDto(d);
                    List<UserType> userTypes = d.getUserTypes();
                    List<UserTypeDto> userTypeDto = userTypes.stream()
                            .map(UserTypeDto :: convertToDto)
                            .toList();
                    dto.setUserTypes(userTypeDto);
                    return dto;
                })
                .toList();

        return new ApplicationResponse("SUCCESS", deptDtos, "departments fetched successfully");
    }

    @Override
    public ApplicationResponse getDeptByCategoryId(Long deptId) {
        List<Department> deptList = departmentService.getDepartmentByCategory(deptId);

        List<DepartmentDto> dtoList = deptList.stream()
                .map(DepartmentDto::convertToDto)
                .toList();

        return new ApplicationResponse("SUCCESS", dtoList, "departments list fetched successfully");
    }

    @Override
    public ApplicationResponse approveDepartment(Long departmentId) {
        DepartmentTemp departmentTemp = departmentTempService.getDepartmentTempById(departmentId);

        departmentTemp.setStatus(Status.APPROVED);
        departmentTempService.saveDepartmentTemp(departmentTemp);

        Department department;

        if(departmentService.existsById(departmentId)){
            department = departmentService.getDepartmentById(departmentId);
            department = DepartmentTemp.convertToMaster(departmentTemp, department);
        }else{
            department = DepartmentTemp.convertToMaster(departmentTemp, new Department());
        }

        Department savedDept = departmentService.addDepartment(department);

        return new ApplicationResponse("SUCCESS", DepartmentDto.convertToDto(savedDept), "Department approved");
    }

    @Override
    public ApplicationResponse rejectDepartment(Long departmentId) {
        DepartmentTemp departmentTemp = departmentTempService.getDepartmentTempById(departmentId);

        if(departmentService.existsById(departmentId)){
            Department department = departmentService.getDepartmentById(departmentId);
            departmentTemp = DepartmentUtil.convertToTemp(department, departmentTemp);
            departmentTemp.setStatus(Status.UPDATE_REJECTED);
        }else{
            departmentTemp.setStatus(Status.REJECTED);
        }

        departmentTempService.saveDepartmentTemp(departmentTemp);

        return new ApplicationResponse("SUCCESS", departmentId, "Department rejected");
    }

    @Override
    public ApplicationResponse getAllTempDepartments(Pageable pageable) {
        Page<DepartmentTemp> page = departmentTempService.getAllDepartmentTemp(pageable);
        return new ApplicationResponse("SUCCESS", page.map(DepartmentUtil::convertTempToDto), "Dept temp fetched successfully");
    }

    @Override
    public ApplicationResponse getTempDeptById(Long departmentId) {
        DepartmentTemp departmentTemp = departmentTempService.getDepartmentTempById(departmentId);
        DepartmentDto departmentDto = DepartmentUtil.convertTempToDto(departmentTemp);
        return new ApplicationResponse("SUCCESS", departmentTemp, "Dept temp fetched");
    }

    @Override
    public ApplicationResponse getDeptById(Long departmentId) {
        Department department = departmentService.getDepartmentById(departmentId);
        DepartmentDto departmentDto = DepartmentDto.convertToDto(department);
        return new ApplicationResponse("SUCCESS", departmentDto, "Dept fetched");
    }

    @Override
    @Transactional
    public ApplicationResponse mapUserTypesWithDepartment(DepartmentToUserTypeMappingRequestDto request) {

        List<DeptIdUserTypeIdDto> list = request.getMapping();

        List<Department> mappingList = new ArrayList<>();

        for(DeptIdUserTypeIdDto d : list) {
            Department department = departmentService.getDepartmentById(d.getDeptId());

            List<UserType> userTypes = userTypeService.getUserTypeByIdIn(d.getUserTypeIds());

            department.setUserTypes(userTypes);

            mappingList.add(department);
        }

        departmentService.saveAll(mappingList);

        return new ApplicationResponse("SUCCESS", null, "Mapping saved successfully.");
    }

    @Override
    public ApplicationResponse createDepartment(DepartmentRequestDto request) {
        DepartmentTemp departmentTemp;
        if(Objects.nonNull(request.getIsUpdate()) && request.getIsUpdate()){
            departmentTemp = departmentTempService.getDepartmentTempById(request.getId());
        }else{
            departmentTemp = new DepartmentTemp();
        }

        BeanUtils.copyProperties(request, departmentTemp);

        CategoryMaster categoryMaster = categoryMasterService.getCategoryById(request.getCategoryId());
        departmentTemp.setCategory(categoryMaster);

        departmentTemp.setStatus(Status.PENDING);

        DepartmentTemp savedDept = departmentTempService.saveDepartmentTemp(departmentTemp);

        return new ApplicationResponse("SUCCESS", DepartmentUtil.convertTempToDto(savedDept), "Department added successfully");
    }
}
