package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.SmsFacade;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SmsFacadeImpl implements SmsFacade {

    private final WebClient webClient;

    @Value("${app.sms.gupshup.base-url}")
    private String gupshupBaseUrl;

    @Value("${app.sms.gupshup.userid}")
    private String gupshupUserId;

    @Value("${app.sms.gupshup.password}")
    private String gupshupPassword;

    @Value("${app.sms.gupshup.message-template}")
    private String messageTemplate;

    @Override
    public HashMap<String, String> sendSms(long contactNo) {
        Logger logger = LoggerFactory.getLogger(SmsFacadeImpl.class);
        HashMap<String, String> smsResponse = new HashMap<>();

        String otp = generateOtp();
        String message = String.format(messageTemplate, otp);
        String smsUrl = gupshupBaseUrl
                + "?method=SendMessage"
                + "&send_to=" + contactNo
                + "&msg=" + URLEncoder.encode(message, StandardCharsets.UTF_8)
                + "&msg_type=TEXT"
                + "&userid=" + gupshupUserId
                + "&auth_scheme=plain"
                + "&password=" + gupshupPassword
                + "&v=1.1&format=text";

        try{
            String res = webClient.get()
                    .uri(smsUrl)
                    .retrieve()
                    .onStatus(
                            status -> !status.is2xxSuccessful(), //replace responseCode check
                            clientResponse -> {
                                logger.info("request failed");
                                return Mono.error(new RuntimeException("Request failed"));
                            }
                    )
                    .bodyToMono(String.class) //replace BufferedReader
                    .block(); // keeps  existing sync behavior

            smsResponse.put("status", res.split("\\|")[0].trim());
            smsResponse.put("phone", res.split("\\|")[1].trim());
            smsResponse.put("msgId", res.split("\\|")[2].trim());
            smsResponse.put("otp", otp);
            logger.info("sendSMSReq: Response- " + res);
        } catch (Exception e) {
            logger.info("Exception occurred: {}", e.getMessage());
            // your existing fallback
            smsResponse.put("status", "success");
            smsResponse.put("phone", String.valueOf(contactNo));
            smsResponse.put("msgId", UUID.randomUUID().toString());
            smsResponse.put("otp", otp);
        }
        logger.info("smsResponse: " + smsResponse);
        logger.info("sendSMSReq: end");
        return smsResponse;
    }
    public static String generateOtp(){
        SecureRandom random = new SecureRandom();
        int otp = random.nextInt(90000)+10000;
        return String.valueOf(otp);
    }
}



