package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.model.entities.master.SubProductMasterTemp;
import com.indusind.trade.admin.facade.SubProductMasterFacade;
import com.indusind.trade.model.service.*;
import com.indusind.trade.admin.utility.SubProductMasterUtils;
import com.indusind.trade.model.dtos.requestdtos.SubProductMasterDto;
import com.indusind.trade.model.dtos.requestdtos.TabMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.entities.master.TabMaster;
import com.indusind.trade.model.enums.Status;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class SubProductMasterFacadeImpl implements SubProductMasterFacade {

    private final SubProductMasterService subProductMasterService;

    private final ProductMasterService productMasterService;

    private final ProductMasterTempService productMasterTempService;

    private final SubProductMasterTempService subProductMasterTempService;

    private final TabMasterService tabMasterService;

//    @Override
//    @Transactional(rollbackOn = Exception.class)
//    public ApplicationResponse saveSubProduct(SubProductMasterDto subProductMasterDto) {
//        ProductMaster pm = productMasterService.getProductById(subProductMasterDto.getProductId());
//        Long currSeq = subProductMasterService.findMaxSequenceIdByProductId(subProductMasterDto.getProductId());
//        long nextSeq = currSeq+1;
//        SubProductMaster subProductMaster = SubProductMasterDto.convertToEntity(subProductMasterDto);
//        subProductMaster.setSequenceId(nextSeq);
//        subProductMaster.setProductMaster(pm);
//        SubProductMaster savedSubProduct = subProductMasterService.saveSubProduct(subProductMaster);
//        return new ApplicationResponse("SUCCESS", SubProductMasterDto.convertToDto(savedSubProduct), "Sub Product saved.");
//    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public ApplicationResponse saveSubProduct(SubProductMasterDto subProductMasterDto) {
        if(subProductMasterDto.getIsUpdate()) {
            //update flow
            SubProductMasterTemp subProductMasterTemp = subProductMasterTempService.getSubProductMasterTempById(subProductMasterDto.getSubProductId());

            subProductMasterTemp.setSubProductLabel(subProductMasterDto.getSubProductLabel());
            subProductMasterTemp.setSubProductName(subProductMasterDto.getSubProductName());
            subProductMasterTemp.setStatus(Status.PENDING);

            SubProductMasterTemp savedSubProductMaster = subProductMasterTempService.saveSubProductTemp(subProductMasterTemp);

            return new ApplicationResponse("SUCCESS", SubProductMasterUtils.convertTempToDto(savedSubProductMaster), "Sub product changes saved.");

        } else {
            //new insert flow
//            ProductMasterTemp productMasterTemp = productMasterTempService.getProductMasterTempById(subProductMasterDto.getProductId());
            ProductMaster productMaster = productMasterService.getProductById(subProductMasterDto.getProductId());
            Long currSeq = subProductMasterTempService.findMaxSequenceIdByProductId(subProductMasterDto.getProductId());
            Long nextSeq = currSeq+1;

            SubProductMasterTemp subProductMaster = SubProductMasterTemp.builder()
                    .subProductLabel(subProductMasterDto.getSubProductLabel())
                    .subProductName(subProductMasterDto.getSubProductName())
                    .productMaster(productMaster)
                    .status(Status.PENDING)
                    .sequenceId(nextSeq)
                    .build();

            SubProductMasterTemp savedSubProductMaster = subProductMasterTempService.saveSubProductTemp(subProductMaster);

            return new ApplicationResponse("SUCCESS", SubProductMasterUtils.convertTempToDto(savedSubProductMaster), "Sub product changes saved.");

        }
    }

    @Override
    public ApplicationResponse approve(Long id) {


        SubProductMasterTemp temp =
                subProductMasterTempService.getSubProductMasterTempById(id);

        ProductMaster productMaster =
                productMasterService.getProductById(
                        temp.getProductMaster().getProductId()
                );

        SubProductMaster master;

        // If already exists in MASTER → update
        if (subProductMasterService.existsById(id)) {
            master = subProductMasterService.getSubProductById(id);
        } else {
            master = new SubProductMaster();
            master.setSubProductId(temp.getSubProductId());
        }

        master.setSubProductName(temp.getSubProductName());
        master.setSequenceId(temp.getSequenceId());
        master.setProductMaster(productMaster);
        master.setSubProductLabel(temp.getSubProductLabel());

        subProductMasterService.saveSubProduct(master);

        // Update TEMP status
        temp.setStatus(Status.APPROVED);
        subProductMasterTempService.saveSubProductTemp(temp);

        return new ApplicationResponse(
                "SUCCESS",
                SubProductMasterUtils.convertTempToDto(temp),
                "Sub Product approved successfully"
        );
    }

    @Override
    public ApplicationResponse reject(Long id) {
        SubProductMasterTemp temp =
                subProductMasterTempService.getSubProductMasterTempById(id);

        // If temp exists → update
        if (subProductMasterService.existsById(id)) {
            SubProductMaster subProductMaster =  subProductMasterService.getSubProductById(id);
            temp.setSubProductLabel(subProductMaster.getSubProductLabel());
            temp.setStatus(Status.UPDATE_REJECTED);
        } else {
            temp.setStatus(Status.REJECTED);
        }

        subProductMasterTempService.saveSubProductTemp(temp);

        return new ApplicationResponse(
                "SUCCESS",
                SubProductMasterUtils.convertTempToDto(temp),
                "Sub Product rejected successfully"
        );
    }

    @Override
    public ApplicationResponse getAllSubProducts(Pageable pageable) {
//        Pageable sortedPageable = pageable;
//        if(pageable.getSort().isUnsorted()){
//            sortedPageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(),
//                    Sort.by(Sort.Order.desc("createdAt")));
//        }
        if (Objects.nonNull(pageable)) {
            Page<SubProductMaster> page = subProductMasterService.getAllSubProducts(pageable);
            return new ApplicationResponse("SUCCESS", page.map(SubProductMasterDto::convertToDto), "Sub Products fetched");
        } else {
            List<SubProductMaster> subProductMasters = subProductMasterService.getAllSubProducts();
            List<SubProductMasterDto> subProductMasterDtolist = subProductMasters.stream().map(SubProductMasterDto::convertToDto).collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", subProductMasterDtolist, "All Sub Products fetched");

        }
    }

    @Override
    public ApplicationResponse getSubProductById(Long subProductId) {
        SubProductMaster subProductMaster = subProductMasterService.getSubProductById(subProductId);
        return new ApplicationResponse("SUCCESS", SubProductMasterDto.convertToDto(subProductMaster), "Sub Product Fetched with id");
    }

    @Override
    public ApplicationResponse getAllSubProductsTemp(Pageable pageable) {
        if (Objects.nonNull(pageable)) {
            Page<SubProductMasterTemp> page = subProductMasterTempService.getAllSubProducts(pageable);
            return new ApplicationResponse("SUCCESS", page.map(SubProductMasterUtils::convertTempToDto), "Sub Products fetched");
        } else {
            List<SubProductMasterTemp> subProductMasters = subProductMasterTempService.getAllSubProducts();
            List<SubProductMasterDto> subProductMasterDtolist = subProductMasters.stream().map(SubProductMasterUtils::convertTempToDto).collect(Collectors.toList());
            return new ApplicationResponse("SUCCESS", subProductMasterDtolist, "All Sub Products fetched");

        }
    }

    @Override
    public ApplicationResponse getSubProductTempById(Long subProductId) {
        SubProductMasterTemp subProductMasterTemp = subProductMasterTempService.getSubProductMasterTempById(subProductId);
        return new ApplicationResponse("SUCCESS", SubProductMasterUtils.convertTempToDto(subProductMasterTemp), "Sub product fetched");
    }

    @Override
    public ApplicationResponse getTabsBySubProduct(Long subProductId, Long productId) {
        List<TabMaster> tabMasterList;
        if(Objects.nonNull(subProductId)){
            tabMasterList = tabMasterService.findByProdAndSubProd(productId,subProductId);
        }else{
            tabMasterList = tabMasterService.getTabsByProdId(productId);
        }

        List<TabMasterDto> tabsDto = tabMasterList.stream().map(TabMasterDto::convertToDto).toList();

        return new ApplicationResponse("SUCCESS", tabsDto, "Sub Product Fetched with id");
    }
}
