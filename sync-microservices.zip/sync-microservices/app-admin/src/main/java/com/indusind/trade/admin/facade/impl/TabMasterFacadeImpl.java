package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.facade.TabMasterFacade;
import com.indusind.trade.model.dtos.requestdtos.TabMasterDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.master.*;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.service.ProductMasterService;
import com.indusind.trade.model.service.SubProductMasterService;
import com.indusind.trade.model.service.TabMasterService;
import com.indusind.trade.model.service.TabMasterTempService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class TabMasterFacadeImpl implements TabMasterFacade {

    private final TabMasterService tabMasterService;
    private final TabMasterTempService tabMasterTempService;
    private final ProductMasterService productMasterService;
    private final SubProductMasterService subProductMasterService;

//    @Override
//    @Transactional(rollbackOn = Exception.class)
//    public ApplicationResponse addTabMaster(TabMasterDto tabMasterDto) {
//        try {
//            TabMaster tabMaster = TabMasterDto.convertToEntity(tabMasterDto);
//            List<ProductMaster> productMasterList = productMasterService.getProductsByIds(tabMasterDto.getProductIds());
//
//            if (CollectionUtils.isNotEmpty(tabMasterDto.getSubProductIds())) {
//                List<SubProductMaster> subProductList = subProductMasterService.getSubProductMasterList(tabMasterDto.getSubProductIds());
//                tabMaster.setSubProducts(subProductList);
//            }
//
//            tabMaster.setProducts(productMasterList);
//
//            TabMaster savedTabMaster = tabMasterService.addTabMaster(tabMaster);
//            return new ApplicationResponse("SUCCESS", TabMasterDto.convertToDto(savedTabMaster), "Tab Master saved");
//        } catch (Exception e) {
//            throw new GTPAppException("Exception occurred while saving tab master", e);
//        }
//    }

    @Override
    @Transactional
    public ApplicationResponse saveTabTemp(TabMasterDto dto) {
        TabMasterTemp temp;
        if (Boolean.TRUE.equals(dto.getIsUpdate())) {
            temp = tabMasterTempService.getTabById(dto.getTabId());
        } else {
            temp = new TabMasterTemp();
            temp.setTabName(dto.getTabName());
            ProductMaster product = productMasterService.getProductById(dto.getProductId());
            temp.setProduct(product);
            if (Objects.nonNull(dto.getSubProductId())) {
                SubProductMaster subProduct = subProductMasterService.getSubProductById(dto.getSubProductId());
                temp.setSubProduct(subProduct);
            }
        }
        temp.setTabLabel(dto.getTabLabel());
        temp.setStatus(Status.PENDING);
        tabMasterTempService.saveTabMasterTemp(temp);
        return new ApplicationResponse("SUCCESS", temp.getTabId(), "Tab saved for approval");
    }

    @Override
    @Transactional
    public ApplicationResponse approveTab(Long tabId) {
        TabMasterTemp temp = tabMasterTempService.getTabById(tabId);
        TabMaster master;
        if (tabMasterService.existById(tabId)) {
            master = tabMasterService.getTabById(tabId);
        } else {
            master = new TabMaster();
            master.setTabId(temp.getTabId());
            master.setProduct(temp.getProduct());
            master.setSubProduct(temp.getSubProduct());
            master.setTabName(temp.getTabName());
        }
        master.setTabLabel(temp.getTabLabel());
        tabMasterService.addTabMaster(master);
        temp.setStatus(Status.APPROVED);
        tabMasterTempService.saveTabMasterTemp(temp);
        return new ApplicationResponse("SUCCESS", tabId, "Tab approved");
    }

    @Override
    @Transactional
    public ApplicationResponse rejectTab(Long tabId) {
        TabMasterTemp temp = tabMasterTempService.getTabById(tabId);
        if (tabMasterService.existById(tabId)) {
            TabMaster master = tabMasterService.getTabById(tabId);
            temp.setStatus(Status.UPDATE_REJECTED);
            temp.setTabLabel(master.getTabLabel());

        } else {
            temp.setStatus(Status.REJECTED);
        }
        tabMasterTempService.saveTabMasterTemp(temp);
        return new ApplicationResponse("SUCCESS", tabId, "Tab rejected");
    }

    @Override
    public ApplicationResponse getAllTabMaster(Pageable pageable) {
        try {
            if (Objects.isNull(pageable)) {
                List<TabMaster> tabMaster = tabMasterService.getAllTabMaster();
                List<TabMasterDto> tabDtoList = tabMaster.stream().map(tab -> {
                    TabMasterDto tabDto = TabMasterDto.convertToDto(tab);
                    this.getProductSubProductMap(tabDto, tab.getProduct(), tab.getSubProduct());
                    return tabDto;
                }).toList();
                return new ApplicationResponse("SUCCESS", tabDtoList, "Tab master fetched");
            } else {
                Page<TabMaster> tabMasterPage = tabMasterService.getAllTabMaster(pageable);
                Page<TabMasterDto> tabMasterDtos = tabMasterPage.map(tab -> {
                    TabMasterDto tabDto = TabMasterDto.convertToDto(tab);
                    this.getProductSubProductMap(tabDto, tab.getProduct(), tab.getSubProduct());
                    return tabDto;
                });

                return new ApplicationResponse("SUCCESS", tabMasterDtos, "Tab master fetched");
            }
        } catch (Exception e) {
            throw new GTPAppException("Exception occurred while fetching tab master", e);
        }
    }

    @Override
    public ApplicationResponse getAllTempTabMaster(Pageable pageable) {
        try {
            if (Objects.isNull(pageable)) {
                List<TabMasterTemp> tabMasterTemps = tabMasterTempService.getAllTabMasterTemp();
                List<TabMasterDto> tabDtoList = tabMasterTemps.stream().map(tab -> {
                    TabMasterDto tabDto = TabMasterDto.convertToDtoFromTemp(tab);
                    this.getProductSubProductMap(tabDto, tab.getProduct(), tab.getSubProduct());
                    return tabDto;
                }).toList();
                return new ApplicationResponse("SUCCESS", tabDtoList, "Tab master fetched");
            } else {
                Page<TabMasterTemp> tabMasterPage = tabMasterTempService.getAllTabMasterTemp(pageable);
                Page<TabMasterDto> tabMasterDtos = tabMasterPage.map(tab -> {
                    TabMasterDto tabDto = TabMasterDto.convertToDtoFromTemp(tab);
                    this.getProductSubProductMap(tabDto, tab.getProduct(), tab.getSubProduct());
                    return tabDto;
                });
                return new ApplicationResponse("SUCCESS", tabMasterDtos, "Tab master fetched");
            }
        } catch (Exception e) {
            throw new GTPAppException("Exception occurred while fetching tab master", e);
        }
    }

    private void getProductSubProductMap(TabMasterDto tabMasterDto, ProductMaster prod, SubProductMaster subProd) {
        CategoryMaster category = prod.getCategory();
        if (Objects.nonNull(subProd)) {
            tabMasterDto.setSubProductId(subProd.getSubProductId());
            tabMasterDto.setSubProductLabel(subProd.getSubProductLabel());
        }
        tabMasterDto.setCategoryMap(Map.of(category.getCategoryId(), category.getCategoryName()));
        tabMasterDto.setProductId(prod.getProductId());
        tabMasterDto.setProductLabel(prod.getProductNameLabel());
    }

    @Override
    public ApplicationResponse getTabById(Long tabId) {
        TabMaster tabMaster = tabMasterService.getTabById(tabId);
        TabMasterDto tabDto = TabMasterDto.convertToDto(tabMaster);
        this.getProductSubProductMap(tabDto, tabMaster.getProduct(), tabMaster.getSubProduct());
        return new ApplicationResponse("SUCCESS", tabDto, "Tab Master fetched");
    }

    @Override
    public ApplicationResponse getTabTempById(Long tabId) {
        TabMasterTemp tabMasterTemp = tabMasterTempService.getTabById(tabId);
        TabMasterDto tabDto = TabMasterDto.convertToDtoFromTemp(tabMasterTemp);
        this.getProductSubProductMap(tabDto, tabMasterTemp.getProduct(), tabMasterTemp.getSubProduct());
        return new ApplicationResponse("SUCCESS", tabDto, "Tab Master fetched");
    }


    @Override
    public ApplicationResponse getProdSubProdMappingForTab(Long tabId) {
        TabMaster tabMaster = tabMasterService.getTabById(tabId);
        TabMasterDto dto = TabMasterDto.convertToDto(tabMaster);
        this.getProductSubProductMap(dto, tabMaster.getProduct(), tabMaster.getSubProduct());
        return new ApplicationResponse("SUCCESS", dto, "Prod SubProduct Mapping fetched");
    }

    @Override
    public ApplicationResponse getProdSubProdMappingForTabTemp(Long tabId) {
        TabMasterTemp tabTemp = tabMasterTempService.getTabById(tabId);
        TabMasterDto dto = TabMasterDto.convertToDtoFromTemp(tabTemp);
        this.getProductSubProductMap(dto, tabTemp.getProduct(), tabTemp.getSubProduct());
        return new ApplicationResponse("SUCCESS", dto, "Prod SubProduct Temp Mapping fetched");
    }

    @Override
    public ApplicationResponse getTabsByProdAndSubProd(Long productId, Long subProductId) {
        List<TabMaster> tabMasterList = tabMasterService.findByProdAndSubProd(productId, subProductId);
        List<TabMasterDto> tabsDtos = tabMasterList.stream().map(TabMasterDto::convertToDto).toList();
        return new ApplicationResponse("SUCCESS", tabsDtos, "Tabs for product fetched successfully.");
    }
}
