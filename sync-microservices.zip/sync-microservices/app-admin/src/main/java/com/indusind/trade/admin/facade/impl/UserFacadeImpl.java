package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.admin.client.PulseFeignClient;
import com.indusind.trade.admin.enums.EmailCategory;
import com.indusind.trade.admin.facade.EmailFacade;
import com.indusind.trade.admin.facade.SmsFacade;
import com.indusind.trade.admin.facade.UserFacade;
import com.indusind.trade.model.dtos.requestdtos.LegalIdDetailsDto;
import com.indusind.trade.model.dtos.requestdtos.UserDTO;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.PulseDetailsResponseDto;
import com.indusind.trade.model.entities.company.*;
import com.indusind.trade.model.entities.master.ProductMaster;
import com.indusind.trade.model.entities.master.SubProductMaster;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.model.service.*;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@RequiredArgsConstructor
public class UserFacadeImpl implements UserFacade {

    private final UserService userService;
    private final UserTypeService userTypeService;
    private final ProductMasterService productMasterService;
    private final SubProductMasterService subProductMasterService;
    private final AuthGroupService authGroupService;
    private final CompanyService companyService;
    private final PasswordEncoder passwordEncoder;
    private final EmailFacade emailFacade;
    private final SmsFacade smsFacade;
    private final PulseFeignClient pulseFeignClient;

    @Value("${user.default.password}")
    private String defaultUserPassword;

    @Value(("${email.content}"))
    private String emailContentTemplate;

    @Value(("${email.welcome.subject}"))
    private String welcomeEmailSubject;

    @Value(("${email.welcome.content}"))
    private String welcomeEmailContent;

    @Value(("${email.password.subject}"))
    private String passwordEmailSubject;

    @Value(("${email.password.content}"))
    private String passwordEmailContent;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse saveUserTemp(UserDTO userDTO) {
        //userDTO.setCreatedAt(LocalDateTime.now());
        UserTemp userTemp = null;
        if (Objects.nonNull(userDTO.getIsUpdate()) && userDTO.getIsUpdate()) {
            userTemp = userService.getTempUserById(userDTO.getUserId());
            userTemp = userDTO.convertToTempEntity(userDTO, userTemp);
            clearUserCompanyAndLegalIdMappingTemp(userTemp);
        } else {
            userTemp = userDTO.convertToTempEntity(userDTO, new UserTemp());
            userTemp.setUserPassword(passwordEncoder.encode(defaultUserPassword)); //need to set later while approving
        }

        Company company = companyService.getCompanyById(userDTO.getCompanyId());
        userTemp.setCompany(company);

        if (Objects.nonNull(userDTO.getAuthLevel())) {
            AuthGroup authGroup = authGroupService.getAuthGroup(userDTO.getAuthLevel());
            userTemp.setAuthGroup(authGroup);
        }

        //getUserTypeById
        UserType userType = userTypeService.getUserTypeById(userDTO.getUserTypeId());
        userTemp.setUserType(userType);
        userTemp.setBaseCurr(company.getBaseCurrency());
        //set status
        userTemp.setStatus(Status.PENDING.toString());
        userService.flushUserTemp();

//        if (Objects.nonNull(userDTO.getLegalIdDetailsDtoList()) && CollectionUtils.isNotEmpty(userDTO.getLegalIdDetailsDtoList())) {
//            List<LegalIdDetailsTemp> legalIdDetailsList = userDTO.getLegalIdDetailsDtoList().stream().map(LegalIdDetailsDto::convertToTempEntity).collect(Collectors.toList());
//            userTemp.setLegalIdDetailsTempList(legalIdDetailsList);
//        }
        if (Objects.nonNull(userDTO.getLegalIdDetailsDtoList()) && CollectionUtils.isNotEmpty(userDTO.getLegalIdDetailsDtoList())) {
            for (LegalIdDetailsDto legalIdDetailsDto : userDTO.getLegalIdDetailsDtoList()) {
                //legalIdDetailsDto.setId(null);
                LegalIdDetailsTemp legalIdDetailsTemp = LegalIdDetailsDto.convertToTempEntity(legalIdDetailsDto);
                legalIdDetailsTemp.setStatus(Status.PENDING.toString());
                userTemp.addLegalIdTemp(legalIdDetailsTemp);
            }
        }
        if (Objects.nonNull(userDTO.getProductSubProdRespMap()) && !userDTO.getProductSubProdRespMap().isEmpty()) {
            Map<Long, List<Long>> prodSubProdMap = userDTO.getProductSubProdRespMap();
            for (Map.Entry<Long, List<Long>> entry : prodSubProdMap.entrySet()) {
                //entry-fetch product by productId first, then subprod for every subprod id
                Long productId = entry.getKey();
                List<Long> subProductsIdList = entry.getValue();
//                UserCompanyProductSubProdMappingTemp tempMapping = new UserCompanyProductSubProdMappingTemp();
                ProductMaster productMaster = productMasterService.getProductById(productId);

                if (subProductsIdList == null || subProductsIdList.isEmpty()) {
//                tempMapping.setCompany(company);
                    UserCompanyProductSubProdMappingTemp tempMapping = new UserCompanyProductSubProdMappingTemp();
                    tempMapping.setUserTemp(userTemp);
                    tempMapping.setProductMaster(productMaster);
                    tempMapping.setSubProductMaster(null);
                    userTemp.getUserMappingTemp().add(tempMapping);
                } else {
                    for (Long subProdId : subProductsIdList) {
                        UserCompanyProductSubProdMappingTemp tempMapping = new UserCompanyProductSubProdMappingTemp();
                        SubProductMaster subProductMaster = subProductMasterService.getSubProductById(subProdId);
                        tempMapping.setUserTemp(userTemp);
                        tempMapping.setProductMaster(productMaster);
                        tempMapping.setSubProductMaster(subProductMaster);
                        userTemp.getUserMappingTemp().add(tempMapping);
                    }
                }

            }
        }
        UserTemp savedUserTemp = userService.saveUserTemp(userTemp);



        //userMappingService.addMappingTemp(savedUserTemp.getUserId(), userDTO.getProductSubProdMap());

//        UserDTO savedUserDto = UserDTO.convertToTempDto(userService.saveUserTemp(userTemp));

        emailFacade.sendEmail(savedUserTemp.getEmail(), welcomeEmailSubject, welcomeEmailContent, EmailCategory.WELCOME);
        return new ApplicationResponse("SUCCESS", Map.of(savedUserTemp.getUserId(), userTemp.getUserType().getUserTypeName()), "Company User Saved Successfully");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse approveUser(Long userId) {
        User user = null;
        UserTemp userTemp = userService.getTempUserById(userId);
        userTemp.setStatus(Status.APPROVED.toString());

        userTemp = userService.saveUserTemp(userTemp);

        Boolean existsFlag = userService.existsUser(userId);

        if (existsFlag) {
            user = userService.getUserById(userId);
            clearUserCompanyAndLegalIdMapping(user);
            userService.flushUser();
            user = UserTemp.convertToMaster(userTemp, user);

        } else {
            user = UserTemp.convertToMaster(userTemp, new User()); //user based from userTemp
//          ----------------SEND EMAIL--------------------
//
//            String emailContent = emailContentTemplate.replace("$UserName", user.getFirstName())
//                    .replace("$role", user.getUserType().getUserTypeName())
//                    .replace("$Email", user.getEmail())
//                    .replace("$Defaultpassword", defaultUserPassword); //sending mail with plain text password
//
//            System.out.println("emailContent "+emailContent);
//
//
////              send email
//                Map<String, Object> emailRes = emailService.sendEmail(user.getEmail(), "User Approved for Trade", emailContent);
//                System.out.println("emailRes "+emailRes);
//                System.out.println("SUCCESS: Email sent to user " + user.getLoginId() + " at " + user.getEmail());
//                HashMap<String, String> smsResponse;
//                smsResponse = smsService.sendSms(Long.parseLong(user.getContactNo()));
//                System.out.println("smsRes: "+ smsResponse);
//
//          ----------------SEND EMAIL--------------------
            //user.setUserPassword(passwordEncoder.encode(defaultUserPassword));
        }

//        userTemp = userService.saveUserTemp(userTemp);
        addUserMapLegalIdMappingFromTemp(user, userTemp);
        user = userService.saveUser(user);

        emailFacade.sendEmail(user.getEmail(), passwordEmailSubject, passwordEmailContent, EmailCategory.PASSWORD_GENERATOR);

        return new ApplicationResponse("SUCCESS", Map.of(user.getUserId(), user.getUserType().getUserTypeName()), "User approved successfully");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse rejectUserTemp(Long userId) {
        UserTemp userTempSaved = null;
        UserTemp userTemp = userService.getTempUserById(userId);

        if (userService.existsUser(userId)) {
            clearUserCompanyAndLegalIdMappingTemp(userTemp);
            userService.flushUserTemp();
            User user = userService.getUserById(userId);
            userTemp = User.convertToTempEntity(user, userTemp);
            addUserMapLegalIdMapping(userTemp, user);
            userTemp.setStatus(Status.UPDATE_REJECTED.toString());
            userTempSaved = userService.saveUserTemp(userTemp);

            //to make id of both temp and master consistent
            clearUserCompanyAndLegalIdMapping(user);
            userService.flushUser();
            addUserMapLegalIdMappingFromTemp(user, userTempSaved);
            userService.saveUser(user);

        } else {
            userTemp.setStatus(Status.REJECTED.toString());
            userTempSaved = userService.saveUserTemp(userTemp);

        }

        return new ApplicationResponse("SUCCESS", Map.of(userTempSaved.getUserId(), userTempSaved.getUserType().getUserTypeName()), "User updates rejected successfully.");
    }

    private void addUserMapLegalIdMapping(UserTemp userTemp, User user) {
        if (Objects.nonNull(user.getLegalIdDetailsList()) && CollectionUtils.isNotEmpty(user.getLegalIdDetailsList())) {
            for (LegalIdDetails legalIdDetails : user.getLegalIdDetailsList()) {
                LegalIdDetailsTemp legalIdDetailsTemp = LegalIdDetails.convertToTempEntity(legalIdDetails);
                userTemp.addLegalIdTemp(legalIdDetailsTemp);
            }
        }

        if (Objects.nonNull(user.getMappingUser()) && !user.getMappingUser().isEmpty()) {
            for (UserCompanyProductSubProdMapping userMap : user.getMappingUser()) {
                UserCompanyProductSubProdMappingTemp userCompanyProductSubProdMappingTemp = UserCompanyProductSubProdMapping.convertToTempEntity(userMap);
                userTemp.addUserCompanyProdSubProd(userCompanyProductSubProdMappingTemp);
            }
        }
    }

    private void addUserMapLegalIdMappingFromTemp(User user, UserTemp userTemp) {
        if (Objects.nonNull(userTemp.getLegalIdDetailsTempList()) && CollectionUtils.isNotEmpty(userTemp.getLegalIdDetailsTempList())) {
            for (LegalIdDetailsTemp legalIdDetailsTemp : userTemp.getLegalIdDetailsTempList()) {
                LegalIdDetails legalIdDetails = LegalIdDetailsTemp.convertToMasterEntity(legalIdDetailsTemp);
                user.addLegalId(legalIdDetails);
            }
        }
        if (Objects.nonNull(userTemp.getUserMappingTemp()) && CollectionUtils.isNotEmpty(userTemp.getUserMappingTemp())) {
            for (UserCompanyProductSubProdMappingTemp userMap : userTemp.getUserMappingTemp()) {
                UserCompanyProductSubProdMapping userCompanyProductSubProdMapping = UserCompanyProductSubProdMappingTemp.convertToMasterEntity(userMap);
                user.addUserCompanyProdSubProd(userCompanyProductSubProdMapping);
            }
        }
    }

    @Override
    public ApplicationResponse getUserTempById(Long userId) {
        UserTemp userTemp = userService.getTempUserById(userId);
        UserDTO userDTO = UserDTO.convertTempToDto(userTemp);
        return new ApplicationResponse("SUCCESS", userDTO, "UserTemp fetched");
    }

    @Override
    public ApplicationResponse getUserById(Long userId) {
        User user = userService.getUserById(userId);
        UserDTO userDTO = UserDTO.convertToDto(user);
        return new ApplicationResponse("SUCCESS", userDTO, "User fetchde");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getTempUsersByCompanyId(Long companyId, Pageable pageable) {
        Page<UserTemp> page = userService.getTempUsersByCompanyId(companyId, pageable);
        Page<UserDTO> responsePage = page.map(UserDTO::convertTempToDto);
        return new ApplicationResponse("SUCCESS", responsePage, "Temp users fetched");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse getUsersByCompanyId(Long companyId, Pageable pageable) {
        Page<User> page = userService.getUsersByCompanyId(companyId, pageable);
        Page<UserDTO> responsePage = page.map(UserDTO::convertToDto);
        return new ApplicationResponse("SUCCESS", responsePage, "Users fetched");
    }

    @Override
    public ApplicationResponse getAllUsers(Pageable pageable) {
        Page<User> page = userService.getAllUsers(pageable);
        Page<UserDTO> responsePage = page.map(UserDTO::convertToDto);
        return new ApplicationResponse("SUCCESS", responsePage, "All Users fetched");
    }

    @Override
    public ApplicationResponse getAllTempUsers(Pageable pageable) {
        Page<UserTemp> page = userService.getAllTempUsers(pageable);
        Page<UserDTO> responsePage = page.map(UserDTO::convertTempToDto);
        return new ApplicationResponse("SUCCESS", responsePage, "All Temp Users fetched");
    }

//    @Override
//    public ApplicationResponse getPulseDetailsByPulseId(String pulseId) {
//        PulseDetailsResponseDto response = null;
//        try{
//            //need to update client id and secret
//            //response = pulseFeignClient.getPulseDeatilsByPulseId("IBL_CLIENT_ID", "IBL_CLIENT_SECRET",pulseId);
//            response = getDummyPulseDetailsResponse(pulseId);
//        } catch (Exception e){
//           throw  new GTPAppException("Error while calling pulse api", e);
//        }
//        UserDTO userDto = mapPulseDetailsToUserDto(response);
//        return new ApplicationResponse("SUCCESS", userDto, "All Temp Users fetched");
//    }
//
//    private UserDTO mapPulseDetailsToUserDto(PulseDetailsResponseDto resp) {
//        if (Objects.isNull(resp)){
//            throw new GTPAppException("User not found with given ECN", null);
//        }
//        return  UserDTO.builder().loginId("IBL"+ resp.getEmployeeNumber())
//                .firstName(resp.getName().split("--")[0])
//                .lastName(resp.getName().split("--")[1])
//                .employeeDepartment(resp.getDepartment())
//                .contactNo(resp.getMobileNumber())
//                .status(resp.getStatus())
//                .email(resp.getMailId())
//                .build();
//    }


    public static PulseDetailsResponseDto getDummyPulseDetailsResponse(String pulseId) {

        PulseDetailsResponseDto employee = new PulseDetailsResponseDto();
        employee.setEmployeeNumber(pulseId);
        employee.setDoj(LocalDateTime.of(2015, 2, 23, 0, 0));
        employee.setName("John--Doe");
        employee.setGender("Male");
        employee.setDepartment("IT");
        employee.setCurrentDesignation("Project Manager");
        employee.setBusinessUnit("TECH - Core Banking");
        employee.setOuName("TECH - Core Banking");
        employee.setMailId("john.doe@indusind.com");
        employee.setMobileNumber("7738050714");

        employee.setReportingManager("5181");
        employee.setReportingManagerName("Robert Peter");
        employee.setReportingManagerDesignation("Head - IT Support Core Banking");
        employee.setReportingManagerMailId("robert.peter@indusind.com");

        employee.setWeeklyOff("");
        employee.setFunctionalReportingManager("Robert Peter");
        employee.setCountry("India");
        employee.setEmployeeStatus("Confirmed");
        employee.setStatus("Active");

        employee.setBranchCode("9907");
        employee.setBranchAddress(
                "CTS No 179 G, MIDC, Cross Road-B, Extn of Andheri Kurla Road, Andheri East"
        );
        employee.setCurrentLocation("IBL House Office");
        employee.setCityName("Mumbai");

        return employee;
    }


//    @Override
//    public ApplicationResponse rejectTempUser(Long userId) {
//        User user;
//        try{
//            user = userService.getUserById(userId);
//        }catch (GTPAppException e){
//            user = null;
//        }
//        UserTemp userTemp;
//        if(Objects.nonNull(user)){
//            //user exists in main table, take the main user from main table and save to temp table
//            //delete the temp mappings, copy main table mappings and save to temp table
//            userTemp = User.convertToMaster(user);
//            userTemp.setStatus(Status.UPDATE_REJECTED.toString());
//
//            userMappingService.deleteByUserTempUserId(userId);
//            userMappingService.flush();
//
//            List<UserCompanyProductSubProdMapping> userMapping = userMappingService.getMappingById(userId);
//
//
//
//
//        }else{
//            userTemp = userService.getTempUserById(userId);
//            userTemp.setStatus(Status.REJECTED.toString());
//
////            userMappingService.deleteByUserTempUserId(userId);
////            userMappingService.flush();
//
//
//
//        }
//    }

    private void clearUserCompanyAndLegalIdMappingTemp(UserTemp userTemp) {
        userTemp.getLegalIdDetailsTempList().clear();
        userTemp.getUserMappingTemp().clear();
    }

    private void clearUserCompanyAndLegalIdMapping(User user) {
        user.getLegalIdDetailsList().clear();
        user.getMappingUser().clear();
    }

}
