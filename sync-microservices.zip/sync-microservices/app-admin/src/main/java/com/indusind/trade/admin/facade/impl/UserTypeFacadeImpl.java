package com.indusind.trade.admin.facade.impl;

import com.indusind.trade.model.entities.master.UserTypeTemp;
import com.indusind.trade.admin.facade.UserTypeFacade;
import com.indusind.trade.model.service.UserTypeTempService;
import com.indusind.trade.admin.utility.UserTypeUtil;
import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.dtos.requestdtos.UserTypeTabActionMappingDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.master.CategoryMaster;
import com.indusind.trade.model.entities.master.UserType;
import com.indusind.trade.model.entities.master.UserTypeTabActionMapping;
import com.indusind.trade.model.enums.Status;
import com.indusind.trade.model.service.CategoryMasterService;
import com.indusind.trade.model.service.UserTypeService;
import com.indusind.trade.model.service.UserTypeTabActionMappingService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class UserTypeFacadeImpl implements UserTypeFacade {

    private final UserTypeService userTypeService;
    private final UserTypeTempService userTypeTempService;

    private final CategoryMasterService categoryMasterService;

    private final UserTypeTabActionMappingService userTypeTabActionMappingService;

    // @Override
    // @Transactional(rollbackFor = Exception.class)
    // public ApplicationResponse saveUserType(UserTypeDto userTypeDto) {
    // CategoryMaster categoryMaster =
    // categoryMasterService.getCategoryById(userTypeDto.getCategoryId());
    // UserType userType = UserTypeDto.convertToEntity(userTypeDto);
    // userType.setCategory(categoryMaster);
    // UserType savedUserType = userTypeService.saveUserType(userType);
    // return new ApplicationResponse("SUCCESS",
    // UserTypeDto.convertToDto(savedUserType), "User Type Saved");
    // }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse saveUserType(UserTypeDto userTypeDto) {
        UserTypeTemp userTypeTemp;
        if (Objects.nonNull(userTypeDto.getIsUpdate()) && userTypeDto.getIsUpdate()) {
            userTypeTemp = userTypeTempService.getUserTypeTempById(userTypeDto.getUserTypeId());
        } else {
            userTypeTemp = new UserTypeTemp();
        }

        BeanUtils.copyProperties(userTypeDto, userTypeTemp);

        CategoryMaster categoryMaster = categoryMasterService.getCategoryById(userTypeDto.getCategoryId());
        userTypeTemp.setCategory(categoryMaster);

        userTypeTemp.setStatus(Status.PENDING);

        UserTypeTemp savedUserType = userTypeTempService.saveUserTypeTemp(userTypeTemp);

        return new ApplicationResponse("SUCCESS", UserTypeUtil.convertTempToDto(savedUserType),
                "Saved UserType in temp");
    }

    @Override
    public ApplicationResponse approveUserType(Long userTypeId) {
        UserTypeTemp userTypeTemp = userTypeTempService.getUserTypeTempById(userTypeId);

        userTypeTemp.setStatus(Status.APPROVED);
        userTypeTempService.saveUserTypeTemp(userTypeTemp);

        UserType userType;

        if (userTypeService.existsById(userTypeId)) {
            userType = userTypeService.getUserTypeById(userTypeId);
            userType = UserTypeTemp.convertToMaster(userTypeTemp, userType);
        } else {
            userType = UserTypeTemp.convertToMaster(userTypeTemp, new UserType());
        }

        UserType savedUserType = userTypeService.saveUserType(userType);

        return new ApplicationResponse("SUCCESS", UserTypeDto.convertToDto(savedUserType), "UserType approved");

    }

    @Override
    public ApplicationResponse rejectUserType(Long userTypeId) {
        UserTypeTemp userTypeTemp = userTypeTempService.getUserTypeTempById(userTypeId);

        if (userTypeService.existsById(userTypeId)) {
            UserType userType = userTypeService.getUserTypeById(userTypeId);
            userTypeTemp = UserTypeUtil.convertToTemp(userType, userTypeTemp);
            userTypeTemp.setStatus(Status.UPDATE_REJECTED);
        } else {
            userTypeTemp.setStatus(Status.REJECTED);
        }

        userTypeTempService.saveUserTypeTemp(userTypeTemp);

        return new ApplicationResponse("SUCCESS", userTypeId, "USerType rejected");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse updateUserType(UserTypeDto userTypeDto) {
        UserType userType = UserTypeDto.convertToEntity(userTypeDto);
        UserType updatedUserType = userTypeService.saveUserType(userType);
        return new ApplicationResponse("SUCCESS", UserTypeDto.convertToDto(updatedUserType), "User Type Updated");
    }

    @Override
    public ApplicationResponse getAllUserTypes(Pageable pageable) {
        Page<UserType> page = userTypeService.getAllUserTypes(pageable);
        return new ApplicationResponse("SUCCESS", page.map(UserTypeDto::convertToDto),
                "User Types fetched successfully");
    }

    @Override
    public ApplicationResponse getAllTempUserType(Pageable pageable) {
        Page<UserTypeTemp> page = userTypeTempService.getAllTempUserType(pageable);
        return new ApplicationResponse("SUCCESS", page.map(UserTypeUtil::convertTempToDto),
                "UserType fetched successfully");
    }

    @Override
    public ApplicationResponse getUserTypeById(Long userTypeId) {
        UserType userType = userTypeService.getUserTypeById(userTypeId);
        UserTypeDto userTypeDto = UserTypeDto.convertToDto(userType);

        List<UserTypeTabActionMapping> mappingList = userTypeTabActionMappingService.findByUserTypeId(userTypeId);
        List<UserTypeTabActionMappingDto> userTypeTabActionMappingResp = new ArrayList<>();
        Map<String, List<String>> tabActionMap = mappingList.stream()
                .collect(Collectors.groupingBy(map -> map.getTab().getTabId() + "-" + map.getTab().getTabName(),
                        Collectors.mapping(map -> map.getAction().getActionId() + "-" + map.getAction().getActionCode(),
                                Collectors.toList())));
        // tabActionMap.forEach((k, v) -> {
        // UserTypeTabActionMappingDto dto = new UserTypeTabActionMappingDto();
        // dto.setTabId(k.split("-")[0]);
        // dto.setTabName(k.split("-")[1]);
        //
        // List<Map<String, String>> result = v.stream()
        // .map(s -> {
        // String[] parts = s.split("-", 2);
        // String id = parts[0].trim();
        // String name = parts[1].trim();
        // Map<String, String> m = new HashMap<>();
        // m.put("id", id);
        // m.put("name", name);
        // return m;
        // })
        // .collect(Collectors.toList());
        //
        // dto.setActions(result);
        // userTypeTabActionMappingResp.add(dto);
        // });
        userTypeDto.setTabActionMapping(userTypeTabActionMappingResp);

        return new ApplicationResponse("SUCCESS", userTypeDto, "User Type Fetched");
    }

    @Override
    public ApplicationResponse getUserTypeTempById(Long userTypeId) {
        UserTypeTemp userTypeTemp = userTypeTempService.getUserTypeTempById(userTypeId);
        UserTypeDto userTypeDto = UserTypeUtil.convertTempToDto(userTypeTemp);
        return new ApplicationResponse("SUCCESS", userTypeDto, "User Type Temp Fetched");
    }

    @Override
    public ApplicationResponse getUserTypeListByCategory(Long categoryId) {
        List<UserType> userTypes = userTypeService.getUserTypeByCategoryId(categoryId);

        List<UserTypeDto> userTypeDtoList = userTypes.stream()
                .map(UserTypeDto::convertToDto)
                .toList();

        return new ApplicationResponse("SUCCESS", userTypeDtoList, "User Type List Fetched");
    }

    @Override
    public ApplicationResponse getUserTypePageByCategory(Pageable pageable, Long categoryId) {
        Page<UserType> page = userTypeService.getUserTypePageByCategory(pageable, categoryId);
        return new ApplicationResponse("SUCCESS", page.map(UserTypeDto::convertToDto), "UserType fetched successfully");
    }

}
