package com.indusind.trade.admin.repository;

import com.indusind.trade.admin.entities.UserAccountMappingTemp;
import com.indusind.trade.admin.entities.UserAccountMappingTempId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserAccountMappingTempRepository extends JpaRepository<UserAccountMappingTemp, UserAccountMappingTempId> {
    List<UserAccountMappingTemp> findById_UserId(Long userId);
}
