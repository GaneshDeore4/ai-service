package com.indusind.trade.admin.service;

import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;

public interface DashboardService {
    ApplicationResponse getDashboardStats();
}
