package com.indusind.trade.admin.service;

import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;

import java.util.List;

public interface UserAccountMappingApprovalService {
    ApplicationResponse approveUserAccountMapping(Long userId, List<String> accountIds);
    ApplicationResponse rejectUserAccountMapping(Long userId, List<String> accountIds);
    ApplicationResponse getAllPendingUserAccountMappings();
    ApplicationResponse getPendingUserAccountMappingsByUserId(Long userId); // New method
}
