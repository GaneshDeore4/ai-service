package com.indusind.trade.admin.service;

import com.indusind.trade.admin.entities.UserAccountMappingTemp;

import java.util.List;

public interface UserAccountMappingTempService {
    UserAccountMappingTemp save(UserAccountMappingTemp userAccountMappingTemp);
    List<UserAccountMappingTemp> findAll();
    void delete(UserAccountMappingTemp userAccountMappingTemp);
    List<UserAccountMappingTemp> findByUserId(Long userId);
}
