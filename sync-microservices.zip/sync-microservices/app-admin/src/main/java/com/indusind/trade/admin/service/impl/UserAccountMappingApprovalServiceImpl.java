package com.indusind.trade.admin.service.impl;

import com.indusind.trade.model.dtos.response.dtos.AccountDetailsDto;
import com.indusind.trade.model.dtos.response.dtos.AddUserAccountMappingResponseDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.entities.company.AccountDetail;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.admin.entities.UserAccountMappingTemp;
import com.indusind.trade.admin.entities.UserAccountMappingTempId;
import com.indusind.trade.model.exception.GTPAppException;
import com.indusind.trade.admin.service.UserAccountMappingApprovalService;
import com.indusind.trade.model.service.UserAccountMappingService;
import com.indusind.trade.admin.service.UserAccountMappingTempService;
import com.indusind.trade.model.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserAccountMappingApprovalServiceImpl implements UserAccountMappingApprovalService {

    private final UserService userService;
    private final UserAccountMappingService userAccountMappingService;
    private final UserAccountMappingTempService userAccountMappingTempService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse approveUserAccountMapping(Long userId, List<String> accountIds) {
        User user = userService.getUserById(userId);
        if (user == null) {
            throw new GTPAppException("User with ID: " + userId + " not found.", null);
        }

        // FIX: Use findAccountsById to fetch by UUID
        List<AccountDetail> accountsToApprove = userAccountMappingService.findAccountsById(accountIds);
        if (accountsToApprove.size() != accountIds.size()) {
            throw new GTPAppException("One or more accounts to approve were not found.", null);
        }

        // Initialize accountMapping if null, or clear it to replace existing mappings
        if (user.getAccountMapping() == null) {
            user.setAccountMapping(new ArrayList<>());
        } else {
            // Clear existing mappings to replace them with the newly approved ones
            user.getAccountMapping().clear();
        }

        // Add only the newly approved accounts to the user's mapping
        user.getAccountMapping().addAll(accountsToApprove);

        userService.saveUser(user); // This will persist changes to gtp_user_account_mapping (deleting old, inserting new)

        // Delete from temporary table
        for (String accountId : accountIds) {
            UserAccountMappingTempId tempId = new UserAccountMappingTempId(userId, accountId);
            UserAccountMappingTemp tempMapping = UserAccountMappingTemp.builder().id(tempId).build();
            userAccountMappingTempService.delete(tempMapping);
        }

        List<AccountDetailsDto> approvedAccountDetails = user.getAccountMapping().stream()
                .map(AccountDetailsDto::convertToDto)
                .collect(Collectors.toList());

        AddUserAccountMappingResponseDto responseDto = AddUserAccountMappingResponseDto.builder()
                .userId(user.getUserId())
                .accountDetails(approvedAccountDetails)
                .build();

        return new ApplicationResponse("SUCCESS", responseDto, "User Account Mapping approved and replaced successfully.");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApplicationResponse rejectUserAccountMapping(Long userId, List<String> accountIds) {
        // Only delete from temporary table
        for (String accountId : accountIds) {
            UserAccountMappingTempId tempId = new UserAccountMappingTempId(userId, accountId);
            UserAccountMappingTemp tempMapping = UserAccountMappingTemp.builder().id(tempId).build();
            userAccountMappingTempService.delete(tempMapping);
        }
        return new ApplicationResponse("SUCCESS", null, "User Account Mapping request rejected successfully.");
    }

    @Override
    public ApplicationResponse getAllPendingUserAccountMappings() {
        List<UserAccountMappingTemp> pendingMappings = userAccountMappingTempService.findAll();

        // Collect all unique account IDs from pending mappings
        Set<String> allPendingAccountIds = pendingMappings.stream()
                .map(temp -> temp.getId().getAccountId())
                .collect(Collectors.toSet());

        // FIX: Use findAccountsById to fetch by UUID
        List<AccountDetail> allAccountDetails = userAccountMappingService.findAccountsById(new ArrayList<>(allPendingAccountIds));

        // Create a map of accountId to AccountDetailsDto for easy lookup
        Map<String, AccountDetailsDto> accountDetailsDtoMap = allAccountDetails.stream()
                .map(AccountDetailsDto::convertToDto)
                .collect(Collectors.toMap(AccountDetailsDto::getId, Function.identity()));

        List<AddUserAccountMappingResponseDto> pendingResponseDtos = pendingMappings.stream()
                .collect(Collectors.groupingBy(temp -> temp.getId().getUserId()))
                .entrySet().stream()
                .map(entry -> {
                    Long userId = entry.getKey();
                    List<AccountDetailsDto> accountDetailsForUser = entry.getValue().stream()
                            .map(temp -> accountDetailsDtoMap.get(temp.getId().getAccountId())) // Get full DTO from map
                            .filter(java.util.Objects::nonNull) // Filter out any accounts not found (shouldn't happen if validation is correct)
                            .collect(Collectors.toList());

                    return AddUserAccountMappingResponseDto.builder()
                            .userId(userId)
                            .accountDetails(accountDetailsForUser)
                            .build();
                })
                .collect(Collectors.toList());

        return new ApplicationResponse("SUCCESS", pendingResponseDtos, "Pending User Account Mappings fetched successfully.");
    }

    @Override
    public ApplicationResponse getPendingUserAccountMappingsByUserId(Long userId) {
        // Validate User existence
        User user = userService.getUserById(userId);
        if (user == null) {
            throw new GTPAppException("User with ID: " + userId + " not found.", null);
        }

        List<UserAccountMappingTemp> pendingMappings = userAccountMappingTempService.findByUserId(userId);

        if (pendingMappings.isEmpty()) {
            return new ApplicationResponse("SUCCESS", Collections.emptyList(), "No pending User Account Mappings found for userId: " + userId);
        }

        // Collect all account IDs for this user's pending mappings
        List<String> accountIds = pendingMappings.stream()
                .map(temp -> temp.getId().getAccountId())
                .collect(Collectors.toList());

        // FIX: Use findAccountsById to fetch by UUID
        List<AccountDetail> accountDetails = userAccountMappingService.findAccountsById(accountIds);

        // Convert to AccountDetailsDto
        List<AccountDetailsDto> accountDetailsDtos = accountDetails.stream()
                .map(AccountDetailsDto::convertToDto)
                .collect(Collectors.toList());

        AddUserAccountMappingResponseDto responseDto = AddUserAccountMappingResponseDto.builder()
                .userId(userId)
                .accountDetails(accountDetailsDtos)
                .build();

        return new ApplicationResponse("SUCCESS", responseDto, "Pending User Account Mappings fetched successfully for userId: " + userId);
    }
}