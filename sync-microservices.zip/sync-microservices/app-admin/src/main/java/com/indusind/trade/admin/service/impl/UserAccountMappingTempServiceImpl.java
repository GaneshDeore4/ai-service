package com.indusind.trade.admin.service.impl;

import com.indusind.trade.admin.entities.UserAccountMappingTemp;
import com.indusind.trade.admin.repository.UserAccountMappingTempRepository;
import com.indusind.trade.admin.service.UserAccountMappingTempService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserAccountMappingTempServiceImpl implements UserAccountMappingTempService {

    private final UserAccountMappingTempRepository userAccountMappingTempRepository;

    @Override
    @Transactional
    public UserAccountMappingTemp save(UserAccountMappingTemp userAccountMappingTemp) {
        return userAccountMappingTempRepository.save(userAccountMappingTemp);
    }

    @Override
    public List<UserAccountMappingTemp> findAll() {
        return userAccountMappingTempRepository.findAll();
    }

    @Override
    @Transactional
    public void delete(UserAccountMappingTemp userAccountMappingTemp) {
        userAccountMappingTempRepository.delete(userAccountMappingTemp);
    }

    @Override
    public List<UserAccountMappingTemp> findByUserId(Long userId) {
        // This method needs to be implemented in the repository if needed
        // For now, returning an empty list or throwing an exception
        return userAccountMappingTempRepository.findById_UserId(userId);
    }
}
