package com.indusind.trade.admin.utility;

import com.indusind.trade.model.entities.master.DepartmentTemp;
import com.indusind.trade.model.dtos.response.dtos.DepartmentDto;
import com.indusind.trade.model.entities.master.Department;
import org.springframework.beans.BeanUtils;

public class DepartmentUtil {

    public static DepartmentDto convertTempToDto(DepartmentTemp departmentTemp){
        DepartmentDto departmentDto = new DepartmentDto();
        BeanUtils.copyProperties(departmentTemp, departmentDto);
        departmentDto.setCategoryId(departmentTemp.getCategory().getCategoryId());
        departmentDto.setCategoryName(departmentTemp.getCategory().getCategoryName());
        return departmentDto;
    }

    public static DepartmentTemp convertToTemp(Department department, DepartmentTemp departmentTemp){
        BeanUtils.copyProperties(department, departmentTemp);
        return departmentTemp;
    }
}
