package com.indusind.trade.admin.utility;

import com.indusind.trade.model.entities.master.ProductMasterTemp;
import com.indusind.trade.model.dtos.requestdtos.ProductMasterDto;
import com.indusind.trade.model.entities.master.ProductMaster;
import org.springframework.beans.BeanUtils;

public class ProductMasterUtils {

    public static ProductMaster convertToMaster(ProductMasterTemp temp, ProductMaster master) {
        BeanUtils.copyProperties(temp, master,"category");
        master.setCategory(temp.getCategory());
//        master.setMidOfficeFlag(temp.getMidOfficeFlag());
//        master.setSequenceId(temp.getSequenceId());
        return master;
    }


    public static ProductMasterDto convertToDto(ProductMasterTemp productMasterTemp) {
        ProductMasterDto productMasterDto = new ProductMasterDto();
        BeanUtils.copyProperties(productMasterTemp, productMasterDto);
        productMasterDto.setCategoryId(productMasterTemp.getCategory().getCategoryId());
        productMasterDto.setCategoryName(productMasterTemp.getCategory().getCategoryName());
        return productMasterDto;
    }
}
