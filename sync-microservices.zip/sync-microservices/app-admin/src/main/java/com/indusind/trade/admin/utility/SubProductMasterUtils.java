package com.indusind.trade.admin.utility;

import com.indusind.trade.model.entities.master.SubProductMasterTemp;
import com.indusind.trade.model.dtos.requestdtos.SubProductMasterDto;
import com.indusind.trade.model.entities.master.SubProductMaster;
import org.springframework.beans.BeanUtils;

public class SubProductMasterUtils {

    public static SubProductMasterTemp convertToTempEntity(SubProductMaster subProductMaster) {
        SubProductMasterTemp subProductMasterTemp = new SubProductMasterTemp();
        BeanUtils.copyProperties(subProductMaster, subProductMasterTemp);

        return subProductMasterTemp;
    }

    public static SubProductMaster convertToEntity(SubProductMasterTemp subProductMasterTemp) {
        SubProductMaster subProductMaster = new SubProductMaster();
        BeanUtils.copyProperties(subProductMasterTemp, subProductMaster);

        return subProductMaster;
    }

    public static SubProductMasterDto convertTempToDto(SubProductMasterTemp subProductMaster){
        SubProductMasterDto subProductMasterDto = new SubProductMasterDto();
        BeanUtils.copyProperties(subProductMaster, subProductMasterDto);
        subProductMasterDto.setCategoryId(subProductMaster.getProductMaster().getCategory().getCategoryId());
        subProductMasterDto.setCategoryName(subProductMaster.getProductMaster().getCategory().getCategoryName());
        subProductMasterDto.setProductId(subProductMaster.getProductMaster().getProductId());
        subProductMasterDto.setProductName(subProductMaster.getProductMaster().getProductName());
        subProductMasterDto.setProductLabel(subProductMaster.getProductMaster().getProductNameLabel());
        subProductMasterDto.setStatus(subProductMaster.getStatus());
        return subProductMasterDto;
    }

    public static SubProductMasterDto convertToDto(SubProductMaster subProductMaster){
        SubProductMasterDto subProductMasterDto = new SubProductMasterDto();
        BeanUtils.copyProperties(subProductMaster, subProductMasterDto);
        subProductMasterDto.setCategoryId(subProductMaster.getProductMaster().getCategory().getCategoryId());
        subProductMasterDto.setCategoryName(subProductMaster.getProductMaster().getCategory().getCategoryName());
        subProductMasterDto.setProductId(subProductMaster.getProductMaster().getProductId());
        subProductMasterDto.setProductName(subProductMaster.getProductMaster().getProductName());
        subProductMasterDto.setProductLabel(subProductMaster.getProductMaster().getProductNameLabel());
        return subProductMasterDto;
    }

}
