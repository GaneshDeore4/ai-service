package com.indusind.trade.admin.utility;

import com.indusind.trade.model.entities.master.UserTypeTemp;
import com.indusind.trade.model.dtos.requestdtos.UserTypeDto;
import com.indusind.trade.model.entities.master.UserType;
import org.springframework.beans.BeanUtils;

public class UserTypeUtil {

    public static UserTypeDto convertTempToDto(UserTypeTemp userTypeTemp){
        UserTypeDto userTypeDto = new UserTypeDto();
        BeanUtils.copyProperties(userTypeTemp, userTypeDto);
        userTypeDto.setCategoryId(userTypeTemp.getCategory().getCategoryId());
        userTypeDto.setCategoryName(userTypeTemp.getCategory().getCategoryName());
        return userTypeDto;
    }

    public static UserTypeTemp convertToTemp(UserType userType, UserTypeTemp userTypeTemp){
        BeanUtils.copyProperties(userType, userTypeTemp);
        return userTypeTemp;
    }

}
