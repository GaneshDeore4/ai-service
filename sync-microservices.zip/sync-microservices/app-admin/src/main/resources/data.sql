-- Seed data for Admin Service
-- Active DB: MSSQL. To revert to Oracle/Postgres, comment the MSSQL block and
-- uncomment the corresponding fallback block below.

-- =========================
-- MSSQL (Active)
-- =========================
-- IDs are explicit so FK references (gtp_user_type.category_id -> gtp_category_master,
-- basewidget.yml seeds) stay deterministic. Hibernate maps @GeneratedValue(IDENTITY)
-- to MSSQL IDENTITY columns, so explicit inserts require SET IDENTITY_INSERT ON.

/*SET IDENTITY_INSERT gtp_auth_group ON;

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 1)
    INSERT INTO gtp_auth_group (id, auth_group) VALUES (1, 'A');

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 2)
    INSERT INTO gtp_auth_group (id, auth_group) VALUES (2, 'B');

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 3)
    INSERT INTO gtp_auth_group (id, auth_group) VALUES (3, 'C');

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 4)
    INSERT INTO gtp_auth_group (id, auth_group) VALUES (4, 'D');

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 5)
    INSERT INTO gtp_auth_group (id, auth_group) VALUES (5, 'E');

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 6)
    INSERT INTO gtp_auth_group (id, auth_group) VALUES (6, 'F');

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 7)
    INSERT INTO gtp_auth_group (id, auth_group) VALUES (7, 'G');

IF NOT EXISTS (SELECT 1 FROM gtp_auth_group WHERE id = 8)
    INSERT INTO gtp_auth_group (id, auth_group) VALUES (8, 'H');

SET IDENTITY_INSERT gtp_auth_group OFF;


SET IDENTITY_INSERT gtp_category_master ON;

IF NOT EXISTS (SELECT 1 FROM gtp_category_master WHERE category_id = 1)
    INSERT INTO gtp_category_master (category_id, category_name) VALUES (1, 'Client');

IF NOT EXISTS (SELECT 1 FROM gtp_category_master WHERE category_id = 2)
    INSERT INTO gtp_category_master (category_id, category_name) VALUES (2, 'Bank');

SET IDENTITY_INSERT gtp_category_master OFF;


SET IDENTITY_INSERT gtp_user_type ON;

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 20)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (20, 'Super Admin', 2);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 21)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (21, 'Bank Super Admin Maker', 2);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 22)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (22, 'Bank Super Admin Checker', 2);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 23)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (23, 'Bank Setup Maker', 2);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 24)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (24, 'Bank Setup Checker', 2);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 25)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (25, 'Bank View Only', 2);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 26)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (26, 'Bank Branch Verifier', 2);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 27)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (27, 'Client (M=C)', 1);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 28)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (28, 'Client Maker', 1);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 29)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (29, 'Client Checker', 1);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 30)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (30, 'Client Verifier', 1);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 31)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (31, 'Client Releaser', 1);

IF NOT EXISTS (SELECT 1 FROM gtp_user_type WHERE user_type_id = 32)
    INSERT INTO gtp_user_type (user_type_id, user_type_name, category_id) VALUES (32, 'Client View', 1);

SET IDENTITY_INSERT gtp_user_type OFF;
*/

-- =========================
-- Oracle (fallback - commented)
-- =========================
--MERGE INTO gtp_auth_group t
--USING (SELECT 1 AS id, 'A' AS auth_group FROM dual) s
--ON (t.id = s.id)
--WHEN NOT MATCHED THEN INSERT (id, auth_group) VALUES (s.id, s.auth_group);
--
--MERGE INTO gtp_auth_group t
--USING (SELECT 2 AS id, 'B' AS auth_group FROM dual) s
--ON (t.id = s.id)
--WHEN NOT MATCHED THEN INSERT (id, auth_group) VALUES (s.id, s.auth_group);
--
--MERGE INTO gtp_auth_group t
--USING (SELECT 3 AS id, 'C' AS auth_group FROM dual) s
--ON (t.id = s.id)
--WHEN NOT MATCHED THEN INSERT (id, auth_group) VALUES (s.id, s.auth_group);
--
--MERGE INTO gtp_auth_group t
--USING (SELECT 4 AS id, 'D' AS auth_group FROM dual) s
--ON (t.id = s.id)
--WHEN NOT MATCHED THEN INSERT (id, auth_group) VALUES (s.id, s.auth_group);
--
--MERGE INTO gtp_auth_group t
--USING (SELECT 5 AS id, 'E' AS auth_group FROM dual) s
--ON (t.id = s.id)
--WHEN NOT MATCHED THEN INSERT (id, auth_group) VALUES (s.id, s.auth_group);
--
--MERGE INTO gtp_auth_group t
--USING (SELECT 6 AS id, 'F' AS auth_group FROM dual) s
--ON (t.id = s.id)
--WHEN NOT MATCHED THEN INSERT (id, auth_group) VALUES (s.id, s.auth_group);
--
--MERGE INTO gtp_auth_group t
--USING (SELECT 7 AS id, 'G' AS auth_group FROM dual) s
--ON (t.id = s.id)
--WHEN NOT MATCHED THEN INSERT (id, auth_group) VALUES (s.id, s.auth_group);
--
--MERGE INTO gtp_auth_group t
--USING (SELECT 8 AS id, 'H' AS auth_group FROM dual) s
--ON (t.id = s.id)
--WHEN NOT MATCHED THEN INSERT (id, auth_group) VALUES (s.id, s.auth_group);
--
--INSERT INTO gtp_category_master (category_id, category_name)
--SELECT 1, 'Client' FROM dual
--WHERE NOT EXISTS (SELECT 1 FROM gtp_category_master WHERE category_id = 1);
--
--INSERT INTO gtp_category_master (category_id, category_name)
--SELECT 2, 'Bank' FROM dual
--WHERE NOT EXISTS (SELECT 1 FROM gtp_category_master WHERE category_id = 2);
--
--MERGE INTO gtp_user_type t
--USING (
--  SELECT 21 AS user_type_id, 'Bank Super Admin Maker' AS user_type_name, 2 AS category_id FROM dual UNION ALL
--  SELECT 22, 'Bank Super Admin Checker', 2 FROM dual UNION ALL
--  SELECT 23, 'Bank Setup Maker',         2 FROM dual UNION ALL
--  SELECT 24, 'Bank Setup Checker',       2 FROM dual UNION ALL
--  SELECT 25, 'Bank View Only',           2 FROM dual UNION ALL
--  SELECT 26, 'Bank Branch Verifier',     2 FROM dual UNION ALL
--  SELECT 27, 'Client (M=C)',             1 FROM dual UNION ALL
--  SELECT 28, 'Client Maker',             1 FROM dual UNION ALL
--  SELECT 29, 'Client Checker',           1 FROM dual UNION ALL
--  SELECT 30, 'Client Verifier',          1 FROM dual UNION ALL
--  SELECT 31, 'Client Releaser',          1 FROM dual UNION ALL
--  SELECT 32, 'Client View',              1 FROM dual UNION ALL
--  SELECT 20, 'Super Admin',              2 FROM dual
--) s
--ON (t.user_type_id = s.user_type_id)
--WHEN NOT MATCHED THEN
--  INSERT (user_type_id, user_type_name, category_id)
--  VALUES (s.user_type_id, s.user_type_name, s.category_id);
--
--commit;


-- =========================
-- Postgres (fallback - commented)
-- =========================
--Postgres script
INSERT INTO gtp_auth_group (id, auth_group) VALUES (1, 'A') ON CONFLICT (id) DO NOTHING;
INSERT INTO gtp_auth_group (id, auth_group) VALUES (2, 'B') ON CONFLICT (id) DO NOTHING;
INSERT INTO gtp_auth_group (id, auth_group) VALUES (3, 'C') ON CONFLICT (id) DO NOTHING;
INSERT INTO gtp_auth_group (id, auth_group) VALUES (4, 'D') ON CONFLICT (id) DO NOTHING;
INSERT INTO gtp_auth_group (id, auth_group) VALUES (5, 'E') ON CONFLICT (id) DO NOTHING;
INSERT INTO gtp_auth_group (id, auth_group) VALUES (6, 'F') ON CONFLICT (id) DO NOTHING;
INSERT INTO gtp_auth_group (id, auth_group) VALUES (7, 'G') ON CONFLICT (id) DO NOTHING;
INSERT INTO gtp_auth_group (id, auth_group) VALUES (8, 'H') ON CONFLICT (id) DO NOTHING;

-- Adjust sequence to avoid primary key collisions if dynamic inserts happen later

SELECT setval(pg_get_serial_sequence('gtp_auth_group', 'id'), coalesce(max(id),0) + 1, false) FROM gtp_auth_group;

INSERT INTO gtp_category_master (category_name) VALUES ('Client')
ON CONFLICT (category_name) DO NOTHING;

INSERT INTO gtp_category_master (category_name) VALUES ('Bank')
ON CONFLICT (category_name) DO NOTHING;

--for USER_TYPE_TEMP

INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (21, 'Bank Super Admin Maker', 'Bank Super Admin Maker', 2, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (22, 'Bank Super Admin Checker', 'Bank Super Admin Checker',2, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (23, 'Bank Setup Maker', 'Bank Setup Maker',2, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (24, 'Bank Setup Checker', 'Bank Setup Checker', 2, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (25, 'Bank View Only','Bank View Only', 2, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (26, 'Bank Branch Verifier', 'Bank Branch Verifier', 2, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (27, 'Client (M=C)', 'Client (M=C)', 1, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (28, 'Client Maker', 'Client Maker', 1, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (29, 'Client Checker', 'Client Checker', 1, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (30, 'Client Verifier', 'Client Verifier', 1, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (31, 'Client Releaser', 'Client Releaser', 1, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (32, 'Client View', 'Client View', 1, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type_temp(user_type_id, user_type_name, user_type_name_label, category_id, status) VALUES (20, 'Super Admin', 'Super Admin', 2, 'APPROVED') ON CONFLICT (user_type_id) DO NOTHING;

-- for USER_TYPE
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (21, 'Bank Super Admin Maker', 'Bank Super Admin Maker', 2) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (22, 'Bank Super Admin Checker', 'Bank Super Admin Checker', 2) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (23, 'Bank Setup Maker', 'Bank Setup Maker', 2) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (24, 'Bank Setup Checker', 'Bank Setup Checker', 2) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (25, 'Bank View Only', 'Bank View Only', 2) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (26, 'Bank Branch Verifier', 'Bank Branch Verifier', 2) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (27, 'Client (M=C)', 'Client (M=C)', 1) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (28, 'Client Maker', 'Client Maker', 1) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (29, 'Client Checker', 'Client Checker', 1) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (30, 'Client Verifier', 'Client Verifier', 1) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (31, 'Client Releaser', 'Client Releaser', 1) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (32, 'Client View', 'Client View', 1) ON CONFLICT (user_type_id) DO NOTHING;
INSERT INTO gtp_user_type(user_type_id, user_type_name, user_type_name_label, category_id) VALUES (20, 'Super Admin', 'Super Admin', 2) ON CONFLICT (user_type_id) DO NOTHING;

-- Re-align the sequence for CATEGORY_ID to max(id)+1
SELECT setval(
 pg_get_serial_sequence('gtp_category_master', 'category_id'),
 COALESCE((SELECT MAX(category_id) FROM gtp_category_master), 0) + 1,
 false
);

commit;