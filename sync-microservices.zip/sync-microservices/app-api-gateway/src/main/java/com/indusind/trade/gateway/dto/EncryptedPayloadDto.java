package com.indusind.trade.gateway.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EncryptedPayloadDto {

    private String data;
    private String encKey;
    private String iv;

}
