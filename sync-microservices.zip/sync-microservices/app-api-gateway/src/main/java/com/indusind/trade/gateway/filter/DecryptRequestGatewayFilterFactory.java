package com.indusind.trade.gateway.filter;

import com.indusind.trade.gateway.dto.EncryptedPayloadDto;
import com.indusind.trade.util.EncryptionDecryptionUtil;
import com.indusind.trade.util.RSAKeyUtil;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.HandlerStrategies;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
public class DecryptRequestGatewayFilterFactory
        extends AbstractGatewayFilterFactory<DecryptRequestGatewayFilterFactory.Config> {

    @Autowired
    private RSAKeyUtil rsaKeyUtil;

    public DecryptRequestGatewayFilterFactory() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            ServerRequest serverRequest = ServerRequest.create(
                    exchange,
                    HandlerStrategies.withDefaults().messageReaders());

            return serverRequest.bodyToMono(EncryptedPayloadDto.class)
                    .flatMap(encryptedRequest -> {

                        if (encryptedRequest.getEncKey() == null || encryptedRequest.getData() == null) {
                            return Mono.error(new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid encrypted payload"));
                        }

                        try {
                            // 1. Decrypt AES Key and IV
                            SecretKey secretKey = rsaKeyUtil.decryptAESKey(encryptedRequest.getEncKey());
                            String aesKeyBase64 = Base64.getEncoder().encodeToString(secretKey.getEncoded());
                            
                            String iv = encryptedRequest.getIv();
                            if (iv == null) {
                                return Mono.error(new ResponseStatusException(HttpStatus.BAD_REQUEST, "IV is missing in request"));
                            }
                            String plainIV = rsaKeyUtil.decryptIV(iv);

                            // 2. Decrypt Request Body
                            String decryptedPayload = EncryptionDecryptionUtil.decryptPayload(encryptedRequest.getData(), aesKeyBase64, plainIV);
                            byte[] requestBytes = decryptedPayload.getBytes(StandardCharsets.UTF_8);

                            // 3. Store Key and IV in Exchange Attributes for Response Encryption
                            exchange.getAttributes().put("cachedAesKey", aesKeyBase64);
                            exchange.getAttributes().put("cachedIv", plainIV);

                            // 4. Mutate Request
                            ServerHttpRequest mutatedRequest = exchange.getRequest().mutate()
                                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                    .header(HttpHeaders.CONTENT_LENGTH, String.valueOf(requestBytes.length))
                                    .build();

                            ServerHttpRequestDecorator requestDecorator = new ServerHttpRequestDecorator(mutatedRequest) {
                                @Override
                                public Flux<DataBuffer> getBody() {
                                    return Flux.just(exchange.getResponse().bufferFactory().wrap(requestBytes));
                                }
                            };

                            // 5. Mutate Response to Encrypt
                            ServerHttpResponseDecorator responseDecorator = new ServerHttpResponseDecorator(exchange.getResponse()) {
                                @Override
                                public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
                                    String key = exchange.getAttribute("cachedAesKey");
                                    String iv = exchange.getAttribute("cachedIv");

                                    if (key != null && iv != null && body instanceof Flux) {
                                        Flux<? extends DataBuffer> fluxBody = (Flux<? extends DataBuffer>) body;

                                        return super.writeWith(fluxBody.collectList().flatMap(dataBuffers -> {
                                            DataBufferFactory bufferFactory = exchange.getResponse().bufferFactory();
                                            DataBuffer joinBuffer = bufferFactory.join(dataBuffers);
                                            byte[] content = new byte[joinBuffer.readableByteCount()];
                                            joinBuffer.read(content);
                                            DataBufferUtils.release(joinBuffer);

                                            try {
                                                String responseBody = new String(content, StandardCharsets.UTF_8);
                                                // Encrypt response using same AES key and IV
                                                String encryptedResponse = EncryptionDecryptionUtil.encryptPayload(responseBody, key, iv);
                                                
                                                byte[] encryptedBytes = encryptedResponse.getBytes(StandardCharsets.UTF_8);
                                                getHeaders().setContentLength(encryptedBytes.length);
                                                getHeaders().setContentType(MediaType.TEXT_PLAIN); // Or custom type
                                                
                                                return Mono.just(bufferFactory.wrap(encryptedBytes));
                                            } catch (Exception e) {
                                                return Mono.error(e);
                                            }
                                        }));
                                    }
                                    return super.writeWith(body);
                                }
                            };

                            return chain.filter(exchange.mutate()
                                    .request(requestDecorator)
                                    .response(responseDecorator)
                                    .build());

                        } catch (Exception e) {
                            return Mono.error(new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Decryption/Encryption failed: " + e.getMessage()));
                        }
                    });
        };
    }

    public static class Config {
    }
}
