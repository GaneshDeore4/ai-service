package com.indusind.trade.gateway.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


@Component
@Slf4j
public class JwtAuthenticationFilter implements GlobalFilter, Ordered {

    @Value("${jwt.secret}")
    private String jwtSecret;

    @Value("${gateway.internal.secret}")
    private String gatewayInternalSecret;

    private final WebClient.Builder webClientBuilder;

    public JwtAuthenticationFilter(WebClient.Builder webClientBuilder) {
        this.webClientBuilder = webClientBuilder;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        String path = exchange.getRequest().getURI().getPath();
        String requestId = UUID.randomUUID().toString();

        if (path.startsWith("/api/auth/")
                || path.startsWith("/session/")
                || exchange.getRequest().getMethod() == HttpMethod.OPTIONS) {

            return chain.filter(exchange.mutate()
                    .request(exchange.getRequest()
                            .mutate()
                            .header("X-Request-Id", requestId)
                            .build())
                    .build());
        }

        String authHeader = exchange.getRequest()
                .getHeaders()
                .getFirst(HttpHeaders.AUTHORIZATION);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return sessionExpired(exchange, requestId);
        }

        String token = authHeader.substring(7);

        try {
            Claims claims = Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            String username = claims.getSubject();

            String rolesStr = claims.get("roles", String.class);
            List<String> roles = (rolesStr != null && !rolesStr.isBlank())
                    ? Arrays.asList(rolesStr.split(","))
                    : List.of(Optional.ofNullable(
                    claims.get("userType", String.class)).orElse("USER"));

            String sessionId = Optional.ofNullable(
                            claims.get("session_id", String.class))
                    .orElse(claims.get("sessionId", String.class));

            if (sessionId == null || sessionId.isBlank()) {
                return sessionExpired(exchange, requestId);
            }

            return webClientBuilder.build()
                    .get()
                    .uri("lb://session-service/session/validate?session_id={id}", sessionId)
                    .retrieve()
                    .bodyToMono(SessionValidateGatewayResponse.class)
                    .timeout(Duration.ofSeconds(5))
                    .flatMap(resp -> {

                        if (!resp.isValid()) {
                            return sessionExpired(exchange, requestId);
                        }

                        String forwardToken = token;
                        if ("SESSION_CONTINUED".equalsIgnoreCase(resp.getMessage())
                                && resp.getToken() != null
                                && !resp.getToken().isBlank()) {

                            forwardToken = resp.getToken();
                        }

                        ServerHttpRequest mutatedRequest =
                                exchange.getRequest().mutate()
                                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + forwardToken)
                                        .header("X-Gateway-Secret", gatewayInternalSecret)
                                        .header("X-User-Name", username)
                                        .header("X-User-Roles", String.join(",", roles))
                                        .header("X-Request-Id", requestId)
                                        .build();

                        return chain.filter(
                                exchange.mutate().request(mutatedRequest).build());
                    })
                    .onErrorResume(WebClientRequestException.class, ex -> {
                        log.error("Session-service unreachable requestId={}", requestId, ex);
                        exchange.getResponse().setStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
                        return exchange.getResponse().setComplete();
                    });

        } catch (JwtException ex) {
            log.warn("Invalid JWT requestId={}", requestId, ex);
            return sessionExpired(exchange, requestId);
        }
    }

    private Mono<Void> sessionExpired(ServerWebExchange exchange, String requestId) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        exchange.getResponse().getHeaders().add("X-Auth-Error", "SESSION_EXPIRED");
        exchange.getResponse().getHeaders().add(HttpHeaders.CONTENT_TYPE, "application/json");

        String body = """
                {
                  "errorCode": "SESSION_EXPIRED",
                  "message": "Your session has expired. Please login again.",
                  "requestId": "%s"
                }
                """.formatted(requestId);

        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        DataBuffer buffer =
                exchange.getResponse().bufferFactory().wrap(bytes);

        return exchange.getResponse().writeWith(Mono.just(buffer));
    }

    private SecretKey getSigningKey() {
        byte[] keyBytes = Decoders.BASE64.decode(jwtSecret);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    @Override
    public int getOrder() {
        return -10;
    }

    @Data
    private static class SessionValidateGatewayResponse {
        private boolean valid;
        private String message;
        private String token;
    }
}
