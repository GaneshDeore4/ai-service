package com.indusind.trade.auth.client;

import com.indusind.trade.auth.dto.LDAPRequestDto;
import com.indusind.trade.auth.dto.LDAPResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "ldapClient", url = "${app.feign.ldap-url}")
public interface LDAPClient {

    @PostMapping
    LDAPResponseDto callLDAP(
            @RequestHeader("IBL-Client-ID") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody LDAPRequestDto request
    );

}
