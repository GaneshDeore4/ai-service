package com.indusind.trade.auth.client;

import com.indusind.trade.auth.dto.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;


@FeignClient(name = "session-service", url = "${session.service.url:}")
    public interface SessionServiceClient {

        @PostMapping("/session/create")
        SessionCreateResponse createSession(@RequestBody SessionCreateRequest request);


        @PostMapping("/session/logout")
        void logout(@RequestBody SessionLogoutRequest request);


        @PostMapping("/session/force-logout")
        void forceLogout(@RequestBody SessionForceLogoutRequest request);

        @GetMapping("/session/validate")
        SessionValidateResponse validateSession(@RequestParam("session_id") String sessionId);


        @GetMapping("/session/has-active")
        boolean hasActiveSession(@RequestParam("userId") String userId);


        @GetMapping("/session/history")
        List<SessionHistoryResponse> getSessionHistory(@RequestParam("userId") String userId);


}


