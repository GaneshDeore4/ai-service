package com.indusind.trade.auth.controller;

import com.indusind.trade.auth.audit.AuthAuditService;
import com.indusind.trade.auth.dto.SessionHistoryResponse;
import com.indusind.trade.auth.security.JwtTokenProvider;
import com.indusind.trade.auth.service.SessionServiceImpl;
import com.indusind.trade.auth.service.TrustedDeviceServiceImpl;
import com.indusind.trade.model.entities.master.UserSession;
import com.indusind.trade.model.repository.BankUserDao;
import com.indusind.trade.model.repository.UserDao;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {

        private final AuthenticationConfiguration authenticationConfiguration;
        private final JwtTokenProvider jwtTokenProvider;
        private final SessionServiceImpl sessionServiceImpl;
        private final TrustedDeviceServiceImpl trustedDeviceServiceImpl;
        private final AuthAuditService authAuditService;
        private final UserDao userDao;
        private final BankUserDao bankUserDao;

        @PostMapping("/logout")
        public ResponseEntity<?> logout(HttpServletRequest request) {
                String authHeader = request.getHeader("Authorization");
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                        String token = authHeader.substring(7);
                        try {
                                String sessionId = jwtTokenProvider.getClaimAsString(token, "sessionId");
                                String loginId = jwtTokenProvider.getUsername(token);
                                String role = jwtTokenProvider.getClaimAsString(token, "role");
                                if (sessionId != null) {
                                        sessionServiceImpl.terminateSession(sessionId, "EXPLICIT_LOGOUT");
                                }
                                SecurityContextHolder.clearContext();
                                authAuditService.logEvent("AUTH_LOGOUT", loginId, role,
                                                request.getRemoteAddr(), "SUCCESS", "Explicit logout", sessionId);
                        } catch (Exception e) {
                                log.warn("Logout called with invalid/expired token: {}", e.getMessage());
                        }
                }
                return ResponseEntity.ok(Map.of("message", "Logged out successfully"));
        }

        // ──────────────────────────────────────────────
        // FORCED LOGOUT (for testing/admin after browser close)
        // ──────────────────────────────────────────────
        @PostMapping("/logout/force")
        public ResponseEntity<?> forceLogout(@RequestBody Map<String, Object> requestDto, HttpServletRequest request) {
                String loginId = (String) requestDto.get("loginId");
                String cifOrAbbvName = (String) requestDto.get("cifOrAbbvName");
                sessionServiceImpl.revokeAllSessions(loginId, cifOrAbbvName, "FORCED_POSTMAN_LOGOUT");
                authAuditService.logEvent("AUTH_LOGOUT_FORCE", loginId, "ADMIN_OR_TEST",
                                request.getRemoteAddr(), "SUCCESS", "Forced explicit logout via /force API", null);
                return ResponseEntity.ok(Map.of("message",
                                "All active sessions for " + loginId + " have been terminated successfully."));
        }

        // ──────────────────────────────────────────────
        // SESSION HISTORY (admin/self use)
        // ──────────────────────────────────────────────
        @GetMapping("/getSessions")
        public ResponseEntity<?> getSessionHistory(@RequestBody Map<String, Object> requestDto) {
                String loginId = (String) requestDto.get("loginId");
                String cifOrAbbvName = (String) requestDto.get("cifOrAbbvName");
                List<SessionHistoryResponse> sessions = sessionServiceImpl.getSessionHistory(loginId,cifOrAbbvName);
                return ResponseEntity.ok(sessions);
        }

        // ──────────────────────────────────────────────
        // TRUSTED DEVICES (admin management)
        // ──────────────────────────────────────────────
        @GetMapping("/devices/pending")
        public ResponseEntity<?> getPendingDevices() {
                return ResponseEntity.ok(trustedDeviceServiceImpl.getPendingDevices());
        }

        @PostMapping("/devices/{deviceId}/approve")
        public ResponseEntity<?> approveDevice(@PathVariable Long deviceId, HttpServletRequest request) {
                String approvedBy = jwtTokenProvider.getClaimAsString(
                                request.getHeader("Authorization").substring(7), "loginId");
                trustedDeviceServiceImpl.approveDevice(deviceId, approvedBy);
                return ResponseEntity.ok(Map.of("message", "Device approved"));
        }

        @PostMapping("/devices/{deviceId}/block")
        public ResponseEntity<?> blockDevice(@PathVariable Long deviceId,
                        @RequestBody Map<String, String> body,
                        HttpServletRequest request) {
                String blockedBy = jwtTokenProvider.getClaimAsString(
                                request.getHeader("Authorization").substring(7), "loginId");
                trustedDeviceServiceImpl.blockDevice(deviceId, body.getOrDefault("reason", "Blocked by admin"),
                                blockedBy);
                return ResponseEntity.ok(Map.of("message", "Device blocked"));
        }
}
