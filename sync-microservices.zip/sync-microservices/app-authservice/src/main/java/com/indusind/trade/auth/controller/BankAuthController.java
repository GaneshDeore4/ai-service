package com.indusind.trade.auth.controller;

import com.indusind.trade.auth.audit.AuthAuditService;
import com.indusind.trade.auth.security.AppUserDetails;
import com.indusind.trade.auth.security.JwtTokenProvider;
import com.indusind.trade.auth.service.SessionServiceImpl;
import com.indusind.trade.auth.service.TrustedDeviceServiceImpl;
import com.indusind.trade.auth.service.MfaService;
import com.indusind.trade.auth.util.DateFormatterUtil;
import com.indusind.trade.auth.util.LdapRelidAuthenticationToken;
import com.indusind.trade.auth.util.RELID_2FA_Auth;
import com.indusind.trade.model.common.security.SecurityUtils;
import com.indusind.trade.model.dtos.requestdtos.BankLoginRequestDto;
import com.indusind.trade.model.dtos.requestdtos.ResetPasswordDto;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.JwtResponse;
import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.entities.master.UserSession;
import com.indusind.trade.model.repository.BankUserDao;
import com.indusind.trade.model.service.BankUserService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/auth/bank")
@RequiredArgsConstructor
@Slf4j
public class BankAuthController {

    private final AuthenticationConfiguration authenticationConfiguration;
    private final JwtTokenProvider jwtTokenProvider;
    private final SessionServiceImpl sessionServiceImpl;
    private final TrustedDeviceServiceImpl trustedDeviceServiceImpl;
    private final AuthAuditService authAuditService;
    private final BankUserDao bankUserDao;
    private final BankUserService bankUserService;
    private final PasswordEncoder passwordEncoder;
    private final MfaService mfaService;
    private final RELID_2FA_Auth relid2FAAuth;
//    private final AuthenticationManager authenticationManager;

    @Value("${mfa.enabled:false}")
    private boolean mfaEnabled;

    @Value("${bank.user.max.auth.fail.count}")
    private Long maxAuthFailCount;

    private AuthenticationManager getAuthenticationManager() throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @PostMapping("/bankLogin")
    public ResponseEntity<?> authenticateBankUser(@RequestBody BankLoginRequestDto bankLoginRequestDto,
                                                  HttpServletRequest request) throws Exception {

        String ip = request.getRemoteAddr();

        if (Objects.nonNull(bankLoginRequestDto) && Objects.nonNull(bankLoginRequestDto.getBankAbbvName())
                && Objects.nonNull(bankLoginRequestDto.getLoginId())) {
            boolean isValidBankUser = bankUserDao.existsByBankProfileAbbvNameAndLoginId(
                    bankLoginRequestDto.getBankAbbvName(), bankLoginRequestDto.getLoginId());

            if (!isValidBankUser) {
                authAuditService.logEvent("AUTH_LOGIN_FAILURE", bankLoginRequestDto.getLoginId(),
                        null, ip, "FAILURE", "Invalid Corp ID or Username", null);
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(new JwtResponse(null, null,
                                "Error: Invalid Corp ID (Company ID) or Username",null));
            }
        }

        // 2. Device fingerprint check
        String fingerprint = SecurityUtils.generateDeviceFingerprint(request);
        TrustedDeviceServiceImpl.DeviceCheckResult deviceResult = trustedDeviceServiceImpl.validateDevice(
                bankLoginRequestDto.getLoginId(), bankLoginRequestDto.getBankAbbvName(), fingerprint,
                ip);

        if (deviceResult.isBlocked()) {
            authAuditService.logEvent("DEVICE_BLOCKED_ATTEMPT", bankLoginRequestDto.getLoginId(),
                    null, ip, "FAILURE", "Blocked device login attempt", null);
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "Device is blocked. Contact your administrator."));
        }

        BankUser bankUser = bankUserDao.findByLoginIdAndBankProfileAbbvName(bankLoginRequestDto.getLoginId(), bankLoginRequestDto.getBankAbbvName()).get();
        if(bankUser.getIsUserLocked()){
            authAuditService.logEvent("AUTH_LOGIN_FAILURE", bankLoginRequestDto.getLoginId(),
                    null, ip, "FAILURE", "User Locked", null);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new JwtResponse(null, null,
                            "User Locked",null));
        }

        // 2.5 Concurrent Session Check (Enforce single active session)
        if (!bankLoginRequestDto.isForce() && sessionServiceImpl.hasActiveSession(bankLoginRequestDto.getLoginId(), bankLoginRequestDto.getBankAbbvName())) {
            authAuditService.logEvent("CONCURRENT_LOGIN_ATTEMPT", bankLoginRequestDto.getLoginId(),
                    null, ip, "FAILURE", "Active session already exists", null);
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("error",
                            "User is already active. Please logout from your previous session or wait for it to expire."));
        }
        Authentication authentication = null;
        try {
//            authentication = this.getAuthenticationManager().authenticate(
//                    new UsernamePasswordAuthenticationToken(
//                            bankLoginRequestDto.getLoginId() + "-"+ bankLoginRequestDto.getBankAbbvName(),
//                            bankLoginRequestDto.getPassword()));
            authentication = this.getAuthenticationManager().authenticate(
                    new LdapRelidAuthenticationToken(
                            bankLoginRequestDto.getLoginId() + "-" + bankLoginRequestDto.getBankAbbvName(),
                            bankLoginRequestDto.getPassword()
                    )
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);
            
            // 2.6 Revoke old sessions if force flag is set (After successful authentication)
            if (bankLoginRequestDto.isForce()) {
                sessionServiceImpl.revokeAllSessions(bankLoginRequestDto.getLoginId(), 
                        bankLoginRequestDto.getBankAbbvName(), "FORCED_LOGIN_UPON_AUTHENTICATION");
            }

        } catch (Exception e) {
            bankUser.setLoginFailedCount(bankUser.getLoginFailedCount() + 1);
            if (bankUser.getLoginFailedCount() >= maxAuthFailCount) {
                bankUser.setIsUserLocked(true);
                bankUserService.saveBankUser(bankUser);
            }
            throw e;
        }
        // 3. Authenticate credentials (existing logic — unchanged)


        AppUserDetails userDetails = (AppUserDetails) authentication.getPrincipal();
        String roleName = userDetails.getRoleName() != null ? userDetails.getRoleName() : "BANKADMIN";
        String loginId = userDetails.getLoginId();
        String bankAbbvName = userDetails.getBankAbbvName();

        // 4. Create full session record
        UserSession session = sessionServiceImpl.createSession(
                loginId, bankAbbvName, roleName,
                ip, fingerprint, deviceResult.deviceId());

        // 5. Generate enriched JWT
        String jwt = jwtTokenProvider.generateToken(
                authentication, request,
                roleName,
                bankAbbvName, session.getSessionId(), deviceResult.deviceId());

        // 6. Audit success + device warning if unrecognized
        if (deviceResult.isPending()) {
            authAuditService.logEvent("DEVICE_UNRECOGNIZED", loginId, roleName, ip,
                    "WARNING", "Login from unrecognized device — pending admin approval",
                    session.getSessionId());
        }
        bankUser.setLoginFailedCount(0L);
        LocalDateTime lastLogin = bankUser.getLastLogin() == null ? LocalDateTime.now(): bankUser.getLastLogin();
        bankUser.setLastLogin(LocalDateTime.now());
        bankUserService.saveBankUser(bankUser);
        
        if (mfaEnabled) {
            mfaService.generateAndSendOtp(loginId, "bank");
            JwtResponse mfaPendingResponse = new JwtResponse(null, loginId, roleName, bankUser.getBankUserId());
            mfaPendingResponse.setStatus("PENDING_MFA");
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(mfaPendingResponse);
        }

        authAuditService.logEvent("AUTH_LOGIN_SUCCESS", loginId, roleName, ip,
                "SUCCESS", null, session.getSessionId());

        JwtResponse successResponse = new JwtResponse(jwt, loginId, roleName, bankUser.getBankUserId());
        successResponse.setStatus("SUCCESS");
        successResponse.setUserFirstName(bankUser.getFirstName());
        successResponse.setUserLastName(bankUser.getLastName());
        successResponse.setLastLogin(DateFormatterUtil.formatLastLogin(lastLogin));
        return ResponseEntity.ok(successResponse);
    }

    @PostMapping("/mfaVerify")
    public ResponseEntity<?> verifyMfa(@RequestBody Map<String, String> requestBody, HttpServletRequest request) {
        String loginId = requestBody.get("loginId");
        String bankAbbvName = requestBody.get("bankAbbvName");
        String otp = requestBody.get("otp");

        if (!mfaService.verifyOtp(loginId, otp)) {
             return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid or expired OTP"));
        }

        BankUser bankUser = bankUserDao.findByLoginIdAndBankProfileAbbvName(loginId, bankAbbvName).get();
        String roleName = "BANKADMIN"; // Should come from bankUser.getBankRole() if available
        String jwt = jwtTokenProvider.generateToken(null, request, roleName, bankAbbvName, "MFA_SESSION", null);

        authAuditService.logEvent("BANK_MFA_SUCCESS", loginId, roleName, request.getRemoteAddr(), "SUCCESS", "MFA Verified", null);

        JwtResponse successResponse = new JwtResponse(jwt, loginId, roleName, bankUser.getBankUserId());
        successResponse.setStatus("SUCCESS");
        return ResponseEntity.ok(successResponse);
    }

    @PostMapping("/resetBankUserPassword")
    public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordDto resetPasswordDto){
        if(!resetPasswordDto.isAfterLogin()){
            bankUserService.resetBankUserPasswordByLoginIdAndBankAbbvName(resetPasswordDto.getLoginId(), passwordEncoder.encode(resetPasswordDto.getNewPassword()), resetPasswordDto.getBankAbbvName());
        } else{
            bankUserService.resetBankUserPasswordByUserId(resetPasswordDto.getUserId(), passwordEncoder.encode(resetPasswordDto.getNewPassword()));
        }
        return ResponseEntity.ok().body(new ApplicationResponse("SUCCESS",null,"Password reset successfully"));
    }

//    @PostMapping("/unclockBankUser")
//    public ResponseEntity<?> resetPassword(String loginId){
//        bankUserService.lockUnlockUser(loginId, false);
//        return ResponseEntity.ok().body(new ApplicationResponse("SUCCESS",null,"User reset successfully"));
//
//    }

    @PostMapping("/unlockBankUser")
    public ResponseEntity<?> unlockBankUser(@RequestBody Map<String, Object> request) {
        String loginId = (String) request.get("loginId");
        String bankAbbvName = (String) request.get("bankAbbvName");
        bankUserService.lockUnlockUser(loginId, false, bankAbbvName);
        return ResponseEntity.ok().body(new ApplicationResponse("SUCCESS", null, "User unlocked successfully"));
    }

    @PatchMapping("/privacy-policy")
    public ResponseEntity<?> updatePrivacyPolicy(@RequestBody Map<String, Object> request) {
        String loginId = (String) request.get("loginId");
        String bankAbbvName = (String) request.get("bankAbbvName");
        Boolean accepted = (Boolean) request.get("accepted");
        bankUserService.updatePrivacyPolicy(loginId, accepted, bankAbbvName);
        return ResponseEntity.ok().body(new ApplicationResponse("SUCCESS", null, "Privacy policy updated successfully"));
    }

    @PostMapping("/relid")
    public CompletableFuture<ApplicationResponse> relid(@RequestParam String ecn) {
        return CompletableFuture.supplyAsync(() -> {
            try {
//                String res = relid2FAAuth.validate2FA(ecn);
//                return new ApplicationResponse("SUCCESS", res, "SUCCESS");

                Thread.sleep(3000);
                return new ApplicationResponse("SUCCESS", "success", "SUCCESS");
            } catch (Exception e) {
//                throw new IllegalStateException(e);
                System.out.println("error: " + e.getMessage());
                return new ApplicationResponse("SUCCESS", "fail", "SUCCESS");
            }

        });
    }


}
