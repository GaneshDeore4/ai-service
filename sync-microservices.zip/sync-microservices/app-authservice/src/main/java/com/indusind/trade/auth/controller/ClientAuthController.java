package com.indusind.trade.auth.controller;

import com.indusind.trade.auth.audit.AuthAuditService;
import com.indusind.trade.auth.security.AppUserDetails;
import com.indusind.trade.auth.security.JwtTokenProvider;
import com.indusind.trade.auth.service.SessionServiceImpl;
import com.indusind.trade.auth.service.TrustedDeviceServiceImpl;
import com.indusind.trade.auth.service.MfaService;
import com.indusind.trade.auth.util.DateFormatterUtil;
import com.indusind.trade.model.common.security.SecurityUtils;
import com.indusind.trade.model.dtos.requestdtos.ClientLoginRequestDto;
import com.indusind.trade.model.dtos.requestdtos.ResetPasswordDto;
import com.indusind.trade.model.dtos.requestdtos.UserDTO;
import com.indusind.trade.model.dtos.response.dtos.ApplicationResponse;
import com.indusind.trade.model.dtos.response.dtos.JwtResponse;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.entities.master.UserSession;
import com.indusind.trade.model.repository.UserDao;
import com.indusind.trade.model.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;

@RestController
@RequestMapping("/api/auth/client")
@RequiredArgsConstructor
@Slf4j
public class ClientAuthController {

        private final AuthenticationConfiguration authenticationConfiguration;
        private final JwtTokenProvider jwtTokenProvider;
        private final SessionServiceImpl sessionServiceImpl;
        private final TrustedDeviceServiceImpl trustedDeviceServiceImpl;
        private final AuthAuditService authAuditService;
        private final UserDao userDao;
        private final PasswordEncoder passwordEncoder;
        private final UserService userService;
        private final MfaService mfaService;

        @Value("${mfa.enabled:false}")
        private boolean mfaEnabled;

        @Value("${user.max.auth.fail.count}")
        private Long maxAuthFailCount;

        private AuthenticationManager getAuthenticationManager() throws Exception {
                return authenticationConfiguration.getAuthenticationManager();
        }

        @PostMapping("/clientLogin")
        public ResponseEntity<?> authenticateUser(@RequestBody ClientLoginRequestDto clientLoginRequestDto,
                        HttpServletRequest request) throws Exception {

                String ip = request.getRemoteAddr();

                // 1. Validate Corp ID / Company ID matches Login ID (existing business logic —
                // unchanged)
                if (Objects.nonNull(clientLoginRequestDto) && Objects.nonNull(clientLoginRequestDto.getCifId())
                                && Objects.nonNull(clientLoginRequestDto.getLoginId())) {
                        boolean isValidUser = userDao.existsByCompanyCifIdAndLoginId(clientLoginRequestDto.getCifId(),
                                        clientLoginRequestDto.getLoginId());

                        if (!isValidUser) {
                                authAuditService.logEvent("AUTH_LOGIN_FAILURE", clientLoginRequestDto.getLoginId(),
                                                null, ip, "FAILURE", "Invalid Corp ID or Username", null);
                                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                                                .body(new JwtResponse(null, null,
                                                                "Error: Invalid Corp ID (Company ID) or Username",
                                                                null));
                        }
                }

                // 2. Device fingerprint check
                String fingerprint = SecurityUtils.generateDeviceFingerprint(request);
                TrustedDeviceServiceImpl.DeviceCheckResult deviceResult = trustedDeviceServiceImpl.validateDevice(
                                clientLoginRequestDto.getLoginId(), clientLoginRequestDto.getCifId(), fingerprint, ip);

                if (deviceResult.isBlocked()) {
                        authAuditService.logEvent("DEVICE_BLOCKED_ATTEMPT", clientLoginRequestDto.getLoginId(),
                                        null, ip, "FAILURE", "Blocked device login attempt", null);
                        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                                        .body(Map.of("error", "Device is blocked. Contact your administrator."));
                }

                User user = userDao.findByLoginIdAndCompanyCifId(clientLoginRequestDto.getLoginId(),
                                clientLoginRequestDto.getCifId()).get();
                if (user.getIsUserLocked()) {
                        authAuditService.logEvent("AUTH_LOGIN_FAILURE", clientLoginRequestDto.getLoginId(),
                                        null, ip, "FAILURE", "User Locked", null);
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                                        .body(new JwtResponse(null, null,
                                                        "User Locked", null));
                }

                // 2.5 Concurrent Session Check (Enforce single active session)
                if (sessionServiceImpl.hasActiveSession(clientLoginRequestDto.getLoginId(),
                                clientLoginRequestDto.getCifId())) {
                        authAuditService.logEvent("CONCURRENT_LOGIN_ATTEMPT", clientLoginRequestDto.getLoginId(),
                                        null, ip, "FAILURE", "Active session already exists", null);
                        return ResponseEntity.status(HttpStatus.CONFLICT)
                                        .body(Map.of("error",
                                                        "User is already active. Please logout from your previous session or wait for it to expire."));
                }

                Authentication authentication = null;
                try {
                        authentication = this.getAuthenticationManager().authenticate(
                                        new UsernamePasswordAuthenticationToken(
                                                        clientLoginRequestDto.getLoginId() + "-"
                                                                        + clientLoginRequestDto.getCifId(),
                                                        clientLoginRequestDto.getPassword()));

                        SecurityContextHolder.getContext().setAuthentication(authentication);
                } catch (Exception e) {
                        user.setLoginFailedCount(user.getLoginFailedCount() + 1);
                        if (user.getLoginFailedCount() >= maxAuthFailCount) {
                                user.setIsUserLocked(true);
                                userService.saveUser(user);
                        }
                        throw e;
                }

                SecurityContextHolder.getContext().setAuthentication(authentication);

                AppUserDetails userDetails = (AppUserDetails) authentication.getPrincipal();
                String roleName = userDetails.getRoleName() != null ? userDetails.getRoleName() : "USER";
                String loginId = userDetails.getLoginId();
                String companyCifId = userDetails.getCompanyCifId();
                String email = userDetails.getEmail();

                // 4. Create full session record
                UserSession session = sessionServiceImpl.createSession(
                                loginId, companyCifId, roleName,
                                ip, fingerprint, deviceResult.deviceId());

                // 5. Generate enriched JWT
                String jwt = jwtTokenProvider.generateToken(
                                authentication, request,
                                roleName,
                                companyCifId, session.getSessionId(), deviceResult.deviceId());

                // 6. Audit success + device warning if unrecognized
                if (deviceResult.isPending()) {
                        authAuditService.logEvent("DEVICE_UNRECOGNIZED", loginId, roleName, ip,
                                        "WARNING", "Login from unrecognized device — pending admin approval",
                                        session.getSessionId());
                }
                user.setLoginFailedCount(0L);
                LocalDateTime lastLogin = user.getLastLogin() == null ? LocalDateTime.now(): user.getLastLogin();
                user.setLastLogin(LocalDateTime.now());

                userService.saveUser(user);

                if (mfaEnabled) {
                        mfaService.generateAndSendOtp(loginId, "client");
                        JwtResponse mfaPendingResponse = new JwtResponse(null, loginId, roleName,
                                        user.getUserId(), user.isTermPrivacyAccepted());
                        mfaPendingResponse.setStatus("PENDING_MFA");
                        return ResponseEntity.status(HttpStatus.ACCEPTED).body(mfaPendingResponse);
                }

                authAuditService.logEvent("AUTH_LOGIN_SUCCESS", loginId, roleName, ip,
                                "SUCCESS", null, session.getSessionId());

                JwtResponse successResponse = new JwtResponse(jwt, loginId, email, roleName, user.getUserId(),
                                user.isTermPrivacyAccepted());
                successResponse.setStatus("SUCCESS");
                if(Objects.nonNull(user.getAuthGroup())){
                        successResponse.setGroupId(user.getAuthGroup().getId());
                        successResponse.setGroupName(user.getAuthGroup().getAuthGroup());
                }
                successResponse.setUserFirstName(user.getFirstName());
                successResponse.setUserLastName(user.getLastName());
                successResponse.setBaseCurrency(user.getBaseCurr());
                successResponse.setLastLogin(DateFormatterUtil.formatLastLogin(lastLogin));
                return ResponseEntity.ok(successResponse);
        }

        @PostMapping("/mfaVerify")
        public ResponseEntity<?> verifyMfa(@RequestBody Map<String, String> requestBody, HttpServletRequest request) {
                String loginId = requestBody.get("loginId");
                String cifId = requestBody.get("cifId");
                String otp = requestBody.get("otp");

                if (!mfaService.verifyOtp(loginId, otp)) {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid or expired OTP"));
                }

                User user = userDao.findByLoginIdAndCompanyCifId(loginId, cifId).get();
                // Generate final token after MFA
                String jwt = jwtTokenProvider.generateToken(null, request, "USER", cifId, "MFA_SESSION", "DEVICE_ID");

                JwtResponse successResponse = new JwtResponse(jwt, loginId, "USER", user.getUserId(), user.isTermPrivacyAccepted());
                successResponse.setStatus("SUCCESS");
                return ResponseEntity.ok(successResponse);
        }

        @PostMapping("/resetUserPassword")
        public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordDto resetPasswordDto) {
                if (!resetPasswordDto.isAfterLogin()) {
                        userService.resetUserPasswordByLoginIdAndCifId(resetPasswordDto.getLoginId(),
                                        resetPasswordDto.getComanyCifId(),
                                        passwordEncoder.encode(resetPasswordDto.getNewPassword()));
                } else {
                        userService.resetUserPasswordByUserId(resetPasswordDto.getUserId(),
                                        passwordEncoder.encode(resetPasswordDto.getNewPassword()));
                }
                return ResponseEntity.ok()
                                .body(new ApplicationResponse("SUCCESS", null, "Password reset successfully"));
        }

        @PostMapping("/unclockUser")
        public ResponseEntity<?> resetPassword(@RequestBody Map<String, Object> request) {
                String loginId = (String) request.get("loginId");
                String cifId = (String) request.get("cifId");
                userService.lockUnlockUser(loginId, false, cifId);
                return ResponseEntity.ok().body(new ApplicationResponse("SUCCESS", null, "User reset successfully"));

        }

        @PatchMapping("/privacy-policy")
        public ResponseEntity<?> updatePrivacyPolicy(@RequestBody Map<String, Object> request) {
                String loginId = (String) request.get("loginId");
                String cifId = (String) request.get("cifId");
                Boolean accepted = (Boolean) request.get("accepted");
                userService.updatePrivacyPolicy(loginId, accepted, cifId);
                return ResponseEntity.ok()
                                .body(new ApplicationResponse("SUCCESS", null, "Privacy policy updated successfully"));
        }

}
