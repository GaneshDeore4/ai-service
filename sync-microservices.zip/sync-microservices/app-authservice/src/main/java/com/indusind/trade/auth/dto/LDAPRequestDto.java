package com.indusind.trade.auth.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@Builder
public class LDAPRequestDto {

    private String userid;
    private String password;
    private String requestUUID;
    private LocalDateTime timestamp;

}
