package com.indusind.trade.auth.dto;

import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class RelRvnResponse {
    private Integer response_code;

    private String notification_uuid;

    private String verification_mode;

    private String msg_id;

    private String comments;

    private String user_status;

    private String user_id;

    private String group_name;

    private List<String> secondary_group_names;

    private String user_updated_ts;

    public Integer getResponse_code() {
        return this.response_code;
    }

    public void setResponse_code(Integer response_code) {
        this.response_code = response_code;
    }

    public String getNotification_uuid() {
        return this.notification_uuid;
    }

    public void setNotification_uuid(String notification_uuid) {
        this.notification_uuid = notification_uuid;
    }

    public String getVerification_mode() {
        return this.verification_mode;
    }

    public void setVerification_mode(String verification_mode) {
        this.verification_mode = verification_mode;
    }

    public String getMsg_id() {
        return this.msg_id;
    }

    public void setMsg_id(String msg_id) {
        this.msg_id = msg_id;
    }

    public String getComments() {
        return this.comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getUser_status() {
        return this.user_status;
    }

    public void setUser_status(String user_status) {
        this.user_status = user_status;
    }

    public String getUser_id() {
        return this.user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getGroup_name() {
        return this.group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public List<String> getSecondary_group_names() {
        return this.secondary_group_names;
    }

    public void setSecondary_group_names(List<String> secondary_group_names) {
        this.secondary_group_names = secondary_group_names;
    }

    public String getUser_updated_ts() {
        return this.user_updated_ts;
    }

    public void setUser_updated_ts(String user_updated_ts) {
        this.user_updated_ts = user_updated_ts;
    }
}

