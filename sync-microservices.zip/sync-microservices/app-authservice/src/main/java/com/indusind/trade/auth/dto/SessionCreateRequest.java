package com.indusind.trade.auth.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SessionCreateRequest {
    @NotNull
    private String userId;
    private String ipAddress;
    private String deviceInfo;
    private String loginId;
}
