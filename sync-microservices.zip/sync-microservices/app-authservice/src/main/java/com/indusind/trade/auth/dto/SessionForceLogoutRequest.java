package com.indusind.trade.auth.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class SessionForceLogoutRequest {
    private String sessionId;
    private String userId;
    private Long adminUserId;
    private String reason;
}
