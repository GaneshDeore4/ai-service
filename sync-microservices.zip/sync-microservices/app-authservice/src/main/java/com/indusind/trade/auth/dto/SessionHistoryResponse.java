package com.indusind.trade.auth.dto;

import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@Builder
public class SessionHistoryResponse {


    private String sessionId;
    private Long userId;

    private Instant loginTime;
    private Instant logoutTime;

    private String logoutReason;
    private String sessionStatus;

    private String ipAddress;
    private String deviceInfo;

}
