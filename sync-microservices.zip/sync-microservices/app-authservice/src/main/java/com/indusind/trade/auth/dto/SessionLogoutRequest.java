package com.indusind.trade.auth.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SessionLogoutRequest {
    @NotNull
    private String sessionId;
    private String reason;
}
