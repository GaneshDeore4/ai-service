package com.indusind.trade.auth.dto;

import com.indusind.trade.auth.enums.SessionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SessionValidateResponse {
    private boolean valid;
    private String message;
    private String sessionId;
    private String userId;
    private SessionStatus sessionStatus;
    private Instant expiryTime;
    private String token;
}
