package com.indusind.trade.auth.enums;

public enum SessionStatus {
    ACTIVE,
    EXPIRED,
    TERMINATED
}
