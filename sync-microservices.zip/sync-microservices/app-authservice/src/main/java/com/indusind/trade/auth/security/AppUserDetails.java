package com.indusind.trade.auth.security;

import com.indusind.trade.model.entities.bank.BankUser;
import com.indusind.trade.model.entities.company.User;
import com.indusind.trade.model.entities.master.UserType;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;

@Getter
public class AppUserDetails implements UserDetails {

    private final Long userId;
    private final String loginId;
    private final String password;
    private final String email;
    private final String companyCifId;
    private final String bankAbbvName;
    private final Long roleId;
    private final String roleName;
    private final Collection<? extends GrantedAuthority> authorities;

    public AppUserDetails(User user) {
        this.userId = user.getUserId();
        this.loginId = user.getLoginId();
        this.email = user.getEmail();	
        this.password = user.getUserPassword();
        this.companyCifId = user.getCompany().getCifId();
        this.bankAbbvName = null;

        UserType userType = user.getUserType();
        if (userType != null) {
            this.roleId = userType.getUserTypeId();
            this.roleName = userType.getUserTypeName();
            this.authorities = Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + roleName));
        } else {
            this.roleId = null;
            this.roleName = null;
            this.authorities = Collections.emptyList();
        }
    }

    public AppUserDetails(BankUser user) {
        this.userId = user.getBankUserId();
        this.loginId = user.getLoginId();
        this.email = user.getEmail();
        this.password = user.getUserPassword();
        this.bankAbbvName = user.getBankProfile().getAbbvName();
        this.companyCifId = null;
        UserType userType = user.getUserType();
        if (userType != null) {
            this.roleId = userType.getUserTypeId();
            this.roleName = userType.getUserTypeName();
            this.authorities = Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + roleName));
        } else {
            this.roleId = null;
            this.roleName = null;
            this.authorities = Collections.emptyList();
        }
    }

    public static AppUserDetails build(User user) {
        return new AppUserDetails(user);
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return loginId;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        // use activeFlag logic if needed, e.g.
        // "Y".equalsIgnoreCase(user.getActiveFlag())
        return true;
    }
}
