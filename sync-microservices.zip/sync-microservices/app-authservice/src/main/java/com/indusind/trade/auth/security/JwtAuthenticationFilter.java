package com.indusind.trade.auth.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.indusind.trade.auth.exception.GlobalExceptionHandler;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	 private static final Logger log = LoggerFactory.getLogger(JwtAuthenticationFilter.class);
	
    private final JwtTokenProvider jwtTokenProvider;
    private final UnifiedUserDetailsService userDetailsService;
    private final com.indusind.trade.auth.client.SessionServiceClient sessionServiceClient;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {

        String path = request.getServletPath();

        return path.startsWith("/api/auth/client/clientLogin") ||
                path.startsWith("/api/auth/bank/bankLogin") ||
                path.startsWith("/v3/api-docs") ||
                path.startsWith("/swagger-ui") ||
                path.startsWith("/h2-console");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String token = getTokenFromRequest(request);

        if (StringUtils.hasText(token)) {
            try {
                if (jwtTokenProvider.validateToken(token, request)) {
                    String sessionId = jwtTokenProvider.getClaimAsString(token, "sessionId");
                    
                    if (StringUtils.hasText(sessionId)) {
                        com.indusind.trade.auth.dto.SessionValidateResponse sessionResponse = 
                                sessionServiceClient.validateSession(sessionId);
                        
                        if (!sessionResponse.isValid()) {
                            log.warn("Session in DB is invalid for sessionId: {} Reason: {}", 
                                    sessionId, sessionResponse.getMessage());
                            response.setHeader("x-auth-error", "SESSION_EXPIRED");
                            filterChain.doFilter(request, response);
                            return;
                        }
                    }

                    String usernameAndAbbv = jwtTokenProvider.getUsername(token);
                    String username = usernameAndAbbv.split("-")[0];

                    UserDetails userDetailsServiceDetails = userDetailsService.loadUserByUsername(username);

                    UsernamePasswordAuthenticationToken authentication =
                            new UsernamePasswordAuthenticationToken(
                                    userDetailsServiceDetails, null, userDetailsServiceDetails.getAuthorities());

                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                    SecurityContextHolder.getContext().setAuthentication(authentication);
                }
            } catch (io.jsonwebtoken.ExpiredJwtException ex) {
                log.warn("Session Expired: {}", ex.getMessage());
                response.setHeader("x-auth-error", "SESSION_EXPIRED");
                // We don't block the chain here, Spring Security will handle 401/403 later
                // but the header is now available for the frontend.
            } catch (Exception ex) {
                log.error("Authentication Error: {}", ex.getMessage());
            }
        }

        filterChain.doFilter(request, response);
    }

    private String getTokenFromRequest(HttpServletRequest request) {
        String bearer = request.getHeader("Authorization");

        if (StringUtils.hasText(bearer) && bearer.startsWith("Bearer ")) {
            return bearer.substring(7);
        }
        return null;
    }
}
