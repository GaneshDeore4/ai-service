package com.indusind.trade.auth.service;

import com.indusind.trade.auth.client.SessionServiceClient;
import com.indusind.trade.auth.dto.*;
import com.indusind.trade.model.entities.master.UserSession;
import com.indusind.trade.model.repository.UserSessionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class SessionServiceImpl {

    private final UserSessionRepository sessionRepository;

    private final SessionServiceClient sessionServiceClient;


    @Transactional
    public UserSession createSession(
            String loginId,
            String cifIdOrAbbvName,
            String userType,
            String ipAddress,
            String deviceFingerprint,
            String deviceId
    ) {

        SessionCreateRequest request = SessionCreateRequest.builder()
                .loginId(loginId)
                .userId(cifIdOrAbbvName) // IMPORTANT
                .ipAddress(ipAddress)
                .deviceInfo(deviceFingerprint)
                .build();

        SessionCreateResponse response =
                sessionServiceClient.createSession(request);

        return UserSession.builder()
                .sessionId(response.getSessionId())
                .loginId(loginId)
                .cifIdAbbvName(cifIdOrAbbvName)
                .userType(userType)
                .ipAddress(ipAddress)
                .deviceFingerprint(deviceFingerprint)
                .deviceId(deviceId)
                .status("ACTIVE")
                .loginTime(response.getLoginTime())
                .build();
    }


/**
 * Called on successful login. Creates ACTIVE session.
 */
    /*@Transactional
    public UserSession createSession(String loginId, String cifIdOrAbbvName,
            String userType, String ipAddress,
            String deviceFingerprint, String deviceId) {
        String sessionId = UUID.randomUUID().toString();
        UserSession session = UserSession.builder()
                .sessionId(sessionId)
                .loginId(loginId)
                .cifIdAbbvName(cifIdOrAbbvName)
                .userType(userType)
                .ipAddress(ipAddress)
                .deviceFingerprint(deviceFingerprint)
                .deviceId(deviceId)
                .loginTime(Instant.now())
                .lastActiveTime(Instant.now())
                .status("ACTIVE")
                .build();
        return sessionRepository.save(session);
    } */

    /**
     * Called on explicit logout.
     */
    /*@Transactional
    public void terminateSession(String sessionId, String reason) {
        sessionRepository.findById(sessionId).ifPresent(session -> {
            session.setStatus("LOGGED_OUT");
            session.setLogoutTime(Instant.now());
            session.setLogoutReason(reason != null ? reason : "EXPLICIT_LOGOUT");
            sessionRepository.save(session);
        });
    }
*/
    @Transactional
    public void terminateSession(String sessionId, String reason) {

        SessionLogoutRequest request = SessionLogoutRequest.builder()
                .sessionId(sessionId)
                .reason(reason != null ? reason : "EXPLICIT_LOGOUT")
                .build();

        sessionServiceClient.logout(request);
    }
    /**
     * Update last-active timestamp for an ongoing session (call from JWT filter).
     */
    //commenting this as session‑service already updates activity on every /session/validate call, which the gateway calls automatically for every request.
   /* @Transactional
    public void touchSession(String sessionId) {
        sessionRepository.findById(sessionId).ifPresent(session -> {
            if ("ACTIVE".equals(session.getStatus())) {
                session.setLastActiveTime(Instant.now());
                sessionRepository.save(session);
            }
        });
    }*/

    /**
     * Revoke all active sessions for a user (admin-triggered or security event).
     */
   /* @Transactional
    public void revokeAllSessions(String loginId, String cifOrAbvvName, String reason) {
        List<UserSession> activeSessions = sessionRepository.findByLoginIdAndCifIdAbbvNameAndStatus(loginId, cifOrAbvvName,"ACTIVE");
        activeSessions.forEach(s -> {
            s.setStatus("REVOKED");
            s.setLogoutTime(Instant.now());
            s.setLogoutReason(reason);
        });
        sessionRepository.saveAll(activeSessions);
        log.warn("Revoked {} active sessions for user: {} reason: {}", activeSessions.size(), loginId, reason);
    }*/


    @Transactional
    public void revokeAllSessions(String loginId, String cifOrAbbvName, String reason) {

        SessionForceLogoutRequest request =
                SessionForceLogoutRequest.builder()
                        .userId(cifOrAbbvName)
                        .reason(reason != null ? reason : "SECURITY_REVOKE")
                        .build();
        sessionServiceClient.forceLogout(request);

        log.warn("Force‑revoked all active sessions for user: {} reason: {}",
                loginId, request.getReason());
    }


    /**
     * Scheduled: mark sessions whose last-active is older than JWT expiry window as
     * EXPIRED.
     * Runs every 15 minutes.
     */
    // commented expireInactiveSessions() as  session‑service already has below logic

   /* Instant absoluteExpiry = session.getLoginTime()
            .plus(sessionProperties.getAbsoluteTimeoutHours(), HOURS);*/
    // commented as  session‑service already has below logic

    /*@Scheduled(fixedRate = 15 * 60 * 1000)
    @Transactional
    public void expireInactiveSessions() {
        // Sessions inactive for more than 8 hours are expired
        Instant cutoff = Instant.now().minus(8, ChronoUnit.HOURS);
        int count = sessionRepository.markExpiredBefore(cutoff);
        if (count > 0) {
            log.info("Expired {} inactive sessions", count);
        }
    }*/

    /*public boolean hasActiveSession(String loginId, String cifOrAbbvName) {
        return !sessionRepository.findByLoginIdAndCifIdAbbvNameAndStatus(loginId, cifOrAbbvName, "ACTIVE").isEmpty();
    }*/


    public boolean hasActiveSession(String loginId, String cifOrAbbvName) {

        return sessionServiceClient.hasActiveSession(loginId);
    }


   /* public List<UserSession> getSessionHistory(String loginId, String cifOrfAbbvName) {
        return sessionRepository.findByLoginIdAndAndCifIdAbbvNameOrderByLoginTimeDesc(loginId, cifOrfAbbvName);
    }*/


    public List<SessionHistoryResponse>
    getSessionHistory(String loginId, String cifOrAbbvName) {

        return sessionServiceClient.getSessionHistory(loginId);
    }

}
