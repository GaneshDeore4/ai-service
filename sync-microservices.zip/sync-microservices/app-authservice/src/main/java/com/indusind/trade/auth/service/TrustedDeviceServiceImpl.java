package com.indusind.trade.auth.service;

import com.indusind.trade.model.entities.master.TrustedDevice;
import com.indusind.trade.model.repository.TrustedDeviceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class TrustedDeviceServiceImpl {

    public static final String STATUS_TRUSTED = "TRUSTED";
    public static final String STATUS_PENDING = "PENDING_APPROVAL";
    public static final String STATUS_BLOCKED = "BLOCKED";

    private final TrustedDeviceRepository deviceRepository;

    /**
     * Validate device on login. Returns device status outcome.
     * AUTO-registers new devices as PENDING_APPROVAL.
     *
     * @return TRUSTED / PENDING_APPROVAL / BLOCKED
     */
    @Transactional
    public DeviceCheckResult validateDevice(String loginId, String cifOrAbbvName,
            String fingerprint, String ipAddress) {
        Optional<TrustedDevice> existing = deviceRepository
                .findByLoginIdAndCifIdAbbvNameAndDeviceFingerprint(loginId, cifOrAbbvName, fingerprint);

        if (existing.isPresent()) {
            TrustedDevice device = existing.get();
            device.setLastUsedAt(Instant.now());
            deviceRepository.save(device);

            if (STATUS_BLOCKED.equals(device.getStatus())) {
                log.warn("Blocked device login attempt: loginId={} deviceId={}", loginId, device.getDeviceId());
                return new DeviceCheckResult(STATUS_BLOCKED, null, "Device is blocked");
            }
            return new DeviceCheckResult(device.getStatus(), String.valueOf(device.getDeviceId()), null);
        }

        // Auto-register as PENDING
        TrustedDevice newDevice = TrustedDevice.builder()
                .loginId(loginId)
                .cifIdAbbvName(cifOrAbbvName)
                .deviceFingerprint(fingerprint)
                .deviceAlias("Unrecognized Device")
                .status(STATUS_PENDING)
                .registeredAt(Instant.now())
                .lastUsedAt(Instant.now())
                .registeredByIp(ipAddress)
                .build();
        TrustedDevice saved = deviceRepository.save(newDevice);
        log.info("New device auto-registered (PENDING) for: {} deviceId={}", loginId, saved.getDeviceId());
        return new DeviceCheckResult(STATUS_PENDING, String.valueOf(saved.getDeviceId()), "Unrecognized device");
    }

    /** Admin: approve a device */
    @Transactional
    public void approveDevice(Long deviceId, String approvedBy) {
        deviceRepository.findById(deviceId).ifPresent(device -> {
            device.setStatus(STATUS_TRUSTED);
            device.setApprovedBy(approvedBy);
            device.setApprovedAt(Instant.now());
            deviceRepository.save(device);
            log.info("Device {} approved by {}", deviceId, approvedBy);
        });
    }

    /** Admin: block a device */
    @Transactional
    public void blockDevice(Long deviceId, String reason, String blockedBy) {
        deviceRepository.findById(deviceId).ifPresent(device -> {
            device.setStatus(STATUS_BLOCKED);
            device.setBlockedReason(reason);
            deviceRepository.save(device);
            log.warn("Device {} blocked by {} reason: {}", deviceId, blockedBy, reason);
        });
    }

    public List<TrustedDevice> getDevicesForUser(String loginId, String cifOrAbbvName) {
        return deviceRepository.findByLoginIdAndCifIdAbbvNameOrderByLastUsedAtDesc(loginId, cifOrAbbvName);
    }

    public List<TrustedDevice> getPendingDevices() {
        return deviceRepository.findByStatus(STATUS_PENDING);
    }

    /** Simple result holder */
    public record DeviceCheckResult(String status, String deviceId, String message) {
        public boolean isTrusted() {
            return STATUS_TRUSTED.equals(status);
        }

        public boolean isPending() {
            return STATUS_PENDING.equals(status);
        }

        public boolean isBlocked() {
            return STATUS_BLOCKED.equals(status);
        }
    }
}
