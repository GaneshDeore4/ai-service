package com.indusind.trade.auth.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class DateFormatterUtil {

    private static final DateTimeFormatter LAST_LOGIN_FORMATTER =
            DateTimeFormatter.ofPattern("EEEE,dd/MM/yyyy, h:mm a");

    public static String formatLastLogin(LocalDateTime lastLogin) {
        if (Objects.isNull(lastLogin)) {
            return null;
        }
        return lastLogin.format(LAST_LOGIN_FORMATTER);
    }

}
