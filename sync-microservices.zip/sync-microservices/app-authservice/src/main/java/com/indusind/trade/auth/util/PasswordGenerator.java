package com.indusind.trade.auth.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordGenerator {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        String pass1 = "password";
        System.out.println("Pass: " + pass1 + " -> Hash: " + encoder.encode(pass1));

        String pass2 = "password123";
        System.out.println("Pass: " + pass2 + " -> Hash: " + encoder.encode(pass2));
    }
}
