package com.indusind.audit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonAuditApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonAuditApplication.class, args);
	}

}
