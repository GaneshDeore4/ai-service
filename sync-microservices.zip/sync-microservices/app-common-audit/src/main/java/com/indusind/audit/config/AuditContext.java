package com.indusind.audit.config;

import com.indusind.audit.enums.Action;

public class AuditContext {

    private static final ThreadLocal<String> USER = new ThreadLocal<>();
    private static final ThreadLocal<Action> ROLE = new ThreadLocal<>();

    public static void set(String user, Action role) {
        USER.set(user);
        ROLE.set(role);
    }

    public static String getUser() {
        return USER.get();
    }

    public static Action getRole() {
        return ROLE.get();
    }

    public static void clear() {
        USER.remove();
        ROLE.remove();
    }
}
