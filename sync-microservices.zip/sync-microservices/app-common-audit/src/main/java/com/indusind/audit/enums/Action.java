package com.indusind.audit.enums;

public enum Action {
    CREATE,
    EDIT,
    APPROVE,
    REJECT
}
