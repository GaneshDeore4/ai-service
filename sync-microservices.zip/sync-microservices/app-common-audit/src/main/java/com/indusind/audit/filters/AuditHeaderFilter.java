package com.indusind.audit.filters;

import com.indusind.audit.config.AuditContext;
import com.indusind.audit.enums.Action;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class AuditHeaderFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            String user = request.getHeader("X-USERNAME");
            String role = request.getHeader("X-ACTION-ROLE");

            System.out.println("user: " + user + " : " + role);

            AuditContext.set(
                    user,
                    role == null ? null : Action.valueOf(role.toUpperCase())
            );

            filterChain.doFilter(request, response);
        } catch (Exception e) {
            filterChain.doFilter(request, response);
        } finally {
            AuditContext.clear();
        }
    }

    @PostConstruct
    public void init() {
        System.out.println("✅ AuditHeaderFilter BEAN CREATED");
    }
}
