package com.indusind.audit.listeners;

import com.indusind.audit.config.AuditContext;
import com.indusind.audit.entity.Auditable;
import com.indusind.audit.enums.Action;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

import java.time.LocalDateTime;

public class MakerCheckerListener {

    @PrePersist
    public void onCreate(Object entity) {
        if (entity instanceof Auditable auditable) {
            if (AuditContext.getRole() == Action.CREATE) {
                auditable.setMakerName(AuditContext.getUser());
                auditable.setCreatedAt(LocalDateTime.now());
                auditable.setLastModifiedBy(AuditContext.getUser());
                auditable.setLastModifiedAt(LocalDateTime.now());
            }
        }
    }

    @PreUpdate
    public void onUpdate(Object entity) {
        if (entity instanceof Auditable auditable) {
            if (AuditContext.getRole() == Action.APPROVE) {
                auditable.setCheckerName(AuditContext.getUser());
                auditable.setApprovedAt(LocalDateTime.now());
                auditable.setLastModifiedBy(AuditContext.getUser());
                auditable.setLastModifiedAt(LocalDateTime.now());
            } else if(AuditContext.getRole() == Action.EDIT) {
                auditable.setEditorName(AuditContext.getUser());
                auditable.setEditedAt(LocalDateTime.now());
                auditable.setLastModifiedBy(AuditContext.getUser());
                auditable.setLastModifiedAt(LocalDateTime.now());
            } else if(AuditContext.getRole() == Action.REJECT) {
                auditable.setRejectedBy(AuditContext.getUser());
                auditable.setRejectedAt(LocalDateTime.now());
                auditable.setLastModifiedBy(AuditContext.getUser());
                auditable.setLastModifiedAt(LocalDateTime.now());
            }
        }
    }
}