package com.indusind.trade.model.common.enums;

public enum Role {
    SUPERADMIN,
    ADMIN,
    USER,
    MAKER,
    CHECKER,
    RELEASER,
    AUDITOR
}
