package com.indusind.trade.model.common.exception;

public class GTPAppException extends RuntimeException{
    public GTPAppException(String message, Throwable cause) {
        super(message, cause);
    }
}