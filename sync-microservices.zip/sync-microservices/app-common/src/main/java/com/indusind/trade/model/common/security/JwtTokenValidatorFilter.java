package com.indusind.trade.model.common.security;

import java.io.IOException;
import java.security.Key;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Shared JWT/Gateway validation filter for all microservices.
 *
 * <p>Two-path authentication:
 * <ul>
 *   <li><b>PATH A (Gateway-Trusted):</b> Reads X-Gateway-Secret header injected by API Gateway.
 *       If the secret matches, trusts X-User-Name and X-User-Roles headers — no JWT parsing.</li>
 *   <li><b>PATH B (Standalone/Direct):</b> Validates raw Bearer JWT when called without Gateway.
 *       Used for development/testing or service-to-service direct calls.</li>
 * </ul>
 * 
 * Usage in SecurityConfig:
 * <pre>
 *   http.addFilterBefore(
 *       new JwtTokenValidatorFilter(jwtSecret, gatewaySecret),
 *       UsernamePasswordAuthenticationFilter.class
 *   );
 * </pre>
 */
public class JwtTokenValidatorFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(JwtTokenValidatorFilter.class);

    private final String jwtSecret;
    private final String gatewaySecret;

    /**
     * @param jwtSecret     JWT signing secret — must match auth-service and gateway
     * @param gatewaySecret Internal gateway secret — must match gateway.internal.secret
     */
    public JwtTokenValidatorFilter(String jwtSecret, String gatewaySecret) {
        this.jwtSecret = jwtSecret;
        this.gatewaySecret = gatewaySecret;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        // ── PATH A: Gateway-Trusted Mode ─────────────────────────────────────────
        String incomingGatewaySecret = request.getHeader("X-Gateway-Secret");
        if (gatewaySecret != null && gatewaySecret.equals(incomingGatewaySecret)) {
            if (handleGatewayAuthentication(request)) {
                filterChain.doFilter(request, response);
                return;
            }
        }

        // ── PATH B: Standalone / Direct JWT Validation ────────────────────────────
        handleDirectJwtAuthentication(request);
        
        filterChain.doFilter(request, response);
    }

    private boolean handleGatewayAuthentication(HttpServletRequest request) {
        String loginId = request.getHeader("X-User-Name");
        String roles   = request.getHeader("X-User-Roles");

        if (loginId != null && roles != null) {
            List<SimpleGrantedAuthority> authorities = Arrays.stream(roles.split(","))
                    .map(String::trim)
                    .filter(r -> !r.isEmpty())
                    .map(r -> r.startsWith("ROLE_") ? r : "ROLE_" + r)
                    .map(SimpleGrantedAuthority::new)
                    .collect(Collectors.toList());

            UserPrincipal principal = new UserPrincipal(loginId, roles);
            UsernamePasswordAuthenticationToken auth =
                    new UsernamePasswordAuthenticationToken(principal, null, authorities);

            SecurityContextHolder.getContext().setAuthentication(auth);
            log.debug("Gateway-trusted auth set for user: {}, roles: {}", loginId, roles);
            return true;
        }
        return false;
    }

    private void handleDirectJwtAuthentication(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            return;
        }

        String token = header.substring(7);
        try {
            javax.crypto.SecretKey key = Keys.hmacShaKeyFor(io.jsonwebtoken.io.Decoders.BASE64.decode(jwtSecret));
            Claims claims = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            String loginId   = claims.get("loginId", String.class);
            String rolesStr  = claims.get("roles", String.class);

            if (rolesStr == null || rolesStr.isBlank()) {
                rolesStr = claims.get("role", String.class);
            }

            String sessionId    = claims.get("sessionId", String.class);
            Object companyIdObj = claims.get("companyId");
            Long   companyId    = companyIdObj != null ? ((Number) companyIdObj).longValue() : null;

            if (loginId != null && rolesStr != null) {
                request.setAttribute("currentLoginId",   loginId);
                request.setAttribute("currentRole",      rolesStr);
                request.setAttribute("currentSessionId", sessionId);
                request.setAttribute("currentCompanyId", companyId);

                MDC.put("loginId",   loginId);
                MDC.put("role",      rolesStr);
                MDC.put("sessionId", sessionId != null ? sessionId : "");

                String finalRolesStr = rolesStr;
                List<SimpleGrantedAuthority> authorities = Arrays.stream(rolesStr.split(","))
                        .map(String::trim)
                        .filter(r -> !r.isEmpty())
                        .map(r -> r.startsWith("ROLE_") ? r : "ROLE_" + r)
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());

                UserPrincipal principal = new UserPrincipal(loginId, rolesStr);
                UsernamePasswordAuthenticationToken auth =
                        new UsernamePasswordAuthenticationToken(principal, null, authorities);

                SecurityContextHolder.getContext().setAuthentication(auth);
                log.debug("JWT direct-auth set for user: {}, roles: {}", loginId, finalRolesStr);
            }
        } catch (Exception e) {
            log.warn("JWT validation failed for request [{}]: {}", request.getRequestURI(), e.getMessage());
            SecurityContextHolder.clearContext();
        }
    }
}
