# app-discovery-server

Repository under project **GIFTCITYINNOVATION** in workspace `transbnk`.
