// const mysql = require('mysql');
const express = require('express');
const bodyparser = require('body-parser');
// const https = require('https');
const http = require('http');
// const fs = require('fs');

var app = express();
const routes = require('./routes')
//Configuring express server
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());

// const sslOptions = {
//   key: fs.readFileSync('./ssl/private.key'),
//   cert: fs.readFileSync('./ssl/certificate.crt')
// };

var conn = require('./db/database')

global.__basedir = __dirname;

// const server = https.createServer(sslOptions, app);
const server = http.createServer(app);

const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`Listening on port ${port}..`));

app.get('/test', (req, res) => res.send('App is working'))

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PATCH, PUT, DELETE, OPTIONS"
  );
   next();
});




routes(app); //register the route



  