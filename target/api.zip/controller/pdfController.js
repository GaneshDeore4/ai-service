var pdfModel = require('../model/pdfModel')
var uploadFile = require('../services/upload')
exports.pdfList = async (req, res) => {
  try {
    pdfModel.pdfList(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      });
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.getFilterData = async (req, res) => {
  try {
    pdfModel.getFilterData(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      });
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.addPdf = async (req, res) => {
  try {
    await uploadFile(req, res);
    console.log(newfilename);
    req.body['fileName'] = req.file.originalname;
    req.body['file'] = newfilename;
    pdfModel.addPdf(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      })
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
    if (err.code == "LIMIT_FILE_SIZE") {
      return res.status(500).send({
        message: "File size cannot be larger than 2MB!",
      });
    }
    res.status(500).send({
        message: `Could not upload the file: ${req.file.originalname}. ${err}`,
    });
  }
}

exports.updatePdf = async (req, res) => {
  try {    
    await uploadFile(req, res);
    req.body['fileName'] = req.file.originalname;
    pdfModel.updatePdf(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      })
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.getPdfById = async (req, res) => {
  try {
    pdfModel.getPdfById(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      })
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.getPdfCount = async (req, res) => {
  try {
    pdfModel.getPdfCount(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      })
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.removePdf = async (req, res) => {
  try {
    pdfModel.removePdf(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      });
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.unlinkPdf = async (req, res) => {
  try {
    pdfModel.unlinkPdf(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      });
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}


// module.exports = {
//     userList
// }