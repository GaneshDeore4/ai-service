var userModel = require('../model/userModel')

exports.userList = async (req, res) => {
  try {
    userModel.userList(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      });
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.getAnnType = async (req, res) => {
  try {
    userModel.getAnnType(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      });
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.login = async (req, res) => {
  try {
    userModel.login(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      });
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.addUser = async (req, res) => {
  try {
    userModel.addUser(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      })
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.getUserById = async (req, res) => {
  try {
    userModel.getUserById(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      })
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}

exports.removeUser = async (req, res) => {
  try {
    userModel.removeUser(req, function (err, result) {
          if (err) {
              res.json({
                  "message": "failed",
                  "status": "0",
                  "data": null
              });
          } else {
              res.json({
                  "message": "success",
                  "status": "1",
                  "data": result
              });
          }
      });
  } catch(e) {
    console.log(e.message)
    res.sendStatus(500) && next(error)
  }
}


// module.exports = {
//     userList
// }