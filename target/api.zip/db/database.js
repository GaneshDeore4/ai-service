'user strict';

const mysql = require('mysql');

var conn = mysql.createConnection({
    // host: 'www.spectrum-india.com',
    host:'localhost',
    user: 'root',
    // password: 'Supp0rt@123',
    password: '',
    database: 'spectrum',
    multipleStatements: true
});

conn.connect((err)=> {
    if(err){
        console.log('Connection Failed!', err);
        return
    }
    console.log('Connection Established Successfully');
});

module.exports = conn;