var sql = require('../db/database')
const fs = require('fs');


exports.pdfList = function (req, result) {   
    let sqlQuery = "SELECT * FROM files_pdf order by id desc";
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });
};

exports.getFilterData = function (req, result) {   
    let sqlQuery = "SELECT * FROM files_pdf where fiscalYear='"+req.params.fiscalYear +"' and fileType ="+ req.params.fileType +" order by id desc";
    console.log(sqlQuery)
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });
};

exports.getPdfCount = function (req, result) {   
    let sqlQuery = "SELECT count(*) as count FROM `files_pdf`";
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });
};

exports.addPdf = function (req, result) {   
    let data = req.body;
    let sqlQuery = "INSERT INTO files_pdf SET ?";    
    sql.query(sqlQuery,data, function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });      
};

exports.updatePdf = function (req, result) {   
    let data = req.body;
    let sqlQuery = "UPDATE files_pdf SET ? WHERE id="+data.id
    let queryParam = { fileName:data.fileName, title:data.title }
    console.log(sqlQuery);   
    sql.query(sqlQuery, queryParam, function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }else{
            result(null, res);
        }
    });
};

exports.getPdfById = function (req, result) {   
    let sqlQuery = "SELECT * FROM files_pdf WHERE id=" + req.params.id;
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });      
};

exports.removePdf = function (req, result) {   
    let sqlQuery = "DELETE FROM files_pdf WHERE id="+req.params.id+"";
    sql.query(sqlQuery,function (err, res) {
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            // fs.unlink( "/var/www/html/assets/PDF/"+req.params.fileName, (err) => {
            fs.unlink( __basedir + "/PDF/"+req.params.fileName, (err) => {
                if (err) {            
                    console.log(err);
                    result(null, "Record deleted,.. PDF file not found");
                }    
                result(null, res);
            });
           
        }
    });     
}
    exports.unlinkPdf = function (req, result) {   
        fs.unlink( __basedir + "/PDF/"+req.params.fileName, (err) => {
            if (err) {            
                console.log(err);
                result(null, "Record deleted,.. PDF file not found");
            }    
            result(null, res);
        }); 
    };
