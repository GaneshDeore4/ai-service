var sql = require('../db/database')

exports.userList = function (req, result) {   
    let sqlQuery = "SELECT * FROM users";
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });
};

exports.getAnnType = function (req, result) {   
    let sqlQuery = "SELECT * FROM announcement where active_status = 0";
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });
};


exports.login = function (req, result) {   
    data = req.body;
    let sqlQuery = "SELECT * FROM user where username = '"+data.username+"' and password = '"+data.password+"'";
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });
};

exports.addUser = function (req, result) {   
    let data = req.body;    
    let sqlQuery = "INSERT INTO users SET ?";    
    sql.query(sqlQuery,data, function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });      
};

// exports.updateUser = function (req, result) {   
//     let sqlQuery = "SELECT * FROM users";
//     sql.query(sqlQuery,function (err, res) {
//         console.log(res);
//         if(err) {
//             console.log("error: ", err);
//             result(err, null);
//         }
//         else{
//             result(null, res);
//         }
//     });
//     conn.on('error', function(err) {
//         console.log("[mysql error]",err);
//     });          
// };

exports.getUserById = function (req, result) {   
    let sqlQuery = "SELECT * FROM users WHERE id=" + req.params.id;
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });      
};

exports.removeUser = function (req, result) {   
    let sqlQuery = "DELETE FROM users WHERE id="+req.params.id+"";
    sql.query(sqlQuery,function (err, res) {
        console.log(res);
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });        
};

