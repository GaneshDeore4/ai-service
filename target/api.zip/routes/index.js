
const appRouter = (app) => {

   var userRouter =  require('./userRoutes')
   var pdfRouter =  require('./pdfRoutes')
    
   userRouter(app);
   pdfRouter(app);
   
}

module.exports = appRouter
