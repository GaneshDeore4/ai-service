const userRouter = (app) => {
    var pdfController = require('../controller/pdfController')

    app.route('/api/getPdfFiles').get(pdfController.pdfList);

    app.route('/api/getFilterData/:fiscalYear/:fileType').get(pdfController.getFilterData);
 
    app.route('/api/addPdf').post(pdfController.addPdf);
    
    app.route('/api/updatePdf').post(pdfController.updatePdf);
 
    app.route('/api/getpdf/:id').get(pdfController.getPdfById);
 
    app.route('/api/removePdf/:id/:fileName').delete(pdfController.removePdf)
    
    app.route('/api/unlinkPdf/:fileName').delete(pdfController.unlinkPdf)

    app.route('/api/getPdfCount').get(pdfController.getPdfCount)
    
}

module.exports = userRouter