const userRouter = (app) => {
    var user = require('../controller/userController')


    app.route('/api/getUsers').get(user.userList);
 
    app.route('/api/login').post(user.login);

    app.route('/api/addUser').post(user.addUser);

    app.route('/api/getAnnType').get(user.getAnnType);
 
    app.route('/api/user/:id').get(user.getUserById);
 
    app.route('/api/removeUser/:id').delete(user.removeUser)

}

module.exports = userRouter