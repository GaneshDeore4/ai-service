const util = require("util");
const multer = require("multer");
// const maxSize = 2 * 1024 * 1024;

let storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // cb(null, "/var/www/html/assets/PDF/");
    cb(null, __basedir + "/PDF/");
    
  },
  filename: (req, file, cb) => {
    console.log(file);
    newfilename = "PDF"+Date.now()+".pdf"
    cb(null, newfilename);
  },
});

let uploadFile = multer({
  storage: storage,
//   limits: { fileSize: maxSize },
}).single("fileName");

let uploadFileMiddleware = util.promisify(uploadFile);
module.exports = uploadFileMiddleware;