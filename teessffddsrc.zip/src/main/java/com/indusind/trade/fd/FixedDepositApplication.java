package com.indusind.trade.fd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@EnableJpaRepositories({"com.indusind.trade.model.repository","com.indusind.trade.fd.repository"})
@EntityScan({"com.indusind.trade.model.entities", "com.indusind.trade.fd.entity"})
public class FixedDepositApplication {
    public static void main(String[] args) {
        SpringApplication.run(FixedDepositApplication.class, args);
    }
}
