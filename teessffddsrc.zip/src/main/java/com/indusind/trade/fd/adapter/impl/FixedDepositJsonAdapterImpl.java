package com.indusind.trade.fd.adapter.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.EncDec.EncDecUtil;
import com.indusind.trade.fd.adapter.FixedDepositJsonAdapter;
import com.indusind.trade.fd.client.BankJsonFeignClient;
import com.indusind.trade.fd.dto.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class FixedDepositJsonAdapterImpl implements FixedDepositJsonAdapter {


    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;
    
    private final BankJsonFeignClient bankJsonFeignClient;

    @Override
    public AccountDetailsResponse fetchAccountDetails(String acid, CommonRequest common) {
        log.info("Fetching account details for ACID: {}", acid);
        Map<String, Object> request = mapToMap(common);
        request.put("acid", acid);

        try {
             return bankJsonFeignClient.getAccountDetailsLcr(request);
//            return getDummyAccountDetails(acid);
        } catch (Exception e) {
            log.error("Error fetching account details: {}", e.getMessage());
            return getDummyAccountDetails(acid);
        }
    }


    @Override
    public FDInterestRatesRespDto calculateFdModel(FDInterestRatesReqDto request) {
        log.info("Calculating FD model for amount: {}", request.getAmountValue());
        
        ExternalFDModelDTOs.FDModelDepositRequest bodyRequest = ExternalFDModelDTOs.FDModelDepositRequest.builder()
                .depositAmount(request.getAmountValue())
                .depositPeriodDays(request.getDays() != null ? request.getDays() : "0")
                .depositPeriodMonths(request.getMonths() != null ? request.getMonths() : "0")
                .depositDate(request.getDepositDate().toString() + "Z")
                .depositcurrencyCode(request.getCurrencyCode())
                .currencyCode(request.getCurrencyCode())
                .schmCode("FEIBU") // Working code provided by user
                .interestTableCode("TGINT") // Working code provided by user
                .daysInAYear("365")
                .monthsInYear("12")
                .flowType("N")
                .pegFlag("Y")
                .depositType("T")
                .schmType("TDA")
                .build();

        ExternalFDModelDTOs.RequestWrapper wrapper = ExternalFDModelDTOs.RequestWrapper.builder()
                .request(ExternalFDModelDTOs.RequestContent.builder()
                        .header(ExternalFDModelDTOs.RequestHeader.builder()
                                .requestUUID(java.util.UUID.randomUUID().toString())
                                .channelId("GCT")
                                .build())
                        .body(ExternalFDModelDTOs.RequestBody.builder()
                                .fdModelDepositRequest(bodyRequest)
                                .build())
                        .build())
                .build();

        EncDecUtil encDecUtil = new EncDecUtil();
        ObjectMapper objectMapper = new ObjectMapper();

        try {

            String requestJson= objectMapper.writeValueAsString(wrapper);
            String encryptedPayload= encDecUtil.getEncyption(requestJson,"UAT");

            JsonNode rootNode= objectMapper.readTree(encryptedPayload);
            JsonNode requstNode= rootNode.get("request");

            String jsonRequestStr= objectMapper.writeValueAsString(requstNode);

            String decryptionKey= rootNode.get("key").asText();

           // ExternalFDModelDTOs.ResponseWrapper response = bankJsonFeignClient.getDepositModel(clientId, clientSecret, wrapper);

            String encResponse =bankJsonFeignClient.getDepositModel(clientId, clientSecret, jsonRequestStr);
            JsonNode responserootNode = objectMapper.readTree(encResponse);
            String responseDataObj=responserootNode.get("data").asText();
            String decryptedRes=encDecUtil.getDecryption(responseDataObj,decryptionKey);
            ExternalFDModelDTOs.ResponseWrapper response = objectMapper.readValue(decryptedRes, ExternalFDModelDTOs.ResponseWrapper.class);

            if (response != null && response.getResponse() != null && response.getResponse().getBody() != null) {
                ExternalFDModelDTOs.FDModelDepositResponse bankResp = response.getResponse().getBody().getFdModelDepositResponse();
                
                return FDInterestRatesRespDto.builder()
                        .status("SUCCESS")
                        .interestRate(bankResp.getInterestRate())
                        .maturityAmount(bankResp.getMaturityAmt())
                        .interestAmount(bankResp.getInterestAmount())
                        .currency(bankResp.getCurrencyCode())
                        .maturityDate(parseBankDate(bankResp.getMaturityDate()))
                        .build();
            }
        } catch (Exception e) {
            log.error("Error calculating FD model: {}", e.getMessage());

        }
        
        return FDInterestRatesRespDto.builder().status("FAILURE").build();
    }

    private java.time.LocalDate parseBankDate(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return null;
        try {
            // Handles format like 2027-08-25
            if (dateStr.contains("-")) {
                return java.time.LocalDate.parse(dateStr.substring(0, 10));
            }
            // Handles format like 25/08/2027
            if (dateStr.contains("/")) {
                java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
                return java.time.LocalDate.parse(dateStr, formatter);
            }
        } catch (Exception e) {
            log.warn("Failed to parse bank date: {}", dateStr);
        }
        return null;
    }


    @Override
    public Object createFd(Map<String, Object> request) {
        log.info("Creating FD (td-add-account)");
        // Dummy implementation for now
        Map<String, String> response = new HashMap<>();
        response.put("responseCode", "00");
        response.put("responseDesc", "Fixed Deposit Created Successfully");
        return response;
    }

    private Map<String, Object> mapToMap(CommonRequest common) {
        Map<String, Object> map = new HashMap<>();
        map.put("appType", common.getAppType());
        map.put("appVersion", common.getAppVersion());
        map.put("authProduct", common.getAuthProduct());
        map.put("com_ImeiNo", common.getCom_ImeiNo());
        map.put("customerId", common.getCustomerId());
        map.put("deviceId", common.getDeviceId());
        map.put("deviceModel", common.getDeviceModel());
        map.put("deviceName", common.getDeviceName());
        map.put("deviceOS", common.getDeviceOS());
        map.put("deviceType", common.getDeviceType());
        map.put("isUsrLoggedIn", common.getIsUsrLoggedIn());
        map.put("platform", common.getPlatform());
        map.put("requestType", common.getRequestType());
        map.put("token", common.getToken());
        map.put("userCode", common.getUserCode());
        map.put("userId", common.getUserId());
        map.put("userRole", common.getUserRole());
        return map;
    }

    private AccountDetailsResponse getDummyAccountDetails(String acid) {
        AccountDetailsResponse resp = new AccountDetailsResponse();
        resp.setResponseCode("R000");
        resp.setResponseDesc("Success");
        resp.setListAcno(new ArrayList<>());

        AccountDetailsResponse.MappedAccount acc = new AccountDetailsResponse.MappedAccount();
        acc.setAcctName("XYZ Limited - MOCKED");
        acc.setAcno(acid);
        acc.setIsMapped("1");
        resp.getListAcno().add(acc);
        return resp;
    }

    private FdModelResponse getDummyFdModel() {
        FdModelResponse resp = new FdModelResponse();
        resp.setStatus("SUCCESS");
        resp.setInterestRates("6.75");
        return resp;
    }

    private OtpResponse getDummyOtpResponse() {
        OtpResponse resp = new OtpResponse();
        resp.setErrorCode("00");
        resp.setOtpHint("1189");
        resp.setSentTo("878882XXXX");
        resp.setAction("STATE_ID_MOCKED_123456");
        return resp;
    }

    private OtpVerifyResponse getDummyOtpVerifyResponse() {
        OtpVerifyResponse resp = new OtpVerifyResponse();
        resp.setResponseCode("00");
        resp.setResponseDesc("Otp Verified Successfully");
        return resp;
    }

    @Override
    public FdSummaryResponse fetchFdSummary(FdSummaryRequest request) {
        log.info("Fetching FD summary via JSON (Dummy) for CIF: {}", request.getCifId());
        return FdSummaryResponse.builder()
                .responseCode("00")
                .responseDesc("Success (MOCK)")
                .fdDetails(new ArrayList<>())
                .build();
    }
}
