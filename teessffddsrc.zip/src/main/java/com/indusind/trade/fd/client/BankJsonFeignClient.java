package com.indusind.trade.fd.client;

import com.indusind.trade.fd.dto.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "bank-json-client", url = "${app.bank.api.json.url}")
public interface BankJsonFeignClient {

    @PostMapping("/soap-service/core-banking//get-account-details-lcr")
    AccountDetailsResponse getAccountDetailsLcr(@RequestBody Map<String, Object> request);

  /*  @PostMapping("/cbs/v25/fd-servicing/fdmodeldeposit/V2")
    ExternalFDModelDTOs.ResponseWrapper getDepositModel(
    		@RequestHeader("IBL-Client-ID") String clientId,
    	    @RequestHeader("IBL-Client-Secret") String clientSecret,
    		@RequestBody ExternalFDModelDTOs.RequestWrapper request);*/

    @PostMapping("/cbs/v25/fd-servicing/fdmodeldeposit/V2")
    String getDepositModel(
            @RequestHeader("IBL-Client-ID") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody String request);

    @PostMapping("/us-mgmt/generateverifyotp")
    OtpResponse generateOtp(@RequestBody Map<String, Object> request);

    @PostMapping("/us-mgmt/verifyotp")
    OtpVerifyResponse verifyOtp(@RequestBody Map<String, Object> request);
    
}
