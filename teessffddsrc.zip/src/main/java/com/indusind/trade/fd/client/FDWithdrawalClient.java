package com.indusind.trade.fd.client;

import com.indusind.trade.fd.dto.FDWithdrawalRequest;
import com.indusind.trade.fd.dto.FDWithdrawalResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "fd-withdrawal-client", url = "${app.fd.close.url}")
public interface FDWithdrawalClient {


    @PostMapping(value="/fd-servicing/fdfullwithdrawl/V2",

            headers = {
                    "Content-Type=application/json",
                    "Accept=application/json"
            }

    )
    FDWithdrawalResponse fullWithdrawal(
            @RequestHeader("IBL-Client-Id") String clientID,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody FDWithdrawalRequest request);

}