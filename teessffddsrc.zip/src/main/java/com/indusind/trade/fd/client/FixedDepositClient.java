package com.indusind.trade.fd.client;

import com.indusind.trade.fd.dto.request_wrapper.RequestWrapper;
import com.indusind.trade.fd.dto.response_wrapper.ResponseWrapper;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "fdClient", url="${app.bank.api.json.url}")
public interface FixedDepositClient {

//    @PostMapping("/cbs/v25/fdbooking-servicing/fdbooking/V1")
//    ResponseWrapper createFD(
//    	    @RequestHeader("IBL-Client-ID") String clientId,
//    	    @RequestHeader("IBL-Client-Secret") String clientSecret,
//    		@RequestBody RequestWrapper request
//    	);

    
    @PostMapping(value = "/cbs/v25/fdbooking-servicing/fdbooking/V1", consumes = "application/json", produces = "application/json")
    String createFD(@RequestHeader("IBL-Client-ID") String clientId, 
                    @RequestHeader("IBL-Client-Secret") String clientSecret, 
                    @RequestBody String rawJsonRequest);
    
}
