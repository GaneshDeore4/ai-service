package com.indusind.trade.fd.client;

import com.indusind.trade.fd.dto.ExternalFDModelDTOs;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "indus-fd-v2-client", url = "${app.bank.api.json.url}")
public interface IndusIndV2FeignClient {

    @PostMapping("/cbs/v25/fd-servicing/fdmodeldeposit/V2")
    ExternalFDModelDTOs.ResponseWrapper getDepositModelV2(
        @RequestBody ExternalFDModelDTOs.RequestWrapper request,
        @RequestHeader("IBL-Client-ID") String clientId,
        @RequestHeader("IBL-Client-Secret") String clientSecret
    );
}
