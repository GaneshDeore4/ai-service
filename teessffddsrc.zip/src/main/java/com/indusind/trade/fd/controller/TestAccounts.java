package com.indusind.trade.fd.controller;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;

public class TestAccounts {

    private static void trustAllSSL() throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                }
        };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
    }

    public static void main(String[] args) throws Exception {
        trustAllSSL(); // Allow untrusted SSL for UAT

        String url = "https://coreuatj2ee2.ibl.com:50000/fiwebservice/services/FIPWebService";

        String soapXml =
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                        + "xmlns:web=\"https://webservice.fiusb.ci.infosys.com\">"
                        + "<soapenv:Header/>"
                        + "<soapenv:Body>"
                        + "<web:executeService>"
                        + "<arg_0_0><![CDATA[ " +
                        "<FIXML xsi:schemaLocation=\"http://www.finacle.com/fixml executeFinacleScript.xsd\" xmlns=\"http://www.finacle.com/fixml\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><Header><RequestHeader><MessageKey><RequestUUID>Req_35133028</RequestUUID><ServiceRequestId>executeFinacleScript</ServiceRequestId><ServiceRequestVersion>10.2</ServiceRequestVersion><ChannelId>COR</ChannelId><LanguageId></LanguageId></MessageKey><RequestMessageInfo><BankId></BankId><TimeZone></TimeZone><EntityId></EntityId><EntityType></EntityType><ArmCorrelationId></ArmCorrelationId><MessageDateTime>2025-07-010T10:42:00.420</MessageDateTime></RequestMessageInfo><Security><Token><PasswordToken><UserId></UserId><Password></Password></PasswordToken>\n"+
                        "</Token><FICertToken></FICertToken><RealUserLoginSessionId></RealUserLoginSessionId><RealUser></RealUser><RealUserPwd></RealUserPwd><SSOTransferToken></SSOTransferToken></Security>\n" +
                        "</RequestHeader>\n" +
                        "</Header><Body><executeFinacleScriptRequest><ExecuteFinacleScriptInputVO><requestId>IBL0210CIFINQ.scr</requestId></ExecuteFinacleScriptInputVO><executeFinacleScript_CustomData><CIF_ID>35133028</CIF_ID></executeFinacleScript_CustomData>\n" +
                        "</executeFinacleScriptRequest>\n" +
                        "</Body>\n" +
                        "</FIXML> ]]></arg_0_0>"
                        + "</web:executeService>"
                        + "</soapenv:Body>"
                        + "</soapenv:Envelope>";

        // Send POST Request
        URL endpoint = new URL(url);
        HttpsURLConnection conn = (HttpsURLConnection) endpoint.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
        conn.setDoOutput(true);

        // Write SOAP XML
        OutputStream os = conn.getOutputStream();
        os.write(soapXml.getBytes());
        os.flush();

        // Read Response
        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn.getInputStream())));

        String line;
        System.out.println("\n=== SOAP Response ===");
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }

        conn.disconnect();
    }
}