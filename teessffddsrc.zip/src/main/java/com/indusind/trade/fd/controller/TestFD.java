package com.indusind.trade.fd.controller;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;

public class TestFD {

    // ------- Trust all SSL certificates (ONLY for UAT testing) -------
    private static void trustAllSSL() throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                }
        };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
    }

    public static void main(String[] args) throws Exception {
        trustAllSSL(); // Allow untrusted SSL for UAT

        String url = "https://coreuatj2ee2.ibl.com:50000/fiwebservice/services/FIPWebService";

        String soapXml =
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                        + "xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">"
                        + "<soapenv:Header/>"
                        + "<soapenv:Body>"
                        + "<web:executeService>"
                        + "<arg_0_0><![CDATA["
                        + "<FIXML xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\n" +
                        "       xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                        "       xmlns=\"http://www.finacle.com/fixml\">\n" +
                        "\n" +
                        "  <Header>\n" +
                        "    <RequestHeader>\n" +
                        "\n" +
                        "      <MessageKey>\n" +
                        "        <RequestUUID>IDTFD_187t3550063</RequestUUID>\n" +
                        "        <ServiceRequestId>TDAcctAdd</ServiceRequestId>\n" +
                        "        <ServiceRequestVersion>10.2</ServiceRequestVersion>\n" +
                        "        <ChannelId>IDC</ChannelId>\n" +
                        "        <LanguageId/>\n" +
                        "      </MessageKey>\n" +
                        "\n" +
                        "      <RequestMessageInfo>\n" +
                        "        <BankId/>\n" +
                        "        <TimeZone/>\n" +
                        "        <EntityId/>\n" +
                        "        <EntityType/>\n" +
                        "        <ArmCorrelationId/>\n" +
                        "        <MessageDateTime>2020-02-11T18:35:50.063</MessageDateTime>\n" +
                        "      </RequestMessageInfo>\n" +
                        "\n" +
                        "      <Security>\n" +
                        "        <Token>\n" +
                        "          <PasswordToken>\n" +
                        "            <UserId/>\n" +
                        "            <Password/>\n" +
                        "          </PasswordToken>\n" +
                        "        </Token>\n" +
                        "        <FICertToken/>\n" +
                        "        <RealUserLoginSessionId/>\n" +
                        "        <RealUser/>\n" +
                        "        <RealUserPwd/>\n" +
                        "        <SSOTransferToken/>\n" +
                        "      </Security>\n" +
                        "\n" +
                        "    </RequestHeader>\n" +
                        "  </Header>\n" +
                        "\n" +
                        "  <Body>\n" +
                        "\n" +
                        "    <TDAcctAddRequest>\n" +
                        "      <TDAcctAddRq>\n" +
                        "\n" +
                        "        <CustId>\n" +
                        "          <CustId>35133028</CustId>\n" +
                        "        </CustId>\n" +
                        "\n" +
                        "        <TDAcctId>\n" +
                        "          <AcctType>\n" +
                        "            <AcctId>255678899999</AcctId>\n" +
                        "            <SchmCode>TRGEN</SchmCode>\n" +
                        "          </AcctType>\n" +
                        "          <AcctCurr>INR</AcctCurr>\n" +
                        "        </TDAcctId>\n" +
                        "\n" +
                        "        <TDAcctGenInfo>\n" +
                        "          <GenLedgerSubHead>\n" +
                        "            <GenLedgerSubHeadCode/>\n" +
                        "            <CurCode>INR</CurCode>\n" +
                        "          </GenLedgerSubHead>\n" +
                        "          <ModeOfOper>13</ModeOfOper>\n" +
                        "          <AcctName>NITIN TIWARI</AcctName>\n" +
                        "          <AcctShortName>NITIN TIWA</AcctShortName>\n" +
                        "          <AcctStmtMode>N</AcctStmtMode>\n" +
                        "          <DespatchMode>N</DespatchMode>\n" +
                        "        </TDAcctGenInfo>\n" +
                        "\n" +
                        "        <InitialDeposit>\n" +
                        "          <amountValue>500</amountValue>\n" +
                        "          <currencyCode>INR</currencyCode>\n" +
                        "        </InitialDeposit>\n" +
                        "\n" +
                        "        <DepositTerm>\n" +
                        "          <Days>0</Days>\n" +
                        "          <Months>65</Months>\n" +
                        "        </DepositTerm>\n" +
                        "\n" +
                        "        <RepayAcctId>\n" +
                        "          <AcctId>255678899999</AcctId>\n" +
                        "          <AcctCurr/>\n" +
                        "        </RepayAcctId>\n" +
                        "\n" +
                        "        <TrnDtls>\n" +
                        "          <TrnType>T</TrnType>\n" +
                        "          <TrnSubType>CI</TrnSubType>\n" +
                        "\n" +
                        "          <DebitAcctId>\n" +
                        "            <AcctId>255678899999</AcctId>\n" +
                        "            <AcctType>\n" +
                        "              <SchmCode>TRGEN</SchmCode>\n" +
                        "              <SchmType>TDA</SchmType>\n" +
                        "            </AcctType>\n" +
                        "            <AcctCurr>INR</AcctCurr>\n" +
                        "            <BankInfo>\n" +
                        "              <BankId>01</BankId>\n" +
                        "            </BankInfo>\n" +
                        "          </DebitAcctId>\n" +
                        "        </TrnDtls>\n" +
                        "\n" +
                        "        <TDAcctAdd_CustomData>\n" +
                        "          <SOLID>0022</SOLID>\n" +
                        "          <XFERINDCODE>O</XFERINDCODE>\n" +
                        "          <TRANCREMODE>O</TRANCREMODE>\n" +
                        "          <FREETEXT15/>\n" +
                        "          <MODEOFOPER>13</MODEOFOPER>\n" +
                        "          <OUTFLOWMULTAMT>0</OUTFLOWMULTAMT>\n" +
                        "          <INTTBLCD>TBGEN</INTTBLCD>\n" +
                        "          <FREECODE8/>\n" +
                        "          <MISCFLG>1</MISCFLG>\n" +
                        "        </TDAcctAdd_CustomData>\n" +
                        "\n" +
                        "        <RenewalDtls>\n" +
                        "          <IntTblCode>TBGEN</IntTblCode>\n" +
                        "          <AutoCloseOnMaturityFlg>Y</AutoCloseOnMaturityFlg>\n" +
                        "          <AutoRenewalflg>N</AutoRenewalflg>\n" +
                        "        </RenewalDtls>\n" +
                        "\n" +
                        "      </TDAcctAddRq>\n" +
                        "    </TDAcctAddRequest>\n" +
                        "\n" +
                        "  </Body>\n" +
                        "</FIXML>"
                        + "]]></arg_0_0>"
                        + "</web:executeService>"
                        + "</soapenv:Body>"
                        + "</soapenv:Envelope>";

        // Send POST Request
        URL endpoint = new URL(url);
        HttpsURLConnection conn = (HttpsURLConnection) endpoint.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
        conn.setDoOutput(true);

        // Write SOAP XML
        OutputStream os = conn.getOutputStream();
        os.write(soapXml.getBytes());
        os.flush();

        // Read Response
        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn.getInputStream())));

        String line;
        System.out.println("\n=== SOAP Response ===");
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }

        conn.disconnect();
    }
}