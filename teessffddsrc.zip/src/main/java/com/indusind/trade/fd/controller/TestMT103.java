package com.indusind.trade.fd.controller;

import javax.net.ssl.*;
import java.io.*;
import java.net.URL;

public class TestMT103 {

    // ------- Trust all SSL certificates (ONLY for UAT testing) -------
    private static void trustAllSSL() throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                }
        };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
    }

    public static void main(String[] args) throws Exception {
        trustAllSSL(); // Allow untrusted SSL for UAT

        String url = "http://10.24.114.212:9080/ConnectOnlineTrade/api/webcommon/getNotification";

        String soapXml =
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                        + "xmlns:web=\"http://webservice.fiusb.ci.infosys.com\">"
                        + "<soapenv:Header/>"
                        + "<soapenv:Body>"
                        + "<web:executeService>"
                        + "<arg_0_0><![CDATA["
                        + "<notification>\n" +
                        "<header>\n" +
                        "<notification_type>MTP_NOTIFY</notification_type>\n" +
                        "<event_code>01</event_code>\n" +
                        "<source_system_id>ITRAC</source_system_id>\n" +
                        "</header>\n" +
                        "<data>\n" +
                        "<item id='message'>Data Push Successful</item>\n" +
                        "</data>\n" +
                        "</notification>"
                        + "]]></arg_0_0>"
                        + "</web:executeService>"
                        + "</soapenv:Body>"
                        + "</soapenv:Envelope>";

        // Send POST Request
        URL endpoint = new URL(url);
        HttpsURLConnection conn = (HttpsURLConnection) endpoint.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
        conn.setDoOutput(true);

        // Write SOAP XML
        OutputStream os = conn.getOutputStream();
        os.write(soapXml.getBytes());
        os.flush();

        // Read Response
        BufferedReader br = new BufferedReader(new InputStreamReader(
                (conn.getInputStream())));

        String line;
        System.out.println("\n=== MT103 Response ===");
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }

        conn.disconnect();
    }
}
