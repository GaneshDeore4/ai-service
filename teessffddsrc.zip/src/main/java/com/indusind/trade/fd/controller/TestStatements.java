package com.indusind.trade.fd.controller;
import javax.net.ssl.*;
import java.io.*;
import java.net.URL;

public class TestStatements {

    private static void trustAllSSL() throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { return null; }
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {}
                }
        };

        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
    }

    public static void main(String[] args) {
        try {
            trustAllSSL();
            String urlStr = "https://cbsuatdc-daapi.indusind.com:20387/api/da/accounts/256001000004/statement"
                    + "?fromDate=2025-01-01"
                    + "&toDate=2025-09-22"
                    + "&limit=100000"
                    + "&continue=%7B%22tranDate%22:%222025-05-18%22,"
                    + "%22pstdDate%22:%222025-05-18T16:36:37%22,"
                    + "%22tranId%22:%22S89649276%22,"
                    + "%22partTranSrlNum%22:%22%22%7D";

            URL url = new URL(urlStr);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("finacle-internal-client", "true");
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(20000);

            int responseCode = conn.getResponseCode();
            System.out.println("HTTP Response Code: " + responseCode);

            // Read response stream
            BufferedReader br;
            if (responseCode >= 200 && responseCode < 300) {
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            } else {
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            }

            System.out.println("\n=== API RESPONSE ===");
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }

            conn.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}