package com.indusind.trade.fd.dto;

import com.indusind.trade.fd.projection.CheckerTrayProjection;
import jakarta.persistence.Column;
import lombok.*;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Bean;

import java.time.LocalDate;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CheckerFDTrayDTO {

    private Long fdId;

    private String status;

    private String fdStatus;

    private Integer currentLevel;

    private String accountNumber;

    private Double amount;

    private String currency;

    private Integer tenureMonths;

    private String maturityInstruction;

    private Double maturityAmount;

    private LocalDate maturityDate;

    private Integer tenureYears;

    private Integer tenureDays;

    private Double interestRate;

    public static CheckerFDTrayDTO convertToDto(CheckerTrayProjection checkerTrayProjection) {
        CheckerFDTrayDTO checkerFDTrayDTO = new CheckerFDTrayDTO();
        BeanUtils.copyProperties(checkerTrayProjection, checkerFDTrayDTO);
        return checkerFDTrayDTO;

    }

}
