package com.indusind.trade.fd.dto;

import com.indusind.trade.fd.entity.CloseFixedDeposit;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.enums.FDStatus;
import lombok.*;
import org.springframework.beans.BeanUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CloseFDDto {

    private Long id;

    private String cifId;
    private String loginId;
    private String fdAccountNumber;

    private double amount;
    private String currency;

    private String repaymentAccount;
    private String interestFrequency;

    private BigDecimal interestRate;
    private BigDecimal interestAmount;

    private String maturityInstruction;
    private BigDecimal maturityAmount;
    private LocalDate maturityDate;

    private Integer tenureDays;
    private Integer tenureMonths;
    private Integer tenureYears;

    private String userId;
    private String stateId;
    private FDStatus status;

    private Long authMatrixId;
    private Integer currentLevel;
    private Long makerId;

    private Long version;

    private Boolean isMidOfficeApproved;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long productId;
    private Long subProductId;

    public static CloseFixedDeposit convertToEntity(CloseFDDto fdReq) {
        CloseFixedDeposit fd = new CloseFixedDeposit();
        BeanUtils.copyProperties(fdReq, fd);
        fd.setId(null);
        return fd;
    }

    public static CloseFDDto convertToDto(CloseFDDto fd) {
        CloseFDDto fdDto = new CloseFDDto();
        BeanUtils.copyProperties(fd, fdDto);

        return fdDto;
    }

}

