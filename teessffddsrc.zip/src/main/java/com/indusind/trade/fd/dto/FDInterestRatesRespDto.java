package com.indusind.trade.fd.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FDInterestRatesRespDto {

    private String status;
    private String interestRate;
    private String maturityAmount;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDate maturityDate;
    private String interestAmount;
    private String currency;
    private String errorCode;
    private String errorMessage;

}
