package com.indusind.trade.fd.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.indusind.trade.fd.enums.FDFinacleStatus;
import com.indusind.trade.fd.enums.FDStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "fixed_deposits")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FixedDeposit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cif_id")
    private String cifId;

    @Column(name = "account_number")
    private String accountNumber;

    @Column(name = "amount")
    private Double amount;

    @Column(name = "currency")
    private String currency;

    @Column(name = "tenure_months")
    private Integer tenureMonths;

    @Column(name = "interest_rate")
    private Double interestRate;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "login_id")
    private String loginId;

    @Column(name = "terms_accepted")
    private Boolean termsAccepted;

    @Column(name = "interest_frequency")
    private String interestFrequency;

    @Column(name = "maturity_instruction")
    private String maturityInstruction;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "tenure_days")
    private Integer tenureDays;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private FDStatus status;

    @Column(name = "finacle_status")
    @Enumerated(EnumType.STRING)
    private FDFinacleStatus finacleStatus;

    @Column(name = "state_id")
    private String stateId;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "maturity_amount")
    private Double maturityAmount;

    @Column(name = "maturity_date")
    private LocalDate maturityDate;

    @Column(name = "interest_amount")
    private  Double interestAmount ;

    private Long authMatrixId;

    private Integer currentLevel;

    private String rejectReason;

    private Long makerId;

    private Boolean isMidOfficeApproved = false;

    @Version
    private Long version;
}
