package com.indusind.trade.fd.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "fixed_deposit_audits")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FixedDepositAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cif_id")
    private String cifId;

    @Column(name = "action")
    private String action; // OTP_GENERATE, OTP_VERIFY, FD_CREATE, FD_CALCULATE

    @Column(name = "details", length = 2000)
    private String details;

    @Column(name = "status")
    private String status; // SUCCESS, FAILURE

    @Column(name = "updated_by")
    private String updatedBy;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
}
