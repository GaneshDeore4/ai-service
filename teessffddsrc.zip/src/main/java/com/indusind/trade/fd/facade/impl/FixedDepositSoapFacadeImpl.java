package com.indusind.trade.fd.facade.impl;

import com.indusind.trade.fd.dto.ApplicationResponse;
import com.indusind.trade.fd.dto.FDInterestRatesReqDto;
import com.indusind.trade.fd.dto.FDInterestRatesRespDto;
import com.indusind.trade.fd.dto.FixedDepositDto;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.facade.FixedDepositFacade;
import com.indusind.trade.fd.service.CoreBankingBackendService;
import com.indusind.trade.fd.service.FDAuditService;
import com.indusind.trade.fd.service.FixedDepositService;
import com.indusind.trade.fd.service.SoapTransformationService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@ConditionalOnProperty(name = "app.fd.adapter.type", havingValue = "soap")
@RequiredArgsConstructor
public class FixedDepositSoapFacadeImpl implements FixedDepositFacade {

    private final SoapTransformationService soapTransformationService;
    private final CoreBankingBackendService coreBankingBackendService;
    private final FDAuditService fdAuditService;
    private final FixedDepositService fixedDepositService;

    @Override
    public FDInterestRatesRespDto calculateFDInterest(FDInterestRatesReqDto fdInterestRatesReqDto) {
        try {
            String soapReq = soapTransformationService.convertFDInterestRatesReqToSoap(fdInterestRatesReqDto);
            String soapResp = coreBankingBackendService.callCalculateFDIntgerestSoap(soapReq);
            FDInterestRatesRespDto resp = soapTransformationService.parseFDInterestRatesRespToJson(soapResp);
            fdAuditService.saveAudit(fdInterestRatesReqDto.getCifId(), "FD_INETEREST_RATE", "Fetched Interest Rate for CIF: " + fdInterestRatesReqDto.getCifId(),
                    "00".equals(resp.getStatus()) ? "SUCCESS" : "FAILURE", "SYSTEM");
            return resp;

        } catch (Exception e) {
            return FDInterestRatesRespDto.builder()
                    .status("FAILURE")
                    .errorMessage(e.getMessage())
                    .build();
        }
    }

    @Override
    @Transactional
    public ApplicationResponse createFD(FixedDepositDto request) {

        FixedDeposit fd = FixedDepositDto.convertToEntity(request);

        FixedDeposit savedFd = fixedDepositService.saveFixedDeposit(fd);

        fdAuditService.saveAudit(savedFd.getCifId(), "FD_CREATE", "", "", savedFd.getUserId());

        return new ApplicationResponse("SUCCESS", FixedDepositDto.convertToDto(savedFd), "FD created");
    }
}
