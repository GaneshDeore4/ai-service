package com.indusind.trade.fd.projection;

import com.indusind.trade.fd.enums.FDStatus;
import com.indusind.trade.model.entities.company.Account;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public interface CheckerTrayProjection {

    Long getFdId();

    String getStatus();

    String getFdStatus();

    Integer getCurrentLevel();

    String getAccountNumber();

    Double getAmount();

    String getCurrency();

    Integer getTenureMonths();

    String getMaturityInstruction();

    Double getMaturityAmount();

    LocalDate getMaturityDate();


    Integer getTenureYears();

    Integer getTenureDays();

    Double getInterestRate();


}
