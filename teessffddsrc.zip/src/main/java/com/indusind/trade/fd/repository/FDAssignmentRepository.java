package com.indusind.trade.fd.repository;

import com.indusind.trade.fd.entity.FDAssignment;
import com.indusind.trade.fd.enums.AssignmentStatus;
import com.indusind.trade.fd.projection.CheckerTrayProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FDAssignmentRepository extends JpaRepository<FDAssignment, Long> {

    List<FDAssignment> findByFdId(Long fdId);

    @Query("SELECT a FROM FDAssignment a WHERE a.fdId = :fdId AND a.groupId = :groupId AND a.isActive = true")
    List<FDAssignment> findActiveAssignment(Long fdId, Long groupId);

    @Query("""
            SELECT 
            f.id as fdId,
             
            CASE 
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'APPROVED'
                ) THEN 'APPROVED'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'PENDING'
                    AND a.isActive = true
                ) THEN 'PENDING'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'WAITING'
                ) THEN 'WAITING'
             
                WHEN EXISTS (
                    SELECT 1 FROM FDAssignment a
                    WHERE a.fdId = f.id
                    AND a.groupId = :groupId
                    AND a.status = 'REJECTED'
                ) THEN 'REJECTED'
             
                ELSE 'VIEW ONLY'
            END as status,
             
            f.status as fdStatus,
            f.currentLevel as currentLevel,
            f.accountNumber as accountNumber,
            f.amount as amount,
            f.currency as currency,
            f.tenureMonths as tenureMonths,
            f.maturityInstruction as maturityInstruction,
            f.maturityAmount as maturityAmount,
            f.maturityDate as maturityDate,
            f.tenureYears as tenureYears,
            f.tenureDays as tenureDays,
            f.interestRate as interestRate
             
            FROM FixedDeposit f
             
            WHERE EXISTS (
                SELECT 1 FROM FDAssignment a
                WHERE a.fdId = f.id
                AND a.groupId = :groupId
            )
             
            AND f.accountNumber IN (
                SELECT acc.accountNumber
                FROM User u
                JOIN u.accountMapping acc
                WHERE u.userId = :userId
            )
            """)
    Page<CheckerTrayProjection> findCheckerTray(
            Long userId,
            Long groupId,
            Pageable pageable
    );

    @Query(value = """
            SELECT 
                combined.id AS fdId,
                (CASE 
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.group_id = :groupId AND a.status = 'APPROVED') THEN 'APPROVED'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.group_id = :groupId AND a.status = 'PENDING' AND a.is_active = true) THEN 'PENDING'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.group_id = :groupId AND a.status = 'WAITING') THEN 'WAITING'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.group_id = :groupId AND a.status = 'REJECTED') THEN 'REJECTED'
                    ELSE 'VIEW ONLY'
                END) AS status,
                combined.status AS fdStatus,
                combined.current_level AS currentLevel,
                combined.account_number AS accountNumber,
                combined.amount AS amount,
                combined.currency AS currency,
                combined.tenure_months AS tenureMonths,
                combined.maturity_instruction AS maturityInstruction,
                combined.maturity_amount AS maturityAmount,
                combined.maturity_date AS maturityDate,
                combined.tenure_years AS tenureYears,
                combined.tenure_days AS tenureDays,
                combined.interest_rate AS interestRate
            FROM (
                SELECT id, status, current_level, account_number, amount, currency, 
                       tenure_months, maturity_instruction, maturity_amount, maturity_date, 
                       tenure_years, tenure_days, interest_rate 
                FROM fixed_deposits
                UNION ALL
                SELECT id, status, current_level, fd_account_number as account_number, amount, currency, 
                       tenure_months, maturity_instruction, maturity_amount, maturity_date, 
                       tenure_years, tenure_days, interest_rate 
                FROM close_fixed_deposits
            ) combined
            WHERE EXISTS (
                SELECT 1 FROM gtp_fd_assignment a 
                WHERE a.fd_id = combined.id 
                AND a.group_id = :groupId
            )
            AND combined.account_number IN (
                SELECT ad.account_number 
                FROM gtp_user_account_mapping map 
                JOIN account_details ad ON map.account_mapping_id = ad.id 
                WHERE map.user_user_id = :userId
            )
            AND combined.status IN (:status)
            """, 
            countQuery = """
            SELECT count(*) FROM (
                SELECT id, status, account_number FROM fixed_deposits
                UNION ALL
                SELECT id, status, fd_account_number as account_number FROM close_fixed_deposits
            ) combined
            WHERE EXISTS (
                SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.group_id = :groupId
            )
            AND combined.account_number IN (
                SELECT ad.account_number 
                FROM gtp_user_account_mapping map 
                JOIN account_details ad ON map.account_mapping_id = ad.id 
                WHERE map.user_user_id = :userId
            )
            AND combined.status IN (:status)
            """, nativeQuery = true)
    Page<CheckerTrayProjection> findCheckerTrayByStatus(
            Long userId,
            Long groupId,
            List<String> status,
            Pageable pageable
    );

    /*
    @Query("""
            SELECT
            f.id as fdId,
            
            CASE
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'APPROVED'
            ) THEN 'APPROVED'
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'PENDING'
            AND a.isActive = true
            ) THEN 'PENDING'
            
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'WAITING'
            ) THEN 'WAITING'
           
            WHEN EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            AND a.status = 'REJECTED'
            ) THEN 'REJECTED'
            
            ELSE 'VIEW_ONLY'
            
            END as status,
            
            f.status as fdStatus,
            f.currentLevel as currentLevel,
            f.accountNumber as accountNumber,
            f.amount as amount,
            f.currency as currency,
            f.tenureMonths as tenureMonths,
            f.maturityInstruction as maturityInstruction,
            f.maturityAmount as maturityAmount,
            f.maturityDate as maturityDate,
            f.tenureYears as tenureYears,
            f.tenureDays as tenureDays,
            f.interestRate as interestRate
            FROM FixedDeposit f
            WHERE EXISTS (
            SELECT 1 FROM FDAssignment a
            WHERE a.fdId = f.id
            AND a.assignmentType = 'ROLE'
            AND a.userType = :roleName
            )
            AND f.accountNumber IN (
            SELECT acc.accountNumber
            FROM User u
            JOIN u.accountMapping acc
            WHERE u.userId = :userId
            )
            """)
    Page<CheckerTrayProjection> findReleaserOrVerifierTray(
            Long userId,
            String roleName,
            Pageable pageable
    );
    */

    /**
     * Unified tray query for Releasers and Verifiers (Creation + Closure).
     */
    @Query(value = """
            SELECT 
                combined.id AS fdId,
                (CASE 
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName AND a.status = 'APPROVED') THEN 'APPROVED'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName AND a.status = 'PENDING' AND a.is_active = true) THEN 'PENDING'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName AND a.status = 'WAITING') THEN 'WAITING'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName AND a.status = 'REJECTED') THEN 'REJECTED'
                    ELSE 'VIEW_ONLY'
                END) AS status,
                combined.status AS fdStatus,
                combined.current_level AS currentLevel,
                combined.account_number AS accountNumber,
                combined.amount AS amount,
                combined.currency AS currency,
                combined.tenure_months AS tenureMonths,
                combined.maturity_instruction AS maturityInstruction,
                combined.maturity_amount AS maturityAmount,
                combined.maturity_date AS maturityDate,
                combined.tenure_years AS tenureYears,
                combined.tenure_days AS tenureDays,
                combined.interest_rate AS interestRate
            FROM (
                SELECT id, status, current_level, account_number, amount, currency, 
                       tenure_months, maturity_instruction, maturity_amount, maturity_date, 
                       tenure_years, tenure_days, interest_rate 
                FROM fixed_deposits
                UNION ALL
                SELECT id, status, current_level, fd_account_number as account_number, amount, currency, 
                       tenure_months, maturity_instruction, maturity_amount, maturity_date, 
                       tenure_years, tenure_days, interest_rate 
                FROM close_fixed_deposits
            ) combined
            WHERE EXISTS (
                SELECT 1 FROM gtp_fd_assignment a 
                WHERE a.fd_id = combined.id 
                AND a.assignment_type = 'ROLE' 
                AND a.user_type = :roleName
            )
            AND combined.account_number IN (
                SELECT ad.account_number 
                FROM gtp_user_account_mapping map 
                JOIN account_details ad ON map.account_mapping_id = ad.id 
                WHERE map.user_user_id = :userId
            )
            """, 
            countQuery = """
            SELECT count(*) FROM (
                SELECT id, account_number FROM fixed_deposits
                UNION ALL
                SELECT id, fd_account_number as account_number FROM close_fixed_deposits
            ) combined
            WHERE EXISTS (
                SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName
            )
            AND combined.account_number IN (
                SELECT ad.account_number 
                FROM gtp_user_account_mapping map 
                JOIN account_details ad ON map.account_mapping_id = ad.id 
                WHERE map.user_user_id = :userId
            )
            """, 
            nativeQuery = true)
    Page<CheckerTrayProjection> findReleaserOrVerifierTray(
            Long userId,
            String roleName,
            Pageable pageable
    );

    /**
     * Unified tray query for Releasers and Verifiers.
     * Merges Creation (fixed_deposits) and Closure (close_fixed_deposits) requests via Native SQL.
     * Corrects join logic for the @ManyToMany User-Account mapping.
     */
    @Query(value = """
            SELECT 
                combined.id AS fdId,
                (CASE 
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName AND a.status = 'APPROVED') THEN 'APPROVED'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName AND a.status = 'PENDING' AND a.is_active = true) THEN 'PENDING'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName AND a.status = 'WAITING') THEN 'WAITING'
                    WHEN EXISTS (SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName AND a.status = 'REJECTED') THEN 'REJECTED'
                    ELSE 'VIEW_ONLY'
                END) AS status,
                combined.status AS fdStatus,
                combined.current_level AS currentLevel,
                combined.account_number AS accountNumber,
                combined.amount AS amount,
                combined.currency AS currency,
                combined.tenure_months AS tenureMonths,
                combined.maturity_instruction AS maturityInstruction,
                combined.maturity_amount AS maturityAmount,
                combined.maturity_date AS maturityDate,
                combined.tenure_years AS tenureYears,
                combined.tenure_days AS tenureDays,
                combined.interest_rate AS interestRate
            FROM (
                SELECT id, status, current_level, account_number, amount, currency, 
                       tenure_months, maturity_instruction, maturity_amount, maturity_date, 
                       tenure_years, tenure_days, interest_rate 
                FROM fixed_deposits
                UNION ALL
                SELECT id, status, current_level, fd_account_number as account_number, amount, currency, 
                       tenure_months, maturity_instruction, maturity_amount, maturity_date, 
                       tenure_years, tenure_days, interest_rate 
                FROM close_fixed_deposits
            ) combined
            WHERE EXISTS (
                SELECT 1 FROM gtp_fd_assignment a 
                WHERE a.fd_id = combined.id 
                AND a.assignment_type = 'ROLE' 
                AND a.user_type = :roleName
            )
            AND combined.account_number IN (
                SELECT ad.account_number 
                FROM gtp_user_account_mapping map 
                JOIN account_details ad ON map.account_mapping_id = ad.id 
                WHERE map.user_user_id = :userId
            )
            AND combined.status IN (:status)
            """, 
            countQuery = """
            SELECT count(*) FROM (
                SELECT id, status, account_number FROM fixed_deposits
                UNION ALL
                SELECT id, status, fd_account_number as account_number FROM close_fixed_deposits
            ) combined
            WHERE EXISTS (
                SELECT 1 FROM gtp_fd_assignment a WHERE a.fd_id = combined.id AND a.assignment_type = 'ROLE' AND a.user_type = :roleName
            )
            AND combined.account_number IN (
                SELECT ad.account_number 
                FROM gtp_user_account_mapping map 
                JOIN account_details ad ON map.account_mapping_id = ad.id 
                WHERE map.user_user_id = :userId
            )
            AND combined.status IN (:status)
            """, 
            nativeQuery = true)
    Page<CheckerTrayProjection> findReleaserOrVerifierTrayByStatus(
            Long userId,
            String roleName,
            List<String> status,
            Pageable pageable
    );

    List<FDAssignment> findByFdIdOrderByLevel(Long fdId);

    List<FDAssignment> findByFdIdAndStatus(Long fdId, AssignmentStatus status);


}
