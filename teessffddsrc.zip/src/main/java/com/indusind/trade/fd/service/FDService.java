package com.indusind.trade.fd.service;

import com.indusind.trade.fd.dto.CheckerFDTrayDTO;
import com.indusind.trade.fd.dto.FdActionAuditsDto;
import com.indusind.trade.fd.dto.FixedDepositDto;
import com.indusind.trade.fd.dto.MakerTrayDTO;
import com.indusind.trade.model.dtos.response.dtos.MidOfficeCountDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface FDService {

    // CREATE FD
    
    void createFD(FixedDepositDto fd);

    void approve(Long fdId,
                 Long userId,
                 String loginId,
                 String userName,
                 Long groupId,
                 String groupName,
                 String roleName,
                 boolean midOffice);

    // REJECT
    void reject(Long fdId, Long userId, String loginId,String userName, Long groupId, String groupName, String reason, String roleName);

    // REOPEN
    void reopen(FixedDepositDto updated);

    // ================= CLOSE =================
    void close(Long fdId, Long makerId, String loginId, String userName);

    // MAKER TRAY
    Page<MakerTrayDTO> getMakerTray(Long makerId, Pageable pageable);

    // CHECKER TRAY
    Page<CheckerFDTrayDTO> getCheckerTray(Long userId, Long groupId, Pageable pageable);

    Page<CheckerFDTrayDTO> getCheckerTrayByStatus(Long userId, Long groupId, List<String> status, Pageable pageable);

    Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTray(Long userId, String groupName, Pageable pageable);

    Page<CheckerFDTrayDTO> getRelaeaserOrVerifierTrayByStatus(Long userId, String groupName, List<String> status,Pageable pageable);

    Page<FixedDepositDto> getAllFDByCifId(String cifId, Pageable pageable);

    public MidOfficeCountDTO getMidOfficeCounts();

    void approveFdMidOffice(Long fdId, Long midOfficeId, String midOfficeLoginId, String midOfficeUserName);

    void rejectFdMidOffice(Long fdId, Long midOfficeId, String midOfficeLoginId,String midOfficeUserName);

    Page<FixedDepositDto> getFDByStatus(List<String> status, Pageable page);

    Page<FdActionAuditsDto> getFDAuditsByFdId(Long fdId, Pageable page);
}
