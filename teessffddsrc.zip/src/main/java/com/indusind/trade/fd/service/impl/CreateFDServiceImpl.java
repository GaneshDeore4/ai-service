package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.client.FixedDepositClient;
import com.indusind.trade.fd.dto.request_wrapper.Header;
import com.indusind.trade.fd.dto.request_wrapper.Request;
import com.indusind.trade.fd.dto.request_wrapper.RequestWrapper;
import com.indusind.trade.fd.dto.request_wrapper.create_fd.CreateFDBody;
import com.indusind.trade.fd.dto.request_wrapper.create_fd.FDBookingRequestWrapper;
import com.indusind.trade.fd.dto.request_wrapper.create_fd.NomineeDTO;
import com.indusind.trade.fd.dto.request_wrapper.create_fd.PostalAddressDTO;
import com.indusind.trade.fd.dto.response_wrapper.ResponseWrapper;
import com.indusind.trade.fd.entity.FixedDeposit;
import com.indusind.trade.fd.service.CreateFDService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CreateFDServiceImpl implements CreateFDService {

        private static final Logger log = LoggerFactory.getLogger(CreateFDServiceImpl.class);
        
        private final FixedDepositClient fdClient;

        @Value("${ibl.client.id}")
        private String clientId;

        @Value("${ibl.client.secret}")
        private String clientSecret;

        private final com.fasterxml.jackson.databind.ObjectMapper objectMapper;

        @Override
        public ResponseWrapper createFD(FixedDeposit fd) {
                RequestWrapper requestDTO = convertFDToRequestWrapper(fd);

                try {
                        String rawJsonRequest = objectMapper.writerWithDefaultPrettyPrinter()
                                        .writeValueAsString(requestDTO);
                        log.info("Exact Request sending to Bank: \n{}", rawJsonRequest);
                        String rawJsonResponse = fdClient.createFD(clientId, clientSecret, rawJsonRequest);
                        log.info("Exact Response received from Bank: \n{}", rawJsonResponse);

                        ResponseWrapper responseDTO = objectMapper.readValue(rawJsonResponse, ResponseWrapper.class);
                        return responseDTO;

                } catch (Exception e) {
                        log.error("Failed to communicate with Bank API: {}", e.getMessage());
                        throw new RuntimeException("Bank API Error: " + e.getMessage());
                }
        }
        
        
private RequestWrapper convertFDToRequestWrapper(FixedDeposit fd) {

    String uuid = UUID.randomUUID().toString();

    return RequestWrapper.builder()
            .request(
                    Request.builder()
                            .header(
                                    Header.builder()
                                            .requestUUID(uuid)
                                            .channelId("GCNB")
                                            .build()
                            )
                            .body(
                                    FDBookingRequestWrapper.builder()
                                            .fdBookingRequest(
                                                    CreateFDBody.builder()

                                                            // Customer Details
                                                            .custId(fd.getCifId())
                                                            .currencyCode(fd.getCurrency())

                                                            // Account Details
                                                            .rePayacctId(fd.getAccountNumber())
                                                            .debitacctId(fd.getAccountNumber())

                                                            // Scheme Details
                                                            .rePayschmCode("SNIBU")
                                                            .rePayschmType("SBA")
                                                            .debitschmCode("SNIBU")
                                                            .debitschmType("SBA")
                                                            .tdSchmCode("THNFN")
                                                            .tdSchmType("TDA")

                                                            // Deposit Details
                                                            .branchId("9001")
                                                            .amountValue(String.valueOf(fd.getAmount()))
                                                            .depositDays(String.valueOf(fd.getTenureDays()))
                                                            .depositMonths(String.valueOf(fd.getTenureMonths()))

                                                            // Renewal Settings
                                                            .autoCloseOnMaturityFlg("Y")
                                                            .maxNumOfRenewalAllwd("12")
                                                            .autoRenewalflg("N")
                                                            .renewalSchmCode("FEIBU")

                                                            // Interest
                                                            .intTblCode("TGINT")

                                                            // Nominee Details
                                                            .nomineeFlag("Y")
                                                            .nomineeName("Bablu")
                                                            .relType("HUS")
                                                            .nomineeMinorFlg("N")
                                                            .nomineeBirthDt("1995-04-14T00:00:00.000Z")
                                                            .nomineePercent("100")

                                                            // Contact
                                                            .mobNum("7777777777")

                                                            // Address
                                                            .postalAdd(
                                                                    PostalAddressDTO.builder()
                                                                            .nominee(
                                                                                    NomineeDTO.builder()
                                                                                            .addr1("house 1")
                                                                                            .city("MUM")
                                                                                            .stateProv("MH")
                                                                                            .postalCode("400076")
                                                                                            .country("IN")
                                                                                            .build()
                                                                            )
                                                                            .build()
                                                            )

                                                            // Misc
                                                            .solID("9001")
                                                            .modeOfOper("009")
                                                            .freeCode4("GCNB")

                                                            .build()
                                            )
                                            .build()
                            )
                            .build()
            )
            .build();
}


}
