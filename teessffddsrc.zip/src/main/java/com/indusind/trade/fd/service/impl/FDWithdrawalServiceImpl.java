package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.dto.FDWithdrawalRequest;
import com.indusind.trade.fd.client.FDWithdrawalClient;
import com.indusind.trade.fd.dto.FDWithdrawalResponse;
import com.indusind.trade.fd.service.FDWithdrawalService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class FDWithdrawalServiceImpl implements FDWithdrawalService {

    private final FDWithdrawalClient fdWithdrawalClient;

    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    @Override
    public FDWithdrawalResponse initiateFullWithdrawal(String acctNum, String repaymentAcctId, double amount) {
        System.out.println("Inside initiateFullWithdrawal");

        FDWithdrawalRequest.Header header = FDWithdrawalRequest.Header.builder()
                .requestUUID(UUID.randomUUID().toString())
                .channelId("GCT")
                .build();

        FDWithdrawalRequest.FDFullWithdrawlRequest bodyContent = FDWithdrawalRequest.FDFullWithdrawlRequest.builder()
                .acctNum(acctNum)
                .repymntAcctId(repaymentAcctId)
                .amt(amount)
                .build();

        FDWithdrawalRequest request = FDWithdrawalRequest.builder()
                .request(FDWithdrawalRequest.RequestContainer.builder()
                        .header(header)
                        .body(FDWithdrawalRequest.Body.builder()
                                .FDFullWithdrawlRequest(bodyContent)
                                .build())
                        .build())
                .build();

        try {
            System.out.println("Request is =" +request);
            return fdWithdrawalClient.fullWithdrawal(clientId, clientSecret, request);
        } catch (Exception e) {
            System.out.println("Error occurred while calling downstream Full Withdrawal API: {}");
            e.printStackTrace();
            throw e;
        }
    }
}