package com.indusind.trade.fd.service.impl;

import com.indusind.trade.fd.dto.FDInterestRatesReqDto;
import com.indusind.trade.fd.dto.FDInterestRatesRespDto;
import com.indusind.trade.fd.service.SoapTransformationService;
import com.indusind.trade.fd.utils.DateUtils;
import com.indusind.trade.fd.utils.TemplateLoaderUtils;
import com.indusind.trade.model.common.exception.GTPAppException;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class SoapTransformationServiceImpl implements SoapTransformationService {

    @Override
    public String convertFDInterestRatesReqToSoap(FDInterestRatesReqDto req) {
        String template = TemplateLoaderUtils.load("templates/calculateFDInterestSoapReq.xml");

        Map<String, String> map = new HashMap<>();

        map.put("requestUUID", UUID.randomUUID().toString().substring(0, 8));
        map.put("messageDateTime", DateUtils.now());

        map.put("currencyCode", val(req.getCurrencyCode()));
        map.put("daysInAYear", val(req.getDaysInAYear()));
        map.put("amountValue", val(req.getAmountValue()));
        map.put("currencyCodes", val(req.getCurrencyCode()));
        map.put("depositDate", DateUtils.format(req.getDepositDate()));
        map.put("days", val(req.getDays()));
        map.put("months", val(req.getMonths()));
        map.put("depositType", val(req.getDepositType()));
        map.put("flowType", val(req.getFlowType()));
        map.put("monthsInAYear", val(req.getMonthsInAYear()));
        map.put("pegFlag", val(req.getPegFlag()));
        map.put("schmCode", val(req.getSchmCode()));
        map.put("schmType", val(req.getSchmType()));
        map.put("channelId", val(req.getChannelId()));


        // empty required fields
        map.put("userId", "");
        map.put("password", "");
        map.put("bankId", "");
        map.put("timeZone", "");
        map.put("entityId", "");
        map.put("entityType", "");
        map.put("armCorrelationId", "");
        map.put("fiCertToken", "");
        map.put("realUserLoginSessionId", "");
        map.put("realUser", "");
        map.put("realUserPwd", "");
        map.put("ssoTransferToken", "");
        map.put("languageId", "");
        map.put("tableCode", "");

        for (Map.Entry<String, String> e : map.entrySet()) {
            template = template.replace("{{" + e.getKey() + "}}", escape(e.getValue()));
        }

        return template;
    }

//    @Override
//    public FDInterestRatesRespDto parseFDInterestRatesRespToJson(String soapRespXml) {
//        try {
//            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
//            Document doc = f.newDocumentBuilder()
//                    .parse(new InputSource(new StringReader(soapRespXml)));
//
//            XPath x = XPathFactory.newInstance().newXPath();
//            if ("SUCCESS".equalsIgnoreCase(x.evaluate("//HostTransaction/Status", doc))) {
//                return FDInterestRatesRespDto.builder()
//                        .status(x.evaluate("//HostTransaction/Status", doc))
//                        .interestRate(x.evaluate("//interestRate", doc))
//                        .maturityAmount(x.evaluate("//maturityAmt/amountValue", doc))
//                        .maturityDate(x.evaluate("//maturityDate", doc))
//                        .interestAmount(x.evaluate("//interestAmount/amountValue", doc))
//                        .currency(x.evaluate("//currencyCode", doc))
//                        .build();
//            } else {
//                return FDInterestRatesRespDto.builder()
//                        .status(x.evaluate("//HostTransaction/Status", doc))
//                        .build();
//            }
//        } catch (Exception e) {
//            throw new GTPAppException(e.getMessage(), e);
//        }
//    }

    @Override
    public FDInterestRatesRespDto parseFDInterestRatesRespToJson(String soapRespXml) {

        if (soapRespXml == null || soapRespXml.isBlank()) {
            throw new GTPAppException("Empty SOAP response", null);
        }

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(false);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);

            Document soapDoc = factory.newDocumentBuilder()
                    .parse(new InputSource(new StringReader(soapRespXml)));

            XPath xpath = XPathFactory.newInstance().newXPath();

            String fixmlEscaped = xpath.evaluate("//*[local-name()='executeServiceReturn']", soapDoc);

            if (isBlank(fixmlEscaped)) {
                throw new GTPAppException("FIXML not found in SOAP response", null);
            }

            String fixml = StringEscapeUtils.unescapeXml(fixmlEscaped);

            fixml = fixml.trim();

            Document fixmlDoc = factory.newDocumentBuilder()
                    .parse(new InputSource(new StringReader(fixml)));

            XPath x = XPathFactory.newInstance().newXPath();

            String status = getValue(x, fixmlDoc, "//*[local-name()='HostTransaction']/*[local-name()='Status']");

            if ("SUCCESS".equalsIgnoreCase(status)) {

                return FDInterestRatesRespDto.builder()
                        .status(status)
                        .interestRate(getValue(x, fixmlDoc, "//*[local-name()='interestRate']"))
                        .maturityAmount(getValue(x, fixmlDoc, "//*[local-name()='maturityAmt']/*[local-name()='amountValue']"))
                        .maturityDate(DateUtils.parseToLocalDate(getValue(x, fixmlDoc, "//*[local-name()='maturityDate']")))
                        .interestAmount(getValue(x, fixmlDoc, "//*[local-name()='interestAmount']/*[local-name()='amountValue']"))
                        .currency(getValue(x, fixmlDoc, "//*[local-name()='currencyCode']"))
                        .build();

            } else {
                return FDInterestRatesRespDto.builder()
                        .status(status)
                        .errorMessage("HostTransaction not successful")
                        .build();
            }

        } catch (Exception e) {
            throw new GTPAppException("Error parsing FD Interest SOAP response", e);
        }
    }

    private String getValue(XPath xpath, Document doc, String expression) {
        try {
            String value = xpath.evaluate(expression, doc);
            return value != null ? value.trim() : "";
        } catch (Exception e) {
            return "";
        }
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private String val(String v) {
        return v == null ? "" : v;
    }

    private String escape(String v) {
        return v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
