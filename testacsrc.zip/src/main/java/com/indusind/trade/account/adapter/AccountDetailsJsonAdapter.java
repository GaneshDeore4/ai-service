package com.indusind.trade.account.adapter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.EncDec.EncDecUtil;
import com.indusind.trade.account.client.BankJsonFeignClient;
import com.indusind.trade.account.client.SingleAccountDetailsFeignClient;
import com.indusind.trade.account.dto.json.AccountDetailsJSONRequest;
import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.response.AccountDetailsResponseDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "app.acc.adapter.type", havingValue = "json", matchIfMissing = true)
@RequiredArgsConstructor
public class AccountDetailsJsonAdapter implements AccountDetailsAdapter {

    private final SingleAccountDetailsFeignClient singleAccountDetailsFeignClient;

    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    @Override
    public AccountDetailsResponseDTO getAccountDetails(String accountNo)  {

        String encryptedPayload="";
        String decryptedRes = "";
        String jsonRequestStr="";
        String decryptionKey="";
        String responseDataObj="";
        EncDecUtil encDecUtil = new EncDecUtil();
        ObjectMapper objectMapper = new ObjectMapper();
        AccountDetailsJSONRequest request= AccountDetailsJSONRequest.builder()
                .accountNumber(accountNo)
                .build();

        AccountDetailsResponseDTO response =new AccountDetailsResponseDTO();
        try{
            String requestJson = objectMapper.writeValueAsString(request);
            encryptedPayload=encDecUtil.getEncyption(requestJson,"UAT");
            JsonNode rootNode = objectMapper.readTree(encryptedPayload);

            JsonNode requestNode = rootNode.get("request");

            System.out.println("Request Node :" +requestNode);

            jsonRequestStr = objectMapper.writeValueAsString(requestNode);

            System.out.println("Request Node to String :" +jsonRequestStr);

            decryptionKey  = rootNode.get("key").asText();

           String encResponse = singleAccountDetailsFeignClient.getAccountDetails(clientId, clientSecret, jsonRequestStr);
            JsonNode responserootNode = objectMapper.readTree(encResponse);

            responseDataObj=responserootNode.get("data").asText();

            decryptedRes=encDecUtil.getDecryption(responseDataObj,decryptionKey);

            response =
                    objectMapper.readValue(decryptedRes, AccountDetailsResponseDTO.class);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return response;
    }
}
