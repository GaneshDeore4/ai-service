package com.indusind.trade.account.adapter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.indusind.EncDec.EncDecUtil;
import com.indusind.trade.account.client.BalanceEnquiryFeignClient;
import com.indusind.trade.account.client.BankJsonFeignClient;
import com.indusind.trade.account.client.SingleAccountDetailsFeignClient;
import com.indusind.trade.account.dto.AccountDTO;
import com.indusind.trade.account.dto.BalanceDTO;
import com.indusind.trade.account.dto.SyncAccountRequestDto;
import com.indusind.trade.account.dto.json.BalanceEnquiryRequest;
import com.indusind.trade.account.dto.json.BalanceEnquiryResponse;
import com.indusind.trade.account.dto.json.SyncAccountJson;
import com.indusind.trade.account.dto.json.SyncAccountJsonResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.bank.adapter.type", havingValue = "json")
@RequiredArgsConstructor
public class BankJsonAdapter implements AccountAdapter, BalanceAdapter {

    private final BankJsonFeignClient bankJsonFeignClient;
    private final BalanceEnquiryFeignClient balanceEnquiryClient;
    private final SingleAccountDetailsFeignClient singleAccountDetailsFeignClient;
    private final ObjectMapper objectMapper;
    private static final List<String> OPERATIVE_ACCOUNT_SCHEME_TYPES = Arrays.asList("SBA", "CAA", "CCA");
    private static final String FD_ACCOUNT_SCHEME_TYPE = "TDA";


    @Value("${ibl.client.id}")
    private String clientId;

    @Value("${ibl.client.secret}")
    private String clientSecret;

    @Override
    public List<AccountDTO> fetchAccountsByCif(String cifId) {
        log.info("Fetching accounts from JSON API for CIF: {}", cifId);
        SyncAccountRequestDto syncAccountRequestDto = SyncAccountRequestDto.builder().cifid(cifId).build();
        SyncAccountJsonResponse jsonResponses = null;

        String encryptedPayload="";
        String decryptedRes = "";
        String jsonRequestStr="";
        String decryptionKey="";
        String responseDataObj="";
        EncDecUtil encDecUtil = new EncDecUtil();

        try {
            String requestJson = objectMapper.writeValueAsString(syncAccountRequestDto);
            encryptedPayload=encDecUtil.getEncyption(requestJson,"UAT");

            System.out.println("Enc Payload  :" +encryptedPayload);
            JsonNode rootNode = objectMapper.readTree(encryptedPayload);

            JsonNode requestNode = rootNode.get("request");


            jsonRequestStr = objectMapper.writeValueAsString(requestNode);
            System.out.println("Request Node  :" +jsonRequestStr);
            decryptionKey  = rootNode.get("key").asText();

            System.out.println("Decryption Key  :" +decryptionKey);


            String encResponse = singleAccountDetailsFeignClient.fetchAccountsByCifId(clientId, clientSecret, jsonRequestStr);

            JsonNode responserootNode = objectMapper.readTree(encResponse);

            responseDataObj=responserootNode.get("data").asText();
            decryptedRes=encDecUtil.getDecryption(responseDataObj,decryptionKey);

            System.out.println("Account agains CIF  :" +decryptedRes);

            jsonResponses =
                    objectMapper.readValue(decryptedRes, SyncAccountJsonResponse.class);

            log.info("Process using Mocked JSON response for testing");
        } catch (Exception e) {        	
            log.error("Error calling Bank JSON API: {}", e.getMessage());           
            throw new RuntimeException("Bank JSON API Error", e);
        }
        return mapJsonToDto(jsonResponses);
    }

    private List<AccountDTO> mapJsonToDto(SyncAccountJsonResponse jsonResponses) {
        if (jsonResponses == null) return List.of();
        return jsonResponses.getAccounts().stream().map(resp -> AccountDTO.builder()
                .cifId(resp.getCifId())
                .accountNumber(resp.getAccountNumber())
                .currency(resp.getCurrency())
                .schemeDescription(resp.getSchemeDesc())
                .schemeType(resp.getSchemeType())
                /*.effectiveAvailBalance(OPERATIVE_ACCOUNT_SCHEME_TYPES.contains(resp.getSchemeType()) ?
                        new BigDecimal(resp.getAccountBalance()) :
                        FD_ACCOUNT_SCHEME_TYPE.equals(resp.getSchemeType()) ? new BigDecimal(resp.getDepositAmount()) : BigDecimal.valueOf(0))*/
                .build()).collect(Collectors.toList());
    }

    /*public static SyncAccountJsonResponse generateDummyResponse(String cifId, int accountCount) throws NoSuchAlgorithmException {

        SyncAccountJsonResponse syncAccountJsonResponse = new SyncAccountJsonResponse();
        syncAccountJsonResponse.setCountry("AE");
        syncAccountJsonResponse.setCity("DXB");
        syncAccountJsonResponse.setMobileNumber("930535799");
        syncAccountJsonResponse.setEmailId("ABARHK1508@GMAIL.COM");
        syncAccountJsonResponse.setCustomerType("010");
        syncAccountJsonResponse.setCountryCode("971");
        syncAccountJsonResponse.setSegment("CRET");
        syncAccountJsonResponse.setState("DUB");
        syncAccountJsonResponse.setPan("BHN CITY");
        syncAccountJsonResponse.setLandmark("DUBAI");
        syncAccountJsonResponse.setCifId(cifId);
        syncAccountJsonResponse.setPincode("000000");
        syncAccountJsonResponse.setDOBorDOI(LocalDateTime.of(2022, 8, 31, 0, 0));
        syncAccountJsonResponse.setCustomerName("ABHISHEK AMITABH BACCHAN");
        syncAccountJsonResponse.setKeyContactPerson("VIMAL KUMAR MISHRA");
        syncAccountJsonResponse.setSubsegment("RET");
        syncAccountJsonResponse.setAddressline1("AC-SP-AC8-18,");
        syncAccountJsonResponse.setAddressline2("AVIATION DISTRICT");
        syncAccountJsonResponse.setAddressline3(".");
        syncAccountJsonResponse.setPrimaryRMName("400020");
        syncAccountJsonResponse.setStatusCode("SUCCESS");

        List<SyncAccountJson> accounts = new ArrayList<>();

        String acctNumPrefix;

        if (cifId.length() >= 4) {
            acctNumPrefix = cifId.substring(0, 4);
        } else {
            acctNumPrefix = String.format("%4s", cifId).replace(' ', '0');
        }

        for (int i = 1; i <= accountCount; i++) {

            SyncAccountJson account = new SyncAccountJson();
            account.setSchemeCode("CRIBU");
            account.setCifId(cifId);
            account.setAccountNumber(acctNumPrefix + "2541429" + i);
            account.setAccountOpenDate("2022-10-12 00:00:00");
            account.setAcctClsFlg("N");
            account.setAccountBalance(String.valueOf(SecureRandom.getInstanceStrong().nextInt(10000)));
            account.setSchemeType(i == accountCount ? FD_ACCOUNT_SCHEME_TYPE : OPERATIVE_ACCOUNT_SCHEME_TYPES.get(SecureRandom.getInstanceStrong().nextInt(OPERATIVE_ACCOUNT_SCHEME_TYPES.size())));
            account.setModeOfOperation("009");
            account.setCurrency("USD");
            account.setLienAmount("0");
            account.setLienFlag("N");
            account.setNomFlg("N");
            account.setAccountStatus("A");
            account.setC5Code("GK");
            account.setNomName("Rajan");
            account.setNomReltnCode("HUS");
            account.setApplRateOfInterest(0.0);
            account.setInterestTableCode("CGINT");
            account.setSchemeDesc("CURRENT ACCOUNT IBU BHN CITY");
            account.setC5CodeDescription("PIONEER GLOBAL BUSINESS ACCOUNT");
            account.setIfscCode("INDB0009001");
            account.setRelationShipType("M");
            account.setGlSubHeadCode("34821");
            account.setSOL_ID("9001");
            account.setPAN("BHN CITY");
            account.setAcct_crncy_code("USD");
            account.setDepositAmount(String.valueOf(SecureRandom.getInstanceStrong().nextInt(10000)));
            accounts.add(account);
        }

        syncAccountJsonResponse.setAccounts(accounts);
        return syncAccountJsonResponse;
    }*/


//    private List<AccountDTO> mapJsonToDto(List<SyncAccountJsonResponse> jsonResponses) {
//        if (jsonResponses == null) return List.of();
//        return jsonResponses.stream().map(resp -> AccountDTO.builder()
//                .cifId(resp.getCifId())
//                .accountNumber(resp.getAcctId())
//                .currency(resp.getCrncy())
//                .schemeDescription(resp.getSchemeDesc())
//                .schemeType(resp.getSchemeType())
//                .effectiveAvailBalance(new BigDecimal(resp.getBalance()))
//                .build()).collect(Collectors.toList());
//    }
//
//    private List<SyncAccountJsonResponse> getDummyJsonResponse(String cifId) {
//        // Simulating the same 5 records as SOAP but in JSON format
//        List<SyncAccountJsonResponse> dummyList = new java.util.ArrayList<>();
//        for (int i = 1; i <= 5; i++) {
//            SyncAccountJsonResponse resp = new SyncAccountJsonResponse();
//            resp.setCifId(cifId);
//            resp.setAcctId("JSON-ACC-" + i + "-" + cifId.substring(Math.max(0, cifId.length() - 4)));
//            resp.setBalance(String.valueOf(10000 * i));
//            resp.setCrncy("INR");
//            resp.setSchemeDesc("Savings Account " + i);
//            resp.setSchemeType("SBA");
//            dummyList.add(resp);
//        }
//        return dummyList;
//    }

    @Override
    public BalanceDTO fetchBalanceByAccount(String accountNumber) {
        log.info("Fetching balance from JSON API for Account: {}", accountNumber);
        
        BalanceEnquiryRequest request = BalanceEnquiryRequest.builder()
                .requestUUID(UUID.randomUUID().toString())
                .channelID("GCT")
                .accountNo(accountNumber)
                .build();

        try {
            BalanceEnquiryResponse response = balanceEnquiryClient.fetchBalance(clientId, clientSecret, request);
            
            if (response != null) {
                log.info("Received balance for account {}: {}", accountNumber, response.getEffAvailableBalance());
                return BalanceDTO.builder()
                        .accountNumber(response.getAccountId())
                        .effectiveAvailBalance(response.getEffAvailableBalance())
                        .currency(response.getCurrency())
                        .build();
            }
        } catch (Exception e) {
            log.error("Error fetching balance for account {}: {}", accountNumber, e.getMessage());
            throw new RuntimeException("Bank Balance API Error", e);
        }
        
        return BalanceDTO.builder()
                .accountNumber(accountNumber)
                .effectiveAvailBalance(BigDecimal.ZERO)
                .currency("USD")
                .build();
    }
}
