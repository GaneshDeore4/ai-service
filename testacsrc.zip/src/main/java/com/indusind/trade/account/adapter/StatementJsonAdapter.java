package com.indusind.trade.account.adapter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.indusind.trade.account.client.StatementFeignClient;
import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.AccountTransactionDTO;
import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import com.indusind.trade.account.dto.request.IndusFullStatementRequest;
import com.indusind.trade.account.dto.request.IndusMiniStatementRequest;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import com.indusind.EncDec.EncDecUtil;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.acc.adapter.type", havingValue = "json", matchIfMissing = true)
@RequiredArgsConstructor
public class StatementJsonAdapter implements StatementAdapter {

    private final StatementFeignClient statementFeignClient;
    private final ObjectMapper objectMapper;

    @org.springframework.beans.factory.annotation.Value("${ibl.client.id}")
    private String clientId;

    @org.springframework.beans.factory.annotation.Value("${ibl.client.secret}")
    private String clientSecret;

    @Override
    public AccountStatementResponse fetchStatement(String accountNumber, String fromDate, String toDate) {

        log.info("Fetching statement from JSON API for Account: {} from {} to {}", accountNumber, fromDate, toDate);

        String encryptedPayload="";
        String decryptedRes = "";
        String jsonRequestStr="";
        String decryptionKey="";
        String responseDataObj="";
        EncDecUtil encDecUtil = new EncDecUtil();

        IndusMiniStatementRequest request = IndusMiniStatementRequest.builder()
                .requestUUID(java.util.UUID.randomUUID().toString())
                .channelID("COR") // Default value as seen in user trace
                .accountNo(accountNumber)
                .fromDate(fromDate)
                .toDate(toDate)
                .limit(10) // Set default limit as per requirement
                .build();

        try{
            String requestJson = objectMapper.writeValueAsString(request);

            encryptedPayload=encDecUtil.getEncyption(requestJson,"UAT");

            System.out.println("Encrypted PayLoad is :" +encryptedPayload);
            jsonRequestStr=getJSONStr(encryptedPayload);
            decryptionKey=getkey(encryptedPayload);
            System.out.println("JSON STI Main " +jsonRequestStr) ;
            System.out.println("Decryption Key=" +decryptionKey);

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {

            String encResponse = statementFeignClient.fetchMiniStatement(clientId, clientSecret, jsonRequestStr);
            System.out.println("Encrypted Response is=" +encResponse);
            JsonNode responserootNode = objectMapper.readTree(encResponse);

            responseDataObj=responserootNode.get("data").asText();

            System.out.println("Data Node==" +responseDataObj);

            try {
                decryptedRes=encDecUtil.getDecryption(responseDataObj,decryptionKey);
                System.out.println("Decrypted Response=" +decryptedRes);
            } catch (Exception e) {
                System.out.println("Inside Catch of decrpted");
            }
            AccountStatementResponse response =
                    objectMapper.readValue(decryptedRes, AccountStatementResponse.class);
            return response;
        } catch (FeignException e) {
            String errorBody = e.contentUTF8();
            log.error("Error calling mini statement API. Status: {}, Body: {}", e.status(), errorBody);

            if (errorBody == null || errorBody.trim().isEmpty()) {
                return AccountStatementResponse.builder()
                        .successFlag(false)
                        .errorMessage("Bank API returned error status " + e.status() + " with empty body")
                        .errorCode(String.valueOf(e.status()))
                        .build();
            }

            try {
                AccountStatementResponse res = objectMapper.readValue(errorBody, AccountStatementResponse.class);
                log.info("res parsed from errorBody: " + res);
                return res;
            } catch (Exception ex) {
                log.error("Failed to parse error body. Type: {}, Message: {}", ex.getClass().getName(), ex.getMessage());
                return AccountStatementResponse.builder()
                        .successFlag(false)
                        .errorMessage("Failed to parse bank error response: " + ex.getMessage())
                        .errorCode(String.valueOf(e.status()))
                        .build();
            }
        } catch (JsonMappingException e) {
            throw new RuntimeException(e);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public AccountStatementResponse fetchFullStatement(AccountStatementRequestDto requestDto, String continueToken) {
        log.info("Fetching full statement from JSON API for Account: {} from {} to {}", requestDto.getAccountNo(), requestDto.getFromDate(), requestDto.getToDate());


        String encryptedPayload="";
        String decryptedRes = "";
        String jsonRequestStr="";
        String decryptionKey="";
        String responseDataObj="";
        EncDecUtil encDecUtil = new EncDecUtil();

        IndusFullStatementRequest request = IndusFullStatementRequest.builder()
                .requestUUID(requestDto.getRequestUUID())
                .accountNo(requestDto.getAccountNo())
                .fromDate(requestDto.getFromDate())
                .toDate(requestDto.getToDate())
                .limit(requestDto.getLimit() != null && !requestDto.getLimit().isEmpty() ? Integer.parseInt(requestDto.getLimit()) : 10)
                .continueToken(continueToken)
                .build();
        try{
            String requestJson = objectMapper.writeValueAsString(request);
            encryptedPayload=encDecUtil.getEncyption(requestJson,"UAT");
            System.out.println("Encrypted PayLoad is :" +encryptedPayload);
            jsonRequestStr=getJSONStr(encryptedPayload);
            decryptionKey=getkey(encryptedPayload);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {

            String encResponse  = statementFeignClient.fetchFullStatement(clientId, clientSecret, jsonRequestStr);
            System.out.println("Encrypted Response :" +encResponse);
            JsonNode responserootNode = objectMapper.readTree(encResponse);

            responseDataObj=responserootNode.get("data").asText();

            System.out.println("Data Response :" +responseDataObj);

            try {
                decryptedRes=encDecUtil.getDecryption(responseDataObj,decryptionKey);
                System.out.println("Statement Decrypted Response=" +decryptedRes);
            } catch (Exception e) {
                System.out.println("Inside Catch of decrpted");
            }
            AccountStatementResponse response =
                    objectMapper.readValue(decryptedRes, AccountStatementResponse.class);
            return response;
        } catch (FeignException e) {
            String errorBody = e.contentUTF8();
            log.error("Error calling full statement API. Status: {}, Body: {}", e.status(), errorBody);

            if (errorBody == null || errorBody.trim().isEmpty()) {
                return AccountStatementResponse.builder()
                        .successFlag(false)
                        .errorMessage("Bank API returned error status " + e.status() + " with empty body")
                        .errorCode(String.valueOf(e.status()))
                        .build();
            }

            try {
                AccountStatementResponse res = objectMapper.readValue(errorBody, AccountStatementResponse.class);
                log.info("res parsed from errorBody: " + res);
                return res;
            } catch (Exception ex) {
                log.error("Failed to parse error body. Type: {}, Message: {}", ex.getClass().getName(), ex.getMessage());
                return AccountStatementResponse.builder()
                        .successFlag(false)
                        .errorMessage("Failed to parse bank error response: " + ex.getMessage())
                        .errorCode(String.valueOf(e.status()))
                        .build();
            }
        } catch (JsonMappingException e) {
            throw new RuntimeException(e);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private AccountStatementResponse getMockStatement(String accountNumber, String fromDate, String toDate) {
        return null;
    }

    public String getJSONStr(String encryptedPayload) throws JsonProcessingException {

        JsonNode rootNode = objectMapper.readTree(encryptedPayload);

        JsonNode requestNode = rootNode.get("request");

        System.out.println("Request Node :" +requestNode);

         String jsonRequestStr = objectMapper.writeValueAsString(requestNode);

        System.out.println("Request Node to String :" +jsonRequestStr);

        return jsonRequestStr;

    }

    public String getkey(String encryptedPayload) throws JsonProcessingException {

        String decryptionKey="";

        JsonNode rootNode = objectMapper.readTree(encryptedPayload);

        System.out.println("Request Node getkey :" +rootNode);

        decryptionKey  = rootNode.get("key").asText();

        System.out.println("Desc Key :" +decryptionKey);

        return decryptionKey;

    }
}
