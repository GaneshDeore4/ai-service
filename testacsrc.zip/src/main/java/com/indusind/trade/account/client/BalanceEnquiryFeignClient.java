package com.indusind.trade.account.client;

import com.indusind.trade.account.config.FeignConfig;
import com.indusind.trade.account.dto.json.BalanceEnquiryRequest;
import com.indusind.trade.account.dto.json.BalanceEnquiryResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "balanceEnquiryClient", url = "${app.bank.api.balance.url}", configuration = FeignConfig.class)
public interface BalanceEnquiryFeignClient {

    @PostMapping("/BalanceEnquiry/enc/v25")
    BalanceEnquiryResponse fetchBalance(
            @RequestHeader("IBL-Client-Id") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody BalanceEnquiryRequest request
    );
}
