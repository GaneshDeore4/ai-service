package com.indusind.trade.account.client;

import com.indusind.trade.account.config.FeignConfig;
import com.indusind.trade.account.dto.json.AccountDetailsJSONRequest;
import com.indusind.trade.account.dto.json.SyncAccountJsonResponse;
import com.indusind.trade.account.dto.response.AccountDetailsResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "singleAccountClient", url = "${app.feign.json-account.url}", configuration = FeignConfig.class)
public interface SingleAccountDetailsFeignClient {

    @PostMapping("/dedupeenquiry/accountnumber/V5")
    String  getAccountDetails(@RequestHeader("IBL-Client-Id") String clientID,
                                                @RequestHeader("IBL-Client-Secret") String clientSecret,
                                                @RequestBody String request);

    @PostMapping("/indie/getcustomeraccounts/cifid/V1")
    String fetchAccountsByCifId(
            @RequestHeader("IBL-Client-ID") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody String request);

}
