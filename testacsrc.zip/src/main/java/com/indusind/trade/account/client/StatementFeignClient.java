package com.indusind.trade.account.client;

import com.indusind.trade.account.config.FeignConfig;
import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import com.indusind.trade.account.dto.request.IndusFullStatementRequest;
import com.indusind.trade.account.dto.request.IndusMiniStatementRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "statementFeignClient", url = "${app.feign.account-statement-json}")
public interface StatementFeignClient {

    /*@PostMapping("/balsrv/Ministatement/V25")
    AccountStatementResponse fetchMiniStatement(
            @RequestHeader("IBL-Client-ID") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody IndusMiniStatementRequest request
    );*/

    @PostMapping("/balsrv/ministatement/V25")
    String fetchMiniStatement(
            @RequestHeader("IBL-Client-ID") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody String encryptedPayload
    );

    @PostMapping("/fullstatement/V1")
    String fetchFullStatement(
            @RequestHeader("IBL-Client-ID") String clientId,
            @RequestHeader("IBL-Client-Secret") String clientSecret,
            @RequestBody String request
    );
}
