package com.indusind.trade.account.dto;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SyncAccountRequestDto {

    private String cifid;

}
