package com.indusind.trade.account.dto.json;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AccountDetailsJSONRequest {

    private String accountNumber;

}
