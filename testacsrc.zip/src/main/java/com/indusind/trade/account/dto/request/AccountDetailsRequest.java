package com.indusind.trade.account.dto.request;

import lombok.Data;

@Data
public class AccountDetailsRequest {
    private String accountNumber;
}