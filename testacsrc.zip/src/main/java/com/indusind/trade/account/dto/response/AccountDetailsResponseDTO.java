package com.indusind.trade.account.dto.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class AccountDetailsResponseDTO {
    private String cifId;
    private String accountNumber;
    private String accountOpenDate; // e.g., "2023-11-29 00:00:00"
    private String acctClsFlg;
    private String acctClsDate;
    private String accountStatus;
    
    private String ifscCode;
    private String pdFlg;
    @JsonProperty("c5Code")
    private String c5Code;
    private String c5CodeDescription;
    private String schemeCode;
    private String schemeType;
    private String schemeDesc;
    private String modeOfOperation;
    private String frezCode;
    private String fraudFlag;
    private String currency;
    private String lienAmount; // "0" - using String as it's quoted in JSON
    private String lienFlag;
    private String nomFlg;
    private String nomName;
    private String nomReltnCode;
    private Double applRateOfInterest; // 0 - using Double as it's not quoted in JSON
    private String startDate;
    private String maturityAmount; // "0" - using String as it's quoted in JSON
    private String maturityDate;
    private String maturityInsc;
    private String depositAmount; // "0" - using String as it's quoted in JSON
    private String depositPeriodDays;
    private String depositPeriodMonths;
    private String repaymentAccount;
    private String repaymentSchemeType;
    private String renewalOption;
    private String flowFreqMths;
    private String flowFreqDays;
    private String autoRenewalFlg;
    private String flowCode;
    private String constitutionCode;
    private String nomineePrintFlg;
    private List<AasDetail> aas;
    private String fdtype;
    @JsonProperty("PAN")
    private String pan;
    @JsonProperty("SOL_ID")
    private String solId;
    @JsonProperty("FDSBALinked")
    private String fdsbaLinked;
    @JsonProperty("TDTerm")
    private String tdTerm;

    @Data
    public static class AasDetail {
        private String cifId;
        private String modeofOperation;
    }
}
