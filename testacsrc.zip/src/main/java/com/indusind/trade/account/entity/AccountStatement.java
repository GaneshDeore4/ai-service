package com.indusind.trade.account.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "account_statements")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountStatement {

    @Id
    @GeneratedValue
    @UuidGenerator
    @Column(name = "id", updatable = false, nullable = false)
    private String id;

    @Column(name = "account_id")
    private String accountId;

    @Column(name = "cif_id")
    private String cifId;

    @Column(name = "currency")
    private String currency;

    @Column(name = "name")
    private String name;

    @Column(name = "ledger_balance", precision = 19, scale = 4)
    private BigDecimal ledgerBalance;

    @Column(name = "available_balance", precision = 19, scale = 4)
    private BigDecimal availableBalance;

    @Column(name = "eff_available_balance", precision = 19, scale = 4)
    private BigDecimal effAvailableBalance;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "statement", cascade = CascadeType.ALL)
    private List<AccountTransaction> transactions;

    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @UpdateTimestamp
    @Column(name = "updated_date")
    private LocalDateTime updatedDate;
}
