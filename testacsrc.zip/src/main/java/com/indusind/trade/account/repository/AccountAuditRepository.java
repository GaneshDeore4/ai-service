package com.indusind.trade.account.repository;

import com.indusind.trade.account.entity.AccountAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountAuditRepository extends JpaRepository<AccountAudit, Long> {
    List<AccountAudit> findByAccountNumber(String accountNumber);
    List<AccountAudit> findByCifId(String cifId);
}
