package com.indusind.trade.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.indusind.trade.account.entity.AccountDetail;

import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<AccountDetail, String> {

    List<AccountDetail> findByCifId(String cifId);

    Optional<AccountDetail> findByAccountNumber(String accountNumber);
}
