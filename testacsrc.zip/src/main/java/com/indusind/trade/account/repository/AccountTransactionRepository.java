package com.indusind.trade.account.repository;

import com.indusind.trade.account.entity.AccountTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountTransactionRepository extends JpaRepository<AccountTransaction, String>, JpaSpecificationExecutor<AccountTransaction> {
    List<AccountTransaction> findByAccountNumber(String accountNumber);
}
