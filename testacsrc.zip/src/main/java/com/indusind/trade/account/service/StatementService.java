package com.indusind.trade.account.service;

import com.indusind.trade.account.dto.AccountStatementDTO;
import com.indusind.trade.account.dto.ApplicationResponse;
import com.indusind.trade.account.dto.json.AccountStatementResponse;
import com.indusind.trade.account.dto.request.AccountStatementRequestDto;
import com.indusind.trade.account.dto.request.ContinueTokenDTO;
import com.indusind.trade.account.entity.AccountTransaction;

import java.time.LocalDate;
import java.util.List;

public interface StatementService {
	
    AccountStatementDTO syncStatement(String accountNumber, LocalDate fromDate, LocalDate toDate, String debitOrCredit, String tranId);
    
    List<AccountTransaction> filterTransactions(String accountNumber,
                                              LocalDate startDate,
                                              LocalDate endDate,
                                              String refNumber,
                                              String tranType);

    AccountStatementDTO fetchFullStatement(AccountStatementRequestDto requestDto, String continueToken);
}
